package a9;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import co.vpn.plusvpn.R;
import e8.a;
import v7.h9;
import v7.i9;
import w8.d0;

public abstract class e {

    /* renamed from: a  reason: collision with root package name */
    public int f672a;

    /* renamed from: b  reason: collision with root package name */
    public int f673b;

    /* renamed from: c  reason: collision with root package name */
    public int[] f674c = new int[0];

    /* renamed from: d  reason: collision with root package name */
    public int f675d;

    /* renamed from: e  reason: collision with root package name */
    public int f676e;

    /* renamed from: f  reason: collision with root package name */
    public int f677f;

    public e(Context context, AttributeSet attributeSet, int i10, int i11) {
        int f10;
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(R.dimen.mtrl_progress_track_thickness);
        int[] iArr = a.f18088d;
        d0.a(context, attributeSet, i10, i11);
        d0.b(context, attributeSet, iArr, i10, i11, new int[0]);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i10, i11);
        this.f672a = i9.s(context, obtainStyledAttributes, 8, dimensionPixelSize);
        this.f673b = Math.min(i9.s(context, obtainStyledAttributes, 7, 0), this.f672a / 2);
        this.f676e = obtainStyledAttributes.getInt(4, 0);
        this.f677f = obtainStyledAttributes.getInt(1, 0);
        if (!obtainStyledAttributes.hasValue(2)) {
            this.f674c = new int[]{h9.j(R.attr.colorPrimary, context, -1)};
        } else if (obtainStyledAttributes.peekValue(2).type != 1) {
            this.f674c = new int[]{obtainStyledAttributes.getColor(2, -1)};
        } else {
            int[] intArray = context.getResources().getIntArray(obtainStyledAttributes.getResourceId(2, -1));
            this.f674c = intArray;
            if (intArray.length == 0) {
                throw new IllegalArgumentException("indicatorColors cannot be empty when indicatorColor is not used.");
            }
        }
        if (obtainStyledAttributes.hasValue(6)) {
            f10 = obtainStyledAttributes.getColor(6, -1);
        } else {
            this.f675d = this.f674c[0];
            TypedArray obtainStyledAttributes2 = context.getTheme().obtainStyledAttributes(new int[]{16842803});
            float f11 = obtainStyledAttributes2.getFloat(0, 0.2f);
            obtainStyledAttributes2.recycle();
            f10 = h9.f(this.f675d, (int) (f11 * 255.0f));
        }
        this.f675d = f10;
        obtainStyledAttributes.recycle();
    }

    public abstract void a();
}
