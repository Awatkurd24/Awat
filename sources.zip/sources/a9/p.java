package a9;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import androidx.appcompat.widget.l3;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;
import java.util.Arrays;
import m.d;
import n2.b;
import v7.h9;

public final class p extends d {

    /* renamed from: j  reason: collision with root package name */
    public static final l3 f724j = new l3(15, Float.class, "animationFraction");

    /* renamed from: d  reason: collision with root package name */
    public ObjectAnimator f725d;

    /* renamed from: e  reason: collision with root package name */
    public final b f726e;

    /* renamed from: f  reason: collision with root package name */
    public final LinearProgressIndicatorSpec f727f;

    /* renamed from: g  reason: collision with root package name */
    public int f728g = 1;

    /* renamed from: h  reason: collision with root package name */
    public boolean f729h;

    /* renamed from: i  reason: collision with root package name */
    public float f730i;

    public p(LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(3);
        this.f727f = linearProgressIndicatorSpec;
        this.f726e = new b();
    }

    public final void A() {
        if (this.f725d == null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, f724j, new float[]{0.0f, 1.0f});
            this.f725d = ofFloat;
            ofFloat.setDuration(333);
            this.f725d.setInterpolator((TimeInterpolator) null);
            this.f725d.setRepeatCount(-1);
            this.f725d.addListener(new androidx.appcompat.widget.d(9, this));
        }
        L();
        this.f725d.start();
    }

    public final void D() {
    }

    public final void L() {
        this.f729h = true;
        this.f728g = 1;
        Arrays.fill((int[]) this.f22220c, h9.f(this.f727f.f674c[0], ((n) this.f22218a).f715j));
    }

    public final void e() {
        ObjectAnimator objectAnimator = this.f725d;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public final void t() {
        L();
    }

    public final void v(c cVar) {
    }

    public final void y() {
    }
}
