package a9;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import androidx.appcompat.widget.l3;
import com.android.volley.toolbox.ImageRequest;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import l3.c;
import m.d;
import n2.b;
import v7.h9;

public final class h extends d {

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f684l = {0, 1350, 2700, 4050};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f685m = {667, 2017, 3367, 4717};

    /* renamed from: n  reason: collision with root package name */
    public static final int[] f686n = {ImageRequest.DEFAULT_IMAGE_TIMEOUT_MS, 2350, 3700, 5050};

    /* renamed from: o  reason: collision with root package name */
    public static final l3 f687o;

    /* renamed from: p  reason: collision with root package name */
    public static final l3 f688p;

    /* renamed from: d  reason: collision with root package name */
    public ObjectAnimator f689d;

    /* renamed from: e  reason: collision with root package name */
    public ObjectAnimator f690e;

    /* renamed from: f  reason: collision with root package name */
    public final b f691f;

    /* renamed from: g  reason: collision with root package name */
    public final CircularProgressIndicatorSpec f692g;

    /* renamed from: h  reason: collision with root package name */
    public int f693h = 0;

    /* renamed from: i  reason: collision with root package name */
    public float f694i;

    /* renamed from: j  reason: collision with root package name */
    public float f695j;

    /* renamed from: k  reason: collision with root package name */
    public c f696k = null;

    static {
        Class<Float> cls = Float.class;
        f687o = new l3(12, cls, "animationFraction");
        f688p = new l3(13, cls, "completeEndFraction");
    }

    public h(CircularProgressIndicatorSpec circularProgressIndicatorSpec) {
        super(1);
        this.f692g = circularProgressIndicatorSpec;
        this.f691f = new b();
    }

    public final void A() {
        if (this.f689d == null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, f687o, new float[]{0.0f, 1.0f});
            this.f689d = ofFloat;
            ofFloat.setDuration(5400);
            this.f689d.setInterpolator((TimeInterpolator) null);
            this.f689d.setRepeatCount(-1);
            this.f689d.addListener(new g(this, 0));
        }
        if (this.f690e == null) {
            ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this, f688p, new float[]{0.0f, 1.0f});
            this.f690e = ofFloat2;
            ofFloat2.setDuration(333);
            this.f690e.setInterpolator(this.f691f);
            this.f690e.addListener(new g(this, 1));
        }
        L();
        this.f689d.start();
    }

    public final void D() {
        this.f696k = null;
    }

    public final void L() {
        this.f693h = 0;
        ((int[]) this.f22220c)[0] = h9.f(this.f692g.f674c[0], ((n) this.f22218a).f715j);
        this.f695j = 0.0f;
    }

    public final void e() {
        ObjectAnimator objectAnimator = this.f689d;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public final void t() {
        L();
    }

    public final void v(c cVar) {
        this.f696k = cVar;
    }

    public final void y() {
        ObjectAnimator objectAnimator = this.f690e;
        if (objectAnimator != null && !objectAnimator.isRunning()) {
            if (((n) this.f22218a).isVisible()) {
                this.f690e.start();
            } else {
                e();
            }
        }
    }
}
