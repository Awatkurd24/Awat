package a9;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import m.d;

public final class n extends l {

    /* renamed from: l  reason: collision with root package name */
    public final m f718l;

    /* renamed from: m  reason: collision with root package name */
    public d f719m;

    public n(Context context, e eVar, m mVar, d dVar) {
        super(context, eVar);
        this.f718l = mVar;
        mVar.f717b = this;
        this.f719m = dVar;
        dVar.f22218a = this;
    }

    public final void draw(Canvas canvas) {
        Rect rect = new Rect();
        if (!getBounds().isEmpty() && isVisible() && canvas.getClipBounds(rect)) {
            canvas.save();
            m mVar = this.f718l;
            Rect bounds = getBounds();
            float b5 = b();
            mVar.f716a.a();
            mVar.a(canvas, bounds, b5);
            m mVar2 = this.f718l;
            Paint paint = this.f714i;
            mVar2.c(canvas, paint);
            int i10 = 0;
            while (true) {
                d dVar = this.f719m;
                int[] iArr = (int[]) dVar.f22220c;
                if (i10 < iArr.length) {
                    m mVar3 = this.f718l;
                    float[] fArr = (float[]) dVar.f22219b;
                    int i11 = i10 * 2;
                    mVar3.b(canvas, paint, fArr[i11], fArr[i11 + 1], iArr[i10]);
                    i10++;
                } else {
                    canvas.restore();
                    return;
                }
            }
        }
    }

    public final boolean f(boolean z4, boolean z10, boolean z11) {
        boolean f10 = super.f(z4, z10, z11);
        if (!isRunning()) {
            this.f719m.e();
        }
        a aVar = this.f708c;
        ContentResolver contentResolver = this.f706a.getContentResolver();
        aVar.getClass();
        float f11 = Settings.Global.getFloat(contentResolver, "animator_duration_scale", 1.0f);
        if (z4 && (z11 || (Build.VERSION.SDK_INT <= 22 && f11 > 0.0f))) {
            this.f719m.A();
        }
        return f10;
    }

    public final int getIntrinsicHeight() {
        return this.f718l.d();
    }

    public final int getIntrinsicWidth() {
        return this.f718l.e();
    }
}
