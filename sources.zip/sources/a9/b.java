package a9;

import android.os.SystemClock;

public final class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f656a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d f657b;

    public /* synthetic */ b(d dVar, int i10) {
        this.f656a = i10;
        this.f657b = dVar;
    }

    public final void run() {
        int i10 = this.f656a;
        d dVar = this.f657b;
        switch (i10) {
            case 0:
                if (dVar.f664e > 0) {
                    SystemClock.uptimeMillis();
                }
                dVar.setVisibility(0);
                return;
            default:
                ((l) dVar.getCurrentDrawable()).e(false, false, true);
                if (dVar.getProgressDrawable() != null && dVar.getProgressDrawable().isVisible()) {
                    return;
                }
                if (dVar.getIndeterminateDrawable() == null || !dVar.getIndeterminateDrawable().isVisible()) {
                    dVar.setVisibility(4);
                    return;
                }
                return;
        }
    }
}
