package a9;

import b0.j0;
import b0.r;
import t.f;

public final class i extends j0 {
    public i(r rVar, f fVar) {
        super((Object) rVar);
    }

    public float q(Object obj) {
        return ((j) obj).f701o * 10000.0f;
    }

    public void s(Object obj, float f10) {
        j jVar = (j) obj;
        jVar.f701o = f10 / 10000.0f;
        jVar.invalidateSelf();
    }
}
