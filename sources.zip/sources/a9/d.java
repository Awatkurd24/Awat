package a9;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import android.widget.ProgressBar;
import co.vpn.plusvpn.R;
import com.android.volley.toolbox.ImageRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.WeakHashMap;
import k9.a;
import r1.h1;
import r1.s0;
import v7.h9;
import w8.d0;

public abstract class d extends ProgressBar {

    /* renamed from: a  reason: collision with root package name */
    public final e f660a;

    /* renamed from: b  reason: collision with root package name */
    public int f661b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f662c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f663d;

    /* renamed from: e  reason: collision with root package name */
    public final int f664e;

    /* renamed from: f  reason: collision with root package name */
    public a f665f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f666g = false;

    /* renamed from: h  reason: collision with root package name */
    public int f667h = 4;

    /* renamed from: i  reason: collision with root package name */
    public final b f668i = new b(this, 0);

    /* renamed from: j  reason: collision with root package name */
    public final b f669j = new b(this, 1);

    /* renamed from: k  reason: collision with root package name */
    public final c f670k = new c(this, 0);

    /* renamed from: l  reason: collision with root package name */
    public final c f671l = new c(this, 1);

    /* JADX WARNING: type inference failed for: r9v4, types: [a9.a, java.lang.Object] */
    public d(Context context, AttributeSet attributeSet, int i10, int i11) {
        super(a.a(context, attributeSet, i10, 2132018297), attributeSet, i10);
        Context context2 = getContext();
        this.f660a = a(context2, attributeSet);
        TypedArray h10 = d0.h(context2, attributeSet, e8.a.f18088d, i10, i11, new int[0]);
        h10.getInt(5, -1);
        this.f664e = Math.min(h10.getInt(3, -1), ImageRequest.DEFAULT_IMAGE_TIMEOUT_MS);
        h10.recycle();
        this.f665f = new Object();
        this.f663d = true;
    }

    private m getCurrentDrawingDelegate() {
        if (isIndeterminate()) {
            if (getIndeterminateDrawable() == null) {
                return null;
            }
            return getIndeterminateDrawable().f718l;
        } else if (getProgressDrawable() == null) {
            return null;
        } else {
            return getProgressDrawable().f698l;
        }
    }

    public abstract e a(Context context, AttributeSet attributeSet);

    public void b(int i10, boolean z4) {
        if (!isIndeterminate()) {
            super.setProgress(i10);
            if (getProgressDrawable() != null && !z4) {
                getProgressDrawable().jumpToCurrentState();
            }
        } else if (getProgressDrawable() != null) {
            this.f661b = i10;
            this.f662c = z4;
            this.f666g = true;
            if (getIndeterminateDrawable().isVisible()) {
                a aVar = this.f665f;
                ContentResolver contentResolver = getContext().getContentResolver();
                aVar.getClass();
                if (Settings.Global.getFloat(contentResolver, "animator_duration_scale", 1.0f) != 0.0f) {
                    getIndeterminateDrawable().f719m.y();
                    return;
                }
            }
            this.f670k.a(getIndeterminateDrawable());
        }
    }

    public final boolean c() {
        WeakHashMap weakHashMap = h1.f25195a;
        if (s0.b(this) && getWindowVisibility() == 0) {
            View view = this;
            while (true) {
                if (view.getVisibility() != 0) {
                    break;
                }
                ViewParent parent = view.getParent();
                if (parent == null) {
                    if (getWindowVisibility() == 0) {
                        return true;
                    }
                } else if (!(parent instanceof View)) {
                    break;
                } else {
                    view = (View) parent;
                }
            }
        }
        return false;
    }

    public Drawable getCurrentDrawable() {
        return isIndeterminate() ? getIndeterminateDrawable() : getProgressDrawable();
    }

    public int getHideAnimationBehavior() {
        return this.f660a.f677f;
    }

    public n getIndeterminateDrawable() {
        return (n) super.getIndeterminateDrawable();
    }

    public int[] getIndicatorColor() {
        return this.f660a.f674c;
    }

    public j getProgressDrawable() {
        return (j) super.getProgressDrawable();
    }

    public int getShowAnimationBehavior() {
        return this.f660a.f676e;
    }

    public int getTrackColor() {
        return this.f660a.f675d;
    }

    public int getTrackCornerRadius() {
        return this.f660a.f673b;
    }

    public int getTrackThickness() {
        return this.f660a.f672a;
    }

    public final void invalidate() {
        super.invalidate();
        if (getCurrentDrawable() != null) {
            getCurrentDrawable().invalidateSelf();
        }
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!(getProgressDrawable() == null || getIndeterminateDrawable() == null)) {
            getIndeterminateDrawable().f719m.v(this.f670k);
        }
        j progressDrawable = getProgressDrawable();
        c cVar = this.f671l;
        if (progressDrawable != null) {
            j progressDrawable2 = getProgressDrawable();
            if (progressDrawable2.f711f == null) {
                progressDrawable2.f711f = new ArrayList();
            }
            if (!progressDrawable2.f711f.contains(cVar)) {
                progressDrawable2.f711f.add(cVar);
            }
        }
        if (getIndeterminateDrawable() != null) {
            n indeterminateDrawable = getIndeterminateDrawable();
            if (indeterminateDrawable.f711f == null) {
                indeterminateDrawable.f711f = new ArrayList();
            }
            if (!indeterminateDrawable.f711f.contains(cVar)) {
                indeterminateDrawable.f711f.add(cVar);
            }
        }
        if (c()) {
            if (this.f664e > 0) {
                SystemClock.uptimeMillis();
            }
            setVisibility(0);
        }
    }

    public final void onDetachedFromWindow() {
        removeCallbacks(this.f669j);
        removeCallbacks(this.f668i);
        ((l) getCurrentDrawable()).e(false, false, false);
        n indeterminateDrawable = getIndeterminateDrawable();
        c cVar = this.f671l;
        if (indeterminateDrawable != null) {
            getIndeterminateDrawable().g(cVar);
            getIndeterminateDrawable().f719m.D();
        }
        if (getProgressDrawable() != null) {
            getProgressDrawable().g(cVar);
        }
        super.onDetachedFromWindow();
    }

    public final synchronized void onDraw(Canvas canvas) {
        try {
            int save = canvas.save();
            if (getPaddingLeft() == 0) {
                if (getPaddingTop() != 0) {
                }
                if (!(getPaddingRight() == 0 && getPaddingBottom() == 0)) {
                    canvas.clipRect(0, 0, getWidth() - (getPaddingLeft() + getPaddingRight()), getHeight() - (getPaddingTop() + getPaddingBottom()));
                }
                getCurrentDrawable().draw(canvas);
                canvas.restoreToCount(save);
            }
            canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            canvas.clipRect(0, 0, getWidth() - (getPaddingLeft() + getPaddingRight()), getHeight() - (getPaddingTop() + getPaddingBottom()));
            getCurrentDrawable().draw(canvas);
            canvas.restoreToCount(save);
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized void onMeasure(int i10, int i11) {
        try {
            m currentDrawingDelegate = getCurrentDrawingDelegate();
            if (currentDrawingDelegate != null) {
                setMeasuredDimension(currentDrawingDelegate.e() < 0 ? View.getDefaultSize(getSuggestedMinimumWidth(), i10) : currentDrawingDelegate.e() + getPaddingLeft() + getPaddingRight(), currentDrawingDelegate.d() < 0 ? View.getDefaultSize(getSuggestedMinimumHeight(), i11) : currentDrawingDelegate.d() + getPaddingTop() + getPaddingBottom());
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final void onVisibilityChanged(View view, int i10) {
        boolean z4;
        super.onVisibilityChanged(view, i10);
        if (i10 == 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (this.f663d) {
            ((l) getCurrentDrawable()).e(c(), false, z4);
        }
    }

    public final void onWindowVisibilityChanged(int i10) {
        super.onWindowVisibilityChanged(i10);
        if (this.f663d) {
            ((l) getCurrentDrawable()).e(c(), false, false);
        }
    }

    public void setAnimatorDurationScaleProvider(a aVar) {
        this.f665f = aVar;
        if (getProgressDrawable() != null) {
            getProgressDrawable().f708c = aVar;
        }
        if (getIndeterminateDrawable() != null) {
            getIndeterminateDrawable().f708c = aVar;
        }
    }

    public void setHideAnimationBehavior(int i10) {
        this.f660a.f677f = i10;
        invalidate();
    }

    public synchronized void setIndeterminate(boolean z4) {
        try {
            if (z4 != isIndeterminate()) {
                l lVar = (l) getCurrentDrawable();
                if (lVar != null) {
                    lVar.e(false, false, false);
                }
                super.setIndeterminate(z4);
                l lVar2 = (l) getCurrentDrawable();
                if (lVar2 != null) {
                    lVar2.e(c(), false, false);
                }
                if ((lVar2 instanceof n) && c()) {
                    ((n) lVar2).f719m.A();
                }
                this.f666g = false;
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public void setIndeterminateDrawable(Drawable drawable) {
        if (drawable == null) {
            super.setIndeterminateDrawable((Drawable) null);
        } else if (drawable instanceof n) {
            ((l) drawable).e(false, false, false);
            super.setIndeterminateDrawable(drawable);
        } else {
            throw new IllegalArgumentException("Cannot set framework drawable as indeterminate drawable.");
        }
    }

    public void setIndicatorColor(int... iArr) {
        if (iArr.length == 0) {
            iArr = new int[]{h9.j(R.attr.colorPrimary, getContext(), -1)};
        }
        if (!Arrays.equals(getIndicatorColor(), iArr)) {
            this.f660a.f674c = iArr;
            getIndeterminateDrawable().f719m.t();
            invalidate();
        }
    }

    public synchronized void setProgress(int i10) {
        if (!isIndeterminate()) {
            b(i10, false);
        }
    }

    public void setProgressDrawable(Drawable drawable) {
        if (drawable == null) {
            super.setProgressDrawable((Drawable) null);
        } else if (drawable instanceof j) {
            j jVar = (j) drawable;
            jVar.e(false, false, false);
            super.setProgressDrawable(jVar);
            jVar.setLevel((int) ((((float) getProgress()) / ((float) getMax())) * 10000.0f));
        } else {
            throw new IllegalArgumentException("Cannot set framework drawable as progress drawable.");
        }
    }

    public void setShowAnimationBehavior(int i10) {
        this.f660a.f676e = i10;
        invalidate();
    }

    public void setTrackColor(int i10) {
        e eVar = this.f660a;
        if (eVar.f675d != i10) {
            eVar.f675d = i10;
            invalidate();
        }
    }

    public void setTrackCornerRadius(int i10) {
        e eVar = this.f660a;
        if (eVar.f673b != i10) {
            eVar.f673b = Math.min(i10, eVar.f672a / 2);
        }
    }

    public void setTrackThickness(int i10) {
        e eVar = this.f660a;
        if (eVar.f672a != i10) {
            eVar.f672a = i10;
            requestLayout();
        }
    }

    public void setVisibilityAfterHide(int i10) {
        if (i10 == 0 || i10 == 4 || i10 == 8) {
            this.f667h = i10;
            return;
        }
        throw new IllegalArgumentException("The component's visibility must be one of VISIBLE, INVISIBLE, and GONE defined in View.");
    }
}
