package a9;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Looper;
import android.provider.Settings;
import android.util.AndroidRuntimeException;
import b0.j0;
import g2.c;
import g2.d;
import g2.h;
import g2.i;
import java.util.ArrayList;
import v7.h9;

public final class j extends l {

    /* renamed from: q  reason: collision with root package name */
    public static final i f697q = new j0((Object) "indicatorLevel");

    /* renamed from: l  reason: collision with root package name */
    public final m f698l;

    /* renamed from: m  reason: collision with root package name */
    public final i f699m;

    /* renamed from: n  reason: collision with root package name */
    public final h f700n;

    /* renamed from: o  reason: collision with root package name */
    public float f701o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f702p = false;

    public j(Context context, e eVar, m mVar) {
        super(context, eVar);
        this.f698l = mVar;
        mVar.f717b = this;
        i iVar = new i();
        this.f699m = iVar;
        iVar.f19062b = (double) 1.0f;
        iVar.f19063c = false;
        iVar.f19061a = Math.sqrt((double) 50.0f);
        iVar.f19063c = false;
        h hVar = new h(this);
        this.f700n = hVar;
        hVar.f19058m = iVar;
        if (this.f713h != 1.0f) {
            this.f713h = 1.0f;
            invalidateSelf();
        }
    }

    public final void draw(Canvas canvas) {
        Rect rect = new Rect();
        if (!getBounds().isEmpty() && isVisible() && canvas.getClipBounds(rect)) {
            canvas.save();
            m mVar = this.f698l;
            Rect bounds = getBounds();
            float b5 = b();
            mVar.f716a.a();
            mVar.a(canvas, bounds, b5);
            m mVar2 = this.f698l;
            Paint paint = this.f714i;
            mVar2.c(canvas, paint);
            Canvas canvas2 = canvas;
            this.f698l.b(canvas2, paint, 0.0f, this.f701o, h9.f(this.f707b.f674c[0], this.f715j));
            canvas.restore();
        }
    }

    public final boolean f(boolean z4, boolean z10, boolean z11) {
        boolean f10 = super.f(z4, z10, z11);
        a aVar = this.f708c;
        ContentResolver contentResolver = this.f706a.getContentResolver();
        aVar.getClass();
        float f11 = Settings.Global.getFloat(contentResolver, "animator_duration_scale", 1.0f);
        if (f11 == 0.0f) {
            this.f702p = true;
        } else {
            this.f702p = false;
            float f12 = 50.0f / f11;
            i iVar = this.f699m;
            iVar.getClass();
            if (f12 > 0.0f) {
                iVar.f19061a = Math.sqrt((double) f12);
                iVar.f19063c = false;
            } else {
                throw new IllegalArgumentException("Spring stiffness constant must be positive.");
            }
        }
        return f10;
    }

    public final int getIntrinsicHeight() {
        return this.f698l.d();
    }

    public final int getIntrinsicWidth() {
        return this.f698l.e();
    }

    public final void jumpToCurrentState() {
        this.f700n.b();
        this.f701o = ((float) getLevel()) / 10000.0f;
        invalidateSelf();
    }

    public final boolean onLevelChange(int i10) {
        boolean z4 = this.f702p;
        h hVar = this.f700n;
        if (z4) {
            hVar.b();
            this.f701o = ((float) i10) / 10000.0f;
            invalidateSelf();
        } else {
            hVar.f19047b = this.f701o * 10000.0f;
            hVar.f19048c = true;
            float f10 = (float) i10;
            if (hVar.f19051f) {
                hVar.f19059n = f10;
            } else {
                if (hVar.f19058m == null) {
                    hVar.f19058m = new i(f10);
                }
                i iVar = hVar.f19058m;
                double d10 = (double) f10;
                iVar.f19069i = d10;
                double d11 = (double) ((float) d10);
                if (d11 > ((double) hVar.f19052g)) {
                    throw new UnsupportedOperationException("Final position of the spring cannot be greater than the max value.");
                } else if (d11 >= ((double) hVar.f19053h)) {
                    double abs = Math.abs((double) (hVar.f19055j * 0.75f));
                    iVar.f19064d = abs;
                    iVar.f19065e = abs * 62.5d;
                    if (Looper.myLooper() == Looper.getMainLooper()) {
                        boolean z10 = hVar.f19051f;
                        if (!z10 && !z10) {
                            hVar.f19051f = true;
                            if (!hVar.f19048c) {
                                hVar.f19047b = hVar.f19050e.q(hVar.f19049d);
                            }
                            float f11 = hVar.f19047b;
                            if (f11 > hVar.f19052g || f11 < hVar.f19053h) {
                                throw new IllegalArgumentException("Starting value need to be in between min value and max value");
                            }
                            ThreadLocal threadLocal = d.f19030g;
                            if (threadLocal.get() == null) {
                                threadLocal.set(new d());
                            }
                            d dVar = (d) threadLocal.get();
                            ArrayList arrayList = dVar.f19032b;
                            if (arrayList.size() == 0) {
                                if (dVar.f19034d == null) {
                                    dVar.f19034d = new c(dVar.f19033c);
                                }
                                dVar.f19034d.y();
                            }
                            if (!arrayList.contains(hVar)) {
                                arrayList.add(hVar);
                            }
                        }
                    } else {
                        throw new AndroidRuntimeException("Animations may only be started on the main thread");
                    }
                } else {
                    throw new UnsupportedOperationException("Final position of the spring cannot be less than the min value.");
                }
            }
        }
        return true;
    }
}
