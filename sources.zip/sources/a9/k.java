package a9;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import java.util.ArrayList;
import java.util.Iterator;
import l3.c;

public final class k extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f703a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ l f704b;

    public /* synthetic */ k(l lVar, int i10) {
        this.f703a = i10;
        this.f704b = lVar;
    }

    public final void onAnimationEnd(Animator animator) {
        switch (this.f703a) {
            case 1:
                super.onAnimationEnd(animator);
                l lVar = this.f704b;
                k.super.setVisible(false, false);
                ArrayList arrayList = lVar.f711f;
                if (arrayList != null && !lVar.f712g) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        ((c) it.next()).a(lVar);
                    }
                    return;
                }
                return;
            default:
                super.onAnimationEnd(animator);
                return;
        }
    }

    public final void onAnimationStart(Animator animator) {
        switch (this.f703a) {
            case 0:
                super.onAnimationStart(animator);
                l lVar = this.f704b;
                ArrayList arrayList = lVar.f711f;
                if (arrayList != null && !lVar.f712g) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        ((c) it.next()).b(lVar);
                    }
                    return;
                }
                return;
            default:
                super.onAnimationStart(animator);
                return;
        }
    }
}
