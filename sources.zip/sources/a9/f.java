package a9;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import v7.h9;

public final class f extends m {

    /* renamed from: c  reason: collision with root package name */
    public int f678c = 1;

    /* renamed from: d  reason: collision with root package name */
    public float f679d;

    /* renamed from: e  reason: collision with root package name */
    public float f680e;

    /* renamed from: f  reason: collision with root package name */
    public float f681f;

    public f(CircularProgressIndicatorSpec circularProgressIndicatorSpec) {
        super(circularProgressIndicatorSpec);
    }

    public final void a(Canvas canvas, Rect rect, float f10) {
        int i10;
        float width = ((float) rect.width()) / ((float) g());
        float height = ((float) rect.height()) / ((float) g());
        e eVar = this.f716a;
        float f11 = (((float) ((CircularProgressIndicatorSpec) eVar).f16694g) / 2.0f) + ((float) ((CircularProgressIndicatorSpec) eVar).f16695h);
        canvas.translate((f11 * width) + ((float) rect.left), (f11 * height) + ((float) rect.top));
        canvas.scale(width, height);
        canvas.rotate(-90.0f);
        float f12 = -f11;
        canvas.clipRect(f12, f12, f11, f11);
        if (((CircularProgressIndicatorSpec) eVar).f16696i == 0) {
            i10 = 1;
        } else {
            i10 = -1;
        }
        this.f678c = i10;
        this.f679d = ((float) ((CircularProgressIndicatorSpec) eVar).f672a) * f10;
        this.f680e = ((float) ((CircularProgressIndicatorSpec) eVar).f673b) * f10;
        this.f681f = ((float) (((CircularProgressIndicatorSpec) eVar).f16694g - ((CircularProgressIndicatorSpec) eVar).f672a)) / 2.0f;
        if ((this.f717b.d() && ((CircularProgressIndicatorSpec) eVar).f676e == 2) || (this.f717b.c() && ((CircularProgressIndicatorSpec) eVar).f677f == 1)) {
            this.f681f = (((1.0f - f10) * ((float) ((CircularProgressIndicatorSpec) eVar).f672a)) / 2.0f) + this.f681f;
        } else if ((this.f717b.d() && ((CircularProgressIndicatorSpec) eVar).f676e == 1) || (this.f717b.c() && ((CircularProgressIndicatorSpec) eVar).f677f == 2)) {
            this.f681f -= ((1.0f - f10) * ((float) ((CircularProgressIndicatorSpec) eVar).f672a)) / 2.0f;
        }
    }

    public final void b(Canvas canvas, Paint paint, float f10, float f11, int i10) {
        Paint paint2 = paint;
        if (f10 != f11) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.BUTT);
            paint.setAntiAlias(true);
            paint.setColor(i10);
            paint.setStrokeWidth(this.f679d);
            float f12 = (float) this.f678c;
            float f13 = f10 * 360.0f * f12;
            float f14 = (f11 >= f10 ? f11 - f10 : (1.0f + f11) - f10) * 360.0f * f12;
            float f15 = this.f681f;
            float f16 = -f15;
            canvas.drawArc(new RectF(f16, f16, f15, f15), f13, f14, false, paint);
            if (this.f680e > 0.0f && Math.abs(f14) < 360.0f) {
                paint.setStyle(Paint.Style.FILL);
                Canvas canvas2 = canvas;
                Paint paint3 = paint;
                f(canvas2, paint3, this.f679d, this.f680e, f13);
                f(canvas2, paint3, this.f679d, this.f680e, f13 + f14);
            }
        }
    }

    public final void c(Canvas canvas, Paint paint) {
        int f10 = h9.f(((CircularProgressIndicatorSpec) this.f716a).f675d, this.f717b.f715j);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setAntiAlias(true);
        paint.setColor(f10);
        paint.setStrokeWidth(this.f679d);
        float f11 = this.f681f;
        canvas.drawArc(new RectF(-f11, -f11, f11, f11), 0.0f, 360.0f, false, paint);
    }

    public final int d() {
        return g();
    }

    public final int e() {
        return g();
    }

    public final void f(Canvas canvas, Paint paint, float f10, float f11, float f12) {
        canvas.save();
        canvas.rotate(f12);
        float f13 = this.f681f;
        float f14 = f10 / 2.0f;
        canvas.drawRoundRect(new RectF(f13 - f14, f11, f13 + f14, -f11), f11, f11, paint);
        canvas.restore();
    }

    public final int g() {
        e eVar = this.f716a;
        return (((CircularProgressIndicatorSpec) eVar).f16695h * 2) + ((CircularProgressIndicatorSpec) eVar).f16694g;
    }
}
