package a9;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import l3.c;

public final class q extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f731a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ r f732b;

    public /* synthetic */ q(r rVar, int i10) {
        this.f731a = i10;
        this.f732b = rVar;
    }

    public final void onAnimationEnd(Animator animator) {
        switch (this.f731a) {
            case 1:
                super.onAnimationEnd(animator);
                r rVar = this.f732b;
                rVar.e();
                c cVar = rVar.f743k;
                if (cVar != null) {
                    cVar.a((n) rVar.f22218a);
                    return;
                }
                return;
            default:
                super.onAnimationEnd(animator);
                return;
        }
    }

    public final void onAnimationRepeat(Animator animator) {
        switch (this.f731a) {
            case 0:
                super.onAnimationRepeat(animator);
                r rVar = this.f732b;
                rVar.f740h = (rVar.f740h + 1) % rVar.f739g.f674c.length;
                rVar.f741i = true;
                return;
            default:
                super.onAnimationRepeat(animator);
                return;
        }
    }
}
