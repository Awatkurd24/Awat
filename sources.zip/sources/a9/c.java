package a9;

import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.google.android.material.checkbox.MaterialCheckBox;
import k1.b;

public final class c extends l3.c {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f658b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ View f659c;

    public c(View view, int i10) {
        this.f658b = i10;
        this.f659c = view;
    }

    public final void a(Drawable drawable) {
        int i10 = this.f658b;
        View view = this.f659c;
        switch (i10) {
            case 0:
                d dVar = (d) view;
                dVar.setIndeterminate(false);
                dVar.b(dVar.f661b, dVar.f662c);
                return;
            case 1:
                d dVar2 = (d) view;
                if (!dVar2.f666g) {
                    dVar2.setVisibility(dVar2.f667h);
                    return;
                }
                return;
            default:
                ColorStateList colorStateList = ((MaterialCheckBox) view).f16441o;
                if (colorStateList != null) {
                    b.h(drawable, colorStateList);
                    return;
                }
                return;
        }
    }

    public final void b(Drawable drawable) {
        switch (this.f658b) {
            case 2:
                MaterialCheckBox materialCheckBox = (MaterialCheckBox) this.f659c;
                ColorStateList colorStateList = materialCheckBox.f16441o;
                if (colorStateList != null) {
                    b.g(drawable, colorStateList.getColorForState(materialCheckBox.f16445s, colorStateList.getDefaultColor()));
                    return;
                }
                return;
            default:
                return;
        }
    }
}
