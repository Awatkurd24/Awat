package a9;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import l3.c;

public final class g extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f682a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ h f683b;

    public /* synthetic */ g(h hVar, int i10) {
        this.f682a = i10;
        this.f683b = hVar;
    }

    public final void onAnimationEnd(Animator animator) {
        switch (this.f682a) {
            case 1:
                super.onAnimationEnd(animator);
                h hVar = this.f683b;
                hVar.e();
                c cVar = hVar.f696k;
                if (cVar != null) {
                    cVar.a((n) hVar.f22218a);
                    return;
                }
                return;
            default:
                super.onAnimationEnd(animator);
                return;
        }
    }

    public final void onAnimationRepeat(Animator animator) {
        switch (this.f682a) {
            case 0:
                super.onAnimationRepeat(animator);
                h hVar = this.f683b;
                hVar.f693h = (hVar.f693h + 4) % hVar.f692g.f674c.length;
                return;
            default:
                super.onAnimationRepeat(animator);
                return;
        }
    }
}
