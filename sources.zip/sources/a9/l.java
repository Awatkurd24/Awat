package a9;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.provider.Settings;
import androidx.appcompat.widget.l3;
import f8.a;
import java.util.ArrayList;

public abstract class l extends Drawable implements Animatable {

    /* renamed from: k  reason: collision with root package name */
    public static final l3 f705k = new l3(14, Float.class, "growFraction");

    /* renamed from: a  reason: collision with root package name */
    public final Context f706a;

    /* renamed from: b  reason: collision with root package name */
    public final e f707b;

    /* renamed from: c  reason: collision with root package name */
    public a f708c;

    /* renamed from: d  reason: collision with root package name */
    public ValueAnimator f709d;

    /* renamed from: e  reason: collision with root package name */
    public ValueAnimator f710e;

    /* renamed from: f  reason: collision with root package name */
    public ArrayList f711f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f712g;

    /* renamed from: h  reason: collision with root package name */
    public float f713h;

    /* renamed from: i  reason: collision with root package name */
    public final Paint f714i = new Paint();

    /* renamed from: j  reason: collision with root package name */
    public int f715j;

    /* JADX WARNING: type inference failed for: r2v1, types: [a9.a, java.lang.Object] */
    public l(Context context, e eVar) {
        this.f706a = context;
        this.f707b = eVar;
        this.f708c = new Object();
        setAlpha(255);
    }

    public final float b() {
        e eVar = this.f707b;
        if (eVar.f676e == 0 && eVar.f677f == 0) {
            return 1.0f;
        }
        return this.f713h;
    }

    public final boolean c() {
        ValueAnimator valueAnimator = this.f710e;
        return valueAnimator != null && valueAnimator.isRunning();
    }

    public final boolean d() {
        ValueAnimator valueAnimator = this.f709d;
        return valueAnimator != null && valueAnimator.isRunning();
    }

    public final boolean e(boolean z4, boolean z10, boolean z11) {
        boolean z12;
        a aVar = this.f708c;
        ContentResolver contentResolver = this.f706a.getContentResolver();
        aVar.getClass();
        float f10 = Settings.Global.getFloat(contentResolver, "animator_duration_scale", 1.0f);
        if (!z11 || f10 <= 0.0f) {
            z12 = false;
        } else {
            z12 = true;
        }
        return f(z4, z10, z12);
    }

    public boolean f(boolean z4, boolean z10, boolean z11) {
        ValueAnimator valueAnimator;
        ValueAnimator valueAnimator2;
        ValueAnimator valueAnimator3 = this.f709d;
        l3 l3Var = f705k;
        boolean z12 = false;
        if (valueAnimator3 == null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, l3Var, new float[]{0.0f, 1.0f});
            this.f709d = ofFloat;
            ofFloat.setDuration(500);
            this.f709d.setInterpolator(a.f18599b);
            ValueAnimator valueAnimator4 = this.f709d;
            if (valueAnimator4 == null || !valueAnimator4.isRunning()) {
                this.f709d = valueAnimator4;
                valueAnimator4.addListener(new k(this, 0));
            } else {
                throw new IllegalArgumentException("Cannot set showAnimator while the current showAnimator is running.");
            }
        }
        if (this.f710e == null) {
            ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this, l3Var, new float[]{1.0f, 0.0f});
            this.f710e = ofFloat2;
            ofFloat2.setDuration(500);
            this.f710e.setInterpolator(a.f18599b);
            ValueAnimator valueAnimator5 = this.f710e;
            if (valueAnimator5 == null || !valueAnimator5.isRunning()) {
                this.f710e = valueAnimator5;
                valueAnimator5.addListener(new k(this, 1));
            } else {
                throw new IllegalArgumentException("Cannot set hideAnimator while the current hideAnimator is running.");
            }
        }
        if (!isVisible() && !z4) {
            return false;
        }
        if (z4) {
            valueAnimator = this.f709d;
        } else {
            valueAnimator = this.f710e;
        }
        if (z4) {
            valueAnimator2 = this.f710e;
        } else {
            valueAnimator2 = this.f709d;
        }
        if (!z11) {
            if (valueAnimator2.isRunning()) {
                boolean z13 = this.f712g;
                this.f712g = true;
                valueAnimator2.cancel();
                this.f712g = z13;
            }
            if (valueAnimator.isRunning()) {
                valueAnimator.end();
            } else {
                boolean z14 = this.f712g;
                this.f712g = true;
                valueAnimator.end();
                this.f712g = z14;
            }
            return super.setVisible(z4, false);
        } else if (z11 && valueAnimator.isRunning()) {
            return false;
        } else {
            if (!z4 || super.setVisible(z4, false)) {
                z12 = true;
            }
            e eVar = this.f707b;
            if (!z4 ? eVar.f677f == 0 : eVar.f676e == 0) {
                boolean z15 = this.f712g;
                this.f712g = true;
                valueAnimator.end();
                this.f712g = z15;
                return z12;
            }
            if (z10 || !valueAnimator.isPaused()) {
                valueAnimator.start();
            } else {
                valueAnimator.resume();
            }
            return z12;
        }
    }

    public final void g(c cVar) {
        ArrayList arrayList = this.f711f;
        if (arrayList != null && arrayList.contains(cVar)) {
            this.f711f.remove(cVar);
            if (this.f711f.isEmpty()) {
                this.f711f = null;
            }
        }
    }

    public final int getAlpha() {
        return this.f715j;
    }

    public final int getOpacity() {
        return -3;
    }

    public final boolean isRunning() {
        return d() || c();
    }

    public final void setAlpha(int i10) {
        this.f715j = i10;
        invalidateSelf();
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.f714i.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public final boolean setVisible(boolean z4, boolean z10) {
        return e(z4, z10, true);
    }

    public final void start() {
        f(true, true, false);
    }

    public final void stop() {
        f(false, true, false);
    }
}
