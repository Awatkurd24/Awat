package a9;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public abstract class m {

    /* renamed from: a  reason: collision with root package name */
    public final e f716a;

    /* renamed from: b  reason: collision with root package name */
    public l f717b;

    public m(e eVar) {
        this.f716a = eVar;
    }

    public abstract void a(Canvas canvas, Rect rect, float f10);

    public abstract void b(Canvas canvas, Paint paint, float f10, float f11, int i10);

    public abstract void c(Canvas canvas, Paint paint);

    public abstract int d();

    public abstract int e();
}
