package a9;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.l3;
import co.vpn.plusvpn.R;
import com.android.volley.toolbox.ImageRequest;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;
import l3.c;
import m.d;
import v7.h9;

public final class r extends d {

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f733l = {533, 567, 850, 750};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f734m = {1267, ImageRequest.DEFAULT_IMAGE_TIMEOUT_MS, 333, 0};

    /* renamed from: n  reason: collision with root package name */
    public static final l3 f735n = new l3(16, Float.class, "animationFraction");

    /* renamed from: d  reason: collision with root package name */
    public ObjectAnimator f736d;

    /* renamed from: e  reason: collision with root package name */
    public ObjectAnimator f737e;

    /* renamed from: f  reason: collision with root package name */
    public final Interpolator[] f738f;

    /* renamed from: g  reason: collision with root package name */
    public final LinearProgressIndicatorSpec f739g;

    /* renamed from: h  reason: collision with root package name */
    public int f740h = 0;

    /* renamed from: i  reason: collision with root package name */
    public boolean f741i;

    /* renamed from: j  reason: collision with root package name */
    public float f742j;

    /* renamed from: k  reason: collision with root package name */
    public c f743k = null;

    public r(Context context, LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(2);
        this.f739g = linearProgressIndicatorSpec;
        this.f738f = new Interpolator[]{AnimationUtils.loadInterpolator(context, R.anim.linear_indeterminate_line1_head_interpolator), AnimationUtils.loadInterpolator(context, R.anim.linear_indeterminate_line1_tail_interpolator), AnimationUtils.loadInterpolator(context, R.anim.linear_indeterminate_line2_head_interpolator), AnimationUtils.loadInterpolator(context, R.anim.linear_indeterminate_line2_tail_interpolator)};
    }

    public final void A() {
        ObjectAnimator objectAnimator = this.f736d;
        l3 l3Var = f735n;
        if (objectAnimator == null) {
            ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, l3Var, new float[]{0.0f, 1.0f});
            this.f736d = ofFloat;
            ofFloat.setDuration(1800);
            this.f736d.setInterpolator((TimeInterpolator) null);
            this.f736d.setRepeatCount(-1);
            this.f736d.addListener(new q(this, 0));
        }
        if (this.f737e == null) {
            ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this, l3Var, new float[]{1.0f});
            this.f737e = ofFloat2;
            ofFloat2.setDuration(1800);
            this.f737e.setInterpolator((TimeInterpolator) null);
            this.f737e.addListener(new q(this, 1));
        }
        L();
        this.f736d.start();
    }

    public final void D() {
        this.f743k = null;
    }

    public final void L() {
        this.f740h = 0;
        int f10 = h9.f(this.f739g.f674c[0], ((n) this.f22218a).f715j);
        int[] iArr = (int[]) this.f22220c;
        iArr[0] = f10;
        iArr[1] = f10;
    }

    public final void e() {
        ObjectAnimator objectAnimator = this.f736d;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public final void t() {
        L();
    }

    public final void v(c cVar) {
        this.f743k = cVar;
    }

    public final void y() {
        ObjectAnimator objectAnimator = this.f737e;
        if (objectAnimator != null && !objectAnimator.isRunning()) {
            e();
            if (((n) this.f22218a).isVisible()) {
                this.f737e.setFloatValues(new float[]{this.f742j, 1.0f});
                this.f737e.setDuration((long) ((1.0f - this.f742j) * 1800.0f));
                this.f737e.start();
            }
        }
    }
}
