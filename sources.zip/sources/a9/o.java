package a9;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;
import v7.h9;

public final class o extends m {

    /* renamed from: c  reason: collision with root package name */
    public float f720c = 300.0f;

    /* renamed from: d  reason: collision with root package name */
    public float f721d;

    /* renamed from: e  reason: collision with root package name */
    public float f722e;

    /* renamed from: f  reason: collision with root package name */
    public Path f723f;

    public o(LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(linearProgressIndicatorSpec);
    }

    public final void a(Canvas canvas, Rect rect, float f10) {
        this.f720c = (float) rect.width();
        e eVar = this.f716a;
        float f11 = (float) ((LinearProgressIndicatorSpec) eVar).f672a;
        canvas.translate((((float) rect.width()) / 2.0f) + ((float) rect.left), Math.max(0.0f, ((float) (rect.height() - ((LinearProgressIndicatorSpec) eVar).f672a)) / 2.0f) + (((float) rect.height()) / 2.0f) + ((float) rect.top));
        if (((LinearProgressIndicatorSpec) eVar).f16700i) {
            canvas.scale(-1.0f, 1.0f);
        }
        if ((this.f717b.d() && ((LinearProgressIndicatorSpec) eVar).f676e == 1) || (this.f717b.c() && ((LinearProgressIndicatorSpec) eVar).f677f == 2)) {
            canvas.scale(1.0f, -1.0f);
        }
        if (this.f717b.d() || this.f717b.c()) {
            canvas.translate(0.0f, ((f10 - 1.0f) * ((float) ((LinearProgressIndicatorSpec) eVar).f672a)) / 2.0f);
        }
        float f12 = this.f720c;
        canvas.clipRect((-f12) / 2.0f, (-f11) / 2.0f, f12 / 2.0f, f11 / 2.0f);
        this.f721d = ((float) ((LinearProgressIndicatorSpec) eVar).f672a) * f10;
        this.f722e = ((float) ((LinearProgressIndicatorSpec) eVar).f673b) * f10;
    }

    public final void b(Canvas canvas, Paint paint, float f10, float f11, int i10) {
        if (f10 != f11) {
            float f12 = this.f720c;
            float f13 = (-f12) / 2.0f;
            float f14 = (f11 * f12) + f13;
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            paint.setColor(i10);
            canvas.save();
            canvas.clipPath(this.f723f);
            float f15 = this.f721d;
            RectF rectF = new RectF(((f10 * f12) + f13) - (this.f722e * 2.0f), (-f15) / 2.0f, f14, f15 / 2.0f);
            float f16 = this.f722e;
            canvas.drawRoundRect(rectF, f16, f16, paint);
            canvas.restore();
        }
    }

    public final void c(Canvas canvas, Paint paint) {
        int f10 = h9.f(((LinearProgressIndicatorSpec) this.f716a).f675d, this.f717b.f715j);
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        paint.setColor(f10);
        Path path = new Path();
        this.f723f = path;
        float f11 = this.f720c;
        float f12 = this.f721d;
        RectF rectF = new RectF((-f11) / 2.0f, (-f12) / 2.0f, f11 / 2.0f, f12 / 2.0f);
        float f13 = this.f722e;
        path.addRoundRect(rectF, f13, f13, Path.Direction.CCW);
        canvas.drawPath(this.f723f, paint);
    }

    public final int d() {
        return ((LinearProgressIndicatorSpec) this.f716a).f672a;
    }

    public final int e() {
        return -1;
    }
}
