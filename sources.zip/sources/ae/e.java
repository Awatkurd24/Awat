package ae;

import be.c;
import v7.r0;

public final class e extends c {
    public final Object p(Object obj) {
        r0.C(obj);
        return obj;
    }
}
