package ae;

import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import v7.r0;
import zd.e;
import zd.j;

public final class c extends be.c {

    /* renamed from: d  reason: collision with root package name */
    public int f800d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ ge.c f801e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ Object f802f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(e eVar, j jVar, ge.c cVar, Object obj) {
        super(eVar, jVar);
        this.f801e = cVar;
        this.f802f = obj;
        r0.h("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>", eVar);
    }

    public final Object p(Object obj) {
        int i10 = this.f800d;
        if (i10 == 0) {
            this.f800d = 1;
            r0.C(obj);
            ge.c cVar = this.f801e;
            r0.h("null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>", cVar);
            b0.l(2, cVar);
            return cVar.g(this.f802f, this);
        } else if (i10 == 1) {
            this.f800d = 2;
            r0.C(obj);
            return obj;
        } else {
            throw new IllegalStateException("This coroutine had already completed".toString());
        }
    }
}
