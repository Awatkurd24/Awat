package ae;

import be.g;
import v7.r0;

public final class d extends g {
    public final Object p(Object obj) {
        r0.C(obj);
        return obj;
    }
}
