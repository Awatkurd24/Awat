package ae;

public enum a {
    ;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: ae.a[]} */
    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Enum, ae.a] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            ae.a r0 = new ae.a
            java.lang.String r1 = "COROUTINE_SUSPENDED"
            r2 = 0
            r0.<init>(r1, r2)
            f795a = r0
            ae.a r1 = new ae.a
            java.lang.String r3 = "UNDECIDED"
            r4 = 1
            r1.<init>(r3, r4)
            ae.a r3 = new ae.a
            java.lang.String r5 = "RESUMED"
            r6 = 2
            r3.<init>(r5, r6)
            r5 = 3
            ae.a[] r5 = new ae.a[r5]
            r5[r2] = r0
            r5[r4] = r1
            r5[r6] = r3
            f796b = r5
            v7.i9.m(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ae.a.<clinit>():void");
    }
}
