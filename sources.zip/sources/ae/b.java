package ae;

import be.g;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import ge.c;
import v7.r0;
import zd.e;

public final class b extends g {

    /* renamed from: b  reason: collision with root package name */
    public int f797b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ c f798c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f799d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(Object obj, e eVar, c cVar) {
        super(eVar);
        this.f798c = cVar;
        this.f799d = obj;
        r0.h("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>", eVar);
    }

    public final Object p(Object obj) {
        int i10 = this.f797b;
        if (i10 == 0) {
            this.f797b = 1;
            r0.C(obj);
            c cVar = this.f798c;
            r0.h("null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>", cVar);
            b0.l(2, cVar);
            return cVar.g(this.f799d, this);
        } else if (i10 == 1) {
            this.f797b = 2;
            r0.C(obj);
            return obj;
        } else {
            throw new IllegalStateException("This coroutine had already completed".toString());
        }
    }
}
