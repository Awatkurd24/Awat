package ac;

import androidx.lifecycle.k0;
import androidx.lifecycle.p;
import androidx.lifecycle.x;
import d7.j;
import java.io.Closeable;

public interface a extends Closeable, x, j {
    @k0(p.ON_DESTROY)
    void close();
}
