package ac;

import java.util.Arrays;
import java.util.concurrent.Executor;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final int f790a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f791b;

    /* renamed from: c  reason: collision with root package name */
    public final Executor f792c;

    public /* synthetic */ b(int i10, boolean z4, Executor executor) {
        this.f790a = i10;
        this.f791b = z4;
        this.f792c = executor;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000a, code lost:
        r5 = (ac.b) r5;
        r1 = r5.f790a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(java.lang.Object r5) {
        /*
            r4 = this;
            r0 = 1
            if (r5 != r4) goto L_0x0004
            return r0
        L_0x0004:
            boolean r1 = r5 instanceof ac.b
            r2 = 0
            if (r1 != 0) goto L_0x000a
            return r2
        L_0x000a:
            ac.b r5 = (ac.b) r5
            int r1 = r5.f790a
            int r3 = r4.f790a
            if (r3 != r1) goto L_0x002a
            boolean r1 = r4.f791b
            boolean r3 = r5.f791b
            if (r1 != r3) goto L_0x002a
            java.util.concurrent.Executor r1 = r4.f792c
            java.util.concurrent.Executor r5 = r5.f792c
            boolean r5 = d0.g.f(r1, r5)
            if (r5 == 0) goto L_0x002a
            r5 = 0
            boolean r5 = d0.g.f(r5, r5)
            if (r5 == 0) goto L_0x002a
            return r0
        L_0x002a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.b.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f790a), Boolean.valueOf(this.f791b), this.f792c, null});
    }
}
