package ab;

public interface e {
}
