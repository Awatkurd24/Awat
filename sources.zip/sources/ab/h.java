package ab;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class h {

    /* renamed from: a  reason: collision with root package name */
    public final SharedPreferences f789a;

    public h(Context context, String str) {
        this.f789a = context.getSharedPreferences("FirebaseHeartBeat" + str, 0);
    }

    public final synchronized void a() {
        try {
            long j3 = this.f789a.getLong("fire-count", 0);
            String str = "";
            String str2 = null;
            for (Map.Entry next : this.f789a.getAll().entrySet()) {
                if (next.getValue() instanceof Set) {
                    for (String str3 : (Set) next.getValue()) {
                        if (str2 != null) {
                            if (str2.compareTo(str3) > 0) {
                            }
                        }
                        str = (String) next.getKey();
                        str2 = str3;
                    }
                }
            }
            HashSet hashSet = new HashSet(this.f789a.getStringSet(str, new HashSet()));
            hashSet.remove(str2);
            this.f789a.edit().putStringSet(str, hashSet).putLong("fire-count", j3 - 1).commit();
        } finally {
        }
    }

    public final synchronized void b() {
        try {
            SharedPreferences.Editor edit = this.f789a.edit();
            int i10 = 0;
            for (Map.Entry next : this.f789a.getAll().entrySet()) {
                if (next.getValue() instanceof Set) {
                    String d10 = d(System.currentTimeMillis());
                    String str = (String) next.getKey();
                    if (((Set) next.getValue()).contains(d10)) {
                        HashSet hashSet = new HashSet();
                        hashSet.add(d10);
                        i10++;
                        edit.putStringSet(str, hashSet);
                    } else {
                        edit.remove(str);
                    }
                }
            }
            if (i10 == 0) {
                edit.remove("fire-count");
            } else {
                edit.putLong("fire-count", (long) i10);
            }
            edit.commit();
        } finally {
        }
    }

    public final synchronized ArrayList c() {
        ArrayList arrayList;
        try {
            arrayList = new ArrayList();
            for (Map.Entry next : this.f789a.getAll().entrySet()) {
                if (next.getValue() instanceof Set) {
                    HashSet hashSet = new HashSet((Set) next.getValue());
                    hashSet.remove(d(System.currentTimeMillis()));
                    if (!hashSet.isEmpty()) {
                        arrayList.add(new a((String) next.getKey(), new ArrayList(hashSet)));
                    }
                }
            }
            l(System.currentTimeMillis());
        } finally {
        }
        return arrayList;
    }

    public final synchronized String d(long j3) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Date(j3).toInstant().atOffset(ZoneOffset.UTC).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE);
        }
        return new SimpleDateFormat("yyyy-MM-dd", Locale.UK).format(new Date(j3));
    }

    public final synchronized String e(String str) {
        for (Map.Entry next : this.f789a.getAll().entrySet()) {
            if (next.getValue() instanceof Set) {
                for (String equals : (Set) next.getValue()) {
                    if (str.equals(equals)) {
                        return (String) next.getKey();
                    }
                }
                continue;
            }
        }
        return null;
    }

    public final synchronized boolean f(long j3, long j10) {
        return d(j3).equals(d(j10));
    }

    public final synchronized void g() {
        String d10 = d(System.currentTimeMillis());
        this.f789a.edit().putString("last-used-date", d10).commit();
        h(d10);
    }

    public final synchronized void h(String str) {
        try {
            String e10 = e(str);
            if (e10 != null) {
                HashSet hashSet = new HashSet(this.f789a.getStringSet(e10, new HashSet()));
                hashSet.remove(str);
                (hashSet.isEmpty() ? this.f789a.edit().remove(e10) : this.f789a.edit().putStringSet(e10, hashSet)).commit();
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized boolean i(long j3) {
        return j(j3);
    }

    public final synchronized boolean j(long j3) {
        if (!this.f789a.contains("fire-global")) {
            this.f789a.edit().putLong("fire-global", j3).commit();
            return true;
        } else if (f(this.f789a.getLong("fire-global", -1), j3)) {
            return false;
        } else {
            this.f789a.edit().putLong("fire-global", j3).commit();
            return true;
        }
    }

    public final synchronized void k(long j3, String str) {
        String d10 = d(j3);
        if (this.f789a.getString("last-used-date", "").equals(d10)) {
            String e10 = e(d10);
            if (e10 != null) {
                if (!e10.equals(str)) {
                    m(str, d10);
                    return;
                }
                return;
            }
            return;
        }
        long j10 = this.f789a.getLong("fire-count", 0);
        if (j10 + 1 == 30) {
            a();
            j10 = this.f789a.getLong("fire-count", 0);
        }
        HashSet hashSet = new HashSet(this.f789a.getStringSet(str, new HashSet()));
        hashSet.add(d10);
        this.f789a.edit().putStringSet(str, hashSet).putLong("fire-count", j10 + 1).putString("last-used-date", d10).commit();
    }

    public final synchronized void l(long j3) {
        this.f789a.edit().putLong("fire-global", j3).commit();
    }

    public final synchronized void m(String str, String str2) {
        h(str2);
        HashSet hashSet = new HashSet(this.f789a.getStringSet(str, new HashSet()));
        hashSet.add(str2);
        this.f789a.edit().putStringSet(str, hashSet).commit();
    }
}
