package ab;

import a3.u;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import androidx.lifecycle.a0;
import androidx.lifecycle.p;
import androidx.lifecycle.s0;
import androidx.lifecycle.y;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.r;
import b6.b;
import co.vpn.plusvpn.R;
import com.google.android.gms.ads.internal.overlay.zzc;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.de;
import com.google.android.gms.internal.ads.fr;
import com.google.android.gms.internal.ads.he;
import com.google.android.gms.internal.ads.ij1;
import com.google.android.gms.internal.ads.ml0;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import n7.e;
import p6.q;
import q3.g;
import q6.j;
import q6.l;
import r6.h0;
import r6.n0;
import t7.p0;
import t7.z;
import v7.r0;
import wg.k;
import y2.c;

public final class d implements r, c, b, e, p0, ml0 {

    /* renamed from: b  reason: collision with root package name */
    public static d f787b;

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f788a;

    public /* synthetic */ d(int i10) {
        this.f788a = i10;
    }

    public static void b(u uVar, Object[] objArr) {
        long j3;
        int byteValue;
        double doubleValue;
        if (objArr != null) {
            int length = objArr.length;
            int i10 = 0;
            while (i10 < length) {
                byte[] bArr = objArr[i10];
                i10++;
                if (bArr == null) {
                    uVar.t(i10);
                } else if (bArr instanceof byte[]) {
                    uVar.G(i10, bArr);
                } else {
                    if (bArr instanceof Float) {
                        doubleValue = (double) ((Number) bArr).floatValue();
                    } else if (bArr instanceof Double) {
                        doubleValue = ((Number) bArr).doubleValue();
                    } else {
                        if (bArr instanceof Long) {
                            j3 = ((Number) bArr).longValue();
                        } else {
                            if (bArr instanceof Integer) {
                                byteValue = ((Number) bArr).intValue();
                            } else if (bArr instanceof Short) {
                                byteValue = ((Number) bArr).shortValue();
                            } else if (bArr instanceof Byte) {
                                byteValue = ((Number) bArr).byteValue();
                            } else if (bArr instanceof String) {
                                uVar.m(i10, (String) bArr);
                            } else if (!(bArr instanceof Boolean)) {
                                throw new IllegalArgumentException("Cannot bind " + bArr + " at index " + i10 + " Supported types: Null, ByteArray, Float, Double, Long, Int, Short, Byte, String");
                            } else if (((Boolean) bArr).booleanValue()) {
                                j3 = 1;
                            } else {
                                j3 = 0;
                            }
                            j3 = (long) byteValue;
                        }
                        uVar.D(i10, j3);
                    }
                    uVar.a(doubleValue, i10);
                }
            }
        }
    }

    public static void d(Activity activity, p pVar) {
        r0.j("activity", activity);
        r0.j("event", pVar);
        if (activity instanceof y) {
            androidx.lifecycle.r lifecycle = ((y) activity).getLifecycle();
            if (lifecycle instanceof a0) {
                ((a0) lifecycle).f(pVar);
            }
        }
    }

    public static g3.c f(ha.c cVar, SQLiteDatabase sQLiteDatabase) {
        r0.j("refHolder", cVar);
        r0.j("sqLiteDatabase", sQLiteDatabase);
        g3.c cVar2 = (g3.c) cVar.f19652b;
        if (cVar2 != null && r0.b(cVar2.f19076a, sQLiteDatabase)) {
            return cVar2;
        }
        g3.c cVar3 = new g3.c(sQLiteDatabase);
        cVar.f19652b = cVar3;
        return cVar3;
    }

    public static void g(Activity activity) {
        r0.j("activity", activity);
        if (Build.VERSION.SDK_INT >= 29) {
            androidx.lifecycle.r0.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new androidx.lifecycle.r0());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new s0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    public static g i(String str) {
        Integer num;
        Integer num2;
        Integer num3;
        String str2;
        if (str == null || k.J(str)) {
            return null;
        }
        Matcher matcher = Pattern.compile("(\\d+)(?:\\.(\\d+))(?:\\.(\\d+))(?:-(.+))?").matcher(str);
        if (!matcher.matches()) {
            return null;
        }
        String group = matcher.group(1);
        if (group == null) {
            num = null;
        } else {
            num = Integer.valueOf(Integer.parseInt(group));
        }
        if (num == null) {
            return null;
        }
        int intValue = num.intValue();
        String group2 = matcher.group(2);
        if (group2 == null) {
            num2 = null;
        } else {
            num2 = Integer.valueOf(Integer.parseInt(group2));
        }
        if (num2 == null) {
            return null;
        }
        int intValue2 = num2.intValue();
        String group3 = matcher.group(3);
        if (group3 == null) {
            num3 = null;
        } else {
            num3 = Integer.valueOf(Integer.parseInt(group3));
        }
        if (num3 == null) {
            return null;
        }
        int intValue3 = num3.intValue();
        if (matcher.group(4) != null) {
            str2 = matcher.group(4);
        } else {
            str2 = "";
        }
        r0.i("description", str2);
        return new g(intValue, intValue2, intValue3, str2);
    }

    public static final boolean j(Context context, Intent intent, l lVar, j jVar, boolean z4) {
        int i10;
        if (z4) {
            Uri data = intent.getData();
            try {
                o6.k.A.f23633c.getClass();
                i10 = n0.z(context, data);
                if (lVar != null) {
                    lVar.r();
                }
            } catch (ActivityNotFoundException e10) {
                fr.g(e10.getMessage());
                i10 = 6;
            }
            if (jVar != null) {
                jVar.z(i10);
            }
            if (i10 != 5) {
                return false;
            }
            return true;
        }
        try {
            String uri = intent.toURI();
            h0.k("Launching an intent: " + uri);
            n0 n0Var = o6.k.A.f23633c;
            n0.o(context, intent);
            if (lVar != null) {
                lVar.r();
            }
            if (jVar != null) {
                jVar.a(true);
            }
            return true;
        } catch (ActivityNotFoundException e11) {
            fr.g(e11.getMessage());
            if (jVar != null) {
                jVar.a(false);
            }
            return false;
        }
    }

    public static final boolean k(Context context, zzc zzc, l lVar, j jVar) {
        String concat;
        int i10 = 0;
        if (zzc == null) {
            concat = "No intent data for launcher overlay.";
        } else {
            he.a(context);
            boolean z4 = zzc.f5744j;
            Intent intent = zzc.f5742h;
            if (intent != null) {
                return j(context, intent, lVar, jVar, z4);
            }
            Intent intent2 = new Intent();
            String str = zzc.f5736b;
            if (TextUtils.isEmpty(str)) {
                concat = "Open GMSG did not contain a URL.";
            } else {
                String str2 = zzc.f5737c;
                boolean isEmpty = TextUtils.isEmpty(str2);
                Uri parse = Uri.parse(str);
                if (!isEmpty) {
                    intent2.setDataAndType(parse, str2);
                } else {
                    intent2.setData(parse);
                }
                intent2.setAction("android.intent.action.VIEW");
                String str3 = zzc.f5738d;
                if (!TextUtils.isEmpty(str3)) {
                    intent2.setPackage(str3);
                }
                String str4 = zzc.f5739e;
                if (!TextUtils.isEmpty(str4)) {
                    String[] split = str4.split("/", 2);
                    if (split.length < 2) {
                        concat = "Could not parse component name from open GMSG: ".concat(str4);
                    } else {
                        intent2.setClassName(split[0], split[1]);
                    }
                }
                String str5 = zzc.f5740f;
                if (!TextUtils.isEmpty(str5)) {
                    try {
                        i10 = Integer.parseInt(str5);
                    } catch (NumberFormatException unused) {
                        fr.g("Could not parse intent flags.");
                    }
                    intent2.addFlags(i10);
                }
                de deVar = he.Q3;
                q qVar = q.f24015d;
                if (((Boolean) qVar.f24018c.a(deVar)).booleanValue()) {
                    intent2.addFlags(268435456);
                    intent2.putExtra("android.support.customtabs.extra.user_opt_out", true);
                } else {
                    if (((Boolean) qVar.f24018c.a(he.P3)).booleanValue()) {
                        n0 n0Var = o6.k.A.f23633c;
                        n0.B(context, intent2);
                    }
                }
                return j(context, intent2, lVar, jVar, z4);
            }
        }
        fr.g(concat);
        return false;
    }

    public void D(int i10, Object obj) {
    }

    public /* synthetic */ Object a() {
        Handler handler = z.f26684a;
        cq0.L(handler);
        return handler;
    }

    public CharSequence c(Preference preference) {
        ListPreference listPreference = (ListPreference) preference;
        if (TextUtils.isEmpty(listPreference.B())) {
            return listPreference.f2506a.getString(R.string.not_set);
        }
        return listPreference.B();
    }

    public void e(Object obj) {
        switch (this.f788a) {
            case 0:
                ij1 ij1 = (ij1) obj;
                return;
            case 1:
                ij1 ij12 = (ij1) obj;
                return;
            default:
                ij1 ij13 = (ij1) obj;
                return;
        }
    }

    public /* bridge */ /* synthetic */ Object get() {
        return "com.google.android.datatransport.events";
    }

    public n7.d h(Context context, String str, n7.c cVar) {
        switch (this.f788a) {
            case 27:
                n7.d dVar = new n7.d();
                int d10 = cVar.d(context, str, true);
                dVar.f22912b = d10;
                if (d10 != 0) {
                    dVar.f22913c = 1;
                } else {
                    int b5 = cVar.b(context, str);
                    dVar.f22911a = b5;
                    if (b5 != 0) {
                        dVar.f22913c = -1;
                    }
                }
                return dVar;
            default:
                n7.d dVar2 = new n7.d();
                dVar2.f22911a = cVar.b(context, str);
                int d11 = cVar.d(context, str, true);
                dVar2.f22912b = d11;
                int i10 = dVar2.f22911a;
                if (i10 == 0) {
                    i10 = 0;
                    if (d11 == 0) {
                        dVar2.f22913c = 0;
                        return dVar2;
                    }
                }
                if (d11 >= i10) {
                    dVar2.f22913c = 1;
                } else {
                    dVar2.f22913c = -1;
                }
                return dVar2;
        }
    }

    public void x() {
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(int i10, int i11) {
        this(0);
        this.f788a = i10;
        if (i10 != 1) {
        } else {
            this(1);
        }
    }
}
