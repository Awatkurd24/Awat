package ab;

import android.app.NotificationChannel;
import com.v2ray.ang.service.SubscriptionUpdater;

public abstract /* synthetic */ class g {
    public static /* synthetic */ NotificationChannel c() {
        return new NotificationChannel(SubscriptionUpdater.notificationChannel, "Subscription Update Service", 1);
    }

    public static /* synthetic */ NotificationChannel e(String str) {
        return new NotificationChannel("com.google.android.gms.availability", str, 4);
    }

    public static /* synthetic */ NotificationChannel x() {
        return new NotificationChannel("RAY_NG_M_CH_ID", "vpn Background Service", 4);
    }

    public static /* synthetic */ NotificationChannel y(String str) {
        return new NotificationChannel(str, "Time expire", 4);
    }
}
