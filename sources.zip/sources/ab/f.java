package ab;

public interface f {
}
