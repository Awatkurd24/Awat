package ab;

import android.util.Base64OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public final /* synthetic */ class b implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f780a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ c f781b;

    public /* synthetic */ b(c cVar, int i10) {
        this.f780a = i10;
        this.f781b = cVar;
    }

    private final String a() {
        Base64OutputStream base64OutputStream;
        GZIPOutputStream gZIPOutputStream;
        String byteArrayOutputStream;
        c cVar = this.f781b;
        synchronized (cVar) {
            try {
                h hVar = (h) cVar.f782a.get();
                ArrayList c10 = hVar.c();
                hVar.b();
                JSONArray jSONArray = new JSONArray();
                for (int i10 = 0; i10 < c10.size(); i10++) {
                    a aVar = (a) c10.get(i10);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("agent", aVar.f778a);
                    jSONObject.put("dates", new JSONArray(aVar.f779b));
                    jSONArray.put(jSONObject);
                }
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put("heartbeats", jSONArray);
                jSONObject2.put("version", "2");
                ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                base64OutputStream = new Base64OutputStream(byteArrayOutputStream2, 11);
                gZIPOutputStream = new GZIPOutputStream(base64OutputStream);
                gZIPOutputStream.write(jSONObject2.toString().getBytes("UTF-8"));
                gZIPOutputStream.close();
                base64OutputStream.close();
                byteArrayOutputStream = byteArrayOutputStream2.toString("UTF-8");
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return byteArrayOutputStream;
        throw th;
        throw th;
    }

    public final Object call() {
        switch (this.f780a) {
            case 0:
                return a();
            default:
                c cVar = this.f781b;
                synchronized (cVar) {
                    ((h) cVar.f782a.get()).k(System.currentTimeMillis(), ((kb.b) cVar.f784c.get()).a());
                }
                return null;
        }
    }
}
