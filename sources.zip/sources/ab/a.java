package ab;

import java.util.ArrayList;
import java.util.List;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final String f778a;

    /* renamed from: b  reason: collision with root package name */
    public final List f779b;

    public a(String str, ArrayList arrayList) {
        if (str != null) {
            this.f778a = str;
            this.f779b = arrayList;
            return;
        }
        throw new NullPointerException("Null userAgent");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (!this.f778a.equals(aVar.f778a) || !this.f779b.equals(aVar.f779b)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return ((this.f778a.hashCode() ^ 1000003) * 1000003) ^ this.f779b.hashCode();
    }

    public final String toString() {
        return "HeartBeatResult{userAgent=" + this.f778a + ", usedDates=" + this.f779b + "}";
    }
}
