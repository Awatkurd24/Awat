package ab;

import android.content.Context;
import android.os.Build;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import d8.r;
import java.util.Set;
import java.util.concurrent.Executor;
import n1.t;

public final class c implements e, f {

    /* renamed from: a  reason: collision with root package name */
    public final cb.c f782a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f783b;

    /* renamed from: c  reason: collision with root package name */
    public final cb.c f784c;

    /* renamed from: d  reason: collision with root package name */
    public final Set f785d;

    /* renamed from: e  reason: collision with root package name */
    public final Executor f786e;

    public c(Context context, String str, Set set, cb.c cVar, Executor executor) {
        this.f782a = new aa.c(context, str);
        this.f785d = set;
        this.f786e = executor;
        this.f784c = cVar;
        this.f783b = context;
    }

    public final synchronized int a() {
        long currentTimeMillis = System.currentTimeMillis();
        h hVar = (h) this.f782a.get();
        if (!hVar.i(currentTimeMillis)) {
            return 1;
        }
        hVar.g();
        return 3;
    }

    public final r b() {
        boolean z4;
        if (Build.VERSION.SDK_INT >= 24) {
            z4 = t.a(this.f783b);
        } else {
            z4 = true;
        }
        if (!z4) {
            return b0.m0("");
        }
        return b0.q(new b(this, 0), this.f786e);
    }

    public final void c() {
        boolean z4;
        if (this.f785d.size() <= 0) {
            b0.m0((Object) null);
            return;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            z4 = t.a(this.f783b);
        } else {
            z4 = true;
        }
        if (!z4) {
            b0.m0((Object) null);
        } else {
            b0.q(new b(this, 1), this.f786e);
        }
    }
}
