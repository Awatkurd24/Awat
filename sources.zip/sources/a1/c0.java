package a1;

import android.graphics.Rect;
import android.view.animation.Interpolator;
import androidx.constraintlayout.motion.widget.MotionLayout;
import h.n0;
import java.util.ArrayList;
import pa.b;

public final class c0 {

    /* renamed from: a  reason: collision with root package name */
    public final int f94a;

    /* renamed from: b  reason: collision with root package name */
    public final int f95b;

    /* renamed from: c  reason: collision with root package name */
    public final n f96c;

    /* renamed from: d  reason: collision with root package name */
    public final int f97d;

    /* renamed from: e  reason: collision with root package name */
    public final n0 f98e = new n0(7);

    /* renamed from: f  reason: collision with root package name */
    public final b f99f;

    /* renamed from: g  reason: collision with root package name */
    public final Interpolator f100g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f101h = false;

    /* renamed from: i  reason: collision with root package name */
    public float f102i;

    /* renamed from: j  reason: collision with root package name */
    public float f103j;

    /* renamed from: k  reason: collision with root package name */
    public long f104k;

    /* renamed from: l  reason: collision with root package name */
    public final Rect f105l = new Rect();

    /* renamed from: m  reason: collision with root package name */
    public final boolean f106m = false;

    public c0(b bVar, n nVar, int i10, int i11, int i12, Interpolator interpolator, int i13, int i14) {
        float f10;
        this.f99f = bVar;
        this.f96c = nVar;
        this.f97d = i11;
        this.f104k = System.nanoTime();
        if (((ArrayList) bVar.f24103e) == null) {
            bVar.f24103e = new ArrayList();
        }
        ((ArrayList) bVar.f24103e).add(this);
        this.f100g = interpolator;
        this.f94a = i13;
        this.f95b = i14;
        if (i12 == 3) {
            this.f106m = true;
        }
        if (i10 == 0) {
            f10 = Float.MAX_VALUE;
        } else {
            f10 = 1.0f / ((float) i10);
        }
        this.f103j = f10;
        a();
    }

    public final void a() {
        float interpolation;
        boolean z4 = this.f101h;
        b bVar = this.f99f;
        Interpolator interpolator = this.f100g;
        n nVar = this.f96c;
        int i10 = this.f95b;
        int i11 = this.f94a;
        if (z4) {
            long nanoTime = System.nanoTime();
            this.f104k = nanoTime;
            float f10 = this.f102i - (((float) (((double) (nanoTime - this.f104k)) * 1.0E-6d)) * this.f103j);
            this.f102i = f10;
            if (f10 < 0.0f) {
                this.f102i = 0.0f;
            }
            float f11 = this.f102i;
            if (interpolator != null) {
                f11 = interpolator.getInterpolation(f11);
            }
            boolean e10 = nVar.e(f11, nanoTime, nVar.f178b, this.f98e);
            if (this.f102i <= 0.0f) {
                if (i11 != -1) {
                    nVar.f178b.setTag(i11, Long.valueOf(System.nanoTime()));
                }
                if (i10 != -1) {
                    nVar.f178b.setTag(i10, (Object) null);
                }
                ((ArrayList) bVar.f24104f).add(this);
            }
            if (this.f102i > 0.0f || e10) {
                ((MotionLayout) bVar.f24099a).invalidate();
                return;
            }
            return;
        }
        long nanoTime2 = System.nanoTime();
        this.f104k = nanoTime2;
        float f12 = (((float) (((double) (nanoTime2 - this.f104k)) * 1.0E-6d)) * this.f103j) + this.f102i;
        this.f102i = f12;
        if (f12 >= 1.0f) {
            this.f102i = 1.0f;
        }
        if (interpolator == null) {
            interpolation = this.f102i;
        } else {
            interpolation = interpolator.getInterpolation(this.f102i);
        }
        boolean e11 = nVar.e(interpolation, nanoTime2, nVar.f178b, this.f98e);
        if (this.f102i >= 1.0f) {
            if (i11 != -1) {
                nVar.f178b.setTag(i11, Long.valueOf(System.nanoTime()));
            }
            if (i10 != -1) {
                nVar.f178b.setTag(i10, (Object) null);
            }
            if (!this.f106m) {
                ((ArrayList) bVar.f24104f).add(this);
            }
        }
        if (this.f102i < 1.0f || e11) {
            ((MotionLayout) bVar.f24099a).invalidate();
        }
    }

    public final void b() {
        float f10;
        this.f101h = true;
        int i10 = this.f97d;
        if (i10 != -1) {
            if (i10 == 0) {
                f10 = Float.MAX_VALUE;
            } else {
                f10 = 1.0f / ((float) i10);
            }
            this.f103j = f10;
        }
        ((MotionLayout) this.f99f.f24099a).invalidate();
        this.f104k = System.nanoTime();
    }
}
