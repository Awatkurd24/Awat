package a1;

public abstract class k extends c {
}
