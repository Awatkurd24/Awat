package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import io.tooldroid.dialog.ToolDroidDialog;
import java.util.HashMap;
import java.util.HashSet;
import t.u;

public final class e extends c {

    /* renamed from: e  reason: collision with root package name */
    public int f129e = -1;

    /* renamed from: f  reason: collision with root package name */
    public float f130f = Float.NaN;

    /* renamed from: g  reason: collision with root package name */
    public float f131g = Float.NaN;

    /* renamed from: h  reason: collision with root package name */
    public float f132h = Float.NaN;

    /* renamed from: i  reason: collision with root package name */
    public float f133i = Float.NaN;

    /* renamed from: j  reason: collision with root package name */
    public float f134j = Float.NaN;

    /* renamed from: k  reason: collision with root package name */
    public float f135k = Float.NaN;

    /* renamed from: l  reason: collision with root package name */
    public float f136l = Float.NaN;

    /* renamed from: m  reason: collision with root package name */
    public float f137m = Float.NaN;

    /* renamed from: n  reason: collision with root package name */
    public float f138n = Float.NaN;

    /* renamed from: o  reason: collision with root package name */
    public float f139o = Float.NaN;

    /* renamed from: p  reason: collision with root package name */
    public float f140p = Float.NaN;

    /* renamed from: q  reason: collision with root package name */
    public float f141q = Float.NaN;

    /* renamed from: r  reason: collision with root package name */
    public float f142r = Float.NaN;

    /* renamed from: s  reason: collision with root package name */
    public float f143s = Float.NaN;

    public e() {
        this.f93d = new HashMap();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x009c, code lost:
        if (r1.equals("scaleY") == false) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0100, code lost:
        r2.b(r1, r3);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(java.util.HashMap r7) {
        /*
            r6 = this;
            java.util.Set r0 = r7.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x01b2
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r2 = r7.get(r1)
            z0.k r2 = (z0.k) r2
            if (r2 != 0) goto L_0x001d
            goto L_0x0008
        L_0x001d:
            java.lang.String r3 = "CUSTOM"
            boolean r3 = r1.startsWith(r3)
            r4 = 7
            if (r3 == 0) goto L_0x003e
            java.lang.String r1 = r1.substring(r4)
            java.util.HashMap r3 = r6.f93d
            java.lang.Object r1 = r3.get(r1)
            c1.a r1 = (c1.a) r1
            if (r1 == 0) goto L_0x0008
            z0.h r2 = (z0.h) r2
            int r3 = r6.f90a
            android.util.SparseArray r2 = r2.f30594f
            r2.append(r3, r1)
            goto L_0x0008
        L_0x003e:
            int r3 = r1.hashCode()
            r5 = -1
            switch(r3) {
                case -1249320806: goto L_0x00e4;
                case -1249320805: goto L_0x00d8;
                case -1225497657: goto L_0x00cc;
                case -1225497656: goto L_0x00c0;
                case -1225497655: goto L_0x00b5;
                case -1001078227: goto L_0x00aa;
                case -908189618: goto L_0x009f;
                case -908189617: goto L_0x0096;
                case -760884510: goto L_0x008a;
                case -760884509: goto L_0x007d;
                case -40300674: goto L_0x0070;
                case -4379043: goto L_0x0063;
                case 37232917: goto L_0x0056;
                case 92909918: goto L_0x0049;
                default: goto L_0x0046;
            }
        L_0x0046:
            r4 = -1
            goto L_0x00ef
        L_0x0049:
            java.lang.String r3 = "alpha"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0052
            goto L_0x0046
        L_0x0052:
            r4 = 13
            goto L_0x00ef
        L_0x0056:
            java.lang.String r3 = "transitionPathRotate"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x005f
            goto L_0x0046
        L_0x005f:
            r4 = 12
            goto L_0x00ef
        L_0x0063:
            java.lang.String r3 = "elevation"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x006c
            goto L_0x0046
        L_0x006c:
            r4 = 11
            goto L_0x00ef
        L_0x0070:
            java.lang.String r3 = "rotation"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0079
            goto L_0x0046
        L_0x0079:
            r4 = 10
            goto L_0x00ef
        L_0x007d:
            java.lang.String r3 = "transformPivotY"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0086
            goto L_0x0046
        L_0x0086:
            r4 = 9
            goto L_0x00ef
        L_0x008a:
            java.lang.String r3 = "transformPivotX"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0093
            goto L_0x0046
        L_0x0093:
            r4 = 8
            goto L_0x00ef
        L_0x0096:
            java.lang.String r3 = "scaleY"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00ef
            goto L_0x0046
        L_0x009f:
            java.lang.String r3 = "scaleX"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00a8
            goto L_0x0046
        L_0x00a8:
            r4 = 6
            goto L_0x00ef
        L_0x00aa:
            java.lang.String r3 = "progress"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00b3
            goto L_0x0046
        L_0x00b3:
            r4 = 5
            goto L_0x00ef
        L_0x00b5:
            java.lang.String r3 = "translationZ"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00be
            goto L_0x0046
        L_0x00be:
            r4 = 4
            goto L_0x00ef
        L_0x00c0:
            java.lang.String r3 = "translationY"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00ca
            goto L_0x0046
        L_0x00ca:
            r4 = 3
            goto L_0x00ef
        L_0x00cc:
            java.lang.String r3 = "translationX"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00d6
            goto L_0x0046
        L_0x00d6:
            r4 = 2
            goto L_0x00ef
        L_0x00d8:
            java.lang.String r3 = "rotationY"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00e2
            goto L_0x0046
        L_0x00e2:
            r4 = 1
            goto L_0x00ef
        L_0x00e4:
            java.lang.String r3 = "rotationX"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x00ee
            goto L_0x0046
        L_0x00ee:
            r4 = 0
        L_0x00ef:
            switch(r4) {
                case 0: goto L_0x01a4;
                case 1: goto L_0x0196;
                case 2: goto L_0x0188;
                case 3: goto L_0x017a;
                case 4: goto L_0x016d;
                case 5: goto L_0x0160;
                case 6: goto L_0x0153;
                case 7: goto L_0x0146;
                case 8: goto L_0x0139;
                case 9: goto L_0x012c;
                case 10: goto L_0x011f;
                case 11: goto L_0x0112;
                case 12: goto L_0x0105;
                case 13: goto L_0x00f4;
                default: goto L_0x00f2;
            }
        L_0x00f2:
            goto L_0x0008
        L_0x00f4:
            float r1 = r6.f130f
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f130f
        L_0x0100:
            r2.b(r1, r3)
            goto L_0x0008
        L_0x0105:
            float r1 = r6.f137m
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f137m
            goto L_0x0100
        L_0x0112:
            float r1 = r6.f131g
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f131g
            goto L_0x0100
        L_0x011f:
            float r1 = r6.f132h
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f132h
            goto L_0x0100
        L_0x012c:
            float r1 = r6.f134j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f136l
            goto L_0x0100
        L_0x0139:
            float r1 = r6.f133i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f135k
            goto L_0x0100
        L_0x0146:
            float r1 = r6.f139o
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f139o
            goto L_0x0100
        L_0x0153:
            float r1 = r6.f138n
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f138n
            goto L_0x0100
        L_0x0160:
            float r1 = r6.f143s
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f143s
            goto L_0x0100
        L_0x016d:
            float r1 = r6.f142r
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f142r
            goto L_0x0100
        L_0x017a:
            float r1 = r6.f141q
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f141q
            goto L_0x0100
        L_0x0188:
            float r1 = r6.f140p
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f140p
            goto L_0x0100
        L_0x0196:
            float r1 = r6.f134j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f134j
            goto L_0x0100
        L_0x01a4:
            float r1 = r6.f133i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x0008
            int r1 = r6.f90a
            float r3 = r6.f133i
            goto L_0x0100
        L_0x01b2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.e.a(java.util.HashMap):void");
    }

    /* renamed from: b */
    public final c clone() {
        e eVar = new e();
        eVar.f90a = this.f90a;
        eVar.f91b = this.f91b;
        eVar.f92c = this.f92c;
        eVar.f93d = this.f93d;
        eVar.f129e = this.f129e;
        eVar.f130f = this.f130f;
        eVar.f131g = this.f131g;
        eVar.f132h = this.f132h;
        eVar.f133i = this.f133i;
        eVar.f134j = this.f134j;
        eVar.f135k = this.f135k;
        eVar.f136l = this.f136l;
        eVar.f137m = this.f137m;
        eVar.f138n = this.f138n;
        eVar.f139o = this.f139o;
        eVar.f140p = this.f140p;
        eVar.f141q = this.f141q;
        eVar.f142r = this.f142r;
        eVar.f143s = this.f143s;
        return eVar;
    }

    public final void c(HashSet hashSet) {
        if (!Float.isNaN(this.f130f)) {
            hashSet.add("alpha");
        }
        if (!Float.isNaN(this.f131g)) {
            hashSet.add("elevation");
        }
        if (!Float.isNaN(this.f132h)) {
            hashSet.add("rotation");
        }
        if (!Float.isNaN(this.f133i)) {
            hashSet.add("rotationX");
        }
        if (!Float.isNaN(this.f134j)) {
            hashSet.add("rotationY");
        }
        if (!Float.isNaN(this.f135k)) {
            hashSet.add("transformPivotX");
        }
        if (!Float.isNaN(this.f136l)) {
            hashSet.add("transformPivotY");
        }
        if (!Float.isNaN(this.f140p)) {
            hashSet.add("translationX");
        }
        if (!Float.isNaN(this.f141q)) {
            hashSet.add("translationY");
        }
        if (!Float.isNaN(this.f142r)) {
            hashSet.add("translationZ");
        }
        if (!Float.isNaN(this.f137m)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f138n)) {
            hashSet.add("scaleX");
        }
        if (!Float.isNaN(this.f139o)) {
            hashSet.add("scaleY");
        }
        if (!Float.isNaN(this.f143s)) {
            hashSet.add("progress");
        }
        if (this.f93d.size() > 0) {
            for (String str : this.f93d.keySet()) {
                hashSet.add("CUSTOM," + str);
            }
        }
    }

    public final void d(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3910j);
        SparseIntArray sparseIntArray = d.f107a;
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            SparseIntArray sparseIntArray2 = d.f107a;
            switch (sparseIntArray2.get(index)) {
                case 1:
                    this.f130f = obtainStyledAttributes.getFloat(index, this.f130f);
                    break;
                case 2:
                    this.f131g = obtainStyledAttributes.getDimension(index, this.f131g);
                    break;
                case 4:
                    this.f132h = obtainStyledAttributes.getFloat(index, this.f132h);
                    break;
                case 5:
                    this.f133i = obtainStyledAttributes.getFloat(index, this.f133i);
                    break;
                case 6:
                    this.f134j = obtainStyledAttributes.getFloat(index, this.f134j);
                    break;
                case 7:
                    this.f138n = obtainStyledAttributes.getFloat(index, this.f138n);
                    break;
                case V2rayConfig.DEFAULT_LEVEL /*8*/:
                    this.f137m = obtainStyledAttributes.getFloat(index, this.f137m);
                    break;
                case 9:
                    obtainStyledAttributes.getString(index);
                    break;
                case 10:
                    if (!MotionLayout.K1) {
                        if (obtainStyledAttributes.peekValue(index).type != 3) {
                            this.f91b = obtainStyledAttributes.getResourceId(index, this.f91b);
                            break;
                        }
                    } else {
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.f91b);
                        this.f91b = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                    }
                    this.f92c = obtainStyledAttributes.getString(index);
                    break;
                case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                    this.f90a = obtainStyledAttributes.getInt(index, this.f90a);
                    break;
                case 13:
                    this.f129e = obtainStyledAttributes.getInteger(index, this.f129e);
                    break;
                case 14:
                    this.f139o = obtainStyledAttributes.getFloat(index, this.f139o);
                    break;
                case 15:
                    this.f140p = obtainStyledAttributes.getDimension(index, this.f140p);
                    break;
                case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                    this.f141q = obtainStyledAttributes.getDimension(index, this.f141q);
                    break;
                case ToolDroidDialog.CENTER /*17*/:
                    this.f142r = obtainStyledAttributes.getDimension(index, this.f142r);
                    break;
                case 18:
                    this.f143s = obtainStyledAttributes.getFloat(index, this.f143s);
                    break;
                case 19:
                    this.f135k = obtainStyledAttributes.getDimension(index, this.f135k);
                    break;
                case 20:
                    this.f136l = obtainStyledAttributes.getDimension(index, this.f136l);
                    break;
                default:
                    Log.e("KeyAttribute", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray2.get(index));
                    break;
            }
        }
    }

    public final void e(HashMap hashMap) {
        if (this.f129e != -1) {
            if (!Float.isNaN(this.f130f)) {
                hashMap.put("alpha", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f131g)) {
                hashMap.put("elevation", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f132h)) {
                hashMap.put("rotation", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f133i)) {
                hashMap.put("rotationX", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f134j)) {
                hashMap.put("rotationY", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f135k)) {
                hashMap.put("transformPivotX", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f136l)) {
                hashMap.put("transformPivotY", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f140p)) {
                hashMap.put("translationX", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f141q)) {
                hashMap.put("translationY", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f142r)) {
                hashMap.put("translationZ", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f137m)) {
                hashMap.put("transitionPathRotate", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f138n)) {
                hashMap.put("scaleX", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f139o)) {
                hashMap.put("scaleY", Integer.valueOf(this.f129e));
            }
            if (!Float.isNaN(this.f143s)) {
                hashMap.put("progress", Integer.valueOf(this.f129e));
            }
            if (this.f93d.size() > 0) {
                for (String d10 : this.f93d.keySet()) {
                    hashMap.put(u.d("CUSTOM,", d10), Integer.valueOf(this.f129e));
                }
            }
        }
    }

    public final void g(String str, Object obj) {
        int i10;
        char c10 = 65535;
        switch (str.hashCode()) {
            case -1913008125:
                if (str.equals("motionProgress")) {
                    c10 = 0;
                    break;
                }
                break;
            case -1812823328:
                if (str.equals("transitionEasing")) {
                    c10 = 1;
                    break;
                }
                break;
            case -1249320806:
                if (str.equals("rotationX")) {
                    c10 = 2;
                    break;
                }
                break;
            case -1249320805:
                if (str.equals("rotationY")) {
                    c10 = 3;
                    break;
                }
                break;
            case -1225497657:
                if (str.equals("translationX")) {
                    c10 = 4;
                    break;
                }
                break;
            case -1225497656:
                if (str.equals("translationY")) {
                    c10 = 5;
                    break;
                }
                break;
            case -1225497655:
                if (str.equals("translationZ")) {
                    c10 = 6;
                    break;
                }
                break;
            case -908189618:
                if (str.equals("scaleX")) {
                    c10 = 7;
                    break;
                }
                break;
            case -908189617:
                if (str.equals("scaleY")) {
                    c10 = 8;
                    break;
                }
                break;
            case -760884510:
                if (str.equals("transformPivotX")) {
                    c10 = 9;
                    break;
                }
                break;
            case -760884509:
                if (str.equals("transformPivotY")) {
                    c10 = 10;
                    break;
                }
                break;
            case -40300674:
                if (str.equals("rotation")) {
                    c10 = 11;
                    break;
                }
                break;
            case -4379043:
                if (str.equals("elevation")) {
                    c10 = 12;
                    break;
                }
                break;
            case 37232917:
                if (str.equals("transitionPathRotate")) {
                    c10 = 13;
                    break;
                }
                break;
            case 92909918:
                if (str.equals("alpha")) {
                    c10 = 14;
                    break;
                }
                break;
            case 579057826:
                if (str.equals("curveFit")) {
                    c10 = 15;
                    break;
                }
                break;
            case 1941332754:
                if (str.equals("visibility")) {
                    c10 = 16;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                this.f143s = c.f((Number) obj);
                return;
            case 1:
                obj.toString();
                return;
            case 2:
                this.f133i = c.f((Number) obj);
                return;
            case 3:
                this.f134j = c.f((Number) obj);
                return;
            case 4:
                this.f140p = c.f((Number) obj);
                return;
            case 5:
                this.f141q = c.f((Number) obj);
                return;
            case 6:
                this.f142r = c.f((Number) obj);
                return;
            case 7:
                this.f138n = c.f((Number) obj);
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                this.f139o = c.f((Number) obj);
                return;
            case 9:
                this.f135k = c.f((Number) obj);
                return;
            case 10:
                this.f136l = c.f((Number) obj);
                return;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                this.f132h = c.f((Number) obj);
                return;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                this.f131g = c.f((Number) obj);
                return;
            case 13:
                this.f137m = c.f((Number) obj);
                return;
            case 14:
                this.f130f = c.f((Number) obj);
                return;
            case 15:
                Number number = (Number) obj;
                if (number instanceof Integer) {
                    i10 = ((Integer) number).intValue();
                } else {
                    i10 = Integer.parseInt(number.toString());
                }
                this.f129e = i10;
                return;
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                if (obj instanceof Boolean) {
                    ((Boolean) obj).booleanValue();
                    return;
                } else {
                    Boolean.parseBoolean(obj.toString());
                    return;
                }
            default:
                return;
        }
    }
}
