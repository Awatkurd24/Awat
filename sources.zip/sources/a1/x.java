package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;

public final class x implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final y f258a;

    /* renamed from: b  reason: collision with root package name */
    public final int f259b = -1;

    /* renamed from: c  reason: collision with root package name */
    public final int f260c = 17;

    public x(Context context, y yVar, XmlResourceParser xmlResourceParser) {
        this.f258a = yVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.f3921u);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 1) {
                this.f259b = obtainStyledAttributes.getResourceId(index, this.f259b);
            } else if (index == 0) {
                this.f260c = obtainStyledAttributes.getInt(index, this.f260c);
            }
        }
        obtainStyledAttributes.recycle();
    }

    public final void a(MotionLayout motionLayout, int i10, y yVar) {
        boolean z4;
        boolean z10;
        boolean z11;
        boolean z12;
        int i11 = this.f259b;
        View view = motionLayout;
        if (i11 != -1) {
            view = motionLayout.findViewById(i11);
        }
        if (view == null) {
            Log.e("MotionScene", "OnClick could not find id " + i11);
            return;
        }
        int i12 = yVar.f264d;
        int i13 = yVar.f263c;
        if (i12 == -1) {
            view.setOnClickListener(this);
            return;
        }
        int i14 = this.f260c;
        int i15 = i14 & 1;
        boolean z13 = true;
        if (i15 == 0 || i10 != i12) {
            z4 = false;
        } else {
            z4 = true;
        }
        if ((i14 & 256) == 0 || i10 != i12) {
            z10 = false;
        } else {
            z10 = true;
        }
        boolean z14 = z4 | z10;
        if (i15 == 0 || i10 != i12) {
            z11 = false;
        } else {
            z11 = true;
        }
        boolean z15 = z11 | z14;
        if ((i14 & 16) == 0 || i10 != i13) {
            z12 = false;
        } else {
            z12 = true;
        }
        boolean z16 = z15 | z12;
        if ((i14 & 4096) == 0 || i10 != i13) {
            z13 = false;
        }
        if (z16 || z13) {
            view.setOnClickListener(this);
        }
    }

    public final void b(MotionLayout motionLayout) {
        int i10 = this.f259b;
        if (i10 != -1) {
            View findViewById = motionLayout.findViewById(i10);
            if (findViewById == null) {
                Log.e("MotionScene", " (*)  could not find id " + i10);
                return;
            }
            findViewById.setOnClickListener((View.OnClickListener) null);
        }
    }

    public final void onClick(View view) {
        boolean z4;
        y yVar = this.f258a;
        z zVar = yVar.f270j;
        MotionLayout motionLayout = zVar.f279a;
        if (motionLayout.B) {
            if (yVar.f264d == -1) {
                int currentState = motionLayout.getCurrentState();
                if (currentState == -1) {
                    int i10 = yVar.f263c;
                    if (!motionLayout.isAttachedToWindow()) {
                        if (motionLayout.f1703z1 == null) {
                            motionLayout.f1703z1 = new t(motionLayout);
                        }
                        motionLayout.f1703z1.f233d = i10;
                        return;
                    }
                    motionLayout.F(i10, -1);
                    return;
                }
                y yVar2 = new y(yVar.f270j, yVar);
                yVar2.f264d = currentState;
                yVar2.f263c = yVar.f263c;
                motionLayout.setTransition(yVar2);
                motionLayout.r(1.0f);
                motionLayout.A1 = null;
                return;
            }
            y yVar3 = zVar.f281c;
            int i11 = this.f260c;
            int i12 = i11 & 1;
            boolean z10 = true;
            boolean z11 = false;
            if (i12 == 0 && (i11 & 256) == 0) {
                z4 = false;
            } else {
                z4 = true;
            }
            int i13 = i11 & 16;
            if (i13 == 0 && (i11 & 4096) == 0) {
                z10 = false;
            }
            if (!z4 || !z10) {
                z11 = z4;
            } else {
                if (yVar3 != yVar) {
                    motionLayout.setTransition(yVar);
                }
                if (motionLayout.getCurrentState() != motionLayout.getEndState() && motionLayout.getProgress() <= 0.5f) {
                    z11 = z4;
                    z10 = false;
                }
            }
            if (yVar != yVar3) {
                int i14 = yVar.f263c;
                int i15 = yVar.f264d;
                if (i15 != -1) {
                    int i16 = motionLayout.f1698x;
                    if (!(i16 == i15 || i16 == i14)) {
                        return;
                    }
                } else if (motionLayout.f1698x == i14) {
                    return;
                }
            }
            if (z11 && i12 != 0) {
                motionLayout.setTransition(yVar);
                motionLayout.r(1.0f);
                motionLayout.A1 = null;
            } else if (z10 && i13 != 0) {
                motionLayout.setTransition(yVar);
                motionLayout.r(0.0f);
            } else if (z11 && (i11 & 256) != 0) {
                motionLayout.setTransition(yVar);
                motionLayout.setProgress(1.0f);
            } else if (z10 && (i11 & 4096) != 0) {
                motionLayout.setTransition(yVar);
                motionLayout.setProgress(0.0f);
            }
        }
    }
}
