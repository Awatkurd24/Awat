package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.RectF;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;

public final class b0 {
    public static final float[][] E = {new float[]{0.5f, 0.0f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}, new float[]{0.5f, 1.0f}, new float[]{0.5f, 0.5f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}};
    public static final float[][] F = {new float[]{0.0f, -1.0f}, new float[]{0.0f, 1.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}};
    public final float A = Float.NaN;
    public final float B = Float.NaN;
    public final int C = 0;
    public final int D = 0;

    /* renamed from: a  reason: collision with root package name */
    public final int f64a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final int f65b = 0;

    /* renamed from: c  reason: collision with root package name */
    public int f66c = 0;

    /* renamed from: d  reason: collision with root package name */
    public final int f67d = -1;

    /* renamed from: e  reason: collision with root package name */
    public final int f68e = -1;

    /* renamed from: f  reason: collision with root package name */
    public final int f69f = -1;

    /* renamed from: g  reason: collision with root package name */
    public float f70g = 0.5f;

    /* renamed from: h  reason: collision with root package name */
    public float f71h = 0.5f;

    /* renamed from: i  reason: collision with root package name */
    public final int f72i = -1;

    /* renamed from: j  reason: collision with root package name */
    public final boolean f73j = false;

    /* renamed from: k  reason: collision with root package name */
    public float f74k = 0.0f;

    /* renamed from: l  reason: collision with root package name */
    public float f75l = 1.0f;

    /* renamed from: m  reason: collision with root package name */
    public boolean f76m = false;

    /* renamed from: n  reason: collision with root package name */
    public final float[] f77n = new float[2];

    /* renamed from: o  reason: collision with root package name */
    public final int[] f78o = new int[2];

    /* renamed from: p  reason: collision with root package name */
    public float f79p;

    /* renamed from: q  reason: collision with root package name */
    public float f80q;

    /* renamed from: r  reason: collision with root package name */
    public final MotionLayout f81r;

    /* renamed from: s  reason: collision with root package name */
    public final float f82s = 4.0f;

    /* renamed from: t  reason: collision with root package name */
    public final float f83t = 1.2f;

    /* renamed from: u  reason: collision with root package name */
    public final boolean f84u = true;

    /* renamed from: v  reason: collision with root package name */
    public final float f85v = 1.0f;

    /* renamed from: w  reason: collision with root package name */
    public final int f86w = 0;

    /* renamed from: x  reason: collision with root package name */
    public final float f87x = 10.0f;

    /* renamed from: y  reason: collision with root package name */
    public final float f88y = 10.0f;

    /* renamed from: z  reason: collision with root package name */
    public final float f89z = 1.0f;

    public b0(Context context, MotionLayout motionLayout, XmlResourceParser xmlResourceParser) {
        this.f81r = motionLayout;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.f3922v);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 16) {
                this.f67d = obtainStyledAttributes.getResourceId(index, this.f67d);
            } else if (index == 17) {
                int i11 = obtainStyledAttributes.getInt(index, this.f64a);
                this.f64a = i11;
                float[] fArr = E[i11];
                this.f71h = fArr[0];
                this.f70g = fArr[1];
            } else if (index == 1) {
                int i12 = obtainStyledAttributes.getInt(index, this.f65b);
                this.f65b = i12;
                if (i12 < 6) {
                    float[] fArr2 = F[i12];
                    this.f74k = fArr2[0];
                    this.f75l = fArr2[1];
                } else {
                    this.f75l = Float.NaN;
                    this.f74k = Float.NaN;
                    this.f73j = true;
                }
            } else if (index == 6) {
                this.f82s = obtainStyledAttributes.getFloat(index, this.f82s);
            } else if (index == 5) {
                this.f83t = obtainStyledAttributes.getFloat(index, this.f83t);
            } else if (index == 7) {
                this.f84u = obtainStyledAttributes.getBoolean(index, this.f84u);
            } else if (index == 2) {
                this.f85v = obtainStyledAttributes.getFloat(index, this.f85v);
            } else if (index == 3) {
                this.f87x = obtainStyledAttributes.getFloat(index, this.f87x);
            } else if (index == 18) {
                this.f68e = obtainStyledAttributes.getResourceId(index, this.f68e);
            } else if (index == 9) {
                this.f66c = obtainStyledAttributes.getInt(index, this.f66c);
            } else if (index == 8) {
                this.f86w = obtainStyledAttributes.getInteger(index, 0);
            } else if (index == 4) {
                this.f69f = obtainStyledAttributes.getResourceId(index, 0);
            } else if (index == 10) {
                this.f72i = obtainStyledAttributes.getResourceId(index, this.f72i);
            } else if (index == 12) {
                this.f88y = obtainStyledAttributes.getFloat(index, this.f88y);
            } else if (index == 13) {
                this.f89z = obtainStyledAttributes.getFloat(index, this.f89z);
            } else if (index == 14) {
                this.A = obtainStyledAttributes.getFloat(index, this.A);
            } else if (index == 15) {
                this.B = obtainStyledAttributes.getFloat(index, this.B);
            } else if (index == 11) {
                this.C = obtainStyledAttributes.getInt(index, this.C);
            } else if (index == 0) {
                this.D = obtainStyledAttributes.getInt(index, this.D);
            }
        }
        obtainStyledAttributes.recycle();
    }

    public final RectF a(MotionLayout motionLayout, RectF rectF) {
        View findViewById;
        int i10 = this.f69f;
        if (i10 == -1 || (findViewById = motionLayout.findViewById(i10)) == null) {
            return null;
        }
        rectF.set((float) findViewById.getLeft(), (float) findViewById.getTop(), (float) findViewById.getRight(), (float) findViewById.getBottom());
        return rectF;
    }

    public final RectF b(ViewGroup viewGroup, RectF rectF) {
        View findViewById;
        int i10 = this.f68e;
        if (i10 == -1 || (findViewById = viewGroup.findViewById(i10)) == null) {
            return null;
        }
        rectF.set((float) findViewById.getLeft(), (float) findViewById.getTop(), (float) findViewById.getRight(), (float) findViewById.getBottom());
        return rectF;
    }

    public final void c(boolean z4) {
        float[][] fArr = E;
        float[][] fArr2 = F;
        if (z4) {
            fArr2[4] = fArr2[3];
            fArr2[5] = fArr2[2];
            fArr[5] = fArr[2];
            fArr[6] = fArr[1];
        } else {
            fArr2[4] = fArr2[2];
            fArr2[5] = fArr2[3];
            fArr[5] = fArr[1];
            fArr[6] = fArr[2];
        }
        float[] fArr3 = fArr[this.f64a];
        this.f71h = fArr3[0];
        this.f70g = fArr3[1];
        int i10 = this.f65b;
        if (i10 < 6) {
            float[] fArr4 = fArr2[i10];
            this.f74k = fArr4[0];
            this.f75l = fArr4[1];
        }
    }

    public final String toString() {
        if (Float.isNaN(this.f74k)) {
            return "rotation";
        }
        return this.f74k + " , " + this.f75l;
    }
}
