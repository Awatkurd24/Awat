package a1;

import android.util.SparseIntArray;

public abstract class h {

    /* renamed from: a  reason: collision with root package name */
    public static final SparseIntArray f146a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f146a = sparseIntArray;
        sparseIntArray.append(4, 1);
        sparseIntArray.append(2, 2);
        sparseIntArray.append(11, 3);
        sparseIntArray.append(0, 4);
        sparseIntArray.append(1, 5);
        sparseIntArray.append(8, 6);
        sparseIntArray.append(9, 7);
        sparseIntArray.append(3, 9);
        sparseIntArray.append(10, 8);
        sparseIntArray.append(7, 11);
        sparseIntArray.append(6, 12);
        sparseIntArray.append(5, 10);
    }
}
