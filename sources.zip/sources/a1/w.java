package a1;

import c1.a;
import c1.g;
import c1.i;
import java.util.LinkedHashMap;
import t.u;
import v0.e;

public final class w implements Comparable {

    /* renamed from: r  reason: collision with root package name */
    public static final String[] f240r = {"position", "x", "y", "width", "height", "pathRotate"};

    /* renamed from: a  reason: collision with root package name */
    public e f241a;

    /* renamed from: b  reason: collision with root package name */
    public int f242b = 0;

    /* renamed from: c  reason: collision with root package name */
    public float f243c;

    /* renamed from: d  reason: collision with root package name */
    public float f244d;

    /* renamed from: e  reason: collision with root package name */
    public float f245e;

    /* renamed from: f  reason: collision with root package name */
    public float f246f;

    /* renamed from: g  reason: collision with root package name */
    public float f247g;

    /* renamed from: h  reason: collision with root package name */
    public float f248h;

    /* renamed from: i  reason: collision with root package name */
    public float f249i = Float.NaN;

    /* renamed from: j  reason: collision with root package name */
    public int f250j = -1;

    /* renamed from: k  reason: collision with root package name */
    public int f251k = -1;

    /* renamed from: l  reason: collision with root package name */
    public float f252l = Float.NaN;

    /* renamed from: m  reason: collision with root package name */
    public n f253m = null;

    /* renamed from: n  reason: collision with root package name */
    public LinkedHashMap f254n = new LinkedHashMap();

    /* renamed from: o  reason: collision with root package name */
    public int f255o = 0;

    /* renamed from: p  reason: collision with root package name */
    public double[] f256p = new double[18];

    /* renamed from: q  reason: collision with root package name */
    public double[] f257q = new double[18];

    public static boolean b(float f10, float f11) {
        return (Float.isNaN(f10) || Float.isNaN(f11)) ? Float.isNaN(f10) != Float.isNaN(f11) : Math.abs(f10 - f11) > 1.0E-6f;
    }

    public static void g(float f10, float f11, float[] fArr, int[] iArr, double[] dArr, double[] dArr2) {
        int[] iArr2 = iArr;
        float f12 = 0.0f;
        float f13 = 0.0f;
        float f14 = 0.0f;
        float f15 = 0.0f;
        for (int i10 = 0; i10 < iArr2.length; i10++) {
            float f16 = (float) dArr[i10];
            double d10 = dArr2[i10];
            int i11 = iArr2[i10];
            if (i11 == 1) {
                f12 = f16;
            } else if (i11 == 2) {
                f14 = f16;
            } else if (i11 == 3) {
                f13 = f16;
            } else if (i11 == 4) {
                f15 = f16;
            }
        }
        float f17 = f12 - ((0.0f * f13) / 2.0f);
        float f18 = f14 - ((0.0f * f15) / 2.0f);
        fArr[0] = (((f13 * 1.0f) + f17) * f10) + ((1.0f - f10) * f17) + 0.0f;
        fArr[1] = (((f15 * 1.0f) + f18) * f11) + ((1.0f - f11) * f18) + 0.0f;
    }

    public final void a(g gVar) {
        int h10;
        this.f241a = e.c(gVar.f3801d.f3853d);
        i iVar = gVar.f3801d;
        this.f250j = iVar.f3854e;
        this.f251k = iVar.f3851b;
        this.f249i = iVar.f3857h;
        this.f242b = iVar.f3855f;
        float f10 = gVar.f3800c.f3867e;
        this.f252l = gVar.f3802e.C;
        for (String str : gVar.f3804g.keySet()) {
            a aVar = (a) gVar.f3804g.get(str);
            if (!(aVar == null || (h10 = u.h(aVar.f3726c)) == 4 || h10 == 5 || h10 == 7)) {
                this.f254n.put(str, aVar);
            }
        }
    }

    public final void c(double[] dArr, int[] iArr) {
        float[] fArr = {this.f244d, this.f245e, this.f246f, this.f247g, this.f248h, this.f249i};
        int i10 = 0;
        for (int i11 : iArr) {
            if (i11 < 6) {
                dArr[i10] = (double) fArr[i11];
                i10++;
            }
        }
    }

    public final int compareTo(Object obj) {
        return Float.compare(this.f244d, ((w) obj).f244d);
    }

    public final void d(double d10, int[] iArr, double[] dArr, float[] fArr, int i10) {
        int[] iArr2 = iArr;
        float f10 = this.f245e;
        float f11 = this.f246f;
        float f12 = this.f247g;
        float f13 = this.f248h;
        for (int i11 = 0; i11 < iArr2.length; i11++) {
            float f14 = (float) dArr[i11];
            int i12 = iArr2[i11];
            if (i12 == 1) {
                f10 = f14;
            } else if (i12 == 2) {
                f11 = f14;
            } else if (i12 == 3) {
                f12 = f14;
            } else if (i12 == 4) {
                f13 = f14;
            }
        }
        n nVar = this.f253m;
        if (nVar != null) {
            float[] fArr2 = new float[2];
            nVar.c(d10, fArr2, new float[2]);
            float f15 = fArr2[0];
            float f16 = fArr2[1];
            double d11 = (double) f15;
            double d12 = (double) f10;
            double d13 = (double) f11;
            f10 = (float) (((Math.sin(d13) * d12) + d11) - ((double) (f12 / 2.0f)));
            f11 = (float) ((((double) f16) - (Math.cos(d13) * d12)) - ((double) (f13 / 2.0f)));
        }
        fArr[i10] = (f12 / 2.0f) + f10 + 0.0f;
        fArr[i10 + 1] = (f13 / 2.0f) + f11 + 0.0f;
    }

    public final void e(String str, double[] dArr) {
        a aVar = (a) this.f254n.get(str);
        if (aVar != null) {
            int i10 = 0;
            if (aVar.c() == 1) {
                dArr[0] = (double) aVar.a();
                return;
            }
            int c10 = aVar.c();
            float[] fArr = new float[c10];
            aVar.b(fArr);
            int i11 = 0;
            while (i10 < c10) {
                dArr[i11] = (double) fArr[i10];
                i10++;
                i11++;
            }
        }
    }

    public final void f(float f10, float f11, float f12, float f13) {
        this.f245e = f10;
        this.f246f = f11;
        this.f247g = f12;
        this.f248h = f13;
    }

    public final void h(n nVar, w wVar) {
        double d10 = (double) ((((this.f247g / 2.0f) + this.f245e) - wVar.f245e) - (wVar.f247g / 2.0f));
        double d11 = (double) ((((this.f248h / 2.0f) + this.f246f) - wVar.f246f) - (wVar.f248h / 2.0f));
        this.f253m = nVar;
        this.f245e = (float) Math.hypot(d11, d10);
        this.f246f = (float) (Float.isNaN(this.f252l) ? Math.atan2(d11, d10) + 1.5707963267948966d : Math.toRadians((double) this.f252l));
    }
}
