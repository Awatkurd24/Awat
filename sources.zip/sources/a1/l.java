package a1;

import android.graphics.Rect;
import c1.a;
import c1.g;
import c1.i;
import c1.j;
import c1.k;
import java.util.LinkedHashMap;
import t.u;
import v0.e;

public final class l implements Comparable {

    /* renamed from: a  reason: collision with root package name */
    public float f158a = 1.0f;

    /* renamed from: b  reason: collision with root package name */
    public int f159b = 0;

    /* renamed from: c  reason: collision with root package name */
    public int f160c;

    /* renamed from: d  reason: collision with root package name */
    public float f161d = 0.0f;

    /* renamed from: e  reason: collision with root package name */
    public float f162e = 0.0f;

    /* renamed from: f  reason: collision with root package name */
    public float f163f = 0.0f;

    /* renamed from: g  reason: collision with root package name */
    public float f164g = 0.0f;

    /* renamed from: h  reason: collision with root package name */
    public float f165h = 1.0f;

    /* renamed from: i  reason: collision with root package name */
    public float f166i = 1.0f;

    /* renamed from: j  reason: collision with root package name */
    public float f167j = Float.NaN;

    /* renamed from: k  reason: collision with root package name */
    public float f168k = Float.NaN;

    /* renamed from: l  reason: collision with root package name */
    public float f169l = 0.0f;

    /* renamed from: m  reason: collision with root package name */
    public float f170m = 0.0f;

    /* renamed from: n  reason: collision with root package name */
    public float f171n = 0.0f;

    /* renamed from: o  reason: collision with root package name */
    public float f172o = Float.NaN;

    /* renamed from: p  reason: collision with root package name */
    public float f173p = Float.NaN;

    /* renamed from: q  reason: collision with root package name */
    public final LinkedHashMap f174q = new LinkedHashMap();

    public static boolean b(float f10, float f11) {
        return (Float.isNaN(f10) || Float.isNaN(f11)) ? Float.isNaN(f10) != Float.isNaN(f11) : Math.abs(f10 - f11) > 1.0E-6f;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0140, code lost:
        r2.b(r9, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0150, code lost:
        r2.b(r9, r6);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(java.util.HashMap r8, int r9) {
        /*
            r7 = this;
            java.util.Set r0 = r8.keySet()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x01e9
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r2 = r8.get(r1)
            z0.k r2 = (z0.k) r2
            r1.getClass()
            int r3 = r1.hashCode()
            r4 = 1
            r5 = -1
            switch(r3) {
                case -1249320806: goto L_0x00c9;
                case -1249320805: goto L_0x00be;
                case -1225497657: goto L_0x00b3;
                case -1225497656: goto L_0x00a8;
                case -1225497655: goto L_0x009d;
                case -1001078227: goto L_0x0092;
                case -908189618: goto L_0x0087;
                case -908189617: goto L_0x007c;
                case -760884510: goto L_0x006e;
                case -760884509: goto L_0x0060;
                case -40300674: goto L_0x0052;
                case -4379043: goto L_0x0044;
                case 37232917: goto L_0x0036;
                case 92909918: goto L_0x0028;
                default: goto L_0x0026;
            }
        L_0x0026:
            goto L_0x00d3
        L_0x0028:
            java.lang.String r3 = "alpha"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0032
            goto L_0x00d3
        L_0x0032:
            r5 = 13
            goto L_0x00d3
        L_0x0036:
            java.lang.String r3 = "transitionPathRotate"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0040
            goto L_0x00d3
        L_0x0040:
            r5 = 12
            goto L_0x00d3
        L_0x0044:
            java.lang.String r3 = "elevation"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x004e
            goto L_0x00d3
        L_0x004e:
            r5 = 11
            goto L_0x00d3
        L_0x0052:
            java.lang.String r3 = "rotation"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x005c
            goto L_0x00d3
        L_0x005c:
            r5 = 10
            goto L_0x00d3
        L_0x0060:
            java.lang.String r3 = "transformPivotY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x006a
            goto L_0x00d3
        L_0x006a:
            r5 = 9
            goto L_0x00d3
        L_0x006e:
            java.lang.String r3 = "transformPivotX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0078
            goto L_0x00d3
        L_0x0078:
            r5 = 8
            goto L_0x00d3
        L_0x007c:
            java.lang.String r3 = "scaleY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0085
            goto L_0x00d3
        L_0x0085:
            r5 = 7
            goto L_0x00d3
        L_0x0087:
            java.lang.String r3 = "scaleX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x0090
            goto L_0x00d3
        L_0x0090:
            r5 = 6
            goto L_0x00d3
        L_0x0092:
            java.lang.String r3 = "progress"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x009b
            goto L_0x00d3
        L_0x009b:
            r5 = 5
            goto L_0x00d3
        L_0x009d:
            java.lang.String r3 = "translationZ"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00a6
            goto L_0x00d3
        L_0x00a6:
            r5 = 4
            goto L_0x00d3
        L_0x00a8:
            java.lang.String r3 = "translationY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00b1
            goto L_0x00d3
        L_0x00b1:
            r5 = 3
            goto L_0x00d3
        L_0x00b3:
            java.lang.String r3 = "translationX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00bc
            goto L_0x00d3
        L_0x00bc:
            r5 = 2
            goto L_0x00d3
        L_0x00be:
            java.lang.String r3 = "rotationY"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00c7
            goto L_0x00d3
        L_0x00c7:
            r5 = 1
            goto L_0x00d3
        L_0x00c9:
            java.lang.String r3 = "rotationX"
            boolean r3 = r1.equals(r3)
            if (r3 != 0) goto L_0x00d2
            goto L_0x00d3
        L_0x00d2:
            r5 = 0
        L_0x00d3:
            r3 = 1065353216(0x3f800000, float:1.0)
            r6 = 0
            switch(r5) {
                case 0: goto L_0x01db;
                case 1: goto L_0x01cd;
                case 2: goto L_0x01c1;
                case 3: goto L_0x01b5;
                case 4: goto L_0x01a9;
                case 5: goto L_0x019d;
                case 6: goto L_0x0191;
                case 7: goto L_0x0185;
                case 8: goto L_0x0179;
                case 9: goto L_0x016d;
                case 10: goto L_0x0161;
                case 11: goto L_0x0155;
                case 12: goto L_0x0145;
                case 13: goto L_0x0135;
                default: goto L_0x00d9;
            }
        L_0x00d9:
            java.lang.String r3 = "CUSTOM"
            boolean r3 = r1.startsWith(r3)
            java.lang.String r5 = "MotionPaths"
            if (r3 == 0) goto L_0x012e
            java.lang.String r3 = ","
            java.lang.String[] r3 = r1.split(r3)
            r3 = r3[r4]
            java.util.LinkedHashMap r4 = r7.f174q
            boolean r6 = r4.containsKey(r3)
            if (r6 == 0) goto L_0x0008
            java.lang.Object r3 = r4.get(r3)
            c1.a r3 = (c1.a) r3
            boolean r4 = r2 instanceof z0.h
            if (r4 == 0) goto L_0x0106
            z0.h r2 = (z0.h) r2
            android.util.SparseArray r1 = r2.f30594f
            r1.append(r9, r3)
            goto L_0x0008
        L_0x0106:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            r4.append(r1)
            java.lang.String r1 = " ViewSpline not a CustomSet frame = "
            r4.append(r1)
            r4.append(r9)
            java.lang.String r1 = ", value"
            r4.append(r1)
            float r1 = r3.a()
            r4.append(r1)
            r4.append(r2)
            java.lang.String r1 = r4.toString()
        L_0x0129:
            android.util.Log.e(r5, r1)
            goto L_0x0008
        L_0x012e:
            java.lang.String r2 = "UNKNOWN spline "
            java.lang.String r1 = r2.concat(r1)
            goto L_0x0129
        L_0x0135:
            float r1 = r7.f158a
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x013e
            goto L_0x0140
        L_0x013e:
            float r3 = r7.f158a
        L_0x0140:
            r2.b(r9, r3)
            goto L_0x0008
        L_0x0145:
            float r1 = r7.f172o
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x014e
            goto L_0x0150
        L_0x014e:
            float r6 = r7.f172o
        L_0x0150:
            r2.b(r9, r6)
            goto L_0x0008
        L_0x0155:
            float r1 = r7.f161d
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x015e
            goto L_0x0150
        L_0x015e:
            float r6 = r7.f161d
            goto L_0x0150
        L_0x0161:
            float r1 = r7.f162e
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x016a
            goto L_0x0150
        L_0x016a:
            float r6 = r7.f162e
            goto L_0x0150
        L_0x016d:
            float r1 = r7.f168k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0176
            goto L_0x0150
        L_0x0176:
            float r6 = r7.f168k
            goto L_0x0150
        L_0x0179:
            float r1 = r7.f167j
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0182
            goto L_0x0150
        L_0x0182:
            float r6 = r7.f167j
            goto L_0x0150
        L_0x0185:
            float r1 = r7.f166i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x018e
            goto L_0x0140
        L_0x018e:
            float r3 = r7.f166i
            goto L_0x0140
        L_0x0191:
            float r1 = r7.f165h
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x019a
            goto L_0x0140
        L_0x019a:
            float r3 = r7.f165h
            goto L_0x0140
        L_0x019d:
            float r1 = r7.f173p
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01a6
            goto L_0x0150
        L_0x01a6:
            float r6 = r7.f173p
            goto L_0x0150
        L_0x01a9:
            float r1 = r7.f171n
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01b2
            goto L_0x0150
        L_0x01b2:
            float r6 = r7.f171n
            goto L_0x0150
        L_0x01b5:
            float r1 = r7.f170m
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01be
            goto L_0x0150
        L_0x01be:
            float r6 = r7.f170m
            goto L_0x0150
        L_0x01c1:
            float r1 = r7.f169l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01ca
            goto L_0x0150
        L_0x01ca:
            float r6 = r7.f169l
            goto L_0x0150
        L_0x01cd:
            float r1 = r7.f164g
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01d7
            goto L_0x0150
        L_0x01d7:
            float r6 = r7.f164g
            goto L_0x0150
        L_0x01db:
            float r1 = r7.f163f
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01e5
            goto L_0x0150
        L_0x01e5:
            float r6 = r7.f163f
            goto L_0x0150
        L_0x01e9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.l.a(java.util.HashMap, int):void");
    }

    public final void c(Rect rect, c1.l lVar, int i10, int i11) {
        float f10;
        float f11;
        rect.width();
        rect.height();
        g h10 = lVar.h(i11);
        j jVar = h10.f3800c;
        int i12 = jVar.f3865c;
        this.f159b = i12;
        int i13 = jVar.f3864b;
        this.f160c = i13;
        if (i13 == 0 || i12 != 0) {
            f10 = jVar.f3866d;
        } else {
            f10 = 0.0f;
        }
        this.f158a = f10;
        k kVar = h10.f3803f;
        boolean z4 = kVar.f3881m;
        this.f161d = kVar.f3882n;
        this.f162e = kVar.f3870b;
        this.f163f = kVar.f3871c;
        this.f164g = kVar.f3872d;
        this.f165h = kVar.f3873e;
        this.f166i = kVar.f3874f;
        this.f167j = kVar.f3875g;
        this.f168k = kVar.f3876h;
        this.f169l = kVar.f3878j;
        this.f170m = kVar.f3879k;
        this.f171n = kVar.f3880l;
        i iVar = h10.f3801d;
        e.c(iVar.f3853d);
        this.f172o = iVar.f3857h;
        this.f173p = h10.f3800c.f3867e;
        for (String str : h10.f3804g.keySet()) {
            a aVar = (a) h10.f3804g.get(str);
            int h11 = u.h(aVar.f3726c);
            if (!(h11 == 4 || h11 == 5 || h11 == 7)) {
                this.f174q.put(str, aVar);
            }
        }
        float f12 = 90.0f;
        if (i10 != 1) {
            if (i10 != 2) {
                if (i10 != 3) {
                    if (i10 != 4) {
                        return;
                    }
                }
            }
            f11 = this.f162e + 90.0f;
            this.f162e = f11;
            if (f11 > 180.0f) {
                f12 = 360.0f;
                this.f162e = f11 - f12;
            }
            return;
        }
        f11 = this.f162e;
        this.f162e = f11 - f12;
    }

    public final int compareTo(Object obj) {
        ((l) obj).getClass();
        return Float.compare(0.0f, 0.0f);
    }
}
