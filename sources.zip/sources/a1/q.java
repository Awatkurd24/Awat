package a1;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.View;
import androidx.constraintlayout.motion.widget.MotionLayout;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public float[] f207a;

    /* renamed from: b  reason: collision with root package name */
    public final int[] f208b;

    /* renamed from: c  reason: collision with root package name */
    public final float[] f209c;

    /* renamed from: d  reason: collision with root package name */
    public Path f210d;

    /* renamed from: e  reason: collision with root package name */
    public final Paint f211e;

    /* renamed from: f  reason: collision with root package name */
    public final Paint f212f;

    /* renamed from: g  reason: collision with root package name */
    public final Paint f213g;

    /* renamed from: h  reason: collision with root package name */
    public final Paint f214h;

    /* renamed from: i  reason: collision with root package name */
    public final Paint f215i;

    /* renamed from: j  reason: collision with root package name */
    public final float[] f216j;

    /* renamed from: k  reason: collision with root package name */
    public int f217k;

    /* renamed from: l  reason: collision with root package name */
    public final Rect f218l = new Rect();

    /* renamed from: m  reason: collision with root package name */
    public final int f219m = 1;

    /* renamed from: n  reason: collision with root package name */
    public final /* synthetic */ MotionLayout f220n;

    public q(MotionLayout motionLayout) {
        this.f220n = motionLayout;
        Paint paint = new Paint();
        this.f211e = paint;
        paint.setAntiAlias(true);
        paint.setColor(-21965);
        paint.setStrokeWidth(2.0f);
        Paint.Style style = Paint.Style.STROKE;
        paint.setStyle(style);
        Paint paint2 = new Paint();
        this.f212f = paint2;
        paint2.setAntiAlias(true);
        paint2.setColor(-2067046);
        paint2.setStrokeWidth(2.0f);
        paint2.setStyle(style);
        Paint paint3 = new Paint();
        this.f213g = paint3;
        paint3.setAntiAlias(true);
        paint3.setColor(-13391360);
        paint3.setStrokeWidth(2.0f);
        paint3.setStyle(style);
        Paint paint4 = new Paint();
        this.f214h = paint4;
        paint4.setAntiAlias(true);
        paint4.setColor(-13391360);
        paint4.setTextSize(motionLayout.getContext().getResources().getDisplayMetrics().density * 12.0f);
        this.f216j = new float[8];
        Paint paint5 = new Paint();
        this.f215i = paint5;
        paint5.setAntiAlias(true);
        paint3.setPathEffect(new DashPathEffect(new float[]{4.0f, 8.0f}, 0.0f));
        this.f209c = new float[100];
        this.f208b = new int[50];
    }

    public final void a(Canvas canvas, int i10, int i11, n nVar) {
        int i12;
        int i13;
        int i14;
        float f10;
        float f11;
        Paint paint;
        Canvas canvas2 = canvas;
        int i15 = i10;
        n nVar2 = nVar;
        int[] iArr = this.f208b;
        int i16 = 4;
        if (i15 == 4) {
            boolean z4 = false;
            boolean z10 = false;
            for (int i17 = 0; i17 < this.f217k; i17++) {
                int i18 = iArr[i17];
                if (i18 == 1) {
                    z4 = true;
                }
                if (i18 == 0) {
                    z10 = true;
                }
            }
            if (z4) {
                float[] fArr = this.f207a;
                canvas.drawLine(fArr[0], fArr[1], fArr[fArr.length - 2], fArr[fArr.length - 1], this.f213g);
            }
            if (z10) {
                b(canvas);
            }
        }
        if (i15 == 2) {
            float[] fArr2 = this.f207a;
            canvas.drawLine(fArr2[0], fArr2[1], fArr2[fArr2.length - 2], fArr2[fArr2.length - 1], this.f213g);
        }
        if (i15 == 3) {
            b(canvas);
        }
        canvas2.drawLines(this.f207a, this.f211e);
        View view = nVar2.f178b;
        if (view != null) {
            i13 = view.getWidth();
            i12 = nVar2.f178b.getHeight();
        } else {
            i13 = 0;
            i12 = 0;
        }
        int i19 = 1;
        while (i19 < i11 - 1) {
            if (i15 == i16 && iArr[i19 - 1] == 0) {
                i14 = i19;
            } else {
                int i20 = i19 * 2;
                float[] fArr3 = this.f209c;
                float f12 = fArr3[i20];
                float f13 = fArr3[i20 + 1];
                this.f210d.reset();
                this.f210d.moveTo(f12, f13 + 10.0f);
                this.f210d.lineTo(f12 + 10.0f, f13);
                this.f210d.lineTo(f12, f13 - 10.0f);
                this.f210d.lineTo(f12 - 10.0f, f13);
                this.f210d.close();
                int i21 = i19 - 1;
                w wVar = (w) nVar2.f197u.get(i21);
                Paint paint2 = this.f215i;
                if (i15 == i16) {
                    int i22 = iArr[i21];
                    if (i22 == 1) {
                        d(canvas2, f12 - 0.0f, f13 - 0.0f);
                    } else if (i22 == 0) {
                        c(canvas2, f12 - 0.0f, f13 - 0.0f);
                    } else if (i22 == 2) {
                        paint = paint2;
                        f11 = f13;
                        f10 = f12;
                        i14 = i19;
                        e(canvas, f12 - 0.0f, f13 - 0.0f, i13, i12);
                        canvas2.drawPath(this.f210d, paint);
                    }
                    paint = paint2;
                    f11 = f13;
                    f10 = f12;
                    i14 = i19;
                    canvas2.drawPath(this.f210d, paint);
                } else {
                    paint = paint2;
                    f11 = f13;
                    f10 = f12;
                    i14 = i19;
                }
                if (i15 == 2) {
                    d(canvas2, f10 - 0.0f, f11 - 0.0f);
                }
                if (i15 == 3) {
                    c(canvas2, f10 - 0.0f, f11 - 0.0f);
                }
                if (i15 == 6) {
                    e(canvas, f10 - 0.0f, f11 - 0.0f, i13, i12);
                }
                canvas2.drawPath(this.f210d, paint);
            }
            i19 = i14 + 1;
            i16 = 4;
        }
        float[] fArr4 = this.f207a;
        if (fArr4.length > 1) {
            float f14 = fArr4[0];
            float f15 = fArr4[1];
            Paint paint3 = this.f212f;
            canvas2.drawCircle(f14, f15, 8.0f, paint3);
            float[] fArr5 = this.f207a;
            canvas2.drawCircle(fArr5[fArr5.length - 2], fArr5[fArr5.length - 1], 8.0f, paint3);
        }
    }

    public final void b(Canvas canvas) {
        float[] fArr = this.f207a;
        float f10 = fArr[0];
        float f11 = fArr[1];
        float f12 = fArr[fArr.length - 2];
        float f13 = fArr[fArr.length - 1];
        float min = Math.min(f10, f12);
        float max = Math.max(f11, f13);
        float max2 = Math.max(f10, f12);
        float max3 = Math.max(f11, f13);
        Paint paint = this.f213g;
        canvas.drawLine(min, max, max2, max3, paint);
        canvas.drawLine(Math.min(f10, f12), Math.min(f11, f13), Math.min(f10, f12), Math.max(f11, f13), paint);
    }

    public final void c(Canvas canvas, float f10, float f11) {
        Canvas canvas2 = canvas;
        float[] fArr = this.f207a;
        float f12 = fArr[0];
        float f13 = fArr[1];
        float f14 = fArr[fArr.length - 2];
        float f15 = fArr[fArr.length - 1];
        float min = Math.min(f12, f14);
        float max = Math.max(f13, f15);
        float min2 = f10 - Math.min(f12, f14);
        float max2 = Math.max(f13, f15) - f11;
        StringBuilder sb2 = new StringBuilder("");
        float f16 = f13;
        sb2.append(((float) ((int) (((double) ((min2 * 100.0f) / Math.abs(f14 - f12))) + 0.5d))) / 100.0f);
        String sb3 = sb2.toString();
        Paint paint = this.f214h;
        paint.getTextBounds(sb3, 0, sb3.length(), this.f218l);
        Rect rect = this.f218l;
        canvas2.drawText(sb3, ((min2 / 2.0f) - ((float) (rect.width() / 2))) + min, f11 - 20.0f, paint);
        float min3 = Math.min(f12, f14);
        Paint paint2 = this.f213g;
        canvas.drawLine(f10, f11, min3, f11, paint2);
        String str = "" + (((float) ((int) (((double) ((max2 * 100.0f) / Math.abs(f15 - f16))) + 0.5d))) / 100.0f);
        paint.getTextBounds(str, 0, str.length(), this.f218l);
        canvas2.drawText(str, f10 + 5.0f, max - ((max2 / 2.0f) - ((float) (rect.height() / 2))), paint);
        canvas.drawLine(f10, f11, f10, Math.max(f16, f15), paint2);
    }

    public final void d(Canvas canvas, float f10, float f11) {
        float f12 = f10;
        float f13 = f11;
        float[] fArr = this.f207a;
        float f14 = fArr[0];
        float f15 = fArr[1];
        float f16 = fArr[fArr.length - 2];
        float f17 = fArr[fArr.length - 1];
        float hypot = (float) Math.hypot((double) (f14 - f16), (double) (f15 - f17));
        float f18 = f16 - f14;
        float f19 = f17 - f15;
        float f20 = (((f13 - f15) * f19) + ((f12 - f14) * f18)) / (hypot * hypot);
        float f21 = f14 + (f18 * f20);
        float f22 = f15 + (f20 * f19);
        Path path = new Path();
        path.moveTo(f12, f13);
        path.lineTo(f21, f22);
        float hypot2 = (float) Math.hypot((double) (f21 - f12), (double) (f22 - f13));
        String str = "" + (((float) ((int) ((hypot2 * 100.0f) / hypot))) / 100.0f);
        Paint paint = this.f214h;
        paint.getTextBounds(str, 0, str.length(), this.f218l);
        canvas.drawTextOnPath(str, path, (hypot2 / 2.0f) - ((float) (this.f218l.width() / 2)), -20.0f, paint);
        canvas.drawLine(f10, f11, f21, f22, this.f213g);
    }

    public final void e(Canvas canvas, float f10, float f11, int i10, int i11) {
        Canvas canvas2 = canvas;
        StringBuilder sb2 = new StringBuilder("");
        MotionLayout motionLayout = this.f220n;
        sb2.append(((float) ((int) (((double) (((f10 - ((float) (i10 / 2))) * 100.0f) / ((float) (motionLayout.getWidth() - i10)))) + 0.5d))) / 100.0f);
        String sb3 = sb2.toString();
        Paint paint = this.f214h;
        paint.getTextBounds(sb3, 0, sb3.length(), this.f218l);
        Rect rect = this.f218l;
        canvas2.drawText(sb3, ((f10 / 2.0f) - ((float) (rect.width() / 2))) + 0.0f, f11 - 20.0f, paint);
        float min = Math.min(0.0f, 1.0f);
        Paint paint2 = this.f213g;
        canvas.drawLine(f10, f11, min, f11, paint2);
        String str = "" + (((float) ((int) (((double) (((f11 - ((float) (i11 / 2))) * 100.0f) / ((float) (motionLayout.getHeight() - i11)))) + 0.5d))) / 100.0f);
        paint.getTextBounds(str, 0, str.length(), this.f218l);
        canvas2.drawText(str, f10 + 5.0f, 0.0f - ((f11 / 2.0f) - ((float) (rect.height() / 2))), paint);
        canvas.drawLine(f10, f11, f10, Math.max(0.0f, 1.0f), paint2);
    }
}
