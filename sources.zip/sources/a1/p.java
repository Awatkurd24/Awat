package a1;

import androidx.constraintlayout.motion.widget.MotionLayout;

public final class p extends o {

    /* renamed from: a  reason: collision with root package name */
    public float f203a = 0.0f;

    /* renamed from: b  reason: collision with root package name */
    public float f204b = 0.0f;

    /* renamed from: c  reason: collision with root package name */
    public float f205c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ MotionLayout f206d;

    public p(MotionLayout motionLayout) {
        this.f206d = motionLayout;
    }

    public final float a() {
        return this.f206d.f1694v;
    }

    public final float getInterpolation(float f10) {
        float f11 = this.f203a;
        MotionLayout motionLayout = this.f206d;
        if (f11 > 0.0f) {
            float f12 = this.f205c;
            if (f11 / f12 < f10) {
                f10 = f11 / f12;
            }
            motionLayout.f1694v = f11 - (f12 * f10);
            return ((f11 * f10) - (((f12 * f10) * f10) / 2.0f)) + this.f204b;
        }
        float f13 = this.f205c;
        if ((-f11) / f13 < f10) {
            f10 = (-f11) / f13;
        }
        motionLayout.f1694v = (f13 * f10) + f11;
        return (((f13 * f10) * f10) / 2.0f) + (f11 * f10) + this.f204b;
    }
}
