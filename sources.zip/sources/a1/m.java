package a1;

import android.view.animation.Interpolator;
import v0.e;

public final class m implements Interpolator {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f175a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ e f176b;

    public m(e eVar) {
        this.f175a = 0;
        this.f176b = eVar;
    }

    public final float getInterpolation(float f10) {
        int i10 = this.f175a;
        e eVar = this.f176b;
        switch (i10) {
            case 0:
                return (float) eVar.a((double) f10);
            case 1:
                return (float) eVar.a((double) f10);
            default:
                return (float) eVar.a((double) f10);
        }
    }

    public /* synthetic */ m(e eVar, int i10) {
        this.f175a = i10;
        this.f176b = eVar;
    }
}
