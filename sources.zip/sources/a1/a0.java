package a1;

import android.view.MotionEvent;
import android.view.View;

public final class a0 implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f63a = 1;

    public a0() {
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        switch (this.f63a) {
            case 0:
                return false;
            default:
                return true;
        }
    }

    public a0(int i10) {
    }
}
