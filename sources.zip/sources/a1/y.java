package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.SparseArray;
import android.util.Xml;
import c1.l;
import c1.p;
import co.vpn.plusvpn.R;
import java.util.ArrayList;

public final class y {

    /* renamed from: a  reason: collision with root package name */
    public final int f261a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f262b;

    /* renamed from: c  reason: collision with root package name */
    public int f263c;

    /* renamed from: d  reason: collision with root package name */
    public int f264d;

    /* renamed from: e  reason: collision with root package name */
    public int f265e;

    /* renamed from: f  reason: collision with root package name */
    public String f266f;

    /* renamed from: g  reason: collision with root package name */
    public int f267g;

    /* renamed from: h  reason: collision with root package name */
    public int f268h;

    /* renamed from: i  reason: collision with root package name */
    public final float f269i;

    /* renamed from: j  reason: collision with root package name */
    public final z f270j;

    /* renamed from: k  reason: collision with root package name */
    public final ArrayList f271k;

    /* renamed from: l  reason: collision with root package name */
    public b0 f272l;

    /* renamed from: m  reason: collision with root package name */
    public final ArrayList f273m;

    /* renamed from: n  reason: collision with root package name */
    public final int f274n;

    /* renamed from: o  reason: collision with root package name */
    public final boolean f275o;

    /* renamed from: p  reason: collision with root package name */
    public int f276p;

    /* renamed from: q  reason: collision with root package name */
    public final int f277q;

    /* renamed from: r  reason: collision with root package name */
    public final int f278r;

    public y(z zVar, int i10) {
        this.f261a = -1;
        this.f262b = false;
        this.f263c = -1;
        this.f264d = -1;
        this.f265e = 0;
        this.f266f = null;
        this.f267g = -1;
        this.f268h = 400;
        this.f269i = 0.0f;
        this.f271k = new ArrayList();
        this.f272l = null;
        this.f273m = new ArrayList();
        this.f274n = 0;
        this.f275o = false;
        this.f276p = -1;
        this.f277q = 0;
        this.f278r = 0;
        this.f261a = -1;
        this.f270j = zVar;
        this.f264d = R.id.view_transition;
        this.f263c = i10;
        this.f268h = zVar.f288j;
        this.f277q = zVar.f289k;
    }

    public y(z zVar, y yVar) {
        this.f261a = -1;
        this.f262b = false;
        this.f263c = -1;
        this.f264d = -1;
        this.f265e = 0;
        this.f266f = null;
        this.f267g = -1;
        this.f268h = 400;
        this.f269i = 0.0f;
        this.f271k = new ArrayList();
        this.f272l = null;
        this.f273m = new ArrayList();
        this.f274n = 0;
        this.f275o = false;
        this.f276p = -1;
        this.f277q = 0;
        this.f278r = 0;
        this.f270j = zVar;
        this.f268h = zVar.f288j;
        if (yVar != null) {
            this.f276p = yVar.f276p;
            this.f265e = yVar.f265e;
            this.f266f = yVar.f266f;
            this.f267g = yVar.f267g;
            this.f268h = yVar.f268h;
            this.f271k = yVar.f271k;
            this.f269i = yVar.f269i;
            this.f277q = yVar.f277q;
        }
    }

    public y(z zVar, Context context, XmlResourceParser xmlResourceParser) {
        l lVar;
        int i10;
        this.f261a = -1;
        this.f262b = false;
        this.f263c = -1;
        this.f264d = -1;
        this.f265e = 0;
        this.f266f = null;
        this.f267g = -1;
        this.f268h = 400;
        this.f269i = 0.0f;
        this.f271k = new ArrayList();
        this.f272l = null;
        this.f273m = new ArrayList();
        this.f274n = 0;
        this.f275o = false;
        this.f276p = -1;
        this.f277q = 0;
        this.f278r = 0;
        this.f268h = zVar.f288j;
        this.f277q = zVar.f289k;
        this.f270j = zVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.A);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i11 = 0; i11 < indexCount; i11++) {
            int index = obtainStyledAttributes.getIndex(i11);
            SparseArray sparseArray = zVar.f285g;
            if (index == 2) {
                this.f263c = obtainStyledAttributes.getResourceId(index, -1);
                String resourceTypeName = context.getResources().getResourceTypeName(this.f263c);
                if ("layout".equals(resourceTypeName)) {
                    lVar = new l();
                    lVar.j(context, this.f263c);
                    i10 = this.f263c;
                } else {
                    if ("xml".equals(resourceTypeName)) {
                        this.f263c = zVar.j(context, this.f263c);
                    }
                }
            } else {
                if (index == 3) {
                    this.f264d = obtainStyledAttributes.getResourceId(index, this.f264d);
                    String resourceTypeName2 = context.getResources().getResourceTypeName(this.f264d);
                    if ("layout".equals(resourceTypeName2)) {
                        lVar = new l();
                        lVar.j(context, this.f264d);
                        i10 = this.f264d;
                    } else if ("xml".equals(resourceTypeName2)) {
                        this.f264d = zVar.j(context, this.f264d);
                    }
                } else if (index == 6) {
                    int i12 = obtainStyledAttributes.peekValue(index).type;
                    if (i12 == 1) {
                        int resourceId = obtainStyledAttributes.getResourceId(index, -1);
                        this.f267g = resourceId;
                        if (resourceId == -1) {
                        }
                    } else if (i12 == 3) {
                        String string = obtainStyledAttributes.getString(index);
                        this.f266f = string;
                        if (string != null) {
                            if (string.indexOf("/") > 0) {
                                this.f267g = obtainStyledAttributes.getResourceId(index, -1);
                            } else {
                                this.f265e = -1;
                            }
                        }
                    } else {
                        this.f265e = obtainStyledAttributes.getInteger(index, this.f265e);
                    }
                    this.f265e = -2;
                } else if (index == 4) {
                    int i13 = obtainStyledAttributes.getInt(index, this.f268h);
                    this.f268h = i13;
                    if (i13 < 8) {
                        this.f268h = 8;
                    }
                } else if (index == 8) {
                    this.f269i = obtainStyledAttributes.getFloat(index, this.f269i);
                } else if (index == 1) {
                    this.f274n = obtainStyledAttributes.getInteger(index, this.f274n);
                } else if (index == 0) {
                    this.f261a = obtainStyledAttributes.getResourceId(index, this.f261a);
                } else if (index == 9) {
                    this.f275o = obtainStyledAttributes.getBoolean(index, this.f275o);
                } else if (index == 7) {
                    this.f276p = obtainStyledAttributes.getInteger(index, -1);
                } else if (index == 5) {
                    this.f277q = obtainStyledAttributes.getInteger(index, 0);
                } else if (index == 10) {
                    this.f278r = obtainStyledAttributes.getInteger(index, 0);
                }
            }
            sparseArray.append(i10, lVar);
        }
        if (this.f264d == -1) {
            this.f262b = true;
        }
        obtainStyledAttributes.recycle();
    }
}
