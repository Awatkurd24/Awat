package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintHelper;
import c1.a;
import c1.c;
import c1.g;
import c1.h;
import c1.i;
import c1.j;
import c1.k;
import c1.l;
import c1.p;
import c1.u;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;
import pa.b;
import v0.e;
import yg.b0;

public final class z {

    /* renamed from: a  reason: collision with root package name */
    public final MotionLayout f279a;

    /* renamed from: b  reason: collision with root package name */
    public final u f280b = null;

    /* renamed from: c  reason: collision with root package name */
    public y f281c = null;

    /* renamed from: d  reason: collision with root package name */
    public final ArrayList f282d;

    /* renamed from: e  reason: collision with root package name */
    public final y f283e;

    /* renamed from: f  reason: collision with root package name */
    public final ArrayList f284f;

    /* renamed from: g  reason: collision with root package name */
    public final SparseArray f285g;

    /* renamed from: h  reason: collision with root package name */
    public final HashMap f286h;

    /* renamed from: i  reason: collision with root package name */
    public final SparseIntArray f287i;

    /* renamed from: j  reason: collision with root package name */
    public int f288j;

    /* renamed from: k  reason: collision with root package name */
    public int f289k;

    /* renamed from: l  reason: collision with root package name */
    public MotionEvent f290l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f291m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f292n;

    /* renamed from: o  reason: collision with root package name */
    public s f293o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f294p;

    /* renamed from: q  reason: collision with root package name */
    public final b f295q;

    /* renamed from: r  reason: collision with root package name */
    public float f296r;

    /* renamed from: s  reason: collision with root package name */
    public float f297s;

    /* JADX WARNING: type inference failed for: r3v0, types: [pa.b, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r6v5, types: [c1.q] */
    /* JADX WARNING: type inference failed for: r6v8 */
    /* JADX WARNING: type inference failed for: r6v9 */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public z(android.content.Context r13, androidx.constraintlayout.motion.widget.MotionLayout r14, int r15) {
        /*
            r12 = this;
            r12.<init>()
            r0 = 0
            r12.f280b = r0
            r12.f281c = r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r12.f282d = r1
            r12.f283e = r0
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            r12.f284f = r2
            android.util.SparseArray r2 = new android.util.SparseArray
            r2.<init>()
            r12.f285g = r2
            java.util.HashMap r2 = new java.util.HashMap
            r2.<init>()
            r12.f286h = r2
            android.util.SparseIntArray r2 = new android.util.SparseIntArray
            r2.<init>()
            r12.f287i = r2
            r2 = 400(0x190, float:5.6E-43)
            r12.f288j = r2
            r2 = 0
            r12.f289k = r2
            r12.f291m = r2
            r12.f292n = r2
            r12.f279a = r14
            pa.b r3 = new pa.b
            r3.<init>()
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r3.f24100b = r4
            java.lang.String r4 = "ViewTransitionController"
            r3.f24102d = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r3.f24104f = r4
            r3.f24099a = r14
            r12.f295q = r3
            android.content.res.Resources r14 = r13.getResources()
            android.content.res.XmlResourceParser r14 = r14.getXml(r15)
            int r3 = r14.getEventType()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r4 = r0
        L_0x0062:
            r5 = 1
            if (r3 == r5) goto L_0x01cd
            if (r3 == 0) goto L_0x01bd
            r6 = 2
            if (r3 == r6) goto L_0x006c
            goto L_0x01c0
        L_0x006c:
            java.lang.String r3 = r14.getName()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            int r7 = r3.hashCode()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r8 = 5
            java.lang.String r9 = "MotionScene"
            r10 = 4
            r11 = -1
            switch(r7) {
                case -1349929691: goto L_0x00de;
                case -1239391468: goto L_0x00d3;
                case -687739768: goto L_0x00c9;
                case 61998586: goto L_0x00be;
                case 269306229: goto L_0x00b5;
                case 312750793: goto L_0x00ab;
                case 327855227: goto L_0x00a1;
                case 793277014: goto L_0x0099;
                case 1382829617: goto L_0x008f;
                case 1942574248: goto L_0x007e;
                default: goto L_0x007c;
            }
        L_0x007c:
            goto L_0x00e8
        L_0x007e:
            java.lang.String r5 = "include"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 6
            goto L_0x00e9
        L_0x0089:
            r13 = move-exception
            goto L_0x01c6
        L_0x008c:
            r13 = move-exception
            goto L_0x01ca
        L_0x008f:
            java.lang.String r5 = "StateSet"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 4
            goto L_0x00e9
        L_0x0099:
            boolean r3 = r3.equals(r9)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 0
            goto L_0x00e9
        L_0x00a1:
            java.lang.String r5 = "OnSwipe"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 2
            goto L_0x00e9
        L_0x00ab:
            java.lang.String r5 = "OnClick"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 3
            goto L_0x00e9
        L_0x00b5:
            java.lang.String r6 = "Transition"
            boolean r3 = r3.equals(r6)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            goto L_0x00e9
        L_0x00be:
            java.lang.String r5 = "ViewTransition"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 9
            goto L_0x00e9
        L_0x00c9:
            java.lang.String r5 = "Include"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 7
            goto L_0x00e9
        L_0x00d3:
            java.lang.String r5 = "KeyFrameSet"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 8
            goto L_0x00e9
        L_0x00de:
            java.lang.String r5 = "ConstraintSet"
            boolean r3 = r3.equals(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x00e8
            r5 = 5
            goto L_0x00e9
        L_0x00e8:
            r5 = -1
        L_0x00e9:
            switch(r5) {
                case 0: goto L_0x01b9;
                case 1: goto L_0x018a;
                case 2: goto L_0x014f;
                case 3: goto L_0x0141;
                case 4: goto L_0x0138;
                case 5: goto L_0x0133;
                case 6: goto L_0x012e;
                case 7: goto L_0x012e;
                case 8: goto L_0x0120;
                case 9: goto L_0x00ee;
                default: goto L_0x00ec;
            }     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x00ec:
            goto L_0x01c0
        L_0x00ee:
            a1.d0 r3 = new a1.d0     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.<init>(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            pa.b r5 = r12.f295q     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.Object r6 = r5.f24100b     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.util.ArrayList r6 = (java.util.ArrayList) r6     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.add(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r5.f24101c = r0     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            int r5 = r3.f109b     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r5 != r10) goto L_0x0112
            c1.r r5 = androidx.constraintlayout.widget.ConstraintLayout.getSharedValues()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            int r3 = r3.f128u     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            a1.e0 r6 = new a1.e0     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.<init>()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x010d:
            r5.a(r3, r6)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x0112:
            if (r5 != r8) goto L_0x01c0
            c1.r r5 = androidx.constraintlayout.widget.ConstraintLayout.getSharedValues()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            int r3 = r3.f128u     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            a1.e0 r6 = new a1.e0     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.<init>()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x010d
        L_0x0120:
            a1.g r3 = new a1.g     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.<init>(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r4 == 0) goto L_0x01c0
            java.util.ArrayList r5 = r4.f271k     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r5.add(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x012e:
            r12.k(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x0133:
            r12.i(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x0138:
            c1.u r3 = new c1.u     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.<init>(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r12.f280b = r3     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x0141:
            if (r4 == 0) goto L_0x01c0
            a1.x r3 = new a1.x     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.<init>(r13, r4, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.util.ArrayList r5 = r4.f273m     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r5.add(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x014f:
            if (r4 != 0) goto L_0x017e
            android.content.res.Resources r3 = r13.getResources()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.String r3 = r3.getResourceEntryName(r15)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            int r5 = r14.getLineNumber()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.<init>()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.String r7 = " OnSwipe ("
            r6.append(r7)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.append(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.String r3 = ".xml:"
            r6.append(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r6.append(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.String r3 = ")"
            r6.append(r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            java.lang.String r3 = r6.toString()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            android.util.Log.v(r9, r3)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x017e:
            if (r4 == 0) goto L_0x01c0
            a1.b0 r3 = new a1.b0     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            androidx.constraintlayout.motion.widget.MotionLayout r5 = r12.f279a     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.<init>(r13, r5, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r4.f272l = r3     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x018a:
            a1.y r4 = new a1.y     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r4.<init>(r12, r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r1.add(r4)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            a1.y r3 = r12.f281c     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 != 0) goto L_0x01a5
            boolean r3 = r4.f262b     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 != 0) goto L_0x01a5
            r12.f281c = r4     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            a1.b0 r3 = r4.f272l     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x01a5
            boolean r5 = r12.f294p     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.c(r5)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x01a5:
            boolean r3 = r4.f262b     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 == 0) goto L_0x01c0
            int r3 = r4.f263c     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            if (r3 != r11) goto L_0x01b0
            r12.f283e = r4     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01b5
        L_0x01b0:
            java.util.ArrayList r3 = r12.f284f     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            r3.add(r4)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x01b5:
            r1.remove(r4)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x01b9:
            r12.l(r13, r14)     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x01c0
        L_0x01bd:
            r14.getName()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
        L_0x01c0:
            int r3 = r14.next()     // Catch:{ XmlPullParserException -> 0x008c, IOException -> 0x0089 }
            goto L_0x0062
        L_0x01c6:
            r13.printStackTrace()
            goto L_0x01cd
        L_0x01ca:
            r13.printStackTrace()
        L_0x01cd:
            android.util.SparseArray r13 = r12.f285g
            c1.l r14 = new c1.l
            r14.<init>()
            r15 = 2131362304(0x7f0a0200, float:1.8344385E38)
            r13.put(r15, r14)
            java.util.HashMap r13 = r12.f286h
            java.lang.String r14 = "motion_base"
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)
            r13.put(r14, r15)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.z.<init>(android.content.Context, androidx.constraintlayout.motion.widget.MotionLayout, int):void");
    }

    public final boolean a(int i10, MotionLayout motionLayout) {
        y yVar;
        if (this.f293o != null) {
            return false;
        }
        Iterator it = this.f282d.iterator();
        while (it.hasNext()) {
            y yVar2 = (y) it.next();
            int i11 = yVar2.f274n;
            if (i11 != 0 && ((yVar = this.f281c) != yVar2 || (yVar.f278r & 2) == 0)) {
                int i12 = yVar2.f264d;
                v vVar = v.f238d;
                v vVar2 = v.f237c;
                v vVar3 = v.f236b;
                if (i10 == i12 && (i11 == 4 || i11 == 2)) {
                    motionLayout.setState(vVar);
                    motionLayout.setTransition(yVar2);
                    if (yVar2.f274n == 4) {
                        motionLayout.r(1.0f);
                        motionLayout.A1 = null;
                        motionLayout.setState(vVar3);
                        motionLayout.setState(vVar2);
                    } else {
                        motionLayout.setProgress(1.0f);
                        motionLayout.t(true);
                        motionLayout.setState(vVar3);
                        motionLayout.setState(vVar2);
                        motionLayout.setState(vVar);
                        motionLayout.z();
                    }
                    return true;
                } else if (i10 == yVar2.f263c && (i11 == 3 || i11 == 1)) {
                    motionLayout.setState(vVar);
                    motionLayout.setTransition(yVar2);
                    if (yVar2.f274n == 3) {
                        motionLayout.r(0.0f);
                        motionLayout.setState(vVar3);
                        motionLayout.setState(vVar2);
                    } else {
                        motionLayout.setProgress(0.0f);
                        motionLayout.t(true);
                        motionLayout.setState(vVar3);
                        motionLayout.setState(vVar2);
                        motionLayout.setState(vVar);
                        motionLayout.z();
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public final l b(int i10) {
        int b5;
        u uVar = this.f280b;
        if (!(uVar == null || (b5 = uVar.b(i10)) == -1)) {
            i10 = b5;
        }
        SparseArray sparseArray = this.f285g;
        if (sparseArray.get(i10) == null) {
            Log.e("MotionScene", "Warning could not find ConstraintSet id/" + b0.m(this.f279a.getContext(), i10) + " In MotionScene");
            i10 = sparseArray.keyAt(0);
        }
        return (l) sparseArray.get(i10);
    }

    public final int c() {
        y yVar = this.f281c;
        if (yVar != null) {
            return yVar.f268h;
        }
        return this.f288j;
    }

    public final int d(Context context, String str) {
        int i10;
        if (str.contains("/")) {
            i10 = context.getResources().getIdentifier(str.substring(str.indexOf(47) + 1), "id", context.getPackageName());
        } else {
            i10 = -1;
        }
        if (i10 != -1) {
            return i10;
        }
        if (str.length() > 1) {
            return Integer.parseInt(str.substring(1));
        }
        Log.e("MotionScene", "error in parsing id");
        return i10;
    }

    public final Interpolator e() {
        y yVar = this.f281c;
        int i10 = yVar.f265e;
        if (i10 == -2) {
            return AnimationUtils.loadInterpolator(this.f279a.getContext(), this.f281c.f267g);
        }
        if (i10 == -1) {
            return new m(e.c(yVar.f266f), 1);
        }
        if (i10 == 0) {
            return new AccelerateDecelerateInterpolator();
        }
        if (i10 == 1) {
            return new AccelerateInterpolator();
        }
        if (i10 == 2) {
            return new DecelerateInterpolator();
        }
        if (i10 == 4) {
            return new BounceInterpolator();
        }
        if (i10 == 5) {
            return new OvershootInterpolator();
        }
        if (i10 != 6) {
            return null;
        }
        return new AnticipateInterpolator();
    }

    public final void f(n nVar) {
        y yVar = this.f281c;
        if (yVar == null) {
            y yVar2 = this.f283e;
            if (yVar2 != null) {
                Iterator it = yVar2.f271k.iterator();
                while (it.hasNext()) {
                    ((g) it.next()).a(nVar);
                }
                return;
            }
            return;
        }
        Iterator it2 = yVar.f271k.iterator();
        while (it2.hasNext()) {
            ((g) it2.next()).a(nVar);
        }
    }

    public final float g() {
        b0 b0Var;
        y yVar = this.f281c;
        if (yVar == null || (b0Var = yVar.f272l) == null) {
            return 0.0f;
        }
        return b0Var.f83t;
    }

    public final int h() {
        y yVar = this.f281c;
        if (yVar == null) {
            return -1;
        }
        return yVar.f264d;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int i(android.content.Context r14, android.content.res.XmlResourceParser r15) {
        /*
            r13 = this;
            c1.l r0 = new c1.l
            r0.<init>()
            r1 = 0
            r0.f3890e = r1
            int r2 = r15.getAttributeCount()
            r3 = -1
            r4 = 0
            r5 = -1
            r6 = -1
        L_0x0010:
            if (r4 >= r2) goto L_0x00d9
            java.lang.String r7 = r15.getAttributeName(r4)
            java.lang.String r8 = r15.getAttributeValue(r4)
            r7.getClass()
            int r9 = r7.hashCode()
            r10 = 2
            r11 = 1
            switch(r9) {
                case -1496482599: goto L_0x003e;
                case -1153153640: goto L_0x0033;
                case 3355: goto L_0x0028;
                default: goto L_0x0026;
            }
        L_0x0026:
            r7 = -1
            goto L_0x0048
        L_0x0028:
            java.lang.String r9 = "id"
            boolean r7 = r7.equals(r9)
            if (r7 != 0) goto L_0x0031
            goto L_0x0026
        L_0x0031:
            r7 = 2
            goto L_0x0048
        L_0x0033:
            java.lang.String r9 = "constraintRotate"
            boolean r7 = r7.equals(r9)
            if (r7 != 0) goto L_0x003c
            goto L_0x0026
        L_0x003c:
            r7 = 1
            goto L_0x0048
        L_0x003e:
            java.lang.String r9 = "deriveConstraintsFrom"
            boolean r7 = r7.equals(r9)
            if (r7 != 0) goto L_0x0047
            goto L_0x0026
        L_0x0047:
            r7 = 0
        L_0x0048:
            switch(r7) {
                case 0: goto L_0x00d1;
                case 1: goto L_0x0071;
                case 2: goto L_0x004d;
                default: goto L_0x004b;
            }
        L_0x004b:
            goto L_0x00d5
        L_0x004d:
            int r5 = r13.d(r14, r8)
            r7 = 47
            int r7 = r8.indexOf(r7)
            if (r7 >= 0) goto L_0x005a
            goto L_0x0060
        L_0x005a:
            int r7 = r7 + 1
            java.lang.String r8 = r8.substring(r7)
        L_0x0060:
            java.lang.Integer r7 = java.lang.Integer.valueOf(r5)
            java.util.HashMap r9 = r13.f286h
            r9.put(r8, r7)
            java.lang.String r7 = yg.b0.m(r14, r5)
            r0.f3886a = r7
            goto L_0x00d5
        L_0x0071:
            int r7 = java.lang.Integer.parseInt(r8)     // Catch:{ NumberFormatException -> 0x0079 }
            r0.f3888c = r7     // Catch:{ NumberFormatException -> 0x0079 }
            goto L_0x00d5
        L_0x0079:
            r8.getClass()
            int r7 = r8.hashCode()
            r9 = 3
            r12 = 4
            switch(r7) {
                case -768416914: goto L_0x00b4;
                case 3317767: goto L_0x00a9;
                case 3387192: goto L_0x009e;
                case 108511772: goto L_0x0093;
                case 1954540437: goto L_0x0088;
                default: goto L_0x0086;
            }
        L_0x0086:
            r7 = -1
            goto L_0x00be
        L_0x0088:
            java.lang.String r7 = "x_right"
            boolean r7 = r8.equals(r7)
            if (r7 != 0) goto L_0x0091
            goto L_0x0086
        L_0x0091:
            r7 = 4
            goto L_0x00be
        L_0x0093:
            java.lang.String r7 = "right"
            boolean r7 = r8.equals(r7)
            if (r7 != 0) goto L_0x009c
            goto L_0x0086
        L_0x009c:
            r7 = 3
            goto L_0x00be
        L_0x009e:
            java.lang.String r7 = "none"
            boolean r7 = r8.equals(r7)
            if (r7 != 0) goto L_0x00a7
            goto L_0x0086
        L_0x00a7:
            r7 = 2
            goto L_0x00be
        L_0x00a9:
            java.lang.String r7 = "left"
            boolean r7 = r8.equals(r7)
            if (r7 != 0) goto L_0x00b2
            goto L_0x0086
        L_0x00b2:
            r7 = 1
            goto L_0x00be
        L_0x00b4:
            java.lang.String r7 = "x_left"
            boolean r7 = r8.equals(r7)
            if (r7 != 0) goto L_0x00bd
            goto L_0x0086
        L_0x00bd:
            r7 = 0
        L_0x00be:
            switch(r7) {
                case 0: goto L_0x00ce;
                case 1: goto L_0x00cb;
                case 2: goto L_0x00c8;
                case 3: goto L_0x00c5;
                case 4: goto L_0x00c2;
                default: goto L_0x00c1;
            }
        L_0x00c1:
            goto L_0x00d5
        L_0x00c2:
            r0.f3888c = r9
            goto L_0x00d5
        L_0x00c5:
            r0.f3888c = r11
            goto L_0x00d5
        L_0x00c8:
            r0.f3888c = r1
            goto L_0x00d5
        L_0x00cb:
            r0.f3888c = r10
            goto L_0x00d5
        L_0x00ce:
            r0.f3888c = r12
            goto L_0x00d5
        L_0x00d1:
            int r6 = r13.d(r14, r8)
        L_0x00d5:
            int r4 = r4 + 1
            goto L_0x0010
        L_0x00d9:
            if (r5 == r3) goto L_0x00ee
            androidx.constraintlayout.motion.widget.MotionLayout r1 = r13.f279a
            int r1 = r1.M
            r0.k(r14, r15)
            if (r6 == r3) goto L_0x00e9
            android.util.SparseIntArray r14 = r13.f287i
            r14.put(r5, r6)
        L_0x00e9:
            android.util.SparseArray r14 = r13.f285g
            r14.put(r5, r0)
        L_0x00ee:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.z.i(android.content.Context, android.content.res.XmlResourceParser):int");
    }

    public final int j(Context context, int i10) {
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                String name = xml.getName();
                if (2 == eventType && "ConstraintSet".equals(name)) {
                    return i(context, xml);
                }
            }
            return -1;
        } catch (XmlPullParserException e10) {
            e10.printStackTrace();
            return -1;
        } catch (IOException e11) {
            e11.printStackTrace();
            return -1;
        }
    }

    public final void k(Context context, XmlResourceParser xmlResourceParser) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.D);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 0) {
                j(context, obtainStyledAttributes.getResourceId(index, -1));
            }
        }
        obtainStyledAttributes.recycle();
    }

    public final void l(Context context, XmlResourceParser xmlResourceParser) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.f3919s);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 0) {
                int i11 = obtainStyledAttributes.getInt(index, this.f288j);
                this.f288j = i11;
                if (i11 < 8) {
                    this.f288j = 8;
                }
            } else if (index == 1) {
                this.f289k = obtainStyledAttributes.getInteger(index, 0);
            }
        }
        obtainStyledAttributes.recycle();
    }

    public final void m(int i10, MotionLayout motionLayout) {
        SparseArray sparseArray = this.f285g;
        l lVar = (l) sparseArray.get(i10);
        lVar.f3887b = lVar.f3886a;
        int i11 = this.f287i.get(i10);
        HashMap hashMap = lVar.f3891f;
        if (i11 > 0) {
            m(i11, motionLayout);
            l lVar2 = (l) sparseArray.get(i11);
            if (lVar2 == null) {
                Log.e("MotionScene", "ERROR! invalid deriveConstraintsFrom: @id/" + b0.m(this.f279a.getContext(), i11));
                return;
            }
            lVar.f3887b += "/" + lVar2.f3887b;
            HashMap hashMap2 = lVar2.f3891f;
            for (Integer num : hashMap2.keySet()) {
                int intValue = num.intValue();
                g gVar = (g) hashMap2.get(num);
                if (!hashMap.containsKey(Integer.valueOf(intValue))) {
                    hashMap.put(Integer.valueOf(intValue), new g());
                }
                g gVar2 = (g) hashMap.get(Integer.valueOf(intValue));
                if (gVar2 != null) {
                    h hVar = gVar2.f3802e;
                    if (!hVar.f3809b) {
                        hVar.a(gVar.f3802e);
                    }
                    j jVar = gVar2.f3800c;
                    if (!jVar.f3863a) {
                        j jVar2 = gVar.f3800c;
                        jVar.f3863a = jVar2.f3863a;
                        jVar.f3864b = jVar2.f3864b;
                        jVar.f3866d = jVar2.f3866d;
                        jVar.f3867e = jVar2.f3867e;
                        jVar.f3865c = jVar2.f3865c;
                    }
                    k kVar = gVar2.f3803f;
                    if (!kVar.f3869a) {
                        kVar.a(gVar.f3803f);
                    }
                    i iVar = gVar2.f3801d;
                    if (!iVar.f3850a) {
                        iVar.a(gVar.f3801d);
                    }
                    for (String str : gVar.f3804g.keySet()) {
                        if (!gVar2.f3804g.containsKey(str)) {
                            gVar2.f3804g.put(str, (a) gVar.f3804g.get(str));
                        }
                    }
                }
            }
        } else {
            lVar.f3887b = a4.l.J(new StringBuilder(), lVar.f3887b, "  layout");
            int childCount = motionLayout.getChildCount();
            int i12 = 0;
            while (i12 < childCount) {
                View childAt = motionLayout.getChildAt(i12);
                c cVar = (c) childAt.getLayoutParams();
                int id2 = childAt.getId();
                if (!lVar.f3890e || id2 != -1) {
                    if (!hashMap.containsKey(Integer.valueOf(id2))) {
                        hashMap.put(Integer.valueOf(id2), new g());
                    }
                    g gVar3 = (g) hashMap.get(Integer.valueOf(id2));
                    if (gVar3 != null) {
                        h hVar2 = gVar3.f3802e;
                        if (!hVar2.f3809b) {
                            gVar3.c(id2, cVar);
                            if (childAt instanceof ConstraintHelper) {
                                hVar2.f3826j0 = ((ConstraintHelper) childAt).getReferencedIds();
                                if (childAt instanceof Barrier) {
                                    Barrier barrier = (Barrier) childAt;
                                    hVar2.f3836o0 = barrier.getAllowsGoneWidget();
                                    hVar2.f3820g0 = barrier.getType();
                                    hVar2.f3822h0 = barrier.getMargin();
                                }
                            }
                            hVar2.f3809b = true;
                        }
                        j jVar3 = gVar3.f3800c;
                        if (!jVar3.f3863a) {
                            jVar3.f3864b = childAt.getVisibility();
                            jVar3.f3866d = childAt.getAlpha();
                            jVar3.f3863a = true;
                        }
                        k kVar2 = gVar3.f3803f;
                        if (!kVar2.f3869a) {
                            kVar2.f3869a = true;
                            kVar2.f3870b = childAt.getRotation();
                            kVar2.f3871c = childAt.getRotationX();
                            kVar2.f3872d = childAt.getRotationY();
                            kVar2.f3873e = childAt.getScaleX();
                            kVar2.f3874f = childAt.getScaleY();
                            float pivotX = childAt.getPivotX();
                            float pivotY = childAt.getPivotY();
                            if (!(((double) pivotX) == 0.0d && ((double) pivotY) == 0.0d)) {
                                kVar2.f3875g = pivotX;
                                kVar2.f3876h = pivotY;
                            }
                            kVar2.f3878j = childAt.getTranslationX();
                            kVar2.f3879k = childAt.getTranslationY();
                            kVar2.f3880l = childAt.getTranslationZ();
                            if (kVar2.f3881m) {
                                kVar2.f3882n = childAt.getElevation();
                            }
                        }
                    }
                    i12++;
                } else {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
            }
        }
        for (g gVar4 : hashMap.values()) {
            if (gVar4.f3805h != null) {
                if (gVar4.f3799b != null) {
                    for (Integer intValue2 : hashMap.keySet()) {
                        g i13 = lVar.i(intValue2.intValue());
                        String str2 = i13.f3802e.f3830l0;
                        if (str2 != null && gVar4.f3799b.matches(str2)) {
                            gVar4.f3805h.e(i13);
                            i13.f3804g.putAll((HashMap) gVar4.f3804g.clone());
                        }
                    }
                } else {
                    gVar4.f3805h.e(lVar.i(gVar4.f3798a));
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0013, code lost:
        if (r2 != -1) goto L_0x001a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void n(int r9, int r10) {
        /*
            r8 = this;
            c1.u r0 = r8.f280b
            r1 = -1
            if (r0 == 0) goto L_0x0018
            int r0 = r0.b(r9)
            if (r0 == r1) goto L_0x000c
            goto L_0x000d
        L_0x000c:
            r0 = r9
        L_0x000d:
            c1.u r2 = r8.f280b
            int r2 = r2.b(r10)
            if (r2 == r1) goto L_0x0016
            goto L_0x001a
        L_0x0016:
            r2 = r10
            goto L_0x001a
        L_0x0018:
            r0 = r9
            goto L_0x0016
        L_0x001a:
            a1.y r3 = r8.f281c
            if (r3 == 0) goto L_0x0027
            int r4 = r3.f263c
            if (r4 != r10) goto L_0x0027
            int r3 = r3.f264d
            if (r3 != r9) goto L_0x0027
            return
        L_0x0027:
            java.util.ArrayList r3 = r8.f282d
            java.util.Iterator r4 = r3.iterator()
        L_0x002d:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x0053
            java.lang.Object r5 = r4.next()
            a1.y r5 = (a1.y) r5
            int r6 = r5.f263c
            if (r6 != r2) goto L_0x0041
            int r7 = r5.f264d
            if (r7 == r0) goto L_0x0047
        L_0x0041:
            if (r6 != r10) goto L_0x002d
            int r6 = r5.f264d
            if (r6 != r9) goto L_0x002d
        L_0x0047:
            r8.f281c = r5
            a1.b0 r9 = r5.f272l
            if (r9 == 0) goto L_0x0052
            boolean r10 = r8.f294p
            r9.c(r10)
        L_0x0052:
            return
        L_0x0053:
            a1.y r9 = r8.f283e
            java.util.ArrayList r4 = r8.f284f
            java.util.Iterator r4 = r4.iterator()
        L_0x005b:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x006d
            java.lang.Object r5 = r4.next()
            a1.y r5 = (a1.y) r5
            int r6 = r5.f263c
            if (r6 != r10) goto L_0x005b
            r9 = r5
            goto L_0x005b
        L_0x006d:
            a1.y r10 = new a1.y
            r10.<init>((a1.z) r8, (a1.y) r9)
            r10.f264d = r0
            r10.f263c = r2
            if (r0 == r1) goto L_0x007b
            r3.add(r10)
        L_0x007b:
            r8.f281c = r10
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.z.n(int, int):void");
    }

    public final boolean o() {
        Iterator it = this.f282d.iterator();
        while (it.hasNext()) {
            if (((y) it.next()).f272l != null) {
                return true;
            }
        }
        y yVar = this.f281c;
        if (yVar == null || yVar.f272l == null) {
            return false;
        }
        return true;
    }
}
