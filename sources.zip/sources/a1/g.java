package a1;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.Xml;
import c1.a;
import c1.c;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;

public final class g {

    /* renamed from: b  reason: collision with root package name */
    public static final HashMap f144b;

    /* renamed from: a  reason: collision with root package name */
    public HashMap f145a = new HashMap();

    static {
        HashMap hashMap = new HashMap();
        f144b = hashMap;
        try {
            hashMap.put("KeyAttribute", e.class.getConstructor(new Class[0]));
            hashMap.put("KeyPosition", i.class.getConstructor(new Class[0]));
            hashMap.put("KeyCycle", f.class.getConstructor(new Class[0]));
            hashMap.put("KeyTimeCycle", j.class.getConstructor(new Class[0]));
            hashMap.put("KeyTrigger", k.class.getConstructor(new Class[0]));
        } catch (NoSuchMethodException e10) {
            Log.e("KeyFrames", "unable to load", e10);
        }
    }

    public g(Context context, XmlResourceParser xmlResourceParser) {
        HashMap hashMap;
        Exception e10;
        c cVar;
        try {
            int eventType = xmlResourceParser.getEventType();
            c cVar2 = null;
            while (eventType != 1) {
                if (eventType == 2) {
                    String name = xmlResourceParser.getName();
                    HashMap hashMap2 = f144b;
                    if (hashMap2.containsKey(name)) {
                        try {
                            Constructor constructor = (Constructor) hashMap2.get(name);
                            if (constructor != null) {
                                cVar = (c) constructor.newInstance(new Object[0]);
                                try {
                                    cVar.d(context, Xml.asAttributeSet(xmlResourceParser));
                                    b(cVar);
                                } catch (Exception e11) {
                                    e10 = e11;
                                    Log.e("KeyFrames", "unable to create ", e10);
                                    cVar2 = cVar;
                                    eventType = xmlResourceParser.next();
                                }
                                cVar2 = cVar;
                            } else {
                                throw new NullPointerException("Keymaker for " + name + " not found");
                            }
                        } catch (Exception e12) {
                            c cVar3 = cVar2;
                            e10 = e12;
                            cVar = cVar3;
                            Log.e("KeyFrames", "unable to create ", e10);
                            cVar2 = cVar;
                            eventType = xmlResourceParser.next();
                        }
                    } else {
                        if (name.equalsIgnoreCase("CustomAttribute")) {
                            if (cVar2 != null) {
                                hashMap = cVar2.f93d;
                                if (hashMap == null) {
                                }
                            }
                        } else if (!(!name.equalsIgnoreCase("CustomMethod") || cVar2 == null || (hashMap = cVar2.f93d) == null)) {
                        }
                        a.d(context, xmlResourceParser, hashMap);
                    }
                } else if (eventType == 3) {
                    if ("KeyFrameSet".equals(xmlResourceParser.getName())) {
                        return;
                    }
                }
                eventType = xmlResourceParser.next();
            }
        } catch (XmlPullParserException e13) {
            e13.printStackTrace();
        } catch (IOException e14) {
            e14.printStackTrace();
        }
    }

    public final void a(n nVar) {
        Integer valueOf = Integer.valueOf(nVar.f179c);
        HashMap hashMap = this.f145a;
        ArrayList arrayList = (ArrayList) hashMap.get(valueOf);
        if (arrayList != null) {
            nVar.f199w.addAll(arrayList);
        }
        ArrayList arrayList2 = (ArrayList) hashMap.get(-1);
        if (arrayList2 != null) {
            Iterator it = arrayList2.iterator();
            while (it.hasNext()) {
                c cVar = (c) it.next();
                String str = ((c) nVar.f178b.getLayoutParams()).Y;
                String str2 = cVar.f92c;
                if (!(str2 == null || str == null || !str.matches(str2))) {
                    nVar.a(cVar);
                }
            }
        }
    }

    public final void b(c cVar) {
        Integer valueOf = Integer.valueOf(cVar.f91b);
        HashMap hashMap = this.f145a;
        if (!hashMap.containsKey(valueOf)) {
            hashMap.put(Integer.valueOf(cVar.f91b), new ArrayList());
        }
        ArrayList arrayList = (ArrayList) hashMap.get(Integer.valueOf(cVar.f91b));
        if (arrayList != null) {
            arrayList.add(cVar);
        }
    }
}
