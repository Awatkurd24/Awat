package a1;

public abstract class f extends c {
}
