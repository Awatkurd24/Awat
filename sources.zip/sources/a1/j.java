package a1;

public abstract class j extends c {
}
