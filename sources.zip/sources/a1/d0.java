package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Xml;
import android.view.View;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.c;
import c1.g;
import c1.p;
import yg.b0;

public final class d0 {

    /* renamed from: a  reason: collision with root package name */
    public int f108a;

    /* renamed from: b  reason: collision with root package name */
    public int f109b = -1;

    /* renamed from: c  reason: collision with root package name */
    public boolean f110c = false;

    /* renamed from: d  reason: collision with root package name */
    public int f111d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f112e;

    /* renamed from: f  reason: collision with root package name */
    public final g f113f;

    /* renamed from: g  reason: collision with root package name */
    public final g f114g;

    /* renamed from: h  reason: collision with root package name */
    public int f115h = -1;

    /* renamed from: i  reason: collision with root package name */
    public int f116i = -1;

    /* renamed from: j  reason: collision with root package name */
    public int f117j;

    /* renamed from: k  reason: collision with root package name */
    public String f118k;

    /* renamed from: l  reason: collision with root package name */
    public int f119l = 0;

    /* renamed from: m  reason: collision with root package name */
    public String f120m = null;

    /* renamed from: n  reason: collision with root package name */
    public int f121n = -1;

    /* renamed from: o  reason: collision with root package name */
    public final Context f122o;

    /* renamed from: p  reason: collision with root package name */
    public int f123p = -1;

    /* renamed from: q  reason: collision with root package name */
    public int f124q = -1;

    /* renamed from: r  reason: collision with root package name */
    public int f125r = -1;

    /* renamed from: s  reason: collision with root package name */
    public int f126s = -1;

    /* renamed from: t  reason: collision with root package name */
    public int f127t = -1;

    /* renamed from: u  reason: collision with root package name */
    public int f128u = -1;

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public d0(android.content.Context r10, android.content.res.XmlResourceParser r11) {
        /*
            r9 = this;
            r9.<init>()
            r0 = -1
            r9.f109b = r0
            r1 = 0
            r9.f110c = r1
            r9.f111d = r1
            r9.f115h = r0
            r9.f116i = r0
            r9.f119l = r1
            r2 = 0
            r9.f120m = r2
            r9.f121n = r0
            r9.f123p = r0
            r9.f124q = r0
            r9.f125r = r0
            r9.f126s = r0
            r9.f127t = r0
            r9.f128u = r0
            r9.f122o = r10
            int r2 = r11.getEventType()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
        L_0x0028:
            r3 = 1
            if (r2 == r3) goto L_0x00e9
            r4 = 3
            r5 = 2
            java.lang.String r6 = "ViewTransition"
            if (r2 == r5) goto L_0x0046
            if (r2 == r4) goto L_0x0035
            goto L_0x00dc
        L_0x0035:
            java.lang.String r2 = r11.getName()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            boolean r2 = r6.equals(r2)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r2 == 0) goto L_0x00dc
            return
        L_0x0040:
            r10 = move-exception
            goto L_0x00e2
        L_0x0043:
            r10 = move-exception
            goto L_0x00e6
        L_0x0046:
            java.lang.String r2 = r11.getName()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            int r7 = r2.hashCode()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r8 = 4
            switch(r7) {
                case -1962203927: goto L_0x0079;
                case -1239391468: goto L_0x006f;
                case 61998586: goto L_0x0067;
                case 366511058: goto L_0x005d;
                case 1791837707: goto L_0x0053;
                default: goto L_0x0052;
            }     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
        L_0x0052:
            goto L_0x0083
        L_0x0053:
            java.lang.String r7 = "CustomAttribute"
            boolean r7 = r2.equals(r7)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r7 == 0) goto L_0x0083
            r7 = 3
            goto L_0x0084
        L_0x005d:
            java.lang.String r7 = "CustomMethod"
            boolean r7 = r2.equals(r7)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r7 == 0) goto L_0x0083
            r7 = 4
            goto L_0x0084
        L_0x0067:
            boolean r7 = r2.equals(r6)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r7 == 0) goto L_0x0083
            r7 = 0
            goto L_0x0084
        L_0x006f:
            java.lang.String r7 = "KeyFrameSet"
            boolean r7 = r2.equals(r7)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r7 == 0) goto L_0x0083
            r7 = 1
            goto L_0x0084
        L_0x0079:
            java.lang.String r7 = "ConstraintOverride"
            boolean r7 = r2.equals(r7)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            if (r7 == 0) goto L_0x0083
            r7 = 2
            goto L_0x0084
        L_0x0083:
            r7 = -1
        L_0x0084:
            if (r7 == 0) goto L_0x00d9
            if (r7 == r3) goto L_0x00d1
            if (r7 == r5) goto L_0x00ca
            if (r7 == r4) goto L_0x00c2
            if (r7 == r8) goto L_0x00c2
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r3.<init>()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.String r4 = yg.b0.k()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r3.append(r4)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.String r4 = " unknown tag "
            r3.append(r4)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r3.append(r2)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.String r2 = r3.toString()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            android.util.Log.e(r6, r2)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r2.<init>()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.String r3 = ".xml:"
            r2.append(r3)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            int r3 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r2.append(r3)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.lang.String r2 = r2.toString()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            android.util.Log.e(r6, r2)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            goto L_0x00dc
        L_0x00c2:
            c1.g r2 = r9.f114g     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            java.util.HashMap r2 = r2.f3804g     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            c1.a.d(r10, r11, r2)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            goto L_0x00dc
        L_0x00ca:
            c1.g r2 = c1.l.d(r10, r11)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r9.f114g = r2     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            goto L_0x00dc
        L_0x00d1:
            a1.g r2 = new a1.g     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r2.<init>(r10, r11)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            r9.f113f = r2     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            goto L_0x00dc
        L_0x00d9:
            r9.b(r10, r11)     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
        L_0x00dc:
            int r2 = r11.next()     // Catch:{ XmlPullParserException -> 0x0043, IOException -> 0x0040 }
            goto L_0x0028
        L_0x00e2:
            r10.printStackTrace()
            goto L_0x00e9
        L_0x00e6:
            r10.printStackTrace()
        L_0x00e9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.d0.<init>(android.content.Context, android.content.res.XmlResourceParser):void");
    }

    public final boolean a(View view) {
        boolean z4;
        boolean z10;
        String str;
        if (view == null) {
            return false;
        }
        if (this.f117j == -1 && this.f118k == null) {
            return false;
        }
        int i10 = this.f125r;
        if (i10 != -1 && view.getTag(i10) == null) {
            z4 = false;
        } else {
            z4 = true;
        }
        int i11 = this.f126s;
        if (i11 == -1 || view.getTag(i11) == null) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z4 && z10) {
            if (view.getId() == this.f117j) {
                return true;
            }
            if (this.f118k != null && (view.getLayoutParams() instanceof c) && (str = ((c) view.getLayoutParams()).Y) != null && str.matches(this.f118k)) {
                return true;
            }
        }
        return false;
    }

    public final void b(Context context, XmlResourceParser xmlResourceParser) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), p.C);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 0) {
                this.f108a = obtainStyledAttributes.getResourceId(index, this.f108a);
            } else if (index == 8) {
                if (MotionLayout.K1) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, this.f117j);
                    this.f117j = resourceId;
                    if (resourceId != -1) {
                    }
                } else if (obtainStyledAttributes.peekValue(index).type != 3) {
                    this.f117j = obtainStyledAttributes.getResourceId(index, this.f117j);
                }
                this.f118k = obtainStyledAttributes.getString(index);
            } else if (index == 9) {
                this.f109b = obtainStyledAttributes.getInt(index, this.f109b);
            } else if (index == 12) {
                this.f110c = obtainStyledAttributes.getBoolean(index, this.f110c);
            } else if (index == 10) {
                this.f111d = obtainStyledAttributes.getInt(index, this.f111d);
            } else if (index == 4) {
                this.f115h = obtainStyledAttributes.getInt(index, this.f115h);
            } else if (index == 13) {
                this.f116i = obtainStyledAttributes.getInt(index, this.f116i);
            } else if (index == 14) {
                this.f112e = obtainStyledAttributes.getInt(index, this.f112e);
            } else if (index == 7) {
                int i11 = obtainStyledAttributes.peekValue(index).type;
                if (i11 == 1) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, -1);
                    this.f121n = resourceId2;
                    if (resourceId2 == -1) {
                    }
                } else if (i11 == 3) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f120m = string;
                    if (string == null || string.indexOf("/") <= 0) {
                        this.f119l = -1;
                    } else {
                        this.f121n = obtainStyledAttributes.getResourceId(index, -1);
                    }
                } else {
                    this.f119l = obtainStyledAttributes.getInteger(index, this.f119l);
                }
                this.f119l = -2;
            } else if (index == 11) {
                this.f123p = obtainStyledAttributes.getResourceId(index, this.f123p);
            } else if (index == 3) {
                this.f124q = obtainStyledAttributes.getResourceId(index, this.f124q);
            } else if (index == 6) {
                this.f125r = obtainStyledAttributes.getResourceId(index, this.f125r);
            } else if (index == 5) {
                this.f126s = obtainStyledAttributes.getResourceId(index, this.f126s);
            } else if (index == 2) {
                this.f128u = obtainStyledAttributes.getResourceId(index, this.f128u);
            } else if (index == 1) {
                this.f127t = obtainStyledAttributes.getInteger(index, this.f127t);
            }
        }
        obtainStyledAttributes.recycle();
    }

    public final String toString() {
        return "ViewTransition(" + b0.m(this.f122o, this.f108a) + ")";
    }
}
