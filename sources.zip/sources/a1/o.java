package a1;

import android.view.animation.Interpolator;

public abstract class o implements Interpolator {
    public abstract float a();
}
