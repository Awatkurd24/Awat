package a1;

import android.content.Context;
import android.util.AttributeSet;
import java.util.HashMap;
import java.util.HashSet;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public int f90a = -1;

    /* renamed from: b  reason: collision with root package name */
    public int f91b = -1;

    /* renamed from: c  reason: collision with root package name */
    public String f92c = null;

    /* renamed from: d  reason: collision with root package name */
    public HashMap f93d;

    public static float f(Number number) {
        return number instanceof Float ? ((Float) number).floatValue() : Float.parseFloat(number.toString());
    }

    public abstract void a(HashMap hashMap);

    public abstract c b();

    public abstract void c(HashSet hashSet);

    public abstract void d(Context context, AttributeSet attributeSet);

    public void e(HashMap hashMap) {
    }
}
