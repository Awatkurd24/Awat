package a1;

import c1.q;

public final class e0 implements q {
}
