package a1;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import java.util.HashMap;
import java.util.HashSet;
import v0.e;

public final class i extends c {

    /* renamed from: e  reason: collision with root package name */
    public int f147e = -1;

    /* renamed from: f  reason: collision with root package name */
    public String f148f = null;

    /* renamed from: g  reason: collision with root package name */
    public int f149g = -1;

    /* renamed from: h  reason: collision with root package name */
    public int f150h = 0;

    /* renamed from: i  reason: collision with root package name */
    public float f151i = Float.NaN;

    /* renamed from: j  reason: collision with root package name */
    public float f152j = Float.NaN;

    /* renamed from: k  reason: collision with root package name */
    public float f153k = Float.NaN;

    /* renamed from: l  reason: collision with root package name */
    public float f154l = Float.NaN;

    /* renamed from: m  reason: collision with root package name */
    public float f155m = Float.NaN;

    /* renamed from: n  reason: collision with root package name */
    public float f156n = Float.NaN;

    /* renamed from: o  reason: collision with root package name */
    public int f157o = 0;

    public final void a(HashMap hashMap) {
    }

    /* renamed from: b */
    public final c clone() {
        i iVar = new i();
        iVar.f90a = this.f90a;
        iVar.f91b = this.f91b;
        iVar.f92c = this.f92c;
        iVar.f93d = this.f93d;
        iVar.f148f = this.f148f;
        iVar.f149g = this.f149g;
        iVar.f150h = this.f150h;
        iVar.f151i = this.f151i;
        iVar.f152j = Float.NaN;
        iVar.f153k = this.f153k;
        iVar.f154l = this.f154l;
        iVar.f155m = this.f155m;
        iVar.f156n = this.f156n;
        return iVar;
    }

    public final /* bridge */ /* synthetic */ void c(HashSet hashSet) {
    }

    public final void d(Context context, AttributeSet attributeSet) {
        String str;
        float f10;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3911k);
        SparseIntArray sparseIntArray = h.f146a;
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            SparseIntArray sparseIntArray2 = h.f146a;
            switch (sparseIntArray2.get(index)) {
                case 1:
                    if (MotionLayout.K1) {
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.f91b);
                        this.f91b = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                    } else if (obtainStyledAttributes.peekValue(index).type != 3) {
                        this.f91b = obtainStyledAttributes.getResourceId(index, this.f91b);
                        continue;
                    }
                    this.f92c = obtainStyledAttributes.getString(index);
                    break;
                case 2:
                    this.f90a = obtainStyledAttributes.getInt(index, this.f90a);
                    continue;
                case 3:
                    if (obtainStyledAttributes.peekValue(index).type == 3) {
                        str = obtainStyledAttributes.getString(index);
                    } else {
                        str = e.f27496c[obtainStyledAttributes.getInteger(index, 0)];
                    }
                    this.f148f = str;
                    continue;
                case 4:
                    this.f147e = obtainStyledAttributes.getInteger(index, this.f147e);
                    continue;
                case 5:
                    this.f150h = obtainStyledAttributes.getInt(index, this.f150h);
                    continue;
                case 6:
                    this.f153k = obtainStyledAttributes.getFloat(index, this.f153k);
                    continue;
                case 7:
                    this.f154l = obtainStyledAttributes.getFloat(index, this.f154l);
                    continue;
                case V2rayConfig.DEFAULT_LEVEL /*8*/:
                    f10 = obtainStyledAttributes.getFloat(index, this.f152j);
                    this.f151i = f10;
                    break;
                case 9:
                    this.f157o = obtainStyledAttributes.getInt(index, this.f157o);
                    continue;
                case 10:
                    this.f149g = obtainStyledAttributes.getInt(index, this.f149g);
                    continue;
                case AppConfig.MSG_STATE_RUNNING /*11*/:
                    this.f151i = obtainStyledAttributes.getFloat(index, this.f151i);
                    continue;
                case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                    f10 = obtainStyledAttributes.getFloat(index, this.f152j);
                    break;
                default:
                    Log.e("KeyPosition", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray2.get(index));
                    continue;
            }
            this.f152j = f10;
        }
        if (this.f90a == -1) {
            Log.e("KeyPosition", "no frame position");
        }
    }

    public final void g(String str, Object obj) {
        int i10;
        char c10 = 65535;
        switch (str.hashCode()) {
            case -1812823328:
                if (str.equals("transitionEasing")) {
                    c10 = 0;
                    break;
                }
                break;
            case -1127236479:
                if (str.equals("percentWidth")) {
                    c10 = 1;
                    break;
                }
                break;
            case -1017587252:
                if (str.equals("percentHeight")) {
                    c10 = 2;
                    break;
                }
                break;
            case -827014263:
                if (str.equals("drawPath")) {
                    c10 = 3;
                    break;
                }
                break;
            case -200259324:
                if (str.equals("sizePercent")) {
                    c10 = 4;
                    break;
                }
                break;
            case 428090547:
                if (str.equals("percentX")) {
                    c10 = 5;
                    break;
                }
                break;
            case 428090548:
                if (str.equals("percentY")) {
                    c10 = 6;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                this.f148f = obj.toString();
                return;
            case 1:
                this.f151i = c.f((Number) obj);
                return;
            case 2:
                this.f152j = c.f((Number) obj);
                return;
            case 3:
                Number number = (Number) obj;
                if (number instanceof Integer) {
                    i10 = ((Integer) number).intValue();
                } else {
                    i10 = Integer.parseInt(number.toString());
                }
                this.f150h = i10;
                return;
            case 4:
                float f10 = c.f((Number) obj);
                this.f151i = f10;
                this.f152j = f10;
                return;
            case 5:
                this.f153k = c.f((Number) obj);
                return;
            case 6:
                this.f154l = c.f((Number) obj);
                return;
            default:
                return;
        }
    }
}
