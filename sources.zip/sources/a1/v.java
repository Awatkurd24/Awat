package a1;

public enum v {
}
