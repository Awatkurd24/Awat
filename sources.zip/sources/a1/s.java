package a1;

import android.view.VelocityTracker;

public final class s {

    /* renamed from: b  reason: collision with root package name */
    public static final s f228b = new Object();

    /* renamed from: a  reason: collision with root package name */
    public VelocityTracker f229a;
}
