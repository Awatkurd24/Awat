package a1;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.graphics.Rect;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintHelper;
import c1.g;
import fa.b;
import fa.l;
import fa.s;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import w0.a;
import w0.d;
import w0.e;
import w0.f;
import w0.h;
import w0.i;
import w0.j;
import w0.k;
import w0.m;
import w0.n;
import w0.o;
import yg.b0;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public Object f221a = new HashSet();

    /* renamed from: b  reason: collision with root package name */
    public int f222b;

    /* renamed from: c  reason: collision with root package name */
    public int f223c;

    /* renamed from: d  reason: collision with root package name */
    public Object f224d = null;

    /* renamed from: e  reason: collision with root package name */
    public Object f225e = new HashSet();

    /* renamed from: f  reason: collision with root package name */
    public Object f226f;

    /* renamed from: g  reason: collision with root package name */
    public Object f227g;

    public r(s sVar, s[] sVarArr) {
        int i10 = 0;
        this.f222b = 0;
        this.f223c = 0;
        this.f227g = new HashSet();
        ((Set) this.f225e).add(sVar);
        int length = sVarArr.length;
        while (i10 < length) {
            if (sVarArr[i10] != null) {
                i10++;
            } else {
                throw new NullPointerException("Null interface");
            }
        }
        Collections.addAll((Set) this.f225e, sVarArr);
    }

    public static void e(f fVar, f fVar2) {
        e eVar;
        ArrayList arrayList = fVar.f28646v0;
        HashMap hashMap = new HashMap();
        hashMap.put(fVar, fVar2);
        fVar2.f28646v0.clear();
        fVar2.h(fVar, hashMap);
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            e eVar2 = (e) it.next();
            if (eVar2 instanceof a) {
                eVar = new a();
            } else if (eVar2 instanceof i) {
                eVar = new i();
            } else if (eVar2 instanceof h) {
                eVar = new h();
            } else if (eVar2 instanceof m) {
                eVar = new n();
            } else if (eVar2 instanceof j) {
                eVar = new k();
            } else {
                eVar = new e();
            }
            fVar2.f28646v0.add(eVar);
            e eVar3 = eVar.V;
            if (eVar3 != null) {
                ((o) eVar3).f28646v0.remove(eVar);
                eVar.E();
            }
            eVar.V = fVar2;
            hashMap.put(eVar2, eVar);
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            e eVar4 = (e) it2.next();
            ((e) hashMap.get(eVar4)).h(eVar4, hashMap);
        }
    }

    public static e f(f fVar, View view) {
        if (fVar.f28574h0 == view) {
            return fVar;
        }
        ArrayList arrayList = fVar.f28646v0;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            e eVar = (e) arrayList.get(i10);
            if (eVar.f28574h0 == view) {
                return eVar;
            }
        }
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [a1.r, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v11, types: [java.lang.Object, t7.v] */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x01ff, code lost:
        if (r2.equals("CONSENT_SIGNAL_COLLECT_CONSENT") == false) goto L_0x01aa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0172, code lost:
        if (r2.equals("NOT_REQUIRED") == false) goto L_0x0154;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static a1.r l(android.util.JsonReader r12) {
        /*
            a1.r r0 = new a1.r
            r0.<init>()
            r1 = 1
            r0.f222b = r1
            java.util.List r2 = java.util.Collections.emptyList()
            r0.f226f = r2
            java.util.List r2 = java.util.Collections.emptyList()
            r0.f227g = r2
            r0.f223c = r1
            r12.beginObject()
        L_0x0019:
            boolean r2 = r12.hasNext()
            if (r2 == 0) goto L_0x0223
            java.lang.String r2 = r12.nextName()
            r2.getClass()
            int r3 = r2.hashCode()
            r4 = 3
            r5 = 4
            r6 = 5
            r7 = 6
            r8 = 0
            r9 = -1
            r10 = 2
            switch(r3) {
                case -2001388947: goto L_0x0078;
                case -1938755376: goto L_0x006d;
                case -1851537225: goto L_0x0062;
                case -1324537865: goto L_0x0057;
                case -1161803523: goto L_0x004c;
                case -986806987: goto L_0x0041;
                case -790907624: goto L_0x0036;
                default: goto L_0x0034;
            }
        L_0x0034:
            r2 = -1
            goto L_0x0082
        L_0x0036:
            java.lang.String r3 = "consent_form_payload"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x003f
            goto L_0x0034
        L_0x003f:
            r2 = 6
            goto L_0x0082
        L_0x0041:
            java.lang.String r3 = "request_info_keys"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x004a
            goto L_0x0034
        L_0x004a:
            r2 = 5
            goto L_0x0082
        L_0x004c:
            java.lang.String r3 = "actions"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0055
            goto L_0x0034
        L_0x0055:
            r2 = 4
            goto L_0x0082
        L_0x0057:
            java.lang.String r3 = "privacy_options_required"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0060
            goto L_0x0034
        L_0x0060:
            r2 = 3
            goto L_0x0082
        L_0x0062:
            java.lang.String r3 = "consent_form_base_url"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x006b
            goto L_0x0034
        L_0x006b:
            r2 = 2
            goto L_0x0082
        L_0x006d:
            java.lang.String r3 = "error_message"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0076
            goto L_0x0034
        L_0x0076:
            r2 = 1
            goto L_0x0082
        L_0x0078:
            java.lang.String r3 = "consent_signal"
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0081
            goto L_0x0034
        L_0x0081:
            r2 = 0
        L_0x0082:
            switch(r2) {
                case 0: goto L_0x019b;
                case 1: goto L_0x0193;
                case 2: goto L_0x018b;
                case 3: goto L_0x0146;
                case 4: goto L_0x00b1;
                case 5: goto L_0x0090;
                case 6: goto L_0x0089;
                default: goto L_0x0085;
            }
        L_0x0085:
            r12.skipValue()
            goto L_0x0019
        L_0x0089:
            java.lang.String r2 = r12.nextString()
            r0.f224d = r2
            goto L_0x0019
        L_0x0090:
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            r0.f226f = r2
            r12.beginArray()
        L_0x009a:
            boolean r2 = r12.hasNext()
            if (r2 == 0) goto L_0x00ac
            java.lang.String r2 = r12.nextString()
            java.lang.Object r3 = r0.f226f
            java.util.List r3 = (java.util.List) r3
            r3.add(r2)
            goto L_0x009a
        L_0x00ac:
            r12.endArray()
            goto L_0x0019
        L_0x00b1:
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            r0.f227g = r2
            r12.beginArray()
        L_0x00bb:
            boolean r2 = r12.hasNext()
            if (r2 == 0) goto L_0x00ac
            t7.v r2 = new t7.v
            r2.<init>()
            r2.f26650b = r1
            r12.beginObject()
        L_0x00cb:
            boolean r3 = r12.hasNext()
            if (r3 == 0) goto L_0x013a
            java.lang.String r3 = r12.nextName()
            r3.getClass()
            java.lang.String r5 = "action_type"
            boolean r5 = r3.equals(r5)
            if (r5 != 0) goto L_0x00f3
            java.lang.String r5 = "args_json"
            boolean r3 = r3.equals(r5)
            if (r3 != 0) goto L_0x00ec
            r12.skipValue()
            goto L_0x00cb
        L_0x00ec:
            java.lang.String r3 = r12.nextString()
            r2.f26649a = r3
            goto L_0x00cb
        L_0x00f3:
            java.lang.String r3 = r12.nextString()
            r3.getClass()
            int r5 = r3.hashCode()
            switch(r5) {
                case 64208429: goto L_0x0119;
                case 82862015: goto L_0x010e;
                case 1856333582: goto L_0x0103;
                default: goto L_0x0101;
            }
        L_0x0101:
            r5 = -1
            goto L_0x0123
        L_0x0103:
            java.lang.String r5 = "UNKNOWN_ACTION_TYPE"
            boolean r5 = r3.equals(r5)
            if (r5 != 0) goto L_0x010c
            goto L_0x0101
        L_0x010c:
            r5 = 2
            goto L_0x0123
        L_0x010e:
            java.lang.String r5 = "WRITE"
            boolean r5 = r3.equals(r5)
            if (r5 != 0) goto L_0x0117
            goto L_0x0101
        L_0x0117:
            r5 = 1
            goto L_0x0123
        L_0x0119:
            java.lang.String r5 = "CLEAR"
            boolean r5 = r3.equals(r5)
            if (r5 != 0) goto L_0x0122
            goto L_0x0101
        L_0x0122:
            r5 = 0
        L_0x0123:
            switch(r5) {
                case 0: goto L_0x0136;
                case 1: goto L_0x0134;
                case 2: goto L_0x0132;
                default: goto L_0x0126;
            }
        L_0x0126:
            java.io.IOException r12 = new java.io.IOException
            java.lang.String r0 = "Failed to parse contentads.contributor.direct.serving.appswitchboard.proto.ApplicationGdprResponse.Action.ActionTypefrom: "
            java.lang.String r0 = r0.concat(r3)
            r12.<init>(r0)
            throw r12
        L_0x0132:
            r3 = 1
            goto L_0x0137
        L_0x0134:
            r3 = 2
            goto L_0x0137
        L_0x0136:
            r3 = 3
        L_0x0137:
            r2.f26650b = r3
            goto L_0x00cb
        L_0x013a:
            r12.endObject()
            java.lang.Object r3 = r0.f227g
            java.util.List r3 = (java.util.List) r3
            r3.add(r2)
            goto L_0x00bb
        L_0x0146:
            java.lang.String r2 = r12.nextString()
            r2.getClass()
            int r3 = r2.hashCode()
            switch(r3) {
                case -1888946261: goto L_0x016c;
                case 389487519: goto L_0x0161;
                case 433141802: goto L_0x0156;
                default: goto L_0x0154;
            }
        L_0x0154:
            r8 = -1
            goto L_0x0175
        L_0x0156:
            java.lang.String r3 = "UNKNOWN"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x015f
            goto L_0x0154
        L_0x015f:
            r8 = 2
            goto L_0x0175
        L_0x0161:
            java.lang.String r3 = "REQUIRED"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x016a
            goto L_0x0154
        L_0x016a:
            r8 = 1
            goto L_0x0175
        L_0x016c:
            java.lang.String r3 = "NOT_REQUIRED"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x0175
            goto L_0x0154
        L_0x0175:
            switch(r8) {
                case 0: goto L_0x0187;
                case 1: goto L_0x0186;
                case 2: goto L_0x0184;
                default: goto L_0x0178;
            }
        L_0x0178:
            java.io.IOException r12 = new java.io.IOException
            java.lang.String r0 = "Failed to parse contentads.contributor.direct.serving.appswitchboard.proto.ApplicationGdprResponse.PrivacyOptionsRequirementStatusfrom: "
            java.lang.String r0 = r0.concat(r2)
            r12.<init>(r0)
            throw r12
        L_0x0184:
            r4 = 1
            goto L_0x0187
        L_0x0186:
            r4 = 2
        L_0x0187:
            r0.f223c = r4
            goto L_0x0019
        L_0x018b:
            java.lang.String r2 = r12.nextString()
            r0.f225e = r2
            goto L_0x0019
        L_0x0193:
            java.lang.String r2 = r12.nextString()
            r0.f221a = r2
            goto L_0x0019
        L_0x019b:
            java.lang.String r2 = r12.nextString()
            r2.getClass()
            int r3 = r2.hashCode()
            r11 = 7
            switch(r3) {
                case -2058725357: goto L_0x01f9;
                case -1969035850: goto L_0x01ee;
                case -1263695752: goto L_0x01e3;
                case -954325659: goto L_0x01d8;
                case -918677260: goto L_0x01cd;
                case 429411856: goto L_0x01c2;
                case 467888915: goto L_0x01b7;
                case 1725474845: goto L_0x01ac;
                default: goto L_0x01aa;
            }
        L_0x01aa:
            r8 = -1
            goto L_0x0202
        L_0x01ac:
            java.lang.String r3 = "CONSENT_SIGNAL_NOT_REQUIRED"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01b5
            goto L_0x01aa
        L_0x01b5:
            r8 = 7
            goto L_0x0202
        L_0x01b7:
            java.lang.String r3 = "CONSENT_SIGNAL_PERSONALIZED_ADS"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01c0
            goto L_0x01aa
        L_0x01c0:
            r8 = 6
            goto L_0x0202
        L_0x01c2:
            java.lang.String r3 = "CONSENT_SIGNAL_SUFFICIENT"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01cb
            goto L_0x01aa
        L_0x01cb:
            r8 = 5
            goto L_0x0202
        L_0x01cd:
            java.lang.String r3 = "CONSENT_SIGNAL_PUBLISHER_MISCONFIGURATION"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01d6
            goto L_0x01aa
        L_0x01d6:
            r8 = 4
            goto L_0x0202
        L_0x01d8:
            java.lang.String r3 = "CONSENT_SIGNAL_NON_PERSONALIZED_ADS"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01e1
            goto L_0x01aa
        L_0x01e1:
            r8 = 3
            goto L_0x0202
        L_0x01e3:
            java.lang.String r3 = "CONSENT_SIGNAL_UNKNOWN"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01ec
            goto L_0x01aa
        L_0x01ec:
            r8 = 2
            goto L_0x0202
        L_0x01ee:
            java.lang.String r3 = "CONSENT_SIGNAL_ERROR"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x01f7
            goto L_0x01aa
        L_0x01f7:
            r8 = 1
            goto L_0x0202
        L_0x01f9:
            java.lang.String r3 = "CONSENT_SIGNAL_COLLECT_CONSENT"
            boolean r3 = r2.equals(r3)
            if (r3 != 0) goto L_0x0202
            goto L_0x01aa
        L_0x0202:
            switch(r8) {
                case 0: goto L_0x021e;
                case 1: goto L_0x021c;
                case 2: goto L_0x021a;
                case 3: goto L_0x021f;
                case 4: goto L_0x0217;
                case 5: goto L_0x0215;
                case 6: goto L_0x0213;
                case 7: goto L_0x0211;
                default: goto L_0x0205;
            }
        L_0x0205:
            java.io.IOException r12 = new java.io.IOException
            java.lang.String r0 = "Failed to parse contentads.contributor.direct.serving.appswitchboard.proto.ApplicationGdprResponse.ConsentSignalfrom: "
            java.lang.String r0 = r0.concat(r2)
            r12.<init>(r0)
            throw r12
        L_0x0211:
            r4 = 6
            goto L_0x021f
        L_0x0213:
            r4 = 2
            goto L_0x021f
        L_0x0215:
            r4 = 4
            goto L_0x021f
        L_0x0217:
            r4 = 8
            goto L_0x021f
        L_0x021a:
            r4 = 1
            goto L_0x021f
        L_0x021c:
            r4 = 7
            goto L_0x021f
        L_0x021e:
            r4 = 5
        L_0x021f:
            r0.f222b = r4
            goto L_0x0019
        L_0x0223:
            r12.endObject()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.r.l(android.util.JsonReader):a1.r");
    }

    public final void a(l lVar) {
        if (!((Set) this.f225e).contains(lVar.f18751a)) {
            ((Set) this.f221a).add(lVar);
            return;
        }
        throw new IllegalArgumentException("Components are not allowed to depend on interfaces they themselves provide.");
    }

    public final b b() {
        boolean z4;
        if (((fa.f) this.f226f) != null) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z4) {
            return new b((String) this.f224d, new HashSet((Set) this.f225e), new HashSet((Set) this.f221a), this.f222b, this.f223c, (fa.f) this.f226f, (Set) this.f227g);
        }
        throw new IllegalStateException("Missing required property: factory.");
    }

    public final void c() {
        int i10;
        int[] iArr;
        SparseArray sparseArray;
        Interpolator interpolator;
        int childCount = ((MotionLayout) this.f227g).getChildCount();
        ((MotionLayout) this.f227g).C.clear();
        SparseArray sparseArray2 = new SparseArray();
        int[] iArr2 = new int[childCount];
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = ((MotionLayout) this.f227g).getChildAt(i11);
            n nVar = new n(childAt);
            int id2 = childAt.getId();
            iArr2[i11] = id2;
            sparseArray2.put(id2, nVar);
            ((MotionLayout) this.f227g).C.put(childAt, nVar);
        }
        int i12 = 0;
        while (i12 < childCount) {
            View childAt2 = ((MotionLayout) this.f227g).getChildAt(i12);
            n nVar2 = (n) ((MotionLayout) this.f227g).C.get(childAt2);
            if (nVar2 == null) {
                i10 = childCount;
                sparseArray = sparseArray2;
                iArr = iArr2;
            } else {
                if (((c1.l) this.f221a) != null) {
                    e f10 = f((f) this.f224d, childAt2);
                    if (f10 != null) {
                        Rect q10 = MotionLayout.q((MotionLayout) this.f227g, f10);
                        c1.l lVar = (c1.l) this.f221a;
                        int width = ((MotionLayout) this.f227g).getWidth();
                        int height = ((MotionLayout) this.f227g).getHeight();
                        int i13 = lVar.f3888c;
                        sparseArray = sparseArray2;
                        if (i13 != 0) {
                            n.g(q10, nVar2.f177a, i13, width, height);
                        }
                        w wVar = nVar2.f182f;
                        wVar.f243c = 0.0f;
                        wVar.f244d = 0.0f;
                        nVar2.f(wVar);
                        iArr = iArr2;
                        i10 = childCount;
                        wVar.f((float) q10.left, (float) q10.top, (float) q10.width(), (float) q10.height());
                        g h10 = lVar.h(nVar2.f179c);
                        wVar.a(h10);
                        c1.i iVar = h10.f3801d;
                        nVar2.f188l = iVar.f3856g;
                        nVar2.f184h.c(q10, lVar, i13, nVar2.f179c);
                        nVar2.B = h10.f3803f.f3877i;
                        nVar2.D = iVar.f3859j;
                        nVar2.E = iVar.f3858i;
                        Context context = nVar2.f178b.getContext();
                        int i14 = iVar.f3861l;
                        String str = iVar.f3860k;
                        int i15 = iVar.f3862m;
                        if (i14 == -2) {
                            interpolator = AnimationUtils.loadInterpolator(context, i15);
                        } else if (i14 == -1) {
                            interpolator = new m(v0.e.c(str));
                        } else if (i14 == 0) {
                            interpolator = new AccelerateDecelerateInterpolator();
                        } else if (i14 == 1) {
                            interpolator = new AccelerateInterpolator();
                        } else if (i14 == 2) {
                            interpolator = new DecelerateInterpolator();
                        } else if (i14 == 4) {
                            interpolator = new BounceInterpolator();
                        } else if (i14 != 5) {
                            interpolator = null;
                        } else {
                            interpolator = new OvershootInterpolator();
                        }
                        nVar2.F = interpolator;
                    } else {
                        i10 = childCount;
                        sparseArray = sparseArray2;
                        iArr = iArr2;
                        if (((MotionLayout) this.f227g).M != 0) {
                            Log.e("MotionLayout", b0.l() + "no widget for  " + b0.n(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                } else {
                    i10 = childCount;
                    sparseArray = sparseArray2;
                    iArr = iArr2;
                    ((MotionLayout) this.f227g).getClass();
                }
                if (((c1.l) this.f226f) != null) {
                    e f11 = f((f) this.f225e, childAt2);
                    if (f11 != null) {
                        Rect q11 = MotionLayout.q((MotionLayout) this.f227g, f11);
                        c1.l lVar2 = (c1.l) this.f226f;
                        int width2 = ((MotionLayout) this.f227g).getWidth();
                        int height2 = ((MotionLayout) this.f227g).getHeight();
                        int i16 = lVar2.f3888c;
                        if (i16 != 0) {
                            n.g(q11, nVar2.f177a, i16, width2, height2);
                            q11 = nVar2.f177a;
                        }
                        w wVar2 = nVar2.f183g;
                        wVar2.f243c = 1.0f;
                        wVar2.f244d = 1.0f;
                        nVar2.f(wVar2);
                        wVar2.f((float) q11.left, (float) q11.top, (float) q11.width(), (float) q11.height());
                        wVar2.a(lVar2.h(nVar2.f179c));
                        nVar2.f185i.c(q11, lVar2, i16, nVar2.f179c);
                    } else if (((MotionLayout) this.f227g).M != 0) {
                        Log.e("MotionLayout", b0.l() + "no widget for  " + b0.n(childAt2) + " (" + childAt2.getClass().getName() + ")");
                    }
                }
            }
            i12++;
            sparseArray2 = sparseArray;
            iArr2 = iArr;
            childCount = i10;
        }
        SparseArray sparseArray3 = sparseArray2;
        int[] iArr3 = iArr2;
        int i17 = 0;
        while (i17 < childCount) {
            SparseArray sparseArray4 = sparseArray3;
            n nVar3 = (n) sparseArray4.get(iArr3[i17]);
            int i18 = nVar3.f182f.f251k;
            if (i18 != -1) {
                n nVar4 = (n) sparseArray4.get(i18);
                nVar3.f182f.h(nVar4, nVar4.f182f);
                nVar3.f183g.h(nVar4, nVar4.f183g);
            }
            i17++;
            sparseArray3 = sparseArray4;
        }
    }

    public final void d(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int optimizationLevel = ((MotionLayout) this.f227g).getOptimizationLevel();
        Object obj = this.f227g;
        if (((MotionLayout) obj).f1698x == ((MotionLayout) obj).getStartState()) {
            MotionLayout motionLayout = (MotionLayout) this.f227g;
            f fVar = (f) this.f225e;
            Object obj2 = this.f226f;
            if (((c1.l) obj2) == null || ((c1.l) obj2).f3888c == 0) {
                i15 = i10;
            } else {
                i15 = i11;
            }
            if (((c1.l) obj2) == null || ((c1.l) obj2).f3888c == 0) {
                i16 = i11;
            } else {
                i16 = i10;
            }
            motionLayout.n(fVar, optimizationLevel, i15, i16);
            Object obj3 = this.f221a;
            if (((c1.l) obj3) != null) {
                MotionLayout motionLayout2 = (MotionLayout) this.f227g;
                f fVar2 = (f) this.f224d;
                if (((c1.l) obj3).f3888c == 0) {
                    i17 = i10;
                } else {
                    i17 = i11;
                }
                if (((c1.l) obj3).f3888c == 0) {
                    i10 = i11;
                }
                motionLayout2.n(fVar2, optimizationLevel, i17, i10);
                return;
            }
            return;
        }
        Object obj4 = this.f221a;
        if (((c1.l) obj4) != null) {
            MotionLayout motionLayout3 = (MotionLayout) this.f227g;
            f fVar3 = (f) this.f224d;
            if (((c1.l) obj4).f3888c == 0) {
                i13 = i10;
            } else {
                i13 = i11;
            }
            if (((c1.l) obj4).f3888c == 0) {
                i14 = i11;
            } else {
                i14 = i10;
            }
            motionLayout3.n(fVar3, optimizationLevel, i13, i14);
        }
        MotionLayout motionLayout4 = (MotionLayout) this.f227g;
        f fVar4 = (f) this.f225e;
        Object obj5 = this.f226f;
        if (((c1.l) obj5) == null || ((c1.l) obj5).f3888c == 0) {
            i12 = i10;
        } else {
            i12 = i11;
        }
        if (((c1.l) obj5) == null || ((c1.l) obj5).f3888c == 0) {
            i10 = i11;
        }
        motionLayout4.n(fVar4, optimizationLevel, i12, i10);
    }

    public final void g(c1.l lVar, c1.l lVar2) {
        this.f221a = lVar;
        this.f226f = lVar2;
        this.f224d = new f();
        f fVar = new f();
        this.f225e = fVar;
        Object obj = this.f224d;
        f fVar2 = (f) obj;
        Object obj2 = this.f227g;
        boolean z4 = MotionLayout.K1;
        x0.n nVar = ((MotionLayout) obj2).f1800c.f28609z0;
        fVar2.f28609z0 = nVar;
        fVar2.f28607x0.f29519h = nVar;
        x0.n nVar2 = ((MotionLayout) obj2).f1800c.f28609z0;
        fVar.f28609z0 = nVar2;
        fVar.f28607x0.f29519h = nVar2;
        ((f) obj).f28646v0.clear();
        ((f) this.f225e).f28646v0.clear();
        e(((MotionLayout) this.f227g).f1800c, (f) this.f224d);
        e(((MotionLayout) this.f227g).f1800c, (f) this.f225e);
        if (((double) ((MotionLayout) this.f227g).G) > 0.5d) {
            if (lVar != null) {
                k((f) this.f224d, lVar);
            }
            k((f) this.f225e, lVar2);
        } else {
            k((f) this.f225e, lVar2);
            if (lVar != null) {
                k((f) this.f224d, lVar);
            }
        }
        ((f) this.f224d).A0 = ((MotionLayout) this.f227g).k();
        f fVar3 = (f) this.f224d;
        fVar3.f28606w0.R(fVar3);
        ((f) this.f225e).A0 = ((MotionLayout) this.f227g).k();
        f fVar4 = (f) this.f225e;
        fVar4.f28606w0.R(fVar4);
        ViewGroup.LayoutParams layoutParams = ((MotionLayout) this.f227g).getLayoutParams();
        if (layoutParams != null) {
            int i10 = layoutParams.width;
            d dVar = d.f28555b;
            if (i10 == -2) {
                ((f) this.f224d).O(dVar);
                ((f) this.f225e).O(dVar);
            }
            if (layoutParams.height == -2) {
                ((f) this.f224d).P(dVar);
                ((f) this.f225e).P(dVar);
            }
        }
    }

    public final void h(Context context, XmlResourceParser xmlResourceParser) {
        int i10;
        c1.l lVar = new c1.l();
        int attributeCount = xmlResourceParser.getAttributeCount();
        int i11 = 0;
        while (i11 < attributeCount) {
            String attributeName = xmlResourceParser.getAttributeName(i11);
            String attributeValue = xmlResourceParser.getAttributeValue(i11);
            if (attributeName == null || attributeValue == null || !"id".equals(attributeName)) {
                i11++;
            } else {
                if (attributeValue.contains("/")) {
                    i10 = context.getResources().getIdentifier(attributeValue.substring(attributeValue.indexOf(47) + 1), "id", context.getPackageName());
                } else {
                    i10 = -1;
                }
                if (i10 == -1) {
                    if (attributeValue.length() > 1) {
                        i10 = Integer.parseInt(attributeValue.substring(1));
                    } else {
                        Log.e("ConstraintLayoutStates", "error in parsing id");
                    }
                }
                lVar.k(context, xmlResourceParser);
                ((SparseArray) this.f226f).put(i10, lVar);
                return;
            }
        }
    }

    public final void i() {
        boolean z4;
        boolean z10;
        HashMap hashMap;
        int i10;
        float f10;
        float f11;
        float f12;
        float f13;
        boolean z11;
        MotionLayout motionLayout = (MotionLayout) this.f227g;
        int i11 = motionLayout.f1702z;
        int i12 = motionLayout.A;
        int mode = View.MeasureSpec.getMode(i11);
        int mode2 = View.MeasureSpec.getMode(i12);
        MotionLayout motionLayout2 = (MotionLayout) this.f227g;
        motionLayout2.f1693u1 = mode;
        motionLayout2.f1695v1 = mode2;
        motionLayout2.getOptimizationLevel();
        d(i11, i12);
        boolean z12 = true;
        int i13 = 0;
        if (!((((MotionLayout) this.f227g).getParent() instanceof MotionLayout) && mode == 1073741824 && mode2 == 1073741824)) {
            d(i11, i12);
            ((MotionLayout) this.f227g).f1686q1 = ((f) this.f224d).s();
            ((MotionLayout) this.f227g).f1687r1 = ((f) this.f224d).m();
            ((MotionLayout) this.f227g).f1689s1 = ((f) this.f225e).s();
            ((MotionLayout) this.f227g).f1691t1 = ((f) this.f225e).m();
            MotionLayout motionLayout3 = (MotionLayout) this.f227g;
            if (motionLayout3.f1686q1 == motionLayout3.f1689s1 && motionLayout3.f1687r1 == motionLayout3.f1691t1) {
                z11 = false;
            } else {
                z11 = true;
            }
            motionLayout3.f1685p1 = z11;
        }
        MotionLayout motionLayout4 = (MotionLayout) this.f227g;
        int i14 = motionLayout4.f1686q1;
        int i15 = motionLayout4.f1687r1;
        int i16 = motionLayout4.f1693u1;
        if (i16 == Integer.MIN_VALUE || i16 == 0) {
            i14 = (int) ((motionLayout4.f1697w1 * ((float) (motionLayout4.f1689s1 - i14))) + ((float) i14));
        }
        int i17 = motionLayout4.f1695v1;
        if (i17 == Integer.MIN_VALUE || i17 == 0) {
            i15 = (int) ((motionLayout4.f1697w1 * ((float) (motionLayout4.f1691t1 - i15))) + ((float) i15));
        }
        int i18 = i15;
        f fVar = (f) this.f224d;
        if (fVar.J0 || ((f) this.f225e).J0) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (fVar.K0 || ((f) this.f225e).K0) {
            z10 = true;
        } else {
            z10 = false;
        }
        motionLayout4.m(i11, i12, i14, i18, z4, z10);
        MotionLayout motionLayout5 = (MotionLayout) this.f227g;
        int childCount = motionLayout5.getChildCount();
        motionLayout5.E1.c();
        motionLayout5.K = true;
        SparseArray sparseArray = new SparseArray();
        int i19 = 0;
        while (true) {
            hashMap = motionLayout5.C;
            if (i19 >= childCount) {
                break;
            }
            View childAt = motionLayout5.getChildAt(i19);
            sparseArray.put(childAt.getId(), (n) hashMap.get(childAt));
            i19++;
        }
        int width = motionLayout5.getWidth();
        int height = motionLayout5.getHeight();
        y yVar = motionLayout5.f1688s.f281c;
        if (yVar != null) {
            i10 = yVar.f276p;
        } else {
            i10 = -1;
        }
        if (i10 != -1) {
            for (int i20 = 0; i20 < childCount; i20++) {
                n nVar = (n) hashMap.get(motionLayout5.getChildAt(i20));
                if (nVar != null) {
                    nVar.A = i10;
                }
            }
        }
        SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
        int[] iArr = new int[hashMap.size()];
        int i21 = 0;
        for (int i22 = 0; i22 < childCount; i22++) {
            n nVar2 = (n) hashMap.get(motionLayout5.getChildAt(i22));
            int i23 = nVar2.f182f.f251k;
            if (i23 != -1) {
                sparseBooleanArray.put(i23, true);
                iArr[i21] = nVar2.f182f.f251k;
                i21++;
            }
        }
        if (motionLayout5.f1677i1 != null) {
            for (int i24 = 0; i24 < i21; i24++) {
                n nVar3 = (n) hashMap.get(motionLayout5.findViewById(iArr[i24]));
                if (nVar3 != null) {
                    motionLayout5.f1688s.f(nVar3);
                }
            }
            Iterator it = motionLayout5.f1677i1.iterator();
            while (it.hasNext()) {
                ((MotionHelper) it.next()).s(motionLayout5, hashMap);
            }
            for (int i25 = 0; i25 < i21; i25++) {
                n nVar4 = (n) hashMap.get(motionLayout5.findViewById(iArr[i25]));
                if (nVar4 != null) {
                    nVar4.h(width, height, motionLayout5.getNanoTime());
                }
            }
        } else {
            for (int i26 = 0; i26 < i21; i26++) {
                n nVar5 = (n) hashMap.get(motionLayout5.findViewById(iArr[i26]));
                if (nVar5 != null) {
                    motionLayout5.f1688s.f(nVar5);
                    nVar5.h(width, height, motionLayout5.getNanoTime());
                }
            }
        }
        for (int i27 = 0; i27 < childCount; i27++) {
            View childAt2 = motionLayout5.getChildAt(i27);
            n nVar6 = (n) hashMap.get(childAt2);
            if (!sparseBooleanArray.get(childAt2.getId()) && nVar6 != null) {
                motionLayout5.f1688s.f(nVar6);
                nVar6.h(width, height, motionLayout5.getNanoTime());
            }
        }
        y yVar2 = motionLayout5.f1688s.f281c;
        if (yVar2 != null) {
            f10 = yVar2.f269i;
        } else {
            f10 = 0.0f;
        }
        if (f10 != 0.0f) {
            if (((double) f10) >= 0.0d) {
                z12 = false;
            }
            float abs = Math.abs(f10);
            float f14 = -3.4028235E38f;
            float f15 = Float.MAX_VALUE;
            float f16 = Float.MAX_VALUE;
            float f17 = -3.4028235E38f;
            for (int i28 = 0; i28 < childCount; i28++) {
                n nVar7 = (n) hashMap.get(motionLayout5.getChildAt(i28));
                if (!Float.isNaN(nVar7.f188l)) {
                    for (int i29 = 0; i29 < childCount; i29++) {
                        n nVar8 = (n) hashMap.get(motionLayout5.getChildAt(i29));
                        if (!Float.isNaN(nVar8.f188l)) {
                            f15 = Math.min(f15, nVar8.f188l);
                            f14 = Math.max(f14, nVar8.f188l);
                        }
                    }
                    while (i13 < childCount) {
                        n nVar9 = (n) hashMap.get(motionLayout5.getChildAt(i13));
                        if (!Float.isNaN(nVar9.f188l)) {
                            nVar9.f190n = 1.0f / (1.0f - abs);
                            float f18 = nVar9.f188l;
                            if (z12) {
                                f12 = ((f14 - f18) / (f14 - f15)) * abs;
                            } else {
                                f12 = ((f18 - f15) * abs) / (f14 - f15);
                            }
                            nVar9.f189m = abs - f12;
                        }
                        i13++;
                    }
                    return;
                }
                w wVar = nVar7.f183g;
                float f19 = wVar.f245e;
                float f20 = wVar.f246f;
                if (z12) {
                    f13 = f20 - f19;
                } else {
                    f13 = f20 + f19;
                }
                f16 = Math.min(f16, f13);
                f17 = Math.max(f17, f13);
            }
            while (i13 < childCount) {
                n nVar10 = (n) hashMap.get(motionLayout5.getChildAt(i13));
                w wVar2 = nVar10.f183g;
                float f21 = wVar2.f245e;
                float f22 = wVar2.f246f;
                if (z12) {
                    f11 = f22 - f21;
                } else {
                    f11 = f22 + f21;
                }
                nVar10.f190n = 1.0f / (1.0f - abs);
                nVar10.f189m = abs - (((f11 - f16) * abs) / (f17 - f16));
                i13++;
            }
        }
    }

    public final void j(int i10) {
        boolean z4;
        if (this.f222b == 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z4) {
            this.f222b = i10;
            return;
        }
        throw new IllegalStateException("Instantiation type has already been set.");
    }

    public final void k(f fVar, c1.l lVar) {
        int i10;
        g gVar;
        g gVar2;
        SparseArray sparseArray = new SparseArray();
        c1.m mVar = new c1.m();
        sparseArray.clear();
        sparseArray.put(0, fVar);
        sparseArray.put(((MotionLayout) this.f227g).getId(), fVar);
        if (!(lVar == null || lVar.f3888c == 0)) {
            MotionLayout motionLayout = (MotionLayout) this.f227g;
            int optimizationLevel = motionLayout.getOptimizationLevel();
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(((MotionLayout) this.f227g).getHeight(), 1073741824);
            int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(((MotionLayout) this.f227g).getWidth(), 1073741824);
            boolean z4 = MotionLayout.K1;
            motionLayout.n((f) this.f225e, optimizationLevel, makeMeasureSpec, makeMeasureSpec2);
        }
        Iterator it = fVar.f28646v0.iterator();
        while (it.hasNext()) {
            e eVar = (e) it.next();
            eVar.f28578j0 = true;
            sparseArray.put(((View) eVar.f28574h0).getId(), eVar);
        }
        Iterator it2 = fVar.f28646v0.iterator();
        while (it2.hasNext()) {
            e eVar2 = (e) it2.next();
            View view = (View) eVar2.f28574h0;
            int id2 = view.getId();
            HashMap hashMap = lVar.f3891f;
            if (hashMap.containsKey(Integer.valueOf(id2)) && (gVar2 = (g) hashMap.get(Integer.valueOf(id2))) != null) {
                gVar2.a(mVar);
            }
            eVar2.Q(lVar.h(view.getId()).f3802e.f3811c);
            eVar2.N(lVar.h(view.getId()).f3802e.f3813d);
            if (view instanceof ConstraintHelper) {
                ConstraintHelper constraintHelper = (ConstraintHelper) view;
                int id3 = constraintHelper.getId();
                HashMap hashMap2 = lVar.f3891f;
                if (hashMap2.containsKey(Integer.valueOf(id3)) && (gVar = (g) hashMap2.get(Integer.valueOf(id3))) != null && (eVar2 instanceof k)) {
                    constraintHelper.m(gVar, (k) eVar2, mVar, sparseArray);
                }
                if (view instanceof Barrier) {
                    ((Barrier) view).r();
                }
            }
            mVar.resolveLayoutDirection(((MotionLayout) this.f227g).getLayoutDirection());
            boolean z10 = MotionLayout.K1;
            ((MotionLayout) this.f227g).g(false, view, eVar2, mVar, sparseArray);
            if (lVar.h(view.getId()).f3800c.f3865c == 1) {
                i10 = view.getVisibility();
            } else {
                i10 = lVar.h(view.getId()).f3800c.f3864b;
            }
            eVar2.f28576i0 = i10;
        }
        Iterator it3 = fVar.f28646v0.iterator();
        while (it3.hasNext()) {
            e eVar3 = (e) it3.next();
            if (eVar3 instanceof n) {
                j jVar = (j) eVar3;
                ((ConstraintHelper) eVar3.f28574h0).q(jVar, sparseArray);
                n nVar = (n) jVar;
                for (int i11 = 0; i11 < nVar.f28641w0; i11++) {
                    e eVar4 = nVar.f28640v0[i11];
                    if (eVar4 != null) {
                        eVar4.G = true;
                    }
                }
            }
        }
    }

    public r(Class cls, Class[] clsArr) {
        int i10 = 0;
        this.f222b = 0;
        this.f223c = 0;
        this.f227g = new HashSet();
        ((Set) this.f225e).add(s.a(cls));
        int length = clsArr.length;
        while (i10 < length) {
            Class cls2 = clsArr[i10];
            if (cls2 != null) {
                ((Set) this.f225e).add(s.a(cls2));
                i10++;
            } else {
                throw new NullPointerException("Null interface");
            }
        }
    }
}
