package a1;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.utils.widget.MotionLabel;
import c1.a;
import c1.c;
import h.n0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import ne.c0;
import v0.b;
import v0.e;
import v7.d9;
import z0.d;
import z0.f;
import z0.i;
import z0.k;
import z0.p;

public final class n {
    public int A = -1;
    public int B = -1;
    public View C = null;
    public int D = -1;
    public float E = Float.NaN;
    public Interpolator F = null;
    public boolean G = false;

    /* renamed from: a  reason: collision with root package name */
    public final Rect f177a = new Rect();

    /* renamed from: b  reason: collision with root package name */
    public final View f178b;

    /* renamed from: c  reason: collision with root package name */
    public final int f179c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f180d = false;

    /* renamed from: e  reason: collision with root package name */
    public int f181e = -1;

    /* renamed from: f  reason: collision with root package name */
    public final w f182f = new w();

    /* renamed from: g  reason: collision with root package name */
    public final w f183g = new w();

    /* renamed from: h  reason: collision with root package name */
    public final l f184h = new l();

    /* renamed from: i  reason: collision with root package name */
    public final l f185i = new l();

    /* renamed from: j  reason: collision with root package name */
    public d9[] f186j;

    /* renamed from: k  reason: collision with root package name */
    public b f187k;

    /* renamed from: l  reason: collision with root package name */
    public float f188l = Float.NaN;

    /* renamed from: m  reason: collision with root package name */
    public float f189m = 0.0f;

    /* renamed from: n  reason: collision with root package name */
    public float f190n = 1.0f;

    /* renamed from: o  reason: collision with root package name */
    public int[] f191o;

    /* renamed from: p  reason: collision with root package name */
    public double[] f192p;

    /* renamed from: q  reason: collision with root package name */
    public double[] f193q;

    /* renamed from: r  reason: collision with root package name */
    public String[] f194r;

    /* renamed from: s  reason: collision with root package name */
    public int[] f195s;

    /* renamed from: t  reason: collision with root package name */
    public final float[] f196t = new float[4];

    /* renamed from: u  reason: collision with root package name */
    public final ArrayList f197u = new ArrayList();

    /* renamed from: v  reason: collision with root package name */
    public final float[] f198v = new float[1];

    /* renamed from: w  reason: collision with root package name */
    public final ArrayList f199w = new ArrayList();

    /* renamed from: x  reason: collision with root package name */
    public HashMap f200x;

    /* renamed from: y  reason: collision with root package name */
    public HashMap f201y;

    /* renamed from: z  reason: collision with root package name */
    public HashMap f202z;

    public n(View view) {
        this.f178b = view;
        this.f179c = view.getId();
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof c) {
            ((c) layoutParams).getClass();
        }
    }

    public static void g(Rect rect, Rect rect2, int i10, int i11, int i12) {
        int i13;
        int width;
        int i14;
        int i15;
        int i16;
        if (i10 != 1) {
            if (i10 == 2) {
                i14 = rect.left + rect.right;
                i15 = rect.top;
                i16 = rect.bottom;
            } else if (i10 == 3) {
                i13 = rect.left + rect.right;
                width = ((rect.height() / 2) + rect.top) - (i13 / 2);
                rect2.left = width;
                rect2.top = i12 - ((rect.height() + i13) / 2);
            } else if (i10 == 4) {
                i14 = rect.left + rect.right;
                i15 = rect.bottom;
                i16 = rect.top;
            } else {
                return;
            }
            rect2.left = i11 - ((rect.width() + (i15 + i16)) / 2);
            rect2.top = (i14 - rect.height()) / 2;
        } else {
            i13 = rect.left + rect.right;
            width = ((rect.top + rect.bottom) - rect.width()) / 2;
            rect2.left = width;
            rect2.top = i12 - ((rect.height() + i13) / 2);
        }
        rect2.right = rect.width() + rect2.left;
        rect2.bottom = rect.height() + rect2.top;
    }

    public final void a(c cVar) {
        this.f199w.add(cVar);
    }

    public final float b(float f10, float[] fArr) {
        float f11 = 0.0f;
        float f12 = 1.0f;
        if (fArr != null) {
            fArr[0] = 1.0f;
        } else {
            float f13 = this.f190n;
            if (((double) f13) != 1.0d) {
                float f14 = this.f189m;
                if (f10 < f14) {
                    f10 = 0.0f;
                }
                if (f10 > f14 && ((double) f10) < 1.0d) {
                    f10 = Math.min((f10 - f14) * f13, 1.0f);
                }
            }
        }
        e eVar = this.f182f.f241a;
        Iterator it = this.f197u.iterator();
        float f15 = Float.NaN;
        while (it.hasNext()) {
            w wVar = (w) it.next();
            e eVar2 = wVar.f241a;
            if (eVar2 != null) {
                float f16 = wVar.f243c;
                if (f16 < f10) {
                    eVar = eVar2;
                    f11 = f16;
                } else if (Float.isNaN(f15)) {
                    f15 = wVar.f243c;
                }
            }
        }
        if (eVar != null) {
            if (!Float.isNaN(f15)) {
                f12 = f15;
            }
            float f17 = f12 - f11;
            double d10 = (double) ((f10 - f11) / f17);
            f10 = (((float) eVar.a(d10)) * f17) + f11;
            if (fArr != null) {
                fArr[0] = (float) eVar.b(d10);
            }
        }
        return f10;
    }

    public final void c(double d10, float[] fArr, float[] fArr2) {
        double d11 = d10;
        double[] dArr = new double[4];
        double[] dArr2 = new double[4];
        this.f186j[0].c(d11, dArr);
        this.f186j[0].f(d11, dArr2);
        float f10 = 0.0f;
        Arrays.fill(fArr2, 0.0f);
        int[] iArr = this.f191o;
        w wVar = this.f182f;
        float f11 = wVar.f245e;
        float f12 = wVar.f246f;
        float f13 = wVar.f247g;
        float f14 = wVar.f248h;
        float f15 = 0.0f;
        int i10 = 0;
        float f16 = 0.0f;
        float f17 = 0.0f;
        while (i10 < iArr.length) {
            float f18 = (float) dArr[i10];
            float f19 = (float) dArr2[i10];
            int i11 = iArr[i10];
            if (i11 == 1) {
                f11 = f18;
                f10 = f19;
            } else if (i11 == 2) {
                f12 = f18;
                f15 = f19;
            } else if (i11 == 3) {
                f13 = f18;
                f16 = f19;
            } else if (i11 == 4) {
                f14 = f18;
                f17 = f19;
            }
            i10++;
            double d12 = d10;
            float[] fArr3 = fArr2;
        }
        float f20 = 2.0f;
        float f21 = (f16 / 2.0f) + f10;
        float f22 = (f17 / 2.0f) + f15;
        n nVar = wVar.f253m;
        if (nVar != null) {
            float[] fArr4 = new float[2];
            float[] fArr5 = new float[2];
            nVar.c(d10, fArr4, fArr5);
            float f23 = fArr4[0];
            float f24 = fArr4[1];
            float f25 = fArr5[0];
            float f26 = fArr5[1];
            double d13 = (double) f11;
            double d14 = (double) f12;
            float sin = (float) (((Math.sin(d14) * d13) + ((double) f23)) - ((double) (f13 / 2.0f)));
            double d15 = (double) f25;
            double d16 = (double) f10;
            double sin2 = (Math.sin(d14) * d16) + d15;
            double d17 = (double) f15;
            f22 = (float) ((Math.sin(d14) * d17) + (((double) f26) - (Math.cos(d14) * d16)));
            f11 = sin;
            f12 = (float) ((((double) f24) - (Math.cos(d14) * d13)) - ((double) (f14 / 2.0f)));
            f21 = (float) ((Math.cos(d14) * d17) + sin2);
            f20 = 2.0f;
        }
        fArr[0] = (f13 / f20) + f11 + 0.0f;
        fArr[1] = (f14 / f20) + f12 + 0.0f;
        fArr2[0] = f21;
        fArr2[1] = f22;
    }

    public final void d(float f10, float f11, float f12, float[] fArr) {
        double[] dArr;
        float[] fArr2 = this.f198v;
        float b5 = b(f10, fArr2);
        d9[] d9VarArr = this.f186j;
        int i10 = 0;
        if (d9VarArr != null) {
            double d10 = (double) b5;
            d9VarArr[0].f(d10, this.f193q);
            this.f186j[0].c(d10, this.f192p);
            float f13 = fArr2[0];
            while (true) {
                dArr = this.f193q;
                if (i10 >= dArr.length) {
                    break;
                }
                dArr[i10] = dArr[i10] * ((double) f13);
                i10++;
            }
            b bVar = this.f187k;
            if (bVar != null) {
                double[] dArr2 = this.f192p;
                if (dArr2.length > 0) {
                    bVar.c(d10, dArr2);
                    this.f187k.f(d10, this.f193q);
                    w wVar = this.f182f;
                    int[] iArr = this.f191o;
                    double[] dArr3 = this.f193q;
                    double[] dArr4 = this.f192p;
                    wVar.getClass();
                    w.g(f11, f12, fArr, iArr, dArr3, dArr4);
                    return;
                }
                return;
            }
            w wVar2 = this.f182f;
            int[] iArr2 = this.f191o;
            double[] dArr5 = this.f192p;
            wVar2.getClass();
            w.g(f11, f12, fArr, iArr2, dArr, dArr5);
            return;
        }
        w wVar3 = this.f183g;
        float f14 = wVar3.f245e;
        w wVar4 = this.f182f;
        float f15 = f14 - wVar4.f245e;
        float f16 = wVar3.f246f - wVar4.f246f;
        fArr[0] = (((wVar3.f247g - wVar4.f247g) + f15) * f11) + ((1.0f - f11) * f15);
        fArr[1] = (((wVar3.f248h - wVar4.f248h) + f16) * f12) + ((1.0f - f12) * f16);
    }

    public final boolean e(float f10, long j3, View view, n0 n0Var) {
        boolean z4;
        z0.n nVar;
        char c10;
        float f11;
        boolean z10;
        double d10;
        w wVar;
        float f12;
        z0.n nVar2;
        boolean z11;
        double d11;
        int i10;
        float f13;
        float f14;
        boolean z12;
        float f15;
        double d12;
        float f16;
        float f17;
        n nVar3 = this;
        View view2 = view;
        float b5 = nVar3.b(f10, (float[]) null);
        int i11 = nVar3.D;
        if (i11 != -1) {
            float f18 = 1.0f / ((float) i11);
            float floor = ((float) Math.floor((double) (b5 / f18))) * f18;
            float f19 = (b5 % f18) / f18;
            if (!Float.isNaN(nVar3.E)) {
                f19 = (f19 + nVar3.E) % 1.0f;
            }
            Interpolator interpolator = nVar3.F;
            if (interpolator != null) {
                f17 = interpolator.getInterpolation(f19);
            } else if (((double) f19) > 0.5d) {
                f17 = 1.0f;
            } else {
                f17 = 0.0f;
            }
            b5 = (f17 * f18) + floor;
        }
        float f20 = b5;
        HashMap hashMap = nVar3.f201y;
        if (hashMap != null) {
            for (k c11 : hashMap.values()) {
                c11.c(view2, f20);
            }
        }
        HashMap hashMap2 = nVar3.f200x;
        if (hashMap2 != null) {
            nVar = null;
            z4 = false;
            for (p pVar : hashMap2.values()) {
                if (pVar instanceof z0.n) {
                    nVar = (z0.n) pVar;
                } else {
                    z4 |= pVar.c(f20, j3, view, n0Var);
                }
            }
        } else {
            nVar = null;
            z4 = false;
        }
        d9[] d9VarArr = nVar3.f186j;
        w wVar2 = nVar3.f182f;
        if (d9VarArr != null) {
            double d13 = (double) f20;
            d9VarArr[0].c(d13, nVar3.f192p);
            nVar3.f186j[0].f(d13, nVar3.f193q);
            b bVar = nVar3.f187k;
            if (bVar != null) {
                double[] dArr = nVar3.f192p;
                if (dArr.length > 0) {
                    bVar.c(d13, dArr);
                    nVar3.f187k.f(d13, nVar3.f193q);
                }
            }
            if (!nVar3.G) {
                int[] iArr = nVar3.f191o;
                double[] dArr2 = nVar3.f192p;
                double[] dArr3 = nVar3.f193q;
                boolean z13 = nVar3.f180d;
                float f21 = wVar2.f245e;
                float f22 = wVar2.f246f;
                float f23 = wVar2.f247g;
                float f24 = wVar2.f248h;
                if (iArr.length != 0) {
                    f14 = f21;
                    if (wVar2.f256p.length <= iArr[iArr.length - 1]) {
                        int i12 = iArr[iArr.length - 1] + 1;
                        wVar2.f256p = new double[i12];
                        wVar2.f257q = new double[i12];
                    }
                } else {
                    f14 = f21;
                }
                float f25 = f22;
                Arrays.fill(wVar2.f256p, Double.NaN);
                for (int i13 = 0; i13 < iArr.length; i13++) {
                    double[] dArr4 = wVar2.f256p;
                    int i14 = iArr[i13];
                    dArr4[i14] = dArr2[i13];
                    wVar2.f257q[i14] = dArr3[i13];
                }
                float f26 = Float.NaN;
                f12 = f20;
                nVar2 = nVar;
                float f27 = f24;
                float f28 = f14;
                float f29 = f25;
                float f30 = 0.0f;
                int i15 = 0;
                float f31 = 0.0f;
                float f32 = 0.0f;
                z11 = z4;
                float f33 = 0.0f;
                while (true) {
                    double[] dArr5 = wVar2.f256p;
                    z12 = z13;
                    if (i15 >= dArr5.length) {
                        break;
                    }
                    if (Double.isNaN(dArr5[i15])) {
                        d12 = d13;
                        f16 = f26;
                    } else {
                        double d14 = 0.0d;
                        if (!Double.isNaN(wVar2.f256p[i15])) {
                            d14 = wVar2.f256p[i15] + 0.0d;
                        }
                        d12 = d13;
                        float f34 = (float) d14;
                        f16 = f26;
                        float f35 = (float) wVar2.f257q[i15];
                        if (i15 == 1) {
                            f30 = f35;
                            f28 = f34;
                        } else if (i15 == 2) {
                            f33 = f35;
                            f29 = f34;
                        } else if (i15 == 3) {
                            f31 = f35;
                            f23 = f34;
                        } else if (i15 == 4) {
                            f32 = f35;
                            f27 = f34;
                        } else if (i15 == 5) {
                            f26 = f34;
                            i15++;
                            z13 = z12;
                            d13 = d12;
                        }
                    }
                    f26 = f16;
                    i15++;
                    z13 = z12;
                    d13 = d12;
                }
                d10 = d13;
                float f36 = f26;
                n nVar4 = wVar2.f253m;
                if (nVar4 != null) {
                    float[] fArr = new float[2];
                    float[] fArr2 = new float[2];
                    nVar4.c(d10, fArr, fArr2);
                    float f37 = fArr[0];
                    float f38 = fArr[1];
                    wVar = wVar2;
                    float f39 = fArr2[0];
                    float f40 = fArr2[1];
                    double d15 = (double) f37;
                    double d16 = (double) f28;
                    float f41 = f36;
                    double d17 = (double) f29;
                    float sin = (float) (((Math.sin(d17) * d16) + d15) - ((double) (f23 / 2.0f)));
                    f29 = (float) ((((double) f38) - (Math.cos(d17) * d16)) - ((double) (f27 / 2.0f)));
                    double d18 = (double) f30;
                    double[] dArr6 = dArr3;
                    double d19 = (double) f33;
                    float cos = (float) ((Math.cos(d17) * d16 * d19) + (Math.sin(d17) * d18) + ((double) f39));
                    f15 = f23;
                    float sin2 = (float) ((Math.sin(d17) * d16 * d19) + (((double) f40) - (Math.cos(d17) * d18)));
                    double[] dArr7 = dArr6;
                    if (dArr7.length >= 2) {
                        dArr7[0] = (double) cos;
                        dArr7[1] = (double) sin2;
                    }
                    if (!Float.isNaN(f41)) {
                        view2 = view;
                        view2.setRotation((float) (Math.toDegrees(Math.atan2((double) sin2, (double) cos)) + ((double) f41)));
                    } else {
                        view2 = view;
                    }
                    f28 = sin;
                } else {
                    float f42 = f36;
                    float f43 = f30;
                    f15 = f23;
                    wVar = wVar2;
                    if (!Float.isNaN(f42)) {
                        view2.setRotation((float) (Math.toDegrees(Math.atan2((double) ((f32 / 2.0f) + f33), (double) ((f31 / 2.0f) + f43))) + ((double) f42) + ((double) 0.0f)));
                    }
                }
                if (view2 instanceof b) {
                    ((MotionLabel) ((b) view2)).b(f28, f29, f28 + f15, f27 + f29);
                } else {
                    float f44 = f28 + 0.5f;
                    int i16 = (int) f44;
                    float f45 = f29 + 0.5f;
                    int i17 = (int) f45;
                    int i18 = (int) (f44 + f15);
                    int i19 = (int) (f45 + f27);
                    int i20 = i18 - i16;
                    int i21 = i19 - i17;
                    if (!(i20 == view.getMeasuredWidth() && i21 == view.getMeasuredHeight() && !z12)) {
                        view2.measure(View.MeasureSpec.makeMeasureSpec(i20, 1073741824), View.MeasureSpec.makeMeasureSpec(i21, 1073741824));
                    }
                    view2.layout(i16, i17, i18, i19);
                }
                nVar3 = this;
                nVar3.f180d = false;
            } else {
                d10 = d13;
                f12 = f20;
                wVar = wVar2;
                nVar2 = nVar;
                z11 = z4;
            }
            if (nVar3.B != -1) {
                if (nVar3.C == null) {
                    nVar3.C = ((View) view.getParent()).findViewById(nVar3.B);
                }
                View view3 = nVar3.C;
                if (view3 != null) {
                    float bottom = ((float) (nVar3.C.getBottom() + view3.getTop())) / 2.0f;
                    float right = ((float) (nVar3.C.getRight() + nVar3.C.getLeft())) / 2.0f;
                    if (view.getRight() - view.getLeft() > 0 && view.getBottom() - view.getTop() > 0) {
                        view2.setPivotX(right - ((float) view.getLeft()));
                        view2.setPivotY(bottom - ((float) view.getTop()));
                    }
                }
            }
            HashMap hashMap3 = nVar3.f201y;
            if (hashMap3 != null) {
                for (k kVar : hashMap3.values()) {
                    if (kVar instanceof i) {
                        double[] dArr8 = nVar3.f193q;
                        if (dArr8.length > 1) {
                            f13 = f12;
                            view2.setRotation(((i) kVar).a(f13) + ((float) Math.toDegrees(Math.atan2(dArr8[1], dArr8[0]))));
                            f12 = f13;
                        }
                    }
                    f13 = f12;
                    f12 = f13;
                }
            }
            f11 = f12;
            if (nVar2 != null) {
                double[] dArr9 = nVar3.f193q;
                d11 = d10;
                c10 = 1;
                view2.setRotation(nVar2.b(f11, j3, view, n0Var) + ((float) Math.toDegrees(Math.atan2(dArr9[1], dArr9[0]))));
                z10 = z11 | nVar2.f27546d;
            } else {
                d11 = d10;
                c10 = 1;
                z10 = z11;
            }
            int i22 = 1;
            while (true) {
                d9[] d9VarArr2 = nVar3.f186j;
                if (i22 >= d9VarArr2.length) {
                    break;
                }
                d9 d9Var = d9VarArr2[i22];
                float[] fArr3 = nVar3.f196t;
                d9Var.d(d11, fArr3);
                c0.j((a) wVar.f254n.get(nVar3.f194r[i22 - 1]), view2, fArr3);
                i22++;
            }
            l lVar = nVar3.f184h;
            if (lVar.f159b == 0) {
                if (f11 <= 0.0f) {
                    i10 = lVar.f160c;
                } else {
                    l lVar2 = nVar3.f185i;
                    if (f11 >= 1.0f) {
                        i10 = lVar2.f160c;
                    } else if (lVar2.f160c != lVar.f160c) {
                        i10 = 0;
                    }
                }
                view2.setVisibility(i10);
            }
        } else {
            f11 = f20;
            w wVar3 = wVar2;
            boolean z14 = z4;
            c10 = 1;
            float f46 = wVar3.f245e;
            w wVar4 = nVar3.f183g;
            float k10 = f.c.k(wVar4.f245e, f46, f11, f46);
            float f47 = wVar3.f246f;
            float k11 = f.c.k(wVar4.f246f, f47, f11, f47);
            float f48 = wVar3.f247g;
            float f49 = wVar4.f247g;
            float k12 = f.c.k(f49, f48, f11, f48);
            float f50 = wVar3.f248h;
            float f51 = wVar4.f248h;
            float f52 = k10 + 0.5f;
            int i23 = (int) f52;
            float f53 = k11 + 0.5f;
            int i24 = (int) f53;
            int i25 = (int) (f52 + k12);
            int k13 = (int) (f53 + f.c.k(f51, f50, f11, f50));
            int i26 = i25 - i23;
            int i27 = k13 - i24;
            if (!(f49 == f48 && f51 == f50 && !nVar3.f180d)) {
                view2.measure(View.MeasureSpec.makeMeasureSpec(i26, 1073741824), View.MeasureSpec.makeMeasureSpec(i27, 1073741824));
                nVar3.f180d = false;
            }
            view2.layout(i23, i24, i25, k13);
            z10 = z14;
        }
        HashMap hashMap4 = nVar3.f202z;
        if (hashMap4 != null) {
            for (f fVar : hashMap4.values()) {
                if (fVar instanceof d) {
                    double[] dArr10 = nVar3.f193q;
                    view2.setRotation(((d) fVar).a(f11) + ((float) Math.toDegrees(Math.atan2(dArr10[c10], dArr10[0]))));
                } else {
                    fVar.d(view2, f11);
                }
            }
        }
        return z10;
    }

    public final void f(w wVar) {
        wVar.f((float) ((int) this.f178b.getX()), (float) ((int) this.f178b.getY()), (float) this.f178b.getWidth(), (float) this.f178b.getHeight());
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v30, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v31, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v77, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v96, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v103, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v104, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v105, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v107, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v108, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v109, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v110, resolved type: z0.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v137, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v138, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v139, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v140, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v141, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v142, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v143, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v144, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v145, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v146, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v147, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v148, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v149, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v151, resolved type: z0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v152, resolved type: z0.g} */
    /* JADX WARNING: type inference failed for: r7v23, types: [z0.p, z0.o] */
    /* JADX WARNING: type inference failed for: r7v47, types: [z0.p, z0.m] */
    /* JADX WARNING: type inference failed for: r8v85, types: [z0.j, z0.k] */
    /* JADX WARNING: type inference failed for: r8v113, types: [z0.h, z0.k] */
    /* JADX WARNING: type inference failed for: r15v9, types: [a1.w, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:342:0x0876, code lost:
        r14 = r32;
        r7 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:343:0x0879, code lost:
        r7 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:349:0x089d, code lost:
        r14 = r32;
        r7 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:352:0x08b2, code lost:
        r14 = r32;
        r7 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:357:0x08da, code lost:
        r7.f27547e = r14;
        r7 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x01d2, code lost:
        if (java.lang.Float.isNaN(r14.f154l) != false) goto L_0x01d7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0225, code lost:
        if (java.lang.Float.isNaN(r14.f154l) != false) goto L_0x01d7;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:165:0x04b5  */
    /* JADX WARNING: Removed duplicated region for block: B:168:0x04da  */
    /* JADX WARNING: Removed duplicated region for block: B:169:0x04df  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void h(int r30, int r31, long r32) {
        /*
            r29 = this;
            r0 = r29
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            java.util.HashSet r2 = new java.util.HashSet
            r2.<init>()
            java.util.HashSet r3 = new java.util.HashSet
            r3.<init>()
            java.util.HashMap r4 = new java.util.HashMap
            r4.<init>()
            int r5 = r0.A
            a1.w r6 = r0.f182f
            r7 = -1
            if (r5 == r7) goto L_0x0024
            r6.f250j = r5
        L_0x0024:
            a1.l r5 = r0.f184h
            float r8 = r5.f158a
            a1.l r9 = r0.f185i
            float r10 = r9.f158a
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "alpha"
            if (r8 == 0) goto L_0x0037
            r2.add(r10)
        L_0x0037:
            float r8 = r5.f161d
            float r11 = r9.f161d
            boolean r8 = a1.l.b(r8, r11)
            java.lang.String r11 = "elevation"
            if (r8 == 0) goto L_0x0046
            r2.add(r11)
        L_0x0046:
            int r8 = r5.f160c
            int r11 = r9.f160c
            if (r8 == r11) goto L_0x0057
            int r12 = r5.f159b
            if (r12 != 0) goto L_0x0057
            if (r8 == 0) goto L_0x0054
            if (r11 != 0) goto L_0x0057
        L_0x0054:
            r2.add(r10)
        L_0x0057:
            float r8 = r5.f162e
            float r10 = r9.f162e
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "rotation"
            if (r8 == 0) goto L_0x0066
            r2.add(r10)
        L_0x0066:
            float r8 = r5.f172o
            boolean r8 = java.lang.Float.isNaN(r8)
            java.lang.String r10 = "transitionPathRotate"
            if (r8 == 0) goto L_0x0078
            float r8 = r9.f172o
            boolean r8 = java.lang.Float.isNaN(r8)
            if (r8 != 0) goto L_0x007b
        L_0x0078:
            r2.add(r10)
        L_0x007b:
            float r8 = r5.f173p
            boolean r8 = java.lang.Float.isNaN(r8)
            java.lang.String r10 = "progress"
            if (r8 == 0) goto L_0x008d
            float r8 = r9.f173p
            boolean r8 = java.lang.Float.isNaN(r8)
            if (r8 != 0) goto L_0x0090
        L_0x008d:
            r2.add(r10)
        L_0x0090:
            float r8 = r5.f163f
            float r10 = r9.f163f
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "rotationX"
            if (r8 == 0) goto L_0x009f
            r2.add(r10)
        L_0x009f:
            float r8 = r5.f164g
            float r10 = r9.f164g
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "rotationY"
            if (r8 == 0) goto L_0x00ae
            r2.add(r10)
        L_0x00ae:
            float r8 = r5.f167j
            float r10 = r9.f167j
            boolean r8 = a1.l.b(r8, r10)
            if (r8 == 0) goto L_0x00bd
            java.lang.String r8 = "transformPivotX"
            r2.add(r8)
        L_0x00bd:
            float r8 = r5.f168k
            float r10 = r9.f168k
            boolean r8 = a1.l.b(r8, r10)
            if (r8 == 0) goto L_0x00cc
            java.lang.String r8 = "transformPivotY"
            r2.add(r8)
        L_0x00cc:
            float r8 = r5.f165h
            float r10 = r9.f165h
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "scaleX"
            if (r8 == 0) goto L_0x00db
            r2.add(r10)
        L_0x00db:
            float r8 = r5.f166i
            float r10 = r9.f166i
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "scaleY"
            if (r8 == 0) goto L_0x00ea
            r2.add(r10)
        L_0x00ea:
            float r8 = r5.f169l
            float r10 = r9.f169l
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "translationX"
            if (r8 == 0) goto L_0x00f9
            r2.add(r10)
        L_0x00f9:
            float r8 = r5.f170m
            float r10 = r9.f170m
            boolean r8 = a1.l.b(r8, r10)
            java.lang.String r10 = "translationY"
            if (r8 == 0) goto L_0x0108
            r2.add(r10)
        L_0x0108:
            float r5 = r5.f171n
            float r8 = r9.f171n
            boolean r5 = a1.l.b(r5, r8)
            java.lang.String r8 = "translationZ"
            if (r5 == 0) goto L_0x0117
            r2.add(r8)
        L_0x0117:
            java.util.ArrayList r5 = r0.f199w
            java.util.ArrayList r8 = r0.f197u
            r9 = 0
            r12 = 0
            if (r5 == 0) goto L_0x0511
            java.util.Iterator r13 = r5.iterator()
        L_0x0123:
            boolean r14 = r13.hasNext()
            if (r14 == 0) goto L_0x0511
            java.lang.Object r14 = r13.next()
            a1.c r14 = (a1.c) r14
            boolean r15 = r14 instanceof a1.i
            if (r15 == 0) goto L_0x04e6
            a1.i r14 = (a1.i) r14
            a1.w r15 = new a1.w
            r15.<init>()
            r15.f242b = r9
            r10 = 2143289344(0x7fc00000, float:NaN)
            r15.f249i = r10
            r15.f250j = r7
            r15.f251k = r7
            r15.f252l = r10
            r15.f253m = r12
            java.util.LinkedHashMap r10 = new java.util.LinkedHashMap
            r10.<init>()
            r15.f254n = r10
            r15.f255o = r9
            r10 = 18
            double[] r12 = new double[r10]
            r15.f256p = r12
            double[] r10 = new double[r10]
            r15.f257q = r10
            int r10 = r6.f251k
            a1.w r12 = r0.f183g
            r16 = 1120403456(0x42c80000, float:100.0)
            if (r10 == r7) goto L_0x0240
            int r10 = r14.f90a
            float r10 = (float) r10
            float r10 = r10 / r16
            r15.f243c = r10
            int r7 = r14.f150h
            r15.f242b = r7
            int r7 = r14.f157o
            r15.f255o = r7
            float r7 = r14.f151i
            boolean r7 = java.lang.Float.isNaN(r7)
            if (r7 == 0) goto L_0x017c
            r7 = r10
            goto L_0x017e
        L_0x017c:
            float r7 = r14.f151i
        L_0x017e:
            float r9 = r14.f152j
            boolean r9 = java.lang.Float.isNaN(r9)
            if (r9 == 0) goto L_0x0188
            r9 = r10
            goto L_0x018a
        L_0x0188:
            float r9 = r14.f152j
        L_0x018a:
            float r11 = r12.f247g
            r18 = r13
            float r13 = r6.f247g
            float r11 = r11 - r13
            r19 = r3
            float r3 = r12.f248h
            r20 = r1
            float r1 = r6.f248h
            float r3 = r3 - r1
            r21 = r5
            float r5 = r15.f243c
            r15.f244d = r5
            float r11 = r11 * r7
            float r11 = r11 + r13
            int r5 = (int) r11
            float r5 = (float) r5
            r15.f247g = r5
            float r3 = r3 * r9
            float r3 = r3 + r1
            int r1 = (int) r3
            float r1 = (float) r1
            r15.f248h = r1
            int r1 = r14.f157o
            r3 = 1
            if (r1 == r3) goto L_0x0209
            r3 = 2
            if (r1 == r3) goto L_0x01e2
            float r1 = r14.f153k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01c0
            r1 = r10
            goto L_0x01c2
        L_0x01c0:
            float r1 = r14.f153k
        L_0x01c2:
            float r3 = r12.f245e
            float r5 = r6.f245e
            float r1 = f.c.k(r3, r5, r1, r5)
            r15.f245e = r1
            float r1 = r14.f154l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01d5
            goto L_0x01d7
        L_0x01d5:
            float r10 = r14.f154l
        L_0x01d7:
            float r1 = r12.f246f
            float r3 = r6.f246f
            float r1 = f.c.k(r1, r3, r10, r3)
        L_0x01df:
            r15.f246f = r1
            goto L_0x0228
        L_0x01e2:
            float r1 = r14.f153k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01f3
            float r1 = r12.f245e
            float r3 = r6.f245e
            float r1 = f.c.k(r1, r3, r10, r3)
            goto L_0x01fb
        L_0x01f3:
            float r1 = r14.f153k
            float r3 = java.lang.Math.min(r9, r7)
            float r1 = r1 * r3
        L_0x01fb:
            r15.f245e = r1
            float r1 = r14.f154l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0206
            goto L_0x01d7
        L_0x0206:
            float r1 = r14.f154l
            goto L_0x01df
        L_0x0209:
            float r1 = r14.f153k
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x0213
            r1 = r10
            goto L_0x0215
        L_0x0213:
            float r1 = r14.f153k
        L_0x0215:
            float r3 = r12.f245e
            float r5 = r6.f245e
            float r1 = f.c.k(r3, r5, r1, r5)
            r15.f245e = r1
            float r1 = r14.f154l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x01d5
            goto L_0x01d7
        L_0x0228:
            int r1 = r6.f251k
            r15.f251k = r1
            java.lang.String r1 = r14.f148f
            v0.e r1 = v0.e.c(r1)
            r15.f241a = r1
            int r1 = r14.f149g
            r15.f250j = r1
            r24 = r2
            r26 = r4
        L_0x023c:
            r0 = r6
            r1 = r8
            goto L_0x04af
        L_0x0240:
            r20 = r1
            r19 = r3
            r21 = r5
            r18 = r13
            int r1 = r14.f157o
            r7 = 1
            if (r1 == r7) goto L_0x03e7
            r7 = 2
            if (r1 == r7) goto L_0x0321
            int r1 = r14.f90a
            float r1 = (float) r1
            float r1 = r1 / r16
            r15.f243c = r1
            int r7 = r14.f150h
            r15.f242b = r7
            float r7 = r14.f151i
            boolean r7 = java.lang.Float.isNaN(r7)
            if (r7 == 0) goto L_0x0265
            r7 = r1
            goto L_0x0267
        L_0x0265:
            float r7 = r14.f151i
        L_0x0267:
            float r9 = r14.f152j
            boolean r9 = java.lang.Float.isNaN(r9)
            if (r9 == 0) goto L_0x0271
            r9 = r1
            goto L_0x0273
        L_0x0271:
            float r9 = r14.f152j
        L_0x0273:
            float r10 = r12.f247g
            float r11 = r6.f247g
            float r13 = r10 - r11
            float r3 = r12.f248h
            float r5 = r6.f248h
            float r16 = r3 - r5
            r24 = r2
            float r2 = r15.f243c
            r15.f244d = r2
            float r2 = r6.f245e
            r23 = 1073741824(0x40000000, float:2.0)
            float r25 = r11 / r23
            float r25 = r25 + r2
            r26 = r4
            float r4 = r6.f246f
            float r27 = r5 / r23
            float r27 = r27 + r4
            float r0 = r12.f245e
            float r10 = r10 / r23
            float r10 = r10 + r0
            float r0 = r12.f246f
            float r3 = r3 / r23
            float r3 = r3 + r0
            float r10 = r10 - r25
            float r3 = r3 - r27
            float r0 = r10 * r1
            float r0 = r0 + r2
            float r13 = r13 * r7
            float r2 = r13 / r23
            float r0 = r0 - r2
            int r0 = (int) r0
            float r0 = (float) r0
            r15.f245e = r0
            float r0 = r3 * r1
            float r0 = r0 + r4
            float r16 = r16 * r9
            float r4 = r16 / r23
            float r0 = r0 - r4
            int r0 = (int) r0
            float r0 = (float) r0
            r15.f246f = r0
            float r11 = r11 + r13
            int r0 = (int) r11
            float r0 = (float) r0
            r15.f247g = r0
            float r5 = r5 + r16
            int r0 = (int) r5
            float r0 = (float) r0
            r15.f248h = r0
            float r0 = r14.f153k
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 == 0) goto L_0x02d0
            r0 = r1
            goto L_0x02d2
        L_0x02d0:
            float r0 = r14.f153k
        L_0x02d2:
            float r5 = r14.f156n
            boolean r5 = java.lang.Float.isNaN(r5)
            if (r5 == 0) goto L_0x02dc
            r5 = 0
            goto L_0x02de
        L_0x02dc:
            float r5 = r14.f156n
        L_0x02de:
            float r7 = r14.f154l
            boolean r7 = java.lang.Float.isNaN(r7)
            if (r7 == 0) goto L_0x02e7
            goto L_0x02e9
        L_0x02e7:
            float r1 = r14.f154l
        L_0x02e9:
            float r7 = r14.f155m
            boolean r7 = java.lang.Float.isNaN(r7)
            if (r7 == 0) goto L_0x02f4
            r7 = 0
        L_0x02f2:
            r9 = 0
            goto L_0x02f7
        L_0x02f4:
            float r7 = r14.f155m
            goto L_0x02f2
        L_0x02f7:
            r15.f255o = r9
            float r9 = r6.f245e
            float r0 = r0 * r10
            float r0 = r0 + r9
            float r7 = r7 * r3
            float r7 = r7 + r0
            float r7 = r7 - r2
            int r0 = (int) r7
            float r0 = (float) r0
            r15.f245e = r0
            float r0 = r6.f246f
            float r10 = r10 * r5
            float r10 = r10 + r0
            float r3 = r3 * r1
            float r3 = r3 + r10
            float r3 = r3 - r4
            int r0 = (int) r3
            float r0 = (float) r0
            r15.f246f = r0
            java.lang.String r0 = r14.f148f
            v0.e r0 = v0.e.c(r0)
            r15.f241a = r0
            int r0 = r14.f149g
            r15.f250j = r0
            goto L_0x023c
        L_0x0321:
            r24 = r2
            r26 = r4
            int r0 = r14.f90a
            float r0 = (float) r0
            float r0 = r0 / r16
            r15.f243c = r0
            int r1 = r14.f150h
            r15.f242b = r1
            float r1 = r14.f151i
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 == 0) goto L_0x033a
            r1 = r0
            goto L_0x033c
        L_0x033a:
            float r1 = r14.f151i
        L_0x033c:
            float r2 = r14.f152j
            boolean r2 = java.lang.Float.isNaN(r2)
            if (r2 == 0) goto L_0x0346
            r2 = r0
            goto L_0x0348
        L_0x0346:
            float r2 = r14.f152j
        L_0x0348:
            float r3 = r12.f247g
            float r4 = r6.f247g
            float r5 = r3 - r4
            float r7 = r12.f248h
            float r9 = r6.f248h
            float r10 = r7 - r9
            float r11 = r15.f243c
            r15.f244d = r11
            float r11 = r6.f245e
            r13 = 1073741824(0x40000000, float:2.0)
            float r16 = r4 / r13
            float r16 = r16 + r11
            r25 = r8
            float r8 = r6.f246f
            float r22 = r9 / r13
            float r22 = r22 + r8
            r27 = r6
            float r6 = r12.f245e
            float r3 = r3 / r13
            float r3 = r3 + r6
            float r6 = r12.f246f
            float r7 = r7 / r13
            float r7 = r7 + r6
            float r3 = r3 - r16
            float r7 = r7 - r22
            float r3 = r3 * r0
            float r3 = r3 + r11
            float r5 = r5 * r1
            float r1 = r5 / r13
            float r3 = r3 - r1
            int r1 = (int) r3
            float r1 = (float) r1
            r15.f245e = r1
            float r7 = r7 * r0
            float r7 = r7 + r8
            float r10 = r10 * r2
            float r0 = r10 / r13
            float r7 = r7 - r0
            int r0 = (int) r7
            float r0 = (float) r0
            r15.f246f = r0
            float r4 = r4 + r5
            int r0 = (int) r4
            float r0 = (float) r0
            r15.f247g = r0
            float r9 = r9 + r10
            int r0 = (int) r9
            float r0 = (float) r0
            r15.f248h = r0
            r0 = 2
            r15.f255o = r0
            float r0 = r14.f153k
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L_0x03b4
            r0 = r30
            float r1 = (float) r0
            float r2 = r15.f247g
            float r1 = r1 - r2
            int r1 = (int) r1
            float r2 = r14.f153k
            float r1 = (float) r1
            float r2 = r2 * r1
            int r1 = (int) r2
            float r1 = (float) r1
            r15.f245e = r1
            goto L_0x03b6
        L_0x03b4:
            r0 = r30
        L_0x03b6:
            float r1 = r14.f154l
            boolean r1 = java.lang.Float.isNaN(r1)
            if (r1 != 0) goto L_0x03cf
            r1 = r31
            float r2 = (float) r1
            float r3 = r15.f248h
            float r2 = r2 - r3
            int r2 = (int) r2
            float r3 = r14.f154l
            float r2 = (float) r2
            float r3 = r3 * r2
            int r2 = (int) r3
            float r2 = (float) r2
            r15.f246f = r2
            goto L_0x03d1
        L_0x03cf:
            r1 = r31
        L_0x03d1:
            int r2 = r15.f251k
            r15.f251k = r2
            java.lang.String r2 = r14.f148f
            v0.e r2 = v0.e.c(r2)
            r15.f241a = r2
            int r2 = r14.f149g
            r15.f250j = r2
            r1 = r25
            r0 = r27
            goto L_0x04af
        L_0x03e7:
            r0 = r30
            r1 = r31
            r24 = r2
            r26 = r4
            r27 = r6
            r25 = r8
            int r2 = r14.f90a
            float r2 = (float) r2
            float r2 = r2 / r16
            r15.f243c = r2
            int r3 = r14.f150h
            r15.f242b = r3
            float r3 = r14.f151i
            boolean r3 = java.lang.Float.isNaN(r3)
            if (r3 == 0) goto L_0x0408
            r3 = r2
            goto L_0x040a
        L_0x0408:
            float r3 = r14.f151i
        L_0x040a:
            float r4 = r14.f152j
            boolean r4 = java.lang.Float.isNaN(r4)
            if (r4 == 0) goto L_0x0414
            r4 = r2
            goto L_0x0416
        L_0x0414:
            float r4 = r14.f152j
        L_0x0416:
            float r5 = r12.f247g
            r6 = r27
            float r7 = r6.f247g
            float r5 = r5 - r7
            float r7 = r12.f248h
            float r8 = r6.f248h
            float r7 = r7 - r8
            float r8 = r15.f243c
            r15.f244d = r8
            float r8 = r14.f153k
            boolean r8 = java.lang.Float.isNaN(r8)
            if (r8 == 0) goto L_0x042f
            goto L_0x0431
        L_0x042f:
            float r2 = r14.f153k
        L_0x0431:
            float r8 = r6.f245e
            float r9 = r6.f247g
            r10 = 1073741824(0x40000000, float:2.0)
            float r11 = r9 / r10
            float r11 = r11 + r8
            float r13 = r6.f246f
            float r0 = r6.f248h
            float r16 = r0 / r10
            float r16 = r16 + r13
            float r1 = r12.f245e
            r27 = r6
            float r6 = r12.f247g
            float r6 = r6 / r10
            float r6 = r6 + r1
            float r1 = r12.f246f
            float r12 = r12.f248h
            float r12 = r12 / r10
            float r12 = r12 + r1
            float r6 = r6 - r11
            float r12 = r12 - r16
            float r1 = r6 * r2
            float r8 = r8 + r1
            float r5 = r5 * r3
            float r3 = r5 / r10
            float r8 = r8 - r3
            int r8 = (int) r8
            float r8 = (float) r8
            r15.f245e = r8
            float r2 = r2 * r12
            float r13 = r13 + r2
            float r7 = r7 * r4
            float r4 = r7 / r10
            float r13 = r13 - r4
            int r8 = (int) r13
            float r8 = (float) r8
            r15.f246f = r8
            float r9 = r9 + r5
            int r5 = (int) r9
            float r5 = (float) r5
            r15.f247g = r5
            float r0 = r0 + r7
            int r0 = (int) r0
            float r0 = (float) r0
            r15.f248h = r0
            float r0 = r14.f154l
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 == 0) goto L_0x047f
            r0 = 0
            goto L_0x0481
        L_0x047f:
            float r0 = r14.f154l
        L_0x0481:
            float r5 = -r12
            float r5 = r5 * r0
            float r6 = r6 * r0
            r0 = 1
            r15.f255o = r0
            r0 = r27
            float r7 = r0.f245e
            float r7 = r7 + r1
            float r7 = r7 - r3
            int r1 = (int) r7
            float r1 = (float) r1
            float r3 = r0.f246f
            float r3 = r3 + r2
            float r3 = r3 - r4
            int r2 = (int) r3
            float r2 = (float) r2
            float r1 = r1 + r5
            r15.f245e = r1
            float r2 = r2 + r6
            r15.f246f = r2
            int r1 = r15.f251k
            r15.f251k = r1
            java.lang.String r1 = r14.f148f
            v0.e r1 = v0.e.c(r1)
            r15.f241a = r1
            int r1 = r14.f149g
            r15.f250j = r1
            r1 = r25
        L_0x04af:
            int r2 = java.util.Collections.binarySearch(r1, r15)
            if (r2 != 0) goto L_0x04cf
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = " KeyPath position \""
            r3.<init>(r4)
            float r4 = r15.f244d
            r3.append(r4)
            java.lang.String r4 = "\" outside of range"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r4 = "MotionController"
            android.util.Log.e(r4, r3)
        L_0x04cf:
            int r2 = -r2
            r3 = 1
            int r2 = r2 - r3
            r1.add(r2, r15)
            int r2 = r14.f147e
            r3 = -1
            if (r2 == r3) goto L_0x04df
            r3 = r29
            r3.f181e = r2
            goto L_0x04e1
        L_0x04df:
            r3 = r29
        L_0x04e1:
            r4 = r24
            r2 = r26
            goto L_0x04fc
        L_0x04e6:
            r20 = r1
            r24 = r2
            r19 = r3
            r2 = r4
            r21 = r5
            r1 = r8
            r18 = r13
            r3 = r0
            r0 = r6
            r14.e(r2)
            r4 = r24
            r14.c(r4)
        L_0x04fc:
            r6 = r0
            r8 = r1
            r0 = r3
            r13 = r18
            r3 = r19
            r1 = r20
            r5 = r21
            r7 = -1
            r9 = 0
            r12 = 0
            r28 = r4
            r4 = r2
            r2 = r28
            goto L_0x0123
        L_0x0511:
            r20 = r1
            r19 = r3
            r21 = r5
            r1 = r8
            r3 = r0
            r0 = r6
            r28 = r4
            r4 = r2
            r2 = r28
            boolean r5 = r4.isEmpty()
            r6 = 4
            r7 = 3
            r9 = 8
            r10 = 7
            java.lang.String r12 = ","
            if (r5 != 0) goto L_0x074c
            java.util.HashMap r5 = new java.util.HashMap
            r5.<init>()
            r3.f201y = r5
            java.util.Iterator r5 = r4.iterator()
        L_0x0537:
            boolean r14 = r5.hasNext()
            if (r14 == 0) goto L_0x06e7
            java.lang.Object r14 = r5.next()
            java.lang.String r14 = (java.lang.String) r14
            java.lang.String r15 = "CUSTOM,"
            boolean r15 = r14.startsWith(r15)
            if (r15 == 0) goto L_0x058d
            android.util.SparseArray r15 = new android.util.SparseArray
            r15.<init>()
            java.lang.String[] r16 = r14.split(r12)
            r17 = 1
            r11 = r16[r17]
            java.util.Iterator r16 = r21.iterator()
        L_0x055c:
            boolean r18 = r16.hasNext()
            if (r18 == 0) goto L_0x057d
            java.lang.Object r18 = r16.next()
            r13 = r18
            a1.c r13 = (a1.c) r13
            java.util.HashMap r8 = r13.f93d
            if (r8 != 0) goto L_0x056f
            goto L_0x055c
        L_0x056f:
            java.lang.Object r8 = r8.get(r11)
            c1.a r8 = (c1.a) r8
            if (r8 == 0) goto L_0x055c
            int r13 = r13.f90a
            r15.append(r13, r8)
            goto L_0x055c
        L_0x057d:
            z0.h r8 = new z0.h
            r8.<init>()
            java.lang.String[] r11 = r14.split(r12)
            r13 = 1
            r11 = r11[r13]
            r8.f30594f = r15
            goto L_0x06da
        L_0x058d:
            r14.hashCode()
            r8 = -1
            int r11 = r14.hashCode()
            switch(r11) {
                case -1249320806: goto L_0x0657;
                case -1249320805: goto L_0x064c;
                case -1225497657: goto L_0x0641;
                case -1225497656: goto L_0x0636;
                case -1225497655: goto L_0x062b;
                case -1001078227: goto L_0x0620;
                case -908189618: goto L_0x0615;
                case -908189617: goto L_0x060a;
                case -797520672: goto L_0x05fc;
                case -760884510: goto L_0x05ee;
                case -760884509: goto L_0x05e0;
                case -40300674: goto L_0x05d2;
                case -4379043: goto L_0x05c4;
                case 37232917: goto L_0x05b6;
                case 92909918: goto L_0x05a8;
                case 156108012: goto L_0x059a;
                default: goto L_0x0598;
            }
        L_0x0598:
            goto L_0x0661
        L_0x059a:
            java.lang.String r11 = "waveOffset"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05a4
            goto L_0x0661
        L_0x05a4:
            r8 = 15
            goto L_0x0661
        L_0x05a8:
            java.lang.String r11 = "alpha"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05b2
            goto L_0x0661
        L_0x05b2:
            r8 = 14
            goto L_0x0661
        L_0x05b6:
            java.lang.String r11 = "transitionPathRotate"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05c0
            goto L_0x0661
        L_0x05c0:
            r8 = 13
            goto L_0x0661
        L_0x05c4:
            java.lang.String r11 = "elevation"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05ce
            goto L_0x0661
        L_0x05ce:
            r8 = 12
            goto L_0x0661
        L_0x05d2:
            java.lang.String r11 = "rotation"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05dc
            goto L_0x0661
        L_0x05dc:
            r8 = 11
            goto L_0x0661
        L_0x05e0:
            java.lang.String r11 = "transformPivotY"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05ea
            goto L_0x0661
        L_0x05ea:
            r8 = 10
            goto L_0x0661
        L_0x05ee:
            java.lang.String r11 = "transformPivotX"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x05f8
            goto L_0x0661
        L_0x05f8:
            r8 = 9
            goto L_0x0661
        L_0x05fc:
            java.lang.String r11 = "waveVariesBy"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0606
            goto L_0x0661
        L_0x0606:
            r8 = 8
            goto L_0x0661
        L_0x060a:
            java.lang.String r11 = "scaleY"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0613
            goto L_0x0661
        L_0x0613:
            r8 = 7
            goto L_0x0661
        L_0x0615:
            java.lang.String r11 = "scaleX"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x061e
            goto L_0x0661
        L_0x061e:
            r8 = 6
            goto L_0x0661
        L_0x0620:
            java.lang.String r11 = "progress"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0629
            goto L_0x0661
        L_0x0629:
            r8 = 5
            goto L_0x0661
        L_0x062b:
            java.lang.String r11 = "translationZ"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0634
            goto L_0x0661
        L_0x0634:
            r8 = 4
            goto L_0x0661
        L_0x0636:
            java.lang.String r11 = "translationY"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x063f
            goto L_0x0661
        L_0x063f:
            r8 = 3
            goto L_0x0661
        L_0x0641:
            java.lang.String r11 = "translationX"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x064a
            goto L_0x0661
        L_0x064a:
            r8 = 2
            goto L_0x0661
        L_0x064c:
            java.lang.String r11 = "rotationY"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0655
            goto L_0x0661
        L_0x0655:
            r8 = 1
            goto L_0x0661
        L_0x0657:
            java.lang.String r11 = "rotationX"
            boolean r11 = r14.equals(r11)
            if (r11 != 0) goto L_0x0660
            goto L_0x0661
        L_0x0660:
            r8 = 0
        L_0x0661:
            switch(r8) {
                case 0: goto L_0x06d4;
                case 1: goto L_0x06cd;
                case 2: goto L_0x06c5;
                case 3: goto L_0x06bd;
                case 4: goto L_0x06b5;
                case 5: goto L_0x06ac;
                case 6: goto L_0x06a5;
                case 7: goto L_0x069e;
                case 8: goto L_0x0697;
                case 9: goto L_0x0690;
                case 10: goto L_0x068a;
                case 11: goto L_0x0684;
                case 12: goto L_0x067d;
                case 13: goto L_0x0677;
                case 14: goto L_0x066f;
                case 15: goto L_0x0667;
                default: goto L_0x0664;
            }
        L_0x0664:
            r8 = 0
            goto L_0x06da
        L_0x0667:
            z0.g r8 = new z0.g
            r11 = 0
            r8.<init>(r11)
            goto L_0x06da
        L_0x066f:
            r11 = 0
            z0.g r8 = new z0.g
            r8.<init>(r11)
            goto L_0x06da
        L_0x0677:
            z0.i r8 = new z0.i
            r8.<init>()
            goto L_0x06da
        L_0x067d:
            z0.g r8 = new z0.g
            r11 = 1
            r8.<init>(r11)
            goto L_0x06da
        L_0x0684:
            z0.g r8 = new z0.g
            r8.<init>(r6)
            goto L_0x06da
        L_0x068a:
            z0.g r8 = new z0.g
            r8.<init>(r7)
            goto L_0x06da
        L_0x0690:
            z0.g r8 = new z0.g
            r11 = 2
            r8.<init>(r11)
            goto L_0x06da
        L_0x0697:
            z0.g r8 = new z0.g
            r11 = 0
            r8.<init>(r11)
            goto L_0x06da
        L_0x069e:
            r11 = 0
            z0.g r8 = new z0.g
            r8.<init>(r9)
            goto L_0x06da
        L_0x06a5:
            r11 = 0
            z0.g r8 = new z0.g
            r8.<init>(r10)
            goto L_0x06da
        L_0x06ac:
            r11 = 0
            z0.j r8 = new z0.j
            r8.<init>()
            r8.f30596f = r11
            goto L_0x06da
        L_0x06b5:
            z0.g r8 = new z0.g
            r11 = 11
            r8.<init>(r11)
            goto L_0x06da
        L_0x06bd:
            z0.g r8 = new z0.g
            r11 = 10
            r8.<init>(r11)
            goto L_0x06da
        L_0x06c5:
            z0.g r8 = new z0.g
            r11 = 9
            r8.<init>(r11)
            goto L_0x06da
        L_0x06cd:
            z0.g r8 = new z0.g
            r11 = 6
            r8.<init>(r11)
            goto L_0x06da
        L_0x06d4:
            z0.g r8 = new z0.g
            r11 = 5
            r8.<init>(r11)
        L_0x06da:
            if (r8 != 0) goto L_0x06de
            goto L_0x0537
        L_0x06de:
            r8.f30601e = r14
            java.util.HashMap r11 = r3.f201y
            r11.put(r14, r8)
            goto L_0x0537
        L_0x06e7:
            if (r21 == 0) goto L_0x0703
            java.util.Iterator r5 = r21.iterator()
        L_0x06ed:
            boolean r8 = r5.hasNext()
            if (r8 == 0) goto L_0x0703
            java.lang.Object r8 = r5.next()
            a1.c r8 = (a1.c) r8
            boolean r11 = r8 instanceof a1.e
            if (r11 == 0) goto L_0x06ed
            java.util.HashMap r11 = r3.f201y
            r8.a(r11)
            goto L_0x06ed
        L_0x0703:
            a1.l r5 = r3.f184h
            java.util.HashMap r8 = r3.f201y
            r11 = 0
            r5.a(r8, r11)
            java.util.HashMap r5 = r3.f201y
            r8 = 100
            a1.l r11 = r3.f185i
            r11.a(r5, r8)
            java.util.HashMap r5 = r3.f201y
            java.util.Set r5 = r5.keySet()
            java.util.Iterator r5 = r5.iterator()
        L_0x071e:
            boolean r8 = r5.hasNext()
            if (r8 == 0) goto L_0x074c
            java.lang.Object r8 = r5.next()
            java.lang.String r8 = (java.lang.String) r8
            boolean r11 = r2.containsKey(r8)
            if (r11 == 0) goto L_0x073d
            java.lang.Object r11 = r2.get(r8)
            java.lang.Integer r11 = (java.lang.Integer) r11
            if (r11 == 0) goto L_0x073d
            int r11 = r11.intValue()
            goto L_0x073e
        L_0x073d:
            r11 = 0
        L_0x073e:
            java.util.HashMap r13 = r3.f201y
            java.lang.Object r8 = r13.get(r8)
            z0.k r8 = (z0.k) r8
            if (r8 == 0) goto L_0x071e
            r8.d(r11)
            goto L_0x071e
        L_0x074c:
            boolean r5 = r20.isEmpty()
            if (r5 != 0) goto L_0x0934
            java.util.HashMap r5 = r3.f200x
            if (r5 != 0) goto L_0x075d
            java.util.HashMap r5 = new java.util.HashMap
            r5.<init>()
            r3.f200x = r5
        L_0x075d:
            java.util.Iterator r5 = r20.iterator()
        L_0x0761:
            boolean r8 = r5.hasNext()
            if (r8 == 0) goto L_0x08ed
            java.lang.Object r8 = r5.next()
            java.lang.String r8 = (java.lang.String) r8
            java.util.HashMap r11 = r3.f200x
            boolean r11 = r11.containsKey(r8)
            if (r11 == 0) goto L_0x0776
            goto L_0x0761
        L_0x0776:
            java.lang.String r11 = "CUSTOM,"
            boolean r11 = r8.startsWith(r11)
            if (r11 == 0) goto L_0x07cc
            android.util.SparseArray r11 = new android.util.SparseArray
            r11.<init>()
            java.lang.String[] r13 = r8.split(r12)
            r14 = 1
            r13 = r13[r14]
            java.util.Iterator r14 = r21.iterator()
        L_0x078e:
            boolean r15 = r14.hasNext()
            if (r15 == 0) goto L_0x07ae
            java.lang.Object r15 = r14.next()
            a1.c r15 = (a1.c) r15
            java.util.HashMap r7 = r15.f93d
            if (r7 != 0) goto L_0x07a0
        L_0x079e:
            r7 = 3
            goto L_0x078e
        L_0x07a0:
            java.lang.Object r7 = r7.get(r13)
            c1.a r7 = (c1.a) r7
            if (r7 == 0) goto L_0x079e
            int r15 = r15.f90a
            r11.append(r15, r7)
            goto L_0x079e
        L_0x07ae:
            z0.m r7 = new z0.m
            r7.<init>()
            android.util.SparseArray r13 = new android.util.SparseArray
            r13.<init>()
            r7.f30605i = r13
            java.lang.String[] r13 = r8.split(r12)
            r14 = 1
            r13 = r13[r14]
            r7.f30603g = r13
            r7.f30604h = r11
            r14 = r32
        L_0x07c7:
            r11 = 5
            r13 = 9
            goto L_0x08dc
        L_0x07cc:
            r8.hashCode()
            r7 = -1
            int r11 = r8.hashCode()
            switch(r11) {
                case -1249320806: goto L_0x085e;
                case -1249320805: goto L_0x0853;
                case -1225497657: goto L_0x0848;
                case -1225497656: goto L_0x083d;
                case -1225497655: goto L_0x0832;
                case -1001078227: goto L_0x0827;
                case -908189618: goto L_0x081c;
                case -908189617: goto L_0x0811;
                case -40300674: goto L_0x0803;
                case -4379043: goto L_0x07f5;
                case 37232917: goto L_0x07e7;
                case 92909918: goto L_0x07d9;
                default: goto L_0x07d7;
            }
        L_0x07d7:
            goto L_0x0868
        L_0x07d9:
            java.lang.String r11 = "alpha"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x07e3
            goto L_0x0868
        L_0x07e3:
            r7 = 11
            goto L_0x0868
        L_0x07e7:
            java.lang.String r11 = "transitionPathRotate"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x07f1
            goto L_0x0868
        L_0x07f1:
            r7 = 10
            goto L_0x0868
        L_0x07f5:
            java.lang.String r11 = "elevation"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x07ff
            goto L_0x0868
        L_0x07ff:
            r7 = 9
            goto L_0x0868
        L_0x0803:
            java.lang.String r11 = "rotation"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x080d
            goto L_0x0868
        L_0x080d:
            r7 = 8
            goto L_0x0868
        L_0x0811:
            java.lang.String r11 = "scaleY"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x081a
            goto L_0x0868
        L_0x081a:
            r7 = 7
            goto L_0x0868
        L_0x081c:
            java.lang.String r11 = "scaleX"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x0825
            goto L_0x0868
        L_0x0825:
            r7 = 6
            goto L_0x0868
        L_0x0827:
            java.lang.String r11 = "progress"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x0830
            goto L_0x0868
        L_0x0830:
            r7 = 5
            goto L_0x0868
        L_0x0832:
            java.lang.String r11 = "translationZ"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x083b
            goto L_0x0868
        L_0x083b:
            r7 = 4
            goto L_0x0868
        L_0x083d:
            java.lang.String r11 = "translationY"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x0846
            goto L_0x0868
        L_0x0846:
            r7 = 3
            goto L_0x0868
        L_0x0848:
            java.lang.String r11 = "translationX"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x0851
            goto L_0x0868
        L_0x0851:
            r7 = 2
            goto L_0x0868
        L_0x0853:
            java.lang.String r11 = "rotationY"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x085c
            goto L_0x0868
        L_0x085c:
            r7 = 1
            goto L_0x0868
        L_0x085e:
            java.lang.String r11 = "rotationX"
            boolean r11 = r8.equals(r11)
            if (r11 != 0) goto L_0x0867
            goto L_0x0868
        L_0x0867:
            r7 = 0
        L_0x0868:
            switch(r7) {
                case 0: goto L_0x08d0;
                case 1: goto L_0x08c7;
                case 2: goto L_0x08be;
                case 3: goto L_0x08b5;
                case 4: goto L_0x08aa;
                case 5: goto L_0x08a0;
                case 6: goto L_0x0897;
                case 7: goto L_0x0890;
                case 8: goto L_0x0889;
                case 9: goto L_0x0882;
                case 10: goto L_0x087c;
                case 11: goto L_0x0870;
                default: goto L_0x086b;
            }
        L_0x086b:
            r14 = r32
            r7 = 0
            goto L_0x07c7
        L_0x0870:
            z0.l r7 = new z0.l
            r11 = 0
            r7.<init>(r11)
        L_0x0876:
            r14 = r32
            r11 = 5
        L_0x0879:
            r13 = 9
            goto L_0x08da
        L_0x087c:
            z0.n r7 = new z0.n
            r7.<init>()
            goto L_0x0876
        L_0x0882:
            z0.l r7 = new z0.l
            r11 = 1
            r7.<init>(r11)
            goto L_0x0876
        L_0x0889:
            z0.l r7 = new z0.l
            r11 = 2
            r7.<init>(r11)
            goto L_0x0876
        L_0x0890:
            z0.l r7 = new z0.l
            r11 = 6
            r7.<init>(r11)
            goto L_0x0876
        L_0x0897:
            z0.l r7 = new z0.l
            r11 = 5
            r7.<init>(r11)
        L_0x089d:
            r14 = r32
            goto L_0x0879
        L_0x08a0:
            r11 = 5
            z0.o r7 = new z0.o
            r7.<init>()
            r13 = 0
            r7.f30608g = r13
            goto L_0x089d
        L_0x08aa:
            r11 = 5
            z0.l r7 = new z0.l
            r13 = 9
            r7.<init>(r13)
        L_0x08b2:
            r14 = r32
            goto L_0x08da
        L_0x08b5:
            r11 = 5
            r13 = 9
            z0.l r7 = new z0.l
            r7.<init>(r9)
            goto L_0x08b2
        L_0x08be:
            r11 = 5
            r13 = 9
            z0.l r7 = new z0.l
            r7.<init>(r10)
            goto L_0x08b2
        L_0x08c7:
            r11 = 5
            r13 = 9
            z0.l r7 = new z0.l
            r7.<init>(r6)
            goto L_0x08b2
        L_0x08d0:
            r11 = 5
            r13 = 9
            z0.l r7 = new z0.l
            r14 = 3
            r7.<init>(r14)
            goto L_0x08b2
        L_0x08da:
            r7.f27547e = r14
        L_0x08dc:
            if (r7 != 0) goto L_0x08e1
            r7 = 3
            goto L_0x0761
        L_0x08e1:
            r7.f27544b = r8
            java.util.HashMap r9 = r3.f200x
            r9.put(r8, r7)
            r7 = 3
            r9 = 8
            goto L_0x0761
        L_0x08ed:
            if (r21 == 0) goto L_0x0900
            java.util.Iterator r5 = r21.iterator()
        L_0x08f3:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L_0x0900
            java.lang.Object r7 = r5.next()
            a1.c r7 = (a1.c) r7
            goto L_0x08f3
        L_0x0900:
            java.util.HashMap r5 = r3.f200x
            java.util.Set r5 = r5.keySet()
            java.util.Iterator r5 = r5.iterator()
        L_0x090a:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L_0x0934
            java.lang.Object r7 = r5.next()
            java.lang.String r7 = (java.lang.String) r7
            boolean r8 = r2.containsKey(r7)
            if (r8 == 0) goto L_0x0927
            java.lang.Object r8 = r2.get(r7)
            java.lang.Integer r8 = (java.lang.Integer) r8
            int r8 = r8.intValue()
            goto L_0x0928
        L_0x0927:
            r8 = 0
        L_0x0928:
            java.util.HashMap r9 = r3.f200x
            java.lang.Object r7 = r9.get(r7)
            z0.p r7 = (z0.p) r7
            r7.a(r8)
            goto L_0x090a
        L_0x0934:
            int r2 = r1.size()
            int r5 = r2 + 2
            a1.w[] r7 = new a1.w[r5]
            r8 = 0
            r7[r8] = r0
            r9 = 1
            int r2 = r2 + r9
            a1.w r9 = r3.f183g
            r7[r2] = r9
            int r2 = r1.size()
            if (r2 <= 0) goto L_0x0952
            int r2 = r3.f181e
            r9 = -1
            if (r2 != r9) goto L_0x0952
            r3.f181e = r8
        L_0x0952:
            java.util.Iterator r1 = r1.iterator()
            r2 = 1
        L_0x0957:
            boolean r8 = r1.hasNext()
            if (r8 == 0) goto L_0x0969
            java.lang.Object r8 = r1.next()
            a1.w r8 = (a1.w) r8
            int r9 = r2 + 1
            r7[r2] = r8
            r2 = r9
            goto L_0x0957
        L_0x0969:
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            a1.w r2 = r3.f183g
            java.util.LinkedHashMap r2 = r2.f254n
            java.util.Set r2 = r2.keySet()
            java.util.Iterator r2 = r2.iterator()
        L_0x097a:
            boolean r8 = r2.hasNext()
            if (r8 == 0) goto L_0x09a6
            java.lang.Object r8 = r2.next()
            java.lang.String r8 = (java.lang.String) r8
            java.util.LinkedHashMap r9 = r0.f254n
            boolean r9 = r9.containsKey(r8)
            if (r9 == 0) goto L_0x097a
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r10 = "CUSTOM,"
            r9.<init>(r10)
            r9.append(r8)
            java.lang.String r9 = r9.toString()
            boolean r9 = r4.contains(r9)
            if (r9 != 0) goto L_0x097a
            r1.add(r8)
            goto L_0x097a
        L_0x09a6:
            r8 = 0
            java.lang.String[] r0 = new java.lang.String[r8]
            java.lang.Object[] r0 = r1.toArray(r0)
            java.lang.String[] r0 = (java.lang.String[]) r0
            r3.f194r = r0
            int r0 = r0.length
            int[] r0 = new int[r0]
            r3.f195s = r0
            r0 = 0
        L_0x09b7:
            java.lang.String[] r1 = r3.f194r
            int r2 = r1.length
            if (r0 >= r2) goto L_0x09ee
            r1 = r1[r0]
            int[] r2 = r3.f195s
            r4 = 0
            r2[r0] = r4
            r2 = 0
        L_0x09c4:
            if (r2 >= r5) goto L_0x09eb
            r4 = r7[r2]
            java.util.LinkedHashMap r4 = r4.f254n
            boolean r4 = r4.containsKey(r1)
            if (r4 == 0) goto L_0x09e8
            r4 = r7[r2]
            java.util.LinkedHashMap r4 = r4.f254n
            java.lang.Object r4 = r4.get(r1)
            c1.a r4 = (c1.a) r4
            if (r4 == 0) goto L_0x09e8
            int[] r1 = r3.f195s
            r2 = r1[r0]
            int r4 = r4.c()
            int r4 = r4 + r2
            r1[r0] = r4
            goto L_0x09eb
        L_0x09e8:
            int r2 = r2 + 1
            goto L_0x09c4
        L_0x09eb:
            int r0 = r0 + 1
            goto L_0x09b7
        L_0x09ee:
            r0 = 0
            r2 = r7[r0]
            int r0 = r2.f250j
            r2 = -1
            if (r0 == r2) goto L_0x09f8
            r0 = 1
            goto L_0x09f9
        L_0x09f8:
            r0 = 0
        L_0x09f9:
            int r1 = r1.length
            r2 = 18
            int r2 = r2 + r1
            boolean[] r1 = new boolean[r2]
            r4 = 1
        L_0x0a00:
            if (r4 >= r5) goto L_0x0a53
            r8 = r7[r4]
            int r9 = r4 + -1
            r9 = r7[r9]
            float r10 = r8.f245e
            float r11 = r9.f245e
            boolean r10 = a1.w.b(r10, r11)
            float r11 = r8.f246f
            float r12 = r9.f246f
            boolean r11 = a1.w.b(r11, r12)
            r12 = 0
            boolean r13 = r1[r12]
            float r14 = r8.f244d
            float r15 = r9.f244d
            boolean r14 = a1.w.b(r14, r15)
            r13 = r13 | r14
            r1[r12] = r13
            r12 = 1
            boolean r13 = r1[r12]
            r10 = r10 | r11
            r10 = r10 | r0
            r11 = r13 | r10
            r1[r12] = r11
            r11 = 2
            boolean r12 = r1[r11]
            r10 = r10 | r12
            r1[r11] = r10
            r10 = 3
            boolean r11 = r1[r10]
            float r12 = r8.f247g
            float r13 = r9.f247g
            boolean r12 = a1.w.b(r12, r13)
            r11 = r11 | r12
            r1[r10] = r11
            boolean r11 = r1[r6]
            float r8 = r8.f248h
            float r9 = r9.f248h
            boolean r8 = a1.w.b(r8, r9)
            r8 = r8 | r11
            r1[r6] = r8
            int r4 = r4 + 1
            goto L_0x0a00
        L_0x0a53:
            r0 = 0
            r4 = 1
        L_0x0a55:
            if (r4 >= r2) goto L_0x0a60
            boolean r6 = r1[r4]
            if (r6 == 0) goto L_0x0a5d
            int r0 = r0 + 1
        L_0x0a5d:
            int r4 = r4 + 1
            goto L_0x0a55
        L_0x0a60:
            int[] r4 = new int[r0]
            r3.f191o = r4
            r4 = 2
            int r0 = java.lang.Math.max(r4, r0)
            double[] r4 = new double[r0]
            r3.f192p = r4
            double[] r0 = new double[r0]
            r3.f193q = r0
            r0 = 0
            r4 = 1
        L_0x0a73:
            if (r4 >= r2) goto L_0x0a83
            boolean r6 = r1[r4]
            if (r6 == 0) goto L_0x0a80
            int[] r6 = r3.f191o
            int r8 = r0 + 1
            r6[r0] = r4
            r0 = r8
        L_0x0a80:
            int r4 = r4 + 1
            goto L_0x0a73
        L_0x0a83:
            int[] r0 = r3.f191o
            int r0 = r0.length
            int[] r0 = new int[]{r5, r0}
            java.lang.Class r1 = java.lang.Double.TYPE
            java.lang.Object r0 = java.lang.reflect.Array.newInstance(r1, r0)
            double[][] r0 = (double[][]) r0
            double[] r1 = new double[r5]
            r2 = 0
        L_0x0a95:
            if (r2 >= r5) goto L_0x0aaa
            r4 = r7[r2]
            r6 = r0[r2]
            int[] r8 = r3.f191o
            r4.c(r6, r8)
            r4 = r7[r2]
            float r4 = r4.f243c
            double r8 = (double) r4
            r1[r2] = r8
            int r2 = r2 + 1
            goto L_0x0a95
        L_0x0aaa:
            r2 = 0
        L_0x0aab:
            int[] r4 = r3.f191o
            int r6 = r4.length
            if (r2 >= r6) goto L_0x0ae0
            r4 = r4[r2]
            r6 = 6
            if (r4 >= r6) goto L_0x0add
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String[] r8 = a1.w.f240r
            int[] r9 = r3.f191o
            r9 = r9[r2]
            r8 = r8[r9]
            java.lang.String r9 = " ["
            java.lang.String r4 = a4.l.J(r4, r8, r9)
            r8 = 0
        L_0x0ac9:
            if (r8 >= r5) goto L_0x0add
            java.lang.StringBuilder r4 = f.c.o(r4)
            r9 = r0[r8]
            r10 = r9[r2]
            r4.append(r10)
            java.lang.String r4 = r4.toString()
            int r8 = r8 + 1
            goto L_0x0ac9
        L_0x0add:
            int r2 = r2 + 1
            goto L_0x0aab
        L_0x0ae0:
            java.lang.String[] r2 = r3.f194r
            int r2 = r2.length
            r4 = 1
            int r2 = r2 + r4
            v7.d9[] r2 = new v7.d9[r2]
            r3.f186j = r2
            r2 = 0
        L_0x0aea:
            java.lang.String[] r4 = r3.f194r
            int r6 = r4.length
            if (r2 >= r6) goto L_0x0b4b
            r4 = r4[r2]
            r6 = 0
            r8 = 0
            r9 = 0
            r10 = 0
        L_0x0af5:
            if (r6 >= r5) goto L_0x0b34
            r11 = r7[r6]
            java.util.LinkedHashMap r11 = r11.f254n
            boolean r11 = r11.containsKey(r4)
            if (r11 == 0) goto L_0x0b31
            if (r10 != 0) goto L_0x0b23
            double[] r9 = new double[r5]
            r10 = r7[r6]
            java.util.LinkedHashMap r10 = r10.f254n
            java.lang.Object r10 = r10.get(r4)
            c1.a r10 = (c1.a) r10
            if (r10 != 0) goto L_0x0b13
            r10 = 0
            goto L_0x0b17
        L_0x0b13:
            int r10 = r10.c()
        L_0x0b17:
            int[] r10 = new int[]{r5, r10}
            java.lang.Class r11 = java.lang.Double.TYPE
            java.lang.Object r10 = java.lang.reflect.Array.newInstance(r11, r10)
            double[][] r10 = (double[][]) r10
        L_0x0b23:
            r11 = r7[r6]
            float r12 = r11.f243c
            double r12 = (double) r12
            r9[r8] = r12
            r12 = r10[r8]
            r11.e(r4, r12)
            int r8 = r8 + 1
        L_0x0b31:
            int r6 = r6 + 1
            goto L_0x0af5
        L_0x0b34:
            double[] r4 = java.util.Arrays.copyOf(r9, r8)
            java.lang.Object[] r6 = java.util.Arrays.copyOf(r10, r8)
            double[][] r6 = (double[][]) r6
            v7.d9[] r8 = r3.f186j
            int r2 = r2 + 1
            int r9 = r3.f181e
            v7.d9 r4 = v7.d9.a(r9, r4, r6)
            r8[r2] = r4
            goto L_0x0aea
        L_0x0b4b:
            v7.d9[] r2 = r3.f186j
            int r4 = r3.f181e
            v7.d9 r0 = v7.d9.a(r4, r1, r0)
            r1 = 0
            r2[r1] = r0
            r0 = r7[r1]
            int r0 = r0.f250j
            r1 = -1
            if (r0 == r1) goto L_0x0b94
            int[] r0 = new int[r5]
            double[] r1 = new double[r5]
            r2 = 2
            int[] r2 = new int[]{r5, r2}
            java.lang.Class r4 = java.lang.Double.TYPE
            java.lang.Object r2 = java.lang.reflect.Array.newInstance(r4, r2)
            double[][] r2 = (double[][]) r2
            r9 = 0
        L_0x0b6f:
            if (r9 >= r5) goto L_0x0b8d
            r4 = r7[r9]
            int r6 = r4.f250j
            r0[r9] = r6
            float r6 = r4.f243c
            double r10 = (double) r6
            r1[r9] = r10
            r6 = r2[r9]
            float r8 = r4.f245e
            double r10 = (double) r8
            r8 = 0
            r6[r8] = r10
            float r4 = r4.f246f
            double r10 = (double) r4
            r4 = 1
            r6[r4] = r10
            int r9 = r9 + 1
            goto L_0x0b6f
        L_0x0b8d:
            v0.b r4 = new v0.b
            r4.<init>(r0, r1, r2)
            r3.f187k = r4
        L_0x0b94:
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            r3.f202z = r0
            if (r21 == 0) goto L_0x0be7
            java.util.Iterator r0 = r19.iterator()
        L_0x0ba1:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0bbc
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            z0.f r2 = z0.f.c(r1)
            if (r2 != 0) goto L_0x0bb4
            goto L_0x0ba1
        L_0x0bb4:
            r2.f30591b = r1
            java.util.HashMap r4 = r3.f202z
            r4.put(r1, r2)
            goto L_0x0ba1
        L_0x0bbc:
            java.util.Iterator r0 = r21.iterator()
        L_0x0bc0:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0bcd
            java.lang.Object r1 = r0.next()
            a1.c r1 = (a1.c) r1
            goto L_0x0bc0
        L_0x0bcd:
            java.util.HashMap r0 = r3.f202z
            java.util.Collection r0 = r0.values()
            java.util.Iterator r0 = r0.iterator()
        L_0x0bd7:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0be7
            java.lang.Object r1 = r0.next()
            z0.f r1 = (z0.f) r1
            r1.e()
            goto L_0x0bd7
        L_0x0be7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a1.n.h(int, int, long):void");
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(" start: x: ");
        w wVar = this.f182f;
        sb2.append(wVar.f245e);
        sb2.append(" y: ");
        sb2.append(wVar.f246f);
        sb2.append(" end: x: ");
        w wVar2 = this.f183g;
        sb2.append(wVar2.f245e);
        sb2.append(" y: ");
        sb2.append(wVar2.f246f);
        return sb2.toString();
    }
}
