package a1;

public interface u {
    void a(int i10);

    void b();
}
