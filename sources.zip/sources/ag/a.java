package ag;

public enum a {
    ;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: ag.a[]} */
    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Enum, ag.a] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            ag.a r0 = new ag.a
            java.lang.String r1 = "WARNING"
            r2 = 0
            r0.<init>(r1, r2)
            ag.a r1 = new ag.a
            java.lang.String r3 = "ERROR"
            r4 = 1
            r1.<init>(r3, r4)
            f806a = r1
            ag.a r3 = new ag.a
            java.lang.String r5 = "HIDDEN"
            r6 = 2
            r3.<init>(r5, r6)
            r5 = 3
            ag.a[] r5 = new ag.a[r5]
            r5[r2] = r0
            r5[r4] = r1
            r5[r6] = r3
            f807b = r5
            v7.i9.m(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ag.a.<clinit>():void");
    }
}
