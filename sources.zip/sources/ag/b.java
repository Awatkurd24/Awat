package ag;

import v7.r0;

public abstract class b implements Comparable {
    /* renamed from: a */
    public final int compareTo(Object obj) {
        r0.j("other", (b) obj);
        a aVar = a.f806a;
        return aVar.compareTo(aVar);
    }
}
