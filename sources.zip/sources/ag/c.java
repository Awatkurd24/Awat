package ag;

import gf.e;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public static final e f808a = new Object();
}
