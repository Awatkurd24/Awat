package a7;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.locks.ReentrantLock;

public final class a {

    /* renamed from: c  reason: collision with root package name */
    public static final ReentrantLock f650c = new ReentrantLock();

    /* renamed from: d  reason: collision with root package name */
    public static a f651d;

    /* renamed from: a  reason: collision with root package name */
    public final ReentrantLock f652a = new ReentrantLock();

    /* renamed from: b  reason: collision with root package name */
    public final SharedPreferences f653b;

    public a(Context context) {
        this.f653b = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    public static a a(Context context) {
        l7.a.j(context);
        ReentrantLock reentrantLock = f650c;
        reentrantLock.lock();
        try {
            if (f651d == null) {
                f651d = new a(context.getApplicationContext());
            }
            a aVar = f651d;
            reentrantLock.unlock();
            return aVar;
        } catch (Throwable th2) {
            reentrantLock.unlock();
            throw th2;
        }
    }

    public final String b(String str) {
        ReentrantLock reentrantLock = this.f652a;
        reentrantLock.lock();
        try {
            return this.f653b.getString(str, (String) null);
        } finally {
            reentrantLock.unlock();
        }
    }
}
