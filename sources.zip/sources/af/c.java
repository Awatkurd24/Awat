package af;

import we.o1;
import we.s1;

public final class c extends s1 {

    /* renamed from: c  reason: collision with root package name */
    public static final c f805c = new s1("protected_static", true);

    public final String b() {
        return "protected/*protected static*/";
    }

    public final s1 c() {
        return o1.f29347c;
    }
}
