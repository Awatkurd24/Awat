package af;

import v7.r0;
import we.j1;
import we.m1;
import we.n1;
import we.o1;
import we.r1;
import we.s1;
import yd.e;

public final class b extends s1 {

    /* renamed from: c  reason: collision with root package name */
    public static final b f804c = new s1("protected_and_package", true);

    public final Integer a(s1 s1Var) {
        int i10;
        r0.j("visibility", s1Var);
        if (r0.b(this, s1Var)) {
            return 0;
        }
        if (s1Var == j1.f29341c) {
            return null;
        }
        e eVar = r1.f29367a;
        if (s1Var == m1.f29345c || s1Var == n1.f29346c) {
            i10 = 1;
        } else {
            i10 = -1;
        }
        return Integer.valueOf(i10);
    }

    public final String b() {
        return "protected/*protected and package*/";
    }

    public final s1 c() {
        return o1.f29347c;
    }
}
