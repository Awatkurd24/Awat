package a5;

public interface a {
}
