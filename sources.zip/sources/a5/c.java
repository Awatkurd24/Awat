package a5;

import java.util.LinkedHashMap;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final LinkedHashMap f627a = new LinkedHashMap();

    /* renamed from: b  reason: collision with root package name */
    public String f628b = "";

    /* renamed from: c  reason: collision with root package name */
    public String f629c = "SCHDXUVUiJd+1EDBbi1EAVJ4IXsn+i7dgA25Wd4CRKU=";

    /* renamed from: d  reason: collision with root package name */
    public final String f630d = "UBSbqFbLWAzq+4xJNX4yAA==";

    /* renamed from: e  reason: collision with root package name */
    public final String f631e = "832367b6-5e88-441d-b41c-184a3966da9d-832367b6-5e88-441d-b41c-184a3966da9d";

    /* renamed from: f  reason: collision with root package name */
    public final String f632f = "";

    /* renamed from: g  reason: collision with root package name */
    public final boolean f633g = true;
}
