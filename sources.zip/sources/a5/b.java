package a5;

import android.content.Context;
import android.os.Handler;
import com.google.firebase.messaging.FirebaseMessaging;
import j4.a;
import j6.n;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public final /* synthetic */ class b implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f621a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Context f622b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f623c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f624d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ Object f625e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ Object f626f;

    public /* synthetic */ b(c cVar, String str, Context context, Handler handler, a aVar) {
        this.f623c = cVar;
        this.f624d = str;
        this.f622b = context;
        this.f625e = handler;
        this.f626f = aVar;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v17, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v18, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v19, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v21, resolved type: ib.w} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v21, resolved type: ib.w} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v24, resolved type: java.lang.String[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v25, resolved type: java.lang.String[]} */
    /* JADX WARNING: type inference failed for: r8v1, types: [he.t, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v23, types: [ib.w] */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object call() {
        /*
            r15 = this;
            int r0 = r15.f621a
            r1 = 0
            r2 = 0
            switch(r0) {
                case 0: goto L_0x0051;
                default: goto L_0x0007;
            }
        L_0x0007:
            android.content.Context r8 = r15.f622b
            java.lang.Object r0 = r15.f623c
            r9 = r0
            java.util.concurrent.ScheduledExecutorService r9 = (java.util.concurrent.ScheduledExecutorService) r9
            java.lang.Object r0 = r15.f624d
            r4 = r0
            com.google.firebase.messaging.FirebaseMessaging r4 = (com.google.firebase.messaging.FirebaseMessaging) r4
            java.lang.Object r0 = r15.f625e
            r5 = r0
            j6.n r5 = (j6.n) r5
            java.lang.Object r0 = r15.f626f
            r7 = r0
            pa.b r7 = (pa.b) r7
            int r0 = ib.x.f20119j
            java.lang.Class<ib.w> r0 = ib.w.class
            monitor-enter(r0)
            java.lang.ref.WeakReference r3 = ib.w.f20114d     // Catch:{ all -> 0x002d }
            if (r3 == 0) goto L_0x002f
            java.lang.Object r2 = r3.get()     // Catch:{ all -> 0x002d }
            ib.w r2 = (ib.w) r2     // Catch:{ all -> 0x002d }
            goto L_0x002f
        L_0x002d:
            r1 = move-exception
            goto L_0x004f
        L_0x002f:
            if (r2 != 0) goto L_0x0046
            java.lang.String r2 = "com.google.android.gms.appid"
            android.content.SharedPreferences r1 = r8.getSharedPreferences(r2, r1)     // Catch:{ all -> 0x002d }
            ib.w r2 = new ib.w     // Catch:{ all -> 0x002d }
            r2.<init>(r1, r9)     // Catch:{ all -> 0x002d }
            r2.b()     // Catch:{ all -> 0x002d }
            java.lang.ref.WeakReference r1 = new java.lang.ref.WeakReference     // Catch:{ all -> 0x002d }
            r1.<init>(r2)     // Catch:{ all -> 0x002d }
            ib.w.f20114d = r1     // Catch:{ all -> 0x002d }
        L_0x0046:
            r6 = r2
            monitor-exit(r0)
            ib.x r0 = new ib.x
            r3 = r0
            r3.<init>(r4, r5, r6, r7, r8, r9)
            return r0
        L_0x004f:
            monitor-exit(r0)
            throw r1
        L_0x0051:
            java.lang.Object r0 = r15.f623c
            a5.c r0 = (a5.c) r0
            java.lang.Object r3 = r15.f624d
            r7 = r3
            java.lang.String r7 = (java.lang.String) r7
            java.lang.Object r3 = r15.f625e
            android.os.Handler r3 = (android.os.Handler) r3
            java.lang.Object r4 = r15.f626f
            r5 = r4
            a5.a r5 = (a5.a) r5
            java.lang.String r4 = "this$0"
            v7.r0.j(r4, r0)
            java.lang.String r4 = "$id"
            v7.r0.j(r4, r7)
            java.lang.String r4 = "$_context"
            android.content.Context r6 = r15.f622b
            v7.r0.j(r4, r6)
            java.lang.String r4 = "$handler"
            v7.r0.j(r4, r3)
            java.lang.String r4 = "$callback"
            v7.r0.j(r4, r5)
            java.lang.String r4 = "start: executor.execute"
            java.lang.String r8 = "remotelibnrc"
            android.util.Log.i(r8, r4)
            java.lang.String r4 = r0.f629c
            java.lang.String r9 = "https:"
            boolean r4 = wg.k.b0(r4, r9)
            if (r4 == 0) goto L_0x00a3
            java.net.URL r4 = new java.net.URL
            java.lang.String r9 = r0.f629c
            r4.<init>(r9)
            java.net.URLConnection r4 = r4.openConnection()
            java.lang.String r9 = "null cannot be cast to non-null type javax.net.ssl.HttpsURLConnection"
            v7.r0.h(r9, r4)
            javax.net.ssl.HttpsURLConnection r4 = (javax.net.ssl.HttpsURLConnection) r4
        L_0x00a1:
            r10 = r4
            goto L_0x00b6
        L_0x00a3:
            java.net.URL r4 = new java.net.URL
            java.lang.String r9 = r0.f629c
            r4.<init>(r9)
            java.net.URLConnection r4 = r4.openConnection()
            java.lang.String r9 = "null cannot be cast to non-null type java.net.HttpURLConnection"
            v7.r0.h(r9, r4)
            java.net.HttpURLConnection r4 = (java.net.HttpURLConnection) r4
            goto L_0x00a1
        L_0x00b6:
            java.lang.String r4 = "POST"
            r10.setRequestMethod(r4)
            r4 = 10000(0x2710, float:1.4013E-41)
            r10.setConnectTimeout(r4)
            java.util.LinkedHashMap r4 = r0.f627a
            java.lang.String r9 = "app_id"
            r4.put(r9, r7)
            java.lang.String r9 = "0"
            java.lang.String r11 = "time"
            l7.a.B()
            android.content.SharedPreferences r12 = l7.a.f21731e
            java.lang.String r9 = r12.getString(r11, r9)
            java.lang.String r12 = "time()"
            v7.r0.i(r12, r9)
            r4.put(r11, r9)
            android.content.pm.PackageManager r9 = r6.getPackageManager()
            java.lang.String r12 = r6.getPackageName()
            android.content.pm.PackageInfo r9 = r9.getPackageInfo(r12, r1)
            java.lang.String r9 = r9.versionName
            java.lang.String r12 = "_context.packageManager.…ckageName, 0).versionName"
            v7.r0.i(r12, r9)
            java.lang.String r12 = "version"
            r4.put(r12, r9)
            boolean r9 = r0.f633g
            if (r9 == 0) goto L_0x0121
            java.lang.String r9 = "phone"
            java.lang.Object r9 = r6.getSystemService(r9)     // Catch:{ Exception -> 0x011a }
            java.lang.String r12 = "null cannot be cast to non-null type android.telephony.TelephonyManager"
            v7.r0.h(r12, r9)     // Catch:{ Exception -> 0x011a }
            android.telephony.TelephonyManager r9 = (android.telephony.TelephonyManager) r9     // Catch:{ Exception -> 0x011a }
            int r12 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x011a }
            r13 = 26
            if (r12 < r13) goto L_0x0110
            java.lang.String r9 = r9.getNetworkCountryIso()     // Catch:{ Exception -> 0x011a }
            goto L_0x0114
        L_0x0110:
            java.lang.String r9 = r9.getSimCountryIso()     // Catch:{ Exception -> 0x011a }
        L_0x0114:
            java.lang.String r12 = "{\n            val teleph…o\n            }\n        }"
            v7.r0.i(r12, r9)     // Catch:{ Exception -> 0x011a }
            goto L_0x011c
        L_0x011a:
            java.lang.String r9 = "error"
        L_0x011c:
            java.lang.String r12 = "country"
            r4.put(r12, r9)
        L_0x0121:
            java.lang.String r9 = r6.getPackageName()     // Catch:{ Exception -> 0x0143 }
            android.content.pm.PackageManager r6 = r6.getPackageManager()     // Catch:{ Exception -> 0x0143 }
            r12 = 64
            android.content.pm.PackageInfo r6 = r6.getPackageInfo(r9, r12)     // Catch:{ Exception -> 0x0143 }
            android.content.pm.Signature[] r6 = r6.signatures     // Catch:{ Exception -> 0x0143 }
            int r9 = r6.length     // Catch:{ Exception -> 0x0143 }
            java.lang.String[] r9 = new java.lang.String[r9]     // Catch:{ Exception -> 0x0143 }
            r12 = 0
        L_0x0135:
            int r13 = r6.length     // Catch:{ Exception -> 0x0143 }
            if (r12 >= r13) goto L_0x0145
            r13 = r6[r12]     // Catch:{ Exception -> 0x0143 }
            java.lang.String r13 = n9.b.a(r13)     // Catch:{ Exception -> 0x0143 }
            r9[r12] = r13     // Catch:{ Exception -> 0x0143 }
            int r12 = r12 + 1
            goto L_0x0135
        L_0x0143:
            r6 = move-exception
            goto L_0x0147
        L_0x0145:
            r2 = r9
            goto L_0x014e
        L_0x0147:
            java.lang.String r9 = "b"
            java.lang.String r12 = "Error getting app signatures"
            android.util.Log.e(r9, r12, r6)
        L_0x014e:
            java.lang.String r6 = "getAppSignatures(_context)"
            v7.r0.i(r6, r2)
            int r6 = r2.length
            r9 = 1
            if (r6 != 0) goto L_0x0159
            r6 = 1
            goto L_0x015a
        L_0x0159:
            r6 = 0
        L_0x015a:
            r6 = r6 ^ r9
            if (r6 == 0) goto L_0x0190
            int r6 = r2.length
            java.lang.Object[] r2 = java.util.Arrays.copyOf(r2, r6)
            java.lang.CharSequence[] r2 = (java.lang.CharSequence[]) r2
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            int r12 = r2.length
            if (r12 <= 0) goto L_0x0182
            r12 = r2[r1]
            r6.append(r12)
            r12 = 1
        L_0x0172:
            int r13 = r2.length
            if (r12 >= r13) goto L_0x0182
            java.lang.String r13 = ","
            r6.append(r13)
            r13 = r2[r12]
            r6.append(r13)
            int r12 = r12 + 1
            goto L_0x0172
        L_0x0182:
            java.lang.String r2 = r6.toString()
            java.lang.String r6 = "join(\",\", *hash)"
            v7.r0.i(r6, r2)
            java.lang.String r6 = "sha256"
            r4.put(r6, r2)
        L_0x0190:
            java.util.Set r2 = r4.entrySet()
            java.util.Iterator r2 = r2.iterator()
        L_0x0198:
            boolean r4 = r2.hasNext()
            if (r4 == 0) goto L_0x01b4
            java.lang.Object r4 = r2.next()
            java.util.Map$Entry r4 = (java.util.Map.Entry) r4
            java.lang.Object r6 = r4.getKey()
            java.lang.String r6 = (java.lang.String) r6
            java.lang.Object r4 = r4.getValue()
            java.lang.String r4 = (java.lang.String) r4
            r10.setRequestProperty(r6, r4)
            goto L_0x0198
        L_0x01b4:
            java.lang.String r2 = "start: header added"
            android.util.Log.i(r8, r2)
            java.lang.String r0 = r0.f632f
            int r2 = r0.length()
            if (r2 <= 0) goto L_0x01e1
            r10.setDoOutput(r9)
            java.io.OutputStream r2 = r10.getOutputStream()
            java.lang.String r4 = "connection.outputStream"
            v7.r0.i(r4, r2)
            java.nio.charset.Charset r4 = wg.a.f29463a
            byte[] r0 = r0.getBytes(r4)
            java.lang.String r4 = "this as java.lang.String).getBytes(charset)"
            v7.r0.i(r4, r0)
            r2.write(r0)
            r2.flush()
            r2.close()
        L_0x01e1:
            int r0 = r10.getResponseCode()
            java.lang.String r2 = "start: get response"
            android.util.Log.i(r8, r2)
            r2 = 200(0xc8, float:2.8E-43)
            if (r0 != r2) goto L_0x02a7
            java.io.BufferedReader r0 = new java.io.BufferedReader
            java.io.InputStreamReader r2 = new java.io.InputStreamReader
            java.io.InputStream r4 = r10.getInputStream()
            r2.<init>(r4)
            r0.<init>(r2)
            java.lang.String r2 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.v1(r0)
            org.json.JSONObject r4 = new org.json.JSONObject
            r4.<init>(r2)
            java.lang.String r2 = "status"
            boolean r2 = r4.getBoolean(r2)
            if (r2 == 0) goto L_0x029f
            java.lang.String r2 = "data"
            java.lang.String r4 = r4.getString(r2)
            he.t r8 = new he.t
            r8.<init>()
            java.lang.String r6 = "cached"
            boolean r6 = r4.equals(r6)
            if (r6 == 0) goto L_0x022d
            java.lang.String r4 = ""
            l7.a.B()
            android.content.SharedPreferences r6 = l7.a.f21731e
            java.lang.String r4 = r6.getString(r2, r4)
            r8.f19688a = r9
        L_0x022d:
            org.json.JSONArray r12 = new org.json.JSONArray
            r12.<init>(r4)
            java.util.LinkedHashMap r6 = new java.util.LinkedHashMap
            r6.<init>()
            int r4 = r12.length()
            me.c r1 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.j2(r1, r4)
            me.b r1 = r1.iterator()
        L_0x0243:
            boolean r4 = r1.f22699c
            if (r4 == 0) goto L_0x0265
            int r4 = r1.b()
            org.json.JSONObject r4 = r12.getJSONObject(r4)
            java.lang.String r9 = "key"
            java.lang.String r13 = r4.getString(r9)
            java.lang.String r14 = "value"
            java.lang.String r4 = r4.getString(r14)
            v7.r0.i(r9, r13)
            v7.r0.i(r14, r4)
            r6.put(r13, r4)
            goto L_0x0243
        L_0x0265:
            java.lang.String r1 = "last_update_date"
            java.lang.Object r1 = r6.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            l7.a.B()
            android.content.SharedPreferences$Editor r4 = l7.a.f21732f
            r4.putString(r11, r1)
            l7.a.B()
            android.content.SharedPreferences$Editor r1 = l7.a.f21732f
            r1.commit()
            t.s r1 = new t.s
            r9 = 6
            r4 = r1
            r4.<init>(r5, r6, r7, r8, r9)
            r3.post(r1)
            java.lang.String r1 = r12.toString()
            l7.a.B()
            android.content.SharedPreferences$Editor r3 = l7.a.f21732f
            r3.putString(r2, r1)
            l7.a.B()
            android.content.SharedPreferences$Editor r1 = l7.a.f21732f
            r1.commit()
            r0.close()
            goto L_0x02ae
        L_0x029f:
            java.lang.String r0 = "Status is false"
        L_0x02a1:
            j4.a r5 = (j4.a) r5
            r5.a(r0)
            goto L_0x02ae
        L_0x02a7:
            java.lang.String r1 = "Server connection error: "
            java.lang.String r0 = f.c.n(r1, r0)
            goto L_0x02a1
        L_0x02ae:
            r10.disconnect()
            wd.m r0 = wd.m.f29306a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.b.call():java.lang.Object");
    }

    public /* synthetic */ b(Context context, n nVar, pa.b bVar, FirebaseMessaging firebaseMessaging, ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        this.f622b = context;
        this.f623c = scheduledThreadPoolExecutor;
        this.f624d = firebaseMessaging;
        this.f625e = nVar;
        this.f626f = bVar;
    }
}
