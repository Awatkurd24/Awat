package a3;

public abstract class w {
}
