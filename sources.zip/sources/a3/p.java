package a3;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Messenger;
import android.util.Log;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import java.util.ArrayList;
import mb.q0;
import o9.l;
import o9.m;
import o9.n;
import s9.g;
import s9.h;
import s9.i;
import v7.h9;
import v7.r0;
import zd.e;
import zd.j;

public final class p implements ServiceConnection {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f482a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f483b;

    public /* synthetic */ p(int i10, Object obj) {
        this.f482a = i10;
        this.f483b = obj;
    }

    /* JADX WARNING: type inference failed for: r6v7, types: [a3.h, java.lang.Object] */
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        i iVar;
        int i10 = this.f482a;
        Object obj = this.f483b;
        switch (i10) {
            case 0:
                r0.j("name", componentName);
                r0.j("service", iBinder);
                q qVar = (q) obj;
                int i11 = r.f494b;
                IInterface queryLocalInterface = iBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
                if (queryLocalInterface == null || !(queryLocalInterface instanceof i)) {
                    ? obj2 = new Object();
                    obj2.f453a = iBinder;
                    iVar = obj2;
                } else {
                    iVar = (i) queryLocalInterface;
                }
                qVar.f489f = iVar;
                qVar.f486c.execute(qVar.f492i);
                return;
            case 1:
                n nVar = (n) obj;
                nVar.f23722b.d("ServiceConnectionImpl.onServiceConnected(%s)", componentName);
                nVar.a().post(new m(this, iBinder));
                return;
            case 2:
                i iVar2 = (i) obj;
                iVar2.f25915b.d("ServiceConnectionImpl.onServiceConnected(%s)", componentName);
                iVar2.a().post(new g(this, iBinder));
                return;
            default:
                StringBuilder sb2 = new StringBuilder("Connected to SessionLifecycleService. Queue size ");
                mb.r0 r0Var = (mb.r0) obj;
                sb2.append(r0Var.f22630c.size());
                Log.d("SessionLifecycleClient", sb2.toString());
                r0Var.f22629b = new Messenger(iBinder);
                ArrayList arrayList = new ArrayList();
                r0Var.f22630c.drainTo(arrayList);
                b0.g1(h9.c(r0Var.f22628a), (j) null, new q0(r0Var, arrayList, (e) null), 3);
                return;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        int i10 = this.f482a;
        Object obj = this.f483b;
        switch (i10) {
            case 0:
                r0.j("name", componentName);
                q qVar = (q) obj;
                qVar.f486c.execute(qVar.f493j);
                qVar.f489f = null;
                return;
            case 1:
                n nVar = (n) obj;
                nVar.f23722b.d("ServiceConnectionImpl.onServiceDisconnected(%s)", componentName);
                nVar.a().post(new l(1, this));
                return;
            case 2:
                i iVar = (i) obj;
                iVar.f25915b.d("ServiceConnectionImpl.onServiceDisconnected(%s)", componentName);
                iVar.a().post(new h(1, this));
                return;
            default:
                Log.d("SessionLifecycleClient", "Disconnected from SessionLifecycleService");
                ((mb.r0) obj).f22629b = null;
                return;
        }
    }

    public /* synthetic */ p(Object obj, int i10) {
        this.f482a = i10;
        this.f483b = obj;
    }
}
