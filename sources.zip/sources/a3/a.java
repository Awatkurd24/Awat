package a3;

import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import ge.b;
import he.l;
import io.tooldroid.dialog.ToolDroidDialog;
import mf.c;
import mf.i;
import mf.o;
import v7.r0;
import wd.m;

public final class a extends l implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f425a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f426b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(String str, int i10) {
        super(1);
        this.f425a = i10;
        this.f426b = str;
    }

    public final void a(o oVar) {
        int i10 = this.f425a;
        String str = this.f426b;
        switch (i10) {
            case 1:
                r0.j("$this$function", oVar);
                c cVar = i.f22732b;
                oVar.a(str, cVar, cVar);
                return;
            case 2:
                r0.j("$this$function", oVar);
                oVar.a(str, i.f22732b);
                return;
            case 3:
                r0.j("$this$function", oVar);
                c cVar2 = i.f22732b;
                oVar.a(str, cVar2);
                oVar.a(str, cVar2);
                return;
            case 4:
                r0.j("$this$function", oVar);
                c cVar3 = i.f22732b;
                oVar.a(str, cVar3);
                oVar.c(str, cVar3);
                return;
            case 5:
                r0.j("$this$function", oVar);
                c cVar4 = i.f22732b;
                oVar.a(str, cVar4);
                oVar.a(str, cVar4);
                oVar.c(str, cVar4);
                return;
            case 6:
                r0.j("$this$function", oVar);
                oVar.c(str, i.f22732b);
                return;
            case 7:
                r0.j("$this$function", oVar);
                c cVar5 = i.f22732b;
                oVar.a(str, cVar5, cVar5);
                oVar.b(cg.c.BOOLEAN);
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                r0.j("$this$function", oVar);
                c cVar6 = i.f22732b;
                oVar.c(str, cVar6, cVar6);
                return;
            case 9:
                r0.j("$this$function", oVar);
                c cVar7 = i.f22732b;
                oVar.c(str, cVar7, cVar7);
                return;
            case 10:
                r0.j("$this$function", oVar);
                c cVar8 = i.f22732b;
                oVar.a(str, cVar8, cVar8);
                return;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                r0.j("$this$function", oVar);
                c cVar9 = i.f22732b;
                oVar.a(str, cVar9, cVar9, cVar9);
                return;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                r0.j("$this$function", oVar);
                c cVar10 = i.f22732b;
                oVar.a(str, cVar10);
                oVar.a(str, cVar10);
                oVar.c(str, i.f22731a);
                return;
            case 13:
                r0.j("$this$function", oVar);
                c cVar11 = i.f22732b;
                oVar.a(str, cVar11);
                oVar.a(str, cVar11);
                oVar.c(str, i.f22731a);
                return;
            case 14:
                r0.j("$this$function", oVar);
                c cVar12 = i.f22732b;
                oVar.a(str, cVar12);
                oVar.a(str, cVar12);
                oVar.a(str, cVar12);
                oVar.b(cg.c.BOOLEAN);
                return;
            case 15:
                r0.j("$this$function", oVar);
                c cVar13 = i.f22732b;
                oVar.a(str, cVar13, cVar13, cVar13, cVar13);
                return;
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                r0.j("$this$function", oVar);
                oVar.c(str, i.f22732b, i.f22733c);
                return;
            case ToolDroidDialog.CENTER /*17*/:
                r0.j("$this$function", oVar);
                oVar.c(str, i.f22733c);
                return;
            case 18:
                r0.j("$this$function", oVar);
                oVar.a(str, i.f22732b, i.f22733c);
                return;
            case 19:
                r0.j("$this$function", oVar);
                oVar.c(str, i.f22731a);
                return;
            case 20:
                r0.j("$this$function", oVar);
                oVar.a(str, i.f22732b);
                oVar.b(cg.c.BOOLEAN);
                return;
            default:
                r0.j("$this$function", oVar);
                c cVar14 = i.f22732b;
                oVar.a(str, cVar14);
                oVar.a(str, cVar14);
                oVar.b(cg.c.BOOLEAN);
                return;
        }
    }

    public final Object h(Object obj) {
        m mVar = m.f29306a;
        switch (this.f425a) {
            case 1:
                a((o) obj);
                return mVar;
            case 2:
                a((o) obj);
                return mVar;
            case 3:
                a((o) obj);
                return mVar;
            case 4:
                a((o) obj);
                return mVar;
            case 5:
                a((o) obj);
                return mVar;
            case 6:
                a((o) obj);
                return mVar;
            case 7:
                a((o) obj);
                return mVar;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                a((o) obj);
                return mVar;
            case 9:
                a((o) obj);
                return mVar;
            case 10:
                a((o) obj);
                return mVar;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                a((o) obj);
                return mVar;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                a((o) obj);
                return mVar;
            case 13:
                a((o) obj);
                return mVar;
            case 14:
                a((o) obj);
                return mVar;
            case 15:
                a((o) obj);
                return mVar;
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                a((o) obj);
                return mVar;
            case ToolDroidDialog.CENTER /*17*/:
                a((o) obj);
                return mVar;
            case 18:
                a((o) obj);
                return mVar;
            case 19:
                a((o) obj);
                return mVar;
            case 20:
                a((o) obj);
                return mVar;
            case 21:
                a((o) obj);
                return mVar;
            default:
                String str = (String) obj;
                r0.j("line", str);
                return a4.l.J(new StringBuilder(), this.f426b, str);
        }
    }
}
