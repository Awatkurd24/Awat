package a3;

import java.util.Arrays;
import v7.r0;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public final long[] f454a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean[] f455b;

    /* renamed from: c  reason: collision with root package name */
    public final int[] f456c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f457d;

    public j(int i10) {
        this.f454a = new long[i10];
        this.f455b = new boolean[i10];
        this.f456c = new int[i10];
    }

    public final int[] a() {
        synchronized (this) {
            try {
                if (!this.f457d) {
                    return null;
                }
                long[] jArr = this.f454a;
                int length = jArr.length;
                int i10 = 0;
                int i11 = 0;
                while (i10 < length) {
                    int i12 = i11 + 1;
                    int i13 = 1;
                    boolean z4 = jArr[i10] > 0;
                    boolean[] zArr = this.f455b;
                    if (z4 != zArr[i11]) {
                        int[] iArr = this.f456c;
                        if (!z4) {
                            i13 = 2;
                        }
                        iArr[i11] = i13;
                    } else {
                        this.f456c[i11] = 0;
                    }
                    zArr[i11] = z4;
                    i10++;
                    i11 = i12;
                }
                this.f457d = false;
                int[] iArr2 = (int[]) this.f456c.clone();
                return iArr2;
            } finally {
            }
        }
    }

    public final boolean b(int... iArr) {
        boolean z4;
        r0.j("tableIds", iArr);
        synchronized (this) {
            z4 = false;
            for (int i10 : iArr) {
                long[] jArr = this.f454a;
                long j3 = jArr[i10];
                jArr[i10] = 1 + j3;
                if (j3 == 0) {
                    z4 = true;
                    this.f457d = true;
                }
            }
        }
        return z4;
    }

    public final boolean c(int... iArr) {
        boolean z4;
        r0.j("tableIds", iArr);
        synchronized (this) {
            z4 = false;
            for (int i10 : iArr) {
                long[] jArr = this.f454a;
                long j3 = jArr[i10];
                jArr[i10] = j3 - 1;
                if (j3 == 1) {
                    z4 = true;
                    this.f457d = true;
                }
            }
        }
        return z4;
    }

    public final void d() {
        synchronized (this) {
            Arrays.fill(this.f455b, false);
            this.f457d = true;
        }
    }
}
