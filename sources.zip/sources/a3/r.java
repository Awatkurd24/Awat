package a3;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.MultiInstanceInvalidationService;
import v7.r0;

public final class r extends Binder implements i {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ int f494b = 0;

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MultiInstanceInvalidationService f495a;

    public r(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f495a = multiInstanceInvalidationService;
        attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
    }

    public final int M0(g gVar, String str) {
        r0.j("callback", gVar);
        int i10 = 0;
        if (str == null) {
            return 0;
        }
        MultiInstanceInvalidationService multiInstanceInvalidationService = this.f495a;
        synchronized (multiInstanceInvalidationService.f3052c) {
            try {
                int i11 = multiInstanceInvalidationService.f3050a + 1;
                multiInstanceInvalidationService.f3050a = i11;
                if (multiInstanceInvalidationService.f3052c.register(gVar, Integer.valueOf(i11))) {
                    multiInstanceInvalidationService.f3051b.put(Integer.valueOf(i11), str);
                    i10 = i11;
                } else {
                    multiInstanceInvalidationService.f3050a--;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return i10;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [a3.f, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v8, types: [a3.f, java.lang.Object] */
    /* renamed from: Y */
    public final boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 >= 1 && i10 <= 16777215) {
            parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
        }
        if (i10 != 1598968902) {
            g gVar = null;
            if (i10 == 1) {
                IBinder readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    Object queryLocalInterface = readStrongBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
                    if (queryLocalInterface == null || !(queryLocalInterface instanceof g)) {
                        ? obj = new Object();
                        obj.f452a = readStrongBinder;
                        gVar = obj;
                    } else {
                        gVar = (g) queryLocalInterface;
                    }
                }
                int M0 = M0(gVar, parcel.readString());
                parcel2.writeNoException();
                parcel2.writeInt(M0);
            } else if (i10 == 2) {
                IBinder readStrongBinder2 = parcel.readStrongBinder();
                if (readStrongBinder2 != null) {
                    Object queryLocalInterface2 = readStrongBinder2.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
                    if (queryLocalInterface2 == null || !(queryLocalInterface2 instanceof g)) {
                        ? obj2 = new Object();
                        obj2.f452a = readStrongBinder2;
                        gVar = obj2;
                    } else {
                        gVar = (g) queryLocalInterface2;
                    }
                }
                int readInt = parcel.readInt();
                r0.j("callback", gVar);
                MultiInstanceInvalidationService multiInstanceInvalidationService = this.f495a;
                synchronized (multiInstanceInvalidationService.f3052c) {
                    multiInstanceInvalidationService.f3052c.unregister(gVar);
                    String str = (String) multiInstanceInvalidationService.f3051b.remove(Integer.valueOf(readInt));
                }
                parcel2.writeNoException();
            } else if (i10 != 3) {
                return super.onTransact(i10, parcel, parcel2, i11);
            } else {
                Z2(parcel.createStringArray(), parcel.readInt());
            }
            return true;
        }
        parcel2.writeString("androidx.room.IMultiInstanceInvalidationService");
        return true;
    }

    public final void Z2(String[] strArr, int i10) {
        r0.j("tables", strArr);
        MultiInstanceInvalidationService multiInstanceInvalidationService = this.f495a;
        synchronized (multiInstanceInvalidationService.f3052c) {
            String str = (String) multiInstanceInvalidationService.f3051b.get(Integer.valueOf(i10));
            if (str == null) {
                Log.w("ROOM", "Remote invalidation client ID not registered");
                return;
            }
            int beginBroadcast = multiInstanceInvalidationService.f3052c.beginBroadcast();
            int i11 = 0;
            while (i11 < beginBroadcast) {
                try {
                    Object broadcastCookie = multiInstanceInvalidationService.f3052c.getBroadcastCookie(i11);
                    r0.h("null cannot be cast to non-null type kotlin.Int", broadcastCookie);
                    int intValue = ((Integer) broadcastCookie).intValue();
                    String str2 = (String) multiInstanceInvalidationService.f3051b.get(Integer.valueOf(intValue));
                    if (i10 != intValue && r0.b(str, str2)) {
                        try {
                            ((g) multiInstanceInvalidationService.f3052c.getBroadcastItem(i11)).K1(strArr);
                        } catch (RemoteException e10) {
                            Log.w("ROOM", "Error invoking a remote callback", e10);
                        }
                    }
                    i11++;
                } catch (Throwable th2) {
                    multiInstanceInvalidationService.f3052c.finishBroadcast();
                    throw th2;
                }
            }
            multiInstanceInvalidationService.f3052c.finishBroadcast();
        }
    }

    public final IBinder asBinder() {
        return this;
    }
}
