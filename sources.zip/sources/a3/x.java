package a3;

import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import f3.b;
import f3.f;
import f3.h;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import v7.r0;
import xd.q;
import xd.r;
import xd.s;

public abstract class x {

    /* renamed from: a  reason: collision with root package name */
    public volatile b f516a;

    /* renamed from: b  reason: collision with root package name */
    public Executor f517b;

    /* renamed from: c  reason: collision with root package name */
    public f f518c;

    /* renamed from: d  reason: collision with root package name */
    public final l f519d = d();

    /* renamed from: e  reason: collision with root package name */
    public boolean f520e;

    /* renamed from: f  reason: collision with root package name */
    public List f521f;

    /* renamed from: g  reason: collision with root package name */
    public final LinkedHashMap f522g = new LinkedHashMap();

    /* renamed from: h  reason: collision with root package name */
    public final ReentrantReadWriteLock f523h = new ReentrantReadWriteLock();

    /* renamed from: i  reason: collision with root package name */
    public final ThreadLocal f524i = new ThreadLocal();

    /* renamed from: j  reason: collision with root package name */
    public final LinkedHashMap f525j;

    public x() {
        r0.i("synchronizedMap(mutableMapOf())", Collections.synchronizedMap(new LinkedHashMap()));
        this.f525j = new LinkedHashMap();
    }

    public static Object o(Class cls, f fVar) {
        if (cls.isInstance(fVar)) {
            return fVar;
        }
        if (fVar instanceof d) {
            return o(cls, ((d) fVar).a());
        }
        return null;
    }

    public final void a() {
        boolean z4;
        if (!this.f520e) {
            if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
                z4 = true;
            } else {
                z4 = false;
            }
            if (!(!z4)) {
                throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.".toString());
            }
        }
    }

    public final void b() {
        if (!g().K().x() && this.f524i.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.".toString());
        }
    }

    public final void c() {
        a();
        a();
        b K = g().K();
        this.f519d.d(K);
        if (K.A()) {
            K.F();
        } else {
            K.f();
        }
    }

    public abstract l d();

    public abstract f e(c cVar);

    public List f(LinkedHashMap linkedHashMap) {
        r0.j("autoMigrationSpecs", linkedHashMap);
        return q.f29842a;
    }

    public final f g() {
        f fVar = this.f518c;
        if (fVar != null) {
            return fVar;
        }
        r0.D("internalOpenHelper");
        throw null;
    }

    public Set h() {
        return s.f29844a;
    }

    public Map i() {
        return r.f29843a;
    }

    public final void j() {
        g().K().e();
        if (!g().K().x()) {
            l lVar = this.f519d;
            if (lVar.f468f.compareAndSet(false, true)) {
                Executor executor = lVar.f463a.f517b;
                if (executor != null) {
                    executor.execute(lVar.f475m);
                } else {
                    r0.D("internalQueryExecutor");
                    throw null;
                }
            }
        }
    }

    public final boolean k() {
        b bVar = this.f516a;
        return r0.b(bVar != null ? Boolean.valueOf(bVar.isOpen()) : null, Boolean.TRUE);
    }

    public final Cursor l(h hVar, CancellationSignal cancellationSignal) {
        a();
        b();
        return cancellationSignal != null ? g().K().M(hVar, cancellationSignal) : g().K().o(hVar);
    }

    public final Object m(Callable callable) {
        c();
        try {
            Object call = callable.call();
            n();
            return call;
        } finally {
            j();
        }
    }

    public final void n() {
        g().K().E();
    }
}
