package a3;

import android.content.Context;
import android.content.Intent;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import v7.r0;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public final String f484a;

    /* renamed from: b  reason: collision with root package name */
    public final l f485b;

    /* renamed from: c  reason: collision with root package name */
    public final Executor f486c;

    /* renamed from: d  reason: collision with root package name */
    public int f487d;

    /* renamed from: e  reason: collision with root package name */
    public final n f488e;

    /* renamed from: f  reason: collision with root package name */
    public i f489f;

    /* renamed from: g  reason: collision with root package name */
    public final o f490g = new o(this);

    /* renamed from: h  reason: collision with root package name */
    public final AtomicBoolean f491h = new AtomicBoolean(false);

    /* renamed from: i  reason: collision with root package name */
    public final m f492i;

    /* renamed from: j  reason: collision with root package name */
    public final m f493j;

    public q(Context context, String str, Intent intent, l lVar, Executor executor) {
        this.f484a = str;
        this.f485b = lVar;
        this.f486c = executor;
        Context applicationContext = context.getApplicationContext();
        p pVar = new p(0, (Object) this);
        this.f492i = new m(this, 0);
        this.f493j = new m(this, 1);
        Object[] array = lVar.f466d.keySet().toArray(new String[0]);
        r0.h("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>", array);
        this.f488e = new n(this, (String[]) array);
        applicationContext.bindService(intent, pVar, 1);
    }
}
