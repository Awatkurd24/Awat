package a3;

import android.os.IBinder;
import android.os.Parcel;

public final class h implements i {

    /* renamed from: a  reason: collision with root package name */
    public IBinder f453a;

    public final int M0(g gVar, String str) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
            obtain.writeStrongInterface(gVar);
            obtain.writeString(str);
            this.f453a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            return obtain2.readInt();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public final void Z2(String[] strArr, int i10) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
            obtain.writeInt(i10);
            obtain.writeStringArray(strArr);
            this.f453a.transact(3, obtain, (Parcel) null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f453a;
    }
}
