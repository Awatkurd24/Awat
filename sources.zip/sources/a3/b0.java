package a3;

import f3.f;

public abstract class b0 implements f, d {
}
