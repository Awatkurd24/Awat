package a3;

import android.os.IInterface;

public interface g extends IInterface {
    void K1(String[] strArr);
}
