package a3;

import f3.f;

public abstract class b implements f, d {
}
