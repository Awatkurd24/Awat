package a3;

import android.database.sqlite.SQLiteProgram;
import f3.g;
import java.util.List;
import v7.r0;

public class u implements g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f497a = 1;

    /* renamed from: b  reason: collision with root package name */
    public final Object f498b;

    public u(SQLiteProgram sQLiteProgram) {
        r0.j("delegate", sQLiteProgram);
        this.f498b = sQLiteProgram;
    }

    public final void D(int i10, long j3) {
        switch (this.f497a) {
            case 0:
                d(i10, Long.valueOf(j3));
                return;
            default:
                ((SQLiteProgram) this.f498b).bindLong(i10, j3);
                return;
        }
    }

    public final void G(int i10, byte[] bArr) {
        switch (this.f497a) {
            case 0:
                d(i10, bArr);
                return;
            default:
                ((SQLiteProgram) this.f498b).bindBlob(i10, bArr);
                return;
        }
    }

    public final void a(double d10, int i10) {
        switch (this.f497a) {
            case 0:
                d(i10, Double.valueOf(d10));
                return;
            default:
                ((SQLiteProgram) this.f498b).bindDouble(i10, d10);
                return;
        }
    }

    public final void close() {
        switch (this.f497a) {
            case 0:
                return;
            default:
                ((SQLiteProgram) this.f498b).close();
                return;
        }
    }

    public final void d(int i10, Object obj) {
        int size;
        int i11 = i10 - 1;
        Object obj2 = this.f498b;
        if (i11 >= ((List) obj2).size() && (size = ((List) obj2).size()) <= i11) {
            while (true) {
                ((List) obj2).add((Object) null);
                if (size == i11) {
                    break;
                }
                size++;
            }
        }
        ((List) obj2).set(i11, obj);
    }

    public final void m(int i10, String str) {
        switch (this.f497a) {
            case 0:
                r0.j("value", str);
                d(i10, str);
                return;
            default:
                r0.j("value", str);
                ((SQLiteProgram) this.f498b).bindString(i10, str);
                return;
        }
    }

    public final void t(int i10) {
        switch (this.f497a) {
            case 0:
                d(i10, (Object) null);
                return;
            default:
                ((SQLiteProgram) this.f498b).bindNull(i10);
                return;
        }
    }
}
