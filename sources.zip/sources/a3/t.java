package a3;

import f3.b;

public abstract class t implements b {
}
