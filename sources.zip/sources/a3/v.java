package a3;

import android.content.Context;
import androidx.work.impl.WorkDatabase;
import b3.a;
import f3.e;
import h.z;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.concurrent.Executor;
import v7.r0;

public final class v {

    /* renamed from: a  reason: collision with root package name */
    public final Context f499a;

    /* renamed from: b  reason: collision with root package name */
    public final Class f500b = WorkDatabase.class;

    /* renamed from: c  reason: collision with root package name */
    public final String f501c;

    /* renamed from: d  reason: collision with root package name */
    public final ArrayList f502d;

    /* renamed from: e  reason: collision with root package name */
    public final ArrayList f503e;

    /* renamed from: f  reason: collision with root package name */
    public final ArrayList f504f;

    /* renamed from: g  reason: collision with root package name */
    public Executor f505g;

    /* renamed from: h  reason: collision with root package name */
    public Executor f506h;

    /* renamed from: i  reason: collision with root package name */
    public e f507i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f508j;

    /* renamed from: k  reason: collision with root package name */
    public final int f509k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f510l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f511m;

    /* renamed from: n  reason: collision with root package name */
    public final long f512n;

    /* renamed from: o  reason: collision with root package name */
    public final z f513o;

    /* renamed from: p  reason: collision with root package name */
    public final LinkedHashSet f514p;

    /* renamed from: q  reason: collision with root package name */
    public HashSet f515q;

    public v(Context context, String str) {
        this.f499a = context;
        this.f501c = str;
        this.f502d = new ArrayList();
        this.f503e = new ArrayList();
        this.f504f = new ArrayList();
        this.f509k = 1;
        this.f510l = true;
        this.f512n = -1;
        this.f513o = new z(12);
        this.f514p = new LinkedHashSet();
    }

    public final void a(a... aVarArr) {
        if (this.f515q == null) {
            this.f515q = new HashSet();
        }
        for (a aVar : aVarArr) {
            HashSet hashSet = this.f515q;
            r0.g(hashSet);
            hashSet.add(Integer.valueOf(aVar.f3501a));
            HashSet hashSet2 = this.f515q;
            r0.g(hashSet2);
            hashSet2.add(Integer.valueOf(aVar.f3502b));
        }
        this.f513o.a((a[]) Arrays.copyOf(aVarArr, aVarArr.length));
    }
}
