package a3;

import android.os.IInterface;

public interface i extends IInterface {
    int M0(g gVar, String str);

    void Z2(String[] strArr, int i10);
}
