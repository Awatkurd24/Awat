package a3;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import i1.m;
import v7.r0;

public final class o extends Binder implements g {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ int f480b = 0;

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f481a;

    public o(q qVar) {
        this.f481a = qVar;
        attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
    }

    public final void K1(String[] strArr) {
        r0.j("tables", strArr);
        q qVar = this.f481a;
        qVar.f486c.execute(new m(qVar, 5, strArr));
    }

    /* renamed from: Y */
    public final boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 >= 1 && i10 <= 16777215) {
            parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback");
        }
        if (i10 == 1598968902) {
            parcel2.writeString("androidx.room.IMultiInstanceInvalidationCallback");
            return true;
        } else if (i10 != 1) {
            return super.onTransact(i10, parcel, parcel2, i11);
        } else {
            K1(parcel.createStringArray());
            return true;
        }
    }

    public final IBinder asBinder() {
        return this;
    }
}
