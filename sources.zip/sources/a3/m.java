package a3;

import android.os.RemoteException;
import android.util.Log;
import java.util.Arrays;
import v7.r0;

public final /* synthetic */ class m implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f476a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ q f477b;

    public /* synthetic */ m(q qVar, int i10) {
        this.f476a = i10;
        this.f477b = qVar;
    }

    public final void run() {
        k kVar;
        switch (this.f476a) {
            case 0:
                q qVar = this.f477b;
                r0.j("this$0", qVar);
                try {
                    i iVar = qVar.f489f;
                    if (iVar != null) {
                        qVar.f487d = iVar.M0(qVar.f490g, qVar.f484a);
                        l lVar = qVar.f485b;
                        n nVar = qVar.f488e;
                        if (nVar != null) {
                            lVar.a(nVar);
                            return;
                        } else {
                            r0.D("observer");
                            throw null;
                        }
                    } else {
                        return;
                    }
                } catch (RemoteException e10) {
                    Log.w("ROOM", "Cannot register multi-instance invalidation callback", e10);
                    return;
                }
            default:
                q qVar2 = this.f477b;
                r0.j("this$0", qVar2);
                l lVar2 = qVar2.f485b;
                n nVar2 = qVar2.f488e;
                if (nVar2 != null) {
                    lVar2.getClass();
                    synchronized (lVar2.f472j) {
                        kVar = (k) lVar2.f472j.i(nVar2);
                    }
                    if (kVar != null) {
                        j jVar = lVar2.f471i;
                        int[] iArr = kVar.f459b;
                        if (jVar.c(Arrays.copyOf(iArr, iArr.length))) {
                            x xVar = lVar2.f463a;
                            if (xVar.k()) {
                                lVar2.d(xVar.g().K());
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    return;
                }
                r0.D("observer");
                throw null;
        }
    }
}
