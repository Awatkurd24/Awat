package a3;

import android.os.RemoteException;
import android.util.Log;
import java.util.Set;
import v7.r0;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public final String[] f478a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ q f479b;

    public n(q qVar, String[] strArr) {
        this.f479b = qVar;
        this.f478a = strArr;
    }

    public final void a(Set set) {
        r0.j("tables", set);
        q qVar = this.f479b;
        if (!qVar.f491h.get()) {
            try {
                i iVar = qVar.f489f;
                if (iVar != null) {
                    int i10 = qVar.f487d;
                    Object[] array = set.toArray(new String[0]);
                    r0.h("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>", array);
                    iVar.Z2((String[]) array, i10);
                }
            } catch (RemoteException e10) {
                Log.w("ROOM", "Cannot broadcast invalidation", e10);
            }
        }
    }
}
