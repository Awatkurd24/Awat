package a3;

import java.util.Set;
import v7.f9;
import v7.r0;
import xd.s;
import yd.h;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public final n f458a;

    /* renamed from: b  reason: collision with root package name */
    public final int[] f459b;

    /* renamed from: c  reason: collision with root package name */
    public final String[] f460c;

    /* renamed from: d  reason: collision with root package name */
    public final Set f461d;

    public k(n nVar, int[] iArr, String[] strArr) {
        this.f458a = nVar;
        this.f459b = iArr;
        this.f460c = strArr;
        this.f461d = (strArr.length == 0) ^ true ? f9.o(strArr[0]) : s.f29844a;
        if (iArr.length != strArr.length) {
            throw new IllegalStateException("Check failed.".toString());
        }
    }

    public final void a(Set set) {
        r0.j("invalidatedTablesIds", set);
        int[] iArr = this.f459b;
        int length = iArr.length;
        Set set2 = s.f29844a;
        if (length != 0) {
            int i10 = 0;
            if (length != 1) {
                h hVar = new h();
                int length2 = iArr.length;
                int i11 = 0;
                while (i10 < length2) {
                    int i12 = i11 + 1;
                    if (set.contains(Integer.valueOf(iArr[i10]))) {
                        hVar.add(this.f460c[i11]);
                    }
                    i10++;
                    i11 = i12;
                }
                set2 = f9.a(hVar);
            } else if (set.contains(Integer.valueOf(iArr[0]))) {
                set2 = this.f461d;
            }
        }
        if (!set2.isEmpty()) {
            this.f458a.a(set2);
        }
    }
}
