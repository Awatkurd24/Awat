package a3;

import android.content.Context;
import android.content.Intent;
import f3.e;
import h.z;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import v7.r0;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final Context f436a;

    /* renamed from: b  reason: collision with root package name */
    public final String f437b;

    /* renamed from: c  reason: collision with root package name */
    public final e f438c;

    /* renamed from: d  reason: collision with root package name */
    public final z f439d;

    /* renamed from: e  reason: collision with root package name */
    public final List f440e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f441f;

    /* renamed from: g  reason: collision with root package name */
    public final int f442g;

    /* renamed from: h  reason: collision with root package name */
    public final Executor f443h;

    /* renamed from: i  reason: collision with root package name */
    public final Executor f444i;

    /* renamed from: j  reason: collision with root package name */
    public final Intent f445j = null;

    /* renamed from: k  reason: collision with root package name */
    public final boolean f446k;

    /* renamed from: l  reason: collision with root package name */
    public final boolean f447l;

    /* renamed from: m  reason: collision with root package name */
    public final Set f448m;

    /* renamed from: n  reason: collision with root package name */
    public final Callable f449n;

    /* renamed from: o  reason: collision with root package name */
    public final List f450o;

    /* renamed from: p  reason: collision with root package name */
    public final List f451p;

    public c(Context context, String str, e eVar, z zVar, ArrayList arrayList, boolean z4, int i10, Executor executor, Executor executor2, boolean z10, boolean z11, LinkedHashSet linkedHashSet, ArrayList arrayList2, ArrayList arrayList3) {
        r0.j("context", context);
        r0.j("migrationContainer", zVar);
        f.c.x("journalMode", i10);
        r0.j("typeConverters", arrayList2);
        r0.j("autoMigrationSpecs", arrayList3);
        this.f436a = context;
        this.f437b = str;
        this.f438c = eVar;
        this.f439d = zVar;
        this.f440e = arrayList;
        this.f441f = z4;
        this.f442g = i10;
        this.f443h = executor;
        this.f444i = executor2;
        this.f446k = z10;
        this.f447l = z11;
        this.f448m = linkedHashSet;
        this.f450o = arrayList2;
        this.f451p = arrayList3;
    }

    public final boolean a(int i10, int i11) {
        if ((i10 > i11 && this.f447l) || !this.f446k) {
            return false;
        }
        Set set = this.f448m;
        return set == null || !set.contains(Integer.valueOf(i10));
    }
}
