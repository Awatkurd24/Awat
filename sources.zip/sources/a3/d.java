package a3;

import f3.f;

public interface d {
    f a();
}
