package a3;

import android.os.IInterface;
import android.os.RemoteCallbackList;
import androidx.room.MultiInstanceInvalidationService;
import v7.r0;

public final class s extends RemoteCallbackList {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MultiInstanceInvalidationService f496a;

    public s(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f496a = multiInstanceInvalidationService;
    }

    public final void onCallbackDied(IInterface iInterface, Object obj) {
        r0.j("callback", (g) iInterface);
        r0.j("cookie", obj);
        this.f496a.f3051b.remove((Integer) obj);
    }
}
