package a3;

public final class y {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f526a;

    /* renamed from: b  reason: collision with root package name */
    public final String f527b;

    public /* synthetic */ y(boolean z4, String str) {
        this.f526a = z4;
        this.f527b = str;
    }
}
