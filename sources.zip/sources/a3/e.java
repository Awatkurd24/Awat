package a3;

import f3.i;
import fc.a;
import java.util.List;
import m.d;

public abstract class e extends d {
    public abstract void L(i iVar, Object obj);

    public void M(Object obj) {
        i c10 = c();
        try {
            L(c10, obj);
            c10.L();
        } finally {
            x(c10);
        }
    }

    public abstract List N(a aVar);
}
