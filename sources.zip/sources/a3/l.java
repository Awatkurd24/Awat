package a3;

import a4.c;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import f3.b;
import f3.i;
import f9.f;
import h.y0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import o.g;
import v7.f9;
import v7.r0;
import xd.o;
import xd.x;
import yd.h;

public final class l {

    /* renamed from: n  reason: collision with root package name */
    public static final String[] f462n = {"UPDATE", "DELETE", "INSERT"};

    /* renamed from: a  reason: collision with root package name */
    public final x f463a;

    /* renamed from: b  reason: collision with root package name */
    public final Map f464b;

    /* renamed from: c  reason: collision with root package name */
    public final Map f465c;

    /* renamed from: d  reason: collision with root package name */
    public final LinkedHashMap f466d;

    /* renamed from: e  reason: collision with root package name */
    public final String[] f467e;

    /* renamed from: f  reason: collision with root package name */
    public final AtomicBoolean f468f = new AtomicBoolean(false);

    /* renamed from: g  reason: collision with root package name */
    public volatile boolean f469g;

    /* renamed from: h  reason: collision with root package name */
    public volatile i f470h;

    /* renamed from: i  reason: collision with root package name */
    public final j f471i;

    /* renamed from: j  reason: collision with root package name */
    public final g f472j;

    /* renamed from: k  reason: collision with root package name */
    public final Object f473k;

    /* renamed from: l  reason: collision with root package name */
    public final Object f474l;

    /* renamed from: m  reason: collision with root package name */
    public final y0 f475m;

    public l(x xVar, HashMap hashMap, HashMap hashMap2, String... strArr) {
        String str;
        r0.j("database", xVar);
        this.f463a = xVar;
        this.f464b = hashMap;
        this.f465c = hashMap2;
        this.f471i = new j(strArr.length);
        new c(xVar, 7);
        this.f472j = new g();
        this.f473k = new Object();
        this.f474l = new Object();
        this.f466d = new LinkedHashMap();
        int length = strArr.length;
        String[] strArr2 = new String[length];
        for (int i10 = 0; i10 < length; i10++) {
            String str2 = strArr[i10];
            Locale locale = Locale.US;
            r0.i("US", locale);
            String lowerCase = str2.toLowerCase(locale);
            r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase);
            this.f466d.put(lowerCase, Integer.valueOf(i10));
            String str3 = (String) this.f464b.get(strArr[i10]);
            if (str3 != null) {
                str = str3.toLowerCase(locale);
                r0.i("this as java.lang.String).toLowerCase(locale)", str);
            } else {
                str = null;
            }
            if (str != null) {
                lowerCase = str;
            }
            strArr2[i10] = lowerCase;
        }
        this.f467e = strArr2;
        for (Map.Entry entry : this.f464b.entrySet()) {
            Locale locale2 = Locale.US;
            r0.i("US", locale2);
            String lowerCase2 = ((String) entry.getValue()).toLowerCase(locale2);
            r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase2);
            if (this.f466d.containsKey(lowerCase2)) {
                String lowerCase3 = ((String) entry.getKey()).toLowerCase(locale2);
                r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase3);
                LinkedHashMap linkedHashMap = this.f466d;
                linkedHashMap.put(lowerCase3, x.v(linkedHashMap, lowerCase2));
            }
        }
        this.f475m = new y0(16, this);
    }

    public final void a(n nVar) {
        k kVar;
        String[] strArr = nVar.f478a;
        h hVar = new h();
        int i10 = 0;
        for (String str : strArr) {
            Locale locale = Locale.US;
            r0.i("US", locale);
            String lowerCase = str.toLowerCase(locale);
            r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase);
            Map map = this.f465c;
            if (map.containsKey(lowerCase)) {
                String lowerCase2 = str.toLowerCase(locale);
                r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase2);
                Object obj = map.get(lowerCase2);
                r0.g(obj);
                hVar.addAll((Collection) obj);
            } else {
                hVar.add(str);
            }
        }
        Object[] array = f9.a(hVar).toArray(new String[0]);
        r0.h("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>", array);
        String[] strArr2 = (String[]) array;
        ArrayList arrayList = new ArrayList(strArr2.length);
        int length = strArr2.length;
        while (i10 < length) {
            String str2 = strArr2[i10];
            LinkedHashMap linkedHashMap = this.f466d;
            Locale locale2 = Locale.US;
            r0.i("US", locale2);
            String lowerCase3 = str2.toLowerCase(locale2);
            r0.i("this as java.lang.String).toLowerCase(locale)", lowerCase3);
            Integer num = (Integer) linkedHashMap.get(lowerCase3);
            if (num != null) {
                arrayList.add(Integer.valueOf(num.intValue()));
                i10++;
            } else {
                throw new IllegalArgumentException("There is no table with name ".concat(str2));
            }
        }
        int[] A0 = o.A0(arrayList);
        k kVar2 = new k(nVar, A0, strArr2);
        synchronized (this.f472j) {
            kVar = (k) this.f472j.f(nVar, kVar2);
        }
        if (kVar == null && this.f471i.b(Arrays.copyOf(A0, A0.length))) {
            x xVar = this.f463a;
            if (xVar.k()) {
                d(xVar.g().K());
            }
        }
    }

    public final boolean b() {
        if (!this.f463a.k()) {
            return false;
        }
        if (!this.f469g) {
            this.f463a.g().K();
        }
        if (this.f469g) {
            return true;
        }
        Log.e("ROOM", "database is not initialized even though it is open");
        return false;
    }

    public final void c(b bVar, int i10) {
        bVar.k("INSERT OR IGNORE INTO room_table_modification_log VALUES(" + i10 + ", 0)");
        String str = this.f467e[i10];
        String[] strArr = f462n;
        for (int i11 = 0; i11 < 3; i11++) {
            String str2 = strArr[i11];
            String str3 = "CREATE TEMP TRIGGER IF NOT EXISTS " + f.j(str, str2) + " AFTER " + str2 + " ON `" + str + "` BEGIN UPDATE room_table_modification_log SET invalidated = 1 WHERE table_id = " + i10 + " AND invalidated = 0; END";
            r0.i("StringBuilder().apply(builderAction).toString()", str3);
            bVar.k(str3);
        }
    }

    public final void d(b bVar) {
        ReentrantReadWriteLock.ReadLock readLock;
        r0.j("database", bVar);
        if (!bVar.x()) {
            try {
                readLock = this.f463a.f523h.readLock();
                r0.i("readWriteLock.readLock()", readLock);
                readLock.lock();
                synchronized (this.f473k) {
                    int[] a10 = this.f471i.a();
                    if (a10 == null) {
                        readLock.unlock();
                        return;
                    }
                    if (bVar.A()) {
                        bVar.F();
                    } else {
                        bVar.f();
                    }
                    try {
                        int length = a10.length;
                        int i10 = 0;
                        int i11 = 0;
                        while (i10 < length) {
                            int i12 = a10[i10];
                            int i13 = i11 + 1;
                            if (i12 == 1) {
                                c(bVar, i11);
                            } else if (i12 == 2) {
                                String str = this.f467e[i11];
                                String[] strArr = f462n;
                                for (int i14 = 0; i14 < 3; i14++) {
                                    String str2 = strArr[i14];
                                    String str3 = "DROP TRIGGER IF EXISTS " + f.j(str, str2);
                                    r0.i("StringBuilder().apply(builderAction).toString()", str3);
                                    bVar.k(str3);
                                }
                            }
                            i10++;
                            i11 = i13;
                        }
                        bVar.E();
                        bVar.e();
                        readLock.unlock();
                    } finally {
                        bVar.e();
                    }
                }
            } catch (SQLiteException | IllegalStateException e10) {
                Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", e10);
            } catch (Throwable th2) {
                readLock.unlock();
                throw th2;
            }
        }
    }
}
