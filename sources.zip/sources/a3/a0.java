package a3;

import f3.g;
import f3.h;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import v7.r0;

public final class a0 implements h, g {

    /* renamed from: i  reason: collision with root package name */
    public static final TreeMap f427i = new TreeMap();

    /* renamed from: a  reason: collision with root package name */
    public final int f428a;

    /* renamed from: b  reason: collision with root package name */
    public volatile String f429b;

    /* renamed from: c  reason: collision with root package name */
    public final long[] f430c;

    /* renamed from: d  reason: collision with root package name */
    public final double[] f431d;

    /* renamed from: e  reason: collision with root package name */
    public final String[] f432e;

    /* renamed from: f  reason: collision with root package name */
    public final byte[][] f433f;

    /* renamed from: g  reason: collision with root package name */
    public final int[] f434g;

    /* renamed from: h  reason: collision with root package name */
    public int f435h;

    public a0(int i10) {
        this.f428a = i10;
        int i11 = i10 + 1;
        this.f434g = new int[i11];
        this.f430c = new long[i11];
        this.f431d = new double[i11];
        this.f432e = new String[i11];
        this.f433f = new byte[i11][];
    }

    public static final a0 p(int i10, String str) {
        r0.j("query", str);
        TreeMap treeMap = f427i;
        synchronized (treeMap) {
            Map.Entry ceilingEntry = treeMap.ceilingEntry(Integer.valueOf(i10));
            if (ceilingEntry != null) {
                treeMap.remove(ceilingEntry.getKey());
                a0 a0Var = (a0) ceilingEntry.getValue();
                a0Var.getClass();
                a0Var.f429b = str;
                a0Var.f435h = i10;
                return a0Var;
            }
            a0 a0Var2 = new a0(i10);
            a0Var2.f429b = str;
            a0Var2.f435h = i10;
            return a0Var2;
        }
    }

    public final void D(int i10, long j3) {
        this.f434g[i10] = 2;
        this.f430c[i10] = j3;
    }

    public final void G(int i10, byte[] bArr) {
        this.f434g[i10] = 5;
        this.f433f[i10] = bArr;
    }

    public final String a() {
        String str = this.f429b;
        if (str != null) {
            return str;
        }
        throw new IllegalStateException("Required value was null.".toString());
    }

    public final void close() {
    }

    public final void d(u uVar) {
        int i10 = this.f435h;
        if (1 <= i10) {
            int i11 = 1;
            while (true) {
                int i12 = this.f434g[i11];
                if (i12 == 1) {
                    uVar.t(i11);
                } else if (i12 == 2) {
                    uVar.D(i11, this.f430c[i11]);
                } else if (i12 == 3) {
                    uVar.a(this.f431d[i11], i11);
                } else if (i12 == 4) {
                    String str = this.f432e[i11];
                    if (str != null) {
                        uVar.m(i11, str);
                    } else {
                        throw new IllegalArgumentException("Required value was null.".toString());
                    }
                } else if (i12 == 5) {
                    byte[] bArr = this.f433f[i11];
                    if (bArr != null) {
                        uVar.G(i11, bArr);
                    } else {
                        throw new IllegalArgumentException("Required value was null.".toString());
                    }
                }
                if (i11 != i10) {
                    i11++;
                } else {
                    return;
                }
            }
        }
    }

    public final void m(int i10, String str) {
        r0.j("value", str);
        this.f434g[i10] = 4;
        this.f432e[i10] = str;
    }

    public final void q() {
        TreeMap treeMap = f427i;
        synchronized (treeMap) {
            treeMap.put(Integer.valueOf(this.f428a), this);
            if (treeMap.size() > 15) {
                int size = treeMap.size() - 10;
                Iterator it = treeMap.descendingKeySet().iterator();
                r0.i("queryPool.descendingKeySet().iterator()", it);
                while (true) {
                    int i10 = size - 1;
                    if (size <= 0) {
                        break;
                    }
                    it.next();
                    it.remove();
                    size = i10;
                }
            }
        }
    }

    public final void t(int i10) {
        this.f434g[i10] = 1;
    }
}
