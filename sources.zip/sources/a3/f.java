package a3;

import android.os.IBinder;
import android.os.Parcel;

public final class f implements g {

    /* renamed from: a  reason: collision with root package name */
    public IBinder f452a;

    public final void K1(String[] strArr) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
            obtain.writeStringArray(strArr);
            this.f452a.transact(1, obtain, (Parcel) null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f452a;
    }
}
