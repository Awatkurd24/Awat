package ad;

import bd.b;
import ic.j;
import ic.n;

public final class a implements j {

    /* renamed from: b  reason: collision with root package name */
    public static final n[] f793b = new n[0];

    /* renamed from: a  reason: collision with root package name */
    public final b f794a = new b();

    /* JADX WARNING: Removed duplicated region for block: B:169:0x02f6  */
    /* JADX WARNING: Removed duplicated region for block: B:286:0x0301 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final ic.l a(a4.m r41, java.util.Map r42) {
        /*
            r40 = this;
            r0 = r42
            r2 = r40
            bd.b r3 = r2.f794a
            r4 = 1073741824(0x40000000, float:2.0)
            r5 = 5
            r6 = 0
            r8 = 1
            if (r0 == 0) goto L_0x00f5
            ic.d r9 = ic.d.f20158a
            boolean r9 = r0.containsKey(r9)
            if (r9 == 0) goto L_0x00f5
            mc.b r9 = r41.f()
            int[] r10 = r9.e()
            int[] r11 = r9.c()
            if (r10 == 0) goto L_0x00f0
            if (r11 == 0) goto L_0x00f0
            int r12 = r9.f22658b
            int r13 = r9.f22657a
            r14 = r10[r6]
            r15 = r10[r8]
            r1 = 1
            r17 = 0
        L_0x0030:
            if (r14 >= r13) goto L_0x0048
            if (r15 >= r12) goto L_0x0048
            boolean r7 = r9.b(r14, r15)
            if (r1 == r7) goto L_0x0043
            int r7 = r17 + 1
            if (r7 != r5) goto L_0x003f
            goto L_0x0048
        L_0x003f:
            r1 = r1 ^ 1
            r17 = r7
        L_0x0043:
            int r14 = r14 + 1
            int r15 = r15 + 1
            goto L_0x0030
        L_0x0048:
            if (r14 == r13) goto L_0x00eb
            if (r15 == r12) goto L_0x00eb
            r1 = r10[r6]
            int r14 = r14 - r1
            float r5 = (float) r14
            r7 = 1088421888(0x40e00000, float:7.0)
            float r5 = r5 / r7
            r7 = r10[r8]
            r10 = r11[r8]
            r11 = r11[r6]
            if (r1 >= r11) goto L_0x00e6
            if (r7 >= r10) goto L_0x00e6
            int r12 = r10 - r7
            int r13 = r11 - r1
            if (r12 == r13) goto L_0x006f
            int r11 = r1 + r12
            int r13 = r9.f22657a
            if (r11 >= r13) goto L_0x006a
            goto L_0x006f
        L_0x006a:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x006f:
            int r13 = r11 - r1
            int r13 = r13 + r8
            float r13 = (float) r13
            float r13 = r13 / r5
            int r13 = java.lang.Math.round(r13)
            int r12 = r12 + r8
            float r8 = (float) r12
            float r8 = r8 / r5
            int r8 = java.lang.Math.round(r8)
            if (r13 <= 0) goto L_0x00e1
            if (r8 <= 0) goto L_0x00e1
            if (r8 != r13) goto L_0x00dc
            float r4 = r5 / r4
            int r4 = (int) r4
            int r7 = r7 + r4
            int r1 = r1 + r4
            int r12 = r13 + -1
            float r12 = (float) r12
            float r12 = r12 * r5
            int r12 = (int) r12
            int r12 = r12 + r1
            int r12 = r12 - r11
            if (r12 <= 0) goto L_0x009d
            if (r12 > r4) goto L_0x0098
            int r1 = r1 - r12
            goto L_0x009d
        L_0x0098:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x009d:
            int r11 = r8 + -1
            float r11 = (float) r11
            float r11 = r11 * r5
            int r11 = (int) r11
            int r11 = r11 + r7
            int r11 = r11 - r10
            if (r11 <= 0) goto L_0x00b0
            if (r11 > r4) goto L_0x00ab
            int r7 = r7 - r11
            goto L_0x00b0
        L_0x00ab:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00b0:
            mc.b r4 = new mc.b
            r4.<init>(r13, r8)
            r10 = 0
        L_0x00b6:
            if (r10 >= r8) goto L_0x00d4
            float r11 = (float) r10
            float r11 = r11 * r5
            int r11 = (int) r11
            int r11 = r11 + r7
            r12 = 0
        L_0x00be:
            if (r12 >= r13) goto L_0x00d1
            float r14 = (float) r12
            float r14 = r14 * r5
            int r14 = (int) r14
            int r14 = r14 + r1
            boolean r14 = r9.b(r14, r11)
            if (r14 == 0) goto L_0x00ce
            r4.h(r12, r10)
        L_0x00ce:
            int r12 = r12 + 1
            goto L_0x00be
        L_0x00d1:
            int r10 = r10 + 1
            goto L_0x00b6
        L_0x00d4:
            mc.d r0 = r3.b(r4, r0)
            ic.n[] r1 = f793b
            goto L_0x0489
        L_0x00dc:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00e1:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00e6:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00eb:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00f0:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x00f5:
            a4.c r1 = new a4.c
            mc.b r7 = r41.f()
            r1.<init>((java.lang.Object) r7)
            if (r0 != 0) goto L_0x0101
            goto L_0x010a
        L_0x0101:
            ic.d r7 = ic.d.f20166i
            java.lang.Object r7 = r0.get(r7)
            f.c.w(r7)
        L_0x010a:
            r7 = 0
            r1.f537b = r7
            cd.e r9 = new cd.e
            java.lang.Object r10 = r1.f536a
            mc.b r10 = (mc.b) r10
            r9.<init>(r10)
            if (r0 == 0) goto L_0x0122
            ic.d r11 = ic.d.f20160c
            boolean r11 = r0.containsKey(r11)
            if (r11 == 0) goto L_0x0122
            r11 = 1
            goto L_0x0123
        L_0x0122:
            r11 = 0
        L_0x0123:
            int r12 = r10.f22658b
            int r13 = r10.f22657a
            int r14 = r12 * 3
            int r14 = r14 / 388
            r15 = 3
            if (r14 < r15) goto L_0x0130
            if (r11 == 0) goto L_0x0131
        L_0x0130:
            r14 = 3
        L_0x0131:
            int[] r5 = new int[r5]
            int r11 = r14 + -1
            r15 = 0
        L_0x0136:
            java.util.ArrayList r7 = r9.f4138b
            if (r11 >= r12) goto L_0x0234
            if (r15 != 0) goto L_0x0234
            java.util.Arrays.fill(r5, r6)
            r4 = 0
        L_0x0140:
            if (r4 >= r13) goto L_0x0212
            boolean r20 = r10.b(r4, r11)
            r2 = r6 & 1
            if (r20 == 0) goto L_0x0155
            if (r2 != r8) goto L_0x014e
            int r6 = r6 + 1
        L_0x014e:
            r2 = r5[r6]
            int r2 = r2 + r8
            r5[r6] = r2
            goto L_0x020d
        L_0x0155:
            if (r2 != 0) goto L_0x0208
            r2 = 4
            if (r6 != r2) goto L_0x01ff
            boolean r2 = cd.e.b(r5)
            if (r2 == 0) goto L_0x01e8
            boolean r2 = r9.c(r11, r4, r5)
            if (r2 == 0) goto L_0x01cf
            boolean r2 = r9.f4139c
            if (r2 == 0) goto L_0x0172
            boolean r15 = r9.d()
            r2 = 0
            r16 = 2
            goto L_0x01c8
        L_0x0172:
            int r2 = r7.size()
            if (r2 > r8) goto L_0x017c
            r2 = 0
            r16 = 2
            goto L_0x01bd
        L_0x017c:
            java.util.Iterator r2 = r7.iterator()
            r6 = 0
        L_0x0181:
            boolean r14 = r2.hasNext()
            if (r14 == 0) goto L_0x01ba
            java.lang.Object r14 = r2.next()
            cd.c r14 = (cd.c) r14
            int r8 = r14.f4135d
            r21 = r2
            r2 = 2
            if (r8 < r2) goto L_0x0197
            if (r6 != 0) goto L_0x019a
            r6 = r14
        L_0x0197:
            r16 = 2
            goto L_0x01b6
        L_0x019a:
            r2 = 1
            r9.f4139c = r2
            float r2 = r6.f20209a
            float r8 = r14.f20209a
            float r2 = r2 - r8
            float r2 = java.lang.Math.abs(r2)
            float r6 = r6.f20210b
            float r8 = r14.f20210b
            float r6 = r6 - r8
            float r6 = java.lang.Math.abs(r6)
            float r2 = r2 - r6
            int r2 = (int) r2
            r16 = 2
            int r2 = r2 / 2
            goto L_0x01bd
        L_0x01b6:
            r2 = r21
            r8 = 1
            goto L_0x0181
        L_0x01ba:
            r16 = 2
            r2 = 0
        L_0x01bd:
            r6 = r5[r16]
            if (r2 <= r6) goto L_0x01c7
            int r2 = r2 - r6
            int r2 = r2 + -2
            int r11 = r11 + r2
            int r4 = r13 + -1
        L_0x01c7:
            r2 = 0
        L_0x01c8:
            java.util.Arrays.fill(r5, r2)
            r6 = 0
            r8 = 1
            r14 = 2
            goto L_0x020d
        L_0x01cf:
            r2 = 0
            r16 = 2
            r6 = r5[r16]
            r5[r2] = r6
            r18 = 3
            r6 = r5[r18]
            r8 = 1
            r5[r8] = r6
            r6 = 4
            r19 = r5[r6]
            r5[r16] = r19
            r5[r18] = r8
            r5[r6] = r2
        L_0x01e6:
            r6 = 3
            goto L_0x020d
        L_0x01e8:
            r2 = 0
            r6 = 4
            r16 = 2
            r18 = 3
            r19 = r5[r16]
            r5[r2] = r19
            r19 = r5[r18]
            r5[r8] = r19
            r19 = r5[r6]
            r5[r16] = r19
            r5[r18] = r8
            r5[r6] = r2
            goto L_0x01e6
        L_0x01ff:
            int r2 = r6 + 1
            r6 = r5[r2]
            int r6 = r6 + r8
            r5[r2] = r6
            r6 = r2
            goto L_0x020d
        L_0x0208:
            r2 = r5[r6]
            int r2 = r2 + r8
            r5[r6] = r2
        L_0x020d:
            int r4 = r4 + r8
            r2 = r40
            goto L_0x0140
        L_0x0212:
            boolean r2 = cd.e.b(r5)
            if (r2 == 0) goto L_0x022b
            boolean r2 = r9.c(r11, r13, r5)
            if (r2 == 0) goto L_0x022b
            r2 = 0
            r4 = r5[r2]
            boolean r2 = r9.f4139c
            if (r2 == 0) goto L_0x022a
            boolean r2 = r9.d()
            r15 = r2
        L_0x022a:
            r14 = r4
        L_0x022b:
            int r11 = r11 + r14
            r2 = r40
            r4 = 1073741824(0x40000000, float:2.0)
            r6 = 0
            r8 = 1
            goto L_0x0136
        L_0x0234:
            int r2 = r7.size()
            r4 = 3
            if (r2 < r4) goto L_0x050b
            java.util.Iterator r2 = r7.iterator()
        L_0x023f:
            boolean r4 = r2.hasNext()
            if (r4 == 0) goto L_0x0254
            java.lang.Object r4 = r2.next()
            cd.c r4 = (cd.c) r4
            int r4 = r4.f4135d
            r5 = 2
            if (r4 >= r5) goto L_0x023f
            r2.remove()
            goto L_0x023f
        L_0x0254:
            r5 = 2
            cd.d r2 = cd.e.f4136e
            java.util.Collections.sort(r7, r2)
            r2 = 3
            cd.c[] r4 = new cd.c[r2]
            r2 = 0
            r10 = 9218868437227405311(0x7fefffffffffffff, double:1.7976931348623157E308)
        L_0x0263:
            int r6 = r7.size()
            int r6 = r6 - r5
            if (r2 >= r6) goto L_0x030b
            java.lang.Object r5 = r7.get(r2)
            cd.c r5 = (cd.c) r5
            float r6 = r5.f4134c
            int r2 = r2 + 1
            r12 = r2
        L_0x0275:
            int r13 = r7.size()
            r14 = 1
            int r13 = r13 - r14
            if (r12 >= r13) goto L_0x0306
            java.lang.Object r13 = r7.get(r12)
            cd.c r13 = (cd.c) r13
            double r14 = cd.e.e(r5, r13)
            int r12 = r12 + 1
            r8 = r12
        L_0x028a:
            int r9 = r7.size()
            if (r8 >= r9) goto L_0x0275
            java.lang.Object r9 = r7.get(r8)
            cd.c r9 = (cd.c) r9
            r23 = r2
            float r2 = r9.f4134c
            r24 = 1068708659(0x3fb33333, float:1.4)
            float r24 = r24 * r6
            int r2 = (r2 > r24 ? 1 : (r2 == r24 ? 0 : -1))
            if (r2 <= 0) goto L_0x02a4
            goto L_0x0301
        L_0x02a4:
            double r24 = cd.e.e(r13, r9)
            double r26 = cd.e.e(r5, r9)
            int r2 = (r14 > r24 ? 1 : (r14 == r24 ? 0 : -1))
            if (r2 >= 0) goto L_0x02c9
            int r2 = (r24 > r26 ? 1 : (r24 == r26 ? 0 : -1))
            if (r2 <= 0) goto L_0x02c0
            int r2 = (r14 > r26 ? 1 : (r14 == r26 ? 0 : -1))
            if (r2 >= 0) goto L_0x02bb
            r28 = r14
            goto L_0x02de
        L_0x02bb:
            r28 = r26
        L_0x02bd:
            r26 = r14
            goto L_0x02de
        L_0x02c0:
            r28 = r14
            r38 = r24
            r24 = r26
            r26 = r38
            goto L_0x02de
        L_0x02c9:
            int r2 = (r24 > r26 ? 1 : (r24 == r26 ? 0 : -1))
            if (r2 >= 0) goto L_0x02d9
            int r2 = (r14 > r26 ? 1 : (r14 == r26 ? 0 : -1))
            r28 = r24
            if (r2 >= 0) goto L_0x02d6
            r24 = r26
            goto L_0x02bd
        L_0x02d6:
            r24 = r14
            goto L_0x02de
        L_0x02d9:
            r28 = r26
            r26 = r24
            goto L_0x02d6
        L_0x02de:
            r30 = 4611686018427387904(0x4000000000000000, double:2.0)
            double r26 = r26 * r30
            double r26 = r24 - r26
            double r26 = java.lang.Math.abs(r26)
            double r28 = r28 * r30
            double r24 = r24 - r28
            double r24 = java.lang.Math.abs(r24)
            double r24 = r24 + r26
            int r2 = (r24 > r10 ? 1 : (r24 == r10 ? 0 : -1))
            if (r2 >= 0) goto L_0x0301
            r2 = 0
            r4[r2] = r5
            r2 = 1
            r4[r2] = r13
            r2 = 2
            r4[r2] = r9
            r10 = r24
        L_0x0301:
            int r8 = r8 + 1
            r2 = r23
            goto L_0x028a
        L_0x0306:
            r23 = r2
            r5 = 2
            goto L_0x0263
        L_0x030b:
            r5 = 9218868437227405311(0x7fefffffffffffff, double:1.7976931348623157E308)
            int r2 = (r10 > r5 ? 1 : (r10 == r5 ? 0 : -1))
            if (r2 == 0) goto L_0x0506
            r2 = 0
            r5 = r4[r2]
            r6 = 1
            r7 = r4[r6]
            float r5 = ic.n.a(r5, r7)
            r7 = r4[r6]
            r8 = 2
            r9 = r4[r8]
            float r7 = ic.n.a(r7, r9)
            r9 = r4[r2]
            r10 = r4[r8]
            float r9 = ic.n.a(r9, r10)
            int r10 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1))
            if (r10 < 0) goto L_0x033e
            int r10 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r10 < 0) goto L_0x033e
            r5 = r4[r2]
            r7 = r4[r6]
            r9 = r4[r8]
            goto L_0x0353
        L_0x033e:
            int r7 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r7 < 0) goto L_0x034d
            int r5 = (r9 > r5 ? 1 : (r9 == r5 ? 0 : -1))
            if (r5 < 0) goto L_0x034d
            r5 = r4[r6]
            r7 = r4[r2]
            r9 = r4[r8]
            goto L_0x0353
        L_0x034d:
            r5 = r4[r8]
            r7 = r4[r2]
            r9 = r4[r6]
        L_0x0353:
            float r2 = r5.f20209a
            float r6 = r9.f20209a
            float r6 = r6 - r2
            float r8 = r7.f20210b
            float r10 = r5.f20210b
            float r8 = r8 - r10
            float r8 = r8 * r6
            float r6 = r9.f20210b
            float r6 = r6 - r10
            float r11 = r7.f20209a
            float r11 = r11 - r2
            float r11 = r11 * r6
            float r8 = r8 - r11
            r2 = 0
            int r2 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x0374
            r2 = 0
            r38 = r9
            r9 = r7
            r7 = r38
            goto L_0x0375
        L_0x0374:
            r2 = 0
        L_0x0375:
            r4[r2] = r7
            r2 = 1
            r4[r2] = r5
            r2 = 2
            r4[r2] = r9
            float r2 = r1.e(r5, r9)
            float r4 = r1.e(r5, r7)
            float r4 = r4 + r2
            r2 = 1073741824(0x40000000, float:2.0)
            float r4 = r4 / r2
            r2 = 1065353216(0x3f800000, float:1.0)
            int r6 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r6 < 0) goto L_0x0501
            float r6 = ic.n.a(r5, r9)
            float r6 = r6 / r4
            int r6 = v7.f9.n(r6)
            float r8 = ic.n.a(r5, r7)
            float r8 = r8 / r4
            int r8 = v7.f9.n(r8)
            int r8 = r8 + r6
            r6 = 2
            int r8 = r8 / r6
            int r11 = r8 + 7
            r12 = r11 & 3
            if (r12 == 0) goto L_0x03b8
            if (r12 == r6) goto L_0x03b5
            r6 = 3
            if (r12 == r6) goto L_0x03b0
            goto L_0x03ba
        L_0x03b0:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x03b5:
            int r11 = r8 + 6
            goto L_0x03ba
        L_0x03b8:
            int r11 = r8 + 8
        L_0x03ba:
            int[] r6 = bd.g.f3616e
            int r6 = r11 % 4
            r8 = 1
            if (r6 != r8) goto L_0x04fc
            int r6 = r11 + -17
            r8 = 4
            int r6 = r6 / r8
            bd.g r6 = bd.g.c(r6)     // Catch:{ IllegalArgumentException -> 0x04f7 }
            int r12 = r6.f3618a
            int r12 = r12 * 4
            int r12 = r12 + 10
            int[] r6 = r6.f3619b
            int r6 = r6.length
            float r13 = r5.f20209a
            float r14 = r9.f20210b
            float r15 = r9.f20209a
            float r2 = r7.f20210b
            float r8 = r7.f20209a
            if (r6 <= 0) goto L_0x0408
            float r6 = r15 - r13
            float r6 = r6 + r8
            float r22 = r14 - r10
            float r0 = r22 + r2
            float r12 = (float) r12
            r21 = 1077936128(0x40400000, float:3.0)
            float r12 = r21 / r12
            r17 = 1065353216(0x3f800000, float:1.0)
            float r12 = r17 - r12
            float r6 = f.c.k(r6, r13, r12, r13)
            int r6 = (int) r6
            float r0 = f.c.k(r0, r10, r12, r10)
            int r0 = (int) r0
            r17 = r3
            r12 = 4
        L_0x03fb:
            r3 = 16
            if (r12 > r3) goto L_0x040a
            float r3 = (float) r12
            cd.a r0 = r1.l(r4, r3, r6, r0)     // Catch:{ h -> 0x0405 }
            goto L_0x040b
        L_0x0405:
            int r12 = r12 << 1
            goto L_0x03fb
        L_0x0408:
            r17 = r3
        L_0x040a:
            r0 = 0
        L_0x040b:
            float r3 = (float) r11
            r4 = 1080033280(0x40600000, float:3.5)
            float r29 = r3 - r4
            if (r0 == 0) goto L_0x0421
            r3 = 1077936128(0x40400000, float:3.0)
            float r2 = r29 - r3
            float r3 = r0.f20209a
            float r4 = r0.f20210b
            r27 = r2
            r34 = r3
            r35 = r4
            goto L_0x042b
        L_0x0421:
            float r15 = r15 - r13
            float r15 = r15 + r8
            float r14 = r14 - r10
            float r14 = r14 + r2
            r35 = r14
            r34 = r15
            r27 = r29
        L_0x042b:
            r22 = 1080033280(0x40600000, float:3.5)
            r23 = 1080033280(0x40600000, float:3.5)
            r25 = 1080033280(0x40600000, float:3.5)
            r28 = 1080033280(0x40600000, float:3.5)
            float r2 = r5.f20209a
            float r3 = r5.f20210b
            float r4 = r9.f20209a
            float r6 = r9.f20210b
            float r8 = r7.f20209a
            float r10 = r7.f20210b
            r24 = r29
            r26 = r27
            r30 = r2
            r31 = r3
            r32 = r4
            r33 = r6
            r36 = r8
            r37 = r10
            i1.a r2 = i1.a.c(r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37)
            java.lang.Object r1 = r1.f536a
            mc.b r1 = (mc.b) r1
            mc.b r1 = v7.a2.a(r1, r11, r11, r2)
            r2 = 3
            if (r0 != 0) goto L_0x046e
            ic.n[] r0 = new ic.n[r2]
            r3 = 0
            r0[r3] = r7
            r4 = 1
            r0[r4] = r5
            r6 = 2
            r0[r6] = r9
            r2 = r42
        L_0x046b:
            r3 = r17
            goto L_0x0480
        L_0x046e:
            r3 = 0
            r4 = 1
            r6 = 2
            r8 = 4
            ic.n[] r8 = new ic.n[r8]
            r8[r3] = r7
            r8[r4] = r5
            r8[r6] = r9
            r8[r2] = r0
            r2 = r42
            r0 = r8
            goto L_0x046b
        L_0x0480:
            mc.d r1 = r3.b(r1, r2)
            r38 = r1
            r1 = r0
            r0 = r38
        L_0x0489:
            java.lang.Object r2 = r0.f22672g
            boolean r3 = r2 instanceof bd.f
            if (r3 == 0) goto L_0x04a3
            bd.f r2 = (bd.f) r2
            r2.getClass()
            int r2 = r1.length
            r3 = 3
            if (r2 >= r3) goto L_0x0499
            goto L_0x04a3
        L_0x0499:
            r2 = 0
            r3 = r1[r2]
            r4 = 2
            r5 = r1[r4]
            r1[r2] = r5
            r1[r4] = r3
        L_0x04a3:
            ic.l r2 = new ic.l
            ic.a r3 = ic.a.f20149l
            java.lang.String r4 = r0.f22667b
            byte[] r5 = r0.f22666a
            r2.<init>(r4, r5, r1, r3)
            java.util.List r1 = r0.f22668c
            if (r1 == 0) goto L_0x04b7
            ic.m r3 = ic.m.f20196b
            r2.b(r3, r1)
        L_0x04b7:
            java.lang.String r1 = r0.f22669d
            if (r1 == 0) goto L_0x04c0
            ic.m r3 = ic.m.f20197c
            r2.b(r3, r1)
        L_0x04c0:
            int r1 = r0.f22673h
            if (r1 < 0) goto L_0x04da
            int r3 = r0.f22674i
            if (r3 < 0) goto L_0x04da
            ic.m r4 = ic.m.f20205k
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2.b(r4, r3)
            ic.m r3 = ic.m.f20206l
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r2.b(r3, r1)
        L_0x04da:
            ic.m r1 = ic.m.f20198d
            java.lang.Integer r3 = r0.f22670e
            r2.b(r1, r3)
            ic.m r1 = ic.m.f20207m
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "]Q"
            r3.<init>(r4)
            int r0 = r0.f22675j
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r2.b(r1, r0)
            return r2
        L_0x04f7:
            ic.f r0 = ic.f.a()
            throw r0
        L_0x04fc:
            ic.f r0 = ic.f.a()
            throw r0
        L_0x0501:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x0506:
            ic.h r0 = ic.h.a()
            throw r0
        L_0x050b:
            ic.h r0 = ic.h.a()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ad.a.a(a4.m, java.util.Map):ic.l");
    }
}
