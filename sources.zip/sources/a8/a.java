package a8;

import d0.g;
import d7.b;
import java.util.Arrays;

public final class a implements b {

    /* renamed from: b  reason: collision with root package name */
    public static final a f654b = new Object();

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        ((a) obj).getClass();
        return g.f((Object) null, (Object) null) && g.f((Object) null, (Object) null) && g.f((Object) null, (Object) null) && g.f((Object) null, (Object) null) && g.f((Object) null, (Object) null);
    }

    public final int hashCode() {
        Boolean bool = Boolean.FALSE;
        return Arrays.hashCode(new Object[]{bool, bool, null, bool, bool, null, null, null, null});
    }
}
