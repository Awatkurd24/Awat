package a8;

import com.google.android.gms.common.api.Scope;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public static final h7.b f655a = new h7.b(3);

    static {
        new Scope(1, "profile");
        new Scope(1, "email");
    }
}
