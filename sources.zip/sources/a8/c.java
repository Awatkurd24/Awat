package a8;

public interface c extends d7.c {
    void b(b8.c cVar);

    void h();
}
