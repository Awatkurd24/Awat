package a2;

import ge.c;
import he.l;
import java.util.concurrent.CancellationException;
import v7.r0;
import wd.m;
import yg.b0;
import yg.o;
import yg.r;

public final class u extends l implements c {

    /* renamed from: a  reason: collision with root package name */
    public static final u f412a = new l(2);

    public final Object g(Object obj, Object obj2) {
        Object O;
        r rVar = (r) obj;
        Throwable th2 = (Throwable) obj2;
        r0.j("msg", rVar);
        if (rVar instanceof q) {
            q qVar = (q) rVar;
            if (th2 == null) {
                th2 = new CancellationException("DataStore scope was cancelled before updateData could complete");
            }
            o oVar = (o) qVar.f406b;
            oVar.getClass();
            r rVar2 = new r(th2, false);
            do {
                O = oVar.O(oVar.z(), rVar2);
                if (O != b0.f30268d) {
                    if (O == b0.f30269e) {
                        break;
                    }
                } else {
                    break;
                }
            } while (O == b0.f30270f);
        }
        return m.f29306a;
    }
}
