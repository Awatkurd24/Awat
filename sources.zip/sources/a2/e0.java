package a2;

import be.c;
import he.v;
import zd.e;

public final class e0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public Object f328d;

    /* renamed from: e  reason: collision with root package name */
    public Object f329e;

    /* renamed from: f  reason: collision with root package name */
    public Object f330f;

    /* renamed from: g  reason: collision with root package name */
    public v f331g;

    /* renamed from: h  reason: collision with root package name */
    public n0 f332h;

    /* renamed from: i  reason: collision with root package name */
    public /* synthetic */ Object f333i;

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ f0 f334j;

    /* renamed from: k  reason: collision with root package name */
    public int f335k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e0(f0 f0Var, e eVar) {
        super(eVar);
        this.f334j = f0Var;
    }

    public final Object p(Object obj) {
        this.f333i = obj;
        this.f335k |= Integer.MIN_VALUE;
        return this.f334j.a((g) null, this);
    }
}
