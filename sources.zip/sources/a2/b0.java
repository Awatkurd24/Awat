package a2;

import a4.w;
import ac.b;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.lifecycle.j1;
import androidx.lifecycle.w0;
import androidx.lifecycle.z0;
import androidx.preference.h0;
import co.dev.ui.WelcomeActivity;
import com.blacksquircle.ui.editorkit.widget.internal.SyntaxHighlightEditText;
import com.maxkeppeler.sheets.core.views.SheetButtonToggleGroup;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import com.v2ray.ang.ui.MainActivity;
import com.v2ray.ang.ui.MainRecyclerAdapter;
import com.v2ray.ang.ui.PerAppProxyActivity;
import com.v2ray.ang.ui.RoutingSettingsFragment;
import com.v2ray.ang.ui.SubEditActivity;
import com.v2ray.ang.ui.SubSettingActivity;
import com.v2ray.ang.ui.SubSettingRecyclerAdapter;
import com.v2ray.ang.ui.UserAssetActivity;
import com.v2ray.ang.util.Utils;
import eg.n;
import g3.f;
import g3.g;
import ge.a;
import he.l;
import io.github.g00fy2.quickie.QRScannerActivity;
import io.tooldroid.dialog.ToolDroidDialog;
import java.io.File;
import java.io.StringReader;
import java.math.BigInteger;
import java.net.ProxySelector;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.Executor;
import javax.net.SocketFactory;
import jh.d0;
import jh.o;
import jh.s;
import o5.c;
import o5.d;
import qe.j0;
import qe.m0;
import qe.n0;
import qe.p0;
import qe.q0;
import qe.t1;
import qe.u1;
import qe.w1;
import t.o0;
import t.u;
import v7.c1;
import v7.g9;
import v7.i9;
import v7.r0;
import ve.i;
import wd.m;
import we.s0;
import xd.k;
import xd.q;
import ze.a0;

public final class b0 extends l implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f301a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f302b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b0(int i10, Object obj) {
        super(0);
        this.f301a = i10;
        this.f302b = obj;
    }

    public final SharedPreferences a() {
        int i10 = this.f301a;
        Object obj = this.f302b;
        switch (i10) {
            case 5:
                return h0.a(((WelcomeActivity) obj).getBaseContext());
            case 10:
                return h0.a((PerAppProxyActivity) obj);
            default:
                return h0.a(((RoutingSettingsFragment) obj).requireContext());
        }
    }

    public final File b() {
        switch (this.f301a) {
            case 0:
                File file = (File) ((n0) this.f302b).f391a.invoke();
                String absolutePath = file.getAbsolutePath();
                synchronized (n0.f390k) {
                    LinkedHashSet linkedHashSet = n0.f389j;
                    if (!linkedHashSet.contains(absolutePath)) {
                        r0.i("it", absolutePath);
                        linkedHashSet.add(absolutePath);
                    } else {
                        throw new IllegalStateException(("There are multiple DataStores active for the same file: " + file + ". You should either maintain your DataStore as a singleton or confirm that there is no two DataStore's active on the same file (by confirming that the scope is cancelled).").toString());
                    }
                }
                return file;
            default:
                return new File(Utils.INSTANCE.userAssetPath((UserAssetActivity) this.f302b));
        }
    }

    public final Integer c() {
        int i10;
        int i11 = this.f301a;
        Object obj = this.f302b;
        switch (i11) {
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                Context context = ((SheetButtonToggleGroup) obj).getContext();
                r0.i("context", context);
                return Integer.valueOf(i9.w(context));
            default:
                int i12 = 0;
                for (Map.Entry entry : ((Map) obj).entrySet()) {
                    String str = (String) entry.getKey();
                    Object value = entry.getValue();
                    if (value instanceof boolean[]) {
                        i10 = Arrays.hashCode((boolean[]) value);
                    } else if (value instanceof char[]) {
                        i10 = Arrays.hashCode((char[]) value);
                    } else if (value instanceof byte[]) {
                        i10 = Arrays.hashCode((byte[]) value);
                    } else if (value instanceof short[]) {
                        i10 = Arrays.hashCode((short[]) value);
                    } else if (value instanceof int[]) {
                        i10 = Arrays.hashCode((int[]) value);
                    } else if (value instanceof float[]) {
                        i10 = Arrays.hashCode((float[]) value);
                    } else if (value instanceof long[]) {
                        i10 = Arrays.hashCode((long[]) value);
                    } else if (value instanceof double[]) {
                        i10 = Arrays.hashCode((double[]) value);
                    } else if (value instanceof Object[]) {
                        i10 = Arrays.hashCode((Object[]) value);
                    } else {
                        i10 = value.hashCode();
                    }
                    i12 += i10 ^ (str.hashCode() * 127);
                }
                return Integer.valueOf(i12);
        }
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [q5.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v8, types: [a2.h, java.lang.Object] */
    public final List i() {
        o5.a aVar;
        int i10 = this.f301a;
        Object obj = this.f302b;
        switch (i10) {
            case 7:
                SyntaxHighlightEditText syntaxHighlightEditText = (SyntaxHighlightEditText) obj;
                if (syntaxHighlightEditText.getLanguage() == null) {
                    return q.f29842a;
                }
                if (h.f351a == null) {
                    h.f351a = new Object();
                }
                c structure = syntaxHighlightEditText.getStructure();
                r0.j("structure", structure);
                String obj2 = structure.f23586a.toString();
                ArrayList arrayList = new ArrayList();
                StringReader stringReader = new StringReader(obj2);
                ? obj3 = new Object();
                obj3.f24853c = new char[16384];
                obj3.f24859i = 0;
                obj3.f24851a = stringReader;
                while (true) {
                    try {
                        int ordinal = obj3.a().ordinal();
                        if (ordinal == 17) {
                            return arrayList;
                        }
                        switch (ordinal) {
                            case 0:
                                aVar = new o5.a(d.f23588a, (int) obj3.f24860j, obj3.b());
                                break;
                            case 1:
                            case 2:
                            case 3:
                                aVar = new o5.a(d.f23590c, (int) obj3.f24860j, obj3.b());
                                break;
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                            case 9:
                                aVar = new o5.a(d.f23589b, (int) obj3.f24860j, obj3.b());
                                break;
                            case 10:
                            case AppConfig.MSG_STATE_RUNNING /*11*/:
                                aVar = new o5.a(d.f23591d, (int) obj3.f24860j, obj3.b());
                                break;
                            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                            case 13:
                                aVar = new o5.a(d.f23592e, (int) obj3.f24860j, obj3.b());
                                break;
                            default:
                                continue;
                        }
                        arrayList.add(aVar);
                    } catch (Throwable th2) {
                        th2.printStackTrace();
                        return arrayList;
                    }
                }
            default:
                Iterable upperBounds = ((u1) obj).f25085a.getUpperBounds();
                r0.i("getUpperBounds(...)", upperBounds);
                Iterable<lg.b0> iterable = upperBounds;
                ArrayList arrayList2 = new ArrayList(xd.l.R(iterable));
                for (lg.b0 t1Var : iterable) {
                    arrayList2.add(new t1(t1Var, (a) null));
                }
                return arrayList2;
        }
    }

    public final Object invoke() {
        f fVar;
        o0 o0Var;
        Integer num;
        int i10;
        Collection collection;
        int i11 = this.f301a;
        Object obj = this.f302b;
        switch (i11) {
            case 0:
                return b();
            case 1:
                j1 j1Var = (j1) obj;
                r0.j("<this>", j1Var);
                return (z0) new w(j1Var, new w0(0)).q(z0.class, "androidx.lifecycle.internal.SavedStateHandlesVM");
            case 2:
                return ((m.d) obj).o();
            case 3:
                if (Build.VERSION.SDK_INT >= 23) {
                    g gVar = (g) obj;
                    if (gVar.f19091b != null && gVar.f19093d) {
                        Context context = gVar.f19090a;
                        r0.j("context", context);
                        File noBackupFilesDir = context.getNoBackupFilesDir();
                        r0.i("context.noBackupFilesDir", noBackupFilesDir);
                        fVar = new f(gVar.f19090a, new File(noBackupFilesDir, gVar.f19091b).getAbsolutePath(), new ha.c(13, (Object) null), gVar.f19092c, gVar.f19094e);
                        fVar.setWriteAheadLoggingEnabled(((g) obj).f19096g);
                        return fVar;
                    }
                }
                g gVar2 = (g) obj;
                fVar = new f(gVar2.f19090a, gVar2.f19091b, new ha.c(13, (Object) null), gVar2.f19092c, gVar2.f19094e);
                fVar.setWriteAheadLoggingEnabled(((g) obj).f19096g);
                return fVar;
            case 4:
                q3.g gVar3 = (q3.g) obj;
                return BigInteger.valueOf((long) gVar3.f24831a).shiftLeft(32).or(BigInteger.valueOf((long) gVar3.f24832b)).shiftLeft(32).or(BigInteger.valueOf((long) gVar3.f24833c));
            case 5:
                return a();
            case 6:
                new ArrayList();
                new ArrayList();
                new s();
                List list = d0.f21038y;
                List list2 = d0.f21038y;
                jh.w.factory(jh.w.NONE);
                if (ProxySelector.getDefault() == null) {
                    new ProxySelector();
                }
                SocketFactory.getDefault();
                jh.l lVar = jh.l.f21147c;
                new o();
                ((c1) obj).getClass();
                r0.j("context", (Object) null);
                throw null;
            case 7:
                return i();
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return c();
            case 9:
                return new MainRecyclerAdapter((MainActivity) obj);
            case 10:
                return a();
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                return a();
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                String stringExtra = ((SubEditActivity) obj).getIntent().getStringExtra("subId");
                if (stringExtra == null) {
                    return "";
                }
                return stringExtra;
            case 13:
                return new SubSettingRecyclerAdapter((SubSettingActivity) obj);
            case 14:
                return b();
            case 15:
                sd.a aVar = (sd.a) obj;
                int[] iArr = aVar.f25973a;
                if (iArr.length > 1) {
                    o0Var = new o0();
                    if (iArr.length != 0) {
                        int i12 = iArr[0];
                        r0.j("<this>", iArr);
                        int length = iArr.length - 1;
                        if (length < 0) {
                            length = 0;
                        }
                        if (length >= 0) {
                            if (length == 0) {
                                collection = q.f29842a;
                            } else {
                                int length2 = iArr.length;
                                if (length >= length2) {
                                    collection = k.V2(iArr);
                                } else if (length == 1) {
                                    collection = i9.A(Integer.valueOf(iArr[length2 - 1]));
                                } else {
                                    ArrayList arrayList = new ArrayList(length);
                                    for (int i13 = length2 - length; i13 < length2; i13++) {
                                        arrayList.add(Integer.valueOf(iArr[i13]));
                                    }
                                    collection = arrayList;
                                }
                            }
                            int[] A0 = xd.o.A0(collection);
                            int[] copyOf = Arrays.copyOf(A0, A0.length);
                            o0Var.f26345c = i12;
                            if (copyOf != null) {
                                for (int i14 : copyOf) {
                                    o0Var.f26345c = i14 | o0Var.f26345c;
                                }
                            }
                        } else {
                            throw new IllegalArgumentException(u.c("Requested element count ", length, " is less than zero.").toString());
                        }
                    } else {
                        throw new NoSuchElementException("Array is empty.");
                    }
                } else {
                    o0Var = new o0();
                    if (iArr.length == 0) {
                        num = null;
                    } else {
                        num = Integer.valueOf(iArr[0]);
                    }
                    if (num != null) {
                        i10 = num.intValue();
                    } else {
                        i10 = -1;
                    }
                    o0Var.f26345c = i10;
                }
                try {
                    f.c.w(o0Var.f26347e);
                    return r0.q(new b(o0Var.f26345c, o0Var.f26344b, (Executor) o0Var.f26346d));
                } catch (Exception e10) {
                    aVar.f25975c.h(e10);
                    return null;
                }
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                ((QRScannerActivity) obj).finish();
                return m.f29306a;
            case ToolDroidDialog.CENTER /*17*/:
                switch (i11) {
                    case ToolDroidDialog.CENTER /*17*/:
                        return g9.k((Object[]) obj);
                    default:
                        return ((Iterable) obj).iterator();
                }
            case 18:
                switch (i11) {
                    case ToolDroidDialog.CENTER /*17*/:
                        return g9.k((Object[]) obj);
                    default:
                        return ((Iterable) obj).iterator();
                }
            case 19:
                return w1.a(((j0) obj).c());
            case 20:
                return new m0((n0) obj);
            case 21:
                return new qe.o0((p0) obj);
            case 22:
                return new q0((qe.r0) obj);
            case 23:
                return i();
            case 24:
                return c();
            case 25:
                switch (i11) {
                    case 25:
                        return ((a0) ((we.b0) obj).M(te.q.f26827i)).f31421g;
                    default:
                        s0 s0Var = (s0) obj;
                        return (n) s0Var.f29372b.h(s0Var.f29373c);
                }
            case 26:
                ve.k kVar = (ve.k) obj;
                a aVar2 = kVar.f28338f;
                if (aVar2 != null) {
                    i iVar = (i) aVar2.invoke();
                    kVar.f28338f = null;
                    return iVar;
                }
                throw new AssertionError("JvmBuiltins instance has not been initialized properly");
            case 27:
                switch (i11) {
                    case 25:
                        return ((a0) ((we.b0) obj).M(te.q.f26827i)).f31421g;
                    default:
                        s0 s0Var2 = (s0) obj;
                        return (n) s0Var2.f29372b.h(s0Var2.f29373c);
                }
            case 28:
                xe.k kVar2 = (xe.k) obj;
                return kVar2.f29876a.i(kVar2.f29877b).l();
            default:
                ef.a0 a0Var = (ef.a0) obj;
                yd.b bVar = new yd.b();
                bVar.add(a0Var.f18201a.f18267a);
                ef.h0 h0Var = a0Var.f18202b;
                if (h0Var != null) {
                    bVar.add("under-migration:" + h0Var.f18267a);
                }
                for (Map.Entry entry : a0Var.f18203c.entrySet()) {
                    bVar.add("@" + entry.getKey() + ':' + ((ef.h0) entry.getValue()).f18267a);
                }
                return (String[]) i9.e(bVar).toArray(new String[0]);
        }
    }
}
