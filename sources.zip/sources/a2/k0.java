package a2;

import be.c;
import zd.e;
import zd.j;

public final class k0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f368d;

    /* renamed from: e  reason: collision with root package name */
    public Object f369e;

    /* renamed from: f  reason: collision with root package name */
    public Object f370f;

    /* renamed from: g  reason: collision with root package name */
    public /* synthetic */ Object f371g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ n0 f372h;

    /* renamed from: i  reason: collision with root package name */
    public int f373i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k0(n0 n0Var, e eVar) {
        super(eVar);
        this.f372h = n0Var;
    }

    public final Object p(Object obj) {
        this.f371g = obj;
        this.f373i |= Integer.MIN_VALUE;
        return this.f372h.j(this, (j) null, (ge.c) null);
    }
}
