package a2;

import a4.i;
import bh.u;
import d2.k;
import ge.a;
import ge.c;
import java.io.File;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import v7.l9;
import v7.r0;
import wd.j;
import xd.o;
import yg.a1;
import yg.b0;
import yg.f1;
import yg.k1;
import yg.r;
import yg.v0;
import yg.y0;
import yg.z;
import yg.z0;
import zd.e;

public final class n0 implements j {

    /* renamed from: j  reason: collision with root package name */
    public static final LinkedHashSet f389j = new LinkedHashSet();

    /* renamed from: k  reason: collision with root package name */
    public static final Object f390k = new Object();

    /* renamed from: a  reason: collision with root package name */
    public final a f391a;

    /* renamed from: b  reason: collision with root package name */
    public final m f392b;

    /* renamed from: c  reason: collision with root package name */
    public final b f393c;

    /* renamed from: d  reason: collision with root package name */
    public final z f394d = new z((c) new a0(this, (e) null));

    /* renamed from: e  reason: collision with root package name */
    public final String f395e = ".tmp";

    /* renamed from: f  reason: collision with root package name */
    public final j f396f = new j(new b0(0, this));

    /* renamed from: g  reason: collision with root package name */
    public final u f397g = new u(p0.f404a);

    /* renamed from: h  reason: collision with root package name */
    public List f398h;

    /* renamed from: i  reason: collision with root package name */
    public final i f399i;

    /* JADX WARNING: type inference failed for: r4v6, types: [a4.i, java.lang.Object] */
    public n0(d2.e eVar, List list, b bVar, z zVar) {
        k kVar = k.f17650a;
        this.f391a = eVar;
        this.f392b = kVar;
        this.f393c = bVar;
        this.f398h = o.B0(list);
        t tVar = new t(0, this);
        u uVar = u.f412a;
        v vVar = new v(this, (e) null);
        ? obj = new Object();
        obj.f549a = zVar;
        obj.f550b = vVar;
        obj.f551c = l9.a(Integer.MAX_VALUE, (ah.a) null, 6);
        obj.f552d = new AtomicInteger(0);
        a1 a1Var = (a1) ((z) obj.f549a).q().get(z0.f30362a);
        if (a1Var != null) {
            ((k1) a1Var).D(false, true, new n(tVar, obj, uVar, 0));
        }
        this.f399i = obj;
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ac A[Catch:{ all -> 0x0079 }] */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00d1  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0026  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Object c(a2.n0 r8, a2.q r9, zd.e r10) {
        /*
            r8.getClass()
            boolean r0 = r10 instanceof a2.c0
            if (r0 == 0) goto L_0x0016
            r0 = r10
            a2.c0 r0 = (a2.c0) r0
            int r1 = r0.f310i
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0016
            int r1 = r1 - r2
            r0.f310i = r1
            goto L_0x001b
        L_0x0016:
            a2.c0 r0 = new a2.c0
            r0.<init>(r8, r10)
        L_0x001b:
            java.lang.Object r10 = r0.f308g
            ae.a r1 = ae.a.f795a
            int r2 = r0.f310i
            r3 = 3
            r4 = 2
            r5 = 1
            if (r2 == 0) goto L_0x0054
            if (r2 == r5) goto L_0x004f
            if (r2 == r4) goto L_0x0040
            if (r2 != r3) goto L_0x0038
            java.lang.Object r8 = r0.f305d
            yg.n r8 = (yg.n) r8
        L_0x0030:
            v7.r0.C(r10)     // Catch:{ all -> 0x0035 }
            goto L_0x00c5
        L_0x0035:
            r9 = move-exception
            goto L_0x00c1
        L_0x0038:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L_0x0040:
            yg.n r8 = r0.f307f
            a2.n0 r9 = r0.f306e
            java.lang.Object r2 = r0.f305d
            a2.q r2 = (a2.q) r2
            v7.r0.C(r10)     // Catch:{ all -> 0x0035 }
            r10 = r8
            r8 = r9
            r9 = r2
            goto L_0x0099
        L_0x004f:
            java.lang.Object r8 = r0.f305d
            yg.n r8 = (yg.n) r8
            goto L_0x0030
        L_0x0054:
            v7.r0.C(r10)
            yg.n r10 = r9.f406b
            bh.u r2 = r8.f397g     // Catch:{ all -> 0x0079 }
            java.lang.Object r2 = r2.c()     // Catch:{ all -> 0x0079 }
            a2.o0 r2 = (a2.o0) r2     // Catch:{ all -> 0x0079 }
            boolean r6 = r2 instanceof a2.c     // Catch:{ all -> 0x0079 }
            if (r6 == 0) goto L_0x007c
            ge.c r2 = r9.f405a     // Catch:{ all -> 0x0079 }
            zd.j r9 = r9.f408d     // Catch:{ all -> 0x0079 }
            r0.f305d = r10     // Catch:{ all -> 0x0079 }
            r0.f310i = r5     // Catch:{ all -> 0x0079 }
            java.lang.Object r8 = r8.j(r0, r9, r2)     // Catch:{ all -> 0x0079 }
            if (r8 != r1) goto L_0x0075
            goto L_0x0102
        L_0x0075:
            r7 = r10
            r10 = r8
            r8 = r7
            goto L_0x00c5
        L_0x0079:
            r9 = move-exception
            r8 = r10
            goto L_0x00c1
        L_0x007c:
            boolean r5 = r2 instanceof a2.l     // Catch:{ all -> 0x0079 }
            if (r5 == 0) goto L_0x0081
            goto L_0x0085
        L_0x0081:
            boolean r5 = r2 instanceof a2.p0     // Catch:{ all -> 0x0079 }
            if (r5 == 0) goto L_0x00b2
        L_0x0085:
            a2.o0 r5 = r9.f407c     // Catch:{ all -> 0x0079 }
            if (r2 != r5) goto L_0x00ad
            r0.f305d = r9     // Catch:{ all -> 0x0079 }
            r0.f306e = r8     // Catch:{ all -> 0x0079 }
            r0.f307f = r10     // Catch:{ all -> 0x0079 }
            r0.f310i = r4     // Catch:{ all -> 0x0079 }
            java.lang.Object r2 = r8.f(r0)     // Catch:{ all -> 0x0079 }
            if (r2 != r1) goto L_0x0099
            goto L_0x0102
        L_0x0099:
            ge.c r2 = r9.f405a     // Catch:{ all -> 0x0079 }
            zd.j r9 = r9.f408d     // Catch:{ all -> 0x0079 }
            r0.f305d = r10     // Catch:{ all -> 0x0079 }
            r4 = 0
            r0.f306e = r4     // Catch:{ all -> 0x0079 }
            r0.f307f = r4     // Catch:{ all -> 0x0079 }
            r0.f310i = r3     // Catch:{ all -> 0x0079 }
            java.lang.Object r8 = r8.j(r0, r9, r2)     // Catch:{ all -> 0x0079 }
            if (r8 != r1) goto L_0x0075
            goto L_0x0102
        L_0x00ad:
            a2.l r2 = (a2.l) r2     // Catch:{ all -> 0x0079 }
            java.lang.Throwable r8 = r2.f374a     // Catch:{ all -> 0x0079 }
            throw r8     // Catch:{ all -> 0x0079 }
        L_0x00b2:
            boolean r8 = r2 instanceof a2.k     // Catch:{ all -> 0x0079 }
            if (r8 == 0) goto L_0x00bb
            a2.k r2 = (a2.k) r2     // Catch:{ all -> 0x0079 }
            java.lang.Throwable r8 = r2.f367a     // Catch:{ all -> 0x0079 }
            throw r8     // Catch:{ all -> 0x0079 }
        L_0x00bb:
            n1.q r8 = new n1.q     // Catch:{ all -> 0x0079 }
            r8.<init>()     // Catch:{ all -> 0x0079 }
            throw r8     // Catch:{ all -> 0x0079 }
        L_0x00c1:
            wd.g r10 = v7.r0.m(r9)
        L_0x00c5:
            java.lang.Throwable r9 = wd.h.a(r10)
            dh.w r0 = yg.b0.f30270f
            dh.w r1 = yg.b0.f30269e
            dh.w r2 = yg.b0.f30268d
            if (r9 != 0) goto L_0x00e5
            r3 = r8
            yg.o r3 = (yg.o) r3
        L_0x00d4:
            java.lang.Object r8 = r3.z()
            java.lang.Object r8 = r3.O(r8, r10)
            if (r8 != r2) goto L_0x00df
            goto L_0x0100
        L_0x00df:
            if (r8 != r1) goto L_0x00e2
            goto L_0x0100
        L_0x00e2:
            if (r8 == r0) goto L_0x00d4
            goto L_0x0100
        L_0x00e5:
            yg.o r8 = (yg.o) r8
            r8.getClass()
            yg.r r10 = new yg.r
            r3 = 0
            r10.<init>(r9, r3)
        L_0x00f0:
            java.lang.Object r9 = r8.z()
            java.lang.Object r9 = r8.O(r9, r10)
            if (r9 != r2) goto L_0x00fb
            goto L_0x0100
        L_0x00fb:
            if (r9 != r1) goto L_0x00fe
            goto L_0x0100
        L_0x00fe:
            if (r9 == r0) goto L_0x00f0
        L_0x0100:
            wd.m r1 = wd.m.f29306a
        L_0x0102:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.c(a2.n0, a2.q, zd.e):java.lang.Object");
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [yg.o, yg.k1] */
    public final Object a(c cVar, e eVar) {
        Object C;
        ? k1Var = new k1(true);
        k1Var.C((a1) null);
        this.f399i.r(new q(cVar, k1Var, (o0) this.f397g.c(), eVar.getContext()));
        while (true) {
            Object z4 = k1Var.z();
            if (!(z4 instanceof v0)) {
                if (!(z4 instanceof r)) {
                    C = b0.C(z4);
                } else {
                    throw ((r) z4).f30339a;
                }
            } else if (k1Var.M(z4) >= 0) {
                f1 f1Var = new f1(r0.s(eVar), k1Var);
                f1Var.u();
                f1Var.w(new yg.e(1, k1Var.D(false, true, new y0(1, f1Var))));
                C = f1Var.t();
                if (C == ae.a.f795a) {
                    com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.t1(eVar);
                }
            }
        }
        ae.a aVar = ae.a.f795a;
        return C;
    }

    public final bh.e b() {
        return this.f394d;
    }

    public final File d() {
        return (File) this.f396f.getValue();
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: type inference failed for: r14v13, types: [he.t, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v11, types: [java.lang.Object, java.io.Serializable] */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x006f  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00c2  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00d8  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0111 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0112  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object e(zd.e r14) {
        /*
            r13 = this;
            boolean r0 = r14 instanceof a2.d0
            if (r0 == 0) goto L_0x0013
            r0 = r14
            a2.d0 r0 = (a2.d0) r0
            int r1 = r0.f322l
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f322l = r1
            goto L_0x0018
        L_0x0013:
            a2.d0 r0 = new a2.d0
            r0.<init>(r13, r14)
        L_0x0018:
            java.lang.Object r14 = r0.f320j
            ae.a r1 = ae.a.f795a
            int r2 = r0.f322l
            r3 = 0
            r4 = 3
            r5 = 2
            r6 = 1
            r7 = 0
            if (r2 == 0) goto L_0x006f
            if (r2 == r6) goto L_0x005d
            if (r2 == r5) goto L_0x0046
            if (r2 != r4) goto L_0x003e
            java.lang.Object r1 = r0.f317g
            gh.a r1 = (gh.a) r1
            java.io.Serializable r2 = r0.f316f
            he.t r2 = (he.t) r2
            java.lang.Object r4 = r0.f315e
            he.v r4 = (he.v) r4
            a2.n0 r0 = r0.f314d
            v7.r0.C(r14)
            goto L_0x0114
        L_0x003e:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r0)
            throw r14
        L_0x0046:
            java.util.Iterator r2 = r0.f319i
            a2.f0 r8 = r0.f318h
            java.lang.Object r9 = r0.f317g
            he.t r9 = (he.t) r9
            java.io.Serializable r10 = r0.f316f
            he.v r10 = (he.v) r10
            java.lang.Object r11 = r0.f315e
            gh.a r11 = (gh.a) r11
            a2.n0 r12 = r0.f314d
            v7.r0.C(r14)
            goto L_0x00d2
        L_0x005d:
            java.lang.Object r2 = r0.f317g
            he.v r2 = (he.v) r2
            java.io.Serializable r8 = r0.f316f
            he.v r8 = (he.v) r8
            java.lang.Object r9 = r0.f315e
            gh.a r9 = (gh.a) r9
            a2.n0 r10 = r0.f314d
            v7.r0.C(r14)
            goto L_0x00b2
        L_0x006f:
            v7.r0.C(r14)
            bh.u r14 = r13.f397g
            java.lang.Object r2 = r14.c()
            a2.p0 r8 = a2.p0.f404a
            boolean r2 = v7.r0.b(r2, r8)
            if (r2 != 0) goto L_0x0095
            java.lang.Object r14 = r14.c()
            boolean r14 = r14 instanceof a2.l
            if (r14 == 0) goto L_0x0089
            goto L_0x0095
        L_0x0089:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "Check failed."
            java.lang.String r0 = r0.toString()
            r14.<init>(r0)
            throw r14
        L_0x0095:
            gh.d r9 = new gh.d
            r9.<init>(r3)
            he.v r2 = new he.v
            r2.<init>()
            r0.f314d = r13
            r0.f315e = r9
            r0.f316f = r2
            r0.f317g = r2
            r0.f322l = r6
            java.lang.Object r14 = r13.i(r0)
            if (r14 != r1) goto L_0x00b0
            return r1
        L_0x00b0:
            r10 = r13
            r8 = r2
        L_0x00b2:
            r2.f19690a = r14
            he.t r14 = new he.t
            r14.<init>()
            a2.f0 r2 = new a2.f0
            r2.<init>(r9, r14, r8, r10)
            java.util.List r11 = r10.f398h
            if (r11 != 0) goto L_0x00c6
            r2 = r14
            r14 = r0
            r0 = r10
            goto L_0x00f8
        L_0x00c6:
            java.lang.Iterable r11 = (java.lang.Iterable) r11
            java.util.Iterator r11 = r11.iterator()
            r12 = r10
            r10 = r8
            r8 = r2
            r2 = r11
            r11 = r9
            r9 = r14
        L_0x00d2:
            boolean r14 = r2.hasNext()
            if (r14 == 0) goto L_0x00f3
            java.lang.Object r14 = r2.next()
            ge.c r14 = (ge.c) r14
            r0.f314d = r12
            r0.f315e = r11
            r0.f316f = r10
            r0.f317g = r9
            r0.f318h = r8
            r0.f319i = r2
            r0.f322l = r5
            java.lang.Object r14 = r14.g(r8, r0)
            if (r14 != r1) goto L_0x00d2
            return r1
        L_0x00f3:
            r14 = r0
            r2 = r9
            r8 = r10
            r9 = r11
            r0 = r12
        L_0x00f8:
            r0.f398h = r7
            r14.f314d = r0
            r14.f315e = r8
            r14.f316f = r2
            r14.f317g = r9
            r14.f318h = r7
            r14.f319i = r7
            r14.f322l = r4
            r4 = r9
            gh.d r4 = (gh.d) r4
            java.lang.Object r14 = r4.d(r14)
            if (r14 != r1) goto L_0x0112
            return r1
        L_0x0112:
            r1 = r4
            r4 = r8
        L_0x0114:
            r2.f19688a = r6     // Catch:{ all -> 0x0130 }
            gh.d r1 = (gh.d) r1
            r1.e(r7)
            bh.u r14 = r0.f397g
            a2.c r0 = new a2.c
            java.lang.Object r1 = r4.f19690a
            if (r1 == 0) goto L_0x0127
            int r3 = r1.hashCode()
        L_0x0127:
            r0.<init>(r3, r1)
            r14.d(r0)
            wd.m r14 = wd.m.f29306a
            return r14
        L_0x0130:
            r14 = move-exception
            gh.d r1 = (gh.d) r1
            r1.e(r7)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.e(zd.e):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object f(zd.e r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof a2.g0
            if (r0 == 0) goto L_0x0013
            r0 = r5
            a2.g0 r0 = (a2.g0) r0
            int r1 = r0.f350g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f350g = r1
            goto L_0x0018
        L_0x0013:
            a2.g0 r0 = new a2.g0
            r0.<init>(r4, r5)
        L_0x0018:
            java.lang.Object r5 = r0.f348e
            ae.a r1 = ae.a.f795a
            int r2 = r0.f350g
            r3 = 1
            if (r2 == 0) goto L_0x0033
            if (r2 != r3) goto L_0x002b
            a2.n0 r0 = r0.f347d
            v7.r0.C(r5)     // Catch:{ all -> 0x0029 }
            goto L_0x0041
        L_0x0029:
            r5 = move-exception
            goto L_0x0046
        L_0x002b:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L_0x0033:
            v7.r0.C(r5)
            r0.f347d = r4     // Catch:{ all -> 0x0044 }
            r0.f350g = r3     // Catch:{ all -> 0x0044 }
            java.lang.Object r5 = r4.e(r0)     // Catch:{ all -> 0x0044 }
            if (r5 != r1) goto L_0x0041
            return r1
        L_0x0041:
            wd.m r5 = wd.m.f29306a
            return r5
        L_0x0044:
            r5 = move-exception
            r0 = r4
        L_0x0046:
            bh.u r0 = r0.f397g
            a2.l r1 = new a2.l
            r1.<init>(r5)
            r0.d(r1)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.f(zd.e):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object g(zd.e r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof a2.h0
            if (r0 == 0) goto L_0x0013
            r0 = r5
            a2.h0 r0 = (a2.h0) r0
            int r1 = r0.f355g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f355g = r1
            goto L_0x0018
        L_0x0013:
            a2.h0 r0 = new a2.h0
            r0.<init>(r4, r5)
        L_0x0018:
            java.lang.Object r5 = r0.f353e
            ae.a r1 = ae.a.f795a
            int r2 = r0.f355g
            r3 = 1
            if (r2 == 0) goto L_0x0033
            if (r2 != r3) goto L_0x002b
            a2.n0 r0 = r0.f352d
            v7.r0.C(r5)     // Catch:{ all -> 0x0029 }
            goto L_0x004d
        L_0x0029:
            r5 = move-exception
            goto L_0x0043
        L_0x002b:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L_0x0033:
            v7.r0.C(r5)
            r0.f352d = r4     // Catch:{ all -> 0x0041 }
            r0.f355g = r3     // Catch:{ all -> 0x0041 }
            java.lang.Object r5 = r4.e(r0)     // Catch:{ all -> 0x0041 }
            if (r5 != r1) goto L_0x004d
            return r1
        L_0x0041:
            r5 = move-exception
            r0 = r4
        L_0x0043:
            bh.u r0 = r0.f397g
            a2.l r1 = new a2.l
            r1.<init>(r5)
            r0.d(r1)
        L_0x004d:
            wd.m r5 = wd.m.f29306a
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.g(zd.e):java.lang.Object");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x005a, code lost:
        r5 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0063, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
        com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.w(r1, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0067, code lost:
        throw r2;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [B:24:0x0056, B:30:0x0062] */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object h(zd.e r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof a2.i0
            if (r0 == 0) goto L_0x0013
            r0 = r5
            a2.i0 r0 = (a2.i0) r0
            int r1 = r0.f361h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f361h = r1
            goto L_0x0018
        L_0x0013:
            a2.i0 r0 = new a2.i0
            r0.<init>(r4, r5)
        L_0x0018:
            java.lang.Object r5 = r0.f359f
            ae.a r1 = ae.a.f795a
            int r2 = r0.f361h
            r3 = 1
            if (r2 == 0) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            java.io.FileInputStream r1 = r0.f358e
            a2.n0 r0 = r0.f357d
            v7.r0.C(r5)     // Catch:{ all -> 0x002b }
            goto L_0x0055
        L_0x002b:
            r5 = move-exception
            goto L_0x0062
        L_0x002d:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L_0x0035:
            v7.r0.C(r5)
            java.io.FileInputStream r5 = new java.io.FileInputStream     // Catch:{ FileNotFoundException -> 0x0068 }
            java.io.File r2 = r4.d()     // Catch:{ FileNotFoundException -> 0x0068 }
            r5.<init>(r2)     // Catch:{ FileNotFoundException -> 0x0068 }
            a2.m r2 = r4.f392b     // Catch:{ all -> 0x0060 }
            r0.f357d = r4     // Catch:{ all -> 0x0060 }
            r0.f358e = r5     // Catch:{ all -> 0x0060 }
            r0.f361h = r3     // Catch:{ all -> 0x0060 }
            d2.k r2 = (d2.k) r2     // Catch:{ all -> 0x0060 }
            d2.b r0 = r2.a(r5)     // Catch:{ all -> 0x0060 }
            if (r0 != r1) goto L_0x0052
            return r1
        L_0x0052:
            r1 = r5
            r5 = r0
            r0 = r4
        L_0x0055:
            r2 = 0
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.w(r1, r2)     // Catch:{ FileNotFoundException -> 0x005a }
            return r5
        L_0x005a:
            r5 = move-exception
            goto L_0x006a
        L_0x005c:
            r1 = r5
            r5 = r0
            r0 = r4
            goto L_0x0062
        L_0x0060:
            r0 = move-exception
            goto L_0x005c
        L_0x0062:
            throw r5     // Catch:{ all -> 0x0063 }
        L_0x0063:
            r2 = move-exception
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.w(r1, r5)     // Catch:{ FileNotFoundException -> 0x005a }
            throw r2     // Catch:{ FileNotFoundException -> 0x005a }
        L_0x0068:
            r5 = move-exception
            r0 = r4
        L_0x006a:
            java.io.File r1 = r0.d()
            boolean r1 = r1.exists()
            if (r1 != 0) goto L_0x0081
            a2.m r5 = r0.f392b
            d2.k r5 = (d2.k) r5
            r5.getClass()
            d2.b r5 = new d2.b
            r5.<init>(r3)
            return r5
        L_0x0081:
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.h(zd.e):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0083 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object i(zd.e r8) {
        /*
            r7 = this;
            boolean r0 = r8 instanceof a2.j0
            if (r0 == 0) goto L_0x0013
            r0 = r8
            a2.j0 r0 = (a2.j0) r0
            int r1 = r0.f366h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f366h = r1
            goto L_0x0018
        L_0x0013:
            a2.j0 r0 = new a2.j0
            r0.<init>(r7, r8)
        L_0x0018:
            java.lang.Object r8 = r0.f364f
            ae.a r1 = ae.a.f795a
            int r2 = r0.f366h
            r3 = 3
            r4 = 2
            r5 = 1
            if (r2 == 0) goto L_0x0053
            if (r2 == r5) goto L_0x0049
            if (r2 == r4) goto L_0x003d
            if (r2 != r3) goto L_0x0035
            java.lang.Object r1 = r0.f363e
            java.lang.Object r0 = r0.f362d
            a2.a r0 = (a2.a) r0
            v7.r0.C(r8)     // Catch:{ IOException -> 0x0033 }
            goto L_0x0085
        L_0x0033:
            r8 = move-exception
            goto L_0x0088
        L_0x0035:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L_0x003d:
            java.lang.Object r2 = r0.f363e
            a2.a r2 = (a2.a) r2
            java.lang.Object r4 = r0.f362d
            a2.n0 r4 = (a2.n0) r4
            v7.r0.C(r8)
            goto L_0x0077
        L_0x0049:
            java.lang.Object r2 = r0.f362d
            a2.n0 r2 = (a2.n0) r2
            v7.r0.C(r8)     // Catch:{ a -> 0x0051 }
            goto L_0x0061
        L_0x0051:
            r8 = move-exception
            goto L_0x0064
        L_0x0053:
            v7.r0.C(r8)
            r0.f362d = r7     // Catch:{ a -> 0x0062 }
            r0.f366h = r5     // Catch:{ a -> 0x0062 }
            java.lang.Object r8 = r7.h(r0)     // Catch:{ a -> 0x0062 }
            if (r8 != r1) goto L_0x0061
            return r1
        L_0x0061:
            return r8
        L_0x0062:
            r8 = move-exception
            r2 = r7
        L_0x0064:
            a2.b r5 = r2.f393c
            r0.f362d = r2
            r0.f363e = r8
            r0.f366h = r4
            java.lang.Object r4 = r5.b(r8)
            if (r4 != r1) goto L_0x0073
            return r1
        L_0x0073:
            r6 = r2
            r2 = r8
            r8 = r4
            r4 = r6
        L_0x0077:
            r0.f362d = r2     // Catch:{ IOException -> 0x0086 }
            r0.f363e = r8     // Catch:{ IOException -> 0x0086 }
            r0.f366h = r3     // Catch:{ IOException -> 0x0086 }
            java.lang.Object r0 = r4.k(r8, r0)     // Catch:{ IOException -> 0x0086 }
            if (r0 != r1) goto L_0x0084
            return r1
        L_0x0084:
            r1 = r8
        L_0x0085:
            return r1
        L_0x0086:
            r8 = move-exception
            r0 = r2
        L_0x0088:
            v7.g9.b(r0, r8)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.i(zd.e):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0043  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0075  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0091  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object j(zd.e r8, zd.j r9, ge.c r10) {
        /*
            r7 = this;
            boolean r0 = r8 instanceof a2.k0
            if (r0 == 0) goto L_0x0013
            r0 = r8
            a2.k0 r0 = (a2.k0) r0
            int r1 = r0.f373i
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f373i = r1
            goto L_0x0018
        L_0x0013:
            a2.k0 r0 = new a2.k0
            r0.<init>(r7, r8)
        L_0x0018:
            java.lang.Object r8 = r0.f371g
            ae.a r1 = ae.a.f795a
            int r2 = r0.f373i
            r3 = 0
            r4 = 2
            r5 = 1
            if (r2 == 0) goto L_0x0043
            if (r2 == r5) goto L_0x0037
            if (r2 != r4) goto L_0x002f
            java.lang.Object r9 = r0.f369e
            a2.n0 r10 = r0.f368d
            v7.r0.C(r8)
            goto L_0x0086
        L_0x002f:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L_0x0037:
            java.lang.Object r9 = r0.f370f
            java.lang.Object r10 = r0.f369e
            a2.c r10 = (a2.c) r10
            a2.n0 r2 = r0.f368d
            v7.r0.C(r8)
            goto L_0x006b
        L_0x0043:
            v7.r0.C(r8)
            bh.u r8 = r7.f397g
            java.lang.Object r8 = r8.c()
            a2.c r8 = (a2.c) r8
            r8.a()
            a2.l0 r2 = new a2.l0
            java.lang.Object r6 = r8.f303a
            r2.<init>(r6, r3, r10)
            r0.f368d = r7
            r0.f369e = r8
            r0.f370f = r6
            r0.f373i = r5
            java.lang.Object r9 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.n2(r0, r9, r2)
            if (r9 != r1) goto L_0x0067
            return r1
        L_0x0067:
            r2 = r7
            r10 = r8
            r8 = r9
            r9 = r6
        L_0x006b:
            r10.a()
            boolean r10 = v7.r0.b(r9, r8)
            if (r10 == 0) goto L_0x0075
            goto L_0x0098
        L_0x0075:
            r0.f368d = r2
            r0.f369e = r8
            r0.f370f = r3
            r0.f373i = r4
            java.lang.Object r9 = r2.k(r8, r0)
            if (r9 != r1) goto L_0x0084
            return r1
        L_0x0084:
            r9 = r8
            r10 = r2
        L_0x0086:
            bh.u r8 = r10.f397g
            a2.c r10 = new a2.c
            if (r9 == 0) goto L_0x0091
            int r0 = r9.hashCode()
            goto L_0x0092
        L_0x0091:
            r0 = 0
        L_0x0092:
            r10.<init>(r0, r9)
            r8.d(r10)
        L_0x0098:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.j(zd.e, zd.j, ge.c):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x003e  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00a2 A[Catch:{ all -> 0x00c1, IOException -> 0x00ba }, RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00a3 A[Catch:{ all -> 0x00c1, IOException -> 0x00ba }] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object k(java.lang.Object r9, zd.e r10) {
        /*
            r8 = this;
            java.lang.String r0 = "Unable to rename "
            boolean r1 = r10 instanceof a2.m0
            if (r1 == 0) goto L_0x0015
            r1 = r10
            a2.m0 r1 = (a2.m0) r1
            int r2 = r1.f384j
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L_0x0015
            int r2 = r2 - r3
            r1.f384j = r2
            goto L_0x001a
        L_0x0015:
            a2.m0 r1 = new a2.m0
            r1.<init>(r8, r10)
        L_0x001a:
            java.lang.Object r10 = r1.f382h
            ae.a r2 = ae.a.f795a
            int r3 = r1.f384j
            wd.m r4 = wd.m.f29306a
            r5 = 1
            if (r3 == 0) goto L_0x003e
            if (r3 != r5) goto L_0x0036
            java.io.FileOutputStream r9 = r1.f381g
            java.io.FileOutputStream r2 = r1.f380f
            java.io.File r3 = r1.f379e
            a2.n0 r1 = r1.f378d
            v7.r0.C(r10)     // Catch:{ all -> 0x0033 }
            goto L_0x008d
        L_0x0033:
            r9 = move-exception
            goto L_0x00c0
        L_0x0036:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
            r9.<init>(r10)
            throw r9
        L_0x003e:
            v7.r0.C(r10)
            java.io.File r10 = r8.d()
            java.io.File r3 = r10.getCanonicalFile()
            java.io.File r3 = r3.getParentFile()
            if (r3 != 0) goto L_0x0050
            goto L_0x0059
        L_0x0050:
            r3.mkdirs()
            boolean r3 = r3.isDirectory()
            if (r3 == 0) goto L_0x00d0
        L_0x0059:
            java.io.File r3 = new java.io.File
            java.io.File r10 = r8.d()
            java.lang.String r10 = r10.getAbsolutePath()
            java.lang.String r6 = r8.f395e
            java.lang.String r10 = v7.r0.B(r10, r6)
            r3.<init>(r10)
            java.io.FileOutputStream r10 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x00ba }
            r10.<init>(r3)     // Catch:{ IOException -> 0x00ba }
            a2.m r6 = r8.f392b     // Catch:{ all -> 0x00be }
            a2.s r7 = new a2.s     // Catch:{ all -> 0x00be }
            r7.<init>(r10)     // Catch:{ all -> 0x00be }
            r1.f378d = r8     // Catch:{ all -> 0x00be }
            r1.f379e = r3     // Catch:{ all -> 0x00be }
            r1.f380f = r10     // Catch:{ all -> 0x00be }
            r1.f381g = r10     // Catch:{ all -> 0x00be }
            r1.f384j = r5     // Catch:{ all -> 0x00be }
            d2.k r6 = (d2.k) r6     // Catch:{ all -> 0x00be }
            r6.b(r9, r7)     // Catch:{ all -> 0x00be }
            if (r4 != r2) goto L_0x008a
            return r2
        L_0x008a:
            r1 = r8
            r9 = r10
            r2 = r9
        L_0x008d:
            java.io.FileDescriptor r9 = r9.getFD()     // Catch:{ all -> 0x0033 }
            r9.sync()     // Catch:{ all -> 0x0033 }
            r9 = 0
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.w(r2, r9)     // Catch:{ IOException -> 0x00ba }
            java.io.File r9 = r1.d()     // Catch:{ IOException -> 0x00ba }
            boolean r9 = r3.renameTo(r9)     // Catch:{ IOException -> 0x00ba }
            if (r9 == 0) goto L_0x00a3
            return r4
        L_0x00a3:
            java.io.IOException r9 = new java.io.IOException     // Catch:{ IOException -> 0x00ba }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x00ba }
            r10.<init>(r0)     // Catch:{ IOException -> 0x00ba }
            r10.append(r3)     // Catch:{ IOException -> 0x00ba }
            java.lang.String r0 = ".This likely means that there are multiple instances of DataStore for this file. Ensure that you are only creating a single instance of datastore for this file."
            r10.append(r0)     // Catch:{ IOException -> 0x00ba }
            java.lang.String r10 = r10.toString()     // Catch:{ IOException -> 0x00ba }
            r9.<init>(r10)     // Catch:{ IOException -> 0x00ba }
            throw r9     // Catch:{ IOException -> 0x00ba }
        L_0x00ba:
            r9 = move-exception
            goto L_0x00c6
        L_0x00bc:
            r2 = r10
            goto L_0x00c0
        L_0x00be:
            r9 = move-exception
            goto L_0x00bc
        L_0x00c0:
            throw r9     // Catch:{ all -> 0x00c1 }
        L_0x00c1:
            r10 = move-exception
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.w(r2, r9)     // Catch:{ IOException -> 0x00ba }
            throw r10     // Catch:{ IOException -> 0x00ba }
        L_0x00c6:
            boolean r10 = r3.exists()
            if (r10 == 0) goto L_0x00cf
            r3.delete()
        L_0x00cf:
            throw r9
        L_0x00d0:
            java.io.IOException r9 = new java.io.IOException
            java.lang.String r0 = "Unable to create parent directories of "
            java.lang.String r10 = v7.r0.B(r0, r10)
            r9.<init>(r10)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n0.k(java.lang.Object, zd.e):java.lang.Object");
    }
}
