package a2;

import ae.a;
import be.i;
import bh.f;
import e3.d;
import ge.c;
import v7.r0;
import wd.m;
import zd.e;

public final class a0 extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public int f298e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f299f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ n0 f300g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a0(n0 n0Var, e eVar) {
        super(2, eVar);
        this.f300g = n0Var;
    }

    public final e a(Object obj, e eVar) {
        a0 a0Var = new a0(this.f300g, eVar);
        a0Var.f299f = obj;
        return a0Var;
    }

    public final Object g(Object obj, Object obj2) {
        return ((a0) a((f) obj, (e) obj2)).p(m.f29306a);
    }

    public final Object p(Object obj) {
        a aVar = a.f795a;
        int i10 = this.f298e;
        m mVar = m.f29306a;
        if (i10 == 0) {
            r0.C(obj);
            f fVar = (f) this.f299f;
            n0 n0Var = this.f300g;
            o0 o0Var = (o0) n0Var.f397g.c();
            if (!(o0Var instanceof c)) {
                n0Var.f399i.r(new p(o0Var));
            }
            z zVar = new z(new d(n0Var.f397g, new w(o0Var, (e) null), 2));
            this.f298e = 1;
            Object a10 = zVar.a(fVar, this);
            if (a10 != aVar) {
                a10 = mVar;
            }
            if (a10 == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            r0.C(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return mVar;
    }
}
