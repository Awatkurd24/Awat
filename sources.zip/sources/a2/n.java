package a2;

import com.v2ray.ang.ui.MainActivity;
import com.v2ray.ang.ui.t;
import f.c;
import ge.b;
import he.l;
import he.v;
import java.util.List;
import java.util.Map;
import jd.j;
import v7.r0;
import wd.m;

public final class n extends l implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f385a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f386b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f387c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f388d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(Object obj, Object obj2, Object obj3, int i10) {
        super(1);
        this.f385a = i10;
        this.f386b = obj;
        this.f387c = obj2;
        this.f388d = obj3;
    }

    /* JADX WARNING: Removed duplicated region for block: B:101:0x0198 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x0150 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0168  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0189  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x018c  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x018e  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0199 A[LOOP:4: B:44:0x00ca->B:89:0x0199, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(java.lang.Throwable r20) {
        /*
            r19 = this;
            r0 = r19
            r1 = r20
            int r2 = r0.f385a
            r3 = 0
            java.lang.Object r4 = r0.f387c
            java.lang.Object r5 = r0.f388d
            java.lang.Object r6 = r0.f386b
            switch(r2) {
                case 0: goto L_0x0047;
                case 1: goto L_0x002b;
                case 2: goto L_0x0010;
                case 3: goto L_0x001e;
                default: goto L_0x0010;
            }
        L_0x0010:
            ge.b r6 = (ge.b) r6
            zd.j r5 = (zd.j) r5
            n1.q r1 = v7.l9.c(r6, r4, r3)
            if (r1 == 0) goto L_0x001d
            yg.b0.r(r5, r1)
        L_0x001d:
            return
        L_0x001e:
            dh.w r1 = ah.e.f839l
            if (r6 != r1) goto L_0x0023
            return
        L_0x0023:
            ah.c r4 = (ah.c) r4
            ge.b r1 = r4.f826c
            f.c.w(r5)
            throw r3
        L_0x002b:
            g5.b r6 = (g5.b) r6
            android.view.ViewTreeObserver r4 = (android.view.ViewTreeObserver) r4
            java.lang.String r1 = "viewTreeObserver"
            v7.r0.i(r1, r4)
            g5.a r5 = (g5.a) r5
            boolean r1 = r4.isAlive()
            if (r1 == 0) goto L_0x0040
            r4.removeOnPreDrawListener(r5)
            return
        L_0x0040:
            v7.p1 r6 = (v7.p1) r6
            r6.getClass()
            r1 = 0
            throw r1
        L_0x0047:
            ge.b r6 = (ge.b) r6
            r6.h(r1)
            a4.i r4 = (a4.i) r4
            java.lang.Object r2 = r4.f551c
            ah.g r2 = (ah.g) r2
            ah.c r2 = (ah.c) r2
            r2.getClass()
            dh.w r6 = ah.e.f846s
        L_0x0059:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = ah.c.f823k
            boolean r8 = r7.compareAndSet(r2, r6, r1)
            r12 = 1
            if (r8 == 0) goto L_0x0064
            r13 = 1
            goto L_0x006c
        L_0x0064:
            java.lang.Object r7 = r7.get(r2)
            if (r7 == r6) goto L_0x0059
            r6 = 0
            r13 = 0
        L_0x006c:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r6 = ah.c.f816d
            long r8 = r6.get(r2)
            r7 = 60
            long r10 = r8 >> r7
            int r11 = (int) r10
            r14 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            if (r11 == 0) goto L_0x008d
            if (r11 == r12) goto L_0x0083
            r16 = r13
            goto L_0x009a
        L_0x0083:
            long r10 = r8 & r14
            r3 = 3
            r16 = r13
        L_0x0088:
            long r12 = (long) r3
            long r12 = r12 << r7
            long r12 = r12 + r10
            r10 = r12
            goto L_0x0093
        L_0x008d:
            r16 = r13
            long r10 = r8 & r14
            r3 = 2
            goto L_0x0088
        L_0x0093:
            r7 = r2
            boolean r3 = r6.compareAndSet(r7, r8, r10)
            if (r3 == 0) goto L_0x01ac
        L_0x009a:
            r2.f()
            if (r16 == 0) goto L_0x00ca
        L_0x009f:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r3 = ah.c.f824l
            java.lang.Object r6 = r3.get(r2)
            if (r6 != 0) goto L_0x00aa
            dh.w r7 = ah.e.f844q
            goto L_0x00ac
        L_0x00aa:
            dh.w r7 = ah.e.f845r
        L_0x00ac:
            boolean r8 = r3.compareAndSet(r2, r6, r7)
            if (r8 == 0) goto L_0x00c3
            if (r6 != 0) goto L_0x00b5
            goto L_0x00ca
        L_0x00b5:
            r3 = 1
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.l(r3, r6)
            ge.b r6 = (ge.b) r6
            java.lang.Throwable r2 = r2.j()
            r6.h(r2)
            goto L_0x00ca
        L_0x00c3:
            java.lang.Object r8 = r3.get(r2)
            if (r8 == r6) goto L_0x00ac
            goto L_0x009f
        L_0x00ca:
            java.lang.Object r2 = r4.f551c
            ah.g r2 = (ah.g) r2
            ah.c r2 = (ah.c) r2
            r2.getClass()
            java.util.concurrent.atomic.AtomicLongFieldUpdater r3 = ah.c.f817e
            long r6 = r3.get(r2)
            java.util.concurrent.atomic.AtomicLongFieldUpdater r8 = ah.c.f816d
            long r8 = r8.get(r2)
            r10 = 1
            boolean r11 = r2.o(r8, r10)
            if (r11 == 0) goto L_0x00f2
            java.lang.Throwable r2 = r2.j()
            ah.h r3 = new ah.h
            r3.<init>(r2)
        L_0x00ef:
            r15 = 1
            goto L_0x0184
        L_0x00f2:
            long r8 = r8 & r14
            ah.i r12 = ah.j.f851a
            int r10 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r10 < 0) goto L_0x00fb
            r3 = r12
            goto L_0x00ef
        L_0x00fb:
            dh.w r13 = ah.e.f838k
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = ah.c.f821i
            java.lang.Object r6 = r6.get(r2)
            ah.k r6 = (ah.k) r6
        L_0x0105:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r7 = ah.c.f816d
            long r7 = r7.get(r2)
            r11 = 1
            boolean r7 = r2.o(r7, r11)
            if (r7 == 0) goto L_0x011c
            java.lang.Throwable r2 = r2.j()
            ah.h r3 = new ah.h
            r3.<init>(r2)
            goto L_0x00ef
        L_0x011c:
            long r9 = r3.getAndIncrement(r2)
            int r7 = ah.e.f829b
            long r7 = (long) r7
            r16 = r12
            long r11 = r9 / r7
            long r7 = r9 % r7
            int r8 = (int) r7
            long r14 = r6.f17839c
            int r7 = (r14 > r11 ? 1 : (r14 == r11 ? 0 : -1))
            if (r7 == 0) goto L_0x0140
            ah.k r7 = r2.i(r11, r6)
            if (r7 != 0) goto L_0x013e
        L_0x0136:
            r12 = r16
            r14 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            goto L_0x0105
        L_0x013e:
            r12 = r7
            goto L_0x0141
        L_0x0140:
            r12 = r6
        L_0x0141:
            r6 = r2
            r7 = r12
            r14 = r8
            r17 = r9
            r15 = 1
            r11 = r13
            java.lang.Object r6 = r6.v(r7, r8, r9, r11)
            dh.w r7 = ah.e.f840m
            if (r6 != r7) goto L_0x0168
            boolean r3 = r13 instanceof yg.z1
            if (r3 == 0) goto L_0x0157
            yg.z1 r13 = (yg.z1) r13
            goto L_0x0158
        L_0x0157:
            r13 = 0
        L_0x0158:
            if (r13 == 0) goto L_0x015d
            r13.a(r12, r14)
        L_0x015d:
            r7 = r17
            r2.x(r7)
            r12.h()
            r12 = r16
            goto L_0x0183
        L_0x0168:
            r7 = r17
            dh.w r9 = ah.e.f842o
            if (r6 != r9) goto L_0x017b
            long r9 = r2.m()
            int r6 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r6 >= 0) goto L_0x0179
            r12.a()
        L_0x0179:
            r6 = r12
            goto L_0x0136
        L_0x017b:
            dh.w r2 = ah.e.f841n
            if (r6 == r2) goto L_0x01a0
            r12.a()
            r12 = r6
        L_0x0183:
            r3 = r12
        L_0x0184:
            boolean r2 = r3 instanceof ah.i
            if (r2 != 0) goto L_0x0189
            goto L_0x018a
        L_0x0189:
            r3 = 0
        L_0x018a:
            if (r3 != 0) goto L_0x018e
            r2 = 0
            goto L_0x0196
        L_0x018e:
            r2 = r5
            ge.c r2 = (ge.c) r2
            r2.g(r3, r1)
            wd.m r2 = wd.m.f29306a
        L_0x0196:
            if (r2 != 0) goto L_0x0199
            return
        L_0x0199:
            r14 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            goto L_0x00ca
        L_0x01a0:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "unexpected"
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x01ac:
            r13 = r16
            r3 = 0
            r12 = 1
            goto L_0x006c
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.n.a(java.lang.Throwable):void");
    }

    public final Object h(Object obj) {
        m mVar = m.f29306a;
        switch (this.f385a) {
            case 0:
                a((Throwable) obj);
                return mVar;
            case 1:
                a((Throwable) obj);
                return mVar;
            case 2:
                j jVar = (j) obj;
                r0.j("$this$show", jVar);
                jVar.B = "Social Media:";
                c.x("displayMode", 3);
                jVar.I = 3;
                List list = (List) ((v) this.f386b).f19690a;
                r0.j("options", list);
                jVar.G.addAll(list);
                jVar.F = new t((Map) this.f387c, 0, (MainActivity) this.f388d);
                return mVar;
            case 3:
                a((Throwable) obj);
                return mVar;
            default:
                a((Throwable) obj);
                return mVar;
        }
    }
}
