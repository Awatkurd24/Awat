package a2;

import be.c;
import zd.e;

public final class h0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f352d;

    /* renamed from: e  reason: collision with root package name */
    public /* synthetic */ Object f353e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ n0 f354f;

    /* renamed from: g  reason: collision with root package name */
    public int f355g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h0(n0 n0Var, e eVar) {
        super(eVar);
        this.f354f = n0Var;
    }

    public final Object p(Object obj) {
        this.f353e = obj;
        this.f355g |= Integer.MIN_VALUE;
        return this.f354f.g(this);
    }
}
