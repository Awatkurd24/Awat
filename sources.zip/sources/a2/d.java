package a2;

import ae.a;
import be.i;
import ge.c;
import java.util.List;
import v7.r0;
import wd.m;
import zd.e;

public final class d extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public int f311e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f312f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ List f313g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(List list, e eVar) {
        super(2, eVar);
        this.f313g = list;
    }

    public final e a(Object obj, e eVar) {
        d dVar = new d(this.f313g, eVar);
        dVar.f312f = obj;
        return dVar;
    }

    public final Object g(Object obj, Object obj2) {
        return ((d) a((f0) obj, (e) obj2)).p(m.f29306a);
    }

    public final Object p(Object obj) {
        a aVar = a.f795a;
        int i10 = this.f311e;
        if (i10 == 0) {
            r0.C(obj);
            h hVar = i.f356a;
            this.f311e = 1;
            if (h.c(hVar, this.f313g, (f0) this.f312f, this) == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            r0.C(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return m.f29306a;
    }
}
