package a2;

import be.c;
import yg.n;
import zd.e;

public final class c0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public Object f305d;

    /* renamed from: e  reason: collision with root package name */
    public n0 f306e;

    /* renamed from: f  reason: collision with root package name */
    public n f307f;

    /* renamed from: g  reason: collision with root package name */
    public /* synthetic */ Object f308g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ n0 f309h;

    /* renamed from: i  reason: collision with root package name */
    public int f310i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c0(n0 n0Var, e eVar) {
        super(eVar);
        this.f309h = n0Var;
    }

    public final Object p(Object obj) {
        this.f308g = obj;
        this.f310i |= Integer.MIN_VALUE;
        return n0.c(this.f309h, (q) null, this);
    }
}
