package a2;

import be.c;
import java.io.FileInputStream;
import zd.e;

public final class i0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f357d;

    /* renamed from: e  reason: collision with root package name */
    public FileInputStream f358e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f359f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ n0 f360g;

    /* renamed from: h  reason: collision with root package name */
    public int f361h;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i0(n0 n0Var, e eVar) {
        super(eVar);
        this.f360g = n0Var;
    }

    public final Object p(Object obj) {
        this.f359f = obj;
        this.f361h |= Integer.MIN_VALUE;
        return this.f360g.h(this);
    }
}
