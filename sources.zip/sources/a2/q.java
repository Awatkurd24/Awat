package a2;

import ge.c;
import v7.r0;
import yg.n;
import yg.o;
import zd.j;

public final class q extends r {

    /* renamed from: a  reason: collision with root package name */
    public final c f405a;

    /* renamed from: b  reason: collision with root package name */
    public final n f406b;

    /* renamed from: c  reason: collision with root package name */
    public final o0 f407c;

    /* renamed from: d  reason: collision with root package name */
    public final j f408d;

    public q(c cVar, o oVar, o0 o0Var, j jVar) {
        r0.j("callerContext", jVar);
        this.f405a = cVar;
        this.f406b = oVar;
        this.f407c = o0Var;
        this.f408d = jVar;
    }
}
