package a2;

import be.c;
import zd.e;

public final class j0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public Object f362d;

    /* renamed from: e  reason: collision with root package name */
    public Object f363e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f364f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ n0 f365g;

    /* renamed from: h  reason: collision with root package name */
    public int f366h;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j0(n0 n0Var, e eVar) {
        super(eVar);
        this.f365g = n0Var;
    }

    public final Object p(Object obj) {
        this.f364f = obj;
        this.f366h |= Integer.MIN_VALUE;
        return this.f365g.i(this);
    }
}
