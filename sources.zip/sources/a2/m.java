package a2;

public interface m {
}
