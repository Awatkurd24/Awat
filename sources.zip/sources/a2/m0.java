package a2;

import be.c;
import java.io.File;
import java.io.FileOutputStream;
import zd.e;

public final class m0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f378d;

    /* renamed from: e  reason: collision with root package name */
    public File f379e;

    /* renamed from: f  reason: collision with root package name */
    public FileOutputStream f380f;

    /* renamed from: g  reason: collision with root package name */
    public FileOutputStream f381g;

    /* renamed from: h  reason: collision with root package name */
    public /* synthetic */ Object f382h;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ n0 f383i;

    /* renamed from: j  reason: collision with root package name */
    public int f384j;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public m0(n0 n0Var, e eVar) {
        super(eVar);
        this.f383i = n0Var;
    }

    public final Object p(Object obj) {
        this.f382h = obj;
        this.f384j |= Integer.MIN_VALUE;
        return this.f383i.k((Object) null, this);
    }
}
