package a2;

import gh.a;
import he.t;
import he.v;

public final class f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f337a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ t f338b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ v f339c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ n0 f340d;

    public f0(a aVar, t tVar, v vVar, n0 n0Var) {
        this.f337a = aVar;
        this.f338b = tVar;
        this.f339c = vVar;
        this.f340d = n0Var;
    }

    /* JADX WARNING: type inference failed for: r7v2, types: [gh.a] */
    /* JADX WARNING: type inference failed for: r8v3, types: [ge.c] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0096 A[Catch:{ all -> 0x00d5 }] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b6 A[Catch:{ all -> 0x0054 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00cc A[Catch:{ all -> 0x0039 }] */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00d8 A[SYNTHETIC, Splitter:B:49:0x00d8] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(a2.g r11, zd.e r12) {
        /*
            r10 = this;
            boolean r0 = r12 instanceof a2.e0
            if (r0 == 0) goto L_0x0013
            r0 = r12
            a2.e0 r0 = (a2.e0) r0
            int r1 = r0.f335k
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f335k = r1
            goto L_0x0018
        L_0x0013:
            a2.e0 r0 = new a2.e0
            r0.<init>(r10, r12)
        L_0x0018:
            java.lang.Object r12 = r0.f333i
            ae.a r1 = ae.a.f795a
            int r2 = r0.f335k
            r3 = 3
            r4 = 2
            r5 = 1
            r6 = 0
            if (r2 == 0) goto L_0x0070
            if (r2 == r5) goto L_0x0058
            if (r2 == r4) goto L_0x0044
            if (r2 != r3) goto L_0x003c
            java.lang.Object r11 = r0.f330f
            java.lang.Object r1 = r0.f329e
            he.v r1 = (he.v) r1
            java.lang.Object r0 = r0.f328d
            gh.a r0 = (gh.a) r0
            v7.r0.C(r12)     // Catch:{ all -> 0x0039 }
            goto L_0x00c8
        L_0x0039:
            r11 = move-exception
            goto L_0x00e0
        L_0x003c:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r12)
            throw r11
        L_0x0044:
            java.lang.Object r11 = r0.f330f
            a2.n0 r11 = (a2.n0) r11
            java.lang.Object r2 = r0.f329e
            he.v r2 = (he.v) r2
            java.lang.Object r4 = r0.f328d
            gh.a r4 = (gh.a) r4
            v7.r0.C(r12)     // Catch:{ all -> 0x0054 }
            goto L_0x00ae
        L_0x0054:
            r11 = move-exception
            r0 = r4
            goto L_0x00e0
        L_0x0058:
            a2.n0 r11 = r0.f332h
            he.v r2 = r0.f331g
            java.lang.Object r5 = r0.f330f
            he.t r5 = (he.t) r5
            java.lang.Object r7 = r0.f329e
            gh.a r7 = (gh.a) r7
            java.lang.Object r8 = r0.f328d
            ge.c r8 = (ge.c) r8
            v7.r0.C(r12)
            r12 = r7
            r9 = r8
            r8 = r11
            r11 = r9
            goto L_0x0092
        L_0x0070:
            v7.r0.C(r12)
            r0.f328d = r11
            gh.a r12 = r10.f337a
            r0.f329e = r12
            he.t r2 = r10.f338b
            r0.f330f = r2
            he.v r7 = r10.f339c
            r0.f331g = r7
            a2.n0 r8 = r10.f340d
            r0.f332h = r8
            r0.f335k = r5
            gh.d r12 = (gh.d) r12
            java.lang.Object r5 = r12.d(r0)
            if (r5 != r1) goto L_0x0090
            return r1
        L_0x0090:
            r5 = r2
            r2 = r7
        L_0x0092:
            boolean r5 = r5.f19688a     // Catch:{ all -> 0x00d5 }
            if (r5 != 0) goto L_0x00d8
            java.lang.Object r5 = r2.f19690a     // Catch:{ all -> 0x00d5 }
            r0.f328d = r12     // Catch:{ all -> 0x00d5 }
            r0.f329e = r2     // Catch:{ all -> 0x00d5 }
            r0.f330f = r8     // Catch:{ all -> 0x00d5 }
            r0.f331g = r6     // Catch:{ all -> 0x00d5 }
            r0.f332h = r6     // Catch:{ all -> 0x00d5 }
            r0.f335k = r4     // Catch:{ all -> 0x00d5 }
            java.lang.Object r11 = r11.g(r5, r0)     // Catch:{ all -> 0x00d5 }
            if (r11 != r1) goto L_0x00ab
            return r1
        L_0x00ab:
            r4 = r12
            r12 = r11
            r11 = r8
        L_0x00ae:
            java.lang.Object r5 = r2.f19690a     // Catch:{ all -> 0x0054 }
            boolean r5 = v7.r0.b(r12, r5)     // Catch:{ all -> 0x0054 }
            if (r5 != 0) goto L_0x00cc
            r0.f328d = r4     // Catch:{ all -> 0x0054 }
            r0.f329e = r2     // Catch:{ all -> 0x0054 }
            r0.f330f = r12     // Catch:{ all -> 0x0054 }
            r0.f335k = r3     // Catch:{ all -> 0x0054 }
            java.lang.Object r11 = r11.k(r12, r0)     // Catch:{ all -> 0x0054 }
            if (r11 != r1) goto L_0x00c5
            return r1
        L_0x00c5:
            r11 = r12
            r1 = r2
            r0 = r4
        L_0x00c8:
            r1.f19690a = r11     // Catch:{ all -> 0x0039 }
            r2 = r1
            goto L_0x00cd
        L_0x00cc:
            r0 = r4
        L_0x00cd:
            java.lang.Object r11 = r2.f19690a     // Catch:{ all -> 0x0039 }
            gh.d r0 = (gh.d) r0
            r0.e(r6)
            return r11
        L_0x00d5:
            r11 = move-exception
            r0 = r12
            goto L_0x00e0
        L_0x00d8:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException     // Catch:{ all -> 0x00d5 }
            java.lang.String r0 = "InitializerApi.updateData should not be called after initialization is complete."
            r11.<init>(r0)     // Catch:{ all -> 0x00d5 }
            throw r11     // Catch:{ all -> 0x00d5 }
        L_0x00e0:
            gh.d r0 = (gh.d) r0
            r0.e(r6)
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.f0.a(a2.g, zd.e):java.lang.Object");
    }
}
