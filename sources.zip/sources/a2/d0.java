package a2;

import be.c;
import java.io.Serializable;
import java.util.Iterator;
import zd.e;

public final class d0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f314d;

    /* renamed from: e  reason: collision with root package name */
    public Object f315e;

    /* renamed from: f  reason: collision with root package name */
    public Serializable f316f;

    /* renamed from: g  reason: collision with root package name */
    public Object f317g;

    /* renamed from: h  reason: collision with root package name */
    public f0 f318h;

    /* renamed from: i  reason: collision with root package name */
    public Iterator f319i;

    /* renamed from: j  reason: collision with root package name */
    public /* synthetic */ Object f320j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ n0 f321k;

    /* renamed from: l  reason: collision with root package name */
    public int f322l;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d0(n0 n0Var, e eVar) {
        super(eVar);
        this.f321k = n0Var;
    }

    public final Object p(Object obj) {
        this.f320j = obj;
        this.f322l |= Integer.MIN_VALUE;
        return this.f321k.e(this);
    }
}
