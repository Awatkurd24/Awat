package a2;

import ge.c;
import zd.e;

public interface j {
    Object a(c cVar, e eVar);

    bh.e b();
}
