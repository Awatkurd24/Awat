package a2;

public final class p0 extends o0 {

    /* renamed from: a  reason: collision with root package name */
    public static final p0 f404a = new Object();
}
