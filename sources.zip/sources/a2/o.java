package a2;

import be.i;
import ge.c;
import wd.m;
import yg.z;
import zd.e;

public final class o extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public c f400e;

    /* renamed from: f  reason: collision with root package name */
    public int f401f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ a4.i f402g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(a4.i iVar, e eVar) {
        super(2, eVar);
        this.f402g = iVar;
    }

    public final e a(Object obj, e eVar) {
        return new o(this.f402g, eVar);
    }

    public final Object g(Object obj, Object obj2) {
        return ((o) a((z) obj, (e) obj2)).p(m.f29306a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00ad, code lost:
        if (r8 != ah.e.f841n) goto L_0x0179;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00af, code lost:
        r14 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.G0(v7.r0.s(r2));
        r3 = r11;
        r1 = r13;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
        r8 = r6.v(r4, r5, r16, r14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00c3, code lost:
        if (r8 != r1) goto L_0x00ca;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00c5, code lost:
        r14.a(r4, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00ca, code lost:
        r1 = r6.f826c;
        r5 = r14.f30295e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00ce, code lost:
        if (r8 != r3) goto L_0x015d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00d6, code lost:
        if (r16 >= r6.m()) goto L_0x00df;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00d8, code lost:
        r4.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00dc, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00df, code lost:
        r3 = (ah.k) r15.get(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00f0, code lost:
        if (r6.o(ah.c.f816d.get(r6), true) == false) goto L_0x00ff;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00f2, code lost:
        r14.c(v7.r0.m(r6.k()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00ff, code lost:
        r4 = r18;
        r16 = r4.getAndIncrement(r6);
        r8 = (long) ah.e.f829b;
        r10 = r16 / r8;
        r13 = (int) (r16 % r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0111, code lost:
        if (r3.f17839c == r10) goto L_0x011d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0113, code lost:
        r8 = r6.i(r10, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x0117, code lost:
        if (r8 != null) goto L_0x011c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0119, code lost:
        r18 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x011c, code lost:
        r3 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x011d, code lost:
        r15 = r13;
        r8 = r6.v(r3, r13, r16, r14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x012a, code lost:
        if (r8 != ah.e.f840m) goto L_0x0130;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x012c, code lost:
        r14.a(r3, r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x0132, code lost:
        if (r8 != ah.e.f842o) goto L_0x0140;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x013a, code lost:
        if (r16 >= r6.m()) goto L_0x0119;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x013c, code lost:
        r3.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0142, code lost:
        if (r8 == ah.e.f841n) goto L_0x0153;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0144, code lost:
        r3.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x0147, code lost:
        if (r1 == null) goto L_0x014e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x0149, code lost:
        r1 = v7.l9.b(r1, r8, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x014e, code lost:
        r1 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x014f, code lost:
        r14.C(r1, r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x015c, code lost:
        throw new java.lang.IllegalStateException("unexpected".toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x015d, code lost:
        r4.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0160, code lost:
        if (r1 == null) goto L_0x0167;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0162, code lost:
        r1 = v7.l9.b(r1, r8, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0167, code lost:
        r1 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0169, code lost:
        r1 = r14.t();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x016f, code lost:
        if (r1 != ae.a.f795a) goto L_0x017d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0171, code lost:
        com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.t1(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0175, code lost:
        r14.B();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0178, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:0x0179, code lost:
        r4.a();
        r1 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:80:0x017d, code lost:
        if (r1 != r0) goto L_0x0180;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x017f, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0180, code lost:
        r3 = r2;
        r2 = r7;
        r4 = null;
     */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x019f  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x01a4 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object p(java.lang.Object r21) {
        /*
            r20 = this;
            r1 = r20
            ae.a r0 = ae.a.f795a
            int r2 = r1.f401f
            r3 = 1
            r5 = 2
            if (r2 == 0) goto L_0x0028
            if (r2 == r3) goto L_0x001d
            if (r2 != r5) goto L_0x0015
            v7.r0.C(r21)
            r2 = r1
            r4 = 0
            goto L_0x0190
        L_0x0015:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r2)
            throw r0
        L_0x001d:
            ge.c r2 = r1.f400e
            v7.r0.C(r21)
            r3 = r1
            r4 = 0
            r1 = r21
            goto L_0x0183
        L_0x0028:
            v7.r0.C(r21)
            a4.i r2 = r1.f402g
            java.lang.Object r2 = r2.f552d
            java.util.concurrent.atomic.AtomicInteger r2 = (java.util.concurrent.atomic.AtomicInteger) r2
            int r2 = r2.get()
            if (r2 <= 0) goto L_0x01b5
            r2 = r1
        L_0x0038:
            a4.i r6 = r2.f402g
            java.lang.Object r7 = r6.f549a
            yg.z r7 = (yg.z) r7
            zd.j r7 = r7.q()
            yg.b0.h(r7)
            java.lang.Object r7 = r6.f550b
            ge.c r7 = (ge.c) r7
            java.lang.Object r6 = r6.f551c
            ah.g r6 = (ah.g) r6
            r2.f400e = r7
            r2.f401f = r3
            ah.c r6 = (ah.c) r6
            r6.getClass()
            r14 = 0
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r15 = ah.c.f821i
            java.lang.Object r8 = r15.get(r6)
            ah.k r8 = (ah.k) r8
        L_0x005f:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r9 = ah.c.f816d
            long r9 = r9.get(r6)
            boolean r9 = r6.o(r9, r3)
            if (r9 != 0) goto L_0x01ae
            java.util.concurrent.atomic.AtomicLongFieldUpdater r13 = ah.c.f817e
            long r16 = r13.getAndIncrement(r6)
            int r9 = ah.e.f829b
            long r9 = (long) r9
            long r11 = r16 / r9
            long r9 = r16 % r9
            int r10 = (int) r9
            long r4 = r8.f17839c
            int r9 = (r4 > r11 ? 1 : (r4 == r11 ? 0 : -1))
            if (r9 == 0) goto L_0x0087
            ah.k r4 = r6.i(r11, r8)
            if (r4 != 0) goto L_0x0088
        L_0x0085:
            r5 = 2
            goto L_0x005f
        L_0x0087:
            r4 = r8
        L_0x0088:
            r8 = r6
            r9 = r4
            r5 = r10
            r11 = r16
            r18 = r13
            r13 = r14
            java.lang.Object r8 = r8.v(r9, r10, r11, r13)
            dh.w r13 = ah.e.f840m
            java.lang.String r19 = "unexpected"
            if (r8 == r13) goto L_0x01a4
            dh.w r11 = ah.e.f842o
            if (r8 != r11) goto L_0x00ab
            long r8 = r6.m()
            int r5 = (r16 > r8 ? 1 : (r16 == r8 ? 0 : -1))
            if (r5 >= 0) goto L_0x00a9
            r4.a()
        L_0x00a9:
            r8 = r4
            goto L_0x0085
        L_0x00ab:
            dh.w r9 = ah.e.f841n
            if (r8 != r9) goto L_0x0179
            zd.e r8 = v7.r0.s(r2)
            yg.h r14 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.G0(r8)
            r8 = r6
            r9 = r4
            r10 = r5
            r3 = r11
            r11 = r16
            r1 = r13
            r13 = r14
            java.lang.Object r8 = r8.v(r9, r10, r11, r13)     // Catch:{ all -> 0x00dc }
            if (r8 != r1) goto L_0x00ca
            r14.a(r4, r5)     // Catch:{ all -> 0x00dc }
            goto L_0x0169
        L_0x00ca:
            ge.b r1 = r6.f826c
            zd.j r5 = r14.f30295e
            if (r8 != r3) goto L_0x015d
            long r8 = r6.m()     // Catch:{ all -> 0x00dc }
            int r3 = (r16 > r8 ? 1 : (r16 == r8 ? 0 : -1))
            if (r3 >= 0) goto L_0x00df
            r4.a()     // Catch:{ all -> 0x00dc }
            goto L_0x00df
        L_0x00dc:
            r0 = move-exception
            goto L_0x0175
        L_0x00df:
            java.lang.Object r3 = r15.get(r6)     // Catch:{ all -> 0x00dc }
            ah.k r3 = (ah.k) r3     // Catch:{ all -> 0x00dc }
        L_0x00e5:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r4 = ah.c.f816d     // Catch:{ all -> 0x00dc }
            long r8 = r4.get(r6)     // Catch:{ all -> 0x00dc }
            r15 = 1
            boolean r4 = r6.o(r8, r15)     // Catch:{ all -> 0x00dc }
            if (r4 == 0) goto L_0x00ff
            java.lang.Throwable r1 = r6.k()     // Catch:{ all -> 0x00dc }
            wd.g r1 = v7.r0.m(r1)     // Catch:{ all -> 0x00dc }
            r14.c(r1)     // Catch:{ all -> 0x00dc }
            goto L_0x0169
        L_0x00ff:
            r4 = r18
            long r16 = r4.getAndIncrement(r6)     // Catch:{ all -> 0x00dc }
            int r8 = ah.e.f829b     // Catch:{ all -> 0x00dc }
            long r8 = (long) r8     // Catch:{ all -> 0x00dc }
            long r10 = r16 / r8
            long r8 = r16 % r8
            int r13 = (int) r8     // Catch:{ all -> 0x00dc }
            long r8 = r3.f17839c     // Catch:{ all -> 0x00dc }
            int r12 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r12 == 0) goto L_0x011d
            ah.k r8 = r6.i(r10, r3)     // Catch:{ all -> 0x00dc }
            if (r8 != 0) goto L_0x011c
        L_0x0119:
            r18 = r4
            goto L_0x00e5
        L_0x011c:
            r3 = r8
        L_0x011d:
            r8 = r6
            r9 = r3
            r10 = r13
            r11 = r16
            r15 = r13
            r13 = r14
            java.lang.Object r8 = r8.v(r9, r10, r11, r13)     // Catch:{ all -> 0x00dc }
            dh.w r9 = ah.e.f840m     // Catch:{ all -> 0x00dc }
            if (r8 != r9) goto L_0x0130
            r14.a(r3, r15)     // Catch:{ all -> 0x00dc }
            goto L_0x0169
        L_0x0130:
            dh.w r9 = ah.e.f842o     // Catch:{ all -> 0x00dc }
            if (r8 != r9) goto L_0x0140
            long r8 = r6.m()     // Catch:{ all -> 0x00dc }
            int r10 = (r16 > r8 ? 1 : (r16 == r8 ? 0 : -1))
            if (r10 >= 0) goto L_0x0119
            r3.a()     // Catch:{ all -> 0x00dc }
            goto L_0x0119
        L_0x0140:
            dh.w r4 = ah.e.f841n     // Catch:{ all -> 0x00dc }
            if (r8 == r4) goto L_0x0153
            r3.a()     // Catch:{ all -> 0x00dc }
            if (r1 == 0) goto L_0x014e
            a2.n r1 = v7.l9.b(r1, r8, r5)     // Catch:{ all -> 0x00dc }
            goto L_0x014f
        L_0x014e:
            r1 = 0
        L_0x014f:
            r14.C(r1, r8)     // Catch:{ all -> 0x00dc }
            goto L_0x0169
        L_0x0153:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x00dc }
            java.lang.String r1 = r19.toString()     // Catch:{ all -> 0x00dc }
            r0.<init>(r1)     // Catch:{ all -> 0x00dc }
            throw r0     // Catch:{ all -> 0x00dc }
        L_0x015d:
            r4.a()     // Catch:{ all -> 0x00dc }
            if (r1 == 0) goto L_0x0167
            a2.n r1 = v7.l9.b(r1, r8, r5)     // Catch:{ all -> 0x00dc }
            goto L_0x014f
        L_0x0167:
            r1 = 0
            goto L_0x014f
        L_0x0169:
            java.lang.Object r1 = r14.t()
            ae.a r3 = ae.a.f795a
            if (r1 != r3) goto L_0x017d
            com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.t1(r2)
            goto L_0x017d
        L_0x0175:
            r14.B()
            throw r0
        L_0x0179:
            r4.a()
            r1 = r8
        L_0x017d:
            if (r1 != r0) goto L_0x0180
            return r0
        L_0x0180:
            r3 = r2
            r2 = r7
            r4 = 0
        L_0x0183:
            r3.f400e = r4
            r5 = 2
            r3.f401f = r5
            java.lang.Object r1 = r2.g(r1, r3)
            if (r1 != r0) goto L_0x018f
            return r0
        L_0x018f:
            r2 = r3
        L_0x0190:
            a4.i r1 = r2.f402g
            java.lang.Object r1 = r1.f552d
            java.util.concurrent.atomic.AtomicInteger r1 = (java.util.concurrent.atomic.AtomicInteger) r1
            int r1 = r1.decrementAndGet()
            if (r1 != 0) goto L_0x019f
            wd.m r0 = wd.m.f29306a
            return r0
        L_0x019f:
            r1 = r20
            r3 = 1
            goto L_0x0038
        L_0x01a4:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = r19.toString()
            r0.<init>(r1)
            throw r0
        L_0x01ae:
            java.lang.Throwable r0 = r6.k()
            int r1 = dh.v.f17840a
            throw r0
        L_0x01b5:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Check failed."
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.o.p(java.lang.Object):java.lang.Object");
    }
}
