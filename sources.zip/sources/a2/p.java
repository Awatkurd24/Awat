package a2;

public final class p extends r {

    /* renamed from: a  reason: collision with root package name */
    public final o0 f403a;

    public p(o0 o0Var) {
        this.f403a = o0Var;
    }
}
