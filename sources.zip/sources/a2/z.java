package a2;

import bh.e;
import e3.d;
import ge.c;

public final class z implements e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f423a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final Object f424b;

    public z(d dVar) {
        this.f424b = dVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x003c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(bh.f r8, zd.e r9) {
        /*
            r7 = this;
            wd.m r0 = wd.m.f29306a
            int r1 = r7.f423a
            java.lang.Object r2 = r7.f424b
            switch(r1) {
                case 0: goto L_0x006a;
                default: goto L_0x0009;
            }
        L_0x0009:
            boolean r1 = r9 instanceof bh.a
            if (r1 == 0) goto L_0x001c
            r1 = r9
            bh.a r1 = (bh.a) r1
            int r3 = r1.f3649g
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L_0x001c
            int r3 = r3 - r4
            r1.f3649g = r3
            goto L_0x0021
        L_0x001c:
            bh.a r1 = new bh.a
            r1.<init>(r7, r9)
        L_0x0021:
            java.lang.Object r9 = r1.f3647e
            ae.a r3 = ae.a.f795a
            int r4 = r1.f3649g
            r5 = 1
            if (r4 == 0) goto L_0x003c
            if (r4 != r5) goto L_0x0034
            ch.h r8 = r1.f3646d
            v7.r0.C(r9)     // Catch:{ all -> 0x0032 }
            goto L_0x005c
        L_0x0032:
            r9 = move-exception
            goto L_0x0066
        L_0x0034:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L_0x003c:
            v7.r0.C(r9)
            ch.h r9 = new ch.h
            zd.j r4 = r1.f3624b
            v7.r0.g(r4)
            r9.<init>(r8, r4)
            r1.f3646d = r9     // Catch:{ all -> 0x0064 }
            r1.f3649g = r5     // Catch:{ all -> 0x0064 }
            ge.c r2 = (ge.c) r2     // Catch:{ all -> 0x0064 }
            java.lang.Object r8 = r2.g(r9, r1)     // Catch:{ all -> 0x0064 }
            if (r8 != r3) goto L_0x0056
            goto L_0x0057
        L_0x0056:
            r8 = r0
        L_0x0057:
            if (r8 != r3) goto L_0x005b
            r0 = r3
            goto L_0x005f
        L_0x005b:
            r8 = r9
        L_0x005c:
            r8.q()
        L_0x005f:
            return r0
        L_0x0060:
            r6 = r9
            r9 = r8
            r8 = r6
            goto L_0x0066
        L_0x0064:
            r8 = move-exception
            goto L_0x0060
        L_0x0066:
            r8.q()
            throw r9
        L_0x006a:
            bh.e r2 = (bh.e) r2
            a2.y r1 = new a2.y
            r3 = 0
            r1.<init>(r3, r8)
            java.lang.Object r8 = r2.a(r1, r9)
            ae.a r9 = ae.a.f795a
            if (r8 != r9) goto L_0x007b
            r0 = r8
        L_0x007b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.z.a(bh.f, zd.e):java.lang.Object");
    }

    public z(c cVar) {
        this.f424b = cVar;
    }
}
