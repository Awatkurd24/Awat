package a2;

import java.io.FileOutputStream;
import java.io.OutputStream;
import v7.r0;

public final class s extends OutputStream {

    /* renamed from: a  reason: collision with root package name */
    public final FileOutputStream f409a;

    public s(FileOutputStream fileOutputStream) {
        this.f409a = fileOutputStream;
    }

    public final void close() {
    }

    public final void flush() {
        this.f409a.flush();
    }

    public final void write(int i10) {
        this.f409a.write(i10);
    }

    public final void write(byte[] bArr) {
        r0.j("b", bArr);
        this.f409a.write(bArr);
    }

    public final void write(byte[] bArr, int i10, int i11) {
        r0.j("bytes", bArr);
        this.f409a.write(bArr, i10, i11);
    }
}
