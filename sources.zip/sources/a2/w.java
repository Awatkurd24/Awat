package a2;

import ae.a;
import be.i;
import ge.c;
import v7.r0;
import wd.m;
import zd.e;

public final class w extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public /* synthetic */ Object f416e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ o0 f417f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public w(o0 o0Var, e eVar) {
        super(2, eVar);
        this.f417f = o0Var;
    }

    public final e a(Object obj, e eVar) {
        w wVar = new w(this.f417f, eVar);
        wVar.f416e = obj;
        return wVar;
    }

    public final Object g(Object obj, Object obj2) {
        return ((w) a((o0) obj, (e) obj2)).p(m.f29306a);
    }

    public final Object p(Object obj) {
        a aVar = a.f795a;
        r0.C(obj);
        o0 o0Var = (o0) this.f416e;
        o0 o0Var2 = this.f417f;
        boolean z4 = false;
        if (!(o0Var2 instanceof c) && !(o0Var2 instanceof k) && o0Var == o0Var2) {
            z4 = true;
        }
        return Boolean.valueOf(z4);
    }
}
