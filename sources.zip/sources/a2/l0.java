package a2;

import ae.a;
import be.i;
import ge.c;
import v7.r0;
import wd.m;
import yg.z;
import zd.e;

public final class l0 extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public int f375e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ c f376f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ Object f377g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l0(Object obj, e eVar, c cVar) {
        super(2, eVar);
        this.f376f = cVar;
        this.f377g = obj;
    }

    public final e a(Object obj, e eVar) {
        return new l0(this.f377g, eVar, this.f376f);
    }

    public final Object g(Object obj, Object obj2) {
        return ((l0) a((z) obj, (e) obj2)).p(m.f29306a);
    }

    public final Object p(Object obj) {
        a aVar = a.f795a;
        int i10 = this.f375e;
        if (i10 == 0) {
            r0.C(obj);
            this.f375e = 1;
            obj = this.f376f.g(this.f377g, this);
            if (obj == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            r0.C(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}
