package a2;

import c4.j;
import cc.f;
import com.blacksquircle.ui.editorkit.widget.internal.SyntaxHighlightEditText;
import com.v2ray.ang.AppConfig;
import ge.b;
import he.l;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import lg.b0;
import lg.t1;
import r3.o;
import te.n;
import v7.r0;
import y9.a;

public final class t extends l implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f410a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f411b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(int i10, Object obj) {
        super(1);
        this.f410a = i10;
        this.f411b = obj;
    }

    public final b0 a(we.b0 b0Var) {
        int i10 = this.f410a;
        Object obj = this.f411b;
        switch (i10) {
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                r0.j("module", b0Var);
                te.l n10 = b0Var.n();
                t1 t1Var = t1.INVARIANT;
                return n10.g(((te.l) obj).u());
            case 24:
                r0.j("it", b0Var);
                return b0Var.n().q((n) obj);
            default:
                r0.j("it", b0Var);
                return (b0) obj;
        }
    }

    public final void b(Throwable th2) {
        switch (this.f410a) {
            case 0:
                if (th2 != null) {
                    ((n0) this.f411b).f397g.d(new k(th2));
                }
                Object obj = n0.f390k;
                n0 n0Var = (n0) this.f411b;
                synchronized (obj) {
                    n0.f389j.remove(n0Var.d().getAbsolutePath());
                }
                return;
            case 2:
                Object obj2 = this.f411b;
                if (th2 != null) {
                    o oVar = (o) obj2;
                    if (th2 instanceof CancellationException) {
                        oVar.f25381a.cancel(true);
                        return;
                    }
                    j jVar = oVar.f25381a;
                    Throwable cause = th2.getCause();
                    if (cause != null) {
                        th2 = cause;
                    }
                    jVar.k(th2);
                    return;
                } else if (!((o) obj2).f25381a.isDone()) {
                    throw new IllegalArgumentException("Failed requirement.".toString());
                } else {
                    return;
                }
            default:
                ((a) this.f411b).cancel(false);
                return;
        }
    }

    public final void c(List list) {
        f fVar;
        int i10 = this.f410a;
        Object obj = this.f411b;
        switch (i10) {
            case 6:
                r0.j("spans", list);
                SyntaxHighlightEditText syntaxHighlightEditText = (SyntaxHighlightEditText) obj;
                syntaxHighlightEditText.f4283t.clear();
                syntaxHighlightEditText.f4283t.addAll(list);
                syntaxHighlightEditText.k();
                return;
            default:
                r0.g(list);
                Iterator it = list.iterator();
                while (true) {
                    if (it.hasNext()) {
                        fVar = (f) it.next();
                        if (fVar != null) {
                        }
                    } else {
                        fVar = null;
                    }
                }
                if (fVar != null) {
                    ((sd.a) obj).f25974b.h(fVar);
                    return;
                }
                return;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:140:0x04ce, code lost:
        if (r1.equals("hashCode") == false) goto L_0x0524;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:155:0x0515, code lost:
        if (r1.equals("toString") != false) goto L_0x0517;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:157:0x0521, code lost:
        if (r0 == false) goto L_0x0524;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:207:0x0682, code lost:
        if (r0.length == 0) goto L_0x0662;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:211:0x069d, code lost:
        if (java.util.Arrays.equals(r0.getParameterTypes(), new java.lang.Class[]{java.lang.String.class}) == false) goto L_0x069f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object h(java.lang.Object r28) {
        /*
            r27 = this;
            r0 = r27
            r1 = r28
            wd.m r2 = wd.m.f29306a
            int r3 = r0.f410a
            java.lang.String r4 = "values"
            java.lang.String r5 = "getType(...)"
            java.lang.String r6 = "getParameterTypes(...)"
            java.lang.String r7 = "it"
            r9 = 0
            java.lang.Object r11 = r0.f411b
            switch(r3) {
                case 0: goto L_0x07bc;
                case 1: goto L_0x079a;
                case 2: goto L_0x0792;
                case 3: goto L_0x078a;
                case 4: goto L_0x0754;
                case 5: goto L_0x0735;
                case 6: goto L_0x072d;
                case 7: goto L_0x071d;
                case 8: goto L_0x06d6;
                case 9: goto L_0x06ce;
                case 10: goto L_0x06bc;
                case 11: goto L_0x06af;
                case 12: goto L_0x06a5;
                case 13: goto L_0x0657;
                case 14: goto L_0x0640;
                case 15: goto L_0x0580;
                case 16: goto L_0x056b;
                case 17: goto L_0x052c;
                case 18: goto L_0x047f;
                case 19: goto L_0x0462;
                case 20: goto L_0x043e;
                case 21: goto L_0x041e;
                case 22: goto L_0x016e;
                case 23: goto L_0x0165;
                case 24: goto L_0x015e;
                case 25: goto L_0x0157;
                case 26: goto L_0x0138;
                case 27: goto L_0x0037;
                case 28: goto L_0x0028;
                default: goto L_0x0016;
            }
        L_0x0016:
            mg.h r1 = (mg.h) r1
            java.lang.String r2 = "kotlinTypeRefiner"
            v7.r0.j(r2, r1)
            lg.a0 r11 = (lg.a0) r11
            lg.a0 r1 = r11.d(r1)
            lg.g0 r1 = r1.b()
            return r1
        L_0x0028:
            uf.b r1 = (uf.b) r1
            v7.r0.j(r7, r1)
            hg.p r11 = (hg.p) r11
            jg.k r1 = r11.f19807h
            if (r1 == 0) goto L_0x0034
            goto L_0x0036
        L_0x0034:
            we.t0 r1 = we.u0.f29379a
        L_0x0036:
            return r1
        L_0x0037:
            hg.h r1 = (hg.h) r1
            java.lang.String r2 = "key"
            v7.r0.j(r2, r1)
            hg.i r11 = (hg.i) r11
            java.util.Set r2 = hg.i.f19765c
            r11.getClass()
            hg.l r2 = r11.f19766a
            java.lang.Iterable r3 = r2.f19783k
            java.util.Iterator r3 = r3.iterator()
        L_0x004d:
            boolean r4 = r3.hasNext()
            uf.b r5 = r1.f19762a
            if (r4 == 0) goto L_0x0064
            java.lang.Object r4 = r3.next()
            ye.c r4 = (ye.c) r4
            we.f r4 = r4.a(r5)
            if (r4 == 0) goto L_0x004d
            r9 = r4
            goto L_0x0137
        L_0x0064:
            java.util.Set r3 = hg.i.f19765c
            boolean r3 = r3.contains(r5)
            if (r3 == 0) goto L_0x006e
            goto L_0x0137
        L_0x006e:
            hg.f r1 = r1.f19763b
            if (r1 != 0) goto L_0x007c
            hg.g r1 = r2.f19776d
            hg.f r1 = r1.a(r5)
            if (r1 != 0) goto L_0x007c
            goto L_0x0137
        L_0x007c:
            rf.f r3 = r1.f19754a
            pf.j r4 = r1.f19755b
            rf.a r6 = r1.f19756c
            we.u0 r1 = r1.f19757d
            uf.b r7 = r5.f()
            java.lang.String r8 = "getShortClassName(...)"
            if (r7 == 0) goto L_0x00c0
            kg.m r2 = r11.f19767b
            hg.h r10 = new hg.h
            r10.<init>(r7, r9)
            java.lang.Object r2 = r2.h(r10)
            we.f r2 = (we.f) r2
            boolean r7 = r2 instanceof jg.i
            if (r7 == 0) goto L_0x00a0
            jg.i r2 = (jg.i) r2
            goto L_0x00a1
        L_0x00a0:
            r2 = r9
        L_0x00a1:
            if (r2 != 0) goto L_0x00a5
            goto L_0x0137
        L_0x00a5:
            uf.f r5 = r5.i()
            v7.r0.i(r8, r5)
            jg.g r7 = r2.I0()
            java.util.Set r7 = r7.m()
            boolean r5 = r7.contains(r5)
            if (r5 != 0) goto L_0x00bc
            goto L_0x0137
        L_0x00bc:
            e6.j r2 = r2.f20949l
        L_0x00be:
            r13 = r2
            goto L_0x012b
        L_0x00c0:
            uf.c r7 = r5.g()
            java.lang.String r10 = "getPackageFqName(...)"
            v7.r0.i(r10, r7)
            we.h0 r2 = r2.f19778f
            java.util.ArrayList r2 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.r1(r2, r7)
            java.util.Iterator r2 = r2.iterator()
        L_0x00d3:
            boolean r7 = r2.hasNext()
            if (r7 == 0) goto L_0x0101
            java.lang.Object r7 = r2.next()
            r10 = r7
            we.g0 r10 = (we.g0) r10
            boolean r12 = r10 instanceof hg.p
            if (r12 == 0) goto L_0x0102
            hg.p r10 = (hg.p) r10
            uf.f r12 = r5.i()
            v7.r0.i(r8, r12)
            r10.getClass()
            eg.n r10 = r10.A0()
            jg.p r10 = (jg.p) r10
            java.util.Set r10 = r10.m()
            boolean r10 = r10.contains(r12)
            if (r10 == 0) goto L_0x00d3
            goto L_0x0102
        L_0x0101:
            r7 = r9
        L_0x0102:
            r13 = r7
            we.g0 r13 = (we.g0) r13
            if (r13 != 0) goto L_0x0108
            goto L_0x0137
        L_0x0108:
            hg.l r12 = r11.f19766a
            og.a r15 = new og.a
            pf.w0 r2 = r4.E
            java.lang.String r5 = "getTypeTable(...)"
            v7.r0.i(r5, r2)
            r15.<init>(r2)
            pf.d1 r2 = r4.G
            java.lang.String r5 = "getVersionRequirementTable(...)"
            v7.r0.i(r5, r2)
            rf.h r16 = u7.a0.m(r2)
            r18 = 0
            r14 = r3
            r17 = r6
            e6.j r2 = r12.a(r13, r14, r15, r16, r17, r18)
            goto L_0x00be
        L_0x012b:
            jg.i r9 = new jg.i
            r12 = r9
            r14 = r4
            r15 = r3
            r16 = r6
            r17 = r1
            r12.<init>(r13, r14, r15, r16, r17)
        L_0x0137:
            return r9
        L_0x0138:
            uf.c r1 = (uf.c) r1
            java.lang.String r2 = "fqName"
            v7.r0.j(r2, r1)
            hg.a r11 = (hg.a) r11
            ig.c r1 = r11.d(r1)
            if (r1 == 0) goto L_0x0156
            hg.l r2 = r11.f19734d
            if (r2 == 0) goto L_0x0150
            r1.I0(r2)
            r9 = r1
            goto L_0x0156
        L_0x0150:
            java.lang.String r1 = "components"
            v7.r0.D(r1)
            throw r9
        L_0x0156:
            return r9
        L_0x0157:
            we.b0 r1 = (we.b0) r1
            lg.b0 r1 = r0.a(r1)
            return r1
        L_0x015e:
            we.b0 r1 = (we.b0) r1
            lg.b0 r1 = r0.a(r1)
            return r1
        L_0x0165:
            tg.h r11 = (tg.h) r11
            v7.r0.g(r28)
            r11.add(r1)
            return r2
        L_0x016e:
            nf.c0 r1 = (nf.c0) r1
            java.lang.String r2 = "kotlinClass"
            v7.r0.j(r2, r1)
            nf.f r11 = (nf.f) r11
            r11.getClass()
            java.util.HashMap r2 = new java.util.HashMap
            r2.<init>()
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            java.util.HashMap r4 = new java.util.HashMap
            r4.<init>()
            nf.d r7 = new nf.d
            r7.<init>(r11, r2, r3)
            bf.c r1 = (bf.c) r1
            java.lang.String r9 = "klass"
            java.lang.Class r1 = r1.f3632a
            v7.r0.j(r9, r1)
            java.lang.reflect.Method[] r9 = r1.getDeclaredMethods()
            java.lang.String r11 = "getDeclaredMethods(...)"
            v7.r0.i(r11, r9)
            int r11 = r9.length
            r12 = 0
        L_0x01a2:
            java.lang.String r13 = "toString(...)"
            java.lang.String r14 = "("
            java.lang.String r15 = "getDeclaredAnnotations(...)"
            if (r12 >= r11) goto L_0x0283
            r16 = r9[r12]
            java.lang.String r17 = r16.getName()
            uf.f r8 = uf.f.e(r17)
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>(r14)
            java.lang.Class[] r14 = r16.getParameterTypes()
            v7.r0.i(r6, r14)
            r28 = r9
            int r9 = r14.length
            r19 = r11
            r11 = 0
        L_0x01c6:
            if (r11 >= r9) goto L_0x01db
            r20 = r14[r11]
            v7.r0.g(r20)
            r21 = r9
            java.lang.String r9 = cf.d.b(r20)
            r10.append(r9)
            int r11 = r11 + 1
            r9 = r21
            goto L_0x01c6
        L_0x01db:
            java.lang.String r9 = ")"
            r10.append(r9)
            java.lang.Class r9 = r16.getReturnType()
            java.lang.String r11 = "getReturnType(...)"
            v7.r0.i(r11, r9)
            java.lang.String r9 = cf.d.b(r9)
            r10.append(r9)
            java.lang.String r9 = r10.toString()
            v7.r0.i(r13, r9)
            nf.b r8 = r7.a(r8, r9)
            java.lang.annotation.Annotation[] r9 = r16.getDeclaredAnnotations()
            v7.r0.i(r15, r9)
            int r10 = r9.length
            r11 = 0
        L_0x0204:
            if (r11 >= r10) goto L_0x022c
            r13 = r9[r11]
            v7.r0.g(r13)
            ne.c r14 = v7.l9.h(r13)
            java.lang.Class r14 = v7.l9.i(r14)
            uf.b r15 = cf.d.a(r14)
            r20 = r9
            bf.a r9 = new bf.a
            r9.<init>(r13)
            nf.z r9 = r8.b(r15, r9)
            if (r9 == 0) goto L_0x0227
            na.k1.d(r9, r13, r14)
        L_0x0227:
            int r11 = r11 + 1
            r9 = r20
            goto L_0x0204
        L_0x022c:
            java.lang.annotation.Annotation[][] r9 = r16.getParameterAnnotations()
            java.lang.String r10 = "getParameterAnnotations(...)"
            v7.r0.i(r10, r9)
            java.lang.annotation.Annotation[][] r9 = (java.lang.annotation.Annotation[][]) r9
            int r10 = r9.length
            r11 = 0
        L_0x0239:
            if (r11 >= r10) goto L_0x0278
            r13 = r9[r11]
            v7.r0.g(r13)
            int r14 = r13.length
            r15 = 0
        L_0x0242:
            r16 = r9
            if (r15 >= r14) goto L_0x0273
            r9 = r13[r15]
            ne.c r20 = v7.l9.h(r9)
            r21 = r10
            java.lang.Class r10 = v7.l9.i(r20)
            r20 = r13
            uf.b r13 = cf.d.a(r10)
            r22 = r14
            bf.a r14 = new bf.a
            r14.<init>(r9)
            nf.m r13 = r8.c(r11, r13, r14)
            if (r13 == 0) goto L_0x0268
            na.k1.d(r13, r9, r10)
        L_0x0268:
            int r15 = r15 + 1
            r9 = r16
            r13 = r20
            r10 = r21
            r14 = r22
            goto L_0x0242
        L_0x0273:
            r21 = r10
            int r11 = r11 + 1
            goto L_0x0239
        L_0x0278:
            r8.a()
            int r12 = r12 + 1
            r9 = r28
            r11 = r19
            goto L_0x01a2
        L_0x0283:
            java.lang.reflect.Constructor[] r8 = r1.getDeclaredConstructors()
            java.lang.String r9 = "getDeclaredConstructors(...)"
            v7.r0.i(r9, r8)
            int r9 = r8.length
            r10 = 0
        L_0x028e:
            if (r10 >= r9) goto L_0x038b
            r11 = r8[r10]
            uf.f r12 = uf.h.f27351e
            v7.r0.g(r11)
            r28 = r8
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>(r14)
            r16 = r9
            java.lang.Class[] r9 = r11.getParameterTypes()
            v7.r0.i(r6, r9)
            r19 = r14
            int r14 = r9.length
            r0 = 0
        L_0x02ab:
            if (r0 >= r14) goto L_0x02c0
            r20 = r9[r0]
            v7.r0.g(r20)
            r21 = r9
            java.lang.String r9 = cf.d.b(r20)
            r8.append(r9)
            int r0 = r0 + 1
            r9 = r21
            goto L_0x02ab
        L_0x02c0:
            java.lang.String r0 = ")V"
            r8.append(r0)
            java.lang.String r0 = r8.toString()
            v7.r0.i(r13, r0)
            nf.b r0 = r7.a(r12, r0)
            java.lang.annotation.Annotation[] r8 = r11.getDeclaredAnnotations()
            v7.r0.i(r15, r8)
            int r9 = r8.length
            r12 = 0
        L_0x02d9:
            if (r12 >= r9) goto L_0x0309
            r14 = r8[r12]
            v7.r0.g(r14)
            ne.c r20 = v7.l9.h(r14)
            r21 = r8
            java.lang.Class r8 = v7.l9.i(r20)
            r20 = r9
            uf.b r9 = cf.d.a(r8)
            r22 = r13
            bf.a r13 = new bf.a
            r13.<init>(r14)
            nf.z r9 = r0.b(r9, r13)
            if (r9 == 0) goto L_0x0300
            na.k1.d(r9, r14, r8)
        L_0x0300:
            int r12 = r12 + 1
            r9 = r20
            r8 = r21
            r13 = r22
            goto L_0x02d9
        L_0x0309:
            r22 = r13
            java.lang.annotation.Annotation[][] r8 = r11.getParameterAnnotations()
            v7.r0.g(r8)
            int r9 = r8.length
            if (r9 != 0) goto L_0x0319
            r9 = 1
            r17 = 1
            goto L_0x031c
        L_0x0319:
            r9 = 1
            r17 = 0
        L_0x031c:
            r12 = r17 ^ 1
            if (r12 == 0) goto L_0x0376
            java.lang.Class[] r9 = r11.getParameterTypes()
            int r9 = r9.length
            int r11 = r8.length
            int r9 = r9 - r11
            int r11 = r8.length
            r12 = 0
        L_0x0329:
            if (r12 >= r11) goto L_0x0376
            r13 = r8[r12]
            v7.r0.g(r13)
            int r14 = r13.length
            r20 = r8
            r8 = 0
        L_0x0334:
            if (r8 >= r14) goto L_0x036b
            r21 = r11
            r11 = r13[r8]
            ne.c r23 = v7.l9.h(r11)
            r24 = r13
            java.lang.Class r13 = v7.l9.i(r23)
            r23 = r14
            int r14 = r12 + r9
            r25 = r9
            uf.b r9 = cf.d.a(r13)
            r26 = r6
            bf.a r6 = new bf.a
            r6.<init>(r11)
            nf.m r6 = r0.c(r14, r9, r6)
            if (r6 == 0) goto L_0x035e
            na.k1.d(r6, r11, r13)
        L_0x035e:
            int r8 = r8 + 1
            r11 = r21
            r14 = r23
            r13 = r24
            r9 = r25
            r6 = r26
            goto L_0x0334
        L_0x036b:
            r26 = r6
            r25 = r9
            r21 = r11
            int r12 = r12 + 1
            r8 = r20
            goto L_0x0329
        L_0x0376:
            r26 = r6
            r0.a()
            int r10 = r10 + 1
            r0 = r27
            r8 = r28
            r9 = r16
            r14 = r19
            r13 = r22
            r6 = r26
            goto L_0x028e
        L_0x038b:
            java.lang.reflect.Field[] r0 = r1.getDeclaredFields()
            java.lang.String r1 = "getDeclaredFields(...)"
            v7.r0.i(r1, r0)
            int r1 = r0.length
            r6 = 0
        L_0x0396:
            if (r6 >= r1) goto L_0x0418
            r8 = r0[r6]
            java.lang.String r9 = r8.getName()
            uf.f r9 = uf.f.e(r9)
            java.lang.Class r10 = r8.getType()
            v7.r0.i(r5, r10)
            java.lang.String r10 = cf.d.b(r10)
            java.lang.String r11 = "desc"
            v7.r0.j(r11, r10)
            java.lang.String r9 = r9.b()
            java.lang.String r11 = "asString(...)"
            v7.r0.i(r11, r9)
            nf.f0 r9 = w7.u1.j(r9, r10)
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            java.lang.annotation.Annotation[] r8 = r8.getDeclaredAnnotations()
            v7.r0.i(r15, r8)
            int r11 = r8.length
            r12 = 0
        L_0x03cd:
            if (r12 >= r11) goto L_0x03ff
            r13 = r8[r12]
            v7.r0.g(r13)
            ne.c r14 = v7.l9.h(r13)
            java.lang.Class r14 = v7.l9.i(r14)
            r28 = r0
            uf.b r0 = cf.d.a(r14)
            r16 = r1
            bf.a r1 = new bf.a
            r1.<init>(r13)
            r19 = r8
            nf.f r8 = r7.f23361a
            nf.m r0 = r8.q(r0, r1, r10)
            if (r0 == 0) goto L_0x03f6
            na.k1.d(r0, r13, r14)
        L_0x03f6:
            int r12 = r12 + 1
            r0 = r28
            r1 = r16
            r8 = r19
            goto L_0x03cd
        L_0x03ff:
            r28 = r0
            r16 = r1
            boolean r0 = r10.isEmpty()
            r1 = 1
            r0 = r0 ^ r1
            if (r0 == 0) goto L_0x0410
            java.util.HashMap r0 = r7.f23362b
            r0.put(r9, r10)
        L_0x0410:
            int r6 = r6 + 1
            r0 = r28
            r1 = r16
            goto L_0x0396
        L_0x0418:
            nf.i r0 = new nf.i
            r0.<init>(r2, r3, r4)
            return r0
        L_0x041e:
            r0 = r1
            we.c r0 = (we.c) r0
            v7.r0.j(r7, r0)
            java.util.List r0 = r0.C0()
            we.g1 r11 = (we.g1) r11
            ze.a1 r11 = (ze.a1) r11
            int r1 = r11.f31422f
            java.lang.Object r0 = r0.get(r1)
            we.g1 r0 = (we.g1) r0
            ze.b1 r0 = (ze.b1) r0
            lg.b0 r0 = r0.b()
            v7.r0.i(r5, r0)
            return r0
        L_0x043e:
            r0 = r1
            mf.o r0 = (mf.o) r0
            java.lang.String r1 = "$this$function"
            v7.r0.j(r1, r0)
            nf.r r11 = (nf.r) r11
            r11.getClass()
            java.lang.String r1 = "java/util/"
            java.lang.String r3 = "Spliterator"
            java.lang.String r1 = r1.concat(r3)
            r3 = 2
            mf.c[] r3 = new mf.c[r3]
            mf.c r4 = mf.i.f22732b
            r5 = 0
            r3[r5] = r4
            r5 = 1
            r3[r5] = r4
            r0.c(r1, r3)
            return r2
        L_0x0462:
            r0 = r1
            mg.h r0 = (mg.h) r0
            v7.r0.j(r7, r0)
            if.o r0 = new if.o
            r3 = r11
            if.i r3 = (p000if.i) r3
            q.f r2 = r3.f20271k
            lf.g r4 = r3.f20269i
            we.f r1 = r3.f20270j
            if (r1 == 0) goto L_0x0477
            r5 = 1
            goto L_0x0478
        L_0x0477:
            r5 = 0
        L_0x0478:
            if.o r6 = r3.f20278r
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6)
            return r0
        L_0x047f:
            r0 = r1
            cf.z r0 = (cf.z) r0
            java.lang.String r1 = "m"
            v7.r0.j(r1, r0)
            if.a r11 = (p000if.a) r11
            ge.b r1 = r11.f20219b
            java.lang.Object r1 = r1.h(r0)
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            if (r1 == 0) goto L_0x0526
            java.lang.reflect.Member r1 = r0.a()
            java.lang.reflect.Method r1 = (java.lang.reflect.Method) r1
            java.lang.Class r1 = r1.getDeclaringClass()
            java.lang.String r2 = "getDeclaringClass(...)"
            v7.r0.i(r2, r1)
            boolean r1 = r1.isInterface()
            if (r1 == 0) goto L_0x0524
            uf.f r1 = r0.b()
            java.lang.String r1 = r1.b()
            int r2 = r1.hashCode()
            r3 = -1776922004(0xffffffff9616526c, float:-1.2142911E-25)
            if (r2 == r3) goto L_0x050f
            r3 = -1295482945(0xffffffffb2c87fbf, float:-2.3341157E-8)
            if (r2 == r3) goto L_0x04d1
            r3 = 147696667(0x8cdac1b, float:1.23784505E-33)
            if (r2 == r3) goto L_0x04c8
            goto L_0x0524
        L_0x04c8:
            java.lang.String r2 = "hashCode"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x0517
            goto L_0x0524
        L_0x04d1:
            java.lang.String r2 = "equals"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x04da
            goto L_0x0524
        L_0x04da:
            java.util.List r0 = r0.e()
            java.lang.Object r0 = xd.o.u0(r0)
            cf.f0 r0 = (cf.f0) r0
            if (r0 == 0) goto L_0x04e9
            cf.d0 r0 = r0.f4160a
            goto L_0x04ea
        L_0x04e9:
            r0 = r9
        L_0x04ea:
            boolean r1 = r0 instanceof lf.i
            if (r1 == 0) goto L_0x04f1
            r9 = r0
            lf.i r9 = (lf.i) r9
        L_0x04f1:
            if (r9 != 0) goto L_0x04f4
            goto L_0x0524
        L_0x04f4:
            cf.s r9 = (cf.s) r9
            cf.u r0 = r9.f4181b
            boolean r1 = r0 instanceof lf.g
            if (r1 == 0) goto L_0x0524
            lf.g r0 = (lf.g) r0
            cf.q r0 = (cf.q) r0
            uf.c r0 = r0.b()
            java.lang.String r0 = r0.b()
            java.lang.String r1 = "java.lang.Object"
            boolean r0 = v7.r0.b(r0, r1)
            goto L_0x0521
        L_0x050f:
            java.lang.String r2 = "toString"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0524
        L_0x0517:
            java.util.List r0 = r0.e()
            java.util.ArrayList r0 = (java.util.ArrayList) r0
            boolean r0 = r0.isEmpty()
        L_0x0521:
            if (r0 == 0) goto L_0x0524
            goto L_0x0526
        L_0x0524:
            r8 = 1
            goto L_0x0527
        L_0x0526:
            r8 = 0
        L_0x0527:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r8)
            return r0
        L_0x052c:
            r0 = r1
            cf.e0 r0 = (cf.e0) r0
            java.lang.String r1 = "typeParameter"
            v7.r0.j(r1, r0)
            hf.f r11 = (hf.f) r11
            java.util.LinkedHashMap r1 = r11.f19728d
            java.lang.Object r1 = r1.get(r0)
            java.lang.Integer r1 = (java.lang.Integer) r1
            if (r1 == 0) goto L_0x056a
            int r1 = r1.intValue()
            if.j0 r9 = new if.j0
            java.lang.String r2 = "<this>"
            q.f r3 = r11.f19725a
            v7.r0.j(r2, r3)
            q.f r2 = new q.f
            java.lang.Object r4 = r3.f24801b
            hf.a r4 = (hf.a) r4
            java.lang.Object r3 = r3.f24803d
            wd.d r3 = (wd.d) r3
            r2.<init>((hf.a) r4, (hf.h) r11, (wd.d) r3)
            we.l r3 = r11.f19726b
            xe.i r4 = r3.m()
            q.f r2 = v7.f9.e(r2, r4)
            int r4 = r11.f19727c
            int r4 = r4 + r1
            r9.<init>(r2, r0, r4, r3)
        L_0x056a:
            return r9
        L_0x056b:
            r0 = r1
            lf.a r0 = (lf.a) r0
            java.lang.String r1 = "annotation"
            v7.r0.j(r1, r0)
            uf.f r1 = ff.c.f18848a
            hf.d r11 = (hf.d) r11
            q.f r1 = r11.f19719a
            boolean r2 = r11.f19721c
            gf.h r0 = ff.c.b(r1, r0, r2)
            return r0
        L_0x0580:
            r0 = r1
            uf.c r0 = (uf.c) r0
            v7.r0.g(r0)
            ef.g0 r11 = (ef.g0) r11
            java.util.Map r1 = r11.f18260b
            v7.r0.j(r4, r1)
            java.util.LinkedHashMap r2 = new java.util.LinkedHashMap
            r2.<init>()
            java.util.Set r1 = r1.entrySet()
            java.util.Iterator r1 = r1.iterator()
        L_0x059a:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x05d5
            java.lang.Object r3 = r1.next()
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3
            java.lang.Object r4 = r3.getKey()
            uf.c r4 = (uf.c) r4
            boolean r5 = v7.r0.b(r0, r4)
            if (r5 != 0) goto L_0x05c9
            java.lang.String r5 = "packageName"
            v7.r0.j(r5, r4)
            boolean r5 = r0.d()
            if (r5 == 0) goto L_0x05bf
            r5 = r9
            goto L_0x05c3
        L_0x05bf:
            uf.c r5 = r0.e()
        L_0x05c3:
            boolean r4 = v7.r0.b(r5, r4)
            if (r4 == 0) goto L_0x059a
        L_0x05c9:
            java.lang.Object r4 = r3.getKey()
            java.lang.Object r3 = r3.getValue()
            r2.put(r4, r3)
            goto L_0x059a
        L_0x05d5:
            boolean r1 = r2.isEmpty()
            r3 = 1
            r1 = r1 ^ r3
            if (r1 == 0) goto L_0x05de
            goto L_0x05df
        L_0x05de:
            r2 = r9
        L_0x05df:
            if (r2 != 0) goto L_0x05e2
            goto L_0x063f
        L_0x05e2:
            java.util.Set r1 = r2.entrySet()
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.Iterator r2 = r1.iterator()
            boolean r1 = r2.hasNext()
            if (r1 != 0) goto L_0x05f4
            r1 = r9
            goto L_0x0637
        L_0x05f4:
            java.lang.Object r1 = r2.next()
            boolean r3 = r2.hasNext()
            if (r3 != 0) goto L_0x05ff
            goto L_0x0637
        L_0x05ff:
            r3 = r1
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3
            java.lang.Object r3 = r3.getKey()
            uf.c r3 = (uf.c) r3
            uf.c r3 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.X1(r3, r0)
            java.lang.String r3 = r3.b()
            int r3 = r3.length()
        L_0x0614:
            java.lang.Object r4 = r2.next()
            r5 = r4
            java.util.Map$Entry r5 = (java.util.Map.Entry) r5
            java.lang.Object r5 = r5.getKey()
            uf.c r5 = (uf.c) r5
            uf.c r5 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.X1(r5, r0)
            java.lang.String r5 = r5.b()
            int r5 = r5.length()
            if (r3 <= r5) goto L_0x0631
            r1 = r4
            r3 = r5
        L_0x0631:
            boolean r4 = r2.hasNext()
            if (r4 != 0) goto L_0x0614
        L_0x0637:
            java.util.Map$Entry r1 = (java.util.Map.Entry) r1
            if (r1 == 0) goto L_0x063f
            java.lang.Object r9 = r1.getValue()
        L_0x063f:
            return r9
        L_0x0640:
            r0 = r1
            we.c r0 = (we.c) r0
            v7.r0.j(r7, r0)
            java.util.LinkedHashMap r0 = ef.p0.f18304j
            ze.s0 r11 = (ze.s0) r11
            java.lang.String r1 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.G(r11)
            boolean r0 = r0.containsKey(r1)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        L_0x0657:
            r26 = r6
            r0 = r1
            java.lang.reflect.Method r0 = (java.lang.reflect.Method) r0
            boolean r1 = r0.isSynthetic()
            if (r1 == 0) goto L_0x0664
        L_0x0662:
            r8 = 0
            goto L_0x06a0
        L_0x0664:
            cf.q r11 = (cf.q) r11
            java.lang.Class r1 = r11.f4178a
            boolean r1 = r1.isEnum()
            if (r1 == 0) goto L_0x069f
            java.lang.String r1 = r0.getName()
            boolean r2 = v7.r0.b(r1, r4)
            if (r2 == 0) goto L_0x0685
            java.lang.Class[] r0 = r0.getParameterTypes()
            r1 = r26
            v7.r0.i(r1, r0)
            int r0 = r0.length
            if (r0 != 0) goto L_0x069f
            goto L_0x0662
        L_0x0685:
            java.lang.String r2 = "valueOf"
            boolean r1 = v7.r0.b(r1, r2)
            if (r1 == 0) goto L_0x069f
            java.lang.Class[] r0 = r0.getParameterTypes()
            r1 = 1
            java.lang.Class[] r2 = new java.lang.Class[r1]
            java.lang.Class<java.lang.String> r1 = java.lang.String.class
            r3 = 0
            r2[r3] = r1
            boolean r0 = java.util.Arrays.equals(r0, r2)
            if (r0 != 0) goto L_0x0662
        L_0x069f:
            r8 = 1
        L_0x06a0:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r8)
            return r0
        L_0x06a5:
            r0 = r1
            we.b0 r0 = (we.b0) r0
            r3 = r27
            lg.b0 r0 = r3.a(r0)
            return r0
        L_0x06af:
            r3 = r0
            xd.a r11 = (xd.a) r11
            if (r1 != r11) goto L_0x06b7
            java.lang.String r0 = "(this Collection)"
            goto L_0x06bb
        L_0x06b7:
            java.lang.String r0 = java.lang.String.valueOf(r28)
        L_0x06bb:
            return r0
        L_0x06bc:
            r3 = r0
            r0 = r1
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            z.k r11 = (z.k) r11
            z.l r1 = r11.b()
            r1.l(r0)
            return r2
        L_0x06ce:
            r3 = r0
            r0 = r1
            java.util.List r0 = (java.util.List) r0
            r3.c(r0)
            return r2
        L_0x06d6:
            r3 = r0
            r0 = r1
            java.util.ArrayList r0 = (java.util.ArrayList) r0
            java.util.Set r11 = (java.util.Set) r11
            if (r11 == 0) goto L_0x0713
            v7.r0.g(r0)
            java.util.Iterator r1 = r0.iterator()
        L_0x06e5:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0707
            java.lang.Object r2 = r1.next()
            com.v2ray.ang.dto.AppInfo r2 = (com.v2ray.ang.dto.AppInfo) r2
            java.lang.String r4 = r2.getPackageName()
            boolean r4 = r11.contains(r4)
            if (r4 == 0) goto L_0x0701
            r4 = 1
            r2.setSelected(r4)
            r5 = 0
            goto L_0x06e5
        L_0x0701:
            r4 = 1
            r5 = 0
            r2.setSelected(r5)
            goto L_0x06e5
        L_0x0707:
            t.n1 r1 = new t.n1
            r2 = 8
            r1.<init>(r2)
        L_0x070e:
            java.util.List r0 = xd.o.w0(r0, r1)
            goto L_0x071c
        L_0x0713:
            com.v2ray.ang.ui.PerAppProxyActivity$onCreate$1$comparator$2 r1 = new com.v2ray.ang.ui.PerAppProxyActivity$onCreate$1$comparator$2
            r1.<init>()
            v7.r0.g(r0)
            goto L_0x070e
        L_0x071c:
            return r0
        L_0x071d:
            r3 = r0
            r0 = r1
            java.lang.Long r0 = (java.lang.Long) r0
            com.v2ray.ang.service.V2RayServiceManager r0 = com.v2ray.ang.service.V2RayServiceManager.INSTANCE
            com.v2ray.ang.ui.MainRecyclerAdapter r11 = (com.v2ray.ang.ui.MainRecyclerAdapter) r11
            com.v2ray.ang.ui.MainActivity r1 = r11.mActivity
            r0.startV2Ray(r1)
            return r2
        L_0x072d:
            r3 = r0
            r0 = r1
            java.util.List r0 = (java.util.List) r0
            r3.c(r0)
            return r2
        L_0x0735:
            r3 = r0
            r0 = r1
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            v7.r0.g(r0)
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x0753
            co.dev.ui.WelcomeActivity r11 = (co.dev.ui.WelcomeActivity) r11
            java.lang.String r0 = r11.TAG
            java.lang.String r1 = "onCreate: onDomainChanged"
            android.util.Log.i(r0, r1)
            r11.getToken()
            r11.getAppSetting()
        L_0x0753:
            return r2
        L_0x0754:
            r3 = r0
            r0 = r1
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            co.dev.ui.ConnectedActivity r11 = (co.dev.ui.ConnectedActivity) r11
            int r1 = r11.duration
            int r1 = r1 - r0
            r11.setProgressStep(r1)
            androidx.activity.d r0 = new androidx.activity.d
            r1 = 29
            r0.<init>(r1, r11)
            r11.runOnUiThread(r0)
            java.lang.String r0 = r11.getTAG()
            int r1 = r11.getProgressStep()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "initChronometer: "
            r4.<init>(r5)
            r4.append(r1)
            java.lang.String r1 = r4.toString()
            android.util.Log.i(r0, r1)
            return r2
        L_0x078a:
            r3 = r0
            r0 = r1
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            r3.b(r0)
            return r2
        L_0x0792:
            r3 = r0
            r0 = r1
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            r3.b(r0)
            return r2
        L_0x079a:
            r3 = r0
            r0 = r1
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.String r1 = "entry"
            v7.r0.j(r1, r0)
            java.util.Collection r11 = (java.util.Collection) r11
            java.lang.Iterable r11 = (java.lang.Iterable) r11
            java.lang.Object r0 = r0.getValue()
            android.view.View r0 = (android.view.View) r0
            java.util.WeakHashMap r1 = r1.h1.f25195a
            java.lang.String r0 = r1.v0.k(r0)
            boolean r0 = xd.o.X(r11, r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        L_0x07bc:
            r3 = r0
            r0 = r1
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            r3.b(r0)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.t.h(java.lang.Object):java.lang.Object");
    }
}
