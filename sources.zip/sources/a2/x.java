package a2;

import be.c;
import zd.e;

public final class x extends c {

    /* renamed from: d  reason: collision with root package name */
    public /* synthetic */ Object f418d;

    /* renamed from: e  reason: collision with root package name */
    public int f419e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ y f420f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public x(y yVar, e eVar) {
        super(eVar);
        this.f420f = yVar;
    }

    public final Object p(Object obj) {
        this.f418d = obj;
        this.f419e |= Integer.MIN_VALUE;
        return this.f420f.k((Object) null, this);
    }
}
