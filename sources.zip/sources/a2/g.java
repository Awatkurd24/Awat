package a2;

import ae.a;
import be.i;
import ge.c;
import java.util.Iterator;
import java.util.List;
import v7.r0;
import wd.m;
import zd.e;

public final class g extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public Iterator f341e;

    /* renamed from: f  reason: collision with root package name */
    public Object f342f;

    /* renamed from: g  reason: collision with root package name */
    public int f343g;

    /* renamed from: h  reason: collision with root package name */
    public /* synthetic */ Object f344h;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ List f345i;

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ List f346j;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(List list, List list2, e eVar) {
        super(2, eVar);
        this.f345i = list;
        this.f346j = list2;
    }

    public final e a(Object obj, e eVar) {
        g gVar = new g(this.f345i, this.f346j, eVar);
        gVar.f344h = obj;
        return gVar;
    }

    public final Object g(Object obj, Object obj2) {
        return ((g) a(obj, (e) obj2)).p(m.f29306a);
    }

    public final Object p(Object obj) {
        List list;
        Iterator it;
        a aVar = a.f795a;
        int i10 = this.f343g;
        if (i10 == 0) {
            r0.C(obj);
            obj = this.f344h;
            it = this.f345i.iterator();
            list = this.f346j;
        } else if (i10 == 1) {
            Object obj2 = this.f342f;
            Iterator it2 = this.f341e;
            List list2 = (List) this.f344h;
            r0.C(obj);
            if (!((Boolean) obj).booleanValue()) {
                obj = obj2;
                it = it2;
                list = list2;
            } else {
                list2.add(new i(1, (e) null));
                this.f344h = list2;
                this.f341e = it2;
                this.f342f = null;
                this.f343g = 2;
                throw null;
            }
        } else if (i10 == 2) {
            it = this.f341e;
            list = (List) this.f344h;
            r0.C(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        if (!it.hasNext()) {
            return obj;
        }
        f.c.w(it.next());
        this.f344h = list;
        this.f341e = it;
        this.f342f = obj;
        this.f343g = 1;
        throw null;
    }
}
