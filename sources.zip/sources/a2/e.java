package a2;

import be.c;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

public final class e extends c {

    /* renamed from: d  reason: collision with root package name */
    public Serializable f323d;

    /* renamed from: e  reason: collision with root package name */
    public Iterator f324e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f325f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ h f326g;

    /* renamed from: h  reason: collision with root package name */
    public int f327h;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(h hVar, zd.e eVar) {
        super(eVar);
        this.f326g = hVar;
    }

    public final Object p(Object obj) {
        this.f325f = obj;
        this.f327h |= Integer.MIN_VALUE;
        return h.c(this.f326g, (List) null, (f0) null, this);
    }
}
