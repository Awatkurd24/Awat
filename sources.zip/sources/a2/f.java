package a2;

import ae.a;
import be.i;
import ge.b;
import v7.r0;
import wd.m;
import zd.e;

public final class f extends i implements b {

    /* renamed from: e  reason: collision with root package name */
    public int f336e;

    /* JADX WARNING: type inference failed for: r0v0, types: [be.i, a2.f] */
    public final Object h(Object obj) {
        ? iVar = new i(1, (e) obj);
        m mVar = m.f29306a;
        iVar.p(mVar);
        return mVar;
    }

    public final Object p(Object obj) {
        a aVar = a.f795a;
        int i10 = this.f336e;
        if (i10 == 0) {
            r0.C(obj);
            this.f336e = 1;
            throw null;
        } else if (i10 == 1) {
            r0.C(obj);
            return m.f29306a;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
