package a2;

import be.c;
import zd.e;

public final class g0 extends c {

    /* renamed from: d  reason: collision with root package name */
    public n0 f347d;

    /* renamed from: e  reason: collision with root package name */
    public /* synthetic */ Object f348e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ n0 f349f;

    /* renamed from: g  reason: collision with root package name */
    public int f350g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g0(n0 n0Var, e eVar) {
        super(eVar);
        this.f349f = n0Var;
    }

    public final Object p(Object obj) {
        this.f348e = obj;
        this.f350g |= Integer.MIN_VALUE;
        return this.f349f.f(this);
    }
}
