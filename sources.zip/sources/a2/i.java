package a2;

public abstract class i {

    /* renamed from: a  reason: collision with root package name */
    public static final h f356a = new Object();
}
