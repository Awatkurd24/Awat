package a2;

import bh.f;

public final class y implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f421a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f422b;

    public /* synthetic */ y(int i10, Object obj) {
        this.f421a = i10;
        this.f422b = obj;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0042  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object k(java.lang.Object r7, zd.e r8) {
        /*
            r6 = this;
            wd.m r0 = wd.m.f29306a
            int r1 = r6.f421a
            java.lang.Object r2 = r6.f422b
            switch(r1) {
                case 0: goto L_0x0013;
                default: goto L_0x0009;
            }
        L_0x0009:
            mb.p r7 = (mb.p) r7
            mb.d0 r2 = (mb.d0) r2
            java.util.concurrent.atomic.AtomicReference r8 = r2.f22536c
            r8.set(r7)
            return r0
        L_0x0013:
            boolean r1 = r8 instanceof a2.x
            if (r1 == 0) goto L_0x0026
            r1 = r8
            a2.x r1 = (a2.x) r1
            int r3 = r1.f419e
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L_0x0026
            int r3 = r3 - r4
            r1.f419e = r3
            goto L_0x002b
        L_0x0026:
            a2.x r1 = new a2.x
            r1.<init>(r6, r8)
        L_0x002b:
            java.lang.Object r8 = r1.f418d
            ae.a r3 = ae.a.f795a
            int r4 = r1.f419e
            r5 = 1
            if (r4 == 0) goto L_0x0042
            if (r4 != r5) goto L_0x003a
            v7.r0.C(r8)
            goto L_0x0062
        L_0x003a:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L_0x0042:
            v7.r0.C(r8)
            bh.f r2 = (bh.f) r2
            a2.o0 r7 = (a2.o0) r7
            boolean r8 = r7 instanceof a2.l
            if (r8 != 0) goto L_0x007e
            boolean r8 = r7 instanceof a2.k
            if (r8 != 0) goto L_0x0079
            boolean r8 = r7 instanceof a2.c
            if (r8 == 0) goto L_0x0063
            a2.c r7 = (a2.c) r7
            java.lang.Object r7 = r7.f303a
            r1.f419e = r5
            java.lang.Object r7 = r2.k(r7, r1)
            if (r7 != r3) goto L_0x0062
            r0 = r3
        L_0x0062:
            return r0
        L_0x0063:
            boolean r7 = r7 instanceof a2.p0
            if (r7 == 0) goto L_0x0073
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542"
            java.lang.String r8 = r8.toString()
            r7.<init>(r8)
            throw r7
        L_0x0073:
            n1.q r7 = new n1.q
            r7.<init>()
            throw r7
        L_0x0079:
            a2.k r7 = (a2.k) r7
            java.lang.Throwable r7 = r7.f367a
            throw r7
        L_0x007e:
            a2.l r7 = (a2.l) r7
            java.lang.Throwable r7 = r7.f374a
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.y.k(java.lang.Object, zd.e):java.lang.Object");
    }
}
