package a2;

import be.i;
import ge.c;
import wd.m;
import zd.e;

public final class v extends i implements c {

    /* renamed from: e  reason: collision with root package name */
    public int f413e;

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f414f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ n0 f415g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public v(n0 n0Var, e eVar) {
        super(2, eVar);
        this.f415g = n0Var;
    }

    public final e a(Object obj, e eVar) {
        v vVar = new v(this.f415g, eVar);
        vVar.f414f = obj;
        return vVar;
    }

    public final Object g(Object obj, Object obj2) {
        return ((v) a((r) obj, (e) obj2)).p(m.f29306a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0045, code lost:
        if (r7 == r0) goto L_0x005e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0056, code lost:
        if (r7 == r0) goto L_0x005e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object p(java.lang.Object r7) {
        /*
            r6 = this;
            ae.a r0 = ae.a.f795a
            int r1 = r6.f413e
            wd.m r2 = wd.m.f29306a
            r3 = 2
            r4 = 1
            if (r1 == 0) goto L_0x001b
            if (r1 == r4) goto L_0x0017
            if (r1 != r3) goto L_0x000f
            goto L_0x0017
        L_0x000f:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L_0x0017:
            v7.r0.C(r7)
            goto L_0x007c
        L_0x001b:
            v7.r0.C(r7)
            java.lang.Object r7 = r6.f414f
            a2.r r7 = (a2.r) r7
            boolean r1 = r7 instanceof a2.p
            a2.n0 r5 = r6.f415g
            if (r1 == 0) goto L_0x006d
            a2.p r7 = (a2.p) r7
            r6.f413e = r4
            bh.u r1 = r5.f397g
            java.lang.Object r1 = r1.c()
            a2.o0 r1 = (a2.o0) r1
            boolean r3 = r1 instanceof a2.c
            if (r3 == 0) goto L_0x0039
            goto L_0x005d
        L_0x0039:
            boolean r3 = r1 instanceof a2.l
            if (r3 == 0) goto L_0x004a
            a2.o0 r7 = r7.f403a
            if (r1 != r7) goto L_0x0048
            java.lang.Object r7 = r5.g(r6)
            if (r7 != r0) goto L_0x0048
            goto L_0x005e
        L_0x0048:
            r7 = r2
            goto L_0x005e
        L_0x004a:
            a2.p0 r7 = a2.p0.f404a
            boolean r7 = v7.r0.b(r1, r7)
            if (r7 == 0) goto L_0x0059
            java.lang.Object r7 = r5.g(r6)
            if (r7 != r0) goto L_0x0048
            goto L_0x005e
        L_0x0059:
            boolean r7 = r1 instanceof a2.k
            if (r7 != 0) goto L_0x0061
        L_0x005d:
            goto L_0x0048
        L_0x005e:
            if (r7 != r0) goto L_0x007c
            return r0
        L_0x0061:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "Can't read in final state."
            java.lang.String r0 = r0.toString()
            r7.<init>(r0)
            throw r7
        L_0x006d:
            boolean r1 = r7 instanceof a2.q
            if (r1 == 0) goto L_0x007c
            a2.q r7 = (a2.q) r7
            r6.f413e = r3
            java.lang.Object r7 = a2.n0.c(r5, r7, r6)
            if (r7 != r0) goto L_0x007c
            return r0
        L_0x007c:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.v.p(java.lang.Object):java.lang.Object");
    }
}
