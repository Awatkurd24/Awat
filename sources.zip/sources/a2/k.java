package a2;

import v7.r0;

public final class k extends o0 {

    /* renamed from: a  reason: collision with root package name */
    public final Throwable f367a;

    public k(Throwable th2) {
        r0.j("finalException", th2);
        this.f367a = th2;
    }
}
