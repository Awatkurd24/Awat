package a2;

public interface b {
    Object b(a aVar);
}
