package a2;

import android.animation.ValueAnimator;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;
import androidx.cardview.widget.CardView;
import bg.d;
import com.v2ray.ang.service.ServiceControl;
import com.v2ray.ang.service.V2RayServiceManager;
import f3.e;
import g3.g;
import java.lang.ref.SoftReference;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import jf.b;
import kg.q;
import kg.u;
import l4.f;
import lg.b0;
import lg.c;
import lg.g1;
import lg.l0;
import lg.q1;
import lg.t1;
import libv2ray.V2RayVPNServiceSupportsSet;
import n5.a;
import v7.r0;
import we.a1;

public class h implements b, V2RayVPNServiceSupportsSet, e, f, a {

    /* renamed from: a  reason: collision with root package name */
    public static h f351a;

    public h(u uVar) {
        r0.j("storageManager", uVar);
        String str = q.f21467d;
        new ConcurrentHashMap(3, 1.0f, 2);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: he.v} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v2, resolved type: he.v} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: he.v} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v5, resolved type: he.v} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0097  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Object c(a2.h r5, java.util.List r6, a2.f0 r7, zd.e r8) {
        /*
            r5.getClass()
            boolean r0 = r8 instanceof a2.e
            if (r0 == 0) goto L_0x0016
            r0 = r8
            a2.e r0 = (a2.e) r0
            int r1 = r0.f327h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0016
            int r1 = r1 - r2
            r0.f327h = r1
            goto L_0x001b
        L_0x0016:
            a2.e r0 = new a2.e
            r0.<init>(r5, r8)
        L_0x001b:
            java.lang.Object r5 = r0.f325f
            ae.a r8 = ae.a.f795a
            int r1 = r0.f327h
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L_0x0045
            if (r1 == r3) goto L_0x003d
            if (r1 != r2) goto L_0x0035
            java.util.Iterator r6 = r0.f324e
            java.io.Serializable r7 = r0.f323d
            he.v r7 = (he.v) r7
            v7.r0.C(r5)     // Catch:{ all -> 0x0033 }
            goto L_0x006b
        L_0x0033:
            r5 = move-exception
            goto L_0x0084
        L_0x0035:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L_0x003d:
            java.io.Serializable r6 = r0.f323d
            java.util.List r6 = (java.util.List) r6
            v7.r0.C(r5)
            goto L_0x005f
        L_0x0045:
            v7.r0.C(r5)
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            a2.g r1 = new a2.g
            r4 = 0
            r1.<init>(r6, r5, r4)
            r0.f323d = r5
            r0.f327h = r3
            java.lang.Object r6 = r7.a(r1, r0)
            if (r6 != r8) goto L_0x005e
            goto L_0x0099
        L_0x005e:
            r6 = r5
        L_0x005f:
            he.v r5 = new he.v
            r5.<init>()
            java.lang.Iterable r6 = (java.lang.Iterable) r6
            java.util.Iterator r6 = r6.iterator()
            r7 = r5
        L_0x006b:
            boolean r5 = r6.hasNext()
            if (r5 == 0) goto L_0x0091
            java.lang.Object r5 = r6.next()
            ge.b r5 = (ge.b) r5
            r0.f323d = r7     // Catch:{ all -> 0x0033 }
            r0.f324e = r6     // Catch:{ all -> 0x0033 }
            r0.f327h = r2     // Catch:{ all -> 0x0033 }
            java.lang.Object r5 = r5.h(r0)     // Catch:{ all -> 0x0033 }
            if (r5 != r8) goto L_0x006b
            goto L_0x0099
        L_0x0084:
            java.lang.Object r1 = r7.f19690a
            if (r1 != 0) goto L_0x008b
            r7.f19690a = r5
            goto L_0x006b
        L_0x008b:
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            v7.g9.b(r1, r5)
            goto L_0x006b
        L_0x0091:
            java.lang.Object r5 = r7.f19690a
            java.lang.Throwable r5 = (java.lang.Throwable) r5
            if (r5 != 0) goto L_0x009a
            wd.m r8 = wd.m.f29306a
        L_0x0099:
            return r8
        L_0x009a:
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.h.c(a2.h, java.util.List, a2.f0, zd.e):java.lang.Object");
    }

    public static l0 e(a1 a1Var, c cVar, g1 g1Var, b0 b0Var) {
        r0.j("typeAttr", cVar);
        r0.j("typeParameterUpperBoundEraser", g1Var);
        r0.j("erasedUpperBound", b0Var);
        if (!(cVar instanceof jf.a)) {
            return new l0(b0Var, t1.OUT_VARIANCE);
        }
        jf.a aVar = (jf.a) cVar;
        if (!aVar.f20909c) {
            aVar = aVar.g(b.f20913a);
        }
        int ordinal = aVar.f20908b.ordinal();
        if (ordinal == 0 || ordinal == 1) {
            if (!a1Var.d0().f22122b) {
                return new l0(d.e(a1Var).n(), t1.INVARIANT);
            }
            List r4 = b0Var.K0().r();
            r0.i("getParameters(...)", r4);
            if (!r4.isEmpty()) {
                return new l0(b0Var, t1.OUT_VARIANCE);
            }
            return q1.l(a1Var, aVar);
        } else if (ordinal == 2) {
            return new l0(b0Var, t1.INVARIANT);
        } else {
            throw new RuntimeException();
        }
    }

    public f3.f a(f3.d dVar) {
        return new g(dVar.f18431a, dVar.f18432b, dVar.f18433c, dVar.f18434d, dVar.f18435e);
    }

    public Object b(a aVar) {
        throw aVar;
    }

    public float d(float f10, float f11) {
        return 1.0f;
    }

    public void f(float f10, wb.a aVar) {
        r0.a aVar2 = (r0.a) ((Drawable) aVar.f29275b);
        boolean useCompatPadding = ((CardView) aVar.f29276c).getUseCompatPadding();
        boolean i10 = aVar.i();
        if (!(f10 == aVar2.f25146e && aVar2.f25147f == useCompatPadding && aVar2.f25148g == i10)) {
            aVar2.f25146e = f10;
            aVar2.f25147f = useCompatPadding;
            aVar2.f25148g = i10;
            aVar2.b((Rect) null);
            aVar2.invalidateSelf();
        }
        if (!((CardView) aVar.f29276c).getUseCompatPadding()) {
            aVar.q(0, 0, 0, 0);
            return;
        }
        r0.a aVar3 = (r0.a) ((Drawable) aVar.f29275b);
        float f11 = aVar3.f25146e;
        float f12 = aVar3.f25142a;
        int ceil = (int) Math.ceil((double) r0.b.a(f11, f12, aVar.i()));
        int ceil2 = (int) Math.ceil((double) r0.b.b(f11, f12, aVar.i()));
        aVar.q(ceil, ceil2, ceil, ceil2);
    }

    public void onAdDismissed() {
    }

    public long onEmitStatus(long j3, String str) {
        return 0;
    }

    public void onFail(Object obj) {
    }

    public void onLoad() {
    }

    public void onUserEarnedReward(y6.b bVar) {
    }

    public long prepare() {
        return 0;
    }

    public boolean protect(long j3) {
        ServiceControl serviceControl;
        SoftReference<ServiceControl> serviceControl2 = V2RayServiceManager.INSTANCE.getServiceControl();
        if (serviceControl2 == null || (serviceControl = serviceControl2.get()) == null) {
            return true;
        }
        return serviceControl.vpnProtect((int) j3);
    }

    public long setup(String str) {
        ServiceControl serviceControl;
        r0.j("s", str);
        V2RayServiceManager v2RayServiceManager = V2RayServiceManager.INSTANCE;
        SoftReference<ServiceControl> serviceControl2 = v2RayServiceManager.getServiceControl();
        if (serviceControl2 == null || (serviceControl = serviceControl2.get()) == null) {
            return -1;
        }
        try {
            serviceControl.startService();
            V2RayServiceManager.lastQueryTime = System.currentTimeMillis();
            v2RayServiceManager.startSpeedNotification();
            return 0;
        } catch (Exception e10) {
            Log.d("co.vpn.plusvpn", e10.toString());
            return -1;
        }
    }

    public long shutdown() {
        ServiceControl serviceControl;
        SoftReference<ServiceControl> serviceControl2 = V2RayServiceManager.INSTANCE.getServiceControl();
        if (serviceControl2 == null || (serviceControl = serviceControl2.get()) == null) {
            return -1;
        }
        try {
            serviceControl.stopService();
            return 0;
        } catch (Exception e10) {
            Log.d("co.vpn.plusvpn", e10.toString());
            return -1;
        }
    }

    public h(int[] iArr, ValueAnimator valueAnimator) {
    }
}
