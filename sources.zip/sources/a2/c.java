package a2;

public final class c extends o0 {

    /* renamed from: a  reason: collision with root package name */
    public final Object f303a;

    /* renamed from: b  reason: collision with root package name */
    public final int f304b;

    public c(int i10, Object obj) {
        this.f303a = obj;
        this.f304b = i10;
    }

    public final void a() {
        boolean z4 = false;
        Object obj = this.f303a;
        if ((obj != null ? obj.hashCode() : 0) == this.f304b) {
            z4 = true;
        }
        if (!z4) {
            throw new IllegalStateException("Data in DataStore was mutated but DataStore is only compatible with Immutable types.".toString());
        }
    }
}
