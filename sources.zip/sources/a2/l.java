package a2;

public final class l extends o0 {

    /* renamed from: a  reason: collision with root package name */
    public final Throwable f374a;

    public l(Throwable th2) {
        this.f374a = th2;
    }
}
