package a0;

import com.google.android.gms.internal.measurement.p4;
import f.c;
import q1.a;
import v7.je;
import w7.ua;
import z.t0;

public final /* synthetic */ class j implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f54a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p4 f55b;

    public /* synthetic */ j(int i10, p4 p4Var) {
        this.f54a = i10;
        this.f55b = p4Var;
    }

    public final void accept(Object obj) {
        int i10 = this.f54a;
        p4 p4Var = this.f55b;
        switch (i10) {
            case 0:
                p4Var.getClass();
                je.a();
                c.w(p4Var.f15159b);
                ua.g((String) null, false);
                ((t0) obj).l().a();
                c.w(p4Var.f15159b);
                throw null;
            default:
                c.w(obj);
                p4Var.getClass();
                je.a();
                throw null;
        }
    }
}
