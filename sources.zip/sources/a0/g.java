package a0;

import a4.w;
import android.media.ImageReader;
import android.util.Size;
import android.view.Surface;
import b0.a0;
import b0.l0;
import b0.q0;
import b0.x0;
import b0.z;
import co.dev.ui.d;
import com.google.android.gms.internal.measurement.p4;
import d0.h;
import f.c;
import g0.b;
import g0.e;
import j0.k;
import java.util.Objects;
import java.util.concurrent.Executor;
import q.f;
import t.f1;
import t.o2;
import v7.je;
import v7.ke;
import w7.ua;
import z.e1;
import z.l1;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final l0 f36a;

    /* renamed from: b  reason: collision with root package name */
    public final f f37b;

    /* renamed from: c  reason: collision with root package name */
    public final p4 f38c;

    /* renamed from: d  reason: collision with root package name */
    public final i f39d;

    /* renamed from: e  reason: collision with root package name */
    public final a f40e;

    /* JADX WARNING: type inference failed for: r6v0, types: [a0.i, java.lang.Object] */
    public g(l0 l0Var, Size size, boolean z4) {
        int i10;
        boolean z10;
        Object obj;
        q0 q0Var;
        boolean z11;
        l0 l0Var2 = l0Var;
        je.a();
        this.f36a = l0Var2;
        a0 a10 = l0Var.a();
        if (a10 != null) {
            z zVar = new z();
            a10.a(l0Var2, zVar);
            zVar.d();
            f fVar = new f(1);
            this.f37b = fVar;
            p4 p4Var = new p4(4);
            this.f38c = p4Var;
            d0.f m10 = ua.m();
            Executor executor = (Executor) ((x0) l0Var.z()).m(f0.g.I0, m10);
            Objects.requireNonNull(executor);
            ? obj2 = new Object();
            if (b.f18946a.f(e.class) != null) {
                obj2.f43a = new h(executor);
            } else {
                obj2.f43a = executor;
            }
            obj2.f44b = null;
            this.f39d = obj2;
            int C = l0Var.C();
            Integer num = (Integer) ((x0) l0Var.z()).m(l0.f3400d, (Object) null);
            if (num != null) {
                i10 = num.intValue();
            } else {
                i10 = 256;
            }
            c.w(((x0) l0Var.z()).m(l0.f3401e, (Object) null));
            k kVar = new k();
            k kVar2 = new k();
            k kVar3 = kVar;
            int i11 = i10;
            a aVar = new a(size, C, i10, z4, kVar, kVar2);
            this.f40e = aVar;
            if (((a) fVar.f24805f) == null && ((e1) fVar.f24803d) == null) {
                z10 = true;
            } else {
                z10 = false;
            }
            ua.g("CaptureNode does not support recreation yet.", z10);
            fVar.f24805f = aVar;
            if (!z4) {
                q0Var = new z.x0(size.getWidth(), size.getHeight(), C, 4);
                obj = new e(fVar, 0);
            } else {
                q0Var = new a4.e(new f1(ImageReader.newInstance(size.getWidth(), size.getHeight(), C, 4)));
                obj = new f(fVar, 0, q0Var);
            }
            Surface a11 = q0Var.a();
            Objects.requireNonNull(a11);
            if (aVar.f17a == null) {
                z11 = true;
            } else {
                z11 = false;
            }
            ua.g("The surface is already set.", z11);
            aVar.f17a = new l1(a11, size, C);
            fVar.f24803d = new e1(q0Var);
            q0Var.g(new d(2, fVar), ua.n());
            kVar3.f20496b = obj;
            kVar2.f20496b = new e(fVar, 1);
            k kVar4 = new k();
            k kVar5 = new k();
            fVar.f24804e = new b(kVar4, kVar5, C, i11);
            kVar4.f20496b = new j(0, p4Var);
            kVar5.f20496b = new j(1, p4Var);
            k kVar6 = new k();
            c cVar = new c(kVar6, C, i11);
            p4Var.f15160c = cVar;
            obj2.f45c = cVar;
            kVar6.f20496b = new h(0, obj2);
            obj2.f46d = new u7.a0(4);
            obj2.f47e = new u7.a0(3);
            obj2.f50h = new ke(3, (Object) null);
            obj2.f48f = new ab.d(2);
            obj2.f49g = new Object();
            obj2.f51i = new ab.d(3);
            if (C == 35 || ((w) obj2.f44b) != null) {
                obj2.f52j = new f9.f(3);
            }
            w wVar = (w) obj2.f44b;
            if (wVar != null) {
                obj2.f53k = new yb.b(7, wVar);
                return;
            }
            return;
        }
        throw new IllegalStateException("Implementation is missing option unpacker for " + c.b(l0Var2, l0Var.toString()));
    }

    public final void a() {
        je.a();
        f fVar = this.f37b;
        fVar.getClass();
        je.a();
        a aVar = (a) fVar.f24805f;
        Objects.requireNonNull(aVar);
        e1 e1Var = (e1) fVar.f24803d;
        Objects.requireNonNull(e1Var);
        l1 l1Var = aVar.f17a;
        Objects.requireNonNull(l1Var);
        l1Var.a();
        l1 l1Var2 = aVar.f17a;
        Objects.requireNonNull(l1Var2);
        e0.f.e(l1Var2.f3340e).a(new o2(e1Var, 2), ua.n());
        this.f38c.getClass();
        this.f39d.getClass();
    }
}
