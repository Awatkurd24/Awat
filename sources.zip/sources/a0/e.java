package a0;

import f.c;
import q.f;
import q1.a;
import v7.je;
import z.p0;

public final /* synthetic */ class e implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f31a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ f f32b;

    public /* synthetic */ e(f fVar, int i10) {
        this.f31a = i10;
        this.f32b = fVar;
    }

    public final void accept(Object obj) {
        int i10 = this.f31a;
        f fVar = this.f32b;
        switch (i10) {
            case 0:
                c.w(obj);
                fVar.r();
                throw null;
            default:
                p0 p0Var = (p0) obj;
                fVar.getClass();
                je.a();
                c.w(fVar.f24802c);
                return;
        }
    }
}
