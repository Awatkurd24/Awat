package a0;

import j0.k;
import t.u;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final k f24a;

    /* renamed from: b  reason: collision with root package name */
    public final k f25b;

    /* renamed from: c  reason: collision with root package name */
    public final int f26c;

    /* renamed from: d  reason: collision with root package name */
    public final int f27d;

    public b(k kVar, k kVar2, int i10, int i11) {
        this.f24a = kVar;
        this.f25b = kVar2;
        this.f26c = i10;
        this.f27d = i11;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (!this.f24a.equals(bVar.f24a) || !this.f25b.equals(bVar.f25b) || this.f26c != bVar.f26c || this.f27d != bVar.f27d) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return ((((((this.f24a.hashCode() ^ 1000003) * 1000003) ^ this.f25b.hashCode()) * 1000003) ^ this.f26c) * 1000003) ^ this.f27d;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Out{imageEdge=");
        sb2.append(this.f24a);
        sb2.append(", requestEdge=");
        sb2.append(this.f25b);
        sb2.append(", inputFormat=");
        sb2.append(this.f26c);
        sb2.append(", outputFormat=");
        return u.e(sb2, this.f27d, "}");
    }
}
