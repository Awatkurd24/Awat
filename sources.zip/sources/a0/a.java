package a0;

import android.util.Size;
import j0.k;
import z.l1;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public l1 f17a;

    /* renamed from: b  reason: collision with root package name */
    public final Size f18b;

    /* renamed from: c  reason: collision with root package name */
    public final int f19c;

    /* renamed from: d  reason: collision with root package name */
    public final int f20d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f21e;

    /* renamed from: f  reason: collision with root package name */
    public final k f22f;

    /* renamed from: g  reason: collision with root package name */
    public final k f23g;

    public a(Size size, int i10, int i11, boolean z4, k kVar, k kVar2) {
        if (size != null) {
            this.f18b = size;
            this.f19c = i10;
            this.f20d = i11;
            this.f21e = z4;
            this.f22f = kVar;
            this.f23g = kVar2;
            return;
        }
        throw new NullPointerException("Null size");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (!this.f18b.equals(aVar.f18b) || this.f19c != aVar.f19c || this.f20d != aVar.f20d || this.f21e != aVar.f21e || !this.f22f.equals(aVar.f22f) || !this.f23g.equals(aVar.f23g)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return ((((((((((this.f18b.hashCode() ^ 1000003) * 1000003) ^ this.f19c) * 1000003) ^ this.f20d) * 1000003) ^ (this.f21e ? 1231 : 1237)) * -721379959) ^ this.f22f.hashCode()) * 1000003) ^ this.f23g.hashCode();
    }

    public final String toString() {
        return "In{size=" + this.f18b + ", inputFormat=" + this.f19c + ", outputFormat=" + this.f20d + ", virtualCamera=" + this.f21e + ", imageReaderProxyProvider=null, requestEdge=" + this.f22f + ", errorEdge=" + this.f23g + "}";
    }
}
