package a0;

import android.util.Log;
import ha.c;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import v7.je;
import w7.ua;
import z.t0;
import z.x;

public final class l implements x {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayDeque f58a = new ArrayDeque();

    /* renamed from: b  reason: collision with root package name */
    public final c f59b;

    /* renamed from: c  reason: collision with root package name */
    public g f60c;

    /* renamed from: d  reason: collision with root package name */
    public final ArrayList f61d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f62e = false;

    public l(c cVar) {
        je.a();
        this.f59b = cVar;
        this.f61d = new ArrayList();
    }

    public final void a() {
        je.a();
        new Exception("Camera is closed.", (Throwable) null);
        ArrayDeque arrayDeque = this.f58a;
        Iterator it = arrayDeque.iterator();
        if (!it.hasNext()) {
            arrayDeque.clear();
            Iterator it2 = new ArrayList(this.f61d).iterator();
            if (it2.hasNext()) {
                f.c.w(it2.next());
                throw null;
            }
            return;
        }
        f.c.w(it.next());
        throw null;
    }

    public final void b() {
        je.a();
        Log.d("TakePictureManager", "Issue the next TakePictureRequest.");
        if (this.f62e) {
            Log.d("TakePictureManager", "The class is paused.");
            return;
        }
        g gVar = this.f60c;
        gVar.getClass();
        je.a();
        if (gVar.f37b.j() == 0) {
            Log.d("TakePictureManager", "Too many acquire images. Close image to be able to process next.");
            return;
        }
        f.c.w(this.f58a.poll());
        Log.d("TakePictureManager", "No new request.");
    }

    public final void d(t0 t0Var) {
        ua.n().execute(new k(this, 1));
    }
}
