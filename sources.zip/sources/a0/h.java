package a0;

import ah.g;
import androidx.window.layout.k0;
import q1.a;
import v7.r0;

public final /* synthetic */ class h implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f41a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f42b;

    public /* synthetic */ h(int i10, Object obj) {
        this.f41a = i10;
        this.f42b = obj;
    }

    public final void accept(Object obj) {
        int i10 = this.f41a;
        Object obj2 = this.f42b;
        switch (i10) {
            case 0:
                ((i) obj2).getClass();
                ((d) obj).getClass();
                throw null;
            default:
                k0 k0Var = (k0) obj;
                r0.i("info", k0Var);
                ((g) obj2).a(k0Var);
                return;
        }
    }
}
