package a0;

import a4.l;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.internal.ads.e6;
import com.google.android.gms.internal.ads.l5;
import com.google.android.gms.internal.ads.p5;
import com.google.android.gms.internal.ads.q5;
import com.google.android.gms.internal.ads.si0;
import com.google.android.gms.internal.ads.t5;
import com.google.android.gms.internal.ads.wu;
import f.c;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import na.b0;
import na.d2;
import na.g1;
import na.j1;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public Object f43a = new AtomicInteger();

    /* renamed from: b  reason: collision with root package name */
    public Object f44b = new HashSet();

    /* renamed from: c  reason: collision with root package name */
    public Object f45c = new PriorityBlockingQueue();

    /* renamed from: d  reason: collision with root package name */
    public Object f46d = new PriorityBlockingQueue();

    /* renamed from: e  reason: collision with root package name */
    public Object f47e;

    /* renamed from: f  reason: collision with root package name */
    public Object f48f;

    /* renamed from: g  reason: collision with root package name */
    public Object f49g;

    /* renamed from: h  reason: collision with root package name */
    public Object f50h;

    /* renamed from: i  reason: collision with root package name */
    public Object f51i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    public Object f52j = new ArrayList();

    /* renamed from: k  reason: collision with root package name */
    public Object f53k;

    public i(e6 e6Var, wu wuVar) {
        si0 si0 = new si0(new Handler(Looper.getMainLooper()));
        this.f47e = e6Var;
        this.f48f = wuVar;
        this.f49g = new q5[4];
        this.f53k = si0;
    }

    public final b0 a() {
        String str;
        if (((String) this.f43a) == null) {
            str = " sdkVersion";
        } else {
            str = "";
        }
        if (((String) this.f44b) == null) {
            str = str.concat(" gmpAppId");
        }
        if (((Integer) this.f45c) == null) {
            str = l.H(str, " platform");
        }
        if (((String) this.f46d) == null) {
            str = l.H(str, " installationUuid");
        }
        if (((String) this.f49g) == null) {
            str = l.H(str, " buildVersion");
        }
        if (((String) this.f50h) == null) {
            str = l.H(str, " displayVersion");
        }
        if (str.isEmpty()) {
            return new b0((String) this.f43a, (String) this.f44b, ((Integer) this.f45c).intValue(), (String) this.f46d, (String) this.f47e, (String) this.f48f, (String) this.f49g, (String) this.f50h, (d2) this.f51i, (j1) this.f52j, (g1) this.f53k);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final void b(t5 t5Var) {
        t5Var.f12470h = this;
        synchronized (((Set) this.f44b)) {
            ((Set) this.f44b).add(t5Var);
        }
        t5Var.f12469g = Integer.valueOf(((AtomicInteger) this.f43a).incrementAndGet());
        t5Var.d("add-to-queue");
        c();
        ((PriorityBlockingQueue) this.f45c).add(t5Var);
    }

    public final void c() {
        synchronized (((List) this.f52j)) {
            try {
                Iterator it = ((List) this.f52j).iterator();
                if (it.hasNext()) {
                    c.w(it.next());
                    throw null;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void d() {
        l5 l5Var = (l5) this.f50h;
        if (l5Var != null) {
            l5Var.f9886d = true;
            l5Var.interrupt();
        }
        q5[] q5VarArr = (q5[]) this.f49g;
        for (int i10 = 0; i10 < 4; i10++) {
            q5 q5Var = q5VarArr[i10];
            if (q5Var != null) {
                q5Var.f11468d = true;
                q5Var.interrupt();
            }
        }
        l5 l5Var2 = new l5((PriorityBlockingQueue) this.f45c, (PriorityBlockingQueue) this.f46d, (e6) this.f47e, (si0) this.f53k);
        this.f50h = l5Var2;
        l5Var2.start();
        for (int i11 = 0; i11 < 4; i11++) {
            q5 q5Var2 = new q5((PriorityBlockingQueue) this.f46d, (p5) this.f48f, (e6) this.f47e, (si0) this.f53k);
            ((q5[]) this.f49g)[i11] = q5Var2;
            q5Var2.start();
        }
    }
}
