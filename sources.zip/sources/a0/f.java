package a0;

import android.graphics.SurfaceTexture;
import android.view.Surface;
import f.c;
import j0.j;
import j0.l;
import j0.s;
import q1.a;
import z.g1;
import z.h;
import z.i;

public final /* synthetic */ class f implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f33a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f34b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f35c;

    public /* synthetic */ f(Object obj, int i10, Object obj2) {
        this.f33a = i10;
        this.f34b = obj;
        this.f35c = obj2;
    }

    public final void accept(Object obj) {
        int i10 = this.f33a;
        Object obj2 = this.f35c;
        Object obj3 = this.f34b;
        switch (i10) {
            case 0:
                c.w(obj);
                ((q.f) obj3).r();
                throw null;
            case 1:
                i iVar = (i) obj;
                ((Surface) obj3).release();
                ((SurfaceTexture) obj2).release();
                return;
            default:
                j jVar = (j) obj3;
                h hVar = (h) obj;
                jVar.getClass();
                s sVar = (s) ((g1) obj2);
                sVar.close();
                Surface surface = (Surface) jVar.f20491h.remove(sVar);
                if (surface != null) {
                    l lVar = jVar.f20484a;
                    lVar.d(true);
                    lVar.c();
                    lVar.r(surface, true);
                    return;
                }
                return;
        }
    }
}
