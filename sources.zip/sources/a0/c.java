package a0;

import j0.k;
import t.u;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final k f28a;

    /* renamed from: b  reason: collision with root package name */
    public final int f29b;

    /* renamed from: c  reason: collision with root package name */
    public final int f30c;

    public c(k kVar, int i10, int i11) {
        this.f28a = kVar;
        this.f29b = i10;
        this.f30c = i11;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        if (this.f28a.equals(cVar.f28a) && this.f29b == cVar.f29b && this.f30c == cVar.f30c) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.f28a.hashCode() ^ 1000003) * 1000003) ^ this.f29b) * 1000003) ^ this.f30c;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("In{edge=");
        sb2.append(this.f28a);
        sb2.append(", inputFormat=");
        sb2.append(this.f29b);
        sb2.append(", outputFormat=");
        return u.e(sb2, this.f30c, "}");
    }
}
