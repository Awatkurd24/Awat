package a0;

public final /* synthetic */ class k implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f56a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ l f57b;

    public /* synthetic */ k(l lVar, int i10) {
        this.f56a = i10;
        this.f57b = lVar;
    }

    public final void run() {
        int i10 = this.f56a;
        l lVar = this.f57b;
        switch (i10) {
            case 0:
                lVar.b();
                return;
            default:
                lVar.b();
                return;
        }
    }
}
