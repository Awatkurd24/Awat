package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

public class MediaBrowserCompat$MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaBrowserCompat$MediaItem> CREATOR = new a(0);

    /* renamed from: a  reason: collision with root package name */
    public final int f856a;

    /* renamed from: b  reason: collision with root package name */
    public final MediaDescriptionCompat f857b;

    public MediaBrowserCompat$MediaItem(Parcel parcel) {
        this.f856a = parcel.readInt();
        this.f857b = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "MediaItem{mFlags=" + this.f856a + ", mDescription=" + this.f857b + '}';
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f856a);
        this.f857b.writeToParcel(parcel, i10);
    }
}
