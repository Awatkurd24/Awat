package android.support.v4.media;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.appcompat.widget.x;
import co.vpn.plusvpn.R;
import com.google.android.gms.internal.ads.cr;
import com.google.android.gms.internal.ads.pt0;
import com.google.android.gms.internal.ads.qt0;
import com.google.android.gms.internal.ads.si0;
import com.google.android.gms.internal.ads.ut0;
import com.google.android.gms.internal.ads.wm0;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import com.google.android.material.datepicker.l;
import d8.r;
import e8.a;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import n1.j;
import p6.o;
import t7.c0;
import t7.t0;
import v7.i9;

public final class b implements c0 {

    /* renamed from: a  reason: collision with root package name */
    public Object f871a;

    /* renamed from: b  reason: collision with root package name */
    public Object f872b;

    /* renamed from: c  reason: collision with root package name */
    public Object f873c;

    /* renamed from: d  reason: collision with root package name */
    public Object f874d;

    /* renamed from: e  reason: collision with root package name */
    public Object f875e;

    /* renamed from: f  reason: collision with root package name */
    public Object f876f;

    /* renamed from: g  reason: collision with root package name */
    public Object f877g;

    /* renamed from: h  reason: collision with root package name */
    public Object f878h;

    public b(Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(b0.L1(context, R.attr.materialCalendarStyle, l.class.getCanonicalName()).data, a.B);
        this.f871a = x.b(context, obtainStyledAttributes.getResourceId(4, 0));
        this.f877g = x.b(context, obtainStyledAttributes.getResourceId(2, 0));
        this.f872b = x.b(context, obtainStyledAttributes.getResourceId(3, 0));
        this.f873c = x.b(context, obtainStyledAttributes.getResourceId(5, 0));
        ColorStateList r4 = i9.r(context, obtainStyledAttributes, 7);
        this.f874d = x.b(context, obtainStyledAttributes.getResourceId(9, 0));
        this.f875e = x.b(context, obtainStyledAttributes.getResourceId(8, 0));
        this.f876f = x.b(context, obtainStyledAttributes.getResourceId(10, 0));
        Paint paint = new Paint();
        this.f878h = paint;
        paint.setColor(r4.getDefaultColor());
        obtainStyledAttributes.recycle();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, android.support.v4.media.b] */
    /* JADX WARNING: type inference failed for: r1v0, types: [com.google.android.gms.internal.ads.xt0, java.lang.Object] */
    public static b d(Context context, ExecutorService executorService, pt0 pt0, qt0 qt0) {
        r m02;
        ? obj = new Object();
        Object obj2 = new Object();
        ? obj3 = new Object();
        obj3.f871a = context;
        obj3.f872b = executorService;
        obj3.f873c = pt0;
        obj3.f874d = qt0;
        obj3.f875e = obj;
        obj3.f876f = obj2;
        if (qt0.f11652b) {
            m02 = b0.q(new ut0(obj3, 0), executorService);
            m02.b((Executor) obj3.f872b, new wm0(25, obj3));
        } else {
            m02 = b0.m0(obj.a());
        }
        obj3.f877g = m02;
        r q10 = b0.q(new ut0(obj3, 1), (Executor) obj3.f872b);
        q10.b((Executor) obj3.f872b, new wm0(25, obj3));
        obj3.f878h = q10;
        return obj3;
    }

    public static void g(Context context, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("action", "no_ads_fallback");
        bundle.putString("flow", str);
        o oVar = o.f24008f;
        cr crVar = oVar.f24009a;
        String str2 = oVar.f24012d.f14761a;
        crVar.getClass();
        cr.l(context, str2, bundle, new si0(5, (Object) crVar));
    }

    public final Executor a() {
        Handler handler = (Handler) this.f873c;
        Objects.requireNonNull(handler);
        return new j(1, handler);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(java.lang.String r7, org.json.JSONObject r8) {
        /*
            r6 = this;
            int r0 = r7.hashCode()
            r1 = -1
            r2 = 0
            r3 = 2
            r4 = 3
            r5 = 1
            switch(r0) {
                case -1370505102: goto L_0x002b;
                case -278739366: goto L_0x0021;
                case 150940456: goto L_0x0017;
                case 1671672458: goto L_0x000d;
                default: goto L_0x000c;
            }
        L_0x000c:
            goto L_0x0035
        L_0x000d:
            java.lang.String r0 = "dismiss"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0035
            r7 = 1
            goto L_0x0036
        L_0x0017:
            java.lang.String r0 = "browser"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0035
            r7 = 2
            goto L_0x0036
        L_0x0021:
            java.lang.String r0 = "configure_app_assets"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0035
            r7 = 3
            goto L_0x0036
        L_0x002b:
            java.lang.String r0 = "load_complete"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0035
            r7 = 0
            goto L_0x0036
        L_0x0035:
            r7 = -1
        L_0x0036:
            r0 = 0
            if (r7 == 0) goto L_0x0123
            if (r7 == r5) goto L_0x0095
            if (r7 == r3) goto L_0x004d
            if (r7 == r4) goto L_0x0040
            return r2
        L_0x0040:
            t7.n r7 = new t7.n
            r7.<init>(r6, r5)
            java.lang.Object r8 = r6.f874d
            java.util.concurrent.Executor r8 = (java.util.concurrent.Executor) r8
            r8.execute(r7)
            return r5
        L_0x004d:
            java.lang.String r7 = "url"
            java.lang.String r7 = r8.optString(r7)
            boolean r8 = android.text.TextUtils.isEmpty(r7)
            java.lang.String r0 = "UserMessagingPlatform"
            if (r8 == 0) goto L_0x0060
            java.lang.String r8 = "Action[browser]: empty url."
            android.util.Log.d(r0, r8)
        L_0x0060:
            android.net.Uri r8 = android.net.Uri.parse(r7)
            java.lang.String r1 = r8.getScheme()
            if (r1 != 0) goto L_0x0077
            java.lang.String r1 = java.lang.String.valueOf(r7)
            java.lang.String r2 = "Action[browser]: empty scheme: "
            java.lang.String r1 = r2.concat(r1)
            android.util.Log.d(r0, r1)
        L_0x0077:
            android.content.Intent r1 = new android.content.Intent     // Catch:{ ActivityNotFoundException -> 0x0086 }
            java.lang.String r2 = "android.intent.action.VIEW"
            r1.<init>(r2, r8)     // Catch:{ ActivityNotFoundException -> 0x0086 }
            java.lang.Object r8 = r6.f872b     // Catch:{ ActivityNotFoundException -> 0x0086 }
            t7.q r8 = (t7.q) r8     // Catch:{ ActivityNotFoundException -> 0x0086 }
            r8.startActivity(r1)     // Catch:{ ActivityNotFoundException -> 0x0086 }
            goto L_0x0094
        L_0x0086:
            r8 = move-exception
            java.lang.String r7 = java.lang.String.valueOf(r7)
            java.lang.String r1 = "Action[browser]: can not open url: "
            java.lang.String r7 = r1.concat(r7)
            android.util.Log.d(r0, r7, r8)
        L_0x0094:
            return r5
        L_0x0095:
            java.lang.String r7 = "status"
            java.lang.String r7 = r8.optString(r7)
            r7.getClass()
            int r8 = r7.hashCode()
            switch(r8) {
                case -954325659: goto L_0x00d2;
                case -258041904: goto L_0x00c7;
                case 429411856: goto L_0x00bc;
                case 467888915: goto L_0x00b1;
                case 1666911234: goto L_0x00a6;
                default: goto L_0x00a5;
            }
        L_0x00a5:
            goto L_0x00dc
        L_0x00a6:
            java.lang.String r8 = "non_personalized"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00af
            goto L_0x00dc
        L_0x00af:
            r1 = 4
            goto L_0x00dc
        L_0x00b1:
            java.lang.String r8 = "CONSENT_SIGNAL_PERSONALIZED_ADS"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00ba
            goto L_0x00dc
        L_0x00ba:
            r1 = 3
            goto L_0x00dc
        L_0x00bc:
            java.lang.String r8 = "CONSENT_SIGNAL_SUFFICIENT"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00c5
            goto L_0x00dc
        L_0x00c5:
            r1 = 2
            goto L_0x00dc
        L_0x00c7:
            java.lang.String r8 = "personalized"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00d0
            goto L_0x00dc
        L_0x00d0:
            r1 = 1
            goto L_0x00dc
        L_0x00d2:
            java.lang.String r8 = "CONSENT_SIGNAL_NON_PERSONALIZED_ADS"
            boolean r7 = r7.equals(r8)
            if (r7 != 0) goto L_0x00db
            goto L_0x00dc
        L_0x00db:
            r1 = 0
        L_0x00dc:
            java.lang.Object r7 = r6.f877g
            t7.h r7 = (t7.h) r7
            switch(r1) {
                case 0: goto L_0x0100;
                case 1: goto L_0x0100;
                case 2: goto L_0x0100;
                case 3: goto L_0x0100;
                case 4: goto L_0x0100;
                default: goto L_0x00e3;
            }
        L_0x00e3:
            t7.u0 r8 = new t7.u0
            java.lang.String r1 = "We are getting something wrong with the webview."
            r8.<init>(r5, r1)
            r7.b()
            java.util.concurrent.atomic.AtomicReference r7 = r7.f26587j
            java.lang.Object r7 = r7.getAndSet(r0)
            l4.b r7 = (l4.b) r7
            if (r7 != 0) goto L_0x00f8
            goto L_0x0122
        L_0x00f8:
            f7.n r8 = r8.a()
            r7.a(r8)
            goto L_0x0122
        L_0x0100:
            r7.b()
            java.util.concurrent.atomic.AtomicReference r8 = r7.f26587j
            java.lang.Object r8 = r8.getAndSet(r0)
            l4.b r8 = (l4.b) r8
            if (r8 != 0) goto L_0x010e
            goto L_0x0122
        L_0x010e:
            t7.e r7 = r7.f26580c
            android.content.SharedPreferences r7 = r7.f26567b
            android.content.SharedPreferences$Editor r7 = r7.edit()
            java.lang.String r1 = "consent_status"
            android.content.SharedPreferences$Editor r7 = r7.putInt(r1, r4)
            r7.apply()
            r8.a(r0)
        L_0x0122:
            return r5
        L_0x0123:
            java.lang.Object r7 = r6.f877g
            t7.h r7 = (t7.h) r7
            java.util.concurrent.atomic.AtomicReference r8 = r7.f26586i
            java.lang.Object r8 = r8.getAndSet(r0)
            t7.g r8 = (t7.g) r8
            if (r8 != 0) goto L_0x0132
            goto L_0x0135
        L_0x0132:
            r8.b(r7)
        L_0x0135:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.b.b(java.lang.String, org.json.JSONObject):boolean");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v26, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: com.google.android.gms.internal.ads.j7} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.util.Map c() {
        /*
            r9 = this;
            java.util.Map r0 = r9.e()
            java.lang.Object r1 = r9.f872b
            android.support.v4.media.b r1 = (android.support.v4.media.b) r1
            java.lang.Object r2 = r1.f875e
            com.google.android.gms.internal.ads.xt0 r2 = (com.google.android.gms.internal.ads.xt0) r2
            java.lang.Object r1 = r1.f877g
            d8.h r1 = (d8.h) r1
            com.google.android.gms.internal.ads.j7 r2 = r2.a()
            boolean r3 = r1.i()
            if (r3 != 0) goto L_0x001b
            goto L_0x0022
        L_0x001b:
            java.lang.Object r1 = r1.g()
            r2 = r1
            com.google.android.gms.internal.ads.j7 r2 = (com.google.android.gms.internal.ads.j7) r2
        L_0x0022:
            java.lang.Object r1 = r9.f871a
            com.google.android.gms.internal.ads.qt0 r1 = (com.google.android.gms.internal.ads.qt0) r1
            boolean r1 = r1.f11652b
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            java.lang.String r3 = "gai"
            r4 = r0
            java.util.HashMap r4 = (java.util.HashMap) r4
            r4.put(r3, r1)
            java.lang.String r1 = r2.s0()
            java.lang.String r3 = "did"
            r4.put(r3, r1)
            int r1 = r2.h0()
            int r1 = r1 + -1
            java.lang.String r3 = "dst"
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r4.put(r3, r1)
            boolean r1 = r2.e0()
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            java.lang.String r2 = "doo"
            r4.put(r2, r1)
            java.lang.Object r1 = r9.f875e
            com.google.android.gms.internal.ads.o8 r1 = (com.google.android.gms.internal.ads.o8) r1
            r2 = -1
            if (r1 == 0) goto L_0x00a3
            java.lang.Class<com.google.android.gms.internal.ads.o8> r5 = com.google.android.gms.internal.ads.o8.class
            monitor-enter(r5)
            java.lang.Object r6 = r1.f10839b     // Catch:{ all -> 0x0075 }
            android.net.NetworkCapabilities r6 = (android.net.NetworkCapabilities) r6     // Catch:{ all -> 0x0075 }
            if (r6 == 0) goto L_0x0095
            r7 = 4
            boolean r6 = r6.hasTransport(r7)     // Catch:{ all -> 0x0075 }
            if (r6 == 0) goto L_0x0077
            monitor-exit(r5)     // Catch:{ all -> 0x0075 }
            r5 = 2
            goto L_0x0097
        L_0x0075:
            r0 = move-exception
            goto L_0x00a1
        L_0x0077:
            java.lang.Object r6 = r1.f10839b     // Catch:{ all -> 0x0075 }
            android.net.NetworkCapabilities r6 = (android.net.NetworkCapabilities) r6     // Catch:{ all -> 0x0075 }
            r7 = 1
            boolean r6 = r6.hasTransport(r7)     // Catch:{ all -> 0x0075 }
            if (r6 == 0) goto L_0x0086
            monitor-exit(r5)     // Catch:{ all -> 0x0075 }
            r5 = 1
            goto L_0x0097
        L_0x0086:
            java.lang.Object r1 = r1.f10839b     // Catch:{ all -> 0x0075 }
            android.net.NetworkCapabilities r1 = (android.net.NetworkCapabilities) r1     // Catch:{ all -> 0x0075 }
            r6 = 0
            boolean r1 = r1.hasTransport(r6)     // Catch:{ all -> 0x0075 }
            if (r1 == 0) goto L_0x0095
            monitor-exit(r5)     // Catch:{ all -> 0x0075 }
            r5 = 0
            goto L_0x0097
        L_0x0095:
            monitor-exit(r5)     // Catch:{ all -> 0x0075 }
            r5 = r2
        L_0x0097:
            java.lang.Long r1 = java.lang.Long.valueOf(r5)
            java.lang.String r5 = "nt"
            r4.put(r5, r1)
            goto L_0x00a3
        L_0x00a1:
            monitor-exit(r5)     // Catch:{ all -> 0x0075 }
            throw r0
        L_0x00a3:
            java.lang.Object r1 = r9.f876f
            com.google.android.gms.internal.ads.d9 r1 = (com.google.android.gms.internal.ads.d9) r1
            if (r1 == 0) goto L_0x00ce
            boolean r5 = r1.f6971d
            if (r5 == 0) goto L_0x00b3
            long r5 = r1.f6969b
            long r7 = r1.f6968a
            long r5 = r5 - r7
            goto L_0x00b4
        L_0x00b3:
            r5 = r2
        L_0x00b4:
            java.lang.Long r1 = java.lang.Long.valueOf(r5)
            java.lang.String r5 = "vs"
            r4.put(r5, r1)
            java.lang.Object r1 = r9.f876f
            com.google.android.gms.internal.ads.d9 r1 = (com.google.android.gms.internal.ads.d9) r1
            long r5 = r1.f6970c
            r1.f6970c = r2
            java.lang.Long r1 = java.lang.Long.valueOf(r5)
            java.lang.String r2 = "vf"
            r4.put(r2, r1)
        L_0x00ce:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.b.c():java.util.Map");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v17, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: com.google.android.gms.internal.ads.j7} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.util.Map e() {
        /*
            r5 = this;
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            java.lang.Object r1 = r5.f871a
            com.google.android.gms.internal.ads.qt0 r1 = (com.google.android.gms.internal.ads.qt0) r1
            java.lang.Object r2 = r5.f872b
            android.support.v4.media.b r2 = (android.support.v4.media.b) r2
            java.lang.Object r3 = r2.f876f
            com.google.android.gms.internal.ads.xt0 r3 = (com.google.android.gms.internal.ads.xt0) r3
            java.lang.Object r2 = r2.f878h
            d8.h r2 = (d8.h) r2
            com.google.android.gms.internal.ads.j7 r3 = r3.a()
            boolean r4 = r2.i()
            if (r4 != 0) goto L_0x0020
            goto L_0x0027
        L_0x0020:
            java.lang.Object r2 = r2.g()
            r3 = r2
            com.google.android.gms.internal.ads.j7 r3 = (com.google.android.gms.internal.ads.j7) r3
        L_0x0027:
            java.lang.String r1 = r1.f11651a
            java.lang.String r2 = "v"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f871a
            com.google.android.gms.internal.ads.qt0 r1 = (com.google.android.gms.internal.ads.qt0) r1
            boolean r1 = r1.f11653c
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            java.lang.String r2 = "gms"
            r0.put(r2, r1)
            java.lang.String r1 = r3.t0()
            java.lang.String r2 = "int"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f874d
            com.google.android.gms.internal.ads.u8 r1 = (com.google.android.gms.internal.ads.u8) r1
            boolean r1 = r1.f12768a
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            java.lang.String r2 = "up"
            r0.put(r2, r1)
            java.lang.Throwable r1 = new java.lang.Throwable
            r1.<init>()
            java.lang.String r2 = "t"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            if (r1 == 0) goto L_0x00d9
            long r1 = r1.f12411b
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tcq"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12412c
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tpq"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12413d
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tcv"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12414e
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tpv"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12415f
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tchv"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12416g
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tphv"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12417h
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tcc"
            r0.put(r2, r1)
            java.lang.Object r1 = r5.f877g
            com.google.android.gms.internal.ads.t r1 = (com.google.android.gms.internal.ads.t) r1
            long r1 = r1.f12418i
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.String r2 = "tpc"
            r0.put(r2, r1)
        L_0x00d9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.b.e():java.util.Map");
    }

    public final void f(String str) {
        Log.d("UserMessagingPlatform", "Receive consent action: ".concat(String.valueOf(str)));
        Uri parse = Uri.parse(str);
        String queryParameter = parse.getQueryParameter("action");
        String queryParameter2 = parse.getQueryParameter("args");
        c0[] c0VarArr = {this, (r6.r) this.f876f};
        t0 t0Var = (t0) this.f875e;
        t0Var.getClass();
        t0Var.f26643a.execute(new o1.a(queryParameter, queryParameter2, c0VarArr, 12, 0));
    }

    public /* synthetic */ b(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, Object obj7, Object obj8) {
        this.f871a = obj;
        this.f872b = obj2;
        this.f873c = obj3;
        this.f874d = obj4;
        this.f875e = obj5;
        this.f876f = obj6;
        this.f877g = obj7;
        this.f878h = obj8;
    }
}
