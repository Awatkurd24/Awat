package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new a(3);

    /* renamed from: a  reason: collision with root package name */
    public final int f868a;

    /* renamed from: b  reason: collision with root package name */
    public final float f869b;

    public RatingCompat(int i10, float f10) {
        this.f868a = i10;
        this.f869b = f10;
    }

    public final int describeContents() {
        return this.f868a;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Rating:style=");
        sb2.append(this.f868a);
        sb2.append(" rating=");
        float f10 = this.f869b;
        sb2.append(f10 < 0.0f ? "unrated" : String.valueOf(f10));
        return sb2.toString();
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f868a);
        parcel.writeFloat(this.f869b);
    }
}
