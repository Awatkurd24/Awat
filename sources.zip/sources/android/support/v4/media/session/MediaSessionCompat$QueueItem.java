package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.a;

public final class MediaSessionCompat$QueueItem implements Parcelable {
    public static final Parcelable.Creator<MediaSessionCompat$QueueItem> CREATOR = new a(4);

    /* renamed from: a  reason: collision with root package name */
    public final MediaDescriptionCompat f879a;

    /* renamed from: b  reason: collision with root package name */
    public final long f880b;

    public MediaSessionCompat$QueueItem(Parcel parcel) {
        this.f879a = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        this.f880b = parcel.readLong();
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "MediaSession.QueueItem {Description=" + this.f879a + ", Id=" + this.f880b + " }";
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        this.f879a.writeToParcel(parcel, i10);
        parcel.writeLong(this.f880b);
    }
}
