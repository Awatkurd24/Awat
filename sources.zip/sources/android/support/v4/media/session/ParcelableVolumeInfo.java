package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.a;

public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a(7);

    /* renamed from: a  reason: collision with root package name */
    public int f883a;

    /* renamed from: b  reason: collision with root package name */
    public int f884b;

    /* renamed from: c  reason: collision with root package name */
    public int f885c;

    /* renamed from: d  reason: collision with root package name */
    public int f886d;

    /* renamed from: e  reason: collision with root package name */
    public int f887e;

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f883a);
        parcel.writeInt(this.f885c);
        parcel.writeInt(this.f886d);
        parcel.writeInt(this.f887e);
        parcel.writeInt(this.f884b);
    }
}
