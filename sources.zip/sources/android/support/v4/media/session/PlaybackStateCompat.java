package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.a;
import android.text.TextUtils;
import java.util.ArrayList;

public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a(8);

    /* renamed from: a  reason: collision with root package name */
    public final int f888a;

    /* renamed from: b  reason: collision with root package name */
    public final long f889b;

    /* renamed from: c  reason: collision with root package name */
    public final long f890c;

    /* renamed from: d  reason: collision with root package name */
    public final float f891d;

    /* renamed from: e  reason: collision with root package name */
    public final long f892e;

    /* renamed from: f  reason: collision with root package name */
    public final int f893f;

    /* renamed from: g  reason: collision with root package name */
    public final CharSequence f894g;

    /* renamed from: h  reason: collision with root package name */
    public final long f895h;

    /* renamed from: i  reason: collision with root package name */
    public final ArrayList f896i;

    /* renamed from: j  reason: collision with root package name */
    public final long f897j;

    /* renamed from: k  reason: collision with root package name */
    public final Bundle f898k;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new Object();

        /* renamed from: a  reason: collision with root package name */
        public final String f899a;

        /* renamed from: b  reason: collision with root package name */
        public final CharSequence f900b;

        /* renamed from: c  reason: collision with root package name */
        public final int f901c;

        /* renamed from: d  reason: collision with root package name */
        public final Bundle f902d;

        public CustomAction(Parcel parcel) {
            this.f899a = parcel.readString();
            this.f900b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f901c = parcel.readInt();
            this.f902d = parcel.readBundle(xb.a.class.getClassLoader());
        }

        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + this.f900b + ", mIcon=" + this.f901c + ", mExtras=" + this.f902d;
        }

        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.f899a);
            TextUtils.writeToParcel(this.f900b, parcel, i10);
            parcel.writeInt(this.f901c);
            parcel.writeBundle(this.f902d);
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f888a = parcel.readInt();
        this.f889b = parcel.readLong();
        this.f891d = parcel.readFloat();
        this.f895h = parcel.readLong();
        this.f890c = parcel.readLong();
        this.f892e = parcel.readLong();
        this.f894g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f896i = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f897j = parcel.readLong();
        this.f898k = parcel.readBundle(xb.a.class.getClassLoader());
        this.f893f = parcel.readInt();
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "PlaybackState {state=" + this.f888a + ", position=" + this.f889b + ", buffered position=" + this.f890c + ", speed=" + this.f891d + ", updated=" + this.f895h + ", actions=" + this.f892e + ", error code=" + this.f893f + ", error message=" + this.f894g + ", custom actions=" + this.f896i + ", active item id=" + this.f897j + "}";
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f888a);
        parcel.writeLong(this.f889b);
        parcel.writeFloat(this.f891d);
        parcel.writeLong(this.f895h);
        parcel.writeLong(this.f890c);
        parcel.writeLong(this.f892e);
        TextUtils.writeToParcel(this.f894g, parcel, i10);
        parcel.writeTypedList(this.f896i);
        parcel.writeLong(this.f897j);
        parcel.writeBundle(this.f898k);
        parcel.writeInt(this.f893f);
    }
}
