package android.support.v4.media;

import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat$QueueItem;
import android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper;
import android.support.v4.media.session.MediaSessionCompat$Token;
import android.support.v4.media.session.ParcelableVolumeInfo;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v4.os.ResultReceiver;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import androidx.versionedparcelable.ParcelImpl;
import androidx.work.multiprocess.parcelable.ParcelableConstraints;
import androidx.work.multiprocess.parcelable.ParcelableData;
import androidx.work.multiprocess.parcelable.ParcelableForegroundRequestInfo;
import androidx.work.multiprocess.parcelable.ParcelableRemoteWorkRequest;
import androidx.work.multiprocess.parcelable.ParcelableResult;
import androidx.work.multiprocess.parcelable.ParcelableRuntimeExtras;
import androidx.work.multiprocess.parcelable.ParcelableUpdateRequest;
import androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl;
import androidx.work.multiprocess.parcelable.ParcelableWorkInfo;
import androidx.work.multiprocess.parcelable.ParcelableWorkInfos;
import androidx.work.multiprocess.parcelable.ParcelableWorkQuery;
import androidx.work.multiprocess.parcelable.ParcelableWorkRequest;
import androidx.work.multiprocess.parcelable.ParcelableWorkRequests;
import androidx.work.multiprocess.parcelable.ParcelableWorkerParameters;
import coil.size.OriginalSize;
import coil.size.PixelSize;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import io.tooldroid.dialog.ToolDroidDialog;

public final class a implements Parcelable.Creator {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f870a;

    public /* synthetic */ a(int i10) {
        this.f870a = i10;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v5, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r7v0 */
    /* JADX WARNING: type inference failed for: r2v6, types: [android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v8, types: [android.support.v4.media.session.ParcelableVolumeInfo, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v22, types: [java.lang.Object, androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl] */
    /* JADX WARNING: type inference failed for: r7v5, types: [java.util.ArrayList] */
    /* JADX WARNING: type inference failed for: r5v3, types: [int] */
    /* JADX WARNING: type inference failed for: r7v7, types: [android.os.IBinder] */
    /* JADX WARNING: type inference failed for: r7v10 */
    /* JADX WARNING: type inference failed for: r5v8 */
    /* JADX WARNING: type inference failed for: r7v13 */
    /* JADX WARNING: type inference failed for: r5v11 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x01fa  */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x01fd  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object createFromParcel(android.os.Parcel r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r0.f870a
            java.lang.String r3 = "parcel"
            r4 = 2
            r5 = 0
            r6 = 1
            r7 = 0
            switch(r2) {
                case 0: goto L_0x0215;
                case 1: goto L_0x01a1;
                case 2: goto L_0x019b;
                case 3: goto L_0x018d;
                case 4: goto L_0x0187;
                case 5: goto L_0x0177;
                case 6: goto L_0x016d;
                case 7: goto L_0x0149;
                case 8: goto L_0x0143;
                case 9: goto L_0x013d;
                case 10: goto L_0x0137;
                case 11: goto L_0x0109;
                case 12: goto L_0x0103;
                case 13: goto L_0x00fd;
                case 14: goto L_0x00f7;
                case 15: goto L_0x00f1;
                case 16: goto L_0x00eb;
                case 17: goto L_0x00e5;
                case 18: goto L_0x00df;
                case 19: goto L_0x00d9;
                case 20: goto L_0x0077;
                case 21: goto L_0x0071;
                case 22: goto L_0x006b;
                case 23: goto L_0x0065;
                case 24: goto L_0x005f;
                case 25: goto L_0x0059;
                case 26: goto L_0x0053;
                case 27: goto L_0x004a;
                case 28: goto L_0x0039;
                default: goto L_0x000f;
            }
        L_0x000f:
            int r2 = t7.a0.C(r18)
        L_0x0013:
            int r3 = r18.dataPosition()
            if (r3 >= r2) goto L_0x0030
            int r3 = r18.readInt()
            char r8 = (char) r3
            if (r8 == r6) goto L_0x002b
            if (r8 == r4) goto L_0x0026
            t7.a0.A(r1, r3)
            goto L_0x0013
        L_0x0026:
            android.os.IBinder r7 = t7.a0.v(r1, r3)
            goto L_0x0013
        L_0x002b:
            boolean r5 = t7.a0.t(r1, r3)
            goto L_0x0013
        L_0x0030:
            t7.a0.n(r1, r2)
            com.google.android.gms.ads.formats.AdManagerAdViewOptions r1 = new com.google.android.gms.ads.formats.AdManagerAdViewOptions
            r1.<init>(r5, r7)
            return r1
        L_0x0039:
            v7.r0.j(r3, r1)
            coil.size.PixelSize r2 = new coil.size.PixelSize
            int r3 = r18.readInt()
            int r1 = r18.readInt()
            r2.<init>(r3, r1)
            return r2
        L_0x004a:
            v7.r0.j(r3, r1)
            r18.readInt()
            coil.size.OriginalSize r1 = coil.size.OriginalSize.f4254a
            return r1
        L_0x0053:
            androidx.work.multiprocess.parcelable.ParcelableWorkerParameters r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkerParameters
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x0059:
            androidx.work.multiprocess.parcelable.ParcelableWorkRequests r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkRequests
            r2.<init>(r1)
            return r2
        L_0x005f:
            androidx.work.multiprocess.parcelable.ParcelableWorkRequest r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkRequest
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x0065:
            androidx.work.multiprocess.parcelable.ParcelableWorkQuery r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkQuery
            r2.<init>(r1)
            return r2
        L_0x006b:
            androidx.work.multiprocess.parcelable.ParcelableWorkInfos r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkInfos
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x0071:
            androidx.work.multiprocess.parcelable.ParcelableWorkInfo r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkInfo
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x0077:
            androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl r2 = new androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl
            r2.<init>()
            int r3 = r18.readInt()
            if (r3 != r6) goto L_0x0087
            java.lang.String r3 = r18.readString()
            goto L_0x0088
        L_0x0087:
            r3 = r7
        L_0x0088:
            int r4 = r18.readInt()
            int[] r8 = androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl.f3260b
            r4 = r8[r4]
            int r8 = r18.readInt()
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>(r8)
            java.lang.Class<androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl> r10 = androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl.class
            java.lang.ClassLoader r10 = r10.getClassLoader()
            r11 = 0
        L_0x00a0:
            if (r11 >= r8) goto L_0x00b2
            android.os.Parcelable r12 = r1.readParcelable(r10)
            androidx.work.multiprocess.parcelable.ParcelableWorkRequest r12 = (androidx.work.multiprocess.parcelable.ParcelableWorkRequest) r12
            r3.j0 r12 = r12.f3266a
            s3.a0 r12 = (s3.a0) r12
            r9.add(r12)
            int r11 = r11 + 1
            goto L_0x00a0
        L_0x00b2:
            int r8 = r18.readInt()
            if (r8 != r6) goto L_0x00d1
            int r6 = r18.readInt()
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>(r6)
        L_0x00c1:
            if (r5 >= r6) goto L_0x00d1
            android.os.Parcelable r8 = r1.readParcelable(r10)
            androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl r8 = (androidx.work.multiprocess.parcelable.ParcelableWorkContinuationImpl) r8
            g4.a r8 = r8.f3261a
            r7.add(r8)
            int r5 = r5 + 1
            goto L_0x00c1
        L_0x00d1:
            g4.a r1 = new g4.a
            r1.<init>(r3, r4, r9, r7)
            r2.f3261a = r1
            return r2
        L_0x00d9:
            androidx.work.multiprocess.parcelable.ParcelableUpdateRequest r2 = new androidx.work.multiprocess.parcelable.ParcelableUpdateRequest
            r2.<init>(r1)
            return r2
        L_0x00df:
            androidx.work.multiprocess.parcelable.ParcelableRuntimeExtras r2 = new androidx.work.multiprocess.parcelable.ParcelableRuntimeExtras
            r2.<init>(r1)
            return r2
        L_0x00e5:
            androidx.work.multiprocess.parcelable.ParcelableResult r2 = new androidx.work.multiprocess.parcelable.ParcelableResult
            r2.<init>(r1)
            return r2
        L_0x00eb:
            androidx.work.multiprocess.parcelable.ParcelableRemoteWorkRequest r2 = new androidx.work.multiprocess.parcelable.ParcelableRemoteWorkRequest
            r2.<init>(r1)
            return r2
        L_0x00f1:
            androidx.work.multiprocess.parcelable.ParcelableForegroundRequestInfo r2 = new androidx.work.multiprocess.parcelable.ParcelableForegroundRequestInfo
            r2.<init>(r1)
            return r2
        L_0x00f7:
            androidx.work.multiprocess.parcelable.ParcelableData r2 = new androidx.work.multiprocess.parcelable.ParcelableData
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x00fd:
            androidx.work.multiprocess.parcelable.ParcelableConstraints r2 = new androidx.work.multiprocess.parcelable.ParcelableConstraints
            r2.<init>((android.os.Parcel) r1)
            return r2
        L_0x0103:
            androidx.versionedparcelable.ParcelImpl r2 = new androidx.versionedparcelable.ParcelImpl
            r2.<init>(r1)
            return r2
        L_0x0109:
            java.lang.String r2 = "inParcel"
            v7.r0.j(r2, r1)
            androidx.activity.result.IntentSenderRequest r2 = new androidx.activity.result.IntentSenderRequest
            java.lang.Class<android.content.IntentSender> r3 = android.content.IntentSender.class
            java.lang.ClassLoader r3 = r3.getClassLoader()
            android.os.Parcelable r3 = r1.readParcelable(r3)
            v7.r0.g(r3)
            android.content.IntentSender r3 = (android.content.IntentSender) r3
            java.lang.Class<android.content.Intent> r4 = android.content.Intent.class
            java.lang.ClassLoader r4 = r4.getClassLoader()
            android.os.Parcelable r4 = r1.readParcelable(r4)
            android.content.Intent r4 = (android.content.Intent) r4
            int r5 = r18.readInt()
            int r1 = r18.readInt()
            r2.<init>(r3, r4, r5, r1)
            return r2
        L_0x0137:
            androidx.activity.result.ActivityResult r2 = new androidx.activity.result.ActivityResult
            r2.<init>(r1)
            return r2
        L_0x013d:
            android.support.v4.os.ResultReceiver r2 = new android.support.v4.os.ResultReceiver
            r2.<init>(r1)
            return r2
        L_0x0143:
            android.support.v4.media.session.PlaybackStateCompat r2 = new android.support.v4.media.session.PlaybackStateCompat
            r2.<init>(r1)
            return r2
        L_0x0149:
            android.support.v4.media.session.ParcelableVolumeInfo r2 = new android.support.v4.media.session.ParcelableVolumeInfo
            r2.<init>()
            int r3 = r18.readInt()
            r2.f883a = r3
            int r3 = r18.readInt()
            r2.f885c = r3
            int r3 = r18.readInt()
            r2.f886d = r3
            int r3 = r18.readInt()
            r2.f887e = r3
            int r1 = r18.readInt()
            r2.f884b = r1
            return r2
        L_0x016d:
            android.os.Parcelable r1 = r1.readParcelable(r7)
            android.support.v4.media.session.MediaSessionCompat$Token r2 = new android.support.v4.media.session.MediaSessionCompat$Token
            r2.<init>(r1)
            return r2
        L_0x0177:
            android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper r2 = new android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper
            r2.<init>()
            android.os.Parcelable$Creator r3 = android.os.ResultReceiver.CREATOR
            java.lang.Object r1 = r3.createFromParcel(r1)
            android.os.ResultReceiver r1 = (android.os.ResultReceiver) r1
            r2.f881a = r1
            return r2
        L_0x0187:
            android.support.v4.media.session.MediaSessionCompat$QueueItem r2 = new android.support.v4.media.session.MediaSessionCompat$QueueItem
            r2.<init>(r1)
            return r2
        L_0x018d:
            android.support.v4.media.RatingCompat r2 = new android.support.v4.media.RatingCompat
            int r3 = r18.readInt()
            float r1 = r18.readFloat()
            r2.<init>(r3, r1)
            return r2
        L_0x019b:
            android.support.v4.media.MediaMetadataCompat r2 = new android.support.v4.media.MediaMetadataCompat
            r2.<init>(r1)
            return r2
        L_0x01a1:
            int r2 = android.os.Build.VERSION.SDK_INT
            android.os.Parcelable$Creator r3 = android.media.MediaDescription.CREATOR
            java.lang.Object r1 = r3.createFromParcel(r1)
            if (r1 == 0) goto L_0x0213
            r3 = r1
            android.media.MediaDescription r3 = (android.media.MediaDescription) r3
            java.lang.String r9 = r3.getMediaId()
            java.lang.CharSequence r10 = r3.getTitle()
            java.lang.CharSequence r11 = r3.getSubtitle()
            java.lang.CharSequence r12 = r3.getDescription()
            android.graphics.Bitmap r13 = r3.getIconBitmap()
            android.net.Uri r14 = r3.getIconUri()
            android.os.Bundle r5 = r3.getExtras()
            java.lang.String r6 = "android.support.v4.media.description.MEDIA_URI"
            if (r5 == 0) goto L_0x01de
            java.lang.Class<xb.a> r8 = xb.a.class
            java.lang.ClassLoader r8 = r8.getClassLoader()
            r5.setClassLoader(r8)
            android.os.Parcelable r8 = r5.getParcelable(r6)
            android.net.Uri r8 = (android.net.Uri) r8
            goto L_0x01df
        L_0x01de:
            r8 = r7
        L_0x01df:
            if (r8 == 0) goto L_0x01f7
            java.lang.String r15 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r16 = r5.containsKey(r15)
            if (r16 == 0) goto L_0x01f1
            int r7 = r5.size()
            if (r7 != r4) goto L_0x01f1
            r15 = 0
            goto L_0x01f8
        L_0x01f1:
            r5.remove(r6)
            r5.remove(r15)
        L_0x01f7:
            r15 = r5
        L_0x01f8:
            if (r8 == 0) goto L_0x01fd
            r16 = r8
            goto L_0x020a
        L_0x01fd:
            r4 = 23
            if (r2 < r4) goto L_0x0208
            android.net.Uri r7 = r3.getMediaUri()
            r16 = r7
            goto L_0x020a
        L_0x0208:
            r16 = 0
        L_0x020a:
            android.support.v4.media.MediaDescriptionCompat r7 = new android.support.v4.media.MediaDescriptionCompat
            r8 = r7
            r8.<init>(r9, r10, r11, r12, r13, r14, r15, r16)
            r7.f866i = r1
            goto L_0x0214
        L_0x0213:
            r7 = 0
        L_0x0214:
            return r7
        L_0x0215:
            android.support.v4.media.MediaBrowserCompat$MediaItem r2 = new android.support.v4.media.MediaBrowserCompat$MediaItem
            r2.<init>(r1)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.a.createFromParcel(android.os.Parcel):java.lang.Object");
    }

    public final Object[] newArray(int i10) {
        switch (this.f870a) {
            case 0:
                return new MediaBrowserCompat$MediaItem[i10];
            case 1:
                return new MediaDescriptionCompat[i10];
            case 2:
                return new MediaMetadataCompat[i10];
            case 3:
                return new RatingCompat[i10];
            case 4:
                return new MediaSessionCompat$QueueItem[i10];
            case 5:
                return new MediaSessionCompat$ResultReceiverWrapper[i10];
            case 6:
                return new MediaSessionCompat$Token[i10];
            case 7:
                return new ParcelableVolumeInfo[i10];
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return new PlaybackStateCompat[i10];
            case 9:
                return new ResultReceiver[i10];
            case 10:
                return new ActivityResult[i10];
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                return new IntentSenderRequest[i10];
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                return new ParcelImpl[i10];
            case 13:
                return new ParcelableConstraints[i10];
            case 14:
                return new ParcelableData[i10];
            case 15:
                return new ParcelableForegroundRequestInfo[i10];
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                return new ParcelableRemoteWorkRequest[i10];
            case ToolDroidDialog.CENTER /*17*/:
                return new ParcelableResult[i10];
            case 18:
                return new ParcelableRuntimeExtras[i10];
            case 19:
                return new ParcelableUpdateRequest[i10];
            case 20:
                return new ParcelableWorkContinuationImpl[i10];
            case 21:
                return new ParcelableWorkInfo[i10];
            case 22:
                return new ParcelableWorkInfos[i10];
            case 23:
                return new ParcelableWorkQuery[i10];
            case 24:
                return new ParcelableWorkRequest[i10];
            case 25:
                return new ParcelableWorkRequests[i10];
            case 26:
                return new ParcelableWorkerParameters[i10];
            case 27:
                return new OriginalSize[i10];
            case 28:
                return new PixelSize[i10];
            default:
                return new AdManagerAdViewOptions[i10];
        }
    }
}
