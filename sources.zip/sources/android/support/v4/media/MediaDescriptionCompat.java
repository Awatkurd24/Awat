package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a(1);

    /* renamed from: a  reason: collision with root package name */
    public final String f858a;

    /* renamed from: b  reason: collision with root package name */
    public final CharSequence f859b;

    /* renamed from: c  reason: collision with root package name */
    public final CharSequence f860c;

    /* renamed from: d  reason: collision with root package name */
    public final CharSequence f861d;

    /* renamed from: e  reason: collision with root package name */
    public final Bitmap f862e;

    /* renamed from: f  reason: collision with root package name */
    public final Uri f863f;

    /* renamed from: g  reason: collision with root package name */
    public final Bundle f864g;

    /* renamed from: h  reason: collision with root package name */
    public final Uri f865h;

    /* renamed from: i  reason: collision with root package name */
    public Object f866i;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f858a = str;
        this.f859b = charSequence;
        this.f860c = charSequence2;
        this.f861d = charSequence3;
        this.f862e = bitmap;
        this.f863f = uri;
        this.f864g = bundle;
        this.f865h = uri2;
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return this.f859b + ", " + this.f860c + ", " + this.f861d;
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        int i11 = Build.VERSION.SDK_INT;
        Object obj = this.f866i;
        if (obj == null) {
            MediaDescription.Builder builder = new MediaDescription.Builder();
            builder.setMediaId(this.f858a);
            builder.setTitle(this.f859b);
            builder.setSubtitle(this.f860c);
            builder.setDescription(this.f861d);
            builder.setIconBitmap(this.f862e);
            builder.setIconUri(this.f863f);
            Uri uri = this.f865h;
            Bundle bundle = this.f864g;
            if (i11 < 23 && uri != null) {
                if (bundle == null) {
                    bundle = new Bundle();
                    bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
                }
                bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", uri);
            }
            builder.setExtras(bundle);
            if (i11 >= 23) {
                builder.setMediaUri(uri);
            }
            obj = builder.build();
            this.f866i = obj;
        }
        ((MediaDescription) obj).writeToParcel(parcel, i10);
    }
}
