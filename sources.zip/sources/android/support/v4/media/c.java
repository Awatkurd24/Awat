package android.support.v4.media;

import android.media.AudioDeviceInfo;
import android.media.AudioTrack;
import android.media.MediaDrmResetException;
import android.security.keystore.KeyGenParameterSpec;
import android.widget.ThemedSpinnerAdapter;

public abstract /* synthetic */ class c {
    /*  JADX ERROR: IndexOutOfBoundsException in pass: MethodInlineVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.visitors.MethodInlineVisitor.inlineMth(MethodInlineVisitor.java:57)
        	at jadx.core.dex.visitors.MethodInlineVisitor.visit(MethodInlineVisitor.java:47)
        */
    public static /* synthetic */ void C() {
        /*
            android.media.AudioTrack$Builder r0 = new android.media.AudioTrack$Builder
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.c.C():void");
    }

    public static /* bridge */ /* synthetic */ AudioDeviceInfo b(Object obj) {
        return (AudioDeviceInfo) obj;
    }

    public static /* synthetic */ AudioTrack.Builder c() {
        return new AudioTrack.Builder();
    }

    public static /* synthetic */ KeyGenParameterSpec.Builder k() {
        return new KeyGenParameterSpec.Builder("fl.install.id.sec.key", 3);
    }

    public static /* bridge */ /* synthetic */ ThemedSpinnerAdapter p(Object obj) {
        return (ThemedSpinnerAdapter) obj;
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: MethodInlineVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.visitors.MethodInlineVisitor.inlineMth(MethodInlineVisitor.java:57)
        	at jadx.core.dex.visitors.MethodInlineVisitor.visit(MethodInlineVisitor.java:47)
        */
    public static /* synthetic */ void q() {
        /*
            android.security.keystore.KeyGenParameterSpec$Builder r0 = new android.security.keystore.KeyGenParameterSpec$Builder
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.c.q():void");
    }

    public static /* bridge */ /* synthetic */ boolean x(Object obj) {
        return obj instanceof ThemedSpinnerAdapter;
    }

    public static /* bridge */ /* synthetic */ boolean y(Throwable th2) {
        return th2 instanceof MediaDrmResetException;
    }
}
