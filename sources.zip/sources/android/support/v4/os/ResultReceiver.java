package android.support.v4.os;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.a;
import c.b;
import c.c;

@SuppressLint({"BanParcelableUsage"})
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new a(9);

    /* renamed from: a  reason: collision with root package name */
    public b f903a;

    /* JADX WARNING: type inference failed for: r0v3, types: [c.a, java.lang.Object] */
    public ResultReceiver(Parcel parcel) {
        b bVar;
        IBinder readStrongBinder = parcel.readStrongBinder();
        int i10 = c.f3705b;
        if (readStrongBinder == null) {
            bVar = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface(b.f3704u0);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof b)) {
                ? obj = new Object();
                obj.f3703a = readStrongBinder;
                bVar = obj;
            } else {
                bVar = (b) queryLocalInterface;
            }
        }
        this.f903a = bVar;
    }

    public void a(int i10, Bundle bundle) {
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        synchronized (this) {
            try {
                if (this.f903a == null) {
                    this.f903a = new c(this);
                }
                parcel.writeStrongBinder(this.f903a.asBinder());
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
