package android.app;

public /* synthetic */ class ServiceStartNotAllowedException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}
