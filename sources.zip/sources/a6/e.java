package a6;

import android.content.Context;
import b6.b;
import f6.m;
import vd.a;

public final class e implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f643a;

    /* renamed from: b  reason: collision with root package name */
    public final a f644b;

    /* renamed from: c  reason: collision with root package name */
    public final a f645c;

    /* renamed from: d  reason: collision with root package name */
    public final a f646d;

    public /* synthetic */ e(a aVar, a aVar2, a aVar3, int i10) {
        this.f643a = i10;
        this.f644b = aVar;
        this.f645c = aVar2;
        this.f646d = aVar3;
    }

    public final Object get() {
        int i10 = this.f643a;
        a aVar = this.f646d;
        a aVar2 = this.f645c;
        a aVar3 = this.f644b;
        switch (i10) {
            case 0:
                return new d((Context) aVar3.get(), (h6.a) aVar2.get(), (h6.a) aVar.get());
            default:
                return new m((Context) aVar3.get(), ((Integer) aVar.get()).intValue(), (String) aVar2.get());
        }
    }
}
