package a6;

import a4.c;
import android.content.Context;
import com.google.android.datatransport.cct.CctBackendFactory;
import java.util.HashMap;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final c f647a;

    /* renamed from: b  reason: collision with root package name */
    public final d f648b;

    /* renamed from: c  reason: collision with root package name */
    public final HashMap f649c = new HashMap();

    /* JADX WARNING: type inference failed for: r0v0, types: [a4.c, java.lang.Object] */
    public f(Context context, d dVar) {
        ? obj = new Object();
        obj.f537b = null;
        obj.f536a = context;
        this.f647a = obj;
        this.f648b = dVar;
    }

    public final synchronized g a(String str) {
        if (this.f649c.containsKey(str)) {
            return (g) this.f649c.get(str);
        }
        CctBackendFactory m10 = this.f647a.m(str);
        if (m10 == null) {
            return null;
        }
        d dVar = this.f648b;
        g create = m10.create(new b(dVar.f640a, dVar.f641b, dVar.f642c, str));
        this.f649c.put(str, create);
        return create;
    }
}
