package a6;

public interface g {
}
