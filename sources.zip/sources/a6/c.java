package a6;

public abstract class c {
}
