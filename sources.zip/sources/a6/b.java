package a6;

import a4.l;
import android.content.Context;
import h6.a;

public final class b extends c {

    /* renamed from: a  reason: collision with root package name */
    public final Context f636a;

    /* renamed from: b  reason: collision with root package name */
    public final a f637b;

    /* renamed from: c  reason: collision with root package name */
    public final a f638c;

    /* renamed from: d  reason: collision with root package name */
    public final String f639d;

    public b(Context context, a aVar, a aVar2, String str) {
        if (context != null) {
            this.f636a = context;
            if (aVar != null) {
                this.f637b = aVar;
                if (aVar2 != null) {
                    this.f638c = aVar2;
                    if (str != null) {
                        this.f639d = str;
                        return;
                    }
                    throw new NullPointerException("Null backendName");
                }
                throw new NullPointerException("Null monotonicClock");
            }
            throw new NullPointerException("Null wallClock");
        }
        throw new NullPointerException("Null applicationContext");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        if (this.f636a.equals(((b) cVar).f636a)) {
            b bVar = (b) cVar;
            if (!this.f637b.equals(bVar.f637b) || !this.f638c.equals(bVar.f638c) || !this.f639d.equals(bVar.f639d)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return ((((((this.f636a.hashCode() ^ 1000003) * 1000003) ^ this.f637b.hashCode()) * 1000003) ^ this.f638c.hashCode()) * 1000003) ^ this.f639d.hashCode();
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("CreationContext{applicationContext=");
        sb2.append(this.f636a);
        sb2.append(", wallClock=");
        sb2.append(this.f637b);
        sb2.append(", monotonicClock=");
        sb2.append(this.f638c);
        sb2.append(", backendName=");
        return l.J(sb2, this.f639d, "}");
    }
}
