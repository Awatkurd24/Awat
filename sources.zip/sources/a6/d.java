package a6;

import android.content.Context;
import h6.a;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final Context f640a;

    /* renamed from: b  reason: collision with root package name */
    public final a f641b;

    /* renamed from: c  reason: collision with root package name */
    public final a f642c;

    public d(Context context, a aVar, a aVar2) {
        this.f640a = context;
        this.f641b = aVar;
        this.f642c = aVar2;
    }
}
