package a6;

import a4.l;
import t.u;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final int f634a;

    /* renamed from: b  reason: collision with root package name */
    public final long f635b;

    public a(int i10, long j3) {
        if (i10 != 0) {
            this.f634a = i10;
            this.f635b = j3;
            return;
        }
        throw new NullPointerException("Null status");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (!u.a(this.f634a, aVar.f634a) || this.f635b != aVar.f635b) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        long j3 = this.f635b;
        return ((u.h(this.f634a) ^ 1000003) * 1000003) ^ ((int) (j3 ^ (j3 >>> 32)));
    }

    public final String toString() {
        return "BackendResponse{status=" + l.U(this.f634a) + ", nextRequestWaitMillis=" + this.f635b + "}";
    }
}
