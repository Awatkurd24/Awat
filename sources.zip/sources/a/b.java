package a;

import android.os.IInterface;

public interface b extends IInterface {
}
