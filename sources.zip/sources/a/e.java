package a;

import android.os.IInterface;

public interface e extends IInterface {
}
