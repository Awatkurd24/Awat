package a;

import android.os.IBinder;

public final class c implements e {

    /* renamed from: a  reason: collision with root package name */
    public IBinder f15a;

    public final IBinder asBinder() {
        return this.f15a;
    }
}
