package a;

import android.os.Binder;

public abstract class d extends Binder implements e {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f16a = 0;
}
