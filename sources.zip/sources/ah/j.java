package ah;

public abstract class j {

    /* renamed from: a  reason: collision with root package name */
    public static final i f851a = new Object();
}
