package ah;

import bh.v;
import com.google.android.gms.dynamite.descriptors.com.google.mlkit.dynamite.barcode.ModuleDescriptor;
import dh.w;
import ge.b;
import yg.g;

public abstract class e {

    /* renamed from: a  reason: collision with root package name */
    public static final k f828a = new k(-1, (k) null, (c) null, 0);

    /* renamed from: b  reason: collision with root package name */
    public static final int f829b = v.i("kotlinx.coroutines.bufferedChannel.segmentSize", 32, 0, 0, 12);

    /* renamed from: c  reason: collision with root package name */
    public static final int f830c = v.i("kotlinx.coroutines.bufferedChannel.expandBufferCompletionWaitIterations", ModuleDescriptor.MODULE_VERSION, 0, 0, 12);

    /* renamed from: d  reason: collision with root package name */
    public static final w f831d = new w("BUFFERED");

    /* renamed from: e  reason: collision with root package name */
    public static final w f832e = new w("SHOULD_BUFFER");

    /* renamed from: f  reason: collision with root package name */
    public static final w f833f = new w("S_RESUMING_BY_RCV");

    /* renamed from: g  reason: collision with root package name */
    public static final w f834g = new w("RESUMING_BY_EB");

    /* renamed from: h  reason: collision with root package name */
    public static final w f835h = new w("POISONED");

    /* renamed from: i  reason: collision with root package name */
    public static final w f836i = new w("DONE_RCV");

    /* renamed from: j  reason: collision with root package name */
    public static final w f837j = new w("INTERRUPTED_SEND");

    /* renamed from: k  reason: collision with root package name */
    public static final w f838k = new w("INTERRUPTED_RCV");

    /* renamed from: l  reason: collision with root package name */
    public static final w f839l = new w("CHANNEL_CLOSED");

    /* renamed from: m  reason: collision with root package name */
    public static final w f840m = new w("SUSPEND");

    /* renamed from: n  reason: collision with root package name */
    public static final w f841n = new w("SUSPEND_NO_WAITER");

    /* renamed from: o  reason: collision with root package name */
    public static final w f842o = new w("FAILED");

    /* renamed from: p  reason: collision with root package name */
    public static final w f843p = new w("NO_RECEIVE_RESULT");

    /* renamed from: q  reason: collision with root package name */
    public static final w f844q = new w("CLOSE_HANDLER_CLOSED");

    /* renamed from: r  reason: collision with root package name */
    public static final w f845r = new w("CLOSE_HANDLER_INVOKED");

    /* renamed from: s  reason: collision with root package name */
    public static final w f846s = new w("NO_CLOSE_CAUSE");

    public static final boolean a(g gVar, Object obj, b bVar) {
        w l10 = gVar.l(obj, bVar);
        if (l10 == null) {
            return false;
        }
        gVar.n(l10);
        return true;
    }
}
