package ah;

import yg.z1;

public final class o {

    /* renamed from: a  reason: collision with root package name */
    public final z1 f855a;

    public o(z1 z1Var) {
        this.f855a = z1Var;
    }

    public final String toString() {
        return "WaiterEB(" + this.f855a + ')';
    }
}
