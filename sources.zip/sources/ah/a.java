package ah;

public enum a {
    ;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: ah.a[]} */
    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Enum, ah.a] */
    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Enum, ah.a] */
    /* JADX WARNING: type inference failed for: r3v1, types: [java.lang.Enum, ah.a] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            ah.a r0 = new ah.a
            java.lang.String r1 = "SUSPEND"
            r2 = 0
            r0.<init>(r1, r2)
            f809a = r0
            ah.a r1 = new ah.a
            java.lang.String r3 = "DROP_OLDEST"
            r4 = 1
            r1.<init>(r3, r4)
            f810b = r1
            ah.a r3 = new ah.a
            java.lang.String r5 = "DROP_LATEST"
            r6 = 2
            r3.<init>(r5, r6)
            f811c = r3
            r5 = 3
            ah.a[] r5 = new ah.a[r5]
            r5[r2] = r0
            r5[r4] = r1
            r5[r6] = r3
            f812d = r5
            v7.i9.m(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.a.<clinit>():void");
    }
}
