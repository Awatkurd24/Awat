package ah;

public class i {
    public String toString() {
        return "Failed";
    }
}
