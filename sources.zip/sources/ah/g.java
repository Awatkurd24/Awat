package ah;

public interface g extends n {

    /* renamed from: a  reason: collision with root package name */
    public static final f f849a = f.f847a;
}
