package ah;

import bh.v;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ f f847a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static final int f848b = ((int) v.h("kotlinx.coroutines.channels.defaultBuffer", (long) 64, (long) 1, (long) 2147483646));
}
