package ah;

import ge.b;
import he.w;
import t.u;

public final class m extends c {

    /* renamed from: m  reason: collision with root package name */
    public final a f854m;

    public m(int i10, a aVar, b bVar) {
        super(i10, bVar);
        this.f854m = aVar;
        if (aVar == a.f809a) {
            throw new IllegalArgumentException(("This implementation does not support suspension for senders, use " + w.f19691a.b(c.class).b() + " instead").toString());
        } else if (i10 < 1) {
            throw new IllegalArgumentException(u.c("Buffered channel capacity must be at least 1, but ", i10, " was specified").toString());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00d6 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(java.lang.Object r20) {
        /*
            r19 = this;
            r8 = r19
            ah.a r0 = ah.a.f811c
            wd.m r9 = wd.m.f29306a
            ah.a r1 = r8.f854m
            r10 = 1
            if (r1 != r0) goto L_0x001b
            java.lang.Object r0 = super.a(r20)
            boolean r1 = r0 instanceof ah.i
            r1 = r1 ^ r10
            if (r1 != 0) goto L_0x0018
            boolean r1 = r0 instanceof ah.h
            if (r1 == 0) goto L_0x00d9
        L_0x0018:
            r9 = r0
            goto L_0x00d9
        L_0x001b:
            dh.w r11 = ah.e.f831d
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = ah.c.f820h
            java.lang.Object r0 = r0.get(r8)
            ah.k r0 = (ah.k) r0
        L_0x0025:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r1 = ah.c.f816d
            long r1 = r1.getAndIncrement(r8)
            r3 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            long r12 = r1 & r3
            r3 = 0
            boolean r14 = r8.o(r1, r3)
            int r15 = ah.e.f829b
            long r6 = (long) r15
            long r1 = r12 / r6
            long r3 = r12 % r6
            int r4 = (int) r3
            r16 = r11
            long r10 = r0.f17839c
            int r3 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r3 == 0) goto L_0x0060
            ah.k r1 = ah.c.b(r8, r1, r0)
            if (r1 != 0) goto L_0x005e
            if (r14 == 0) goto L_0x005a
            java.lang.Throwable r0 = r19.l()
            ah.h r9 = new ah.h
            r9.<init>(r0)
            goto L_0x00d9
        L_0x005a:
            r11 = r16
            r10 = 1
            goto L_0x0025
        L_0x005e:
            r10 = r1
            goto L_0x0061
        L_0x0060:
            r10 = r0
        L_0x0061:
            r0 = r19
            r1 = r10
            r2 = r4
            r3 = r20
            r11 = r4
            r4 = r12
            r17 = r6
            r6 = r16
            r7 = r14
            int r0 = ah.c.c(r0, r1, r2, r3, r4, r6, r7)
            if (r0 == 0) goto L_0x00d6
            r1 = 1
            if (r0 == r1) goto L_0x00d9
            r2 = 2
            if (r0 == r2) goto L_0x00ac
            r2 = 3
            if (r0 == r2) goto L_0x00a0
            r2 = 4
            if (r0 == r2) goto L_0x0089
            r2 = 5
            if (r0 == r2) goto L_0x0084
            goto L_0x0087
        L_0x0084:
            r10.a()
        L_0x0087:
            r0 = r10
            goto L_0x005a
        L_0x0089:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = ah.c.f817e
            long r0 = r0.get(r8)
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r2 >= 0) goto L_0x0096
            r10.a()
        L_0x0096:
            java.lang.Throwable r0 = r19.l()
            ah.h r9 = new ah.h
            r9.<init>(r0)
            goto L_0x00d9
        L_0x00a0:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "unexpected"
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x00ac:
            if (r14 == 0) goto L_0x00bb
            r10.h()
            java.lang.Throwable r0 = r19.l()
            ah.h r9 = new ah.h
            r9.<init>(r0)
            goto L_0x00d9
        L_0x00bb:
            r0 = r16
            boolean r1 = r0 instanceof yg.z1
            if (r1 == 0) goto L_0x00c4
            yg.z1 r0 = (yg.z1) r0
            goto L_0x00c5
        L_0x00c4:
            r0 = 0
        L_0x00c5:
            if (r0 == 0) goto L_0x00cc
            int r4 = r11 + r15
            r0.a(r10, r4)
        L_0x00cc:
            long r0 = r10.f17839c
            long r0 = r0 * r17
            long r2 = (long) r11
            long r0 = r0 + r2
            r8.g(r0)
            goto L_0x00d9
        L_0x00d6:
            r10.a()
        L_0x00d9:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.m.a(java.lang.Object):java.lang.Object");
    }

    public final boolean p() {
        return this.f854m == a.f810b;
    }
}
