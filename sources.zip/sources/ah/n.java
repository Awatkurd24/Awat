package ah;

public interface n {
    Object a(Object obj);
}
