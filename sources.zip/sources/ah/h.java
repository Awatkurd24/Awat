package ah;

import v7.r0;

public final class h extends i {

    /* renamed from: a  reason: collision with root package name */
    public final Throwable f850a;

    public h(Throwable th2) {
        this.f850a = th2;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof h) {
            if (r0.b(this.f850a, ((h) obj).f850a)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        Throwable th2 = this.f850a;
        if (th2 != null) {
            return th2.hashCode();
        }
        return 0;
    }

    public final String toString() {
        return "Closed(" + this.f850a + ')';
    }
}
