package ah;

import dh.u;
import dh.w;
import ge.b;
import java.util.concurrent.atomic.AtomicReferenceArray;
import n1.q;
import v7.l9;
import v7.r0;
import yg.b0;
import yg.z1;
import zd.j;

public final class k extends u {

    /* renamed from: e  reason: collision with root package name */
    public final c f852e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ AtomicReferenceArray f853f = new AtomicReferenceArray(e.f829b * 2);

    public k(long j3, k kVar, c cVar, int i10) {
        super(j3, kVar, i10);
        this.f852e = cVar;
    }

    public final int f() {
        return e.f829b;
    }

    public final void g(int i10, j jVar) {
        boolean z4;
        c cVar;
        w wVar;
        q c10;
        q c11;
        int i11 = e.f829b;
        if (i10 >= i11) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z4) {
            i10 -= i11;
        }
        Object obj = this.f853f.get(i10 * 2);
        while (true) {
            Object k10 = k(i10);
            boolean z10 = k10 instanceof z1;
            cVar = this.f852e;
            if (z10 || (k10 instanceof o)) {
                if (z4) {
                    wVar = e.f837j;
                } else {
                    wVar = e.f838k;
                }
                if (j(k10, i10, wVar)) {
                    m(i10, (Object) null);
                    l(i10, !z4);
                    if (z4) {
                        r0.g(cVar);
                        b bVar = cVar.f826c;
                        if (bVar != null && (c10 = l9.c(bVar, obj, (q) null)) != null) {
                            b0.r(jVar, c10);
                            return;
                        }
                        return;
                    }
                    return;
                }
            } else if (k10 == e.f837j || k10 == e.f838k) {
                m(i10, (Object) null);
            } else if (!(k10 == e.f834g || k10 == e.f833f)) {
                if (k10 != e.f836i && k10 != e.f831d && k10 != e.f839l) {
                    throw new IllegalStateException(("unexpected state: " + k10).toString());
                }
                return;
            }
        }
        m(i10, (Object) null);
        if (z4) {
            r0.g(cVar);
            b bVar2 = cVar.f826c;
            if (bVar2 != null && (c11 = l9.c(bVar2, obj, (q) null)) != null) {
                b0.r(jVar, c11);
            }
        }
    }

    public final boolean j(Object obj, int i10, Object obj2) {
        AtomicReferenceArray atomicReferenceArray = this.f853f;
        int i11 = (i10 * 2) + 1;
        while (!atomicReferenceArray.compareAndSet(i11, obj, obj2)) {
            if (atomicReferenceArray.get(i11) != obj) {
                return false;
            }
        }
        return true;
    }

    public final Object k(int i10) {
        return this.f853f.get((i10 * 2) + 1);
    }

    public final void l(int i10, boolean z4) {
        if (z4) {
            c cVar = this.f852e;
            r0.g(cVar);
            cVar.x((this.f17839c * ((long) e.f829b)) + ((long) i10));
        }
        h();
    }

    public final void m(int i10, Object obj) {
        this.f853f.set(i10 * 2, obj);
    }

    public final void n(int i10, w wVar) {
        this.f853f.set((i10 * 2) + 1, wVar);
    }
}
