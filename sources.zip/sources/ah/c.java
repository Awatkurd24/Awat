package ah;

import a2.n;
import com.google.android.gms.internal.ads.f7;
import dh.a;
import dh.w;
import ge.b;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import n1.q;
import t.u;
import v7.l9;
import v7.r0;
import wd.m;
import yg.b0;
import yg.g;
import yg.h;
import yg.z1;
import zd.e;

public class c implements g {

    /* renamed from: d  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f816d;

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f817e;

    /* renamed from: f  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f818f;

    /* renamed from: g  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f819g;

    /* renamed from: h  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f820h;

    /* renamed from: i  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f821i;

    /* renamed from: j  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f822j;

    /* renamed from: k  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f823k;

    /* renamed from: l  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f824l;
    private volatile /* synthetic */ Object _closeCause$volatile;

    /* renamed from: b  reason: collision with root package name */
    public final int f825b;
    private volatile /* synthetic */ long bufferEnd$volatile;
    private volatile /* synthetic */ Object bufferEndSegment$volatile;

    /* renamed from: c  reason: collision with root package name */
    public final b f826c;
    private volatile /* synthetic */ Object closeHandler$volatile;
    private volatile /* synthetic */ long completedExpandBuffersAndPauseFlag$volatile;
    private volatile /* synthetic */ Object receiveSegment$volatile;
    private volatile /* synthetic */ long receivers$volatile;
    private volatile /* synthetic */ Object sendSegment$volatile;
    private volatile /* synthetic */ long sendersAndCloseStatus$volatile;

    static {
        Class<c> cls = c.class;
        f816d = AtomicLongFieldUpdater.newUpdater(cls, "sendersAndCloseStatus$volatile");
        f817e = AtomicLongFieldUpdater.newUpdater(cls, "receivers$volatile");
        f818f = AtomicLongFieldUpdater.newUpdater(cls, "bufferEnd$volatile");
        f819g = AtomicLongFieldUpdater.newUpdater(cls, "completedExpandBuffersAndPauseFlag$volatile");
        Class<Object> cls2 = Object.class;
        f820h = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "sendSegment$volatile");
        f821i = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "receiveSegment$volatile");
        f822j = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "bufferEndSegment$volatile");
        f823k = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_closeCause$volatile");
        f824l = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "closeHandler$volatile");
    }

    public c(int i10, b bVar) {
        long j3;
        this.f825b = i10;
        this.f826c = bVar;
        if (i10 >= 0) {
            k kVar = e.f828a;
            if (i10 == 0) {
                j3 = 0;
            } else if (i10 != Integer.MAX_VALUE) {
                j3 = (long) i10;
            } else {
                j3 = Long.MAX_VALUE;
            }
            this.bufferEnd$volatile = j3;
            this.completedExpandBuffersAndPauseFlag$volatile = f818f.get(this);
            k kVar2 = new k(0, (k) null, this, 3);
            this.sendSegment$volatile = kVar2;
            this.receiveSegment$volatile = kVar2;
            if (q()) {
                kVar2 = e.f828a;
                r0.h("null cannot be cast to non-null type kotlinx.coroutines.channels.ChannelSegment<E of kotlinx.coroutines.channels.BufferedChannel>", kVar2);
            }
            this.bufferEndSegment$volatile = kVar2;
            this._closeCause$volatile = e.f846s;
            return;
        }
        throw new IllegalArgumentException(u.c("Invalid channel capacity: ", i10, ", should be >=0").toString());
    }

    public static final k b(c cVar, long j3, k kVar) {
        Object a10;
        AtomicLongFieldUpdater atomicLongFieldUpdater;
        long j10;
        long j11;
        cVar.getClass();
        k kVar2 = e.f828a;
        d dVar = d.f827j;
        loop0:
        while (true) {
            a10 = a.a(kVar, j3, dVar);
            if (b0.u(a10)) {
                break;
            }
            dh.u p5 = b0.p(a10);
            while (true) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f820h;
                dh.u uVar = (dh.u) atomicReferenceFieldUpdater.get(cVar);
                if (uVar.f17839c >= p5.f17839c) {
                    break loop0;
                } else if (p5.i()) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(cVar, uVar, p5)) {
                        if (atomicReferenceFieldUpdater.get(cVar) != uVar) {
                            if (p5.e()) {
                                p5.d();
                            }
                        }
                    }
                    if (uVar.e()) {
                        uVar.d();
                    }
                }
            }
        }
        boolean u10 = b0.u(a10);
        AtomicLongFieldUpdater atomicLongFieldUpdater2 = f817e;
        if (u10) {
            cVar.f();
            if (kVar.f17839c * ((long) e.f829b) >= atomicLongFieldUpdater2.get(cVar)) {
                return null;
            }
        } else {
            kVar = (k) b0.p(a10);
            long j12 = kVar.f17839c;
            if (j12 <= j3) {
                return kVar;
            }
            long j13 = ((long) e.f829b) * j12;
            do {
                atomicLongFieldUpdater = f816d;
                j10 = atomicLongFieldUpdater.get(cVar);
                j11 = 1152921504606846975L & j10;
                if (j11 >= j13) {
                    break;
                }
            } while (!atomicLongFieldUpdater.compareAndSet(cVar, j10, j11 + (((long) ((int) (j10 >> 60))) << 60)));
            if (j12 * ((long) e.f829b) >= atomicLongFieldUpdater2.get(cVar)) {
                return null;
            }
        }
        kVar.a();
        return null;
    }

    public static final int c(c cVar, k kVar, int i10, Object obj, long j3, w wVar, boolean z4) {
        cVar.getClass();
        kVar.m(i10, obj);
        if (!z4) {
            Object k10 = kVar.k(i10);
            if (k10 == null) {
                if (cVar.d(j3)) {
                    if (kVar.j((Object) null, i10, e.f831d)) {
                        return 1;
                    }
                } else if (wVar == null) {
                    return 3;
                } else {
                    if (kVar.j((Object) null, i10, wVar)) {
                        return 2;
                    }
                }
            } else if (k10 instanceof z1) {
                kVar.m(i10, (Object) null);
                if (cVar.t(k10, obj)) {
                    kVar.n(i10, e.f836i);
                    return 0;
                }
                w wVar2 = e.f838k;
                if (kVar.f853f.getAndSet((i10 * 2) + 1, wVar2) != wVar2) {
                    kVar.l(i10, true);
                }
                return 5;
            }
        }
        return cVar.w(kVar, i10, obj, j3, wVar, z4);
    }

    public static void n(c cVar) {
        cVar.getClass();
        AtomicLongFieldUpdater atomicLongFieldUpdater = f819g;
        if ((atomicLongFieldUpdater.addAndGet(cVar, 1) & 4611686018427387904L) != 0) {
            do {
            } while ((atomicLongFieldUpdater.get(cVar) & 4611686018427387904L) != 0);
        }
    }

    public static boolean u(Object obj) {
        if (obj instanceof g) {
            r0.h("null cannot be cast to non-null type kotlinx.coroutines.CancellableContinuation<kotlin.Unit>", obj);
            return e.a((g) obj, m.f29306a, (b) null);
        }
        throw new IllegalStateException(("Unexpected waiter: " + obj).toString());
    }

    public Object a(Object obj) {
        k kVar;
        m mVar;
        z1 z1Var;
        k kVar2;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f816d;
        long j3 = atomicLongFieldUpdater.get(this);
        boolean o10 = o(j3, false);
        i iVar = j.f851a;
        if (!o10 && (!d(j3 & 1152921504606846975L))) {
            return iVar;
        }
        w wVar = e.f837j;
        k kVar3 = (k) f820h.get(this);
        while (true) {
            long andIncrement = atomicLongFieldUpdater.getAndIncrement(this);
            long j10 = andIncrement & 1152921504606846975L;
            boolean o11 = o(andIncrement, false);
            int i10 = e.f829b;
            long j11 = (long) i10;
            long j12 = j10 / j11;
            int i11 = (int) (j10 % j11);
            if (kVar3.f17839c != j12) {
                k b5 = b(this, j12, kVar3);
                if (b5 != null) {
                    kVar = b5;
                } else if (o11) {
                    return new h(l());
                }
            } else {
                kVar = kVar3;
            }
            k kVar4 = kVar;
            int i12 = i11;
            int i13 = i10;
            int c10 = c(this, kVar, i11, obj, j10, wVar, o11);
            mVar = m.f29306a;
            if (c10 != 0) {
                if (c10 == 1) {
                    break;
                } else if (c10 != 2) {
                    if (c10 == 3) {
                        throw new IllegalStateException("unexpected".toString());
                    } else if (c10 != 4) {
                        if (c10 == 5) {
                            kVar4.a();
                        }
                        kVar3 = kVar4;
                    } else {
                        if (j10 < f817e.get(this)) {
                            kVar4.a();
                        }
                        return new h(l());
                    }
                } else if (o11) {
                    kVar4.h();
                    return new h(l());
                } else {
                    if (wVar instanceof z1) {
                        z1Var = (z1) wVar;
                    } else {
                        z1Var = null;
                    }
                    if (z1Var != null) {
                        kVar2 = kVar4;
                        z1Var.a(kVar2, i12 + i13);
                    } else {
                        kVar2 = kVar4;
                    }
                    kVar2.h();
                    return iVar;
                }
            } else {
                kVar4.a();
                break;
            }
        }
        return mVar;
    }

    public final boolean d(long j3) {
        if (j3 < f818f.get(this) || j3 < f817e.get(this) + ((long) this.f825b)) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0070, code lost:
        r10 = -1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0090, code lost:
        r1 = (ah.k) ((dh.d) dh.d.f17808b.get(r1));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00d4, code lost:
        r3 = yg.b0.z(r3, r6);
        r1.l(r5, true);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final ah.k e(long r14) {
        /*
            r13 = this;
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = f822j
            java.lang.Object r0 = r0.get(r13)
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f820h
            java.lang.Object r1 = r1.get(r13)
            ah.k r1 = (ah.k) r1
            long r2 = r1.f17839c
            r4 = r0
            ah.k r4 = (ah.k) r4
            long r4 = r4.f17839c
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 <= 0) goto L_0x001a
            r0 = r1
        L_0x001a:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f821i
            java.lang.Object r1 = r1.get(r13)
            ah.k r1 = (ah.k) r1
            long r2 = r1.f17839c
            r4 = r0
            ah.k r4 = (ah.k) r4
            long r4 = r4.f17839c
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 <= 0) goto L_0x002e
            r0 = r1
        L_0x002e:
            dh.d r0 = (dh.d) r0
        L_0x0030:
            r0.getClass()
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = dh.d.f17807a
            java.lang.Object r1 = r1.get(r0)
            dh.w r2 = dh.a.f17798b
            r3 = 0
            if (r1 != r2) goto L_0x003f
            goto L_0x004b
        L_0x003f:
            dh.d r1 = (dh.d) r1
            if (r1 != 0) goto L_0x012c
        L_0x0043:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = dh.d.f17807a
            boolean r4 = r1.compareAndSet(r0, r3, r2)
            if (r4 == 0) goto L_0x0124
        L_0x004b:
            ah.k r0 = (ah.k) r0
            boolean r1 = r13.p()
            r2 = -1
            r4 = 1
            if (r1 == 0) goto L_0x00a4
            r1 = r0
        L_0x0056:
            int r5 = ah.e.f829b
            int r5 = r5 - r4
        L_0x0059:
            r6 = -1
            if (r2 >= r5) goto L_0x0090
            int r8 = ah.e.f829b
            long r8 = (long) r8
            long r10 = r1.f17839c
            long r10 = r10 * r8
            long r8 = (long) r5
            long r10 = r10 + r8
            java.util.concurrent.atomic.AtomicLongFieldUpdater r8 = f817e
            long r8 = r8.get(r13)
            int r12 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
            if (r12 >= 0) goto L_0x0072
        L_0x0070:
            r10 = r6
            goto L_0x009d
        L_0x0072:
            java.lang.Object r8 = r1.k(r5)
            if (r8 == 0) goto L_0x0082
            dh.w r9 = ah.e.f832e
            if (r8 != r9) goto L_0x007d
            goto L_0x0082
        L_0x007d:
            dh.w r9 = ah.e.f831d
            if (r8 != r9) goto L_0x008d
            goto L_0x009d
        L_0x0082:
            dh.w r9 = ah.e.f839l
            boolean r8 = r1.j(r8, r5, r9)
            if (r8 == 0) goto L_0x0072
            r1.h()
        L_0x008d:
            int r5 = r5 + -1
            goto L_0x0059
        L_0x0090:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r5 = dh.d.f17808b
            java.lang.Object r1 = r5.get(r1)
            dh.d r1 = (dh.d) r1
            ah.k r1 = (ah.k) r1
            if (r1 != 0) goto L_0x0056
            goto L_0x0070
        L_0x009d:
            int r1 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
            if (r1 == 0) goto L_0x00a4
            r13.g(r10)
        L_0x00a4:
            r1 = r0
        L_0x00a5:
            if (r1 == 0) goto L_0x0102
            int r5 = ah.e.f829b
            int r5 = r5 - r4
        L_0x00aa:
            if (r2 >= r5) goto L_0x00f7
            int r6 = ah.e.f829b
            long r6 = (long) r6
            long r8 = r1.f17839c
            long r8 = r8 * r6
            long r6 = (long) r5
            long r8 = r8 + r6
            int r6 = (r8 > r14 ? 1 : (r8 == r14 ? 0 : -1))
            if (r6 < 0) goto L_0x0102
        L_0x00b9:
            java.lang.Object r6 = r1.k(r5)
            if (r6 == 0) goto L_0x00e9
            dh.w r7 = ah.e.f832e
            if (r6 != r7) goto L_0x00c4
            goto L_0x00e9
        L_0x00c4:
            boolean r7 = r6 instanceof ah.o
            if (r7 == 0) goto L_0x00dc
            dh.w r7 = ah.e.f839l
            boolean r7 = r1.j(r6, r5, r7)
            if (r7 == 0) goto L_0x00b9
            ah.o r6 = (ah.o) r6
            yg.z1 r6 = r6.f855a
        L_0x00d4:
            java.lang.Object r3 = yg.b0.z(r3, r6)
            r1.l(r5, r4)
            goto L_0x00f4
        L_0x00dc:
            boolean r7 = r6 instanceof yg.z1
            if (r7 == 0) goto L_0x00f4
            dh.w r7 = ah.e.f839l
            boolean r7 = r1.j(r6, r5, r7)
            if (r7 == 0) goto L_0x00b9
            goto L_0x00d4
        L_0x00e9:
            dh.w r7 = ah.e.f839l
            boolean r6 = r1.j(r6, r5, r7)
            if (r6 == 0) goto L_0x00b9
            r1.h()
        L_0x00f4:
            int r5 = r5 + -1
            goto L_0x00aa
        L_0x00f7:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r5 = dh.d.f17808b
            java.lang.Object r1 = r5.get(r1)
            dh.d r1 = (dh.d) r1
            ah.k r1 = (ah.k) r1
            goto L_0x00a5
        L_0x0102:
            if (r3 == 0) goto L_0x0123
            boolean r14 = r3 instanceof java.util.ArrayList
            if (r14 != 0) goto L_0x010e
            yg.z1 r3 = (yg.z1) r3
            r13.s(r3, r4)
            goto L_0x0123
        L_0x010e:
            java.util.ArrayList r3 = (java.util.ArrayList) r3
            int r14 = r3.size()
            int r14 = r14 - r4
        L_0x0115:
            if (r2 >= r14) goto L_0x0123
            java.lang.Object r15 = r3.get(r14)
            yg.z1 r15 = (yg.z1) r15
            r13.s(r15, r4)
            int r14 = r14 + -1
            goto L_0x0115
        L_0x0123:
            return r0
        L_0x0124:
            java.lang.Object r1 = r1.get(r0)
            if (r1 == 0) goto L_0x0043
            goto L_0x0030
        L_0x012c:
            r0 = r1
            goto L_0x0030
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.c.e(long):ah.k");
    }

    public final void f() {
        o(f816d.get(this), false);
    }

    public final void g(long j3) {
        q c10;
        k kVar = (k) f821i.get(this);
        while (true) {
            AtomicLongFieldUpdater atomicLongFieldUpdater = f817e;
            long j10 = atomicLongFieldUpdater.get(this);
            if (j3 >= Math.max(((long) this.f825b) + j10, f818f.get(this))) {
                if (atomicLongFieldUpdater.compareAndSet(this, j10, j10 + 1)) {
                    long j11 = (long) e.f829b;
                    long j12 = j10 / j11;
                    int i10 = (int) (j10 % j11);
                    if (kVar.f17839c != j12) {
                        k i11 = i(j12, kVar);
                        if (i11 == null) {
                            continue;
                        } else {
                            kVar = i11;
                        }
                    }
                    Object v10 = v(kVar, i10, j10, (Object) null);
                    if (v10 != e.f842o) {
                        kVar.a();
                        b bVar = this.f826c;
                        if (!(bVar == null || (c10 = l9.c(bVar, v10, (q) null)) == null)) {
                            throw c10;
                        }
                    } else if (j10 < m()) {
                        kVar.a();
                    }
                }
            } else {
                return;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:104:0x0012 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00d3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void h() {
        /*
            r16 = this;
            r6 = r16
            boolean r0 = r16.q()
            if (r0 == 0) goto L_0x0009
            return
        L_0x0009:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = f822j
            java.lang.Object r0 = r7.get(r6)
            ah.k r0 = (ah.k) r0
            r8 = r0
        L_0x0012:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f818f
            long r9 = r0.getAndIncrement(r6)
            int r0 = ah.e.f829b
            long r0 = (long) r0
            long r0 = r9 / r0
            long r2 = r16.m()
            int r4 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            long r2 = r8.f17839c
            if (r4 > 0) goto L_0x0038
            int r4 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r4 >= 0) goto L_0x0034
            dh.d r2 = r8.b()
            if (r2 == 0) goto L_0x0034
            r6.r(r0, r8)
        L_0x0034:
            n(r16)
            return
        L_0x0038:
            int r4 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r4 == 0) goto L_0x00d4
            ah.d r2 = ah.d.f827j
        L_0x003e:
            java.lang.Object r3 = dh.a.a(r8, r0, r2)
            boolean r4 = yg.b0.u(r3)
            if (r4 != 0) goto L_0x0082
            dh.u r4 = yg.b0.p(r3)
        L_0x004c:
            java.lang.Object r5 = r7.get(r6)
            dh.u r5 = (dh.u) r5
            long r11 = r5.f17839c
            long r13 = r4.f17839c
            int r15 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r15 < 0) goto L_0x005b
            goto L_0x0082
        L_0x005b:
            boolean r11 = r4.i()
            if (r11 != 0) goto L_0x0062
            goto L_0x003e
        L_0x0062:
            boolean r11 = r7.compareAndSet(r6, r5, r4)
            if (r11 == 0) goto L_0x0072
            boolean r2 = r5.e()
            if (r2 == 0) goto L_0x0082
            r5.d()
            goto L_0x0082
        L_0x0072:
            java.lang.Object r11 = r7.get(r6)
            if (r11 == r5) goto L_0x0062
            boolean r5 = r4.e()
            if (r5 == 0) goto L_0x004c
            r4.d()
            goto L_0x004c
        L_0x0082:
            boolean r2 = yg.b0.u(r3)
            r11 = 0
            if (r2 == 0) goto L_0x0093
            r16.f()
            r6.r(r0, r8)
        L_0x008f:
            n(r16)
            goto L_0x00cf
        L_0x0093:
            dh.u r2 = yg.b0.p(r3)
            ah.k r2 = (ah.k) r2
            long r3 = r2.f17839c
            int r5 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
            if (r5 <= 0) goto L_0x00ce
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f818f
            r1 = 1
            long r12 = r9 + r1
            int r1 = ah.e.f829b
            long r1 = (long) r1
            long r14 = r3 * r1
            r1 = r16
            r2 = r12
            r4 = r14
            boolean r0 = r0.compareAndSet(r1, r2, r4)
            if (r0 == 0) goto L_0x008f
            long r14 = r14 - r9
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f819g
            long r1 = r0.addAndGet(r6, r14)
            r3 = 4611686018427387904(0x4000000000000000, double:2.0)
            long r1 = r1 & r3
            r12 = 0
            int r5 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r5 == 0) goto L_0x00cf
        L_0x00c4:
            long r1 = r0.get(r6)
            long r1 = r1 & r3
            int r5 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r5 == 0) goto L_0x00cf
            goto L_0x00c4
        L_0x00ce:
            r11 = r2
        L_0x00cf:
            if (r11 != 0) goto L_0x00d3
            goto L_0x0012
        L_0x00d3:
            r8 = r11
        L_0x00d4:
            int r0 = ah.e.f829b
            long r0 = (long) r0
            long r0 = r9 % r0
            int r1 = (int) r0
            java.lang.Object r0 = r8.k(r1)
            boolean r2 = r0 instanceof yg.z1
            java.util.concurrent.atomic.AtomicLongFieldUpdater r3 = f817e
            r4 = 0
            if (r2 == 0) goto L_0x010b
            long r11 = r3.get(r6)
            int r2 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r2 < 0) goto L_0x010b
            dh.w r2 = ah.e.f834g
            boolean r2 = r8.j(r0, r1, r2)
            if (r2 == 0) goto L_0x010b
            boolean r0 = u(r0)
            if (r0 == 0) goto L_0x0102
            dh.w r0 = ah.e.f831d
            r8.n(r1, r0)
            goto L_0x0190
        L_0x0102:
            dh.w r0 = ah.e.f837j
            r8.n(r1, r0)
            r8.l(r1, r4)
            goto L_0x014c
        L_0x010b:
            java.lang.Object r0 = r8.k(r1)
            boolean r2 = r0 instanceof yg.z1
            if (r2 == 0) goto L_0x0148
            long r11 = r3.get(r6)
            int r2 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r2 >= 0) goto L_0x012b
            ah.o r2 = new ah.o
            r5 = r0
            yg.z1 r5 = (yg.z1) r5
            r2.<init>(r5)
            boolean r0 = r8.j(r0, r1, r2)
            if (r0 == 0) goto L_0x010b
            goto L_0x0190
        L_0x012b:
            dh.w r2 = ah.e.f834g
            boolean r2 = r8.j(r0, r1, r2)
            if (r2 == 0) goto L_0x010b
            boolean r0 = u(r0)
            if (r0 == 0) goto L_0x013f
            dh.w r0 = ah.e.f831d
            r8.n(r1, r0)
            goto L_0x0190
        L_0x013f:
            dh.w r0 = ah.e.f837j
            r8.n(r1, r0)
            r8.l(r1, r4)
            goto L_0x014c
        L_0x0148:
            dh.w r2 = ah.e.f837j
            if (r0 != r2) goto L_0x0151
        L_0x014c:
            n(r16)
            goto L_0x0012
        L_0x0151:
            if (r0 != 0) goto L_0x015c
            dh.w r2 = ah.e.f832e
            boolean r0 = r8.j(r0, r1, r2)
            if (r0 == 0) goto L_0x010b
            goto L_0x0190
        L_0x015c:
            dh.w r2 = ah.e.f831d
            if (r0 != r2) goto L_0x0161
            goto L_0x0190
        L_0x0161:
            dh.w r2 = ah.e.f835h
            if (r0 == r2) goto L_0x0190
            dh.w r2 = ah.e.f836i
            if (r0 == r2) goto L_0x0190
            dh.w r2 = ah.e.f838k
            if (r0 != r2) goto L_0x016e
            goto L_0x0190
        L_0x016e:
            dh.w r2 = ah.e.f839l
            if (r0 != r2) goto L_0x0173
            goto L_0x0190
        L_0x0173:
            dh.w r2 = ah.e.f833f
            if (r0 != r2) goto L_0x0178
            goto L_0x010b
        L_0x0178:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unexpected cell state: "
            r2.<init>(r3)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x0190:
            n(r16)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.c.h():void");
    }

    public final k i(long j3, k kVar) {
        Object a10;
        AtomicLongFieldUpdater atomicLongFieldUpdater;
        long j10;
        k kVar2 = e.f828a;
        d dVar = d.f827j;
        loop0:
        while (true) {
            a10 = a.a(kVar, j3, dVar);
            if (b0.u(a10)) {
                break;
            }
            dh.u p5 = b0.p(a10);
            while (true) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f821i;
                dh.u uVar = (dh.u) atomicReferenceFieldUpdater.get(this);
                if (uVar.f17839c >= p5.f17839c) {
                    break loop0;
                } else if (p5.i()) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, uVar, p5)) {
                        if (atomicReferenceFieldUpdater.get(this) != uVar) {
                            if (p5.e()) {
                                p5.d();
                            }
                        }
                    }
                    if (uVar.e()) {
                        uVar.d();
                    }
                }
            }
        }
        if (b0.u(a10)) {
            f();
            if (kVar.f17839c * ((long) e.f829b) >= m()) {
                return null;
            }
        } else {
            kVar = (k) b0.p(a10);
            boolean q10 = q();
            long j11 = kVar.f17839c;
            if (!q10 && j3 <= f818f.get(this) / ((long) e.f829b)) {
                while (true) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = f822j;
                    dh.u uVar2 = (dh.u) atomicReferenceFieldUpdater2.get(this);
                    if (uVar2.f17839c >= j11 || !kVar.i()) {
                        break;
                    }
                    while (!atomicReferenceFieldUpdater2.compareAndSet(this, uVar2, kVar)) {
                        if (atomicReferenceFieldUpdater2.get(this) != uVar2) {
                            if (kVar.e()) {
                                kVar.d();
                            }
                        }
                    }
                    if (uVar2.e()) {
                        uVar2.d();
                    }
                }
            }
            if (j11 <= j3) {
                return kVar;
            }
            long j12 = ((long) e.f829b) * j11;
            do {
                atomicLongFieldUpdater = f817e;
                j10 = atomicLongFieldUpdater.get(this);
                if (j10 >= j12 || atomicLongFieldUpdater.compareAndSet(this, j10, j12)) {
                }
                atomicLongFieldUpdater = f817e;
                j10 = atomicLongFieldUpdater.get(this);
                break;
            } while (atomicLongFieldUpdater.compareAndSet(this, j10, j12));
            if (j11 * ((long) e.f829b) >= m()) {
                return null;
            }
        }
        kVar.a();
        return null;
    }

    public final Throwable j() {
        return (Throwable) f823k.get(this);
    }

    public final Throwable k() {
        Throwable j3 = j();
        if (j3 == null) {
            return new NoSuchElementException("Channel was closed");
        }
        return j3;
    }

    public final Throwable l() {
        Throwable j3 = j();
        return j3 == null ? new f7("Channel was closed", 2) : j3;
    }

    public final long m() {
        return f816d.get(this) & 1152921504606846975L;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x005e, code lost:
        r0.m(r4, (java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0061, code lost:
        r0.h();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00be, code lost:
        r0 = (ah.k) ((dh.d) dh.d.f17808b.get(r0));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean o(long r19, boolean r21) {
        /*
            r18 = this;
            r6 = r18
            r0 = 60
            long r0 = r19 >> r0
            int r1 = (int) r0
            r7 = 0
            if (r1 == 0) goto L_0x0190
            r8 = 1
            if (r1 == r8) goto L_0x0190
            r0 = 2
            java.util.concurrent.atomic.AtomicLongFieldUpdater r9 = f817e
            r2 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            if (r1 == r0) goto L_0x0102
            r0 = 3
            if (r1 != r0) goto L_0x00f2
            long r0 = r19 & r2
            ah.k r0 = r6.e(r0)
            r2 = 0
            r1 = r2
            r3 = r1
        L_0x0023:
            int r4 = ah.e.f829b
            int r4 = r4 - r8
        L_0x0026:
            r5 = -1
            if (r5 >= r4) goto L_0x00be
            int r10 = ah.e.f829b
            long r10 = (long) r10
            long r12 = r0.f17839c
            long r12 = r12 * r10
            long r10 = (long) r4
            long r12 = r12 + r10
        L_0x0032:
            java.lang.Object r10 = r0.k(r4)
            dh.w r11 = ah.e.f836i
            if (r10 == r11) goto L_0x00ca
            dh.w r11 = ah.e.f831d
            java.util.concurrent.atomic.AtomicReferenceArray r14 = r0.f853f
            ge.b r15 = r6.f826c
            if (r10 != r11) goto L_0x0065
            long r16 = r9.get(r6)
            int r11 = (r12 > r16 ? 1 : (r12 == r16 ? 0 : -1))
            if (r11 < 0) goto L_0x00ca
            dh.w r11 = ah.e.f839l
            boolean r10 = r0.j(r10, r4, r11)
            if (r10 == 0) goto L_0x0032
            if (r15 == 0) goto L_0x005e
            int r5 = r4 * 2
            java.lang.Object r5 = r14.get(r5)
            n1.q r1 = v7.l9.c(r15, r5, r1)
        L_0x005e:
            r0.m(r4, r2)
        L_0x0061:
            r0.h()
            goto L_0x00ba
        L_0x0065:
            dh.w r11 = ah.e.f832e
            if (r10 == r11) goto L_0x00b1
            if (r10 != 0) goto L_0x006c
            goto L_0x00b1
        L_0x006c:
            boolean r11 = r10 instanceof yg.z1
            if (r11 != 0) goto L_0x0081
            boolean r11 = r10 instanceof ah.o
            if (r11 == 0) goto L_0x0075
            goto L_0x0081
        L_0x0075:
            dh.w r11 = ah.e.f834g
            if (r10 == r11) goto L_0x00ca
            dh.w r14 = ah.e.f833f
            if (r10 != r14) goto L_0x007e
            goto L_0x00ca
        L_0x007e:
            if (r10 == r11) goto L_0x0032
            goto L_0x00ba
        L_0x0081:
            long r16 = r9.get(r6)
            int r11 = (r12 > r16 ? 1 : (r12 == r16 ? 0 : -1))
            if (r11 < 0) goto L_0x00ca
            boolean r11 = r10 instanceof ah.o
            if (r11 == 0) goto L_0x0093
            r11 = r10
            ah.o r11 = (ah.o) r11
            yg.z1 r11 = r11.f855a
            goto L_0x0096
        L_0x0093:
            r11 = r10
            yg.z1 r11 = (yg.z1) r11
        L_0x0096:
            dh.w r5 = ah.e.f839l
            boolean r5 = r0.j(r10, r4, r5)
            if (r5 == 0) goto L_0x00af
            if (r15 == 0) goto L_0x00aa
            int r5 = r4 * 2
            java.lang.Object r5 = r14.get(r5)
            n1.q r1 = v7.l9.c(r15, r5, r1)
        L_0x00aa:
            java.lang.Object r3 = yg.b0.z(r3, r11)
            goto L_0x005e
        L_0x00af:
            r5 = -1
            goto L_0x0032
        L_0x00b1:
            dh.w r5 = ah.e.f839l
            boolean r5 = r0.j(r10, r4, r5)
            if (r5 == 0) goto L_0x00af
            goto L_0x0061
        L_0x00ba:
            int r4 = r4 + -1
            goto L_0x0026
        L_0x00be:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = dh.d.f17808b
            java.lang.Object r0 = r4.get(r0)
            dh.d r0 = (dh.d) r0
            ah.k r0 = (ah.k) r0
            if (r0 != 0) goto L_0x0023
        L_0x00ca:
            if (r3 == 0) goto L_0x00ec
            boolean r0 = r3 instanceof java.util.ArrayList
            if (r0 != 0) goto L_0x00d6
            yg.z1 r3 = (yg.z1) r3
            r6.s(r3, r7)
            goto L_0x00ec
        L_0x00d6:
            java.util.ArrayList r3 = (java.util.ArrayList) r3
            int r0 = r3.size()
            int r0 = r0 - r8
            r2 = -1
        L_0x00de:
            if (r2 >= r0) goto L_0x00ec
            java.lang.Object r4 = r3.get(r0)
            yg.z1 r4 = (yg.z1) r4
            r6.s(r4, r7)
            int r0 = r0 + -1
            goto L_0x00de
        L_0x00ec:
            if (r1 != 0) goto L_0x00f1
        L_0x00ee:
            r7 = 1
            goto L_0x0190
        L_0x00f1:
            throw r1
        L_0x00f2:
            java.lang.String r0 = "unexpected close status: "
            java.lang.String r0 = f.c.n(r0, r1)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x0102:
            long r0 = r19 & r2
            r6.e(r0)
            if (r21 == 0) goto L_0x00ee
        L_0x0109:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = f821i
            java.lang.Object r1 = r0.get(r6)
            ah.k r1 = (ah.k) r1
            long r2 = r9.get(r6)
            long r4 = r18.m()
            int r10 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r10 > 0) goto L_0x011e
            goto L_0x013b
        L_0x011e:
            int r4 = ah.e.f829b
            long r4 = (long) r4
            long r10 = r2 / r4
            long r12 = r1.f17839c
            int r14 = (r12 > r10 ? 1 : (r12 == r10 ? 0 : -1))
            if (r14 == 0) goto L_0x013c
            ah.k r1 = r6.i(r10, r1)
            if (r1 != 0) goto L_0x013c
            java.lang.Object r0 = r0.get(r6)
            ah.k r0 = (ah.k) r0
            long r0 = r0.f17839c
            int r2 = (r0 > r10 ? 1 : (r0 == r10 ? 0 : -1))
            if (r2 >= 0) goto L_0x0109
        L_0x013b:
            goto L_0x00ee
        L_0x013c:
            r1.a()
            long r4 = r2 % r4
            int r0 = (int) r4
        L_0x0142:
            java.lang.Object r4 = r1.k(r0)
            if (r4 == 0) goto L_0x0179
            dh.w r5 = ah.e.f832e
            if (r4 != r5) goto L_0x014d
            goto L_0x0179
        L_0x014d:
            dh.w r0 = ah.e.f831d
            if (r4 != r0) goto L_0x0152
            goto L_0x0190
        L_0x0152:
            dh.w r0 = ah.e.f837j
            if (r4 != r0) goto L_0x0157
            goto L_0x0184
        L_0x0157:
            dh.w r0 = ah.e.f839l
            if (r4 != r0) goto L_0x015c
            goto L_0x0184
        L_0x015c:
            dh.w r0 = ah.e.f836i
            if (r4 != r0) goto L_0x0161
            goto L_0x0184
        L_0x0161:
            dh.w r0 = ah.e.f835h
            if (r4 != r0) goto L_0x0166
            goto L_0x0184
        L_0x0166:
            dh.w r0 = ah.e.f834g
            if (r4 != r0) goto L_0x016b
            goto L_0x0190
        L_0x016b:
            dh.w r0 = ah.e.f833f
            if (r4 != r0) goto L_0x0170
            goto L_0x0184
        L_0x0170:
            long r0 = r9.get(r6)
            int r4 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r4 != 0) goto L_0x0184
            goto L_0x0190
        L_0x0179:
            dh.w r5 = ah.e.f835h
            boolean r4 = r1.j(r4, r0, r5)
            if (r4 == 0) goto L_0x0142
            r18.h()
        L_0x0184:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f817e
            r4 = 1
            long r4 = r4 + r2
            r1 = r18
            r0.compareAndSet(r1, r2, r4)
            goto L_0x0109
        L_0x0190:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.c.o(long, boolean):boolean");
    }

    public boolean p() {
        return false;
    }

    public final boolean q() {
        long j3 = f818f.get(this);
        if (j3 == 0 || j3 == Long.MAX_VALUE) {
            return true;
        }
        return false;
    }

    public final void r(long j3, k kVar) {
        k kVar2;
        k kVar3;
        while (kVar.f17839c < j3 && (kVar3 = (k) kVar.b()) != null) {
            kVar = kVar3;
        }
        while (true) {
            if (!kVar.c() || (kVar2 = (k) kVar.b()) == null) {
                while (true) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f822j;
                    dh.u uVar = (dh.u) atomicReferenceFieldUpdater.get(this);
                    if (uVar.f17839c < kVar.f17839c) {
                        if (!kVar.i()) {
                            continue;
                            break;
                        }
                        while (!atomicReferenceFieldUpdater.compareAndSet(this, uVar, kVar)) {
                            if (atomicReferenceFieldUpdater.get(this) != uVar) {
                                if (kVar.e()) {
                                    kVar.d();
                                }
                            }
                        }
                        if (uVar.e()) {
                            uVar.d();
                            return;
                        }
                        return;
                    }
                    return;
                }
            }
            kVar = kVar2;
        }
    }

    public final void s(z1 z1Var, boolean z4) {
        Object m10;
        Throwable th2;
        if (z1Var instanceof g) {
            e eVar = (e) z1Var;
            if (z4) {
                th2 = k();
            } else {
                th2 = l();
            }
            eVar.c(r0.m(th2));
        } else if (z1Var instanceof b) {
            b bVar = (b) z1Var;
            h hVar = bVar.f814b;
            r0.g(hVar);
            bVar.f814b = null;
            bVar.f813a = e.f839l;
            Throwable j3 = bVar.f815c.j();
            if (j3 == null) {
                m10 = Boolean.FALSE;
            } else {
                m10 = r0.m(j3);
            }
            hVar.c(m10);
        } else {
            throw new IllegalStateException(("Unexpected waiter: " + z1Var).toString());
        }
    }

    public final boolean t(Object obj, Object obj2) {
        n nVar = null;
        if (obj instanceof b) {
            r0.h("null cannot be cast to non-null type kotlinx.coroutines.channels.BufferedChannel.BufferedChannelIterator<E of kotlinx.coroutines.channels.BufferedChannel>", obj);
            b bVar = (b) obj;
            h hVar = bVar.f814b;
            r0.g(hVar);
            bVar.f814b = null;
            bVar.f813a = obj2;
            Boolean bool = Boolean.TRUE;
            b bVar2 = bVar.f815c.f826c;
            if (bVar2 != null) {
                nVar = l9.b(bVar2, obj2, hVar.f30295e);
            }
            return e.a(hVar, bool, nVar);
        } else if (obj instanceof g) {
            r0.h("null cannot be cast to non-null type kotlinx.coroutines.CancellableContinuation<E of kotlinx.coroutines.channels.BufferedChannel>", obj);
            g gVar = (g) obj;
            b bVar3 = this.f826c;
            if (bVar3 != null) {
                nVar = l9.b(bVar3, obj2, gVar.getContext());
            }
            return e.a(gVar, obj2, nVar);
        } else {
            throw new IllegalStateException(("Unexpected receiver type: " + obj).toString());
        }
    }

    /* JADX WARNING: type inference failed for: r2v10, types: [dh.d] */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0193, code lost:
        r3 = r3.b();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x019a, code lost:
        if (r3 != null) goto L_0x01cd;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x01d1  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x006f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String toString() {
        /*
            r16 = this;
            r0 = r16
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.util.concurrent.atomic.AtomicLongFieldUpdater r2 = f816d
            long r2 = r2.get(r0)
            r4 = 60
            long r2 = r2 >> r4
            int r3 = (int) r2
            r2 = 2
            r4 = 3
            if (r3 == r2) goto L_0x001e
            if (r3 == r4) goto L_0x0018
            goto L_0x0021
        L_0x0018:
            java.lang.String r3 = "cancelled,"
        L_0x001a:
            r1.append(r3)
            goto L_0x0021
        L_0x001e:
            java.lang.String r3 = "closed,"
            goto L_0x001a
        L_0x0021:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r5 = "capacity="
            r3.<init>(r5)
            int r5 = r0.f825b
            r3.append(r5)
            r5 = 44
            r3.append(r5)
            java.lang.String r3 = r3.toString()
            r1.append(r3)
            java.lang.String r3 = "data=["
            r1.append(r3)
            ah.k[] r3 = new ah.k[r4]
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f821i
            java.lang.Object r4 = r4.get(r0)
            r6 = 0
            r3[r6] = r4
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f820h
            java.lang.Object r4 = r4.get(r0)
            r7 = 1
            r3[r7] = r4
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f822j
            java.lang.Object r4 = r4.get(r0)
            r3[r2] = r4
            java.util.List r2 = v7.i9.B(r3)
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            java.util.Iterator r2 = r2.iterator()
        L_0x0069:
            boolean r4 = r2.hasNext()
            if (r4 == 0) goto L_0x007e
            java.lang.Object r4 = r2.next()
            r8 = r4
            ah.k r8 = (ah.k) r8
            ah.k r9 = ah.e.f828a
            if (r8 == r9) goto L_0x0069
            r3.add(r4)
            goto L_0x0069
        L_0x007e:
            java.util.Iterator r2 = r3.iterator()
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x01d1
            java.lang.Object r3 = r2.next()
            boolean r4 = r2.hasNext()
            if (r4 != 0) goto L_0x0093
            goto L_0x00ad
        L_0x0093:
            r4 = r3
            ah.k r4 = (ah.k) r4
            long r8 = r4.f17839c
        L_0x0098:
            java.lang.Object r4 = r2.next()
            r10 = r4
            ah.k r10 = (ah.k) r10
            long r10 = r10.f17839c
            int r12 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r12 <= 0) goto L_0x00a7
            r3 = r4
            r8 = r10
        L_0x00a7:
            boolean r4 = r2.hasNext()
            if (r4 != 0) goto L_0x0098
        L_0x00ad:
            ah.k r3 = (ah.k) r3
            java.util.concurrent.atomic.AtomicLongFieldUpdater r2 = f817e
            long r10 = r2.get(r0)
            long r12 = r16.m()
        L_0x00b9:
            int r2 = ah.e.f829b
            r4 = 0
        L_0x00bc:
            if (r4 >= r2) goto L_0x0193
            long r8 = r3.f17839c
            int r14 = ah.e.f829b
            long r14 = (long) r14
            long r8 = r8 * r14
            long r14 = (long) r4
            long r8 = r8 + r14
            int r14 = (r8 > r12 ? 1 : (r8 == r12 ? 0 : -1))
            if (r14 < 0) goto L_0x00cf
            int r15 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r15 >= 0) goto L_0x019c
        L_0x00cf:
            java.lang.Object r15 = r3.k(r4)
            java.util.concurrent.atomic.AtomicReferenceArray r6 = r3.f853f
            int r7 = r4 * 2
            java.lang.Object r6 = r6.get(r7)
            boolean r7 = r15 instanceof yg.g
            if (r7 == 0) goto L_0x00f5
            int r7 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r7 >= 0) goto L_0x00e9
            if (r14 < 0) goto L_0x00e9
            java.lang.String r7 = "receive"
            goto L_0x015e
        L_0x00e9:
            if (r14 >= 0) goto L_0x00f1
            if (r7 < 0) goto L_0x00f1
            java.lang.String r7 = "send"
            goto L_0x015e
        L_0x00f1:
            java.lang.String r7 = "cont"
            goto L_0x015e
        L_0x00f5:
            boolean r7 = r15 instanceof ah.o
            if (r7 == 0) goto L_0x010d
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r8 = "EB("
            r7.<init>(r8)
            r7.append(r15)
            r8 = 41
            r7.append(r8)
            java.lang.String r7 = r7.toString()
            goto L_0x015e
        L_0x010d:
            dh.w r7 = ah.e.f833f
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0116
            goto L_0x011e
        L_0x0116:
            dh.w r7 = ah.e.f834g
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0121
        L_0x011e:
            java.lang.String r7 = "resuming_sender"
            goto L_0x015e
        L_0x0121:
            if (r15 != 0) goto L_0x0125
            goto L_0x018d
        L_0x0125:
            dh.w r7 = ah.e.f832e
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x012e
            goto L_0x018d
        L_0x012e:
            dh.w r7 = ah.e.f836i
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0137
            goto L_0x018d
        L_0x0137:
            dh.w r7 = ah.e.f835h
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0140
            goto L_0x018d
        L_0x0140:
            dh.w r7 = ah.e.f838k
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0149
            goto L_0x018d
        L_0x0149:
            dh.w r7 = ah.e.f837j
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 == 0) goto L_0x0152
            goto L_0x018d
        L_0x0152:
            dh.w r7 = ah.e.f839l
            boolean r7 = v7.r0.b(r15, r7)
            if (r7 != 0) goto L_0x018d
            java.lang.String r7 = r15.toString()
        L_0x015e:
            if (r6 == 0) goto L_0x017d
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            java.lang.String r9 = "("
            r8.<init>(r9)
            r8.append(r7)
            r8.append(r5)
            r8.append(r6)
            java.lang.String r6 = "),"
            r8.append(r6)
            java.lang.String r6 = r8.toString()
        L_0x0179:
            r1.append(r6)
            goto L_0x018d
        L_0x017d:
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            r6.append(r7)
            r6.append(r5)
            java.lang.String r6 = r6.toString()
            goto L_0x0179
        L_0x018d:
            int r4 = r4 + 1
            r6 = 0
            r7 = 1
            goto L_0x00bc
        L_0x0193:
            dh.d r2 = r3.b()
            r3 = r2
            ah.k r3 = (ah.k) r3
            if (r3 != 0) goto L_0x01cd
        L_0x019c:
            int r2 = r1.length()
            if (r2 == 0) goto L_0x01c5
            int r2 = wg.k.D(r1)
            char r2 = r1.charAt(r2)
            if (r2 != r5) goto L_0x01bb
            int r2 = r1.length()
            r4 = 1
            int r2 = r2 - r4
            java.lang.StringBuilder r2 = r1.deleteCharAt(r2)
            java.lang.String r3 = "deleteCharAt(...)"
            v7.r0.i(r3, r2)
        L_0x01bb:
            java.lang.String r2 = "]"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            return r1
        L_0x01c5:
            java.util.NoSuchElementException r1 = new java.util.NoSuchElementException
            java.lang.String r2 = "Char sequence is empty."
            r1.<init>(r2)
            throw r1
        L_0x01cd:
            r6 = 0
            r7 = 1
            goto L_0x00b9
        L_0x01d1:
            java.util.NoSuchElementException r1 = new java.util.NoSuchElementException
            r1.<init>()
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.c.toString():java.lang.String");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x005d, code lost:
        r12 = r2.get(r11 * 2);
        r10.m(r11, (java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:?, code lost:
        return r12;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object v(ah.k r10, int r11, long r12, java.lang.Object r14) {
        /*
            r9 = this;
            java.lang.Object r0 = r10.k(r11)
            r1 = 0
            java.util.concurrent.atomic.AtomicReferenceArray r2 = r10.f853f
            r3 = 1152921504606846975(0xfffffffffffffff, double:1.2882297539194265E-231)
            java.util.concurrent.atomic.AtomicLongFieldUpdater r5 = f816d
            if (r0 != 0) goto L_0x002a
            long r6 = r5.get(r9)
            long r6 = r6 & r3
            int r8 = (r12 > r6 ? 1 : (r12 == r6 ? 0 : -1))
            if (r8 < 0) goto L_0x0043
            if (r14 != 0) goto L_0x001e
            dh.w r10 = ah.e.f841n
            return r10
        L_0x001e:
            boolean r0 = r10.j(r0, r11, r14)
            if (r0 == 0) goto L_0x0043
            r9.h()
            dh.w r10 = ah.e.f840m
            return r10
        L_0x002a:
            dh.w r6 = ah.e.f831d
            if (r0 != r6) goto L_0x0043
            dh.w r6 = ah.e.f836i
            boolean r0 = r10.j(r0, r11, r6)
            if (r0 == 0) goto L_0x0043
            r9.h()
            int r12 = r11 * 2
            java.lang.Object r12 = r2.get(r12)
            r10.m(r11, r1)
            return r12
        L_0x0043:
            java.lang.Object r0 = r10.k(r11)
            if (r0 == 0) goto L_0x00af
            dh.w r6 = ah.e.f832e
            if (r0 != r6) goto L_0x004e
            goto L_0x00af
        L_0x004e:
            dh.w r6 = ah.e.f831d
            if (r0 != r6) goto L_0x0068
            dh.w r6 = ah.e.f836i
            boolean r0 = r10.j(r0, r11, r6)
            if (r0 == 0) goto L_0x0043
            r9.h()
        L_0x005d:
            int r12 = r11 * 2
            java.lang.Object r12 = r2.get(r12)
            r10.m(r11, r1)
            goto L_0x00d1
        L_0x0068:
            dh.w r6 = ah.e.f837j
            if (r0 != r6) goto L_0x006f
        L_0x006c:
            dh.w r12 = ah.e.f842o
            goto L_0x00d1
        L_0x006f:
            dh.w r7 = ah.e.f835h
            if (r0 != r7) goto L_0x0074
            goto L_0x006c
        L_0x0074:
            dh.w r7 = ah.e.f839l
            if (r0 != r7) goto L_0x007c
        L_0x0078:
            r9.h()
            goto L_0x006c
        L_0x007c:
            dh.w r7 = ah.e.f834g
            if (r0 == r7) goto L_0x0043
            dh.w r7 = ah.e.f833f
            boolean r7 = r10.j(r0, r11, r7)
            if (r7 == 0) goto L_0x0043
            boolean r12 = r0 instanceof ah.o
            if (r12 == 0) goto L_0x0090
            ah.o r0 = (ah.o) r0
            yg.z1 r0 = r0.f855a
        L_0x0090:
            boolean r13 = u(r0)
            if (r13 == 0) goto L_0x009f
            dh.w r12 = ah.e.f836i
            r10.n(r11, r12)
            r9.h()
            goto L_0x005d
        L_0x009f:
            r10.n(r11, r6)
            r13 = 0
            r10.l(r11, r13)
            if (r12 == 0) goto L_0x00ab
            r9.h()
        L_0x00ab:
            dh.w r10 = ah.e.f842o
            r12 = r10
            goto L_0x00d1
        L_0x00af:
            long r6 = r5.get(r9)
            long r6 = r6 & r3
            int r8 = (r12 > r6 ? 1 : (r12 == r6 ? 0 : -1))
            if (r8 >= 0) goto L_0x00c1
            dh.w r6 = ah.e.f835h
            boolean r0 = r10.j(r0, r11, r6)
            if (r0 == 0) goto L_0x0043
            goto L_0x0078
        L_0x00c1:
            if (r14 != 0) goto L_0x00c6
            dh.w r12 = ah.e.f841n
            goto L_0x00d1
        L_0x00c6:
            boolean r0 = r10.j(r0, r11, r14)
            if (r0 == 0) goto L_0x0043
            r9.h()
            dh.w r12 = ah.e.f840m
        L_0x00d1:
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: ah.c.v(ah.k, int, long, java.lang.Object):java.lang.Object");
    }

    public final int w(k kVar, int i10, Object obj, long j3, w wVar, boolean z4) {
        while (true) {
            Object k10 = kVar.k(i10);
            if (k10 == null) {
                if (!d(j3) || z4) {
                    if (z4) {
                        if (kVar.j((Object) null, i10, e.f837j)) {
                            kVar.l(i10, false);
                            return 4;
                        }
                    } else if (wVar == null) {
                        return 3;
                    } else {
                        if (kVar.j((Object) null, i10, wVar)) {
                            return 2;
                        }
                    }
                } else if (kVar.j((Object) null, i10, e.f831d)) {
                    return 1;
                }
            } else if (k10 != e.f832e) {
                w wVar2 = e.f838k;
                if (k10 == wVar2) {
                    kVar.m(i10, (Object) null);
                    return 5;
                } else if (k10 == e.f835h) {
                    kVar.m(i10, (Object) null);
                    return 5;
                } else if (k10 == e.f839l) {
                    kVar.m(i10, (Object) null);
                    f();
                    return 4;
                } else {
                    kVar.m(i10, (Object) null);
                    if (k10 instanceof o) {
                        k10 = ((o) k10).f855a;
                    }
                    if (t(k10, obj)) {
                        kVar.n(i10, e.f836i);
                        return 0;
                    }
                    if (kVar.f853f.getAndSet((i10 * 2) + 1, wVar2) != wVar2) {
                        kVar.l(i10, true);
                    }
                    return 5;
                }
            } else if (kVar.j(k10, i10, e.f831d)) {
                return 1;
            }
        }
    }

    public final void x(long j3) {
        AtomicLongFieldUpdater atomicLongFieldUpdater;
        long j10;
        boolean z4;
        long j11;
        if (!q()) {
            do {
                atomicLongFieldUpdater = f818f;
            } while (atomicLongFieldUpdater.get(this) <= j3);
            int i10 = e.f830c;
            int i11 = 0;
            while (true) {
                AtomicLongFieldUpdater atomicLongFieldUpdater2 = f819g;
                if (i11 < i10) {
                    long j12 = atomicLongFieldUpdater.get(this);
                    if (j12 != (atomicLongFieldUpdater2.get(this) & 4611686018427387903L) || j12 != atomicLongFieldUpdater.get(this)) {
                        i11++;
                    } else {
                        return;
                    }
                } else {
                    do {
                        j10 = atomicLongFieldUpdater2.get(this);
                    } while (!atomicLongFieldUpdater2.compareAndSet(this, j10, 4611686018427387904L + (j10 & 4611686018427387903L)));
                    while (true) {
                        long j13 = atomicLongFieldUpdater.get(this);
                        long j14 = atomicLongFieldUpdater2.get(this);
                        long j15 = j14 & 4611686018427387903L;
                        if ((j14 & 4611686018427387904L) != 0) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        if (j13 == j15 && j13 == atomicLongFieldUpdater.get(this)) {
                            break;
                        } else if (!z4) {
                            atomicLongFieldUpdater2.compareAndSet(this, j14, j15 + 4611686018427387904L);
                        }
                    }
                    do {
                        j11 = atomicLongFieldUpdater2.get(this);
                    } while (!atomicLongFieldUpdater2.compareAndSet(this, j11, j11 & 4611686018427387903L));
                    return;
                }
            }
        }
    }
}
