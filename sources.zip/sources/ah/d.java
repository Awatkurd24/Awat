package ah;

import ge.c;
import he.i;
import v7.r0;

public final /* synthetic */ class d extends i implements c {

    /* renamed from: j  reason: collision with root package name */
    public static final d f827j = new i(2, e.class, "createSegment", "createSegment(JLkotlinx/coroutines/channels/ChannelSegment;)Lkotlinx/coroutines/channels/ChannelSegment;", 1);

    public final Object g(Object obj, Object obj2) {
        long longValue = ((Number) obj).longValue();
        k kVar = (k) obj2;
        k kVar2 = e.f828a;
        c cVar = kVar.f852e;
        r0.g(cVar);
        return new k(longValue, kVar, cVar, 0);
    }
}
