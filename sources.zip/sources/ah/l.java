package ah;

import java.util.NoSuchElementException;

public final class l extends NoSuchElementException {
}
