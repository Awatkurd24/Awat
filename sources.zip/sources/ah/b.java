package ah;

import a2.n;
import ae.a;
import androidx.window.layout.i0;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import dh.u;
import dh.v;
import dh.w;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import v7.l9;
import v7.r0;
import yg.h;
import yg.z1;
import zd.j;

public final class b implements z1 {

    /* renamed from: a  reason: collision with root package name */
    public Object f813a = e.f843p;

    /* renamed from: b  reason: collision with root package name */
    public h f814b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ c f815c;

    public b(c cVar) {
        this.f815c = cVar;
    }

    public final void a(u uVar, int i10) {
        h hVar = this.f814b;
        if (hVar != null) {
            hVar.a(uVar, i10);
        }
    }

    public final Object b(i0 i0Var) {
        k kVar;
        h hVar;
        Boolean bool;
        Object m10;
        k kVar2;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = c.f821i;
        c cVar = this.f815c;
        k kVar3 = (k) atomicReferenceFieldUpdater.get(cVar);
        while (true) {
            cVar.getClass();
            if (cVar.o(c.f816d.get(cVar), true)) {
                this.f813a = e.f839l;
                Throwable j3 = cVar.j();
                if (j3 == null) {
                    return Boolean.FALSE;
                }
                int i10 = v.f17840a;
                throw j3;
            }
            long andIncrement = c.f817e.getAndIncrement(cVar);
            long j10 = (long) e.f829b;
            long j11 = andIncrement / j10;
            int i11 = (int) (andIncrement % j10);
            if (kVar3.f17839c != j11) {
                k i12 = cVar.i(j11, kVar3);
                if (i12 == null) {
                    continue;
                } else {
                    kVar = i12;
                }
            } else {
                kVar = kVar3;
            }
            Object v10 = cVar.v(kVar, i11, andIncrement, (Object) null);
            w wVar = e.f840m;
            if (v10 != wVar) {
                w wVar2 = e.f842o;
                if (v10 == wVar2) {
                    if (andIncrement < cVar.m()) {
                        kVar.a();
                    }
                    kVar3 = kVar;
                } else if (v10 == e.f841n) {
                    c cVar2 = this.f815c;
                    h G0 = b0.G0(r0.s(i0Var));
                    try {
                        this.f814b = G0;
                        hVar = G0;
                        try {
                            Object v11 = cVar2.v(kVar, i11, andIncrement, this);
                            if (v11 == wVar) {
                                a(kVar, i11);
                            } else {
                                n nVar = null;
                                j jVar = hVar.f30295e;
                                ge.b bVar = cVar2.f826c;
                                if (v11 == wVar2) {
                                    if (andIncrement < cVar2.m()) {
                                        kVar.a();
                                    }
                                    k kVar4 = (k) c.f821i.get(cVar2);
                                    while (true) {
                                        if (cVar2.o(c.f816d.get(cVar2), true)) {
                                            h hVar2 = this.f814b;
                                            r0.g(hVar2);
                                            this.f814b = null;
                                            this.f813a = e.f839l;
                                            Throwable j12 = cVar.j();
                                            if (j12 == null) {
                                                m10 = Boolean.FALSE;
                                            } else {
                                                m10 = r0.m(j12);
                                            }
                                            hVar2.c(m10);
                                        } else {
                                            long andIncrement2 = c.f817e.getAndIncrement(cVar2);
                                            long j13 = (long) e.f829b;
                                            long j14 = andIncrement2 / j13;
                                            int i13 = (int) (andIncrement2 % j13);
                                            if (kVar4.f17839c != j14) {
                                                k i14 = cVar2.i(j14, kVar4);
                                                if (i14 != null) {
                                                    kVar2 = i14;
                                                }
                                            } else {
                                                kVar2 = kVar4;
                                            }
                                            ge.b bVar2 = bVar;
                                            Object v12 = cVar2.v(kVar2, i13, andIncrement2, this);
                                            if (v12 == e.f840m) {
                                                a(kVar2, i13);
                                                break;
                                            } else if (v12 == e.f842o) {
                                                if (andIncrement2 < cVar2.m()) {
                                                    kVar2.a();
                                                }
                                                bVar = bVar2;
                                                kVar4 = kVar2;
                                            } else if (v12 != e.f841n) {
                                                kVar2.a();
                                                this.f813a = v12;
                                                this.f814b = null;
                                                bool = Boolean.TRUE;
                                                if (bVar2 != null) {
                                                    nVar = l9.b(bVar2, v12, jVar);
                                                }
                                            } else {
                                                throw new IllegalStateException("unexpected".toString());
                                            }
                                        }
                                    }
                                } else {
                                    ge.b bVar3 = bVar;
                                    kVar.a();
                                    this.f813a = v11;
                                    this.f814b = null;
                                    bool = Boolean.TRUE;
                                    if (bVar3 != null) {
                                        nVar = l9.b(bVar3, v11, jVar);
                                    }
                                }
                                hVar.C(nVar, bool);
                            }
                            Object t10 = hVar.t();
                            if (t10 == a.f795a) {
                                b0.t1(i0Var);
                            }
                            return t10;
                        } catch (Throwable th2) {
                            th = th2;
                            hVar.B();
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        hVar = G0;
                        hVar.B();
                        throw th;
                    }
                } else {
                    kVar.a();
                    this.f813a = v10;
                    return Boolean.TRUE;
                }
            } else {
                throw new IllegalStateException("unreachable".toString());
            }
        }
    }
}
