package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.a0;
import androidx.lifecycle.p;
import androidx.lifecycle.r;
import androidx.lifecycle.y;
import co.vpn.plusvpn.R;
import d3.e;
import d3.f;
import d3.g;
import v7.r0;
import w7.ua;

public class q extends Dialog implements y, e0, g {

    /* renamed from: a  reason: collision with root package name */
    public a0 f940a;

    /* renamed from: b  reason: collision with root package name */
    public final f f941b = f9.f.e(this);

    /* renamed from: c  reason: collision with root package name */
    public final d0 f942c = new d0(new d(2, this));

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public q(Context context, int i10) {
        super(context, i10);
        r0.j("context", context);
    }

    public static void a(q qVar) {
        r0.j("this$0", qVar);
        super.onBackPressed();
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        r0.j("view", view);
        c();
        super.addContentView(view, layoutParams);
    }

    public final a0 b() {
        a0 a0Var = this.f940a;
        if (a0Var != null) {
            return a0Var;
        }
        a0 a0Var2 = new a0(this);
        this.f940a = a0Var2;
        return a0Var2;
    }

    public final void c() {
        Window window = getWindow();
        r0.g(window);
        View decorView = window.getDecorView();
        r0.i("window!!.decorView", decorView);
        ua.q(decorView, this);
        Window window2 = getWindow();
        r0.g(window2);
        View decorView2 = window2.getDecorView();
        r0.i("window!!.decorView", decorView2);
        decorView2.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        Window window3 = getWindow();
        r0.g(window3);
        View decorView3 = window3.getDecorView();
        r0.i("window!!.decorView", decorView3);
        c0.g.i(decorView3, this);
    }

    public final r getLifecycle() {
        return b();
    }

    public final d0 getOnBackPressedDispatcher() {
        return this.f942c;
    }

    public final e getSavedStateRegistry() {
        return this.f941b.f17660b;
    }

    public final void onBackPressed() {
        this.f942c.b();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher j3 = getOnBackInvokedDispatcher();
            r0.i("onBackInvokedDispatcher", j3);
            d0 d0Var = this.f942c;
            d0Var.getClass();
            d0Var.f922e = j3;
            d0Var.c(d0Var.f924g);
        }
        this.f941b.b(bundle);
        b().f(p.ON_CREATE);
    }

    public final Bundle onSaveInstanceState() {
        Bundle onSaveInstanceState = super.onSaveInstanceState();
        r0.i("super.onSaveInstanceState()", onSaveInstanceState);
        this.f941b.c(onSaveInstanceState);
        return onSaveInstanceState;
    }

    public void onStart() {
        super.onStart();
        b().f(p.ON_RESUME);
    }

    public void onStop() {
        b().f(p.ON_DESTROY);
        this.f940a = null;
        super.onStop();
    }

    public void setContentView(int i10) {
        c();
        super.setContentView(i10);
    }

    public void setContentView(View view) {
        r0.j("view", view);
        c();
        super.setContentView(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        r0.j("view", view);
        c();
        super.setContentView(view, layoutParams);
    }
}
