package androidx.activity;

import ge.a;
import he.l;
import java.util.ListIterator;
import wd.m;
import xd.h;

public final class v extends l implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f959a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d0 f960b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ v(d0 d0Var, int i10) {
        super(0);
        this.f959a = i10;
        this.f960b = d0Var;
    }

    public final void a() {
        Object obj;
        int i10 = this.f959a;
        d0 d0Var = this.f960b;
        switch (i10) {
            case 0:
                d0Var.b();
                return;
            case 1:
                t tVar = d0Var.f920c;
                if (tVar == null) {
                    h hVar = d0Var.f919b;
                    ListIterator listIterator = hVar.listIterator(hVar.f());
                    while (true) {
                        if (listIterator.hasPrevious()) {
                            obj = listIterator.previous();
                            if (((t) obj).isEnabled()) {
                            }
                        } else {
                            obj = null;
                        }
                    }
                    tVar = (t) obj;
                }
                d0Var.f920c = null;
                if (tVar != null) {
                    tVar.handleOnBackCancelled();
                    return;
                }
                return;
            default:
                d0Var.b();
                return;
        }
    }

    public final /* bridge */ /* synthetic */ Object invoke() {
        m mVar = m.f29306a;
        switch (this.f959a) {
            case 0:
                a();
                return mVar;
            case 1:
                a();
                return mVar;
            default:
                a();
                return mVar;
        }
    }
}
