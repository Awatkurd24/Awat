package androidx.activity;

import android.os.Bundle;
import androidx.fragment.app.d0;
import androidx.fragment.app.t0;
import d3.d;

public final /* synthetic */ class f implements d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f926a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f927b;

    public /* synthetic */ f(int i10, Object obj) {
        this.f926a = i10;
        this.f927b = obj;
    }

    public final Bundle a() {
        int i10 = this.f926a;
        Object obj = this.f927b;
        switch (i10) {
            case 0:
                return o.a((o) obj);
            case 1:
                return d0.d((d0) obj);
            default:
                return ((t0) obj).T();
        }
    }
}
