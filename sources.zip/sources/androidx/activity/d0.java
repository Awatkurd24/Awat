package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.lifecycle.y;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import v7.r0;
import xd.h;

public final class d0 {

    /* renamed from: a  reason: collision with root package name */
    public final Runnable f918a;

    /* renamed from: b  reason: collision with root package name */
    public final h f919b = new h();

    /* renamed from: c  reason: collision with root package name */
    public t f920c;

    /* renamed from: d  reason: collision with root package name */
    public final OnBackInvokedCallback f921d;

    /* renamed from: e  reason: collision with root package name */
    public OnBackInvokedDispatcher f922e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f923f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f924g;

    public d0(Runnable runnable) {
        OnBackInvokedCallback onBackInvokedCallback;
        this.f918a = runnable;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 33) {
            if (i10 >= 34) {
                onBackInvokedCallback = z.f968a.a(new u(this, 0), new u(this, 1), new v(this, 0), new v(this, 1));
            } else {
                onBackInvokedCallback = x.f963a.a(new v(this, 2));
            }
            this.f921d = onBackInvokedCallback;
        }
    }

    public final void a(y yVar, t tVar) {
        r0.j("owner", yVar);
        r0.j("onBackPressedCallback", tVar);
        r lifecycle = yVar.getLifecycle();
        if (lifecycle.b() != q.f2453a) {
            tVar.addCancellable(new a0(this, lifecycle, tVar));
            d();
            tVar.setEnabledChangedCallback$activity_release(new c0(0, this));
        }
    }

    public final void b() {
        Object obj;
        t tVar = this.f920c;
        if (tVar == null) {
            h hVar = this.f919b;
            ListIterator listIterator = hVar.listIterator(hVar.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    obj = null;
                    break;
                }
                obj = listIterator.previous();
                if (((t) obj).isEnabled()) {
                    break;
                }
            }
            tVar = (t) obj;
        }
        this.f920c = null;
        if (tVar != null) {
            tVar.handleOnBackPressed();
            return;
        }
        Runnable runnable = this.f918a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void c(boolean z4) {
        OnBackInvokedCallback onBackInvokedCallback;
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f922e;
        if (onBackInvokedDispatcher != null && (onBackInvokedCallback = this.f921d) != null) {
            x xVar = x.f963a;
            if (z4 && !this.f923f) {
                xVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
                this.f923f = true;
            } else if (!z4 && this.f923f) {
                xVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
                this.f923f = false;
            }
        }
    }

    public final void d() {
        boolean z4 = this.f924g;
        h hVar = this.f919b;
        boolean z10 = false;
        if (!(hVar instanceof Collection) || !hVar.isEmpty()) {
            Iterator it = hVar.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((t) it.next()).isEnabled()) {
                        z10 = true;
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        this.f924g = z10;
        if (z10 != z4 && Build.VERSION.SDK_INT >= 33) {
            c(z10);
        }
    }
}
