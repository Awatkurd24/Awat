package androidx.activity;

import androidx.lifecycle.p;
import androidx.lifecycle.r;
import androidx.lifecycle.w;
import androidx.lifecycle.y;
import v7.r0;

public final class a0 implements w, c {

    /* renamed from: a  reason: collision with root package name */
    public final r f905a;

    /* renamed from: b  reason: collision with root package name */
    public final t f906b;

    /* renamed from: c  reason: collision with root package name */
    public b0 f907c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ d0 f908d;

    public a0(d0 d0Var, r rVar, t tVar) {
        r0.j("onBackPressedCallback", tVar);
        this.f908d = d0Var;
        this.f905a = rVar;
        this.f906b = tVar;
        rVar.a(this);
    }

    public final void cancel() {
        this.f905a.c(this);
        this.f906b.removeCancellable(this);
        b0 b0Var = this.f907c;
        if (b0Var != null) {
            b0Var.cancel();
        }
        this.f907c = null;
    }

    public final void p(y yVar, p pVar) {
        if (pVar == p.ON_START) {
            d0 d0Var = this.f908d;
            d0Var.getClass();
            t tVar = this.f906b;
            r0.j("onBackPressedCallback", tVar);
            d0Var.f919b.m(tVar);
            b0 b0Var = new b0(d0Var, tVar);
            tVar.addCancellable(b0Var);
            d0Var.d();
            tVar.setEnabledChangedCallback$activity_release(new c0(1, d0Var));
            this.f907c = b0Var;
        } else if (pVar == p.ON_STOP) {
            b0 b0Var2 = this.f907c;
            if (b0Var2 != null) {
                b0Var2.cancel();
            }
        } else if (pVar == p.ON_DESTROY) {
            cancel();
        }
    }
}
