package androidx.activity;

import a3.l;
import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Handler;
import androidx.fragment.app.b1;
import androidx.lifecycle.p0;
import androidx.work.CoroutineWorker;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import androidx.work.multiprocess.RemoteCoroutineWorker;
import c4.j;
import co.dev.ui.ConnectedActivity;
import com.tencent.mmkv.MMKV;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.databinding.ActivityConnectedBinding;
import com.v2ray.ang.dto.V2rayConfig;
import g1.h;
import g1.i;
import ha.c;
import i1.m;
import io.tooldroid.dialog.ToolDroidDialog;
import j0.q;
import j0.r;
import j0.s;
import j0.v;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.concurrent.CancellationException;
import r3.p;
import r3.u;
import s3.z;
import t.a2;
import t.c1;
import t.c2;
import t.h0;
import t.t;
import t.w;
import t.x;
import t.y;
import u.a0;
import u.f;
import v7.i9;
import v7.je;
import v7.r0;
import w7.ua;
import y9.a;
import yg.k1;
import z.g1;
import z.m0;
import z.t0;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f916a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f917b;

    public /* synthetic */ d(int i10, Object obj) {
        this.f916a = i10;
        this.f917b = obj;
    }

    private final void a() {
        m0 m0Var = (m0) this.f917b;
        synchronized (m0Var.f30473u) {
            try {
                m0Var.f30475w = null;
                t0 t0Var = m0Var.f30474v;
                if (t0Var != null) {
                    m0Var.f30474v = null;
                    m0Var.f(t0Var);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    private final void b() {
        l lVar = (l) this.f917b;
        synchronized (lVar.f474l) {
            lVar.f469g = false;
            lVar.f471i.d();
        }
    }

    public final void run() {
        boolean z4;
        Application application;
        i iVar;
        Handler handler;
        j jVar;
        p pVar;
        MMKV h10;
        boolean z10 = false;
        switch (this.f916a) {
            case 0:
                ((o) this.f917b).invalidateMenu();
                return;
            case 1:
                n nVar = (n) this.f917b;
                Runnable runnable = nVar.f937b;
                if (runnable != null) {
                    runnable.run();
                    nVar.f937b = null;
                    return;
                }
                return;
            case 2:
                q.a((q) this.f917b);
                return;
            case 4:
                ((b0.i) this.f917b).a();
                return;
            case 5:
                w wVar = (w) this.f917b;
                if (!wVar.f26424b) {
                    if (((x) wVar.f26426d).f26433f.f26464z == 7) {
                        z10 = true;
                    }
                    ua.g((String) null, z10);
                    boolean c10 = ((x) wVar.f26426d).c();
                    y yVar = ((x) wVar.f26426d).f26433f;
                    if (c10) {
                        yVar.I(true);
                        return;
                    } else {
                        yVar.J(true);
                        return;
                    }
                } else {
                    return;
                }
            case 6:
                ((h0) this.f917b).a();
                return;
            case 7:
                int i10 = c1.f26202c;
                for (a2 a2Var : (LinkedHashSet) this.f917b) {
                    a2Var.getClass();
                    a2Var.e(a2Var);
                }
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                a2 a2Var2 = (a2) this.f917b;
                a2Var2.i(a2Var2);
                return;
            case 9:
                c2.t((c2) this.f917b);
                return;
            case 10:
                f.a(((a0) this.f917b).f26884b);
                return;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                a();
                return;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                t tVar = (t) ((b0.w) this.f917b);
                if (tVar.f26395c.f26464z == 2) {
                    tVar.f26395c.J(false);
                    return;
                }
                return;
            case 13:
                c cVar = (c) this.f917b;
                if (((y) cVar.f19652b).f26464z == 4) {
                    ((y) cVar.f19652b).A();
                    return;
                }
                return;
            case 14:
                ((a) this.f917b).cancel(true);
                return;
            case 15:
                ((s) ((g1) this.f917b)).close();
                return;
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                j0.j jVar2 = (j0.j) this.f917b;
                jVar2.f20493j = true;
                jVar2.a();
                return;
            case ToolDroidDialog.CENTER /*17*/:
                ((t0.j) this.f917b).b(new Exception("Failed to snapshot: OpenGLRenderer not ready."));
                return;
            case 18:
                ((q) this.f917b).b();
                return;
            case 19:
                v vVar = (v) ((a4.i) this.f917b).f551c;
                if (vVar != null) {
                    for (r rVar : vVar.values()) {
                        rVar.getClass();
                        je.a();
                        rVar.c();
                        rVar.f20546n = true;
                    }
                    return;
                }
                return;
            case 21:
                Activity activity = (Activity) this.f917b;
                int i11 = h.f18951c;
                if (!activity.isFinishing()) {
                    int i12 = Build.VERSION.SDK_INT;
                    if (i12 >= 28) {
                        Class cls = g1.j.f18958a;
                        activity.recreate();
                        return;
                    }
                    Class cls2 = g1.j.f18958a;
                    if (i12 == 26 || i12 == 27) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Method method = g1.j.f18963f;
                    if ((!z4 || method != null) && !(g1.j.f18962e == null && g1.j.f18961d == null)) {
                        try {
                            Object obj = g1.j.f18960c.get(activity);
                            if (obj != null) {
                                Object obj2 = g1.j.f18959b.get(activity);
                                if (obj2 != null) {
                                    application = activity.getApplication();
                                    iVar = new i(activity);
                                    application.registerActivityLifecycleCallbacks(iVar);
                                    handler = g1.j.f18964g;
                                    handler.post(new androidx.appcompat.widget.j((Object) iVar, obj, 5));
                                    if (i12 == 26 || i12 == 27) {
                                        Boolean bool = Boolean.FALSE;
                                        method.invoke(obj2, new Object[]{obj, null, null, 0, bool, null, null, bool, bool});
                                    } else {
                                        activity.recreate();
                                    }
                                    handler.post(new androidx.appcompat.widget.j((Object) application, (Object) iVar, 6));
                                    return;
                                }
                            }
                        } catch (Throwable unused) {
                        }
                    }
                    activity.recreate();
                    return;
                }
                return;
            case 22:
                ArrayList arrayList = (ArrayList) this.f917b;
                r0.j("$transitioningViews", arrayList);
                b1.a(4, arrayList);
                return;
            case 23:
                androidx.fragment.app.a0.b((androidx.fragment.app.a0) this.f917b);
                return;
            case 24:
                p0 p0Var = (p0) this.f917b;
                p0 p0Var2 = p0.f2444i;
                r0.j("this$0", p0Var);
                if (p0Var.f2446b == 0) {
                    p0Var.f2447c = true;
                    p0Var.f2450f.f(androidx.lifecycle.p.ON_PAUSE);
                }
                if (p0Var.f2445a == 0 && p0Var.f2447c) {
                    p0Var.f2450f.f(androidx.lifecycle.p.ON_STOP);
                    p0Var.f2448d = true;
                    return;
                }
                return;
            case 25:
                b();
                return;
            case 26:
                CoroutineWorker.a((CoroutineWorker) this.f917b);
                return;
            case 27:
                ConstraintTrackingWorker constraintTrackingWorker = (ConstraintTrackingWorker) this.f917b;
                r0.j("this$0", constraintTrackingWorker);
                if (!(constraintTrackingWorker.f3230d.f4001a instanceof c4.a)) {
                    String b5 = constraintTrackingWorker.getInputData().b("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
                    u e10 = u.e();
                    r0.i("get()", e10);
                    if (b5 == null || b5.length() == 0) {
                        e10.c(e4.a.f17939a, "No worker to delegate to.");
                        jVar = constraintTrackingWorker.f3230d;
                        r0.i("future", jVar);
                        pVar = new p(r3.j.f25369c);
                    } else {
                        r3.t a10 = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), b5, constraintTrackingWorker.f3227a);
                        constraintTrackingWorker.f3231e = a10;
                        if (a10 == null) {
                            e10.a(e4.a.f17939a, "No worker to delegate to.");
                            jVar = constraintTrackingWorker.f3230d;
                            r0.i("future", jVar);
                            pVar = new p(r3.j.f25369c);
                        } else {
                            z o10 = z.o(constraintTrackingWorker.getApplicationContext());
                            r0.i("getInstance(applicationContext)", o10);
                            a4.u v10 = o10.f25873c.v();
                            String uuid = constraintTrackingWorker.getId().toString();
                            r0.i("id.toString()", uuid);
                            a4.s j3 = v10.j(uuid);
                            if (j3 == null) {
                                jVar = constraintTrackingWorker.f3230d;
                                r0.i("future", jVar);
                                String str = e4.a.f17939a;
                                pVar = new p(r3.j.f25369c);
                            } else {
                                a4.p pVar2 = o10.f25881k;
                                r0.i("workManagerImpl.trackers", pVar2);
                                w3.c cVar2 = new w3.c(pVar2, constraintTrackingWorker);
                                cVar2.c(i9.A(j3));
                                String uuid2 = constraintTrackingWorker.getId().toString();
                                r0.i("id.toString()", uuid2);
                                if (cVar2.a(uuid2)) {
                                    e10.a(e4.a.f17939a, "Constraints met for delegate ".concat(b5));
                                    try {
                                        r3.t tVar2 = constraintTrackingWorker.f3231e;
                                        r0.g(tVar2);
                                        a startWork = tVar2.startWork();
                                        r0.i("delegate!!.startWork()", startWork);
                                        startWork.a(new m(constraintTrackingWorker, 11, startWork), constraintTrackingWorker.getBackgroundExecutor());
                                        return;
                                    } catch (Throwable th2) {
                                        throw th2;
                                    }
                                } else {
                                    String str2 = e4.a.f17939a;
                                    e10.a(str2, "Constraints not met for delegate " + b5 + ". Requesting retry.");
                                    j jVar3 = constraintTrackingWorker.f3230d;
                                    r0.i("future", jVar3);
                                    jVar3.j(new Object());
                                    return;
                                }
                            }
                        }
                    }
                    jVar.j(pVar);
                    return;
                }
                return;
            case 28:
                RemoteCoroutineWorker remoteCoroutineWorker = (RemoteCoroutineWorker) this.f917b;
                int i13 = RemoteCoroutineWorker.f3232g;
                r0.j("this$0", remoteCoroutineWorker);
                if (remoteCoroutineWorker.f3234f.f4001a instanceof c4.a) {
                    ((k1) remoteCoroutineWorker.f3233e).h((CancellationException) null);
                    return;
                }
                return;
            default:
                ConnectedActivity connectedActivity = (ConnectedActivity) this.f917b;
                r0.j("this$0", connectedActivity);
                if (Build.VERSION.SDK_INT >= 24) {
                    ActivityConnectedBinding access$getBinding$p = connectedActivity.binding;
                    if (access$getBinding$p != null) {
                        access$getBinding$p.checkProgressBar.setProgress(connectedActivity.getProgressStep(), true);
                    } else {
                        r0.D("binding");
                        throw null;
                    }
                } else {
                    ActivityConnectedBinding access$getBinding$p2 = connectedActivity.binding;
                    if (access$getBinding$p2 != null) {
                        access$getBinding$p2.checkProgressBar.setProgress(connectedActivity.getProgressStep());
                    } else {
                        r0.D("binding");
                        throw null;
                    }
                }
                if (connectedActivity.getProgressStep() >= connectedActivity.duration) {
                    if (connectedActivity.getSuccessJobs().isEmpty() && (h10 = k4.d.h()) != null && h10.c("connectedActivityStopOnFail", false)) {
                        connectedActivity.disconnect();
                    }
                    connectedActivity.calculateToFinish();
                    return;
                }
                return;
        }
    }
}
