package androidx.activity;

import a4.f;
import a4.l;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.activity.result.IntentSenderRequest;
import androidx.fragment.app.d0;
import c.d;
import e.g;
import f.a;
import g1.c;
import java.util.Arrays;
import java.util.HashSet;

public final class h extends g {

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ o f930h;

    public h(d0 d0Var) {
        this.f930h = d0Var;
    }

    public final void b(int i10, a aVar, Object obj) {
        Bundle bundle;
        String[] strArr;
        o oVar = this.f930h;
        f b5 = aVar.b(oVar, obj);
        if (b5 != null) {
            new Handler(Looper.getMainLooper()).post(new d((Object) this, i10, (Object) b5, 1));
            return;
        }
        Intent a10 = aVar.a(oVar, obj);
        if (a10.getExtras() != null && a10.getExtras().getClassLoader() == null) {
            a10.setExtrasClassLoader(oVar.getClassLoader());
        }
        if (a10.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
            Bundle bundleExtra = a10.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            a10.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            bundle = bundleExtra;
        } else {
            bundle = null;
        }
        if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(a10.getAction())) {
            String[] stringArrayExtra = a10.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
            if (stringArrayExtra == null) {
                stringArrayExtra = new String[0];
            }
            int i11 = g1.h.f18951c;
            HashSet hashSet = new HashSet();
            int i12 = 0;
            while (i12 < stringArrayExtra.length) {
                if (!TextUtils.isEmpty(stringArrayExtra[i12])) {
                    if (Build.VERSION.SDK_INT < 33 && TextUtils.equals(stringArrayExtra[i12], "android.permission.POST_NOTIFICATIONS")) {
                        hashSet.add(Integer.valueOf(i12));
                    }
                    i12++;
                } else {
                    throw new IllegalArgumentException(l.J(new StringBuilder("Permission request for permissions "), Arrays.toString(stringArrayExtra), " must not contain null or empty values"));
                }
            }
            int size = hashSet.size();
            if (size > 0) {
                strArr = new String[(stringArrayExtra.length - size)];
            } else {
                strArr = stringArrayExtra;
            }
            if (size > 0) {
                if (size != stringArrayExtra.length) {
                    int i13 = 0;
                    for (int i14 = 0; i14 < stringArrayExtra.length; i14++) {
                        if (!hashSet.contains(Integer.valueOf(i14))) {
                            strArr[i13] = stringArrayExtra[i14];
                            i13++;
                        }
                    }
                } else {
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= 23) {
                if (oVar instanceof g1.g) {
                    ((g1.g) oVar).validateRequestPermissionsRequestCode(i10);
                }
                c.b(oVar, stringArrayExtra, i10);
            } else if (oVar instanceof g1.f) {
                new Handler(Looper.getMainLooper()).post(new d((Object) strArr, (Object) oVar, i10, 5));
            }
        } else if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(a10.getAction())) {
            IntentSenderRequest intentSenderRequest = (IntentSenderRequest) a10.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
            try {
                IntentSender intentSender = intentSenderRequest.f948a;
                Intent intent = intentSenderRequest.f949b;
                int i15 = intentSenderRequest.f950c;
                int i16 = intentSenderRequest.f951d;
                int i17 = g1.h.f18951c;
                g1.a.c(oVar, intentSender, i10, intent, i15, i16, 0, bundle);
            } catch (IntentSender.SendIntentException e10) {
                new Handler(Looper.getMainLooper()).post(new d((Object) this, i10, (Object) e10, 2));
            }
        } else {
            int i18 = g1.h.f18951c;
            g1.a.b(oVar, a10, i10, bundle);
        }
    }
}
