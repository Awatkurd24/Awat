package androidx.activity;

import android.hardware.camera2.params.DynamicRangeProfiles;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

public abstract /* synthetic */ class p {
    public static /* bridge */ /* synthetic */ DynamicRangeProfiles e(Object obj) {
        return (DynamicRangeProfiles) obj;
    }

    public static /* bridge */ /* synthetic */ OnBackInvokedCallback g(Object obj) {
        return (OnBackInvokedCallback) obj;
    }

    public static /* bridge */ /* synthetic */ OnBackInvokedDispatcher k(Object obj) {
        return (OnBackInvokedDispatcher) obj;
    }
}
