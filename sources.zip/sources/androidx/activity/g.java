package androidx.activity;

import android.content.Context;
import androidx.fragment.app.d0;
import d.b;

public final /* synthetic */ class g implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f928a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ o f929b;

    public /* synthetic */ g(d0 d0Var, int i10) {
        this.f928a = i10;
        this.f929b = d0Var;
    }

    public final void a(Context context) {
        int i10 = this.f928a;
        o oVar = this.f929b;
        switch (i10) {
            case 0:
                o.b(oVar);
                return;
            default:
                d0.c((d0) oVar);
                return;
        }
    }
}
