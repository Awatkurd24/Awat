package androidx.activity;

import ge.b;
import he.l;
import wd.m;

public final class u extends l implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f957a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d0 f958b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u(d0 d0Var, int i10) {
        super(1);
        this.f957a = i10;
        this.f958b = d0Var;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v0, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v3, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: androidx.activity.t} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v5, resolved type: androidx.activity.t} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(androidx.activity.b r6) {
        /*
            r5 = this;
            int r0 = r5.f957a
            r1 = 0
            androidx.activity.d0 r2 = r5.f958b
            java.lang.String r3 = "backEvent"
            switch(r0) {
                case 0: goto L_0x0038;
                default: goto L_0x000a;
            }
        L_0x000a:
            v7.r0.j(r3, r6)
            androidx.activity.t r0 = r2.f920c
            if (r0 != 0) goto L_0x0032
            xd.h r0 = r2.f919b
            int r2 = r0.f()
            java.util.ListIterator r0 = r0.listIterator(r2)
        L_0x001b:
            boolean r2 = r0.hasPrevious()
            if (r2 == 0) goto L_0x002f
            java.lang.Object r2 = r0.previous()
            r3 = r2
            androidx.activity.t r3 = (androidx.activity.t) r3
            boolean r3 = r3.isEnabled()
            if (r3 == 0) goto L_0x001b
            r1 = r2
        L_0x002f:
            r0 = r1
            androidx.activity.t r0 = (androidx.activity.t) r0
        L_0x0032:
            if (r0 == 0) goto L_0x0037
            r0.handleOnBackProgressed(r6)
        L_0x0037:
            return
        L_0x0038:
            v7.r0.j(r3, r6)
            xd.h r0 = r2.f919b
            int r3 = r0.f()
            java.util.ListIterator r0 = r0.listIterator(r3)
        L_0x0045:
            boolean r3 = r0.hasPrevious()
            if (r3 == 0) goto L_0x0059
            java.lang.Object r3 = r0.previous()
            r4 = r3
            androidx.activity.t r4 = (androidx.activity.t) r4
            boolean r4 = r4.isEnabled()
            if (r4 == 0) goto L_0x0045
            r1 = r3
        L_0x0059:
            androidx.activity.t r1 = (androidx.activity.t) r1
            r2.f920c = r1
            if (r1 == 0) goto L_0x0062
            r1.handleOnBackStarted(r6)
        L_0x0062:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.u.a(androidx.activity.b):void");
    }

    public final /* bridge */ /* synthetic */ Object h(Object obj) {
        m mVar = m.f29306a;
        switch (this.f957a) {
            case 0:
                a((b) obj);
                return mVar;
            default:
                a((b) obj);
                return mVar;
        }
    }
}
