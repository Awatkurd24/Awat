package androidx.activity;

import ge.a;
import java.util.ArrayList;
import java.util.Iterator;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public final Object f943a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public boolean f944b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList f945c = new ArrayList();

    public r(n nVar, e eVar) {
    }

    public final void a() {
        synchronized (this.f943a) {
            try {
                this.f944b = true;
                Iterator it = this.f945c.iterator();
                while (it.hasNext()) {
                    ((a) it.next()).invoke();
                }
                this.f945c.clear();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
