package androidx.activity;

import android.view.View;
import java.util.concurrent.Executor;

public interface m extends Executor {
    void q(View view);
}
