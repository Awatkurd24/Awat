package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.a;
import kotlin.Metadata;
import v7.r0;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001:\u0002\u0002\u0003¨\u0006\u0004"}, d2 = {"Landroidx/activity/result/IntentSenderRequest;", "Landroid/os/Parcelable;", "e/i", "w7/wa", "activity_release"}, k = 1, mv = {1, 8, 0})
@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new a(11);

    /* renamed from: a  reason: collision with root package name */
    public final IntentSender f948a;

    /* renamed from: b  reason: collision with root package name */
    public final Intent f949b;

    /* renamed from: c  reason: collision with root package name */
    public final int f950c;

    /* renamed from: d  reason: collision with root package name */
    public final int f951d;

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i10, int i11) {
        r0.j("intentSender", intentSender);
        this.f948a = intentSender;
        this.f949b = intent;
        this.f950c = i10;
        this.f951d = i11;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        r0.j("dest", parcel);
        parcel.writeParcelable(this.f948a, i10);
        parcel.writeParcelable(this.f949b, i10);
        parcel.writeInt(this.f950c);
        parcel.writeInt(this.f951d);
    }
}
