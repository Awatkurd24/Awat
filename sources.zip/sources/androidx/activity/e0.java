package androidx.activity;

import androidx.lifecycle.y;

public interface e0 extends y {
    d0 getOnBackPressedDispatcher();
}
