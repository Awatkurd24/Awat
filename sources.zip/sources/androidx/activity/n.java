package androidx.activity;

import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.fragment.app.d0;

public final class n implements m, ViewTreeObserver.OnDrawListener, Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final long f936a = (SystemClock.uptimeMillis() + 10000);

    /* renamed from: b  reason: collision with root package name */
    public Runnable f937b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f938c = false;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ o f939d;

    public n(d0 d0Var) {
        this.f939d = d0Var;
    }

    public final void a() {
        o oVar = this.f939d;
        oVar.getWindow().getDecorView().removeCallbacks(this);
        oVar.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }

    public final void execute(Runnable runnable) {
        this.f937b = runnable;
        View decorView = this.f939d.getWindow().getDecorView();
        if (!this.f938c) {
            decorView.postOnAnimation(new d(1, this));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    public final void onDraw() {
        boolean z4;
        Runnable runnable = this.f937b;
        if (runnable != null) {
            runnable.run();
            this.f937b = null;
            r rVar = this.f939d.mFullyDrawnReporter;
            synchronized (rVar.f943a) {
                z4 = rVar.f944b;
            }
            if (!z4) {
                return;
            }
        } else if (SystemClock.uptimeMillis() <= this.f936a) {
            return;
        }
        this.f938c = false;
        this.f939d.getWindow().getDecorView().post(this);
    }

    public final void q(View view) {
        if (!this.f938c) {
            this.f938c = true;
            view.getViewTreeObserver().addOnDrawListener(this);
        }
    }

    public final void run() {
        this.f939d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
