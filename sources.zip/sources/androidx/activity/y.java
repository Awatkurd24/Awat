package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import ge.a;
import ge.b;
import v7.r0;

public final class y implements OnBackAnimationCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f964a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ b f965b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ a f966c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ a f967d;

    public y(b bVar, b bVar2, a aVar, a aVar2) {
        this.f964a = bVar;
        this.f965b = bVar2;
        this.f966c = aVar;
        this.f967d = aVar2;
    }

    public final void onBackCancelled() {
        this.f967d.invoke();
    }

    public final void onBackInvoked() {
        this.f966c.invoke();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        r0.j("backEvent", backEvent);
        this.f965b.h(new b(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        r0.j("backEvent", backEvent);
        this.f964a.h(new b(backEvent));
    }
}
