package androidx.activity;

import android.window.OnBackInvokedCallback;
import ge.a;
import ge.b;
import v7.r0;

public final class z {

    /* renamed from: a  reason: collision with root package name */
    public static final z f968a = new Object();

    public final OnBackInvokedCallback a(b bVar, b bVar2, a aVar, a aVar2) {
        r0.j("onBackStarted", bVar);
        r0.j("onBackProgressed", bVar2);
        r0.j("onBackInvoked", aVar);
        r0.j("onBackCancelled", aVar2);
        return new y(bVar, bVar2, aVar, aVar2);
    }
}
