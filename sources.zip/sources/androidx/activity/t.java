package androidx.activity;

import ge.a;
import java.util.concurrent.CopyOnWriteArrayList;
import v7.r0;

public abstract class t {
    private final CopyOnWriteArrayList<c> cancellables = new CopyOnWriteArrayList<>();
    private a enabledChangedCallback;
    private boolean isEnabled;

    public t(boolean z4) {
        this.isEnabled = z4;
    }

    public final void addCancellable(c cVar) {
        r0.j("cancellable", cVar);
        this.cancellables.add(cVar);
    }

    public final a getEnabledChangedCallback$activity_release() {
        return this.enabledChangedCallback;
    }

    public void handleOnBackCancelled() {
    }

    public abstract void handleOnBackPressed();

    public void handleOnBackProgressed(b bVar) {
        r0.j("backEvent", bVar);
    }

    public void handleOnBackStarted(b bVar) {
        r0.j("backEvent", bVar);
    }

    public final boolean isEnabled() {
        return this.isEnabled;
    }

    public final void remove() {
        for (c cancel : this.cancellables) {
            cancel.cancel();
        }
    }

    public final void removeCancellable(c cVar) {
        r0.j("cancellable", cVar);
        this.cancellables.remove(cVar);
    }

    public final void setEnabled(boolean z4) {
        this.isEnabled = z4;
        a aVar = this.enabledChangedCallback;
        if (aVar != null) {
            aVar.invoke();
        }
    }

    public final void setEnabledChangedCallback$activity_release(a aVar) {
        this.enabledChangedCallback = aVar;
    }
}
