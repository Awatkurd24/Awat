package androidx.activity;

import androidx.fragment.app.d0;
import ge.a;

public final /* synthetic */ class e implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ o f925a;

    public /* synthetic */ e(d0 d0Var) {
        this.f925a = d0Var;
    }

    public final Object invoke() {
        this.f925a.reportFullyDrawn();
        return null;
    }
}
