package androidx.activity;

import android.text.TextUtils;

public final class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ o f933a;

    public j(o oVar) {
        this.f933a = oVar;
    }

    public final void run() {
        try {
            j.super.onBackPressed();
        } catch (IllegalStateException e10) {
            if (!TextUtils.equals(e10.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                throw e10;
            }
        } catch (NullPointerException e11) {
            if (!TextUtils.equals(e11.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                throw e11;
            }
        }
    }
}
