package androidx.activity;

import android.window.BackEvent;
import v7.r0;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final float f909a;

    /* renamed from: b  reason: collision with root package name */
    public final float f910b;

    /* renamed from: c  reason: collision with root package name */
    public final float f911c;

    /* renamed from: d  reason: collision with root package name */
    public final int f912d;

    public b(BackEvent backEvent) {
        r0.j("backEvent", backEvent);
        a aVar = a.f904a;
        float d10 = aVar.d(backEvent);
        float e10 = aVar.e(backEvent);
        float b5 = aVar.b(backEvent);
        int c10 = aVar.c(backEvent);
        this.f909a = d10;
        this.f910b = e10;
        this.f911c = b5;
        this.f912d = c10;
    }

    public final String toString() {
        return "BackEventCompat{touchX=" + this.f909a + ", touchY=" + this.f910b + ", progress=" + this.f911c + ", swipeEdge=" + this.f912d + '}';
    }
}
