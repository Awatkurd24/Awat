package androidx.activity;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import ge.a;
import v7.r0;

public final class x {

    /* renamed from: a  reason: collision with root package name */
    public static final x f963a = new Object();

    public final OnBackInvokedCallback a(a aVar) {
        r0.j("onBackInvoked", aVar);
        return new w(0, aVar);
    }

    public final void b(Object obj, int i10, Object obj2) {
        r0.j("dispatcher", obj);
        r0.j("callback", obj2);
        ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i10, (OnBackInvokedCallback) obj2);
    }

    public final void c(Object obj, Object obj2) {
        r0.j("dispatcher", obj);
        r0.j("callback", obj2);
        ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
    }
}
