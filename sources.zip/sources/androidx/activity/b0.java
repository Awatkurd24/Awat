package androidx.activity;

import ge.a;
import v7.r0;
import xd.h;

public final class b0 implements c {

    /* renamed from: a  reason: collision with root package name */
    public final t f913a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d0 f914b;

    public b0(d0 d0Var, t tVar) {
        this.f914b = d0Var;
        this.f913a = tVar;
    }

    public final void cancel() {
        d0 d0Var = this.f914b;
        h hVar = d0Var.f919b;
        t tVar = this.f913a;
        hVar.remove(tVar);
        if (r0.b(d0Var.f920c, tVar)) {
            tVar.handleOnBackCancelled();
            d0Var.f920c = null;
        }
        tVar.removeCancellable(this);
        a enabledChangedCallback$activity_release = tVar.getEnabledChangedCallback$activity_release();
        if (enabledChangedCallback$activity_release != null) {
            enabledChangedCallback$activity_release.invoke();
        }
        tVar.setEnabledChangedCallback$activity_release((a) null);
    }
}
