package androidx.activity;

import android.app.Activity;
import androidx.lifecycle.w;
import java.lang.reflect.Field;

public final class s implements w {

    /* renamed from: b  reason: collision with root package name */
    public static int f952b;

    /* renamed from: c  reason: collision with root package name */
    public static Field f953c;

    /* renamed from: d  reason: collision with root package name */
    public static Field f954d;

    /* renamed from: e  reason: collision with root package name */
    public static Field f955e;

    /* renamed from: a  reason: collision with root package name */
    public Activity f956a;

    /* JADX WARNING: Can't wrap try/catch for region: R(3:34|35|36) */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x006e, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:34:0x006d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void p(androidx.lifecycle.y r3, androidx.lifecycle.p r4) {
        /*
            r2 = this;
            androidx.lifecycle.p r3 = androidx.lifecycle.p.ON_DESTROY
            if (r4 == r3) goto L_0x0005
            return
        L_0x0005:
            int r3 = f952b
            r4 = 1
            if (r3 != 0) goto L_0x0034
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            r0 = 2
            f952b = r0     // Catch:{ NoSuchFieldException -> 0x0033 }
            java.lang.String r0 = "mServedView"
            java.lang.reflect.Field r0 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x0033 }
            f954d = r0     // Catch:{ NoSuchFieldException -> 0x0033 }
            r0.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x0033 }
            java.lang.String r0 = "mNextServedView"
            java.lang.reflect.Field r0 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x0033 }
            f955e = r0     // Catch:{ NoSuchFieldException -> 0x0033 }
            r0.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x0033 }
            java.lang.String r0 = "mH"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x0033 }
            f953c = r3     // Catch:{ NoSuchFieldException -> 0x0033 }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x0033 }
            f952b = r4     // Catch:{ NoSuchFieldException -> 0x0033 }
            goto L_0x0034
        L_0x0033:
        L_0x0034:
            int r3 = f952b
            if (r3 != r4) goto L_0x0075
            android.app.Activity r3 = r2.f956a
            java.lang.String r4 = "input_method"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.view.inputmethod.InputMethodManager r3 = (android.view.inputmethod.InputMethodManager) r3
            java.lang.reflect.Field r4 = f953c     // Catch:{ IllegalAccessException -> 0x0075 }
            java.lang.Object r4 = r4.get(r3)     // Catch:{ IllegalAccessException -> 0x0075 }
            if (r4 != 0) goto L_0x004b
            return
        L_0x004b:
            monitor-enter(r4)
            java.lang.reflect.Field r0 = f954d     // Catch:{ IllegalAccessException -> 0x0071, ClassCastException -> 0x006f }
            java.lang.Object r0 = r0.get(r3)     // Catch:{ IllegalAccessException -> 0x0071, ClassCastException -> 0x006f }
            android.view.View r0 = (android.view.View) r0     // Catch:{ IllegalAccessException -> 0x0071, ClassCastException -> 0x006f }
            if (r0 != 0) goto L_0x005a
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return
        L_0x0058:
            r3 = move-exception
            goto L_0x0073
        L_0x005a:
            boolean r0 = r0.isAttachedToWindow()     // Catch:{ all -> 0x0058 }
            if (r0 == 0) goto L_0x0062
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return
        L_0x0062:
            java.lang.reflect.Field r0 = f955e     // Catch:{ IllegalAccessException -> 0x006d }
            r1 = 0
            r0.set(r3, r1)     // Catch:{ IllegalAccessException -> 0x006d }
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            r3.isActive()
            goto L_0x0075
        L_0x006d:
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return
        L_0x006f:
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return
        L_0x0071:
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return
        L_0x0073:
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            throw r3
        L_0x0075:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.s.p(androidx.lifecycle.y, androidx.lifecycle.p):void");
    }
}
