package androidx.activity;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.p;
import androidx.lifecycle.w;
import androidx.lifecycle.y;
import v7.r0;

public final class i implements w {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f931a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ o f932b;

    public /* synthetic */ i(o oVar, int i10) {
        this.f931a = i10;
        this.f932b = oVar;
    }

    public final void p(y yVar, p pVar) {
        View view = null;
        switch (this.f931a) {
            case 0:
                if (pVar == p.ON_DESTROY) {
                    this.f932b.mContextAwareHelper.f17609b = null;
                    if (!this.f932b.isChangingConfigurations()) {
                        this.f932b.getViewModelStore().a();
                    }
                    ((n) this.f932b.mReportFullyDrawnExecutor).a();
                    return;
                }
                return;
            case 1:
                if (pVar == p.ON_STOP) {
                    Window window = this.f932b.getWindow();
                    if (window != null) {
                        view = window.peekDecorView();
                    }
                    if (view != null) {
                        view.cancelPendingInputEvents();
                        return;
                    }
                    return;
                }
                return;
            case 2:
                o oVar = this.f932b;
                oVar.ensureViewModelStore();
                oVar.getLifecycle().c(this);
                return;
            default:
                if (pVar == p.ON_CREATE && Build.VERSION.SDK_INT >= 33) {
                    d0 access$100 = this.f932b.mOnBackPressedDispatcher;
                    OnBackInvokedDispatcher a10 = k.a((o) yVar);
                    access$100.getClass();
                    r0.j("invoker", a10);
                    access$100.f922e = a10;
                    access$100.c(access$100.f924g);
                    return;
                }
                return;
        }
    }
}
