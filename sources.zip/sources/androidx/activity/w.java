package androidx.activity;

import android.window.OnBackInvokedCallback;
import ge.a;
import h.o0;
import v7.r0;
import x8.b;

public final /* synthetic */ class w implements OnBackInvokedCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f961a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f962b;

    public /* synthetic */ w(int i10, Object obj) {
        this.f961a = i10;
        this.f962b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f961a) {
            case 0:
                a aVar = (a) this.f962b;
                r0.j("$onBackInvoked", aVar);
                aVar.invoke();
                return;
            case 1:
                ((o0) this.f962b).G();
                return;
            case 2:
                ((Runnable) this.f962b).run();
                return;
            default:
                ((b) this.f962b).a();
                return;
        }
    }
}
