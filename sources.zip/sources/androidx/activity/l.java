package androidx.activity;

import androidx.lifecycle.i1;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public Object f934a;

    /* renamed from: b  reason: collision with root package name */
    public i1 f935b;
}
