package androidx.activity;

public interface c {
    void cancel();
}
