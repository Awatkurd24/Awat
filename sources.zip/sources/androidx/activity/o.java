package androidx.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.fragment.app.d0;
import androidx.fragment.app.o0;
import androidx.lifecycle.a0;
import androidx.lifecycle.a1;
import androidx.lifecycle.e1;
import androidx.lifecycle.g1;
import androidx.lifecycle.i1;
import androidx.lifecycle.j1;
import androidx.lifecycle.l;
import androidx.lifecycle.r;
import androidx.lifecycle.x0;
import androidx.lifecycle.y;
import co.vpn.plusvpn.R;
import d.a;
import d.b;
import d3.e;
import d3.f;
import d3.g;
import e.h;
import g1.n;
import g1.v0;
import g1.w0;
import h1.k;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import p2.c;
import p2.d;
import r1.p;
import r1.q;
import r1.s;
import r1.t;
import r1.v;
import v7.r0;
import w7.ua;

public abstract class o extends n implements j1, l, g, e0, h, k, h1.l, v0, w0, p {
    private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
    private final e.g mActivityResultRegistry;
    private int mContentLayoutId;
    final a mContextAwareHelper = new a();
    private g1 mDefaultFactory;
    private boolean mDispatchingOnMultiWindowModeChanged;
    private boolean mDispatchingOnPictureInPictureModeChanged;
    final r mFullyDrawnReporter;
    private final a0 mLifecycleRegistry = new a0(this);
    private final t mMenuHostHelper = new t(new d(0, this));
    private final AtomicInteger mNextLocalRequestCode;
    /* access modifiers changed from: private */
    public d0 mOnBackPressedDispatcher;
    private final CopyOnWriteArrayList<q1.a> mOnConfigurationChangedListeners;
    private final CopyOnWriteArrayList<q1.a> mOnMultiWindowModeChangedListeners;
    private final CopyOnWriteArrayList<q1.a> mOnNewIntentListeners;
    private final CopyOnWriteArrayList<q1.a> mOnPictureInPictureModeChangedListeners;
    private final CopyOnWriteArrayList<q1.a> mOnTrimMemoryListeners;
    final m mReportFullyDrawnExecutor;
    final f mSavedStateRegistryController;
    private i1 mViewModelStore;

    /* JADX WARNING: type inference failed for: r1v14, types: [androidx.lifecycle.x, androidx.activity.s, java.lang.Object] */
    public o() {
        f e10 = f9.f.e(this);
        this.mSavedStateRegistryController = e10;
        this.mOnBackPressedDispatcher = null;
        d0 d0Var = (d0) this;
        n nVar = new n(d0Var);
        this.mReportFullyDrawnExecutor = nVar;
        this.mFullyDrawnReporter = new r(nVar, new e(d0Var));
        this.mNextLocalRequestCode = new AtomicInteger();
        this.mActivityResultRegistry = new h(d0Var);
        this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<>();
        this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<>();
        this.mOnNewIntentListeners = new CopyOnWriteArrayList<>();
        this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<>();
        this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<>();
        this.mDispatchingOnMultiWindowModeChanged = false;
        this.mDispatchingOnPictureInPictureModeChanged = false;
        if (getLifecycle() != null) {
            int i10 = Build.VERSION.SDK_INT;
            getLifecycle().a(new i(this, 1));
            getLifecycle().a(new i(this, 0));
            getLifecycle().a(new i(this, 2));
            e10.a();
            x0.c(this);
            if (i10 <= 23) {
                r lifecycle = getLifecycle();
                ? obj = new Object();
                obj.f956a = this;
                lifecycle.a(obj);
            }
            getSavedStateRegistry().c(ACTIVITY_RESULT_TAG, new f(0, this));
            addOnContextAvailableListener(new g(d0Var, 0));
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    public static Bundle a(o oVar) {
        oVar.getClass();
        Bundle bundle = new Bundle();
        e.g gVar = oVar.mActivityResultRegistry;
        gVar.getClass();
        HashMap hashMap = gVar.f17863b;
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(hashMap.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(hashMap.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(gVar.f17865d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) gVar.f17868g.clone());
        return bundle;
    }

    public static void b(o oVar) {
        Bundle a10 = oVar.getSavedStateRegistry().a(ACTIVITY_RESULT_TAG);
        if (a10 != null) {
            e.g gVar = oVar.mActivityResultRegistry;
            gVar.getClass();
            ArrayList<Integer> integerArrayList = a10.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = a10.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                gVar.f17865d = a10.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                Bundle bundle = a10.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                Bundle bundle2 = gVar.f17868g;
                bundle2.putAll(bundle);
                for (int i10 = 0; i10 < stringArrayList.size(); i10++) {
                    String str = stringArrayList.get(i10);
                    HashMap hashMap = gVar.f17863b;
                    boolean containsKey = hashMap.containsKey(str);
                    HashMap hashMap2 = gVar.f17862a;
                    if (containsKey) {
                        Integer num = (Integer) hashMap.remove(str);
                        if (!bundle2.containsKey(str)) {
                            hashMap2.remove(num);
                        }
                    }
                    int intValue = integerArrayList.get(i10).intValue();
                    String str2 = stringArrayList.get(i10);
                    hashMap2.put(Integer.valueOf(intValue), str2);
                    hashMap.put(str2, Integer.valueOf(intValue));
                }
            }
        }
    }

    public void addMenuProvider(v vVar) {
        t tVar = this.mMenuHostHelper;
        tVar.f25274b.add(vVar);
        tVar.f25273a.run();
    }

    public final void addOnConfigurationChangedListener(q1.a aVar) {
        this.mOnConfigurationChangedListeners.add(aVar);
    }

    public final void addOnContextAvailableListener(b bVar) {
        a aVar = this.mContextAwareHelper;
        aVar.getClass();
        r0.j("listener", bVar);
        Context context = aVar.f17609b;
        if (context != null) {
            bVar.a(context);
        }
        aVar.f17608a.add(bVar);
    }

    public final void addOnMultiWindowModeChangedListener(q1.a aVar) {
        this.mOnMultiWindowModeChangedListeners.add(aVar);
    }

    public final void addOnNewIntentListener(q1.a aVar) {
        this.mOnNewIntentListeners.add(aVar);
    }

    public final void addOnPictureInPictureModeChangedListener(q1.a aVar) {
        this.mOnPictureInPictureModeChangedListeners.add(aVar);
    }

    public final void addOnTrimMemoryListener(q1.a aVar) {
        this.mOnTrimMemoryListeners.add(aVar);
    }

    public void ensureViewModelStore() {
        if (this.mViewModelStore == null) {
            l lVar = (l) getLastNonConfigurationInstance();
            if (lVar != null) {
                this.mViewModelStore = lVar.f935b;
            }
            if (this.mViewModelStore == null) {
                this.mViewModelStore = new i1();
            }
        }
    }

    public final e.g getActivityResultRegistry() {
        return this.mActivityResultRegistry;
    }

    public c getDefaultViewModelCreationExtras() {
        d dVar = new d();
        if (getApplication() != null) {
            dVar.a(e1.f2412a, getApplication());
        }
        dVar.a(x0.f2479a, this);
        dVar.a(x0.f2480b, this);
        if (!(getIntent() == null || getIntent().getExtras() == null)) {
            dVar.a(x0.f2481c, getIntent().getExtras());
        }
        return dVar;
    }

    public g1 getDefaultViewModelProviderFactory() {
        if (this.mDefaultFactory == null) {
            this.mDefaultFactory = new a1(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
        }
        return this.mDefaultFactory;
    }

    public r getFullyDrawnReporter() {
        return this.mFullyDrawnReporter;
    }

    @Deprecated
    public Object getLastCustomNonConfigurationInstance() {
        l lVar = (l) getLastNonConfigurationInstance();
        if (lVar != null) {
            return lVar.f934a;
        }
        return null;
    }

    public r getLifecycle() {
        return this.mLifecycleRegistry;
    }

    public final d0 getOnBackPressedDispatcher() {
        if (this.mOnBackPressedDispatcher == null) {
            this.mOnBackPressedDispatcher = new d0(new j(this));
            getLifecycle().a(new i(this, 3));
        }
        return this.mOnBackPressedDispatcher;
    }

    public final e getSavedStateRegistry() {
        return this.mSavedStateRegistryController.f17660b;
    }

    public i1 getViewModelStore() {
        if (getApplication() != null) {
            ensureViewModelStore();
            return this.mViewModelStore;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public void initializeViewTreeOwners() {
        ua.q(getWindow().getDecorView(), this);
        View decorView = getWindow().getDecorView();
        r0.j("<this>", decorView);
        decorView.setTag(R.id.view_tree_view_model_store_owner, this);
        c0.g.i(getWindow().getDecorView(), this);
        View decorView2 = getWindow().getDecorView();
        r0.j("<this>", decorView2);
        decorView2.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView3 = getWindow().getDecorView();
        r0.j("<this>", decorView3);
        decorView3.setTag(R.id.report_drawn, this);
    }

    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    public void onActivityResult(int i10, int i11, Intent intent) {
        if (!this.mActivityResultRegistry.a(i10, i11, intent)) {
            super.onActivityResult(i10, i11, intent);
        }
    }

    @Deprecated
    public void onBackPressed() {
        getOnBackPressedDispatcher().b();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator<q1.a> it = this.mOnConfigurationChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(configuration);
        }
    }

    public void onCreate(Bundle bundle) {
        this.mSavedStateRegistryController.b(bundle);
        a aVar = this.mContextAwareHelper;
        aVar.getClass();
        aVar.f17609b = this;
        Iterator it = aVar.f17608a.iterator();
        while (it.hasNext()) {
            ((b) it.next()).a(this);
        }
        super.onCreate(bundle);
        ab.d.g(this);
        int i10 = this.mContentLayoutId;
        if (i10 != 0) {
            setContentView(i10);
        }
    }

    public boolean onCreatePanelMenu(int i10, Menu menu) {
        if (i10 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i10, menu);
        t tVar = this.mMenuHostHelper;
        MenuInflater menuInflater = getMenuInflater();
        Iterator it = tVar.f25274b.iterator();
        while (it.hasNext()) {
            ((o0) ((v) it.next())).f2295a.j(menu, menuInflater);
        }
        return true;
    }

    public boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        if (super.onMenuItemSelected(i10, menuItem)) {
            return true;
        }
        if (i10 == 0) {
            return this.mMenuHostHelper.a(menuItem);
        }
        return false;
    }

    public void onMultiWindowModeChanged(boolean z4) {
        if (!this.mDispatchingOnMultiWindowModeChanged) {
            Iterator<q1.a> it = this.mOnMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new g1.o(z4));
            }
        }
    }

    public void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent intent) {
        super.onNewIntent(intent);
        Iterator<q1.a> it = this.mOnNewIntentListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(intent);
        }
    }

    public void onPanelClosed(int i10, Menu menu) {
        Iterator it = this.mMenuHostHelper.f25274b.iterator();
        while (it.hasNext()) {
            ((o0) ((v) it.next())).f2295a.p(menu);
        }
        super.onPanelClosed(i10, menu);
    }

    public void onPictureInPictureModeChanged(boolean z4) {
        if (!this.mDispatchingOnPictureInPictureModeChanged) {
            Iterator<q1.a> it = this.mOnPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new g1.x0(z4));
            }
        }
    }

    public boolean onPreparePanel(int i10, View view, Menu menu) {
        if (i10 != 0) {
            return true;
        }
        super.onPreparePanel(i10, view, menu);
        Iterator it = this.mMenuHostHelper.f25274b.iterator();
        while (it.hasNext()) {
            ((o0) ((v) it.next())).f2295a.s(menu);
        }
        return true;
    }

    public void onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        if (!this.mActivityResultRegistry.a(i10, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) && Build.VERSION.SDK_INT >= 23) {
            super.onRequestPermissionsResult(i10, strArr, iArr);
        }
    }

    @Deprecated
    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [androidx.activity.l, java.lang.Object] */
    public final Object onRetainNonConfigurationInstance() {
        l lVar;
        Object onRetainCustomNonConfigurationInstance = onRetainCustomNonConfigurationInstance();
        i1 i1Var = this.mViewModelStore;
        if (i1Var == null && (lVar = (l) getLastNonConfigurationInstance()) != null) {
            i1Var = lVar.f935b;
        }
        if (i1Var == null && onRetainCustomNonConfigurationInstance == null) {
            return null;
        }
        ? obj = new Object();
        obj.f934a = onRetainCustomNonConfigurationInstance;
        obj.f935b = i1Var;
        return obj;
    }

    public void onSaveInstanceState(Bundle bundle) {
        r lifecycle = getLifecycle();
        if (lifecycle instanceof a0) {
            ((a0) lifecycle).h();
        }
        super.onSaveInstanceState(bundle);
        this.mSavedStateRegistryController.c(bundle);
    }

    public void onTrimMemory(int i10) {
        super.onTrimMemory(i10);
        Iterator<q1.a> it = this.mOnTrimMemoryListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(Integer.valueOf(i10));
        }
    }

    public Context peekAvailableContext() {
        return this.mContextAwareHelper.f17609b;
    }

    public final <I, O> e.b registerForActivityResult(f.a aVar, e.a aVar2) {
        return registerForActivityResult(aVar, this.mActivityResultRegistry, aVar2);
    }

    public void removeMenuProvider(v vVar) {
        this.mMenuHostHelper.b(vVar);
    }

    public final void removeOnConfigurationChangedListener(q1.a aVar) {
        this.mOnConfigurationChangedListeners.remove(aVar);
    }

    public final void removeOnContextAvailableListener(b bVar) {
        a aVar = this.mContextAwareHelper;
        aVar.getClass();
        r0.j("listener", bVar);
        aVar.f17608a.remove(bVar);
    }

    public final void removeOnMultiWindowModeChangedListener(q1.a aVar) {
        this.mOnMultiWindowModeChangedListeners.remove(aVar);
    }

    public final void removeOnNewIntentListener(q1.a aVar) {
        this.mOnNewIntentListeners.remove(aVar);
    }

    public final void removeOnPictureInPictureModeChangedListener(q1.a aVar) {
        this.mOnPictureInPictureModeChangedListeners.remove(aVar);
    }

    public final void removeOnTrimMemoryListener(q1.a aVar) {
        this.mOnTrimMemoryListeners.remove(aVar);
    }

    public void reportFullyDrawn() {
        try {
            if (l7.a.C()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            this.mFullyDrawnReporter.a();
            Trace.endSection();
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public abstract void setContentView(int i10);

    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        initializeViewTreeOwners();
        this.mReportFullyDrawnExecutor.q(getWindow().getDecorView());
        super.setContentView(view);
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i10) {
        super.startActivityForResult(intent, i10);
    }

    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i10, Intent intent, int i11, int i12, int i13) {
        super.startIntentSenderForResult(intentSender, i10, intent, i11, i12, i13);
    }

    /* JADX INFO: finally extract failed */
    public void onMultiWindowModeChanged(boolean z4, Configuration configuration) {
        this.mDispatchingOnMultiWindowModeChanged = true;
        try {
            super.onMultiWindowModeChanged(z4, configuration);
            this.mDispatchingOnMultiWindowModeChanged = false;
            Iterator<q1.a> it = this.mOnMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new g1.o(z4, 0));
            }
        } catch (Throwable th2) {
            this.mDispatchingOnMultiWindowModeChanged = false;
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    public void onPictureInPictureModeChanged(boolean z4, Configuration configuration) {
        this.mDispatchingOnPictureInPictureModeChanged = true;
        try {
            super.onPictureInPictureModeChanged(z4, configuration);
            this.mDispatchingOnPictureInPictureModeChanged = false;
            Iterator<q1.a> it = this.mOnPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new g1.x0(z4, 0));
            }
        } catch (Throwable th2) {
            this.mDispatchingOnPictureInPictureModeChanged = false;
            throw th2;
        }
    }

    public final <I, O> e.b registerForActivityResult(f.a aVar, e.g gVar, e.a aVar2) {
        return gVar.c("activity_rq#" + this.mNextLocalRequestCode.getAndIncrement(), this, aVar, aVar2);
    }

    @Deprecated
    public void startActivityForResult(Intent intent, int i10, Bundle bundle) {
        super.startActivityForResult(intent, i10, bundle);
    }

    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i10, Intent intent, int i11, int i12, int i13, Bundle bundle) {
        super.startIntentSenderForResult(intentSender, i10, intent, i11, i12, i13, bundle);
    }

    public void addMenuProvider(v vVar, y yVar) {
        t tVar = this.mMenuHostHelper;
        tVar.f25274b.add(vVar);
        tVar.f25273a.run();
        r lifecycle = yVar.getLifecycle();
        HashMap hashMap = tVar.f25275c;
        s sVar = (s) hashMap.remove(vVar);
        if (sVar != null) {
            sVar.f25267a.c(sVar.f25268b);
            sVar.f25268b = null;
        }
        hashMap.put(vVar, new s(lifecycle, new q(tVar, vVar)));
    }

    @SuppressLint({"LambdaLast"})
    public void addMenuProvider(v vVar, y yVar, androidx.lifecycle.q qVar) {
        t tVar = this.mMenuHostHelper;
        tVar.getClass();
        r lifecycle = yVar.getLifecycle();
        HashMap hashMap = tVar.f25275c;
        s sVar = (s) hashMap.remove(vVar);
        if (sVar != null) {
            sVar.f25267a.c(sVar.f25268b);
            sVar.f25268b = null;
        }
        hashMap.put(vVar, new s(lifecycle, new r1.r(tVar, qVar, vVar)));
    }
}
