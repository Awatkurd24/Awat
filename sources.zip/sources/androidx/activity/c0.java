package androidx.activity;

import ge.a;
import ge.c;
import he.i;
import jd.j;
import wd.m;
import xd.o;

public final /* synthetic */ class c0 extends i implements a {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ int f915j;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c0(int i10, Object obj) {
        super(0, obj, d0.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        this.f915j = i10;
        if (i10 == 1) {
            super(0, obj, d0.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        } else if (i10 != 2) {
        } else {
            super(0, obj, j.class, "save", "save()V", 0);
        }
    }

    public final void i() {
        int i10 = this.f915j;
        Object obj = this.f19674b;
        switch (i10) {
            case 0:
                ((d0) obj).d();
                return;
            case 1:
                ((d0) obj).d();
                return;
            default:
                j jVar = (j) obj;
                Integer num = (Integer) o.f0(jVar.H);
                if (num != null) {
                    int intValue = num.intValue();
                    c cVar = jVar.F;
                    if (cVar != null) {
                        cVar.g(Integer.valueOf(intValue), jVar.G.get(intValue));
                    }
                }
                jVar.i(false, false);
                return;
        }
    }

    public final /* bridge */ /* synthetic */ Object invoke() {
        m mVar = m.f29306a;
        switch (this.f915j) {
            case 0:
                i();
                return mVar;
            case 1:
                i();
                return mVar;
            default:
                i();
                return mVar;
        }
    }
}
