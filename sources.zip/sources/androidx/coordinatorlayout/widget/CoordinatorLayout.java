package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.customview.view.AbsSavedState;
import co.vpn.plusvpn.R;
import e1.a;
import e1.b;
import e1.c;
import e1.e;
import e1.f;
import e1.g;
import e1.h;
import h1.i;
import ib.t;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import q1.d;
import r1.a0;
import r1.b0;
import r1.h1;
import r1.m;
import r1.p0;
import r1.q0;
import r1.s0;
import r1.t0;
import r1.t2;
import r1.v0;
import r1.y;
import r1.z;
import s0.k;
import t7.w;

public class CoordinatorLayout extends ViewGroup implements y, z {

    /* renamed from: t  reason: collision with root package name */
    public static final String f1826t;

    /* renamed from: u  reason: collision with root package name */
    public static final Class[] f1827u = {Context.class, AttributeSet.class};

    /* renamed from: v  reason: collision with root package name */
    public static final ThreadLocal f1828v = new ThreadLocal();

    /* renamed from: w  reason: collision with root package name */
    public static final g f1829w = new g(0);

    /* renamed from: x  reason: collision with root package name */
    public static final d f1830x = new d(12);

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f1831a;

    /* renamed from: b  reason: collision with root package name */
    public final t f1832b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList f1833c;

    /* renamed from: d  reason: collision with root package name */
    public final ArrayList f1834d;

    /* renamed from: e  reason: collision with root package name */
    public final int[] f1835e;

    /* renamed from: f  reason: collision with root package name */
    public final int[] f1836f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1837g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1838h;

    /* renamed from: i  reason: collision with root package name */
    public final int[] f1839i;

    /* renamed from: j  reason: collision with root package name */
    public View f1840j;

    /* renamed from: k  reason: collision with root package name */
    public View f1841k;

    /* renamed from: l  reason: collision with root package name */
    public f f1842l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1843m;

    /* renamed from: n  reason: collision with root package name */
    public t2 f1844n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f1845o;

    /* renamed from: p  reason: collision with root package name */
    public Drawable f1846p;

    /* renamed from: q  reason: collision with root package name */
    public ViewGroup.OnHierarchyChangeListener f1847q;

    /* renamed from: r  reason: collision with root package name */
    public a4.f f1848r;

    /* renamed from: s  reason: collision with root package name */
    public final a0 f1849s;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Object();

        /* renamed from: c  reason: collision with root package name */
        public SparseArray f1850c;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f1850c = new SparseArray(readInt);
            for (int i10 = 0; i10 < readInt; i10++) {
                this.f1850c.append(iArr[i10], readParcelableArray[i10]);
            }
        }

        public final void writeToParcel(Parcel parcel, int i10) {
            int i11;
            parcel.writeParcelable(this.f1896a, i10);
            SparseArray sparseArray = this.f1850c;
            if (sparseArray != null) {
                i11 = sparseArray.size();
            } else {
                i11 = 0;
            }
            parcel.writeInt(i11);
            int[] iArr = new int[i11];
            Parcelable[] parcelableArr = new Parcelable[i11];
            for (int i12 = 0; i12 < i11; i12++) {
                iArr[i12] = this.f1850c.keyAt(i12);
                parcelableArr[i12] = (Parcelable) this.f1850c.valueAt(i12);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i10);
        }
    }

    static {
        Package packageR = CoordinatorLayout.class.getPackage();
        f1826t = packageR != null ? packageR.getName() : null;
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.coordinatorLayoutStyle);
    }

    public static Rect g() {
        Rect rect = (Rect) f1830x.a();
        return rect == null ? new Rect() : rect;
    }

    public static void m(int i10, Rect rect, Rect rect2, e eVar, int i11, int i12) {
        int i13;
        int i14;
        int i15 = eVar.f17894c;
        if (i15 == 0) {
            i15 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i15, i10);
        int i16 = eVar.f17895d;
        if ((i16 & 7) == 0) {
            i16 |= 8388611;
        }
        if ((i16 & 112) == 0) {
            i16 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i16, i10);
        int i17 = absoluteGravity & 7;
        int i18 = absoluteGravity & 112;
        int i19 = absoluteGravity2 & 7;
        int i20 = absoluteGravity2 & 112;
        if (i19 == 1) {
            i13 = rect.left + (rect.width() / 2);
        } else if (i19 != 5) {
            i13 = rect.left;
        } else {
            i13 = rect.right;
        }
        if (i20 == 16) {
            i14 = rect.top + (rect.height() / 2);
        } else if (i20 != 80) {
            i14 = rect.top;
        } else {
            i14 = rect.bottom;
        }
        if (i17 == 1) {
            i13 -= i11 / 2;
        } else if (i17 != 5) {
            i13 -= i11;
        }
        if (i18 == 16) {
            i14 -= i12 / 2;
        } else if (i18 != 80) {
            i14 -= i12;
        }
        rect2.set(i13, i14, i11 + i13, i12 + i14);
    }

    public static e o(View view) {
        e eVar = (e) view.getLayoutParams();
        if (!eVar.f17893b) {
            if (view instanceof a) {
                b behavior = ((a) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                eVar.b(behavior);
            } else {
                c cVar = null;
                for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    cVar = (c) cls.getAnnotation(c.class);
                    if (cVar != null) {
                        break;
                    }
                }
                if (cVar != null) {
                    try {
                        eVar.b((b) cVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
                    } catch (Exception e10) {
                        Log.e("CoordinatorLayout", "Default behavior class " + cVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e10);
                    }
                }
            }
            eVar.f17893b = true;
        }
        return eVar;
    }

    public static void w(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        int i11 = eVar.f17900i;
        if (i11 != i10) {
            h1.l(view, i10 - i11);
            eVar.f17900i = i10;
        }
    }

    public static void x(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        int i11 = eVar.f17901j;
        if (i11 != i10) {
            h1.m(view, i10 - i11);
            eVar.f17901j = i10;
        }
    }

    public final void a(View view, View view2, int i10, int i11) {
        a0 a0Var = this.f1849s;
        if (i11 == 1) {
            a0Var.f25157c = i10;
        } else {
            a0Var.f25156b = i10;
        }
        this.f1841k = view2;
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            ((e) getChildAt(i12).getLayoutParams()).getClass();
        }
    }

    public final void b(View view, int i10) {
        a0 a0Var = this.f1849s;
        if (i10 == 1) {
            a0Var.f25157c = 0;
        } else {
            a0Var.f25156b = 0;
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.a(i10)) {
                b bVar = eVar.f17892a;
                if (bVar != null) {
                    bVar.u(this, childAt, view, i10);
                }
                if (i10 == 0) {
                    eVar.f17905n = false;
                } else if (i10 == 1) {
                    eVar.f17906o = false;
                }
                eVar.f17907p = false;
            }
        }
        this.f1841k = null;
    }

    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        b bVar;
        int min;
        int min2;
        int childCount = getChildCount();
        boolean z4 = false;
        int i13 = 0;
        int i14 = 0;
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt = getChildAt(i15);
            if (childAt.getVisibility() == 8) {
                int i16 = i12;
            } else {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(i12) && (bVar = eVar.f17892a) != null) {
                    int[] iArr2 = this.f1835e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    bVar.o(this, childAt, view, i10, i11, iArr2, i12);
                    int[] iArr3 = this.f1835e;
                    if (i10 > 0) {
                        min = Math.max(i13, iArr3[0]);
                    } else {
                        min = Math.min(i13, iArr3[0]);
                    }
                    i13 = min;
                    if (i11 > 0) {
                        min2 = Math.max(i14, iArr3[1]);
                    } else {
                        min2 = Math.min(i14, iArr3[1]);
                    }
                    i14 = min2;
                    z4 = true;
                }
            }
        }
        iArr[0] = i13;
        iArr[1] = i14;
        if (z4) {
            q(1);
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof e) && super.checkLayoutParams(layoutParams);
    }

    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        b bVar;
        int min;
        int min2;
        int childCount = getChildCount();
        boolean z4 = false;
        int i15 = 0;
        int i16 = 0;
        for (int i17 = 0; i17 < childCount; i17++) {
            View childAt = getChildAt(i17);
            if (childAt.getVisibility() == 8) {
                int i18 = i14;
            } else {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(i14) && (bVar = eVar.f17892a) != null) {
                    int[] iArr2 = this.f1835e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    bVar.p(this, childAt, i11, i12, i13, iArr2);
                    if (i12 > 0) {
                        min = Math.max(i15, iArr2[0]);
                    } else {
                        min = Math.min(i15, iArr2[0]);
                    }
                    i15 = min;
                    if (i13 > 0) {
                        min2 = Math.max(i16, iArr2[1]);
                    } else {
                        min2 = Math.min(i16, iArr2[1]);
                    }
                    i16 = min2;
                    z4 = true;
                }
            }
        }
        iArr[0] = iArr[0] + i15;
        iArr[1] = iArr[1] + i16;
        if (z4) {
            q(1);
        }
    }

    public final boolean drawChild(Canvas canvas, View view, long j3) {
        b bVar = ((e) view.getLayoutParams()).f17892a;
        if (bVar != null) {
            bVar.getClass();
        }
        return super.drawChild(canvas, view, j3);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1846p;
        if (drawable != null && drawable.isStateful() && drawable.setState(drawableState)) {
            invalidate();
        }
    }

    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
        d(view, i10, i11, i12, i13, 0, this.f1836f);
    }

    public final boolean f(View view, View view2, int i10, int i11) {
        int i12 = i11;
        int childCount = getChildCount();
        boolean z4 = false;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                b bVar = eVar.f17892a;
                if (bVar != null) {
                    boolean t10 = bVar.t(this, childAt, view, view2, i10, i11);
                    z4 |= t10;
                    if (i12 == 0) {
                        eVar.f17905n = t10;
                    } else if (i12 == 1) {
                        eVar.f17906o = t10;
                    }
                } else if (i12 == 0) {
                    eVar.f17905n = false;
                } else if (i12 == 1) {
                    eVar.f17906o = false;
                }
            }
        }
        return z4;
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e();
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        u();
        return Collections.unmodifiableList(this.f1831a);
    }

    public final t2 getLastWindowInsets() {
        return this.f1844n;
    }

    public int getNestedScrollAxes() {
        a0 a0Var = this.f1849s;
        return a0Var.f25157c | a0Var.f25156b;
    }

    public Drawable getStatusBarBackground() {
        return this.f1846p;
    }

    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(e eVar, Rect rect, int i10, int i11) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + eVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i10) - eVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + eVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i11) - eVar.bottomMargin));
        rect.set(max, max2, i10 + max, i11 + max2);
    }

    public final void i(View view) {
        List list = (List) ((k) this.f1832b.f20103b).getOrDefault(view, (Object) null);
        if (list != null && !list.isEmpty()) {
            for (int i10 = 0; i10 < list.size(); i10++) {
                View view2 = (View) list.get(i10);
                b bVar = ((e) view2.getLayoutParams()).f17892a;
                if (bVar != null) {
                    bVar.h(this, view2, view);
                }
            }
        }
    }

    public final void j(View view, Rect rect, boolean z4) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z4) {
            l(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList k(View view) {
        t tVar = this.f1832b;
        int i10 = ((k) tVar.f20103b).f25752c;
        ArrayList arrayList = null;
        for (int i11 = 0; i11 < i10; i11++) {
            ArrayList arrayList2 = (ArrayList) ((k) tVar.f20103b).k(i11);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(((k) tVar.f20103b).i(i11));
            }
        }
        ArrayList arrayList3 = this.f1834d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void l(View view, Rect rect) {
        ThreadLocal threadLocal = h.f17912a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = h.f17912a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        h.a(this, view, matrix);
        ThreadLocal threadLocal3 = h.f17913b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int n(int i10) {
        StringBuilder sb2;
        int[] iArr = this.f1839i;
        if (iArr == null) {
            sb2 = new StringBuilder("No keylines defined for ");
            sb2.append(this);
            sb2.append(" - attempted index lookup ");
            sb2.append(i10);
        } else if (i10 >= 0 && i10 < iArr.length) {
            return iArr[i10];
        } else {
            sb2 = new StringBuilder("Keyline index ");
            sb2.append(i10);
            sb2.append(" out of range for ");
            sb2.append(this);
        }
        Log.e("CoordinatorLayout", sb2.toString());
        return 0;
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        v(false);
        if (this.f1843m) {
            if (this.f1842l == null) {
                this.f1842l = new f(0, this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f1842l);
        }
        if (this.f1844n == null) {
            WeakHashMap weakHashMap = h1.f25195a;
            if (p0.b(this)) {
                t0.c(this);
            }
        }
        this.f1838h = true;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        v(false);
        if (this.f1843m && this.f1842l != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f1842l);
        }
        View view = this.f1841k;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f1838h = false;
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f1845o && this.f1846p != null) {
            t2 t2Var = this.f1844n;
            int d10 = t2Var != null ? t2Var.d() : 0;
            if (d10 > 0) {
                this.f1846p.setBounds(0, 0, getWidth(), d10);
                this.f1846p.draw(canvas);
            }
        }
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            v(true);
        }
        boolean t10 = t(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            v(true);
        }
        return t10;
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        b bVar;
        WeakHashMap weakHashMap = h1.f25195a;
        int d10 = q0.d(this);
        ArrayList arrayList = this.f1831a;
        int size = arrayList.size();
        for (int i14 = 0; i14 < size; i14++) {
            View view = (View) arrayList.get(i14);
            if (view.getVisibility() != 8 && ((bVar = ((e) view.getLayoutParams()).f17892a) == null || !bVar.l(this, view, d10))) {
                r(view, d10);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0190, code lost:
        if (r0.m(r30, r19, r25, r20, r26) == false) goto L_0x01a6;
     */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0166  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x016e  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0193  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r6 = r30
            r30.u()
            int r0 = r30.getChildCount()
            r7 = 0
            r1 = 0
        L_0x000b:
            r2 = 1
            if (r1 >= r0) goto L_0x0037
            android.view.View r3 = r6.getChildAt(r1)
            ib.t r4 = r6.f1832b
            java.lang.Object r5 = r4.f20103b
            s0.k r5 = (s0.k) r5
            int r5 = r5.f25752c
            r8 = 0
        L_0x001b:
            if (r8 >= r5) goto L_0x0034
            java.lang.Object r9 = r4.f20103b
            s0.k r9 = (s0.k) r9
            java.lang.Object r9 = r9.k(r8)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 == 0) goto L_0x0031
            boolean r9 = r9.contains(r3)
            if (r9 == 0) goto L_0x0031
            r0 = 1
            goto L_0x0038
        L_0x0031:
            int r8 = r8 + 1
            goto L_0x001b
        L_0x0034:
            int r1 = r1 + 1
            goto L_0x000b
        L_0x0037:
            r0 = 0
        L_0x0038:
            boolean r1 = r6.f1843m
            if (r0 == r1) goto L_0x006c
            if (r0 == 0) goto L_0x0059
            boolean r0 = r6.f1838h
            if (r0 == 0) goto L_0x0056
            e1.f r0 = r6.f1842l
            if (r0 != 0) goto L_0x004d
            e1.f r0 = new e1.f
            r0.<init>(r7, r6)
            r6.f1842l = r0
        L_0x004d:
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            e1.f r1 = r6.f1842l
            r0.addOnPreDrawListener(r1)
        L_0x0056:
            r6.f1843m = r2
            goto L_0x006c
        L_0x0059:
            boolean r0 = r6.f1838h
            if (r0 == 0) goto L_0x006a
            e1.f r0 = r6.f1842l
            if (r0 == 0) goto L_0x006a
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            e1.f r1 = r6.f1842l
            r0.removeOnPreDrawListener(r1)
        L_0x006a:
            r6.f1843m = r7
        L_0x006c:
            int r8 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r9 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            java.util.WeakHashMap r3 = r1.h1.f25195a
            int r10 = r1.q0.d(r30)
            if (r10 != r2) goto L_0x0086
            r11 = 1
            goto L_0x0087
        L_0x0086:
            r11 = 0
        L_0x0087:
            int r12 = android.view.View.MeasureSpec.getMode(r31)
            int r13 = android.view.View.MeasureSpec.getSize(r31)
            int r14 = android.view.View.MeasureSpec.getMode(r32)
            int r15 = android.view.View.MeasureSpec.getSize(r32)
            int r16 = r8 + r9
            int r17 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            r1.t2 r3 = r6.f1844n
            if (r3 == 0) goto L_0x00b0
            boolean r3 = r1.p0.b(r30)
            if (r3 == 0) goto L_0x00b0
            r18 = 1
            goto L_0x00b2
        L_0x00b0:
            r18 = 0
        L_0x00b2:
            java.util.ArrayList r5 = r6.f1831a
            int r4 = r5.size()
            r3 = r0
            r2 = r1
            r0 = 0
            r1 = 0
        L_0x00bc:
            if (r1 >= r4) goto L_0x01ee
            java.lang.Object r19 = r5.get(r1)
            android.view.View r19 = (android.view.View) r19
            int r7 = r19.getVisibility()
            r21 = r0
            r0 = 8
            if (r7 != r0) goto L_0x00e0
            r28 = r4
            r29 = r5
            r23 = r8
            r24 = r9
            r27 = r10
            r0 = r21
            r22 = 0
            r21 = r1
            goto L_0x01df
        L_0x00e0:
            android.view.ViewGroup$LayoutParams r0 = r19.getLayoutParams()
            r7 = r0
            e1.e r7 = (e1.e) r7
            int r0 = r7.f17896e
            if (r0 < 0) goto L_0x012c
            if (r12 == 0) goto L_0x012c
            int r0 = r6.n(r0)
            r22 = r1
            int r1 = r7.f17894c
            if (r1 != 0) goto L_0x00fa
            r1 = 8388661(0x800035, float:1.1755018E-38)
        L_0x00fa:
            int r1 = android.view.Gravity.getAbsoluteGravity(r1, r10)
            r1 = r1 & 7
            r23 = r2
            r2 = 3
            if (r1 != r2) goto L_0x0107
            if (r11 == 0) goto L_0x010c
        L_0x0107:
            r2 = 5
            if (r1 != r2) goto L_0x0118
            if (r11 == 0) goto L_0x0118
        L_0x010c:
            int r1 = r13 - r9
            int r1 = r1 - r0
            r0 = 0
            int r1 = java.lang.Math.max(r0, r1)
            r20 = r1
            r2 = 0
            goto L_0x0133
        L_0x0118:
            if (r1 != r2) goto L_0x011c
            if (r11 == 0) goto L_0x0121
        L_0x011c:
            r2 = 3
            if (r1 != r2) goto L_0x012a
            if (r11 == 0) goto L_0x012a
        L_0x0121:
            int r0 = r0 - r8
            r2 = 0
            int r0 = java.lang.Math.max(r2, r0)
            r20 = r0
            goto L_0x0133
        L_0x012a:
            r2 = 0
            goto L_0x0131
        L_0x012c:
            r22 = r1
            r23 = r2
            goto L_0x012a
        L_0x0131:
            r20 = 0
        L_0x0133:
            if (r18 == 0) goto L_0x0166
            boolean r0 = r1.p0.b(r19)
            if (r0 != 0) goto L_0x0166
            r1.t2 r0 = r6.f1844n
            int r0 = r0.b()
            r1.t2 r1 = r6.f1844n
            int r1 = r1.c()
            int r1 = r1 + r0
            r1.t2 r0 = r6.f1844n
            int r0 = r0.d()
            r1.t2 r2 = r6.f1844n
            int r2 = r2.a()
            int r2 = r2 + r0
            int r0 = r13 - r1
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r12)
            int r1 = r15 - r2
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r14)
            r25 = r0
            r26 = r1
            goto L_0x016a
        L_0x0166:
            r25 = r31
            r26 = r32
        L_0x016a:
            e1.b r0 = r7.f17892a
            if (r0 == 0) goto L_0x0193
            r2 = r21
            r21 = r22
            r1 = r30
            r24 = r9
            r9 = r23
            r22 = 0
            r23 = r8
            r8 = r2
            r2 = r19
            r27 = r10
            r10 = r3
            r3 = r25
            r28 = r4
            r4 = r20
            r29 = r5
            r5 = r26
            boolean r0 = r0.m(r1, r2, r3, r4, r5)
            if (r0 != 0) goto L_0x01b4
            goto L_0x01a6
        L_0x0193:
            r28 = r4
            r29 = r5
            r24 = r9
            r27 = r10
            r9 = r23
            r10 = r3
            r23 = r8
            r8 = r21
            r21 = r22
            r22 = 0
        L_0x01a6:
            r5 = 0
            r0 = r30
            r1 = r19
            r2 = r25
            r3 = r20
            r4 = r26
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
        L_0x01b4:
            int r0 = r19.getMeasuredWidth()
            int r0 = r0 + r16
            int r1 = r7.leftMargin
            int r0 = r0 + r1
            int r1 = r7.rightMargin
            int r0 = r0 + r1
            int r0 = java.lang.Math.max(r10, r0)
            int r1 = r19.getMeasuredHeight()
            int r1 = r1 + r17
            int r2 = r7.topMargin
            int r1 = r1 + r2
            int r2 = r7.bottomMargin
            int r1 = r1 + r2
            int r1 = java.lang.Math.max(r9, r1)
            int r2 = r19.getMeasuredState()
            int r2 = android.view.View.combineMeasuredStates(r8, r2)
            r3 = r0
            r0 = r2
            r2 = r1
        L_0x01df:
            int r1 = r21 + 1
            r8 = r23
            r9 = r24
            r10 = r27
            r4 = r28
            r5 = r29
            r7 = 0
            goto L_0x00bc
        L_0x01ee:
            r8 = r0
            r9 = r2
            r10 = r3
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r8
            r1 = r31
            int r0 = android.view.View.resolveSizeAndState(r10, r1, r0)
            int r1 = r8 << 16
            r2 = r32
            int r1 = android.view.View.resolveSizeAndState(r9, r2, r1)
            r6.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public final boolean onNestedFling(View view, float f10, float f11, boolean z4) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(0)) {
                    b bVar = eVar.f17892a;
                }
            }
        }
        return false;
    }

    public final boolean onNestedPreFling(View view, float f10, float f11) {
        b bVar;
        int childCount = getChildCount();
        boolean z4 = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.a(0) && (bVar = eVar.f17892a) != null) {
                    z4 |= bVar.n(view);
                }
            }
        }
        return z4;
    }

    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        c(view, i10, i11, iArr, 0);
    }

    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        e(view, i10, i11, i12, i13, 0);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        a(view, view2, i10, 0);
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1896a);
        SparseArray sparseArray = savedState.f1850c;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id2 = childAt.getId();
            b bVar = o(childAt).f17892a;
            if (!(id2 == -1 || bVar == null || (parcelable2 = (Parcelable) sparseArray.get(id2)) == null)) {
                bVar.r(childAt, parcelable2);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.os.Parcelable, androidx.customview.view.AbsSavedState, androidx.coordinatorlayout.widget.CoordinatorLayout$SavedState] */
    public final Parcelable onSaveInstanceState() {
        Parcelable s10;
        ? absSavedState = new AbsSavedState(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id2 = childAt.getId();
            b bVar = ((e) childAt.getLayoutParams()).f17892a;
            if (!(id2 == -1 || bVar == null || (s10 = bVar.s(childAt)) == null)) {
                sparseArray.append(id2, s10);
            }
        }
        absSavedState.f1850c = sparseArray;
        return absSavedState;
    }

    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return f(view, view2, i10, 0);
    }

    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0018;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f1840j
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0017
            boolean r3 = r0.t(r1, r4)
            if (r3 == 0) goto L_0x0015
            goto L_0x0018
        L_0x0015:
            r6 = 0
            goto L_0x002a
        L_0x0017:
            r3 = 0
        L_0x0018:
            android.view.View r6 = r0.f1840j
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            e1.e r6 = (e1.e) r6
            e1.b r6 = r6.f17892a
            if (r6 == 0) goto L_0x0015
            android.view.View r7 = r0.f1840j
            boolean r6 = r6.v(r0, r7, r1)
        L_0x002a:
            android.view.View r7 = r0.f1840j
            r8 = 0
            if (r7 != 0) goto L_0x0035
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x0048
        L_0x0035:
            if (r3 == 0) goto L_0x0048
            long r11 = android.os.SystemClock.uptimeMillis()
            r13 = 3
            r14 = 0
            r15 = 0
            r16 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x0048:
            if (r8 == 0) goto L_0x004d
            r8.recycle()
        L_0x004d:
            if (r2 == r4) goto L_0x0052
            r1 = 3
            if (r2 != r1) goto L_0x0055
        L_0x0052:
            r0.v(r5)
        L_0x0055:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final boolean p(View view, int i10, int i11) {
        d dVar = f1830x;
        Rect g10 = g();
        l(view, g10);
        try {
            return g10.contains(i10, i11);
        } finally {
            g10.setEmpty();
            dVar.b(g10);
        }
    }

    public final void q(int i10) {
        int i11;
        Rect rect;
        int i12;
        ArrayList arrayList;
        boolean z4;
        boolean z10;
        boolean z11;
        int width;
        int i13;
        int i14;
        int i15;
        int height;
        int i16;
        int i17;
        int i18;
        Rect rect2;
        e eVar;
        int i19;
        int i20;
        int i21;
        ArrayList arrayList2;
        View view;
        d dVar;
        int i22;
        boolean z12;
        e eVar2;
        b bVar;
        int i23 = i10;
        WeakHashMap weakHashMap = h1.f25195a;
        int d10 = q0.d(this);
        ArrayList arrayList3 = this.f1831a;
        int size = arrayList3.size();
        Rect g10 = g();
        Rect g11 = g();
        Rect g12 = g();
        int i24 = 0;
        while (true) {
            d dVar2 = f1830x;
            if (i24 < size) {
                View view2 = (View) arrayList3.get(i24);
                e eVar3 = (e) view2.getLayoutParams();
                if (i23 != 0 || view2.getVisibility() != 8) {
                    int i25 = 0;
                    while (i25 < i24) {
                        if (eVar3.f17903l == ((View) arrayList3.get(i25))) {
                            e eVar4 = (e) view2.getLayoutParams();
                            if (eVar4.f17902k != null) {
                                Rect g13 = g();
                                Rect g14 = g();
                                arrayList2 = arrayList3;
                                Rect g15 = g();
                                i21 = i25;
                                l(eVar4.f17902k, g13);
                                j(view2, g14, false);
                                int measuredWidth = view2.getMeasuredWidth();
                                i20 = size;
                                int measuredHeight = view2.getMeasuredHeight();
                                Rect rect3 = g13;
                                e eVar5 = eVar4;
                                i19 = i24;
                                int i26 = measuredWidth;
                                eVar = eVar3;
                                view = view2;
                                rect2 = g12;
                                dVar = dVar2;
                                m(d10, rect3, g15, eVar5, i26, measuredHeight);
                                if (g15.left == g14.left && g15.top == g14.top) {
                                    eVar2 = eVar5;
                                    i22 = i26;
                                    z12 = false;
                                } else {
                                    eVar2 = eVar5;
                                    i22 = i26;
                                    z12 = true;
                                }
                                h(eVar2, g15, i22, measuredHeight);
                                int i27 = g15.left - g14.left;
                                int i28 = g15.top - g14.top;
                                if (i27 != 0) {
                                    h1.l(view, i27);
                                }
                                if (i28 != 0) {
                                    h1.m(view, i28);
                                }
                                if (z12 && (bVar = eVar2.f17892a) != null) {
                                    bVar.h(this, view, eVar2.f17902k);
                                }
                                rect3.setEmpty();
                                dVar.b(rect3);
                                g14.setEmpty();
                                dVar.b(g14);
                                g15.setEmpty();
                                dVar.b(g15);
                                i25 = i21 + 1;
                                dVar2 = dVar;
                                view2 = view;
                                arrayList3 = arrayList2;
                                size = i20;
                                i24 = i19;
                                eVar3 = eVar;
                                g12 = rect2;
                            }
                        }
                        i21 = i25;
                        eVar = eVar3;
                        arrayList2 = arrayList3;
                        i20 = size;
                        rect2 = g12;
                        i19 = i24;
                        view = view2;
                        dVar = dVar2;
                        i25 = i21 + 1;
                        dVar2 = dVar;
                        view2 = view;
                        arrayList3 = arrayList2;
                        size = i20;
                        i24 = i19;
                        eVar3 = eVar;
                        g12 = rect2;
                    }
                    ArrayList arrayList4 = arrayList3;
                    int i29 = size;
                    Rect rect4 = g12;
                    i11 = i24;
                    View view3 = view2;
                    d dVar3 = dVar2;
                    j(view3, g11, true);
                    e eVar6 = eVar3;
                    if (eVar6.f17898g != 0 && !g11.isEmpty()) {
                        int absoluteGravity = Gravity.getAbsoluteGravity(eVar6.f17898g, d10);
                        int i30 = absoluteGravity & 112;
                        if (i30 == 48) {
                            g10.top = Math.max(g10.top, g11.bottom);
                        } else if (i30 == 80) {
                            g10.bottom = Math.max(g10.bottom, getHeight() - g11.top);
                        }
                        int i31 = absoluteGravity & 7;
                        if (i31 == 3) {
                            g10.left = Math.max(g10.left, g11.right);
                        } else if (i31 == 5) {
                            g10.right = Math.max(g10.right, getWidth() - g11.left);
                        }
                    }
                    if (eVar6.f17899h != 0 && view3.getVisibility() == 0) {
                        WeakHashMap weakHashMap2 = h1.f25195a;
                        if (s0.c(view3) && view3.getWidth() > 0 && view3.getHeight() > 0) {
                            e eVar7 = (e) view3.getLayoutParams();
                            b bVar2 = eVar7.f17892a;
                            Rect g16 = g();
                            Rect g17 = g();
                            g17.set(view3.getLeft(), view3.getTop(), view3.getRight(), view3.getBottom());
                            if (bVar2 == null || !bVar2.e(view3, g16)) {
                                g16.set(g17);
                            } else if (!g17.contains(g16)) {
                                throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + g16.toShortString() + " | Bounds:" + g17.toShortString());
                            }
                            g17.setEmpty();
                            dVar3.b(g17);
                            if (!g16.isEmpty()) {
                                int absoluteGravity2 = Gravity.getAbsoluteGravity(eVar7.f17899h, d10);
                                if ((absoluteGravity2 & 48) != 48 || (i17 = (g16.top - eVar7.topMargin) - eVar7.f17901j) >= (i18 = g10.top)) {
                                    z10 = false;
                                } else {
                                    x(view3, i18 - i17);
                                    z10 = true;
                                }
                                if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - g16.bottom) - eVar7.bottomMargin) + eVar7.f17901j) < (i16 = g10.bottom)) {
                                    x(view3, height - i16);
                                } else if (!z10) {
                                    x(view3, 0);
                                }
                                if ((absoluteGravity2 & 3) != 3 || (i14 = (g16.left - eVar7.leftMargin) - eVar7.f17900i) >= (i15 = g10.left)) {
                                    z11 = false;
                                } else {
                                    w(view3, i15 - i14);
                                    z11 = true;
                                }
                                if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - g16.right) - eVar7.rightMargin) + eVar7.f17900i) < (i13 = g10.right)) {
                                    w(view3, width - i13);
                                } else if (!z11) {
                                    w(view3, 0);
                                }
                            }
                            g16.setEmpty();
                            dVar3.b(g16);
                        }
                    }
                    if (i23 != 2) {
                        rect = rect4;
                        rect.set(((e) view3.getLayoutParams()).f17908q);
                        if (rect.equals(g11)) {
                            arrayList = arrayList4;
                            i12 = i29;
                        } else {
                            ((e) view3.getLayoutParams()).f17908q.set(g11);
                        }
                    } else {
                        rect = rect4;
                    }
                    int i32 = i11 + 1;
                    i12 = i29;
                    while (true) {
                        arrayList = arrayList4;
                        if (i32 >= i12) {
                            break;
                        }
                        View view4 = (View) arrayList.get(i32);
                        e eVar8 = (e) view4.getLayoutParams();
                        b bVar3 = eVar8.f17892a;
                        if (bVar3 != null && bVar3.f(view4, view3)) {
                            if (i23 != 0 || !eVar8.f17907p) {
                                if (i23 != 2) {
                                    z4 = bVar3.h(this, view4, view3);
                                } else {
                                    bVar3.i(this, view3);
                                    z4 = true;
                                }
                                if (i23 == 1) {
                                    eVar8.f17907p = z4;
                                }
                            } else {
                                eVar8.f17907p = false;
                            }
                        }
                        i32++;
                        arrayList4 = arrayList;
                    }
                } else {
                    arrayList = arrayList3;
                    i12 = size;
                    rect = g12;
                    i11 = i24;
                }
                i24 = i11 + 1;
                g12 = rect;
                size = i12;
                arrayList3 = arrayList;
            } else {
                Rect rect5 = g12;
                d dVar4 = dVar2;
                g10.setEmpty();
                dVar4.b(g10);
                g11.setEmpty();
                dVar4.b(g11);
                rect5.setEmpty();
                dVar4.b(rect5);
                return;
            }
        }
    }

    public final void r(View view, int i10) {
        int i11;
        e eVar = (e) view.getLayoutParams();
        View view2 = eVar.f17902k;
        if (view2 != null || eVar.f17897f == -1) {
            d dVar = f1830x;
            if (view2 != null) {
                Rect g10 = g();
                Rect g11 = g();
                try {
                    l(view2, g10);
                    e eVar2 = (e) view.getLayoutParams();
                    int measuredWidth = view.getMeasuredWidth();
                    int measuredHeight = view.getMeasuredHeight();
                    m(i10, g10, g11, eVar2, measuredWidth, measuredHeight);
                    h(eVar2, g11, measuredWidth, measuredHeight);
                    view.layout(g11.left, g11.top, g11.right, g11.bottom);
                } finally {
                    g10.setEmpty();
                    dVar.b(g10);
                    g11.setEmpty();
                    dVar.b(g11);
                }
            } else {
                int i12 = eVar.f17896e;
                if (i12 >= 0) {
                    e eVar3 = (e) view.getLayoutParams();
                    int i13 = eVar3.f17894c;
                    if (i13 == 0) {
                        i13 = 8388661;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i13, i10);
                    int i14 = absoluteGravity & 7;
                    int i15 = absoluteGravity & 112;
                    int width = getWidth();
                    int height = getHeight();
                    int measuredWidth2 = view.getMeasuredWidth();
                    int measuredHeight2 = view.getMeasuredHeight();
                    if (i10 == 1) {
                        i12 = width - i12;
                    }
                    int n10 = n(i12) - measuredWidth2;
                    if (i14 == 1) {
                        n10 += measuredWidth2 / 2;
                    } else if (i14 == 5) {
                        n10 += measuredWidth2;
                    }
                    if (i15 == 16) {
                        i11 = measuredHeight2 / 2;
                    } else if (i15 != 80) {
                        i11 = 0;
                    } else {
                        i11 = measuredHeight2;
                    }
                    int max = Math.max(getPaddingLeft() + eVar3.leftMargin, Math.min(n10, ((width - getPaddingRight()) - measuredWidth2) - eVar3.rightMargin));
                    int max2 = Math.max(getPaddingTop() + eVar3.topMargin, Math.min(i11, ((height - getPaddingBottom()) - measuredHeight2) - eVar3.bottomMargin));
                    view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
                    return;
                }
                e eVar4 = (e) view.getLayoutParams();
                Rect g12 = g();
                g12.set(getPaddingLeft() + eVar4.leftMargin, getPaddingTop() + eVar4.topMargin, (getWidth() - getPaddingRight()) - eVar4.rightMargin, (getHeight() - getPaddingBottom()) - eVar4.bottomMargin);
                if (this.f1844n != null) {
                    WeakHashMap weakHashMap = h1.f25195a;
                    if (p0.b(this) && !p0.b(view)) {
                        g12.left = this.f1844n.b() + g12.left;
                        g12.top = this.f1844n.d() + g12.top;
                        g12.right -= this.f1844n.c();
                        g12.bottom -= this.f1844n.a();
                    }
                }
                Rect g13 = g();
                int i16 = eVar4.f17894c;
                if ((i16 & 7) == 0) {
                    i16 |= 8388611;
                }
                if ((i16 & 112) == 0) {
                    i16 |= 48;
                }
                m.b(i16, view.getMeasuredWidth(), view.getMeasuredHeight(), g12, g13, i10);
                view.layout(g13.left, g13.top, g13.right, g13.bottom);
                g12.setEmpty();
                dVar.b(g12);
                g13.setEmpty();
                dVar.b(g13);
            }
        } else {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z4) {
        b bVar = ((e) view.getLayoutParams()).f17892a;
        if (bVar == null || !bVar.q(this, view, rect, z4)) {
            return super.requestChildRectangleOnScreen(view, rect, z4);
        }
        return true;
    }

    public final void requestDisallowInterceptTouchEvent(boolean z4) {
        super.requestDisallowInterceptTouchEvent(z4);
        if (z4 && !this.f1837g) {
            v(false);
            this.f1837g = true;
        }
    }

    public final void s(View view, int i10, int i11, int i12) {
        measureChildWithMargins(view, i10, i11, i12, 0);
    }

    public void setFitsSystemWindows(boolean z4) {
        super.setFitsSystemWindows(z4);
        y();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f1847q = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        boolean z4;
        Drawable drawable2 = this.f1846p;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f1846p = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.f1846p.setState(getDrawableState());
                }
                Drawable drawable4 = this.f1846p;
                WeakHashMap weakHashMap = h1.f25195a;
                w.h(drawable4, q0.d(this));
                Drawable drawable5 = this.f1846p;
                if (getVisibility() == 0) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                drawable5.setVisible(z4, false);
                this.f1846p.setCallback(this);
            }
            WeakHashMap weakHashMap2 = h1.f25195a;
            p0.k(this);
        }
    }

    public void setStatusBarBackgroundColor(int i10) {
        setStatusBarBackground(new ColorDrawable(i10));
    }

    public void setStatusBarBackgroundResource(int i10) {
        Drawable drawable;
        if (i10 != 0) {
            Context context = getContext();
            Object obj = i.f19490a;
            drawable = h1.b.b(context, i10);
        } else {
            drawable = null;
        }
        setStatusBarBackground(drawable);
    }

    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z4 = i10 == 0;
        Drawable drawable = this.f1846p;
        if (drawable != null && drawable.isVisible() != z4) {
            this.f1846p.setVisible(z4, false);
        }
    }

    public final boolean t(MotionEvent motionEvent, int i10) {
        boolean z4;
        int i11;
        MotionEvent motionEvent2 = motionEvent;
        int i12 = i10;
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f1833c;
        arrayList.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i13 = childCount - 1; i13 >= 0; i13--) {
            if (isChildrenDrawingOrderEnabled) {
                i11 = getChildDrawingOrder(childCount, i13);
            } else {
                i11 = i13;
            }
            arrayList.add(getChildAt(i11));
        }
        g gVar = f1829w;
        if (gVar != null) {
            Collections.sort(arrayList, gVar);
        }
        int size = arrayList.size();
        MotionEvent motionEvent3 = null;
        boolean z10 = false;
        boolean z11 = false;
        for (int i14 = 0; i14 < size; i14++) {
            View view = (View) arrayList.get(i14);
            e eVar = (e) view.getLayoutParams();
            b bVar = eVar.f17892a;
            if ((!z10 && !z11) || actionMasked == 0) {
                if (!z10 && bVar != null) {
                    if (i12 == 0) {
                        z10 = bVar.k(this, view, motionEvent2);
                    } else if (i12 == 1) {
                        z10 = bVar.v(this, view, motionEvent2);
                    }
                    if (z10) {
                        this.f1840j = view;
                    }
                }
                if (eVar.f17892a == null) {
                    eVar.f17904m = false;
                }
                boolean z12 = eVar.f17904m;
                if (z12) {
                    z4 = true;
                } else {
                    eVar.f17904m = z12;
                    z4 = z12;
                }
                if (!z4 || z12) {
                    z11 = false;
                } else {
                    z11 = true;
                }
                if (z4 && !z11) {
                    break;
                }
            } else if (bVar != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i12 == 0) {
                    bVar.k(this, view, motionEvent3);
                } else if (i12 == 1) {
                    bVar.v(this, view, motionEvent3);
                }
            }
        }
        arrayList.clear();
        return z10;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00ff, code lost:
        if ((android.view.Gravity.getAbsoluteGravity(r6.f17899h, r10) & r11) == r11) goto L_0x010c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void u() {
        /*
            r13 = this;
            java.util.ArrayList r0 = r13.f1831a
            r0.clear()
            ib.t r1 = r13.f1832b
            java.lang.Object r2 = r1.f20103b
            s0.k r2 = (s0.k) r2
            int r2 = r2.f25752c
            r3 = 0
            r4 = 0
        L_0x000f:
            if (r4 >= r2) goto L_0x002a
            java.lang.Object r5 = r1.f20103b
            s0.k r5 = (s0.k) r5
            java.lang.Object r5 = r5.k(r4)
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            if (r5 == 0) goto L_0x0027
            r5.clear()
            java.lang.Object r6 = r1.f20102a
            u0.e r6 = (u0.e) r6
            r6.b(r5)
        L_0x0027:
            int r4 = r4 + 1
            goto L_0x000f
        L_0x002a:
            java.lang.Object r2 = r1.f20103b
            s0.k r2 = (s0.k) r2
            r2.clear()
            int r2 = r13.getChildCount()
            r4 = 0
        L_0x0036:
            if (r4 >= r2) goto L_0x0196
            android.view.View r5 = r13.getChildAt(r4)
            e1.e r6 = o(r5)
            int r7 = r6.f17897f
            r8 = 0
            r9 = -1
            if (r7 != r9) goto L_0x004c
            r6.f17903l = r8
            r6.f17902k = r8
            goto L_0x00c4
        L_0x004c:
            android.view.View r9 = r6.f17902k
            if (r9 == 0) goto L_0x0078
            int r9 = r9.getId()
            if (r9 == r7) goto L_0x0057
            goto L_0x0078
        L_0x0057:
            android.view.View r9 = r6.f17902k
            android.view.ViewParent r10 = r9.getParent()
        L_0x005d:
            if (r10 == r13) goto L_0x0075
            if (r10 == 0) goto L_0x0070
            if (r10 != r5) goto L_0x0064
            goto L_0x0070
        L_0x0064:
            boolean r11 = r10 instanceof android.view.View
            if (r11 == 0) goto L_0x006b
            r9 = r10
            android.view.View r9 = (android.view.View) r9
        L_0x006b:
            android.view.ViewParent r10 = r10.getParent()
            goto L_0x005d
        L_0x0070:
            r6.f17903l = r8
            r6.f17902k = r8
            goto L_0x0078
        L_0x0075:
            r6.f17903l = r9
            goto L_0x00c4
        L_0x0078:
            android.view.View r9 = r13.findViewById(r7)
            r6.f17902k = r9
            if (r9 == 0) goto L_0x00bd
            if (r9 != r13) goto L_0x0095
            boolean r7 = r13.isInEditMode()
            if (r7 == 0) goto L_0x008d
        L_0x0088:
            r6.f17903l = r8
            r6.f17902k = r8
            goto L_0x00c4
        L_0x008d:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "View can not be anchored to the the parent CoordinatorLayout"
            r0.<init>(r1)
            throw r0
        L_0x0095:
            android.view.ViewParent r7 = r9.getParent()
        L_0x0099:
            if (r7 == r13) goto L_0x00ba
            if (r7 == 0) goto L_0x00ba
            if (r7 != r5) goto L_0x00ae
            boolean r7 = r13.isInEditMode()
            if (r7 == 0) goto L_0x00a6
            goto L_0x0088
        L_0x00a6:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Anchor must not be a descendant of the anchored view"
            r0.<init>(r1)
            throw r0
        L_0x00ae:
            boolean r10 = r7 instanceof android.view.View
            if (r10 == 0) goto L_0x00b5
            r9 = r7
            android.view.View r9 = (android.view.View) r9
        L_0x00b5:
            android.view.ViewParent r7 = r7.getParent()
            goto L_0x0099
        L_0x00ba:
            r6.f17903l = r9
            goto L_0x00c4
        L_0x00bd:
            boolean r9 = r13.isInEditMode()
            if (r9 == 0) goto L_0x0172
            goto L_0x0088
        L_0x00c4:
            java.lang.Object r7 = r1.f20103b
            s0.k r7 = (s0.k) r7
            boolean r7 = r7.containsKey(r5)
            if (r7 != 0) goto L_0x00d5
            java.lang.Object r7 = r1.f20103b
            s0.k r7 = (s0.k) r7
            r7.put(r5, r8)
        L_0x00d5:
            r7 = 0
        L_0x00d6:
            if (r7 >= r2) goto L_0x016e
            if (r7 != r4) goto L_0x00dc
            goto L_0x0162
        L_0x00dc:
            android.view.View r9 = r13.getChildAt(r7)
            android.view.View r10 = r6.f17903l
            if (r9 == r10) goto L_0x010c
            java.util.WeakHashMap r10 = r1.h1.f25195a
            int r10 = r1.q0.d(r13)
            android.view.ViewGroup$LayoutParams r11 = r9.getLayoutParams()
            e1.e r11 = (e1.e) r11
            int r11 = r11.f17898g
            int r11 = android.view.Gravity.getAbsoluteGravity(r11, r10)
            if (r11 == 0) goto L_0x0102
            int r12 = r6.f17899h
            int r10 = android.view.Gravity.getAbsoluteGravity(r12, r10)
            r10 = r10 & r11
            if (r10 != r11) goto L_0x0102
            goto L_0x010c
        L_0x0102:
            e1.b r10 = r6.f17892a
            if (r10 == 0) goto L_0x0162
            boolean r10 = r10.f(r5, r9)
            if (r10 == 0) goto L_0x0162
        L_0x010c:
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            boolean r10 = r10.containsKey(r9)
            if (r10 != 0) goto L_0x0127
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            boolean r10 = r10.containsKey(r9)
            if (r10 != 0) goto L_0x0127
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            r10.put(r9, r8)
        L_0x0127:
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            boolean r10 = r10.containsKey(r9)
            if (r10 == 0) goto L_0x0166
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            boolean r10 = r10.containsKey(r5)
            if (r10 == 0) goto L_0x0166
            java.lang.Object r10 = r1.f20103b
            s0.k r10 = (s0.k) r10
            java.lang.Object r10 = r10.getOrDefault(r9, r8)
            java.util.ArrayList r10 = (java.util.ArrayList) r10
            if (r10 != 0) goto L_0x015f
            java.lang.Object r10 = r1.f20102a
            u0.e r10 = (u0.e) r10
            java.lang.Object r10 = r10.a()
            java.util.ArrayList r10 = (java.util.ArrayList) r10
            if (r10 != 0) goto L_0x0158
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
        L_0x0158:
            java.lang.Object r11 = r1.f20103b
            s0.k r11 = (s0.k) r11
            r11.put(r9, r10)
        L_0x015f:
            r10.add(r5)
        L_0x0162:
            int r7 = r7 + 1
            goto L_0x00d6
        L_0x0166:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "All nodes must be present in the graph before being added as an edge"
            r0.<init>(r1)
            throw r0
        L_0x016e:
            int r4 = r4 + 1
            goto L_0x0036
        L_0x0172:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Could not find CoordinatorLayout descendant view with id "
            r1.<init>(r2)
            android.content.res.Resources r2 = r13.getResources()
            java.lang.String r2 = r2.getResourceName(r7)
            r1.append(r2)
            java.lang.String r2 = " to anchor view "
            r1.append(r2)
            r1.append(r5)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0196:
            java.lang.Object r2 = r1.f20104c
            java.util.ArrayList r2 = (java.util.ArrayList) r2
            r2.clear()
            java.lang.Object r2 = r1.f20105d
            java.util.HashSet r2 = (java.util.HashSet) r2
            r2.clear()
            java.lang.Object r2 = r1.f20103b
            s0.k r2 = (s0.k) r2
            int r2 = r2.f25752c
        L_0x01aa:
            if (r3 >= r2) goto L_0x01c2
            java.lang.Object r4 = r1.f20103b
            s0.k r4 = (s0.k) r4
            java.lang.Object r4 = r4.i(r3)
            java.lang.Object r5 = r1.f20104c
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            java.lang.Object r6 = r1.f20105d
            java.util.HashSet r6 = (java.util.HashSet) r6
            r1.c(r4, r5, r6)
            int r3 = r3 + 1
            goto L_0x01aa
        L_0x01c2:
            java.lang.Object r1 = r1.f20104c
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            r0.addAll(r1)
            java.util.Collections.reverse(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.u():void");
    }

    public final void v(boolean z4) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            b bVar = ((e) childAt.getLayoutParams()).f17892a;
            if (bVar != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z4) {
                    bVar.k(this, childAt, obtain);
                } else {
                    bVar.v(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i11 = 0; i11 < childCount; i11++) {
            ((e) getChildAt(i11).getLayoutParams()).f17904m = false;
        }
        this.f1840j = null;
        this.f1837g = false;
    }

    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1846p;
    }

    public final void y() {
        WeakHashMap weakHashMap = h1.f25195a;
        if (p0.b(this)) {
            if (this.f1848r == null) {
                this.f1848r = new a4.f((Object) this);
            }
            v0.u(this, this.f1848r);
            setSystemUiVisibility(1280);
            return;
        }
        v0.u(this, (b0) null);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1831a = new ArrayList();
        this.f1832b = new t(3);
        this.f1833c = new ArrayList();
        this.f1834d = new ArrayList();
        this.f1835e = new int[2];
        this.f1836f = new int[2];
        this.f1849s = new a0(0);
        int[] iArr = d1.a.f17634a;
        TypedArray obtainStyledAttributes = i10 == 0 ? context.obtainStyledAttributes(attributeSet, iArr, 0, 2132018334) : context.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            if (i10 == 0) {
                saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, 0, 2132018334);
            } else {
                saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, i10, 0);
            }
        }
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f1839i = intArray;
            float f10 = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i11 = 0; i11 < length; i11++) {
                int[] iArr2 = this.f1839i;
                iArr2[i11] = (int) (((float) iArr2[i11]) * f10);
            }
        }
        this.f1846p = obtainStyledAttributes.getDrawable(1);
        obtainStyledAttributes.recycle();
        y();
        super.setOnHierarchyChangeListener(new e1.d(this));
        WeakHashMap weakHashMap = h1.f25195a;
        if (p0.c(this) == 0) {
            p0.s(this, 1);
        }
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof e) {
            return new e((e) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }
}
