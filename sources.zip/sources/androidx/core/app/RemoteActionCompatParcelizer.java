package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import m3.a;
import m3.b;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f1851a;
        boolean z4 = true;
        if (aVar.e(1)) {
            obj = aVar.h();
        }
        remoteActionCompat.f1851a = (IconCompat) obj;
        CharSequence charSequence = remoteActionCompat.f1852b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f22394e);
        }
        remoteActionCompat.f1852b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f1853c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f22394e);
        }
        remoteActionCompat.f1853c = charSequence2;
        remoteActionCompat.f1854d = (PendingIntent) aVar.g(remoteActionCompat.f1854d, 4);
        boolean z10 = remoteActionCompat.f1855e;
        if (aVar.e(5)) {
            if (((b) aVar).f22394e.readInt() != 0) {
                z10 = true;
            } else {
                z10 = false;
            }
        }
        remoteActionCompat.f1855e = z10;
        boolean z11 = remoteActionCompat.f1856f;
        if (aVar.e(6)) {
            if (((b) aVar).f22394e.readInt() == 0) {
                z4 = false;
            }
            z11 = z4;
        }
        remoteActionCompat.f1856f = z11;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f1851a;
        aVar.i(1);
        aVar.k(iconCompat);
        CharSequence charSequence = remoteActionCompat.f1852b;
        aVar.i(2);
        Parcel parcel = ((b) aVar).f22394e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f1853c;
        aVar.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f1854d;
        aVar.i(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z4 = remoteActionCompat.f1855e;
        aVar.i(5);
        parcel.writeInt(z4 ? 1 : 0);
        boolean z10 = remoteActionCompat.f1856f;
        aVar.i(6);
        parcel.writeInt(z10 ? 1 : 0);
    }
}
