package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import m3.c;

public final class RemoteActionCompat implements c {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f1851a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f1852b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f1853c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f1854d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1855e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1856f;
}
