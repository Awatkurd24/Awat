package androidx.core.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import androidx.core.widget.NestedScrollView;

public final class a implements Parcelable.Creator {
    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.View$BaseSavedState, androidx.core.widget.NestedScrollView$SavedState, java.lang.Object] */
    public final Object createFromParcel(Parcel parcel) {
        ? baseSavedState = new View.BaseSavedState(parcel);
        baseSavedState.f1894a = parcel.readInt();
        return baseSavedState;
    }

    public final Object[] newArray(int i10) {
        return new NestedScrollView.SavedState[i10];
    }
}
