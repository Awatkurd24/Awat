package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import androidx.recyclerview.widget.b0;
import co.vpn.plusvpn.R;
import java.util.ArrayList;
import java.util.WeakHashMap;
import l7.a;
import r1.a0;
import r1.h1;
import r1.p0;
import r1.v0;
import r1.w;
import r1.x;
import r1.z;
import t.u;
import v1.e;
import v1.i;
import v1.j;
import v1.k;

public class NestedScrollView extends FrameLayout implements z, w {
    public static final float B = ((float) (Math.log(0.78d) / Math.log(0.9d)));
    public static final i C = new i(0);
    public static final int[] D = {16843130};
    public k A;

    /* renamed from: a  reason: collision with root package name */
    public final float f1868a;

    /* renamed from: b  reason: collision with root package name */
    public long f1869b;

    /* renamed from: c  reason: collision with root package name */
    public final Rect f1870c;

    /* renamed from: d  reason: collision with root package name */
    public final OverScroller f1871d;

    /* renamed from: e  reason: collision with root package name */
    public final EdgeEffect f1872e;

    /* renamed from: f  reason: collision with root package name */
    public final EdgeEffect f1873f;

    /* renamed from: g  reason: collision with root package name */
    public int f1874g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1875h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1876i;

    /* renamed from: j  reason: collision with root package name */
    public View f1877j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1878k;

    /* renamed from: l  reason: collision with root package name */
    public VelocityTracker f1879l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1880m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f1881n;

    /* renamed from: o  reason: collision with root package name */
    public final int f1882o;

    /* renamed from: p  reason: collision with root package name */
    public final int f1883p;

    /* renamed from: q  reason: collision with root package name */
    public final int f1884q;

    /* renamed from: r  reason: collision with root package name */
    public int f1885r;

    /* renamed from: s  reason: collision with root package name */
    public final int[] f1886s;

    /* renamed from: t  reason: collision with root package name */
    public final int[] f1887t;

    /* renamed from: u  reason: collision with root package name */
    public int f1888u;

    /* renamed from: v  reason: collision with root package name */
    public int f1889v;

    /* renamed from: w  reason: collision with root package name */
    public SavedState f1890w;

    /* renamed from: x  reason: collision with root package name */
    public final a0 f1891x;

    /* renamed from: y  reason: collision with root package name */
    public final x f1892y;

    /* renamed from: z  reason: collision with root package name */
    public float f1893z;

    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Object();

        /* renamed from: a  reason: collision with root package name */
        public int f1894a;

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("HorizontalScrollView.SavedState{");
            sb2.append(Integer.toHexString(System.identityHashCode(this)));
            sb2.append(" scrollPosition=");
            return u.e(sb2, this.f1894a, "}");
        }

        public final void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeInt(this.f1894a);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.nestedScrollViewStyle);
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f1893z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f1893z = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f1893z;
    }

    public static boolean l(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && l((View) parent, view2);
    }

    public final void a(View view, View view2, int i10, int i11) {
        a0 a0Var = this.f1891x;
        if (i11 == 1) {
            a0Var.f25157c = i10;
        } else {
            a0Var.f25156b = i10;
        }
        this.f1892y.h(2, i11);
    }

    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void b(View view, int i10) {
        a0 a0Var = this.f1891x;
        if (i10 == 1) {
            a0Var.f25157c = 0;
        } else {
            a0Var.f25156b = 0;
        }
        w(i10);
    }

    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        this.f1892y.c(i10, i11, i12, iArr, (int[]) null);
    }

    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x00a9  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00ec  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void computeScroll() {
        /*
            r14 = this;
            android.widget.OverScroller r0 = r14.f1871d
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x0009
            return
        L_0x0009:
            android.widget.OverScroller r0 = r14.f1871d
            r0.computeScrollOffset()
            android.widget.OverScroller r0 = r14.f1871d
            int r0 = r0.getCurrY()
            int r1 = r14.f1889v
            int r1 = r0 - r1
            int r2 = r14.getHeight()
            android.widget.EdgeEffect r3 = r14.f1873f
            android.widget.EdgeEffect r4 = r14.f1872e
            r5 = 1056964608(0x3f000000, float:0.5)
            r6 = 0
            r7 = 1082130432(0x40800000, float:4.0)
            if (r1 <= 0) goto L_0x0049
            float r8 = l7.a.w(r4)
            int r8 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r8 == 0) goto L_0x0049
            int r6 = -r1
            float r6 = (float) r6
            float r6 = r6 * r7
            float r8 = (float) r2
            float r6 = r6 / r8
            int r2 = -r2
            float r2 = (float) r2
            float r2 = r2 / r7
            float r5 = l7.a.F(r4, r6, r5)
            float r5 = r5 * r2
            int r2 = java.lang.Math.round(r5)
            if (r2 == r1) goto L_0x0047
            r4.finish()
        L_0x0047:
            int r1 = r1 - r2
            goto L_0x0069
        L_0x0049:
            if (r1 >= 0) goto L_0x0069
            float r8 = l7.a.w(r3)
            int r6 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r6 == 0) goto L_0x0069
            float r6 = (float) r1
            float r6 = r6 * r7
            float r2 = (float) r2
            float r6 = r6 / r2
            float r2 = r2 / r7
            float r5 = l7.a.F(r3, r6, r5)
            float r5 = r5 * r2
            int r2 = java.lang.Math.round(r5)
            if (r2 == r1) goto L_0x0047
            r3.finish()
            goto L_0x0047
        L_0x0069:
            r14.f1889v = r0
            int[] r0 = r14.f1887t
            r2 = 1
            r11 = 0
            r0[r2] = r11
            r6 = 0
            r8 = 1
            r10 = 0
            r1.x r5 = r14.f1892y
            r7 = r1
            r9 = r0
            r5.c(r6, r7, r8, r9, r10)
            r5 = r0[r2]
            int r1 = r1 - r5
            int r13 = r14.getScrollRange()
            if (r1 == 0) goto L_0x00a7
            int r5 = r14.getScrollY()
            int r6 = r14.getScrollX()
            r14.p(r1, r6, r5, r13)
            int r6 = r14.getScrollY()
            int r7 = r6 - r5
            int r1 = r1 - r7
            r0[r2] = r11
            int[] r10 = r14.f1886s
            r11 = 1
            r6 = 0
            r8 = 0
            r1.x r5 = r14.f1892y
            r9 = r1
            r12 = r0
            r5.e(r6, r7, r8, r9, r10, r11, r12)
            r0 = r0[r2]
            int r1 = r1 - r0
        L_0x00a7:
            if (r1 == 0) goto L_0x00de
            int r0 = r14.getOverScrollMode()
            if (r0 == 0) goto L_0x00b3
            if (r0 != r2) goto L_0x00d6
            if (r13 <= 0) goto L_0x00d6
        L_0x00b3:
            if (r1 >= 0) goto L_0x00c6
            boolean r0 = r4.isFinished()
            if (r0 == 0) goto L_0x00d6
            android.widget.OverScroller r0 = r14.f1871d
            float r0 = r0.getCurrVelocity()
            int r0 = (int) r0
            r4.onAbsorb(r0)
            goto L_0x00d6
        L_0x00c6:
            boolean r0 = r3.isFinished()
            if (r0 == 0) goto L_0x00d6
            android.widget.OverScroller r0 = r14.f1871d
            float r0 = r0.getCurrVelocity()
            int r0 = (int) r0
            r3.onAbsorb(r0)
        L_0x00d6:
            android.widget.OverScroller r0 = r14.f1871d
            r0.abortAnimation()
            r14.w(r2)
        L_0x00de:
            android.widget.OverScroller r0 = r14.f1871d
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x00ec
            java.util.WeakHashMap r0 = r1.h1.f25195a
            r1.p0.k(r14)
            goto L_0x00ef
        L_0x00ec:
            r14.w(r2)
        L_0x00ef:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.computeScroll():void");
    }

    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        n(i13, i14, iArr);
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || i(keyEvent);
    }

    public final boolean dispatchNestedFling(float f10, float f11, boolean z4) {
        return this.f1892y.a(f10, f11, z4);
    }

    public final boolean dispatchNestedPreFling(float f10, float f11) {
        return this.f1892y.b(f10, f11);
    }

    public final boolean dispatchNestedPreScroll(int i10, int i11, int[] iArr, int[] iArr2) {
        return this.f1892y.c(i10, i11, 0, iArr, iArr2);
    }

    public final boolean dispatchNestedScroll(int i10, int i11, int i12, int i13, int[] iArr) {
        return this.f1892y.e(i10, i11, i12, i13, iArr, 0, (int[]) null);
    }

    public final void draw(Canvas canvas) {
        int i10;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f1872e;
        int i11 = 0;
        if (!edgeEffect.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (j.a(this)) {
                width -= getPaddingRight() + getPaddingLeft();
                i10 = getPaddingLeft();
            } else {
                i10 = 0;
            }
            if (j.a(this)) {
                height -= getPaddingBottom() + getPaddingTop();
                min += getPaddingTop();
            }
            canvas.translate((float) i10, (float) min);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                WeakHashMap weakHashMap = h1.f25195a;
                p0.k(this);
            }
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect2 = this.f1873f;
        if (!edgeEffect2.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(getScrollRange(), scrollY) + height2;
            if (j.a(this)) {
                width2 -= getPaddingRight() + getPaddingLeft();
                i11 = getPaddingLeft();
            }
            if (j.a(this)) {
                height2 -= getPaddingBottom() + getPaddingTop();
                max -= getPaddingBottom();
            }
            canvas.translate((float) (i11 - width2), (float) max);
            canvas.rotate(180.0f, (float) width2, 0.0f);
            edgeEffect2.setSize(width2, height2);
            if (edgeEffect2.draw(canvas)) {
                WeakHashMap weakHashMap2 = h1.f25195a;
                p0.k(this);
            }
            canvas.restoreToCount(save2);
        }
    }

    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
        n(i13, i14, (int[]) null);
    }

    public final boolean f(View view, View view2, int i10, int i11) {
        return (i10 & 2) != 0;
    }

    public final boolean g(int i10) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i10);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !m(findNextFocus, maxScrollAmount, getHeight())) {
            if (i10 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i10 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i10 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, 0, 1, true);
        } else {
            Rect rect = this.f1870c;
            findNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findNextFocus, rect);
            s(h(rect), 0, 1, true);
            findNextFocus.requestFocus(i10);
        }
        if (findFocus != null && findFocus.isFocused() && (!m(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        a0 a0Var = this.f1891x;
        return a0Var.f25157c | a0Var.f25156b;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public final int h(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i10 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i11 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i10 - verticalFadingEdgeLength : i10;
        int i12 = rect.bottom;
        if (i12 > i11 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i11, (childAt.getBottom() + layoutParams.bottomMargin) - i10);
        } else if (rect.top >= scrollY || i12 >= i11) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i11 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    public final boolean hasNestedScrollingParent() {
        return this.f1892y.g(0);
    }

    public final boolean i(KeyEvent keyEvent) {
        this.f1870c.setEmpty();
        int i10 = 130;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() != 0) {
                    return false;
                }
                int keyCode = keyEvent.getKeyCode();
                if (keyCode != 19) {
                    if (keyCode != 20) {
                        if (keyCode != 62) {
                            if (keyCode != 92) {
                                if (keyCode != 93) {
                                    if (keyCode == 122) {
                                        q(33);
                                        return false;
                                    } else if (keyCode != 123) {
                                        return false;
                                    }
                                }
                            }
                        } else if (keyEvent.isShiftPressed()) {
                            i10 = 33;
                        }
                        q(i10);
                        return false;
                    } else if (!keyEvent.isAltPressed()) {
                        return g(130);
                    }
                    return k(130);
                } else if (!keyEvent.isAltPressed()) {
                    return g(33);
                }
                return k(33);
            }
        }
        if (!isFocused() || keyEvent.getKeyCode() == 4) {
            return false;
        }
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
        if (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) {
            return false;
        }
        return true;
    }

    public final boolean isNestedScrollingEnabled() {
        return this.f1892y.f25287d;
    }

    public final void j(int i10) {
        if (getChildCount() > 0) {
            this.f1871d.fling(getScrollX(), getScrollY(), 0, i10, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f1892y.h(2, 1);
            this.f1889v = getScrollY();
            WeakHashMap weakHashMap = h1.f25195a;
            p0.k(this);
        }
    }

    public final boolean k(int i10) {
        int childCount;
        boolean z4 = i10 == 130;
        int height = getHeight();
        Rect rect = this.f1870c;
        rect.top = 0;
        rect.bottom = height;
        if (z4 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            rect.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.top = rect.bottom - height;
        }
        return r(i10, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i10, int i11) {
        Rect rect = this.f1870c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i10 >= getScrollY() && rect.top - i10 <= getScrollY() + i11;
    }

    public final void measureChild(View view, int i10, int i11) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public final void measureChildWithMargins(View view, int i10, int i11, int i12, int i13) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i10, int i11, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i10);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f1892y.d(scrollY2, i10 - scrollY2, i11, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1885r) {
            int i10 = actionIndex == 0 ? 1 : 0;
            this.f1874g = (int) motionEvent.getY(i10);
            this.f1885r = motionEvent.getPointerId(i10);
            VelocityTracker velocityTracker = this.f1879l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1876i = false;
    }

    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        boolean z4;
        int i10;
        float f10;
        boolean z10 = false;
        if (motionEvent.getAction() == 8 && !this.f1878k) {
            if ((motionEvent.getSource() & 2) == 2) {
                z4 = true;
            } else {
                z4 = false;
            }
            if (z4) {
                f10 = motionEvent.getAxisValue(9);
                i10 = (int) motionEvent.getX();
            } else if ((motionEvent.getSource() & 4194304) == 4194304) {
                f10 = motionEvent.getAxisValue(26);
                i10 = getWidth() / 2;
            } else {
                f10 = 0.0f;
                i10 = 0;
            }
            if (f10 != 0.0f) {
                int verticalScrollFactorCompat = (int) (f10 * getVerticalScrollFactorCompat());
                if ((motionEvent.getSource() & 8194) == 8194) {
                    z10 = true;
                }
                s(-verticalScrollFactorCompat, i10, 1, z10);
                return true;
            }
        }
        return false;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z4 = true;
        if (action == 2 && this.f1878k) {
            return true;
        }
        int i10 = action & 255;
        if (i10 != 0) {
            if (i10 != 1) {
                if (i10 == 2) {
                    int i11 = this.f1885r;
                    if (i11 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i11);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i11 + " in onInterceptTouchEvent");
                        } else {
                            int y10 = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y10 - this.f1874g) > this.f1882o && (2 & getNestedScrollAxes()) == 0) {
                                this.f1878k = true;
                                this.f1874g = y10;
                                if (this.f1879l == null) {
                                    this.f1879l = VelocityTracker.obtain();
                                }
                                this.f1879l.addMovement(motionEvent);
                                this.f1888u = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                } else if (i10 != 3) {
                    if (i10 == 6) {
                        o(motionEvent);
                    }
                }
            }
            this.f1878k = false;
            this.f1885r = -1;
            VelocityTracker velocityTracker = this.f1879l;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.f1879l = null;
            }
            if (this.f1871d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                WeakHashMap weakHashMap = h1.f25195a;
                p0.k(this);
            }
            w(0);
        } else {
            int y11 = (int) motionEvent.getY();
            int x4 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y11 >= childAt.getTop() - scrollY && y11 < childAt.getBottom() - scrollY && x4 >= childAt.getLeft() && x4 < childAt.getRight()) {
                    this.f1874g = y11;
                    this.f1885r = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker2 = this.f1879l;
                    if (velocityTracker2 == null) {
                        this.f1879l = VelocityTracker.obtain();
                    } else {
                        velocityTracker2.clear();
                    }
                    this.f1879l.addMovement(motionEvent);
                    this.f1871d.computeScrollOffset();
                    if (!v(motionEvent) && this.f1871d.isFinished()) {
                        z4 = false;
                    }
                    this.f1878k = z4;
                    this.f1892y.h(2, 0);
                }
            }
            if (!v(motionEvent) && this.f1871d.isFinished()) {
                z4 = false;
            }
            this.f1878k = z4;
            VelocityTracker velocityTracker3 = this.f1879l;
            if (velocityTracker3 != null) {
                velocityTracker3.recycle();
                this.f1879l = null;
            }
        }
        return this.f1878k;
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        int i14;
        super.onLayout(z4, i10, i11, i12, i13);
        int i15 = 0;
        this.f1875h = false;
        View view = this.f1877j;
        if (view != null && l(view, this)) {
            View view2 = this.f1877j;
            Rect rect = this.f1870c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h10 = h(rect);
            if (h10 != 0) {
                scrollBy(0, h10);
            }
        }
        this.f1877j = null;
        if (!this.f1876i) {
            if (this.f1890w != null) {
                scrollTo(getScrollX(), this.f1890w.f1894a);
                this.f1890w = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i14 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                i14 = 0;
            }
            int paddingTop = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < i14 && scrollY >= 0) {
                i15 = paddingTop + scrollY > i14 ? i14 - paddingTop : scrollY;
            }
            if (i15 != scrollY) {
                scrollTo(getScrollX(), i15);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1876i = true;
    }

    public final void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        if (this.f1880m && View.MeasureSpec.getMode(i11) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public final boolean onNestedFling(View view, float f10, float f11, boolean z4) {
        if (z4) {
            return false;
        }
        dispatchNestedFling(0.0f, f11, true);
        j((int) f11);
        return true;
    }

    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return dispatchNestedPreFling(f10, f11);
    }

    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        this.f1892y.c(i10, i11, 0, iArr, (int[]) null);
    }

    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        n(i13, 0, (int[]) null);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        a(view, view2, i10, 0);
    }

    public final void onOverScrolled(int i10, int i11, boolean z4, boolean z10) {
        super.scrollTo(i10, i11);
    }

    public final boolean onRequestFocusInDescendants(int i10, Rect rect) {
        View view;
        if (i10 == 2) {
            i10 = 130;
        } else if (i10 == 1) {
            i10 = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        if (rect == null) {
            view = instance.findNextFocus(this, (View) null, i10);
        } else {
            view = instance.findNextFocusFromRect(this, rect, i10);
        }
        if (view != null && !(true ^ m(view, 0, getHeight()))) {
            return view.requestFocus(i10, rect);
        }
        return false;
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f1890w = savedState;
        requestLayout();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View$BaseSavedState, androidx.core.widget.NestedScrollView$SavedState, android.os.Parcelable] */
    public final Parcelable onSaveInstanceState() {
        ? baseSavedState = new View.BaseSavedState(super.onSaveInstanceState());
        baseSavedState.f1894a = getScrollY();
        return baseSavedState;
    }

    public final void onScrollChanged(int i10, int i11, int i12, int i13) {
        super.onScrollChanged(i10, i11, i12, i13);
        k kVar = this.A;
        if (kVar != null) {
            kVar.m(this);
        }
    }

    public final void onSizeChanged(int i10, int i11, int i12, int i13) {
        super.onSizeChanged(i10, i11, i12, i13);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m(findFocus, 0, i13)) {
            Rect rect = this.f1870c;
            findFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findFocus, rect);
            int h10 = h(rect);
            if (h10 == 0) {
                return;
            }
            if (this.f1881n) {
                u(0, h10, false);
            } else {
                scrollBy(0, h10);
            }
        }
    }

    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return f(view, view2, i10, 0);
    }

    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x008e, code lost:
        if (r1 != null) goto L_0x0090;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x01d3, code lost:
        if (r1 != null) goto L_0x0090;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r20) {
        /*
            r19 = this;
            r0 = r19
            r1 = r20
            android.view.VelocityTracker r2 = r0.f1879l
            if (r2 != 0) goto L_0x000e
            android.view.VelocityTracker r2 = android.view.VelocityTracker.obtain()
            r0.f1879l = r2
        L_0x000e:
            int r2 = r20.getActionMasked()
            r3 = 0
            if (r2 != 0) goto L_0x0017
            r0.f1888u = r3
        L_0x0017:
            android.view.MotionEvent r4 = android.view.MotionEvent.obtain(r20)
            int r5 = r0.f1888u
            float r5 = (float) r5
            r6 = 0
            r4.offsetLocation(r6, r5)
            r5 = 1
            r7 = 2
            if (r2 == 0) goto L_0x01d7
            android.widget.EdgeEffect r8 = r0.f1873f
            android.widget.EdgeEffect r9 = r0.f1872e
            r10 = 0
            r11 = -1
            if (r2 == r5) goto L_0x015d
            if (r2 == r7) goto L_0x00a4
            r6 = 3
            if (r2 == r6) goto L_0x0060
            r3 = 5
            if (r2 == r3) goto L_0x004d
            r3 = 6
            if (r2 == r3) goto L_0x003b
            goto L_0x020d
        L_0x003b:
            r19.o(r20)
            int r2 = r0.f1885r
            int r2 = r1.findPointerIndex(r2)
            float r1 = r1.getY(r2)
            int r1 = (int) r1
            r0.f1874g = r1
            goto L_0x020d
        L_0x004d:
            int r2 = r20.getActionIndex()
            float r3 = r1.getY(r2)
            int r3 = (int) r3
            r0.f1874g = r3
            int r1 = r1.getPointerId(r2)
            r0.f1885r = r1
            goto L_0x020d
        L_0x0060:
            boolean r1 = r0.f1878k
            if (r1 == 0) goto L_0x0088
            int r1 = r19.getChildCount()
            if (r1 <= 0) goto L_0x0088
            android.widget.OverScroller r12 = r0.f1871d
            int r13 = r19.getScrollX()
            int r14 = r19.getScrollY()
            r15 = 0
            r16 = 0
            r17 = 0
            int r18 = r19.getScrollRange()
            boolean r1 = r12.springBack(r13, r14, r15, r16, r17, r18)
            if (r1 == 0) goto L_0x0088
            java.util.WeakHashMap r1 = r1.h1.f25195a
            r1.p0.k(r19)
        L_0x0088:
            r0.f1885r = r11
            r0.f1878k = r3
            android.view.VelocityTracker r1 = r0.f1879l
            if (r1 == 0) goto L_0x0095
        L_0x0090:
            r1.recycle()
            r0.f1879l = r10
        L_0x0095:
            r0.w(r3)
            android.widget.EdgeEffect r1 = r0.f1872e
            r1.onRelease()
            android.widget.EdgeEffect r1 = r0.f1873f
            r1.onRelease()
            goto L_0x020d
        L_0x00a4:
            int r2 = r0.f1885r
            int r2 = r1.findPointerIndex(r2)
            if (r2 != r11) goto L_0x00c8
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Invalid pointerId="
            r1.<init>(r2)
            int r2 = r0.f1885r
            r1.append(r2)
            java.lang.String r2 = " in onTouchEvent"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            java.lang.String r2 = "NestedScrollView"
            android.util.Log.e(r2, r1)
            goto L_0x020d
        L_0x00c8:
            float r7 = r1.getY(r2)
            int r7 = (int) r7
            int r10 = r0.f1874g
            int r10 = r10 - r7
            float r11 = r1.getX(r2)
            int r12 = r19.getWidth()
            float r12 = (float) r12
            float r11 = r11 / r12
            float r12 = (float) r10
            int r13 = r19.getHeight()
            float r13 = (float) r13
            float r12 = r12 / r13
            float r13 = l7.a.w(r9)
            int r13 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r13 == 0) goto L_0x00fc
            float r8 = -r12
            float r8 = l7.a.F(r9, r8, r11)
            float r8 = -r8
            float r11 = l7.a.w(r9)
            int r6 = (r11 > r6 ? 1 : (r11 == r6 ? 0 : -1))
            if (r6 != 0) goto L_0x00fa
            r9.onRelease()
        L_0x00fa:
            r6 = r8
            goto L_0x0117
        L_0x00fc:
            float r9 = l7.a.w(r8)
            int r9 = (r9 > r6 ? 1 : (r9 == r6 ? 0 : -1))
            if (r9 == 0) goto L_0x0117
            r9 = 1065353216(0x3f800000, float:1.0)
            float r9 = r9 - r11
            float r9 = l7.a.F(r8, r12, r9)
            float r11 = l7.a.w(r8)
            int r6 = (r11 > r6 ? 1 : (r11 == r6 ? 0 : -1))
            if (r6 != 0) goto L_0x0116
            r8.onRelease()
        L_0x0116:
            r6 = r9
        L_0x0117:
            int r8 = r19.getHeight()
            float r8 = (float) r8
            float r6 = r6 * r8
            int r6 = java.lang.Math.round(r6)
            if (r6 == 0) goto L_0x0127
            r19.invalidate()
        L_0x0127:
            int r10 = r10 - r6
            boolean r6 = r0.f1878k
            if (r6 != 0) goto L_0x0146
            int r6 = java.lang.Math.abs(r10)
            int r8 = r0.f1882o
            if (r6 <= r8) goto L_0x0146
            android.view.ViewParent r6 = r19.getParent()
            if (r6 == 0) goto L_0x013d
            r6.requestDisallowInterceptTouchEvent(r5)
        L_0x013d:
            r0.f1878k = r5
            int r6 = r0.f1882o
            if (r10 <= 0) goto L_0x0145
            int r10 = r10 - r6
            goto L_0x0146
        L_0x0145:
            int r10 = r10 + r6
        L_0x0146:
            boolean r6 = r0.f1878k
            if (r6 == 0) goto L_0x020d
            float r1 = r1.getX(r2)
            int r1 = (int) r1
            int r1 = r0.s(r10, r1, r3, r3)
            int r7 = r7 - r1
            r0.f1874g = r7
            int r2 = r0.f1888u
            int r2 = r2 + r1
            r0.f1888u = r2
            goto L_0x020d
        L_0x015d:
            android.view.VelocityTracker r1 = r0.f1879l
            int r2 = r0.f1884q
            float r2 = (float) r2
            r7 = 1000(0x3e8, float:1.401E-42)
            r1.computeCurrentVelocity(r7, r2)
            int r2 = r0.f1885r
            float r1 = r1.getYVelocity(r2)
            int r1 = (int) r1
            int r2 = java.lang.Math.abs(r1)
            int r7 = r0.f1883p
            if (r2 < r7) goto L_0x01af
            float r2 = l7.a.w(r9)
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 == 0) goto L_0x018d
            boolean r2 = r0.t(r9, r1)
            if (r2 == 0) goto L_0x0188
            r9.onAbsorb(r1)
            goto L_0x01cd
        L_0x0188:
            int r1 = -r1
        L_0x0189:
            r0.j(r1)
            goto L_0x01cd
        L_0x018d:
            float r2 = l7.a.w(r8)
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 == 0) goto L_0x01a0
            int r1 = -r1
            boolean r2 = r0.t(r8, r1)
            if (r2 == 0) goto L_0x0189
            r8.onAbsorb(r1)
            goto L_0x01cd
        L_0x01a0:
            int r1 = -r1
            float r2 = (float) r1
            boolean r7 = r0.dispatchNestedPreFling(r6, r2)
            if (r7 != 0) goto L_0x01cd
            r0.dispatchNestedFling(r6, r2, r5)
            r0.j(r1)
            goto L_0x01cd
        L_0x01af:
            android.widget.OverScroller r12 = r0.f1871d
            int r13 = r19.getScrollX()
            int r14 = r19.getScrollY()
            r15 = 0
            r16 = 0
            r17 = 0
            int r18 = r19.getScrollRange()
            boolean r1 = r12.springBack(r13, r14, r15, r16, r17, r18)
            if (r1 == 0) goto L_0x01cd
            java.util.WeakHashMap r1 = r1.h1.f25195a
            r1.p0.k(r19)
        L_0x01cd:
            r0.f1885r = r11
            r0.f1878k = r3
            android.view.VelocityTracker r1 = r0.f1879l
            if (r1 == 0) goto L_0x0095
            goto L_0x0090
        L_0x01d7:
            int r2 = r19.getChildCount()
            if (r2 != 0) goto L_0x01de
            return r3
        L_0x01de:
            boolean r2 = r0.f1878k
            if (r2 == 0) goto L_0x01eb
            android.view.ViewParent r2 = r19.getParent()
            if (r2 == 0) goto L_0x01eb
            r2.requestDisallowInterceptTouchEvent(r5)
        L_0x01eb:
            android.widget.OverScroller r2 = r0.f1871d
            boolean r2 = r2.isFinished()
            if (r2 != 0) goto L_0x01fb
            android.widget.OverScroller r2 = r0.f1871d
            r2.abortAnimation()
            r0.w(r5)
        L_0x01fb:
            float r2 = r20.getY()
            int r2 = (int) r2
            int r1 = r1.getPointerId(r3)
            r0.f1874g = r2
            r0.f1885r = r1
            r1.x r1 = r0.f1892y
            r1.h(r7, r3)
        L_0x020d:
            android.view.VelocityTracker r1 = r0.f1879l
            if (r1 == 0) goto L_0x0214
            r1.addMovement(r4)
        L_0x0214:
            r4.recycle()
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final boolean p(int i10, int i11, int i12, int i13) {
        boolean z4;
        boolean z10;
        int overScrollMode = getOverScrollMode();
        computeHorizontalScrollRange();
        computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        computeVerticalScrollExtent();
        int i14 = i12 + i10;
        if (i11 <= 0 && i11 >= 0) {
            z4 = false;
        } else {
            i11 = 0;
            z4 = true;
        }
        if (i14 > i13) {
            z10 = true;
        } else if (i14 < 0) {
            z10 = true;
            i13 = 0;
        } else {
            i13 = i14;
            z10 = false;
        }
        if (z10 && !this.f1892y.g(1)) {
            this.f1871d.springBack(i11, i13, 0, 0, 0, getScrollRange());
        }
        onOverScrolled(i11, i13, z4, z10);
        if (z4 || z10) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0043, code lost:
        if (r0 < 0) goto L_0x0045;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void q(int r6) {
        /*
            r5 = this;
            r0 = 130(0x82, float:1.82E-43)
            r1 = 0
            r2 = 1
            if (r6 != r0) goto L_0x0008
            r0 = 1
            goto L_0x0009
        L_0x0008:
            r0 = 0
        L_0x0009:
            int r3 = r5.getHeight()
            android.graphics.Rect r4 = r5.f1870c
            if (r0 == 0) goto L_0x003c
            int r0 = r5.getScrollY()
            int r0 = r0 + r3
            r4.top = r0
            int r0 = r5.getChildCount()
            if (r0 <= 0) goto L_0x0047
            int r0 = r0 - r2
            android.view.View r0 = r5.getChildAt(r0)
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r0 = r0.getBottom()
            int r1 = r1.bottomMargin
            int r0 = r0 + r1
            int r1 = r5.getPaddingBottom()
            int r1 = r1 + r0
            int r0 = r4.top
            int r0 = r0 + r3
            if (r0 <= r1) goto L_0x0047
            int r1 = r1 - r3
            goto L_0x0045
        L_0x003c:
            int r0 = r5.getScrollY()
            int r0 = r0 - r3
            r4.top = r0
            if (r0 >= 0) goto L_0x0047
        L_0x0045:
            r4.top = r1
        L_0x0047:
            int r0 = r4.top
            int r3 = r3 + r0
            r4.bottom = r3
            r5.r(r6, r0, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.q(int):void");
    }

    public final boolean r(int i10, int i11, int i12) {
        boolean z4;
        boolean z10;
        int i13;
        boolean z11;
        boolean z12;
        int i14 = i10;
        int i15 = i11;
        int i16 = i12;
        int height = getHeight();
        int scrollY = getScrollY();
        int i17 = height + scrollY;
        if (i14 == 33) {
            z4 = true;
        } else {
            z4 = false;
        }
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z13 = false;
        for (int i18 = 0; i18 < size; i18++) {
            View view2 = focusables.get(i18);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i15 < bottom && top < i16) {
                if (i15 >= top || bottom >= i16) {
                    z11 = false;
                } else {
                    z11 = true;
                }
                if (view == null) {
                    view = view2;
                    z13 = z11;
                } else {
                    if ((!z4 || top >= view.getTop()) && (z4 || bottom <= view.getBottom())) {
                        z12 = false;
                    } else {
                        z12 = true;
                    }
                    if (z13) {
                        if (z11) {
                            if (!z12) {
                            }
                        }
                    } else if (z11) {
                        view = view2;
                        z13 = true;
                    } else if (!z12) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i15 < scrollY || i16 > i17) {
            if (z4) {
                i13 = i15 - scrollY;
            } else {
                i13 = i16 - i17;
            }
            s(i13, 0, 1, true);
            z10 = true;
        } else {
            z10 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i14);
        }
        return z10;
    }

    public final void requestChildFocus(View view, View view2) {
        if (!this.f1875h) {
            Rect rect = this.f1870c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h10 = h(rect);
            if (h10 != 0) {
                scrollBy(0, h10);
            }
        } else {
            this.f1877j = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z4) {
        boolean z10;
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int h10 = h(rect);
        if (h10 != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            if (z4) {
                scrollBy(0, h10);
            } else {
                u(0, h10, false);
            }
        }
        return z10;
    }

    public final void requestDisallowInterceptTouchEvent(boolean z4) {
        VelocityTracker velocityTracker;
        if (z4 && (velocityTracker = this.f1879l) != null) {
            velocityTracker.recycle();
            this.f1879l = null;
        }
        super.requestDisallowInterceptTouchEvent(z4);
    }

    public final void requestLayout() {
        this.f1875h = true;
        super.requestLayout();
    }

    public final int s(int i10, int i11, int i12, boolean z4) {
        int i13;
        int i14;
        boolean z10;
        boolean z11;
        int i15 = i11;
        int i16 = i12;
        x xVar = this.f1892y;
        if (i16 == 1) {
            xVar.h(2, i16);
        }
        boolean c10 = this.f1892y.c(0, i10, i12, this.f1887t, this.f1886s);
        int[] iArr = this.f1887t;
        int[] iArr2 = this.f1886s;
        if (c10) {
            i14 = i10 - iArr[1];
            i13 = iArr2[1];
        } else {
            i14 = i10;
            i13 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        if ((overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z4) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!p(i14, 0, scrollY, scrollRange) || xVar.g(i16)) {
            z11 = false;
        } else {
            z11 = true;
        }
        int scrollY2 = getScrollY() - scrollY;
        iArr[1] = 0;
        int[] iArr3 = this.f1886s;
        int i17 = scrollRange;
        this.f1892y.e(0, scrollY2, 0, i14 - scrollY2, iArr3, i12, iArr);
        int i18 = i13 + iArr2[1];
        int i19 = i14 - iArr[1];
        int i20 = scrollY + i19;
        EdgeEffect edgeEffect = this.f1873f;
        EdgeEffect edgeEffect2 = this.f1872e;
        if (i20 < 0) {
            if (z10) {
                a.F(edgeEffect2, ((float) (-i19)) / ((float) getHeight()), ((float) i15) / ((float) getWidth()));
                if (!edgeEffect.isFinished()) {
                    edgeEffect.onRelease();
                }
            }
        } else if (i20 > i17 && z10) {
            a.F(edgeEffect, ((float) i19) / ((float) getHeight()), 1.0f - (((float) i15) / ((float) getWidth())));
            if (!edgeEffect2.isFinished()) {
                edgeEffect2.onRelease();
            }
        }
        if (!edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
            WeakHashMap weakHashMap = h1.f25195a;
            p0.k(this);
        } else if (z11 && i16 == 0) {
            this.f1879l.clear();
        }
        if (i16 == 1) {
            w(i16);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i18;
    }

    public final void scrollTo(int i10, int i11) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i10 < 0) {
                i10 = 0;
            } else if (width + i10 > width2) {
                i10 = width2 - width;
            }
            if (height >= height2 || i11 < 0) {
                i11 = 0;
            } else if (height + i11 > height2) {
                i11 = height2 - height;
            }
            if (i10 != getScrollX() || i11 != getScrollY()) {
                super.scrollTo(i10, i11);
            }
        }
    }

    public void setFillViewport(boolean z4) {
        if (z4 != this.f1880m) {
            this.f1880m = z4;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z4) {
        x xVar = this.f1892y;
        if (xVar.f25287d) {
            WeakHashMap weakHashMap = h1.f25195a;
            v0.z(xVar.f25286c);
        }
        xVar.f25287d = z4;
    }

    public void setOnScrollChangeListener(k kVar) {
        this.A = kVar;
    }

    public void setSmoothScrollingEnabled(boolean z4) {
        this.f1881n = z4;
    }

    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    public final boolean startNestedScroll(int i10) {
        return this.f1892y.h(i10, 0);
    }

    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i10) {
        if (i10 > 0) {
            return true;
        }
        float w10 = a.w(edgeEffect) * ((float) getHeight());
        float f10 = this.f1868a * 0.015f;
        double log = Math.log((double) ((((float) Math.abs(-i10)) * 0.35f) / f10));
        double d10 = (double) B;
        if (((float) (Math.exp((d10 / (d10 - 1.0d)) * log) * ((double) f10))) < w10) {
            return true;
        }
        return false;
    }

    public final void u(int i10, int i11, boolean z4) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f1869b > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f1871d;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i11 + scrollY, Math.max(0, height - height2))) - scrollY, b0.DEFAULT_SWIPE_ANIMATION_DURATION);
                if (z4) {
                    this.f1892y.h(2, 1);
                } else {
                    w(1);
                }
                this.f1889v = getScrollY();
                WeakHashMap weakHashMap = h1.f25195a;
                p0.k(this);
            } else {
                if (!this.f1871d.isFinished()) {
                    this.f1871d.abortAnimation();
                    w(1);
                }
                scrollBy(i10, i11);
            }
            this.f1869b = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z4;
        EdgeEffect edgeEffect = this.f1872e;
        if (a.w(edgeEffect) != 0.0f) {
            a.F(edgeEffect, 0.0f, motionEvent.getX() / ((float) getWidth()));
            z4 = true;
        } else {
            z4 = false;
        }
        EdgeEffect edgeEffect2 = this.f1873f;
        if (a.w(edgeEffect2) == 0.0f) {
            return z4;
        }
        a.F(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / ((float) getWidth())));
        return true;
    }

    public final void w(int i10) {
        this.f1892y.i(i10);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1870c = new Rect();
        this.f1875h = true;
        this.f1876i = false;
        this.f1877j = null;
        this.f1878k = false;
        this.f1881n = true;
        this.f1885r = -1;
        this.f1886s = new int[2];
        this.f1887t = new int[2];
        int i11 = Build.VERSION.SDK_INT;
        this.f1872e = i11 >= 31 ? e.a(context, attributeSet) : new EdgeEffect(context);
        this.f1873f = i11 >= 31 ? e.a(context, attributeSet) : new EdgeEffect(context);
        this.f1868a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f1871d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1882o = viewConfiguration.getScaledTouchSlop();
        this.f1883p = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1884q = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, D, i10, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f1891x = new a0(0);
        this.f1892y = new x(this);
        setNestedScrollingEnabled(true);
        h1.r(this, C);
    }

    public final void addView(View view, int i10) {
        if (getChildCount() <= 0) {
            super.addView(view, i10);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i10, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
