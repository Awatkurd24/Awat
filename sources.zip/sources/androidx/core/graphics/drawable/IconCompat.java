package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;
import k1.d;
import k1.f;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k  reason: collision with root package name */
    public static final PorterDuff.Mode f1857k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    public int f1858a;

    /* renamed from: b  reason: collision with root package name */
    public Object f1859b;

    /* renamed from: c  reason: collision with root package name */
    public byte[] f1860c;

    /* renamed from: d  reason: collision with root package name */
    public Parcelable f1861d;

    /* renamed from: e  reason: collision with root package name */
    public int f1862e;

    /* renamed from: f  reason: collision with root package name */
    public int f1863f;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f1864g;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f1865h;

    /* renamed from: i  reason: collision with root package name */
    public String f1866i;

    /* renamed from: j  reason: collision with root package name */
    public String f1867j;

    public IconCompat() {
        this.f1858a = -1;
        this.f1860c = null;
        this.f1861d = null;
        this.f1862e = 0;
        this.f1863f = 0;
        this.f1864g = null;
        this.f1865h = f1857k;
        this.f1866i = null;
    }

    public static Bitmap a(Bitmap bitmap, boolean z4) {
        int min = (int) (((float) Math.min(bitmap.getWidth(), bitmap.getHeight())) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f10 = (float) min;
        float f11 = 0.5f * f10;
        float f12 = 0.9166667f * f11;
        if (z4) {
            float f13 = 0.010416667f * f10;
            paint.setColor(0);
            paint.setShadowLayer(f13, 0.0f, f10 * 0.020833334f, 1023410176);
            canvas.drawCircle(f11, f11, f12, paint);
            paint.setShadowLayer(f13, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f11, f11, f12, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate(((float) (-(bitmap.getWidth() - min))) / 2.0f, ((float) (-(bitmap.getHeight() - min))) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f11, f11, f12, paint);
        canvas.setBitmap((Bitmap) null);
        return createBitmap;
    }

    public static IconCompat b(int i10) {
        if (i10 != 0) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.f1862e = i10;
            iconCompat.f1859b = "";
            iconCompat.f1867j = "";
            return iconCompat;
        }
        throw new IllegalArgumentException("Drawable resource ID must not be 0");
    }

    public final Bitmap c() {
        int i10 = this.f1858a;
        if (i10 == -1 && Build.VERSION.SDK_INT >= 23) {
            Object obj = this.f1859b;
            if (obj instanceof Bitmap) {
                return (Bitmap) obj;
            }
            return null;
        } else if (i10 == 1) {
            return (Bitmap) this.f1859b;
        } else {
            if (i10 == 5) {
                return a((Bitmap) this.f1859b, true);
            }
            throw new IllegalStateException("called getBitmap() on " + this);
        }
    }

    public final int d() {
        int i10;
        int i11 = this.f1858a;
        if (i11 == -1 && (i10 = Build.VERSION.SDK_INT) >= 23) {
            Object obj = this.f1859b;
            if (i10 >= 28) {
                return f.a(obj);
            }
            try {
                return ((Integer) obj.getClass().getMethod("getResId", new Class[0]).invoke(obj, new Object[0])).intValue();
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e10) {
                Log.e("IconCompat", "Unable to get icon resource", e10);
                return 0;
            }
        } else if (i11 == 2) {
            return this.f1862e;
        } else {
            throw new IllegalStateException("called getResId() on " + this);
        }
    }

    public final int e() {
        int i10;
        StringBuilder sb2;
        int i11 = this.f1858a;
        if (i11 != -1 || (i10 = Build.VERSION.SDK_INT) < 23) {
            return i11;
        }
        Object obj = this.f1859b;
        if (i10 >= 28) {
            return f.c(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getType", new Class[0]).invoke(obj, new Object[0])).intValue();
        } catch (IllegalAccessException e10) {
            e = e10;
            sb2 = new StringBuilder("Unable to get icon type ");
            sb2.append(obj);
            Log.e("IconCompat", sb2.toString(), e);
            return -1;
        } catch (InvocationTargetException e11) {
            e = e11;
            sb2 = new StringBuilder("Unable to get icon type ");
            sb2.append(obj);
            Log.e("IconCompat", sb2.toString(), e);
            return -1;
        } catch (NoSuchMethodException e12) {
            e = e12;
            sb2 = new StringBuilder("Unable to get icon type ");
            sb2.append(obj);
            Log.e("IconCompat", sb2.toString(), e);
            return -1;
        }
    }

    public final Uri f() {
        int i10 = this.f1858a;
        if (i10 == -1 && Build.VERSION.SDK_INT >= 23) {
            return d.a(this.f1859b);
        }
        if (i10 == 4 || i10 == 6) {
            return Uri.parse((String) this.f1859b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public final Icon g(Context context) {
        if (Build.VERSION.SDK_INT >= 23) {
            return d.c(this, context);
        }
        throw new UnsupportedOperationException("This method is only supported on API level 23+");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String toString() {
        /*
            r4 = this;
            int r0 = r4.f1858a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r4.f1859b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r4.f1858a
            switch(r1) {
                case 1: goto L_0x002a;
                case 2: goto L_0x0027;
                case 3: goto L_0x0024;
                case 4: goto L_0x0021;
                case 5: goto L_0x001e;
                case 6: goto L_0x001b;
                default: goto L_0x0018;
            }
        L_0x0018:
            java.lang.String r1 = "UNKNOWN"
            goto L_0x002c
        L_0x001b:
            java.lang.String r1 = "URI_MASKABLE"
            goto L_0x002c
        L_0x001e:
            java.lang.String r1 = "BITMAP_MASKABLE"
            goto L_0x002c
        L_0x0021:
            java.lang.String r1 = "URI"
            goto L_0x002c
        L_0x0024:
            java.lang.String r1 = "DATA"
            goto L_0x002c
        L_0x0027:
            java.lang.String r1 = "RESOURCE"
            goto L_0x002c
        L_0x002a:
            java.lang.String r1 = "BITMAP"
        L_0x002c:
            r0.append(r1)
            int r1 = r4.f1858a
            switch(r1) {
                case 1: goto L_0x0080;
                case 2: goto L_0x0059;
                case 3: goto L_0x0040;
                case 4: goto L_0x0035;
                case 5: goto L_0x0080;
                case 6: goto L_0x0035;
                default: goto L_0x0034;
            }
        L_0x0034:
            goto L_0x009e
        L_0x0035:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r4.f1859b
            r0.append(r1)
            goto L_0x009e
        L_0x0040:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r4.f1862e
            r0.append(r1)
            int r1 = r4.f1863f
            if (r1 == 0) goto L_0x009e
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r4.f1863f
        L_0x0055:
            r0.append(r1)
            goto L_0x009e
        L_0x0059:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r4.f1867j
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            int r2 = r4.d()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r3 = 0
            r1[r3] = r2
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x009e
        L_0x0080:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r4.f1859b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r4.f1859b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
            goto L_0x0055
        L_0x009e:
            android.content.res.ColorStateList r1 = r4.f1864g
            if (r1 == 0) goto L_0x00ac
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r4.f1864g
            r0.append(r1)
        L_0x00ac:
            android.graphics.PorterDuff$Mode r1 = r4.f1865h
            android.graphics.PorterDuff$Mode r2 = f1857k
            if (r1 == r2) goto L_0x00bc
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r4.f1865h
            r0.append(r1)
        L_0x00bc:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }

    public IconCompat(int i10) {
        this.f1860c = null;
        this.f1861d = null;
        this.f1862e = 0;
        this.f1863f = 0;
        this.f1864g = null;
        this.f1865h = f1857k;
        this.f1866i = null;
        this.f1858a = i10;
    }
}
