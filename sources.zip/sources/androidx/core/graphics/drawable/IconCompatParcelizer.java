package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import m3.a;
import m3.b;

public class IconCompatParcelizer {
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static androidx.core.graphics.drawable.IconCompat read(m3.a r5) {
        /*
            androidx.core.graphics.drawable.IconCompat r0 = new androidx.core.graphics.drawable.IconCompat
            r0.<init>()
            int r1 = r0.f1858a
            r2 = 1
            int r1 = r5.f(r1, r2)
            r0.f1858a = r1
            byte[] r1 = r0.f1860c
            r2 = 2
            boolean r3 = r5.e(r2)
            if (r3 != 0) goto L_0x0018
            goto L_0x002b
        L_0x0018:
            r1 = r5
            m3.b r1 = (m3.b) r1
            android.os.Parcel r1 = r1.f22394e
            int r3 = r1.readInt()
            if (r3 >= 0) goto L_0x0025
            r1 = 0
            goto L_0x002b
        L_0x0025:
            byte[] r3 = new byte[r3]
            r1.readByteArray(r3)
            r1 = r3
        L_0x002b:
            r0.f1860c = r1
            android.os.Parcelable r1 = r0.f1861d
            r3 = 3
            android.os.Parcelable r1 = r5.g(r1, r3)
            r0.f1861d = r1
            int r1 = r0.f1862e
            r4 = 4
            int r1 = r5.f(r1, r4)
            r0.f1862e = r1
            int r1 = r0.f1863f
            r4 = 5
            int r1 = r5.f(r1, r4)
            r0.f1863f = r1
            android.content.res.ColorStateList r1 = r0.f1864g
            r4 = 6
            android.os.Parcelable r1 = r5.g(r1, r4)
            android.content.res.ColorStateList r1 = (android.content.res.ColorStateList) r1
            r0.f1864g = r1
            java.lang.String r1 = r0.f1866i
            r4 = 7
            boolean r4 = r5.e(r4)
            if (r4 != 0) goto L_0x005d
            goto L_0x0066
        L_0x005d:
            r1 = r5
            m3.b r1 = (m3.b) r1
            android.os.Parcel r1 = r1.f22394e
            java.lang.String r1 = r1.readString()
        L_0x0066:
            r0.f1866i = r1
            java.lang.String r1 = r0.f1867j
            r4 = 8
            boolean r4 = r5.e(r4)
            if (r4 != 0) goto L_0x0073
            goto L_0x007b
        L_0x0073:
            m3.b r5 = (m3.b) r5
            android.os.Parcel r5 = r5.f22394e
            java.lang.String r1 = r5.readString()
        L_0x007b:
            r0.f1867j = r1
            java.lang.String r5 = r0.f1866i
            android.graphics.PorterDuff$Mode r5 = android.graphics.PorterDuff.Mode.valueOf(r5)
            r0.f1865h = r5
            int r5 = r0.f1858a
            r1 = 0
            switch(r5) {
                case -1: goto L_0x00c7;
                case 0: goto L_0x008b;
                case 1: goto L_0x00b4;
                case 2: goto L_0x0091;
                case 3: goto L_0x008c;
                case 4: goto L_0x0091;
                case 5: goto L_0x00b4;
                case 6: goto L_0x0091;
                default: goto L_0x008b;
            }
        L_0x008b:
            goto L_0x00cc
        L_0x008c:
            byte[] r5 = r0.f1860c
            r0.f1859b = r5
            goto L_0x00cc
        L_0x0091:
            java.lang.String r5 = new java.lang.String
            byte[] r3 = r0.f1860c
            java.lang.String r4 = "UTF-16"
            java.nio.charset.Charset r4 = java.nio.charset.Charset.forName(r4)
            r5.<init>(r3, r4)
            r0.f1859b = r5
            int r3 = r0.f1858a
            if (r3 != r2) goto L_0x00cc
            java.lang.String r2 = r0.f1867j
            if (r2 != 0) goto L_0x00cc
            java.lang.String r2 = ":"
            r3 = -1
            java.lang.String[] r5 = r5.split(r2, r3)
            r5 = r5[r1]
            r0.f1867j = r5
            goto L_0x00cc
        L_0x00b4:
            android.os.Parcelable r5 = r0.f1861d
            if (r5 == 0) goto L_0x00bb
        L_0x00b8:
            r0.f1859b = r5
            goto L_0x00cc
        L_0x00bb:
            byte[] r5 = r0.f1860c
            r0.f1859b = r5
            r0.f1858a = r3
            r0.f1862e = r1
            int r5 = r5.length
            r0.f1863f = r5
            goto L_0x00cc
        L_0x00c7:
            android.os.Parcelable r5 = r0.f1861d
            if (r5 == 0) goto L_0x00cd
            goto L_0x00b8
        L_0x00cc:
            return r0
        L_0x00cd:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Invalid icon"
            r5.<init>(r0)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.read(m3.a):androidx.core.graphics.drawable.IconCompat");
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f1866i = iconCompat.f1865h.name();
        switch (iconCompat.f1858a) {
            case -1:
            case 1:
            case 5:
                iconCompat.f1861d = (Parcelable) iconCompat.f1859b;
                break;
            case 2:
                iconCompat.f1860c = ((String) iconCompat.f1859b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f1860c = (byte[]) iconCompat.f1859b;
                break;
            case 4:
            case 6:
                iconCompat.f1860c = iconCompat.f1859b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i10 = iconCompat.f1858a;
        if (-1 != i10) {
            aVar.j(i10, 1);
        }
        byte[] bArr = iconCompat.f1860c;
        if (bArr != null) {
            aVar.i(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f22394e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1861d;
        if (parcelable != null) {
            aVar.i(3);
            ((b) aVar).f22394e.writeParcelable(parcelable, 0);
        }
        int i11 = iconCompat.f1862e;
        if (i11 != 0) {
            aVar.j(i11, 4);
        }
        int i12 = iconCompat.f1863f;
        if (i12 != 0) {
            aVar.j(i12, 5);
        }
        ColorStateList colorStateList = iconCompat.f1864g;
        if (colorStateList != null) {
            aVar.i(6);
            ((b) aVar).f22394e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f1866i;
        if (str != null) {
            aVar.i(7);
            ((b) aVar).f22394e.writeString(str);
        }
        String str2 = iconCompat.f1867j;
        if (str2 != null) {
            aVar.i(8);
            ((b) aVar).f22394e.writeString(str2);
        }
    }
}
