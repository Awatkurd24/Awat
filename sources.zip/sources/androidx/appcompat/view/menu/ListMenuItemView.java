package androidx.appcompat.view.menu;

import a4.w;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import co.vpn.plusvpn.R;
import g.a;
import java.util.WeakHashMap;
import m.d0;
import m.q;
import r1.h1;
import r1.p0;

public class ListMenuItemView extends LinearLayout implements d0, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a  reason: collision with root package name */
    public q f984a;

    /* renamed from: b  reason: collision with root package name */
    public ImageView f985b;

    /* renamed from: c  reason: collision with root package name */
    public RadioButton f986c;

    /* renamed from: d  reason: collision with root package name */
    public TextView f987d;

    /* renamed from: e  reason: collision with root package name */
    public CheckBox f988e;

    /* renamed from: f  reason: collision with root package name */
    public TextView f989f;

    /* renamed from: g  reason: collision with root package name */
    public ImageView f990g;

    /* renamed from: h  reason: collision with root package name */
    public ImageView f991h;

    /* renamed from: i  reason: collision with root package name */
    public LinearLayout f992i;

    /* renamed from: j  reason: collision with root package name */
    public final Drawable f993j;

    /* renamed from: k  reason: collision with root package name */
    public final int f994k;

    /* renamed from: l  reason: collision with root package name */
    public final Context f995l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f996m;

    /* renamed from: n  reason: collision with root package name */
    public final Drawable f997n;

    /* renamed from: o  reason: collision with root package name */
    public final boolean f998o;

    /* renamed from: p  reason: collision with root package name */
    public LayoutInflater f999p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f1000q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listMenuViewStyle);
    }

    private LayoutInflater getInflater() {
        if (this.f999p == null) {
            this.f999p = LayoutInflater.from(getContext());
        }
        return this.f999p;
    }

    private void setSubMenuArrowVisible(boolean z4) {
        ImageView imageView = this.f990g;
        if (imageView != null) {
            imageView.setVisibility(z4 ? 0 : 8);
        }
    }

    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f991h;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f991h.getLayoutParams();
            rect.top = this.f991h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0057, code lost:
        if (r0 != 0) goto L_0x005c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x005e  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0115  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(m.q r11) {
        /*
            r10 = this;
            r10.f984a = r11
            boolean r0 = r11.isVisible()
            r1 = 8
            r2 = 0
            if (r0 == 0) goto L_0x000d
            r0 = 0
            goto L_0x000f
        L_0x000d:
            r0 = 8
        L_0x000f:
            r10.setVisibility(r0)
            java.lang.CharSequence r0 = r11.f22326e
            r10.setTitle(r0)
            boolean r0 = r11.isCheckable()
            r10.setCheckable(r0)
            m.o r0 = r11.f22335n
            boolean r0 = r0.o()
            r3 = 1
            if (r0 == 0) goto L_0x0038
            m.o r0 = r11.f22335n
            boolean r0 = r0.n()
            if (r0 == 0) goto L_0x0032
            char r0 = r11.f22331j
            goto L_0x0034
        L_0x0032:
            char r0 = r11.f22329h
        L_0x0034:
            if (r0 == 0) goto L_0x0038
            r0 = 1
            goto L_0x0039
        L_0x0038:
            r0 = 0
        L_0x0039:
            m.o r4 = r11.f22335n
            r4.n()
            if (r0 == 0) goto L_0x005a
            m.q r0 = r10.f984a
            m.o r4 = r0.f22335n
            boolean r4 = r4.o()
            if (r4 == 0) goto L_0x005a
            m.o r4 = r0.f22335n
            boolean r4 = r4.n()
            if (r4 == 0) goto L_0x0055
            char r0 = r0.f22331j
            goto L_0x0057
        L_0x0055:
            char r0 = r0.f22329h
        L_0x0057:
            if (r0 == 0) goto L_0x005a
            goto L_0x005c
        L_0x005a:
            r2 = 8
        L_0x005c:
            if (r2 != 0) goto L_0x010d
            android.widget.TextView r0 = r10.f989f
            m.q r4 = r10.f984a
            m.o r5 = r4.f22335n
            boolean r5 = r5.n()
            if (r5 == 0) goto L_0x006d
            char r5 = r4.f22331j
            goto L_0x006f
        L_0x006d:
            char r5 = r4.f22329h
        L_0x006f:
            if (r5 != 0) goto L_0x0075
            java.lang.String r1 = ""
            goto L_0x010a
        L_0x0075:
            m.o r6 = r4.f22335n
            android.content.Context r7 = r6.f22295a
            android.content.res.Resources r7 = r7.getResources()
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            android.content.Context r9 = r6.f22295a
            android.view.ViewConfiguration r9 = android.view.ViewConfiguration.get(r9)
            boolean r9 = r9.hasPermanentMenuKey()
            if (r9 == 0) goto L_0x0098
            r9 = 2131951633(0x7f130011, float:1.9539686E38)
            java.lang.String r9 = r7.getString(r9)
            r8.append(r9)
        L_0x0098:
            boolean r6 = r6.n()
            if (r6 == 0) goto L_0x00a1
            int r4 = r4.f22332k
            goto L_0x00a3
        L_0x00a1:
            int r4 = r4.f22330i
        L_0x00a3:
            r6 = 2131951629(0x7f13000d, float:1.9539678E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 65536(0x10000, float:9.18355E-41)
            m.q.c(r4, r9, r6, r8)
            r6 = 2131951625(0x7f130009, float:1.953967E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 4096(0x1000, float:5.74E-42)
            m.q.c(r4, r9, r6, r8)
            r6 = 2131951624(0x7f130008, float:1.9539668E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 2
            m.q.c(r4, r9, r6, r8)
            r6 = 2131951630(0x7f13000e, float:1.953968E38)
            java.lang.String r6 = r7.getString(r6)
            m.q.c(r4, r3, r6, r8)
            r3 = 2131951632(0x7f130010, float:1.9539684E38)
            java.lang.String r3 = r7.getString(r3)
            r6 = 4
            m.q.c(r4, r6, r3, r8)
            r3 = 2131951628(0x7f13000c, float:1.9539676E38)
            java.lang.String r3 = r7.getString(r3)
            m.q.c(r4, r1, r3, r8)
            if (r5 == r1) goto L_0x0102
            r1 = 10
            if (r5 == r1) goto L_0x00fe
            r1 = 32
            if (r5 == r1) goto L_0x00f3
            r8.append(r5)
            goto L_0x0106
        L_0x00f3:
            r1 = 2131951631(0x7f13000f, float:1.9539682E38)
        L_0x00f6:
            java.lang.String r1 = r7.getString(r1)
            r8.append(r1)
            goto L_0x0106
        L_0x00fe:
            r1 = 2131951627(0x7f13000b, float:1.9539674E38)
            goto L_0x00f6
        L_0x0102:
            r1 = 2131951626(0x7f13000a, float:1.9539672E38)
            goto L_0x00f6
        L_0x0106:
            java.lang.String r1 = r8.toString()
        L_0x010a:
            r0.setText(r1)
        L_0x010d:
            android.widget.TextView r0 = r10.f989f
            int r0 = r0.getVisibility()
            if (r0 == r2) goto L_0x011a
            android.widget.TextView r0 = r10.f989f
            r0.setVisibility(r2)
        L_0x011a:
            android.graphics.drawable.Drawable r0 = r11.getIcon()
            r10.setIcon(r0)
            boolean r0 = r11.isEnabled()
            r10.setEnabled(r0)
            boolean r0 = r11.hasSubMenu()
            r10.setSubMenuArrowVisible(r0)
            java.lang.CharSequence r11 = r11.f22338q
            r10.setContentDescription(r11)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.b(m.q):void");
    }

    public q getItemData() {
        return this.f984a;
    }

    public final void onFinishInflate() {
        super.onFinishInflate();
        WeakHashMap weakHashMap = h1.f25195a;
        p0.q(this, this.f993j);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f987d = textView;
        int i10 = this.f994k;
        if (i10 != -1) {
            textView.setTextAppearance(this.f995l, i10);
        }
        this.f989f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f990g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f997n);
        }
        this.f991h = (ImageView) findViewById(R.id.group_divider);
        this.f992i = (LinearLayout) findViewById(R.id.content);
    }

    public final void onMeasure(int i10, int i11) {
        if (this.f985b != null && this.f996m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f985b.getLayoutParams();
            int i12 = layoutParams.height;
            if (i12 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i12;
            }
        }
        super.onMeasure(i10, i11);
    }

    public void setCheckable(boolean z4) {
        View view;
        CompoundButton compoundButton;
        if (z4 || this.f986c != null || this.f988e != null) {
            if ((this.f984a.f22345x & 4) != 0) {
                if (this.f986c == null) {
                    RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
                    this.f986c = radioButton;
                    LinearLayout linearLayout = this.f992i;
                    if (linearLayout != null) {
                        linearLayout.addView(radioButton, -1);
                    } else {
                        addView(radioButton, -1);
                    }
                }
                compoundButton = this.f986c;
                view = this.f988e;
            } else {
                if (this.f988e == null) {
                    CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
                    this.f988e = checkBox;
                    LinearLayout linearLayout2 = this.f992i;
                    if (linearLayout2 != null) {
                        linearLayout2.addView(checkBox, -1);
                    } else {
                        addView(checkBox, -1);
                    }
                }
                compoundButton = this.f988e;
                view = this.f986c;
            }
            if (z4) {
                compoundButton.setChecked(this.f984a.isChecked());
                if (compoundButton.getVisibility() != 0) {
                    compoundButton.setVisibility(0);
                }
                if (view != null && view.getVisibility() != 8) {
                    view.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox2 = this.f988e;
            if (checkBox2 != null) {
                checkBox2.setVisibility(8);
            }
            RadioButton radioButton2 = this.f986c;
            if (radioButton2 != null) {
                radioButton2.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z4) {
        CompoundButton compoundButton;
        if ((this.f984a.f22345x & 4) != 0) {
            if (this.f986c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
                this.f986c = radioButton;
                LinearLayout linearLayout = this.f992i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f986c;
        } else {
            if (this.f988e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
                this.f988e = checkBox;
                LinearLayout linearLayout2 = this.f992i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f988e;
        }
        compoundButton.setChecked(z4);
    }

    public void setForceShowIcon(boolean z4) {
        this.f1000q = z4;
        this.f996m = z4;
    }

    public void setGroupDividerEnabled(boolean z4) {
        ImageView imageView = this.f991h;
        if (imageView != null) {
            imageView.setVisibility((this.f998o || !z4) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f984a.f22335n.getClass();
        boolean z4 = this.f1000q;
        if (z4 || this.f996m) {
            ImageView imageView = this.f985b;
            if (imageView != null || drawable != null || this.f996m) {
                if (imageView == null) {
                    ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, this, false);
                    this.f985b = imageView2;
                    LinearLayout linearLayout = this.f992i;
                    if (linearLayout != null) {
                        linearLayout.addView(imageView2, 0);
                    } else {
                        addView(imageView2, 0);
                    }
                }
                if (drawable != null || this.f996m) {
                    ImageView imageView3 = this.f985b;
                    if (!z4) {
                        drawable = null;
                    }
                    imageView3.setImageDrawable(drawable);
                    if (this.f985b.getVisibility() != 0) {
                        this.f985b.setVisibility(0);
                        return;
                    }
                    return;
                }
                this.f985b.setVisibility(8);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i10;
        TextView textView;
        if (charSequence != null) {
            this.f987d.setText(charSequence);
            if (this.f987d.getVisibility() != 0) {
                textView = this.f987d;
                i10 = 0;
            } else {
                return;
            }
        } else {
            i10 = 8;
            if (this.f987d.getVisibility() != 8) {
                textView = this.f987d;
            } else {
                return;
            }
        }
        textView.setVisibility(i10);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet);
        w K = w.K(getContext(), attributeSet, a.f18938t, i10);
        this.f993j = K.w(5);
        this.f994k = K.B(1, -1);
        this.f996m = K.r(7, false);
        this.f995l = context;
        this.f997n = K.w(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.f998o = obtainStyledAttributes.hasValue(0);
        K.N();
        obtainStyledAttributes.recycle();
    }
}
