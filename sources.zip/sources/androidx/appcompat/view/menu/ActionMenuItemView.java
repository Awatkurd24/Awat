package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.o;
import c0.g;
import g.a;
import m.b;
import m.c;
import m.d0;
import m.n;
import m.q;

public class ActionMenuItemView extends AppCompatTextView implements d0, View.OnClickListener, o {

    /* renamed from: h  reason: collision with root package name */
    public q f971h;

    /* renamed from: i  reason: collision with root package name */
    public CharSequence f972i;

    /* renamed from: j  reason: collision with root package name */
    public Drawable f973j;

    /* renamed from: k  reason: collision with root package name */
    public n f974k;

    /* renamed from: l  reason: collision with root package name */
    public b f975l;

    /* renamed from: m  reason: collision with root package name */
    public c f976m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f977n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f978o;

    /* renamed from: p  reason: collision with root package name */
    public final int f979p;

    /* renamed from: q  reason: collision with root package name */
    public int f980q;

    /* renamed from: r  reason: collision with root package name */
    public final int f981r;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    public final void b(q qVar) {
        int i10;
        this.f971h = qVar;
        setIcon(qVar.getIcon());
        setTitle(qVar.getTitleCondensed());
        setId(qVar.f22322a);
        if (qVar.isVisible()) {
            i10 = 0;
        } else {
            i10 = 8;
        }
        setVisibility(i10);
        setEnabled(qVar.isEnabled());
        if (qVar.hasSubMenu() && this.f975l == null) {
            this.f975l = new b(this);
        }
    }

    public final boolean c() {
        if (!(!TextUtils.isEmpty(getText())) || this.f971h.getIcon() != null) {
            return false;
        }
        return true;
    }

    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    public q getItemData() {
        return this.f971h;
    }

    public final void onClick(View view) {
        n nVar = this.f974k;
        if (nVar != null) {
            nVar.d(this.f971h);
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f977n = w();
        x();
    }

    public final void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        boolean z4 = !TextUtils.isEmpty(getText());
        if (z4 && (i13 = this.f980q) >= 0) {
            super.setPadding(i13, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i10, i11);
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int measuredWidth = getMeasuredWidth();
        int i14 = this.f979p;
        if (mode == Integer.MIN_VALUE) {
            i12 = Math.min(size, i14);
        } else {
            i12 = i14;
        }
        if (mode != 1073741824 && i14 > 0 && measuredWidth < i12) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), i11);
        }
        if (!z4 && this.f973j != null) {
            super.setPadding((getMeasuredWidth() - this.f973j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        b bVar;
        if (!this.f971h.hasSubMenu() || (bVar = this.f975l) == null || !bVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z4) {
    }

    public void setChecked(boolean z4) {
    }

    public void setExpandedFormat(boolean z4) {
        if (this.f978o != z4) {
            this.f978o = z4;
            q qVar = this.f971h;
            if (qVar != null) {
                m.o oVar = qVar.f22335n;
                oVar.f22305k = true;
                oVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f973j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i10 = this.f981r;
            if (intrinsicWidth > i10) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i10) / ((float) intrinsicWidth)));
                intrinsicWidth = i10;
            }
            if (intrinsicHeight > i10) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i10) / ((float) intrinsicHeight)));
            } else {
                i10 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i10);
        }
        setCompoundDrawables(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        x();
    }

    public void setItemInvoker(n nVar) {
        this.f974k = nVar;
    }

    public final void setPadding(int i10, int i11, int i12, int i13) {
        this.f980q = i10;
        super.setPadding(i10, i11, i12, i13);
    }

    public void setPopupCallback(c cVar) {
        this.f976m = cVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f972i = charSequence;
        x();
    }

    public final boolean w() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i10 = configuration.screenWidthDp;
        return i10 >= 480 || (i10 >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    public final void x() {
        CharSequence charSequence;
        boolean z4 = true;
        boolean z10 = !TextUtils.isEmpty(this.f972i);
        if (this.f973j != null && ((this.f971h.f22346y & 4) != 4 || (!this.f977n && !this.f978o))) {
            z4 = false;
        }
        boolean z11 = z10 & z4;
        CharSequence charSequence2 = null;
        if (z11) {
            charSequence = this.f972i;
        } else {
            charSequence = null;
        }
        setText(charSequence);
        CharSequence charSequence3 = this.f971h.f22338q;
        if (TextUtils.isEmpty(charSequence3)) {
            if (z11) {
                charSequence3 = null;
            } else {
                charSequence3 = this.f971h.f22326e;
            }
        }
        setContentDescription(charSequence3);
        CharSequence charSequence4 = this.f971h.f22339r;
        if (TextUtils.isEmpty(charSequence4)) {
            if (!z11) {
                charSequence2 = this.f971h.f22326e;
            }
            g.j(this, charSequence2);
            return;
        }
        g.j(this, charSequence4);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Resources resources = context.getResources();
        this.f977n = w();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f18921c, i10, 0);
        this.f979p = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f981r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f980q = -1;
        setSaveEnabled(false);
    }
}
