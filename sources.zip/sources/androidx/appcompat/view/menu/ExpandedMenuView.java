package androidx.appcompat.view.menu;

import a4.w;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import m.c0;
import m.e0;
import m.n;
import m.o;
import m.q;

public final class ExpandedMenuView extends ListView implements n, e0, AdapterView.OnItemClickListener {

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f982b = {16842964, 16843049};

    /* renamed from: a  reason: collision with root package name */
    public o f983a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public final void c(o oVar) {
        this.f983a = oVar;
    }

    public final boolean d(q qVar) {
        return this.f983a.q(qVar, (c0) null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public final void onItemClick(AdapterView adapterView, View view, int i10, long j3) {
        d((q) getAdapter().getItem(i10));
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        w wVar = new w(context, context.obtainStyledAttributes(attributeSet, f982b, i10, 0));
        if (wVar.G(0)) {
            setBackgroundDrawable(wVar.w(0));
        }
        if (wVar.G(1)) {
            setDivider(wVar.w(1));
        }
        wVar.N();
    }
}
