package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import g.a;

public class AlertController$RecycleListView extends ListView {

    /* renamed from: a  reason: collision with root package name */
    public final int f969a;

    /* renamed from: b  reason: collision with root package name */
    public final int f970b;

    public AlertController$RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f18940v);
        this.f970b = obtainStyledAttributes.getDimensionPixelOffset(0, -1);
        this.f969a = obtainStyledAttributes.getDimensionPixelOffset(1, -1);
    }
}
