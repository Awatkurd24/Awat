package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import co.vpn.plusvpn.R;
import h.z;
import java.util.ArrayList;
import m.b0;
import m.c0;
import m.d0;
import m.e0;
import m.i0;
import m.o;
import m.q;
import m.x;
import r1.d;

public final class n implements c0 {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1418a;

    /* renamed from: b  reason: collision with root package name */
    public Context f1419b;

    /* renamed from: c  reason: collision with root package name */
    public o f1420c;

    /* renamed from: d  reason: collision with root package name */
    public final LayoutInflater f1421d;

    /* renamed from: e  reason: collision with root package name */
    public b0 f1422e;

    /* renamed from: f  reason: collision with root package name */
    public final int f1423f = R.layout.abc_action_menu_layout;

    /* renamed from: g  reason: collision with root package name */
    public final int f1424g = R.layout.abc_action_menu_item_layout;

    /* renamed from: h  reason: collision with root package name */
    public e0 f1425h;

    /* renamed from: i  reason: collision with root package name */
    public int f1426i;

    /* renamed from: j  reason: collision with root package name */
    public l f1427j;

    /* renamed from: k  reason: collision with root package name */
    public Drawable f1428k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f1429l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1430m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f1431n;

    /* renamed from: o  reason: collision with root package name */
    public int f1432o;

    /* renamed from: p  reason: collision with root package name */
    public int f1433p;

    /* renamed from: q  reason: collision with root package name */
    public int f1434q;

    /* renamed from: r  reason: collision with root package name */
    public boolean f1435r;

    /* renamed from: s  reason: collision with root package name */
    public final SparseBooleanArray f1436s = new SparseBooleanArray();

    /* renamed from: t  reason: collision with root package name */
    public h f1437t;

    /* renamed from: u  reason: collision with root package name */
    public h f1438u;

    /* renamed from: v  reason: collision with root package name */
    public j f1439v;

    /* renamed from: w  reason: collision with root package name */
    public i f1440w;

    /* renamed from: x  reason: collision with root package name */
    public final z f1441x = new z(2, (Object) this);

    /* renamed from: y  reason: collision with root package name */
    public int f1442y;

    public n(Context context) {
        this.f1418a = context;
        this.f1421d = LayoutInflater.from(context);
    }

    public final View a(q qVar, View view, ViewGroup viewGroup) {
        d0 d0Var;
        View actionView = qVar.getActionView();
        int i10 = 0;
        if (actionView == null || qVar.e()) {
            if (view instanceof d0) {
                d0Var = (d0) view;
            } else {
                d0Var = (d0) this.f1421d.inflate(this.f1424g, viewGroup, false);
            }
            d0Var.b(qVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) d0Var;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f1425h);
            if (this.f1440w == null) {
                this.f1440w = new i(this);
            }
            actionMenuItemView.setPopupCallback(this.f1440w);
            actionView = (View) d0Var;
        }
        if (qVar.C) {
            i10 = 8;
        }
        actionView.setVisibility(i10);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!((ActionMenuView) viewGroup).checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(ActionMenuView.m(layoutParams));
        }
        return actionView;
    }

    public final void b(o oVar, boolean z4) {
        c();
        h hVar = this.f1438u;
        if (hVar != null && hVar.b()) {
            hVar.f22213j.dismiss();
        }
        b0 b0Var = this.f1422e;
        if (b0Var != null) {
            b0Var.b(oVar, z4);
        }
    }

    public final boolean c() {
        e0 e0Var;
        j jVar = this.f1439v;
        if (jVar == null || (e0Var = this.f1425h) == null) {
            h hVar = this.f1437t;
            if (hVar == null) {
                return false;
            }
            if (hVar.b()) {
                hVar.f22213j.dismiss();
            }
            return true;
        }
        ((View) e0Var).removeCallbacks(jVar);
        this.f1439v = null;
        return true;
    }

    public final void d(Parcelable parcelable) {
        int i10;
        MenuItem findItem;
        if ((parcelable instanceof ActionMenuPresenter$SavedState) && (i10 = ((ActionMenuPresenter$SavedState) parcelable).f1056a) > 0 && (findItem = this.f1420c.findItem(i10)) != null) {
            k((i0) findItem.getSubMenu());
        }
    }

    public final boolean e() {
        h hVar = this.f1437t;
        return hVar != null && hVar.b();
    }

    public final void f(boolean z4) {
        e0 e0Var;
        int size;
        int i10;
        q qVar;
        ViewGroup viewGroup = (ViewGroup) this.f1425h;
        ArrayList arrayList = null;
        if (viewGroup != null) {
            o oVar = this.f1420c;
            if (oVar != null) {
                oVar.i();
                ArrayList l10 = this.f1420c.l();
                int size2 = l10.size();
                i10 = 0;
                for (int i11 = 0; i11 < size2; i11++) {
                    q qVar2 = (q) l10.get(i11);
                    if (qVar2.f()) {
                        View childAt = viewGroup.getChildAt(i10);
                        if (childAt instanceof d0) {
                            qVar = ((d0) childAt).getItemData();
                        } else {
                            qVar = null;
                        }
                        View a10 = a(qVar2, childAt, viewGroup);
                        if (qVar2 != qVar) {
                            a10.setPressed(false);
                            a10.jumpDrawablesToCurrentState();
                        }
                        if (a10 != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) a10.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(a10);
                            }
                            ((ViewGroup) this.f1425h).addView(a10, i10);
                        }
                        i10++;
                    }
                }
            } else {
                i10 = 0;
            }
            while (i10 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i10) == this.f1427j) {
                    i10++;
                } else {
                    viewGroup.removeViewAt(i10);
                }
            }
        }
        ((View) this.f1425h).requestLayout();
        o oVar2 = this.f1420c;
        if (oVar2 != null) {
            oVar2.i();
            ArrayList arrayList2 = oVar2.f22303i;
            int size3 = arrayList2.size();
            for (int i12 = 0; i12 < size3; i12++) {
                d dVar = ((q) arrayList2.get(i12)).A;
                if (dVar != null) {
                    dVar.f25166a = this;
                }
            }
        }
        o oVar3 = this.f1420c;
        if (oVar3 != null) {
            oVar3.i();
            arrayList = oVar3.f22304j;
        }
        if (!this.f1430m || arrayList == null || ((size = arrayList.size()) != 1 ? size <= 0 : !(!((q) arrayList.get(0)).C))) {
            l lVar = this.f1427j;
            if (lVar != null && lVar.getParent() == (e0Var = this.f1425h)) {
                ((ViewGroup) e0Var).removeView(this.f1427j);
            }
        } else {
            if (this.f1427j == null) {
                this.f1427j = new l(this, this.f1418a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f1427j.getParent();
            if (viewGroup3 != this.f1425h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f1427j);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f1425h;
                l lVar2 = this.f1427j;
                actionMenuView.getClass();
                q l11 = ActionMenuView.l();
                l11.f1466a = true;
                actionMenuView.addView(lVar2, l11);
            }
        }
        ((ActionMenuView) this.f1425h).setOverflowReserved(this.f1430m);
    }

    public final /* bridge */ /* synthetic */ boolean g(q qVar) {
        return false;
    }

    public final int getId() {
        return this.f1426i;
    }

    public final void h(Context context, o oVar) {
        this.f1419b = context;
        LayoutInflater.from(context);
        this.f1420c = oVar;
        Resources resources = context.getResources();
        if (!this.f1431n) {
            this.f1430m = true;
        }
        int i10 = 2;
        this.f1432o = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i11 = configuration.screenWidthDp;
        int i12 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i11 > 600 || ((i11 > 960 && i12 > 720) || (i11 > 720 && i12 > 960))) {
            i10 = 5;
        } else if (i11 >= 500 || ((i11 > 640 && i12 > 480) || (i11 > 480 && i12 > 640))) {
            i10 = 4;
        } else if (i11 >= 360) {
            i10 = 3;
        }
        this.f1434q = i10;
        int i13 = this.f1432o;
        if (this.f1430m) {
            if (this.f1427j == null) {
                l lVar = new l(this, this.f1418a);
                this.f1427j = lVar;
                if (this.f1429l) {
                    lVar.setImageDrawable(this.f1428k);
                    this.f1428k = null;
                    this.f1429l = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1427j.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i13 -= this.f1427j.getMeasuredWidth();
        } else {
            this.f1427j = null;
        }
        this.f1433p = i13;
        float f10 = resources.getDisplayMetrics().density;
    }

    public final boolean i() {
        int i10;
        ArrayList arrayList;
        int i11;
        boolean z4;
        boolean z10;
        boolean z11;
        boolean z12;
        o oVar = this.f1420c;
        if (oVar != null) {
            arrayList = oVar.l();
            i10 = arrayList.size();
        } else {
            arrayList = null;
            i10 = 0;
        }
        int i12 = this.f1434q;
        int i13 = this.f1433p;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.f1425h;
        int i14 = 0;
        boolean z13 = false;
        int i15 = 0;
        int i16 = 0;
        while (true) {
            i11 = 2;
            z4 = true;
            if (i14 >= i10) {
                break;
            }
            q qVar = (q) arrayList.get(i14);
            int i17 = qVar.f22346y;
            if ((i17 & 2) == 2) {
                i15++;
            } else if ((i17 & 1) == 1) {
                i16++;
            } else {
                z13 = true;
            }
            if (this.f1435r && qVar.C) {
                i12 = 0;
            }
            i14++;
        }
        if (this.f1430m && (z13 || i16 + i15 > i12)) {
            i12--;
        }
        int i18 = i12 - i15;
        SparseBooleanArray sparseBooleanArray = this.f1436s;
        sparseBooleanArray.clear();
        int i19 = 0;
        int i20 = 0;
        while (i19 < i10) {
            q qVar2 = (q) arrayList.get(i19);
            int i21 = qVar2.f22346y;
            if ((i21 & 2) == i11) {
                z10 = true;
            } else {
                z10 = false;
            }
            int i22 = qVar2.f22323b;
            if (z10) {
                View a10 = a(qVar2, (View) null, viewGroup);
                a10.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = a10.getMeasuredWidth();
                i13 -= measuredWidth;
                if (i20 == 0) {
                    i20 = measuredWidth;
                }
                if (i22 != 0) {
                    sparseBooleanArray.put(i22, z4);
                }
                qVar2.h(z4);
            } else if ((i21 & true) == z4) {
                boolean z14 = sparseBooleanArray.get(i22);
                if ((i18 > 0 || z14) && i13 > 0) {
                    z11 = true;
                } else {
                    z11 = false;
                }
                if (z11) {
                    View a11 = a(qVar2, (View) null, viewGroup);
                    a11.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = a11.getMeasuredWidth();
                    i13 -= measuredWidth2;
                    if (i20 == 0) {
                        i20 = measuredWidth2;
                    }
                    if (i13 + i20 > 0) {
                        z12 = true;
                    } else {
                        z12 = false;
                    }
                    z11 &= z12;
                }
                if (z11 && i22 != 0) {
                    sparseBooleanArray.put(i22, true);
                } else if (z14) {
                    sparseBooleanArray.put(i22, false);
                    for (int i23 = 0; i23 < i19; i23++) {
                        q qVar3 = (q) arrayList.get(i23);
                        if (qVar3.f22323b == i22) {
                            if (qVar3.f()) {
                                i18++;
                            }
                            qVar3.h(false);
                        }
                    }
                }
                if (z11) {
                    i18--;
                }
                qVar2.h(z11);
            } else {
                qVar2.h(false);
                i19++;
                i11 = 2;
                z4 = true;
            }
            i19++;
            i11 = 2;
            z4 = true;
        }
        return true;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.os.Parcelable, java.lang.Object, androidx.appcompat.widget.ActionMenuPresenter$SavedState] */
    public final Parcelable j() {
        ? obj = new Object();
        obj.f1056a = this.f1442y;
        return obj;
    }

    public final boolean k(i0 i0Var) {
        boolean z4;
        if (!i0Var.hasVisibleItems()) {
            return false;
        }
        i0 i0Var2 = i0Var;
        while (true) {
            o oVar = i0Var2.f22279z;
            if (oVar == this.f1420c) {
                break;
            }
            i0Var2 = oVar;
        }
        ViewGroup viewGroup = (ViewGroup) this.f1425h;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i10 = 0;
            while (true) {
                if (i10 >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i10);
                if ((childAt instanceof d0) && ((d0) childAt).getItemData() == i0Var2.A) {
                    view = childAt;
                    break;
                }
                i10++;
            }
        }
        if (view == null) {
            return false;
        }
        this.f1442y = i0Var.A.f22322a;
        int size = i0Var.f22300f.size();
        int i11 = 0;
        while (true) {
            if (i11 >= size) {
                z4 = false;
                break;
            }
            MenuItem item = i0Var.getItem(i11);
            if (item.isVisible() && item.getIcon() != null) {
                z4 = true;
                break;
            }
            i11++;
        }
        h hVar = new h(this, this.f1419b, i0Var, view);
        this.f1438u = hVar;
        hVar.f22211h = z4;
        x xVar = hVar.f22213j;
        if (xVar != null) {
            xVar.q(z4);
        }
        h hVar2 = this.f1438u;
        if (!hVar2.b()) {
            if (hVar2.f22209f != null) {
                hVar2.d(0, 0, false, false);
            } else {
                throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
            }
        }
        b0 b0Var = this.f1422e;
        if (b0Var != null) {
            b0Var.I(i0Var);
        }
        return true;
    }

    public final void l(b0 b0Var) {
        this.f1422e = b0Var;
    }

    public final /* bridge */ /* synthetic */ boolean m(q qVar) {
        return false;
    }

    public final boolean n() {
        o oVar;
        if (this.f1430m && !e() && (oVar = this.f1420c) != null && this.f1425h != null && this.f1439v == null) {
            oVar.i();
            if (!oVar.f22304j.isEmpty()) {
                j jVar = new j((Object) this, 0, (Object) new h(this, this.f1419b, this.f1420c, this.f1427j));
                this.f1439v = jVar;
                ((View) this.f1425h).post(jVar);
                return true;
            }
        }
        return false;
    }
}
