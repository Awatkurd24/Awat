package androidx.appcompat.widget;

import android.database.DataSetObserver;
import w1.b;

public final class d2 extends DataSetObserver {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1324a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f1325b;

    public /* synthetic */ d2(int i10, Object obj) {
        this.f1324a = i10;
        this.f1325b = obj;
    }

    public final void onChanged() {
        int i10 = this.f1324a;
        Object obj = this.f1325b;
        switch (i10) {
            case 0:
                ListPopupWindow listPopupWindow = (ListPopupWindow) obj;
                if (listPopupWindow.f1190z.isShowing()) {
                    listPopupWindow.c();
                    return;
                }
                return;
            default:
                b bVar = (b) obj;
                bVar.f28649a = true;
                bVar.notifyDataSetChanged();
                return;
        }
    }

    public final void onInvalidated() {
        int i10 = this.f1324a;
        Object obj = this.f1325b;
        switch (i10) {
            case 0:
                ((ListPopupWindow) obj).dismiss();
                return;
            default:
                b bVar = (b) obj;
                bVar.f28649a = false;
                bVar.notifyDataSetInvalidated();
                return;
        }
    }
}
