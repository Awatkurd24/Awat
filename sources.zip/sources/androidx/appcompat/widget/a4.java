package androidx.appcompat.widget;

public final /* synthetic */ class a4 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1289a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ b4 f1290b;

    public /* synthetic */ a4(b4 b4Var, int i10) {
        this.f1289a = i10;
        this.f1290b = b4Var;
    }

    public final void run() {
        int i10 = this.f1289a;
        b4 b4Var = this.f1290b;
        switch (i10) {
            case 0:
                b4Var.c(false);
                return;
            default:
                b4Var.a();
                return;
        }
    }
}
