package androidx.appcompat.widget;

import android.text.StaticLayout;
import android.widget.TextView;

public class h1 {
    public void a(StaticLayout.Builder builder, TextView textView) {
    }

    public boolean b(TextView textView) {
        return ((Boolean) i1.e(textView, Boolean.FALSE, "getHorizontallyScrolling")).booleanValue();
    }
}
