package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import co.vpn.plusvpn.R;
import h.f1;
import j1.c;
import java.util.WeakHashMap;
import m.o;
import r1.a0;
import r1.h1;
import r1.i2;
import r1.j2;
import r1.k2;
import r1.l2;
import r1.p0;
import r1.t0;
import r1.t2;
import r1.y;
import r1.z;
import yb.b;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements k1, y, z {
    public static final int[] B = {R.attr.actionBarSize, 16842841};
    public final a0 A;

    /* renamed from: a  reason: collision with root package name */
    public int f1030a;

    /* renamed from: b  reason: collision with root package name */
    public int f1031b = 0;

    /* renamed from: c  reason: collision with root package name */
    public ContentFrameLayout f1032c;

    /* renamed from: d  reason: collision with root package name */
    public ActionBarContainer f1033d;

    /* renamed from: e  reason: collision with root package name */
    public l1 f1034e;

    /* renamed from: f  reason: collision with root package name */
    public Drawable f1035f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1036g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1037h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1038i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1039j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1040k;

    /* renamed from: l  reason: collision with root package name */
    public int f1041l;

    /* renamed from: m  reason: collision with root package name */
    public int f1042m;

    /* renamed from: n  reason: collision with root package name */
    public final Rect f1043n = new Rect();

    /* renamed from: o  reason: collision with root package name */
    public final Rect f1044o = new Rect();

    /* renamed from: p  reason: collision with root package name */
    public final Rect f1045p = new Rect();

    /* renamed from: q  reason: collision with root package name */
    public t2 f1046q;

    /* renamed from: r  reason: collision with root package name */
    public t2 f1047r;

    /* renamed from: s  reason: collision with root package name */
    public t2 f1048s;

    /* renamed from: t  reason: collision with root package name */
    public t2 f1049t;

    /* renamed from: u  reason: collision with root package name */
    public f f1050u;

    /* renamed from: v  reason: collision with root package name */
    public OverScroller f1051v;

    /* renamed from: w  reason: collision with root package name */
    public ViewPropertyAnimator f1052w;

    /* renamed from: x  reason: collision with root package name */
    public final d f1053x;

    /* renamed from: y  reason: collision with root package name */
    public final e f1054y;

    /* renamed from: z  reason: collision with root package name */
    public final e f1055z;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        t2 t2Var = t2.f25276b;
        this.f1046q = t2Var;
        this.f1047r = t2Var;
        this.f1048s = t2Var;
        this.f1049t = t2Var;
        this.f1053x = new d(0, this);
        this.f1054y = new e(this, 0);
        this.f1055z = new e(this, 1);
        i(context);
        this.A = new a0(0);
    }

    public static boolean g(FrameLayout frameLayout, Rect rect, boolean z4) {
        boolean z10;
        int i10;
        g gVar = (g) frameLayout.getLayoutParams();
        int i11 = gVar.leftMargin;
        int i12 = rect.left;
        if (i11 != i12) {
            gVar.leftMargin = i12;
            z10 = true;
        } else {
            z10 = false;
        }
        int i13 = gVar.topMargin;
        int i14 = rect.top;
        if (i13 != i14) {
            gVar.topMargin = i14;
            z10 = true;
        }
        int i15 = gVar.rightMargin;
        int i16 = rect.right;
        if (i15 != i16) {
            gVar.rightMargin = i16;
            z10 = true;
        }
        if (!z4 || gVar.bottomMargin == (i10 = rect.bottom)) {
            return z10;
        }
        gVar.bottomMargin = i10;
        return true;
    }

    public final void a(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            onNestedScrollAccepted(view, view2, i10);
        }
    }

    public final void b(View view, int i10) {
        if (i10 == 0) {
            onStopNestedScroll(view);
        }
    }

    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        if (i12 == 0) {
            onNestedPreScroll(view, i10, i11, iArr);
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof g;
    }

    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        e(view, i10, i11, i12, i13, i14);
    }

    public final void draw(Canvas canvas) {
        int i10;
        super.draw(canvas);
        if (this.f1035f != null && !this.f1036g) {
            if (this.f1033d.getVisibility() == 0) {
                i10 = (int) (this.f1033d.getTranslationY() + ((float) this.f1033d.getBottom()) + 0.5f);
            } else {
                i10 = 0;
            }
            this.f1035f.setBounds(0, i10, getWidth(), this.f1035f.getIntrinsicHeight() + i10);
            this.f1035f.draw(canvas);
        }
    }

    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
        if (i14 == 0) {
            onNestedScroll(view, i10, i11, i12, i13);
        }
    }

    public final boolean f(View view, View view2, int i10, int i11) {
        return i11 == 0 && onStartNestedScroll(view, view2, i10);
    }

    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -1);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1033d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        a0 a0Var = this.A;
        return a0Var.f25157c | a0Var.f25156b;
    }

    public CharSequence getTitle() {
        k();
        return ((y3) this.f1034e).f1570a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f1054y);
        removeCallbacks(this.f1055z);
        ViewPropertyAnimator viewPropertyAnimator = this.f1052w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(B);
        boolean z4 = false;
        this.f1030a = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f1035f = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z4 = true;
        }
        this.f1036g = z4;
        this.f1051v = new OverScroller(context);
    }

    public final void j(int i10) {
        k();
        if (i10 == 2) {
            ((y3) this.f1034e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i10 == 5) {
            ((y3) this.f1034e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i10 == 109) {
            setOverlayMode(true);
        }
    }

    public final void k() {
        l1 l1Var;
        if (this.f1032c == null) {
            this.f1032c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f1033d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof l1) {
                l1Var = (l1) findViewById;
            } else if (findViewById instanceof Toolbar) {
                l1Var = ((Toolbar) findViewById).getWrapper();
            } else {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(findViewById.getClass().getSimpleName()));
            }
            this.f1034e = l1Var;
        }
    }

    public final void l(o oVar, b bVar) {
        k();
        y3 y3Var = (y3) this.f1034e;
        n nVar = y3Var.f1582m;
        Toolbar toolbar = y3Var.f1570a;
        if (nVar == null) {
            n nVar2 = new n(toolbar.getContext());
            y3Var.f1582m = nVar2;
            nVar2.f1426i = R.id.action_menu_presenter;
        }
        n nVar3 = y3Var.f1582m;
        nVar3.f1422e = bVar;
        if (oVar != null || toolbar.f1247a != null) {
            toolbar.f();
            o oVar2 = toolbar.f1247a.f1057p;
            if (oVar2 != oVar) {
                if (oVar2 != null) {
                    oVar2.r(toolbar.L);
                    oVar2.r(toolbar.M);
                }
                if (toolbar.M == null) {
                    toolbar.M = new u3(toolbar);
                }
                nVar3.f1435r = true;
                if (oVar != null) {
                    oVar.b(nVar3, toolbar.f1256j);
                    oVar.b(toolbar.M, toolbar.f1256j);
                } else {
                    nVar3.h(toolbar.f1256j, (o) null);
                    toolbar.M.h(toolbar.f1256j, (o) null);
                    nVar3.f(true);
                    toolbar.M.f(true);
                }
                toolbar.f1247a.setPopupTheme(toolbar.f1257k);
                toolbar.f1247a.setPresenter(nVar3);
                toolbar.L = nVar3;
                toolbar.x();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0053, code lost:
        if (r0 != false) goto L_0x0055;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.WindowInsets onApplyWindowInsets(android.view.WindowInsets r7) {
        /*
            r6 = this;
            r6.k()
            r1.t2 r7 = r1.t2.g(r6, r7)
            android.graphics.Rect r0 = new android.graphics.Rect
            int r1 = r7.b()
            int r2 = r7.d()
            int r3 = r7.c()
            int r4 = r7.a()
            r0.<init>(r1, r2, r3, r4)
            androidx.appcompat.widget.ActionBarContainer r1 = r6.f1033d
            r2 = 0
            boolean r0 = g(r1, r0, r2)
            java.util.WeakHashMap r1 = r1.h1.f25195a
            android.graphics.Rect r1 = r6.f1043n
            r1.v0.b(r6, r7, r1)
            int r2 = r1.left
            int r3 = r1.top
            int r4 = r1.right
            int r5 = r1.bottom
            r1.r2 r7 = r7.f25277a
            r1.t2 r2 = r7.l(r2, r3, r4, r5)
            r6.f1046q = r2
            r1.t2 r3 = r6.f1047r
            boolean r2 = r3.equals(r2)
            if (r2 != 0) goto L_0x0047
            r1.t2 r0 = r6.f1046q
            r6.f1047r = r0
            r0 = 1
        L_0x0047:
            android.graphics.Rect r2 = r6.f1044o
            boolean r3 = r2.equals(r1)
            if (r3 != 0) goto L_0x0053
            r2.set(r1)
            goto L_0x0055
        L_0x0053:
            if (r0 == 0) goto L_0x0058
        L_0x0055:
            r6.requestLayout()
        L_0x0058:
            r1.t2 r7 = r7.a()
            r1.r2 r7 = r7.f25277a
            r1.t2 r7 = r7.c()
            r1.r2 r7 = r7.f25277a
            r1.t2 r7 = r7.b()
            android.view.WindowInsets r7 = r7.f()
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onApplyWindowInsets(android.view.WindowInsets):android.view.WindowInsets");
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = h1.f25195a;
        t0.c(this);
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i15 = gVar.leftMargin + paddingLeft;
                int i16 = gVar.topMargin + paddingTop;
                childAt.layout(i15, i16, measuredWidth + i15, measuredHeight + i16);
            }
        }
    }

    public final void onMeasure(int i10, int i11) {
        boolean z4;
        int i12;
        l2 l2Var;
        t2 b5;
        k();
        measureChildWithMargins(this.f1033d, i10, 0, i11, 0);
        g gVar = (g) this.f1033d.getLayoutParams();
        int max = Math.max(0, this.f1033d.getMeasuredWidth() + gVar.leftMargin + gVar.rightMargin);
        int max2 = Math.max(0, this.f1033d.getMeasuredHeight() + gVar.topMargin + gVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f1033d.getMeasuredState());
        WeakHashMap weakHashMap = h1.f25195a;
        if ((p0.g(this) & 256) != 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z4) {
            i12 = this.f1030a;
            if (this.f1038i && this.f1033d.getTabContainer() != null) {
                i12 += this.f1030a;
            }
        } else {
            i12 = this.f1033d.getVisibility() != 8 ? this.f1033d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f1043n;
        Rect rect2 = this.f1045p;
        rect2.set(rect);
        t2 t2Var = this.f1046q;
        this.f1048s = t2Var;
        if (this.f1037h || z4) {
            c b10 = c.b(t2Var.b(), this.f1048s.d() + i12, this.f1048s.c(), this.f1048s.a());
            t2 t2Var2 = this.f1048s;
            int i13 = Build.VERSION.SDK_INT;
            if (i13 >= 30) {
                l2Var = new k2(t2Var2);
            } else if (i13 >= 29) {
                l2Var = new j2(t2Var2);
            } else {
                l2Var = new i2(t2Var2);
            }
            l2Var.g(b10);
            b5 = l2Var.b();
        } else {
            rect2.top += i12;
            rect2.bottom = rect2.bottom;
            b5 = t2Var.f25277a.l(0, i12, 0, 0);
        }
        this.f1048s = b5;
        g(this.f1032c, rect2, true);
        if (!this.f1049t.equals(this.f1048s)) {
            t2 t2Var3 = this.f1048s;
            this.f1049t = t2Var3;
            h1.b(this.f1032c, t2Var3);
        }
        measureChildWithMargins(this.f1032c, i10, 0, i11, 0);
        g gVar2 = (g) this.f1032c.getLayoutParams();
        int max3 = Math.max(max, this.f1032c.getMeasuredWidth() + gVar2.leftMargin + gVar2.rightMargin);
        int max4 = Math.max(max2, this.f1032c.getMeasuredHeight() + gVar2.topMargin + gVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f1032c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i10, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i11, combineMeasuredStates2 << 16));
    }

    public final boolean onNestedFling(View view, float f10, float f11, boolean z4) {
        if (!this.f1039j || !z4) {
            return false;
        }
        this.f1051v.fling(0, 0, 0, (int) f11, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f1051v.getFinalY() > this.f1033d.getHeight()) {
            h();
            this.f1055z.run();
        } else {
            h();
            this.f1054y.run();
        }
        this.f1040k = true;
        return true;
    }

    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
    }

    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        int i14 = this.f1041l + i11;
        this.f1041l = i14;
        setActionBarHideOffset(i14);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r1 = (h.f1) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onNestedScrollAccepted(android.view.View r1, android.view.View r2, int r3) {
        /*
            r0 = this;
            r1.a0 r1 = r0.A
            r1.f25156b = r3
            int r1 = r0.getActionBarHideOffset()
            r0.f1041l = r1
            r0.h()
            androidx.appcompat.widget.f r1 = r0.f1050u
            if (r1 == 0) goto L_0x001d
            h.f1 r1 = (h.f1) r1
            l.l r2 = r1.f19307s
            if (r2 == 0) goto L_0x001d
            r2.a()
            r2 = 0
            r1.f19307s = r2
        L_0x001d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        if ((i10 & 2) == 0 || this.f1033d.getVisibility() != 0) {
            return false;
        }
        return this.f1039j;
    }

    public final void onStopNestedScroll(View view) {
        if (this.f1039j && !this.f1040k) {
            if (this.f1041l <= this.f1033d.getHeight()) {
                h();
                postDelayed(this.f1054y, 600);
                return;
            }
            h();
            postDelayed(this.f1055z, 600);
        }
    }

    public final void onWindowSystemUiVisibilityChanged(int i10) {
        boolean z4;
        boolean z10;
        super.onWindowSystemUiVisibilityChanged(i10);
        k();
        int i11 = this.f1042m ^ i10;
        this.f1042m = i10;
        if ((i10 & 4) == 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        if ((i10 & 256) != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        f fVar = this.f1050u;
        if (fVar != null) {
            ((f1) fVar).f19303o = !z10;
            if (z4 || !z10) {
                f1 f1Var = (f1) fVar;
                if (f1Var.f19304p) {
                    f1Var.f19304p = false;
                    f1Var.v(true);
                }
            } else {
                f1 f1Var2 = (f1) fVar;
                if (!f1Var2.f19304p) {
                    f1Var2.f19304p = true;
                    f1Var2.v(true);
                }
            }
        }
        if ((i11 & 256) != 0 && this.f1050u != null) {
            WeakHashMap weakHashMap = h1.f25195a;
            t0.c(this);
        }
    }

    public final void onWindowVisibilityChanged(int i10) {
        super.onWindowVisibilityChanged(i10);
        this.f1031b = i10;
        f fVar = this.f1050u;
        if (fVar != null) {
            ((f1) fVar).f19302n = i10;
        }
    }

    public void setActionBarHideOffset(int i10) {
        h();
        this.f1033d.setTranslationY((float) (-Math.max(0, Math.min(i10, this.f1033d.getHeight()))));
    }

    public void setActionBarVisibilityCallback(f fVar) {
        this.f1050u = fVar;
        if (getWindowToken() != null) {
            ((f1) this.f1050u).f19302n = this.f1031b;
            int i10 = this.f1042m;
            if (i10 != 0) {
                onWindowSystemUiVisibilityChanged(i10);
                WeakHashMap weakHashMap = h1.f25195a;
                t0.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z4) {
        this.f1038i = z4;
    }

    public void setHideOnContentScrollEnabled(boolean z4) {
        if (z4 != this.f1039j) {
            this.f1039j = z4;
            if (!z4) {
                h();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i10) {
        k();
        y3 y3Var = (y3) this.f1034e;
        y3Var.f1573d = i10 != 0 ? u7.y.e(y3Var.f1570a.getContext(), i10) : null;
        y3Var.d();
    }

    public void setLogo(int i10) {
        Drawable drawable;
        k();
        y3 y3Var = (y3) this.f1034e;
        if (i10 != 0) {
            drawable = u7.y.e(y3Var.f1570a.getContext(), i10);
        } else {
            drawable = null;
        }
        y3Var.f1574e = drawable;
        y3Var.d();
    }

    public void setOverlayMode(boolean z4) {
        this.f1037h = z4;
        this.f1036g = z4 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z4) {
    }

    public void setUiOptions(int i10) {
    }

    public void setWindowCallback(Window.Callback callback) {
        k();
        ((y3) this.f1034e).f1580k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        k();
        y3 y3Var = (y3) this.f1034e;
        if (!y3Var.f1576g) {
            y3Var.f1577h = charSequence;
            if ((y3Var.f1571b & 8) != 0) {
                Toolbar toolbar = y3Var.f1570a;
                toolbar.setTitle(charSequence);
                if (y3Var.f1576g) {
                    h1.s(toolbar.getRootView(), charSequence);
                }
            }
        }
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ViewGroup.MarginLayoutParams(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        y3 y3Var = (y3) this.f1034e;
        y3Var.f1573d = drawable;
        y3Var.d();
    }
}
