package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.MenuItem;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import m.o;
import m.q;

public final class l2 extends ListPopupWindow implements g2 {
    public static final Method E;
    public g2 D;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                E = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public final void h(o oVar, q qVar) {
        g2 g2Var = this.D;
        if (g2Var != null) {
            g2Var.h(oVar, qVar);
        }
    }

    public final void n(o oVar, MenuItem menuItem) {
        g2 g2Var = this.D;
        if (g2Var != null) {
            g2Var.n(oVar, menuItem);
        }
    }

    public final u1 q(Context context, boolean z4) {
        k2 k2Var = new k2(context, z4);
        k2Var.setHoverListener(this);
        return k2Var;
    }
}
