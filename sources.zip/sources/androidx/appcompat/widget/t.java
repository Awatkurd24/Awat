package androidx.appcompat.widget;

import android.database.DataSetObserver;

public final class t extends DataSetObserver {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1500a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ActivityChooserView f1501b;

    public /* synthetic */ t(ActivityChooserView activityChooserView, int i10) {
        this.f1500a = i10;
        this.f1501b = activityChooserView;
    }

    public final void onChanged() {
        int i10 = this.f1500a;
        ActivityChooserView activityChooserView = this.f1501b;
        switch (i10) {
            case 0:
                super.onChanged();
                activityChooserView.f1068a.notifyDataSetChanged();
                return;
            default:
                super.onChanged();
                activityChooserView.f1068a.getClass();
                throw null;
        }
    }

    public final void onInvalidated() {
        switch (this.f1500a) {
            case 0:
                super.onInvalidated();
                this.f1501b.f1068a.notifyDataSetInvalidated();
                return;
            default:
                super.onInvalidated();
                return;
        }
    }
}
