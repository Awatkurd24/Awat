package androidx.appcompat.widget;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController$RecycleListView;
import com.google.android.gms.internal.ads.qm0;
import h.l;
import h.p;

public final class k0 implements p0, DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public p f1380a;

    /* renamed from: b  reason: collision with root package name */
    public ListAdapter f1381b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f1382c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ AppCompatSpinner f1383d;

    public k0(AppCompatSpinner appCompatSpinner) {
        this.f1383d = appCompatSpinner;
    }

    public final boolean a() {
        p pVar = this.f1380a;
        if (pVar != null) {
            return pVar.isShowing();
        }
        return false;
    }

    public final int b() {
        return 0;
    }

    public final Drawable d() {
        return null;
    }

    public final void dismiss() {
        p pVar = this.f1380a;
        if (pVar != null) {
            pVar.dismiss();
            this.f1380a = null;
        }
    }

    public final void f(CharSequence charSequence) {
        this.f1382c = charSequence;
    }

    public final void g(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    public final void i(int i10) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    public final void j(int i10) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }

    public final void k(int i10) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    public final void l(int i10, int i11) {
        if (this.f1381b != null) {
            AppCompatSpinner appCompatSpinner = this.f1383d;
            qm0 qm0 = new qm0(appCompatSpinner.getPopupContext());
            CharSequence charSequence = this.f1382c;
            if (charSequence != null) {
                ((l) qm0.f11599c).f19344e = charSequence;
            }
            ListAdapter listAdapter = this.f1381b;
            int selectedItemPosition = appCompatSpinner.getSelectedItemPosition();
            l lVar = (l) qm0.f11599c;
            lVar.f19354o = listAdapter;
            lVar.f19355p = this;
            lVar.f19360u = selectedItemPosition;
            lVar.f19359t = true;
            p h10 = qm0.h();
            this.f1380a = h10;
            AlertController$RecycleListView alertController$RecycleListView = h10.f19441f.f19389g;
            i0.d(alertController$RecycleListView, i10);
            i0.c(alertController$RecycleListView, i11);
            this.f1380a.show();
        }
    }

    public final int m() {
        return 0;
    }

    public final CharSequence o() {
        return this.f1382c;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        AppCompatSpinner appCompatSpinner = this.f1383d;
        appCompatSpinner.setSelection(i10);
        if (appCompatSpinner.getOnItemClickListener() != null) {
            appCompatSpinner.performItemClick((View) null, i10, this.f1381b.getItemId(i10));
        }
        dismiss();
    }

    public final void p(ListAdapter listAdapter) {
        this.f1381b = listAdapter;
    }
}
