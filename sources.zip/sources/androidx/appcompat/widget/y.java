package androidx.appcompat.widget;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.CheckedTextView;
import android.widget.CompoundButton;
import android.widget.TextView;
import com.google.android.gms.internal.ads.hk;
import com.google.android.gms.internal.ads.qr;
import d0.g;
import java.lang.ref.WeakReference;
import k1.b;
import o6.k;
import t7.w;

public final class y {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1549a;

    /* renamed from: b  reason: collision with root package name */
    public Object f1550b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1551c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1552d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1553e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1554f;

    /* renamed from: g  reason: collision with root package name */
    public final View f1555g;

    public y(Activity activity, View view, ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
        this.f1549a = 2;
        this.f1550b = activity;
        this.f1555g = view;
        this.f1551c = onGlobalLayoutListener;
    }

    public final void a() {
        View view = this.f1555g;
        Drawable i10 = g.i((CompoundButton) view);
        if (i10 == null) {
            return;
        }
        if (this.f1552d || this.f1553e) {
            Drawable mutate = w.m(i10).mutate();
            if (this.f1552d) {
                b.h(mutate, (ColorStateList) this.f1550b);
            }
            if (this.f1553e) {
                b.i(mutate, (PorterDuff.Mode) this.f1551c);
            }
            if (mutate.isStateful()) {
                mutate.setState(((CompoundButton) view).getDrawableState());
            }
            ((CompoundButton) view).setButtonDrawable(mutate);
        }
    }

    public final void b() {
        View view = this.f1555g;
        Drawable checkMarkDrawable = ((CheckedTextView) view).getCheckMarkDrawable();
        if (checkMarkDrawable == null) {
            return;
        }
        if (this.f1552d || this.f1553e) {
            Drawable mutate = w.m(checkMarkDrawable).mutate();
            if (this.f1552d) {
                b.h(mutate, (ColorStateList) this.f1550b);
            }
            if (this.f1553e) {
                b.i(mutate, (PorterDuff.Mode) this.f1551c);
            }
            if (mutate.isStateful()) {
                mutate.setState(((CheckedTextView) view).getDrawableState());
            }
            ((CheckedTextView) view).setCheckMarkDrawable(mutate);
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(12:29|30|(3:34|35|36)|38|39|(1:43)|44|(1:46)|47|(1:49)|50|51) */
    /* JADX WARNING: Can't wrap try/catch for region: R(13:2|3|4|(3:8|9|10)|12|13|(1:17)|18|(1:20)|21|(1:23)|24|25) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x0050 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:38:0x00d5 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(android.util.AttributeSet r17, int r18) {
        /*
            r16 = this;
            r1 = r16
            r0 = r17
            r7 = r18
            int r2 = r1.f1549a
            r8 = 0
            r9 = -1
            r10 = 3
            r11 = 2
            r12 = 1
            r13 = 0
            android.view.View r14 = r1.f1555g
            switch(r2) {
                case 0: goto L_0x0098;
                default: goto L_0x0013;
            }
        L_0x0013:
            r2 = r14
            android.widget.CompoundButton r2 = (android.widget.CompoundButton) r2
            android.content.Context r3 = r2.getContext()
            int[] r4 = g.a.f18932n
            a4.w r15 = a4.w.K(r3, r0, r4, r7)
            android.content.Context r3 = r2.getContext()
            java.lang.Object r5 = r15.f619c
            r6 = r5
            android.content.res.TypedArray r6 = (android.content.res.TypedArray) r6
            r5 = r17
            r7 = r18
            r1.h1.q(r2, r3, r4, r5, r6, r7)
            boolean r0 = r15.G(r12)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x0050
            int r0 = r15.B(r12, r13)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x0050
            r2 = r14
            android.widget.CompoundButton r2 = (android.widget.CompoundButton) r2     // Catch:{ NotFoundException -> 0x0050 }
            r3 = r14
            android.widget.CompoundButton r3 = (android.widget.CompoundButton) r3     // Catch:{ NotFoundException -> 0x0050 }
            android.content.Context r3 = r3.getContext()     // Catch:{ NotFoundException -> 0x0050 }
            android.graphics.drawable.Drawable r0 = u7.y.e(r3, r0)     // Catch:{ NotFoundException -> 0x0050 }
            r2.setButtonDrawable(r0)     // Catch:{ NotFoundException -> 0x0050 }
            goto L_0x006d
        L_0x004e:
            r0 = move-exception
            goto L_0x0094
        L_0x0050:
            boolean r0 = r15.G(r13)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x006d
            int r0 = r15.B(r13, r13)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x006d
            r2 = r14
            android.widget.CompoundButton r2 = (android.widget.CompoundButton) r2     // Catch:{ all -> 0x004e }
            r3 = r14
            android.widget.CompoundButton r3 = (android.widget.CompoundButton) r3     // Catch:{ all -> 0x004e }
            android.content.Context r3 = r3.getContext()     // Catch:{ all -> 0x004e }
            android.graphics.drawable.Drawable r0 = u7.y.e(r3, r0)     // Catch:{ all -> 0x004e }
            r2.setButtonDrawable(r0)     // Catch:{ all -> 0x004e }
        L_0x006d:
            boolean r0 = r15.G(r11)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x007d
            r0 = r14
            android.widget.CompoundButton r0 = (android.widget.CompoundButton) r0     // Catch:{ all -> 0x004e }
            android.content.res.ColorStateList r2 = r15.t(r11)     // Catch:{ all -> 0x004e }
            v1.b.c(r0, r2)     // Catch:{ all -> 0x004e }
        L_0x007d:
            boolean r0 = r15.G(r10)     // Catch:{ all -> 0x004e }
            if (r0 == 0) goto L_0x0090
            android.widget.CompoundButton r14 = (android.widget.CompoundButton) r14     // Catch:{ all -> 0x004e }
            int r0 = r15.z(r10, r9)     // Catch:{ all -> 0x004e }
            android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.o1.c(r0, r8)     // Catch:{ all -> 0x004e }
            v1.b.d(r14, r0)     // Catch:{ all -> 0x004e }
        L_0x0090:
            r15.N()
            return
        L_0x0094:
            r15.N()
            throw r0
        L_0x0098:
            r2 = r14
            android.widget.CheckedTextView r2 = (android.widget.CheckedTextView) r2
            android.content.Context r3 = r2.getContext()
            int[] r4 = g.a.f18931m
            a4.w r15 = a4.w.K(r3, r0, r4, r7)
            android.content.Context r3 = r2.getContext()
            java.lang.Object r5 = r15.f619c
            r6 = r5
            android.content.res.TypedArray r6 = (android.content.res.TypedArray) r6
            r5 = r17
            r7 = r18
            r1.h1.q(r2, r3, r4, r5, r6, r7)
            boolean r0 = r15.G(r12)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x00d5
            int r0 = r15.B(r12, r13)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x00d5
            r2 = r14
            android.widget.CheckedTextView r2 = (android.widget.CheckedTextView) r2     // Catch:{ NotFoundException -> 0x00d5 }
            r3 = r14
            android.widget.CheckedTextView r3 = (android.widget.CheckedTextView) r3     // Catch:{ NotFoundException -> 0x00d5 }
            android.content.Context r3 = r3.getContext()     // Catch:{ NotFoundException -> 0x00d5 }
            android.graphics.drawable.Drawable r0 = u7.y.e(r3, r0)     // Catch:{ NotFoundException -> 0x00d5 }
            r2.setCheckMarkDrawable(r0)     // Catch:{ NotFoundException -> 0x00d5 }
            goto L_0x00f2
        L_0x00d3:
            r0 = move-exception
            goto L_0x0119
        L_0x00d5:
            boolean r0 = r15.G(r13)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x00f2
            int r0 = r15.B(r13, r13)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x00f2
            r2 = r14
            android.widget.CheckedTextView r2 = (android.widget.CheckedTextView) r2     // Catch:{ all -> 0x00d3 }
            r3 = r14
            android.widget.CheckedTextView r3 = (android.widget.CheckedTextView) r3     // Catch:{ all -> 0x00d3 }
            android.content.Context r3 = r3.getContext()     // Catch:{ all -> 0x00d3 }
            android.graphics.drawable.Drawable r0 = u7.y.e(r3, r0)     // Catch:{ all -> 0x00d3 }
            r2.setCheckMarkDrawable(r0)     // Catch:{ all -> 0x00d3 }
        L_0x00f2:
            boolean r0 = r15.G(r11)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x0102
            r0 = r14
            android.widget.CheckedTextView r0 = (android.widget.CheckedTextView) r0     // Catch:{ all -> 0x00d3 }
            android.content.res.ColorStateList r2 = r15.t(r11)     // Catch:{ all -> 0x00d3 }
            r0.setCheckMarkTintList(r2)     // Catch:{ all -> 0x00d3 }
        L_0x0102:
            boolean r0 = r15.G(r10)     // Catch:{ all -> 0x00d3 }
            if (r0 == 0) goto L_0x0115
            android.widget.CheckedTextView r14 = (android.widget.CheckedTextView) r14     // Catch:{ all -> 0x00d3 }
            int r0 = r15.z(r10, r9)     // Catch:{ all -> 0x00d3 }
            android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.o1.c(r0, r8)     // Catch:{ all -> 0x00d3 }
            r14.setCheckMarkTintMode(r0)     // Catch:{ all -> 0x00d3 }
        L_0x0115:
            r15.N()
            return
        L_0x0119:
            r15.N()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.y.c(android.util.AttributeSet, int):void");
    }

    public final void d() {
        ViewTreeObserver viewTreeObserver;
        ViewTreeObserver viewTreeObserver2;
        View decorView;
        if (!this.f1552d) {
            Activity activity = (Activity) this.f1550b;
            ViewTreeObserver viewTreeObserver3 = null;
            if (activity != null) {
                ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener = (ViewTreeObserver.OnGlobalLayoutListener) this.f1551c;
                Window window = activity.getWindow();
                if (window == null || (decorView = window.getDecorView()) == null) {
                    viewTreeObserver2 = null;
                } else {
                    viewTreeObserver2 = decorView.getViewTreeObserver();
                }
                if (viewTreeObserver2 != null) {
                    viewTreeObserver2.addOnGlobalLayoutListener(onGlobalLayoutListener);
                }
            }
            hk hkVar = k.A.f23656z;
            qr qrVar = new qr(this.f1555g, (ViewTreeObserver.OnGlobalLayoutListener) this.f1551c);
            View view = (View) ((WeakReference) qrVar.f7702a).get();
            if (!(view == null || (viewTreeObserver = view.getViewTreeObserver()) == null || !viewTreeObserver.isAlive())) {
                viewTreeObserver3 = viewTreeObserver;
            }
            if (viewTreeObserver3 != null) {
                qrVar.q0(viewTreeObserver3);
            }
            this.f1552d = true;
        }
    }

    public /* synthetic */ y(TextView textView, int i10) {
        this.f1549a = i10;
        this.f1550b = null;
        this.f1551c = null;
        this.f1552d = false;
        this.f1553e = false;
        this.f1555g = textView;
    }
}
