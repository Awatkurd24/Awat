package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import co.vpn.plusvpn.R;
import g.a;
import m.o;
import r1.h1;
import r1.u1;

public class ActionBarContextView extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public final a f1010a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f1011b;

    /* renamed from: c  reason: collision with root package name */
    public ActionMenuView f1012c;

    /* renamed from: d  reason: collision with root package name */
    public n f1013d;

    /* renamed from: e  reason: collision with root package name */
    public int f1014e;

    /* renamed from: f  reason: collision with root package name */
    public u1 f1015f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1016g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1017h;

    /* renamed from: i  reason: collision with root package name */
    public CharSequence f1018i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f1019j;

    /* renamed from: k  reason: collision with root package name */
    public View f1020k;

    /* renamed from: l  reason: collision with root package name */
    public View f1021l;

    /* renamed from: m  reason: collision with root package name */
    public View f1022m;

    /* renamed from: n  reason: collision with root package name */
    public LinearLayout f1023n;

    /* renamed from: o  reason: collision with root package name */
    public TextView f1024o;

    /* renamed from: p  reason: collision with root package name */
    public TextView f1025p;

    /* renamed from: q  reason: collision with root package name */
    public final int f1026q;

    /* renamed from: r  reason: collision with root package name */
    public final int f1027r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f1028s;

    /* renamed from: t  reason: collision with root package name */
    public final int f1029t;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionModeStyle);
    }

    public static int f(View view, int i10, int i11) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i10, Integer.MIN_VALUE), i11);
        return Math.max(0, i10 - view.getMeasuredWidth());
    }

    public static int j(View view, int i10, int i11, int i12, boolean z4) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i13 = ((i12 - measuredHeight) / 2) + i11;
        if (z4) {
            view.layout(i10 - measuredWidth, i13, i10, measuredHeight + i13);
        } else {
            view.layout(i10, i13, i10 + measuredWidth, measuredHeight + i13);
        }
        if (z4) {
            return -measuredWidth;
        }
        return measuredWidth;
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x008b  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x003d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(l.b r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.f1020k
            r1 = 0
            if (r0 != 0) goto L_0x0019
            android.content.Context r0 = r6.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r2 = r6.f1029t
            android.view.View r0 = r0.inflate(r2, r6, r1)
            r6.f1020k = r0
        L_0x0015:
            r6.addView(r0)
            goto L_0x0022
        L_0x0019:
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0022
            android.view.View r0 = r6.f1020k
            goto L_0x0015
        L_0x0022:
            android.view.View r0 = r6.f1020k
            r2 = 2131361859(0x7f0a0043, float:1.8343482E38)
            android.view.View r0 = r0.findViewById(r2)
            r6.f1021l = r0
            androidx.appcompat.widget.c r2 = new androidx.appcompat.widget.c
            r2.<init>(r6, r7)
            r0.setOnClickListener(r2)
            m.o r7 = r7.c()
            androidx.appcompat.widget.n r0 = r6.f1013d
            if (r0 == 0) goto L_0x004f
            r0.c()
            androidx.appcompat.widget.h r0 = r0.f1438u
            if (r0 == 0) goto L_0x004f
            boolean r2 = r0.b()
            if (r2 == 0) goto L_0x004f
            m.x r0 = r0.f22213j
            r0.dismiss()
        L_0x004f:
            androidx.appcompat.widget.n r0 = new androidx.appcompat.widget.n
            android.content.Context r2 = r6.getContext()
            r0.<init>(r2)
            r6.f1013d = r0
            r2 = 1
            r0.f1430m = r2
            r0.f1431n = r2
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r3 = -2
            r4 = -1
            r0.<init>(r3, r4)
            androidx.appcompat.widget.n r3 = r6.f1013d
            android.content.Context r4 = r6.f1011b
            r7.b(r3, r4)
            androidx.appcompat.widget.n r7 = r6.f1013d
            m.e0 r3 = r7.f1425h
            if (r3 != 0) goto L_0x0087
            android.view.LayoutInflater r4 = r7.f1421d
            int r5 = r7.f1423f
            android.view.View r1 = r4.inflate(r5, r6, r1)
            m.e0 r1 = (m.e0) r1
            r7.f1425h = r1
            m.o r4 = r7.f1420c
            r1.c(r4)
            r7.f(r2)
        L_0x0087:
            m.e0 r1 = r7.f1425h
            if (r3 == r1) goto L_0x0091
            r2 = r1
            androidx.appcompat.widget.ActionMenuView r2 = (androidx.appcompat.widget.ActionMenuView) r2
            r2.setPresenter(r7)
        L_0x0091:
            androidx.appcompat.widget.ActionMenuView r1 = (androidx.appcompat.widget.ActionMenuView) r1
            r6.f1012c = r1
            java.util.WeakHashMap r7 = r1.h1.f25195a
            r7 = 0
            r1.p0.q(r1, r7)
            androidx.appcompat.widget.ActionMenuView r7 = r6.f1012c
            r6.addView(r7, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.c(l.b):void");
    }

    public final void d() {
        if (this.f1023n == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f1023n = linearLayout;
            this.f1024o = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f1025p = (TextView) this.f1023n.findViewById(R.id.action_bar_subtitle);
            int i10 = this.f1026q;
            if (i10 != 0) {
                this.f1024o.setTextAppearance(getContext(), i10);
            }
            int i11 = this.f1027r;
            if (i11 != 0) {
                this.f1025p.setTextAppearance(getContext(), i11);
            }
        }
        this.f1024o.setText(this.f1018i);
        this.f1025p.setText(this.f1019j);
        boolean z4 = !TextUtils.isEmpty(this.f1018i);
        boolean z10 = !TextUtils.isEmpty(this.f1019j);
        int i12 = 8;
        this.f1025p.setVisibility(z10 ? 0 : 8);
        LinearLayout linearLayout2 = this.f1023n;
        if (z4 || z10) {
            i12 = 0;
        }
        linearLayout2.setVisibility(i12);
        if (this.f1023n.getParent() == null) {
            addView(this.f1023n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f1022m = null;
        this.f1012c = null;
        this.f1013d = null;
        View view = this.f1021l;
        if (view != null) {
            view.setOnClickListener((View.OnClickListener) null);
        }
    }

    /* renamed from: g */
    public final void onConfigurationChanged(Configuration configuration) {
        int i10;
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, a.f18919a, R.attr.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(13, 0));
        obtainStyledAttributes.recycle();
        n nVar = this.f1013d;
        if (nVar != null) {
            Configuration configuration2 = nVar.f1419b.getResources().getConfiguration();
            int i11 = configuration2.screenWidthDp;
            int i12 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i11 > 600 || ((i11 > 960 && i12 > 720) || (i11 > 720 && i12 > 960))) {
                i10 = 5;
            } else if (i11 >= 500 || ((i11 > 640 && i12 > 480) || (i11 > 480 && i12 > 640))) {
                i10 = 4;
            } else if (i11 >= 360) {
                i10 = 3;
            } else {
                i10 = 2;
            }
            nVar.f1434q = i10;
            o oVar = nVar.f1420c;
            if (oVar != null) {
                oVar.p(true);
            }
        }
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        if (this.f1015f != null) {
            return this.f1010a.f1281b;
        }
        return getVisibility();
    }

    public int getContentHeight() {
        return this.f1014e;
    }

    public CharSequence getSubtitle() {
        return this.f1019j;
    }

    public CharSequence getTitle() {
        return this.f1018i;
    }

    /* renamed from: h */
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1017h = false;
        }
        if (!this.f1017h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1017h = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1017h = false;
        }
        return true;
    }

    /* renamed from: i */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1016g = false;
        }
        if (!this.f1016g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1016g = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1016g = false;
        }
        return true;
    }

    /* renamed from: k */
    public final void setVisibility(int i10) {
        if (i10 != getVisibility()) {
            u1 u1Var = this.f1015f;
            if (u1Var != null) {
                u1Var.b();
            }
            super.setVisibility(i10);
        }
    }

    public final u1 l(int i10, long j3) {
        u1 u1Var = this.f1015f;
        if (u1Var != null) {
            u1Var.b();
        }
        a aVar = this.f1010a;
        if (i10 == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            u1 a10 = h1.a(this);
            a10.a(1.0f);
            a10.c(j3);
            aVar.f1282c.f1015f = a10;
            aVar.f1281b = i10;
            a10.d(aVar);
            return a10;
        }
        u1 a11 = h1.a(this);
        a11.a(0.0f);
        a11.c(j3);
        aVar.f1282c.f1015f = a11;
        aVar.f1281b = i10;
        a11.d(aVar);
        return a11;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        n nVar = this.f1013d;
        if (nVar != null) {
            nVar.c();
            h hVar = this.f1013d.f1438u;
            if (hVar != null && hVar.b()) {
                hVar.f22213j.dismiss();
            }
        }
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        boolean a10 = f4.a(this);
        if (a10) {
            i14 = (i12 - i10) - getPaddingRight();
        } else {
            i14 = getPaddingLeft();
        }
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
        View view = this.f1020k;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1020k.getLayoutParams();
            if (a10) {
                i16 = marginLayoutParams.rightMargin;
            } else {
                i16 = marginLayoutParams.leftMargin;
            }
            if (a10) {
                i17 = marginLayoutParams.leftMargin;
            } else {
                i17 = marginLayoutParams.rightMargin;
            }
            if (a10) {
                i18 = i14 - i16;
            } else {
                i18 = i14 + i16;
            }
            int j3 = j(this.f1020k, i18, paddingTop, paddingTop2, a10) + i18;
            if (a10) {
                i19 = j3 - i17;
            } else {
                i19 = j3 + i17;
            }
            i14 = i19;
        }
        LinearLayout linearLayout = this.f1023n;
        if (!(linearLayout == null || this.f1022m != null || linearLayout.getVisibility() == 8)) {
            i14 += j(this.f1023n, i14, paddingTop, paddingTop2, a10);
        }
        View view2 = this.f1022m;
        if (view2 != null) {
            j(view2, i14, paddingTop, paddingTop2, a10);
        }
        if (a10) {
            i15 = getPaddingLeft();
        } else {
            i15 = (i12 - i10) - getPaddingRight();
        }
        ActionMenuView actionMenuView = this.f1012c;
        if (actionMenuView != null) {
            j(actionMenuView, i15, paddingTop, paddingTop2, !a10);
        }
    }

    public final void onMeasure(int i10, int i11) {
        int i12 = 1073741824;
        if (View.MeasureSpec.getMode(i10) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        } else if (View.MeasureSpec.getMode(i11) != 0) {
            int size = View.MeasureSpec.getSize(i10);
            int i13 = this.f1014e;
            if (i13 <= 0) {
                i13 = View.MeasureSpec.getSize(i11);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i14 = i13 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i14, Integer.MIN_VALUE);
            View view = this.f1020k;
            if (view != null) {
                int f10 = f(view, paddingLeft, makeMeasureSpec);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1020k.getLayoutParams();
                paddingLeft = f10 - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f1012c;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = f(this.f1012c, paddingLeft, makeMeasureSpec);
            }
            LinearLayout linearLayout = this.f1023n;
            if (linearLayout != null && this.f1022m == null) {
                if (this.f1028s) {
                    this.f1023n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f1023n.getMeasuredWidth();
                    boolean z4 = measuredWidth <= paddingLeft;
                    if (z4) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f1023n.setVisibility(z4 ? 0 : 8);
                } else {
                    paddingLeft = f(linearLayout, paddingLeft, makeMeasureSpec);
                }
            }
            View view2 = this.f1022m;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i15 = layoutParams.width;
                int i16 = i15 != -2 ? 1073741824 : Integer.MIN_VALUE;
                if (i15 >= 0) {
                    paddingLeft = Math.min(i15, paddingLeft);
                }
                int i17 = layoutParams.height;
                if (i17 == -2) {
                    i12 = Integer.MIN_VALUE;
                }
                if (i17 >= 0) {
                    i14 = Math.min(i17, i14);
                }
                this.f1022m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i16), View.MeasureSpec.makeMeasureSpec(i14, i12));
            }
            if (this.f1014e <= 0) {
                int childCount = getChildCount();
                i13 = 0;
                for (int i18 = 0; i18 < childCount; i18++) {
                    int measuredHeight = getChildAt(i18).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i13) {
                        i13 = measuredHeight;
                    }
                }
            }
            setMeasuredDimension(size, i13);
        } else {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
    }

    public void setContentHeight(int i10) {
        this.f1014e = i10;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f1022m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f1022m = view;
        if (!(view == null || (linearLayout = this.f1023n) == null)) {
            removeView(linearLayout);
            this.f1023n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1019j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f1018i = charSequence;
        d();
        h1.s(this, charSequence);
    }

    public void setTitleOptional(boolean z4) {
        if (z4 != this.f1028s) {
            requestLayout();
        }
        this.f1028s = z4;
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x003a, code lost:
        r7 = r6.getResourceId(0, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActionBarContextView(android.content.Context r5, android.util.AttributeSet r6, int r7) {
        /*
            r4 = this;
            r4.<init>(r5, r6, r7)
            androidx.appcompat.widget.a r0 = new androidx.appcompat.widget.a
            r0.<init>(r4)
            r4.f1010a = r0
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.res.Resources$Theme r1 = r5.getTheme()
            r2 = 2130968580(0x7f040004, float:1.7545818E38)
            r3 = 1
            boolean r1 = r1.resolveAttribute(r2, r0, r3)
            if (r1 == 0) goto L_0x002b
            int r1 = r0.resourceId
            if (r1 == 0) goto L_0x002b
            android.view.ContextThemeWrapper r1 = new android.view.ContextThemeWrapper
            int r0 = r0.resourceId
            r1.<init>(r5, r0)
            r4.f1011b = r1
            goto L_0x002d
        L_0x002b:
            r4.f1011b = r5
        L_0x002d:
            int[] r0 = g.a.f18922d
            r1 = 0
            android.content.res.TypedArray r6 = r5.obtainStyledAttributes(r6, r0, r7, r1)
            boolean r7 = r6.hasValue(r1)
            if (r7 == 0) goto L_0x0045
            int r7 = r6.getResourceId(r1, r1)
            if (r7 == 0) goto L_0x0045
            android.graphics.drawable.Drawable r5 = u7.y.e(r5, r7)
            goto L_0x0049
        L_0x0045:
            android.graphics.drawable.Drawable r5 = r6.getDrawable(r1)
        L_0x0049:
            java.util.WeakHashMap r7 = r1.h1.f25195a
            r1.p0.q(r4, r5)
            r5 = 5
            int r5 = r6.getResourceId(r5, r1)
            r4.f1026q = r5
            r5 = 4
            int r5 = r6.getResourceId(r5, r1)
            r4.f1027r = r5
            r5 = 3
            int r5 = r6.getLayoutDimension(r5, r1)
            r4.f1014e = r5
            r5 = 2
            r7 = 2131558405(0x7f0d0005, float:1.8742125E38)
            int r5 = r6.getResourceId(r5, r7)
            r4.f1029t = r5
            r6.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }
}
