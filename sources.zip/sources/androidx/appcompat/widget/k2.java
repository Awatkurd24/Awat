package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import m.l;
import m.o;
import m.q;

public final class k2 extends u1 {

    /* renamed from: m  reason: collision with root package name */
    public final int f1384m;

    /* renamed from: n  reason: collision with root package name */
    public final int f1385n;

    /* renamed from: o  reason: collision with root package name */
    public g2 f1386o;

    /* renamed from: p  reason: collision with root package name */
    public q f1387p;

    public k2(Context context, boolean z4) {
        super(context, z4);
        if (1 == j2.a(context.getResources().getConfiguration())) {
            this.f1384m = 21;
            this.f1385n = 22;
            return;
        }
        this.f1384m = 22;
        this.f1385n = 21;
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int i10;
        l lVar;
        q qVar;
        int pointToPosition;
        int i11;
        if (this.f1386o != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                i10 = headerViewListAdapter.getHeadersCount();
                lVar = (l) headerViewListAdapter.getWrappedAdapter();
            } else {
                lVar = (l) adapter;
                i10 = 0;
            }
            if (motionEvent.getAction() == 10 || (pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i11 = pointToPosition - i10) < 0 || i11 >= lVar.getCount()) {
                qVar = null;
            } else {
                qVar = lVar.getItem(i11);
            }
            q qVar2 = this.f1387p;
            if (qVar2 != qVar) {
                o oVar = lVar.f22288a;
                if (qVar2 != null) {
                    this.f1386o.n(oVar, qVar2);
                }
                this.f1387p = qVar;
                if (qVar != null) {
                    this.f1386o.h(oVar, qVar);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    public final boolean onKeyDown(int i10, KeyEvent keyEvent) {
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i10 == this.f1384m) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        } else if (listMenuItemView == null || i10 != this.f1385n) {
            return super.onKeyDown(i10, keyEvent);
        } else {
            setSelection(-1);
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((l) adapter).f22288a.c(false);
            return true;
        }
    }

    public void setHoverListener(g2 g2Var) {
        this.f1386o = g2Var;
    }

    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
