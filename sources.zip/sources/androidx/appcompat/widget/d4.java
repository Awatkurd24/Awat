package androidx.appcompat.widget;

public abstract class d4 extends q2 {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f1326a = 0;
}
