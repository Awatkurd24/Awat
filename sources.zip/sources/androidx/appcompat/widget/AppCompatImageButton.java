package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class AppCompatImageButton extends ImageButton {

    /* renamed from: a  reason: collision with root package name */
    public final x f1101a;

    /* renamed from: b  reason: collision with root package name */
    public final c0 f1102b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1103c = false;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatImageButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        o3.a(getContext(), this);
        x xVar = new x((View) this);
        this.f1101a = xVar;
        xVar.f(attributeSet, i10);
        c0 c0Var = new c0((ImageView) this);
        this.f1102b = c0Var;
        c0Var.b(attributeSet, i10);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1101a;
        if (xVar != null) {
            xVar.a();
        }
        c0 c0Var = this.f1102b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1101a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1101a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        q3 q3Var;
        c0 c0Var = this.f1102b;
        if (c0Var == null || (q3Var = (q3) c0Var.f1313e) == null) {
            return null;
        }
        return (ColorStateList) q3Var.f1478c;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        q3 q3Var;
        c0 c0Var = this.f1102b;
        if (c0Var == null || (q3Var = (q3) c0Var.f1313e) == null) {
            return null;
        }
        return (PorterDuff.Mode) q3Var.f1479d;
    }

    public final boolean hasOverlappingRendering() {
        if (!(!(((ImageView) this.f1102b.f1311c).getBackground() instanceof RippleDrawable)) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1101a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1101a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        c0 c0Var = this.f1102b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        c0 c0Var = this.f1102b;
        if (!(c0Var == null || drawable == null || this.f1103c)) {
            c0Var.f1310b = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (c0Var != null) {
            c0Var.a();
            if (!this.f1103c && ((ImageView) c0Var.f1311c).getDrawable() != null) {
                ((ImageView) c0Var.f1311c).getDrawable().setLevel(c0Var.f1310b);
            }
        }
    }

    public void setImageLevel(int i10) {
        super.setImageLevel(i10);
        this.f1103c = true;
    }

    public void setImageResource(int i10) {
        this.f1102b.c(i10);
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        c0 c0Var = this.f1102b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1101a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1101a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        c0 c0Var = this.f1102b;
        if (c0Var != null) {
            if (((q3) c0Var.f1313e) == null) {
                c0Var.f1313e = new Object();
            }
            q3 q3Var = (q3) c0Var.f1313e;
            q3Var.f1478c = colorStateList;
            q3Var.f1477b = true;
            c0Var.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        c0 c0Var = this.f1102b;
        if (c0Var != null) {
            if (((q3) c0Var.f1313e) == null) {
                c0Var.f1313e = new Object();
            }
            q3 q3Var = (q3) c0Var.f1313e;
            q3Var.f1479d = mode;
            q3Var.f1476a = true;
            c0Var.a();
        }
    }
}
