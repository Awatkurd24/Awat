package androidx.appcompat.widget;

public interface z0 {
    void c(int i10);

    void f(int i10);
}
