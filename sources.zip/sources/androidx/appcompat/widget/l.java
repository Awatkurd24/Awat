package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import c0.g;
import co.vpn.plusvpn.R;
import k1.b;

public final class l extends AppCompatImageView implements o {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ n f1405d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(n nVar, Context context) {
        super(context, (AttributeSet) null, R.attr.actionOverflowButtonStyle);
        this.f1405d = nVar;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        g.j(this, getContentDescription());
        setOnTouchListener(new k(this, this, nVar, 0));
    }

    public final boolean a() {
        return false;
    }

    public final boolean c() {
        return false;
    }

    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.f1405d.n();
        return true;
    }

    public final boolean setFrame(int i10, int i11, int i12, int i13) {
        boolean frame = super.setFrame(i10, i11, i12, i13);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (!(drawable == null || background == null)) {
            int width = getWidth();
            int height = getHeight();
            int max = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            b.f(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
        }
        return frame;
    }
}
