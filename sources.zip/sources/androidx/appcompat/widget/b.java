package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

public final class b extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final ActionBarContainer f1291a;

    public b(ActionBarContainer actionBarContainer) {
        this.f1291a = actionBarContainer;
    }

    public final void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f1291a;
        if (actionBarContainer.f1007g) {
            Drawable drawable = actionBarContainer.f1006f;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f1004d;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Drawable drawable3 = actionBarContainer.f1005e;
        if (drawable3 != null && actionBarContainer.f1008h) {
            drawable3.draw(canvas);
        }
    }

    public final int getOpacity() {
        return 0;
    }

    public final void getOutline(Outline outline) {
        Drawable drawable;
        ActionBarContainer actionBarContainer = this.f1291a;
        if (!actionBarContainer.f1007g) {
            drawable = actionBarContainer.f1004d;
            if (drawable == null) {
                return;
            }
        } else if (actionBarContainer.f1006f != null) {
            drawable = actionBarContainer.f1004d;
        } else {
            return;
        }
        drawable.getOutline(outline);
    }

    public final void setAlpha(int i10) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
