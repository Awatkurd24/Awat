package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import co.vpn.plusvpn.R;
import g.a;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import m.g0;
import r1.h1;
import r1.s0;
import u7.y;
import v1.l;

public class ListPopupWindow implements g0 {
    public static final Method A;
    public static final Method B;
    public static final Method C;

    /* renamed from: a  reason: collision with root package name */
    public final Context f1165a;

    /* renamed from: b  reason: collision with root package name */
    public ListAdapter f1166b;

    /* renamed from: c  reason: collision with root package name */
    public u1 f1167c;

    /* renamed from: d  reason: collision with root package name */
    public final int f1168d;

    /* renamed from: e  reason: collision with root package name */
    public int f1169e;

    /* renamed from: f  reason: collision with root package name */
    public int f1170f;

    /* renamed from: g  reason: collision with root package name */
    public int f1171g;

    /* renamed from: h  reason: collision with root package name */
    public final int f1172h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1173i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1174j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1175k;

    /* renamed from: l  reason: collision with root package name */
    public int f1176l;

    /* renamed from: m  reason: collision with root package name */
    public final int f1177m;

    /* renamed from: n  reason: collision with root package name */
    public d2 f1178n;

    /* renamed from: o  reason: collision with root package name */
    public View f1179o;

    /* renamed from: p  reason: collision with root package name */
    public AdapterView.OnItemClickListener f1180p;

    /* renamed from: q  reason: collision with root package name */
    public AdapterView.OnItemSelectedListener f1181q;

    /* renamed from: r  reason: collision with root package name */
    public final z1 f1182r;

    /* renamed from: s  reason: collision with root package name */
    public final f2 f1183s;

    /* renamed from: t  reason: collision with root package name */
    public final e2 f1184t;

    /* renamed from: u  reason: collision with root package name */
    public final z1 f1185u;

    /* renamed from: v  reason: collision with root package name */
    public final Handler f1186v;

    /* renamed from: w  reason: collision with root package name */
    public final Rect f1187w;

    /* renamed from: x  reason: collision with root package name */
    public Rect f1188x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f1189y;

    /* renamed from: z  reason: collision with root package name */
    public final PopupWindow f1190z;

    static {
        Class<PopupWindow> cls = PopupWindow.class;
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                A = cls.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                C = cls.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                B = cls.getDeclaredMethod("getMaxAvailableHeight", new Class[]{View.class, Integer.TYPE, Boolean.TYPE});
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public ListPopupWindow(Context context) {
        this(context, (AttributeSet) null, R.attr.listPopupWindowStyle);
    }

    public final boolean a() {
        return this.f1190z.isShowing();
    }

    public final int b() {
        return this.f1170f;
    }

    public final void c() {
        int i10;
        boolean z4;
        int i11;
        int i12;
        boolean z10;
        u1 u1Var;
        int i13;
        int i14;
        int i15;
        int i16;
        u1 u1Var2 = this.f1167c;
        PopupWindow popupWindow = this.f1190z;
        Context context = this.f1165a;
        int i17 = 0;
        if (u1Var2 == null) {
            u1 q10 = q(context, !this.f1189y);
            this.f1167c = q10;
            q10.setAdapter(this.f1166b);
            this.f1167c.setOnItemClickListener(this.f1180p);
            this.f1167c.setFocusable(true);
            this.f1167c.setFocusableInTouchMode(true);
            this.f1167c.setOnItemSelectedListener(new a2(0, this));
            this.f1167c.setOnScrollListener(this.f1184t);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f1181q;
            if (onItemSelectedListener != null) {
                this.f1167c.setOnItemSelectedListener(onItemSelectedListener);
            }
            popupWindow.setContentView(this.f1167c);
        } else {
            ViewGroup viewGroup = (ViewGroup) popupWindow.getContentView();
        }
        Drawable background = popupWindow.getBackground();
        Rect rect = this.f1187w;
        if (background != null) {
            background.getPadding(rect);
            int i18 = rect.top;
            i10 = rect.bottom + i18;
            if (!this.f1173i) {
                this.f1171g = -i18;
            }
        } else {
            rect.setEmpty();
            i10 = 0;
        }
        if (popupWindow.getInputMethodMode() == 2) {
            z4 = true;
        } else {
            z4 = false;
        }
        View view = this.f1179o;
        int i19 = this.f1171g;
        if (Build.VERSION.SDK_INT <= 23) {
            Method method = B;
            if (method != null) {
                try {
                    i11 = ((Integer) method.invoke(popupWindow, new Object[]{view, Integer.valueOf(i19), Boolean.valueOf(z4)})).intValue();
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
                }
            }
            i11 = popupWindow.getMaxAvailableHeight(view, i19);
        } else {
            i11 = b2.a(popupWindow, view, i19, z4);
        }
        int i20 = this.f1168d;
        if (i20 == -1) {
            i12 = i11 + i10;
        } else {
            int i21 = this.f1169e;
            if (i21 == -2) {
                i15 = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE);
            } else if (i21 != -1) {
                i15 = View.MeasureSpec.makeMeasureSpec(i21, 1073741824);
            } else {
                i15 = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824);
            }
            int a10 = this.f1167c.a(i15, i11);
            if (a10 > 0) {
                i16 = this.f1167c.getPaddingBottom() + this.f1167c.getPaddingTop() + i10;
            } else {
                i16 = 0;
            }
            i12 = a10 + i16;
        }
        if (this.f1190z.getInputMethodMode() == 2) {
            z10 = true;
        } else {
            z10 = false;
        }
        y.i(popupWindow, this.f1172h);
        if (popupWindow.isShowing()) {
            View view2 = this.f1179o;
            WeakHashMap weakHashMap = h1.f25195a;
            if (s0.b(view2)) {
                int i22 = this.f1169e;
                if (i22 == -1) {
                    i22 = -1;
                } else if (i22 == -2) {
                    i22 = this.f1179o.getWidth();
                }
                if (i20 == -1) {
                    if (z10) {
                        i20 = i12;
                    } else {
                        i20 = -1;
                    }
                    int i23 = this.f1169e;
                    if (z10) {
                        if (i23 == -1) {
                            i14 = -1;
                        } else {
                            i14 = 0;
                        }
                        popupWindow.setWidth(i14);
                        popupWindow.setHeight(0);
                    } else {
                        if (i23 == -1) {
                            i17 = -1;
                        }
                        popupWindow.setWidth(i17);
                        popupWindow.setHeight(-1);
                    }
                } else if (i20 == -2) {
                    i20 = i12;
                }
                popupWindow.setOutsideTouchable(true);
                View view3 = this.f1179o;
                int i24 = this.f1170f;
                int i25 = this.f1171g;
                if (i22 < 0) {
                    i22 = -1;
                }
                if (i20 < 0) {
                    i13 = -1;
                } else {
                    i13 = i20;
                }
                popupWindow.update(view3, i24, i25, i22, i13);
                return;
            }
            return;
        }
        int i26 = this.f1169e;
        if (i26 == -1) {
            i26 = -1;
        } else if (i26 == -2) {
            i26 = this.f1179o.getWidth();
        }
        if (i20 == -1) {
            i20 = -1;
        } else if (i20 == -2) {
            i20 = i12;
        }
        popupWindow.setWidth(i26);
        popupWindow.setHeight(i20);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = A;
            if (method2 != null) {
                try {
                    method2.invoke(popupWindow, new Object[]{Boolean.TRUE});
                } catch (Exception unused2) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            c2.b(popupWindow, true);
        }
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchInterceptor(this.f1183s);
        if (this.f1175k) {
            y.h(popupWindow, this.f1174j);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method3 = C;
            if (method3 != null) {
                try {
                    method3.invoke(popupWindow, new Object[]{this.f1188x});
                } catch (Exception e10) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e10);
                }
            }
        } else {
            c2.a(popupWindow, this.f1188x);
        }
        l.a(popupWindow, this.f1179o, this.f1170f, this.f1171g, this.f1176l);
        this.f1167c.setSelection(-1);
        if ((!this.f1189y || this.f1167c.isInTouchMode()) && (u1Var = this.f1167c) != null) {
            u1Var.setListSelectionHidden(true);
            u1Var.requestLayout();
        }
        if (!this.f1189y) {
            this.f1186v.post(this.f1185u);
        }
    }

    public final Drawable d() {
        return this.f1190z.getBackground();
    }

    public final void dismiss() {
        PopupWindow popupWindow = this.f1190z;
        popupWindow.dismiss();
        popupWindow.setContentView((View) null);
        this.f1167c = null;
        this.f1186v.removeCallbacks(this.f1182r);
    }

    public final u1 e() {
        return this.f1167c;
    }

    public final void g(Drawable drawable) {
        this.f1190z.setBackgroundDrawable(drawable);
    }

    public final void i(int i10) {
        this.f1171g = i10;
        this.f1173i = true;
    }

    public final void k(int i10) {
        this.f1170f = i10;
    }

    public final int m() {
        if (!this.f1173i) {
            return 0;
        }
        return this.f1171g;
    }

    public void p(ListAdapter listAdapter) {
        d2 d2Var = this.f1178n;
        if (d2Var == null) {
            this.f1178n = new d2(0, this);
        } else {
            ListAdapter listAdapter2 = this.f1166b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(d2Var);
            }
        }
        this.f1166b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f1178n);
        }
        u1 u1Var = this.f1167c;
        if (u1Var != null) {
            u1Var.setAdapter(this.f1166b);
        }
    }

    public u1 q(Context context, boolean z4) {
        return new u1(context, z4);
    }

    public final void r(int i10) {
        Drawable background = this.f1190z.getBackground();
        if (background != null) {
            Rect rect = this.f1187w;
            background.getPadding(rect);
            this.f1169e = rect.left + rect.right + i10;
            return;
        }
        this.f1169e = i10;
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i10) {
        this(context, attributeSet, i10, 0);
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [androidx.appcompat.widget.AppCompatPopupWindow, android.widget.PopupWindow] */
    public ListPopupWindow(Context context, AttributeSet attributeSet, int i10, int i11) {
        this.f1168d = -2;
        this.f1169e = -2;
        this.f1172h = 1002;
        this.f1176l = 0;
        this.f1177m = Integer.MAX_VALUE;
        this.f1182r = new z1(this, 2);
        this.f1183s = new f2(0, this);
        this.f1184t = new e2(this);
        this.f1185u = new z1(this, 1);
        this.f1187w = new Rect();
        this.f1165a = context;
        this.f1186v = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f18935q, i10, i11);
        this.f1170f = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f1171g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f1173i = true;
        }
        obtainStyledAttributes.recycle();
        ? popupWindow = new PopupWindow(context, attributeSet, i10, i11);
        popupWindow.a(context, attributeSet, i10, i11);
        this.f1190z = popupWindow;
        popupWindow.setInputMethodMode(1);
    }
}
