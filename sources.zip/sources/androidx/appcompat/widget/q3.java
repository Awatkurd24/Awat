package androidx.appcompat.widget;

import java.io.Serializable;
import jh.m;
import jh.o0;

public final class q3 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1476a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f1477b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1478c;

    /* renamed from: d  reason: collision with root package name */
    public Serializable f1479d;

    public q3(boolean z4) {
        this.f1476a = z4;
    }

    public final void a(String... strArr) {
        if (!this.f1476a) {
            throw new IllegalStateException("no cipher suites for cleartext connections");
        } else if (strArr.length != 0) {
            this.f1478c = (String[]) strArr.clone();
        } else {
            throw new IllegalArgumentException("At least one cipher suite is required");
        }
    }

    public final void b(m... mVarArr) {
        if (this.f1476a) {
            String[] strArr = new String[mVarArr.length];
            for (int i10 = 0; i10 < mVarArr.length; i10++) {
                strArr[i10] = mVarArr[i10].f21173a;
            }
            a(strArr);
            return;
        }
        throw new IllegalStateException("no cipher suites for cleartext connections");
    }

    /* JADX WARNING: type inference failed for: r2v4, types: [java.lang.String[], java.io.Serializable] */
    public final void c(String... strArr) {
        if (!this.f1476a) {
            throw new IllegalStateException("no TLS versions for cleartext connections");
        } else if (strArr.length != 0) {
            this.f1479d = (String[]) strArr.clone();
        } else {
            throw new IllegalArgumentException("At least one TLS version is required");
        }
    }

    public final void d(o0... o0VarArr) {
        if (this.f1476a) {
            String[] strArr = new String[o0VarArr.length];
            for (int i10 = 0; i10 < o0VarArr.length; i10++) {
                strArr[i10] = o0VarArr[i10].f21190a;
            }
            c(strArr);
            return;
        }
        throw new IllegalStateException("no TLS versions for cleartext connections");
    }
}
