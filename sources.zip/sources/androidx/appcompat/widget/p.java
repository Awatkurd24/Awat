package androidx.appcompat.widget;

import m.b0;
import m.o;

public final class p implements b0 {
    public final boolean I(o oVar) {
        return false;
    }

    public final void b(o oVar, boolean z4) {
    }
}
