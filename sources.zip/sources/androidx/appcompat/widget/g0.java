package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import g.a;
import k1.b;
import r1.h1;
import r1.q0;

public final class g0 extends e0 {

    /* renamed from: d  reason: collision with root package name */
    public final SeekBar f1340d;

    /* renamed from: e  reason: collision with root package name */
    public Drawable f1341e;

    /* renamed from: f  reason: collision with root package name */
    public ColorStateList f1342f = null;

    /* renamed from: g  reason: collision with root package name */
    public PorterDuff.Mode f1343g = null;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1344h = false;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1345i = false;

    public g0(SeekBar seekBar) {
        super(seekBar);
        this.f1340d = seekBar;
    }

    public final void a(AttributeSet attributeSet, int i10) {
        super.a(attributeSet, i10);
        SeekBar seekBar = this.f1340d;
        Context context = seekBar.getContext();
        int[] iArr = a.f18926h;
        w K = w.K(context, attributeSet, iArr, i10);
        h1.q(seekBar, seekBar.getContext(), iArr, attributeSet, (TypedArray) K.f619c, i10);
        Drawable x4 = K.x(0);
        if (x4 != null) {
            seekBar.setThumb(x4);
        }
        Drawable w10 = K.w(1);
        Drawable drawable = this.f1341e;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.f1341e = w10;
        if (w10 != null) {
            w10.setCallback(seekBar);
            t7.w.h(w10, q0.d(seekBar));
            if (w10.isStateful()) {
                w10.setState(seekBar.getDrawableState());
            }
            c();
        }
        seekBar.invalidate();
        if (K.G(3)) {
            this.f1343g = o1.c(K.z(3, -1), this.f1343g);
            this.f1345i = true;
        }
        if (K.G(2)) {
            this.f1342f = K.t(2);
            this.f1344h = true;
        }
        K.N();
        c();
    }

    public final void c() {
        Drawable drawable = this.f1341e;
        if (drawable == null) {
            return;
        }
        if (this.f1344h || this.f1345i) {
            Drawable m10 = t7.w.m(drawable.mutate());
            this.f1341e = m10;
            if (this.f1344h) {
                b.h(m10, this.f1342f);
            }
            if (this.f1345i) {
                b.i(this.f1341e, this.f1343g);
            }
            if (this.f1341e.isStateful()) {
                this.f1341e.setState(this.f1340d.getDrawableState());
            }
        }
    }

    public final void d(Canvas canvas) {
        if (this.f1341e != null) {
            SeekBar seekBar = this.f1340d;
            int max = seekBar.getMax();
            int i10 = 1;
            if (max > 1) {
                int intrinsicWidth = this.f1341e.getIntrinsicWidth();
                int intrinsicHeight = this.f1341e.getIntrinsicHeight();
                int i11 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                if (intrinsicHeight >= 0) {
                    i10 = intrinsicHeight / 2;
                }
                this.f1341e.setBounds(-i11, -i10, i11, i10);
                float width = ((float) ((seekBar.getWidth() - seekBar.getPaddingLeft()) - seekBar.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) seekBar.getPaddingLeft(), (float) (seekBar.getHeight() / 2));
                for (int i12 = 0; i12 <= max; i12++) {
                    this.f1341e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }
}
