package androidx.appcompat.widget;

import a4.e;
import a4.w;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import j2.b;
import u7.y;
import v1.v;
import w7.wa;
import yg.b0;

public class AppCompatMultiAutoCompleteTextView extends MultiAutoCompleteTextView implements v {

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1107d = {16843126};

    /* renamed from: a  reason: collision with root package name */
    public final x f1108a;

    /* renamed from: b  reason: collision with root package name */
    public final y0 f1109b;

    /* renamed from: c  reason: collision with root package name */
    public final e f1110c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatMultiAutoCompleteTextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        o3.a(getContext(), this);
        w K = w.K(getContext(), attributeSet, f1107d, i10);
        if (K.G(0)) {
            setDropDownBackgroundDrawable(K.w(0));
        }
        K.N();
        x xVar = new x((View) this);
        this.f1108a = xVar;
        xVar.f(attributeSet, i10);
        y0 y0Var = new y0(this);
        this.f1109b = y0Var;
        y0Var.f(attributeSet, i10);
        y0Var.b();
        e eVar = new e((EditText) this);
        this.f1110c = eVar;
        eVar.u(attributeSet, i10);
        KeyListener keyListener = getKeyListener();
        if (!(keyListener instanceof NumberKeyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener r4 = eVar.r(keyListener);
            if (r4 != keyListener) {
                super.setKeyListener(r4);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1108a;
        if (xVar != null) {
            xVar.a();
        }
        y0 y0Var = this.f1109b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1108a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1108a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1109b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1109b.e();
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        b0.x(this, editorInfo, onCreateInputConnection);
        return this.f1110c.v(onCreateInputConnection, editorInfo);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1108a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1108a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1109b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1109b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public void setDropDownBackgroundResource(int i10) {
        setDropDownBackgroundDrawable(y.e(getContext(), i10));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        ((wa) ((b) this.f1110c.f542c).f20593d).o(z4);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1110c.r(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1108a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1108a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        y0 y0Var = this.f1109b;
        y0Var.l(colorStateList);
        y0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        y0 y0Var = this.f1109b;
        y0Var.m(mode);
        y0Var.b();
    }

    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        y0 y0Var = this.f1109b;
        if (y0Var != null) {
            y0Var.g(context, i10);
        }
    }
}
