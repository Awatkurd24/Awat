package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;

public final class a2 implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1285a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f1286b;

    public /* synthetic */ a2(int i10, Object obj) {
        this.f1285a = i10;
        this.f1286b = obj;
    }

    public final void onItemSelected(AdapterView adapterView, View view, int i10, long j3) {
        u1 u1Var;
        int i11 = this.f1285a;
        Object obj = this.f1286b;
        switch (i11) {
            case 0:
                if (i10 != -1 && (u1Var = ((ListPopupWindow) obj).f1167c) != null) {
                    u1Var.setListSelectionHidden(false);
                    return;
                }
                return;
            default:
                ((SearchView) obj).q(i10);
                return;
        }
    }

    public final void onNothingSelected(AdapterView adapterView) {
    }
}
