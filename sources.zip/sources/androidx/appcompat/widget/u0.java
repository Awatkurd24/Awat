package androidx.appcompat.widget;

import java.util.Locale;

public abstract class u0 {
    public static Locale a(String str) {
        return Locale.forLanguageTag(str);
    }
}
