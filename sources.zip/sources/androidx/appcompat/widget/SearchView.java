package androidx.appcompat.widget;

import a4.w;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import androidx.customview.view.AbsSavedState;
import c0.g;
import co.vpn.plusvpn.R;
import g.a;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import l.c;
import r1.h1;
import r1.p0;
import w1.b;

public class SearchView extends LinearLayoutCompat implements c {

    /* renamed from: l1  reason: collision with root package name */
    public static final f3 f1191l1;
    public final Rect A;
    public final int[] B;
    public final int[] C;
    public final ImageView D;
    public final Drawable E;
    public final int F;
    public final int G;
    public final Intent H;
    public final Intent I;
    public final CharSequence J;
    public d3 K;
    public View.OnFocusChangeListener L;
    public View.OnClickListener M;
    public boolean N;
    public boolean O;
    public boolean W0;
    public CharSequence X0;
    public boolean Y0;
    public boolean Z0;

    /* renamed from: a1  reason: collision with root package name */
    public int f1192a1;

    /* renamed from: b1  reason: collision with root package name */
    public boolean f1193b1;

    /* renamed from: c1  reason: collision with root package name */
    public String f1194c1;

    /* renamed from: d1  reason: collision with root package name */
    public CharSequence f1195d1;

    /* renamed from: e1  reason: collision with root package name */
    public boolean f1196e1;

    /* renamed from: f1  reason: collision with root package name */
    public int f1197f1;

    /* renamed from: g1  reason: collision with root package name */
    public SearchableInfo f1198g1;

    /* renamed from: h1  reason: collision with root package name */
    public Bundle f1199h1;

    /* renamed from: i1  reason: collision with root package name */
    public final u2 f1200i1;

    /* renamed from: j1  reason: collision with root package name */
    public final u2 f1201j1;

    /* renamed from: k1  reason: collision with root package name */
    public final WeakHashMap f1202k1;

    /* renamed from: p  reason: collision with root package name */
    public final SearchAutoComplete f1203p;

    /* renamed from: p0  reason: collision with root package name */
    public b f1204p0;

    /* renamed from: q  reason: collision with root package name */
    public final View f1205q;

    /* renamed from: r  reason: collision with root package name */
    public final View f1206r;

    /* renamed from: s  reason: collision with root package name */
    public final View f1207s;

    /* renamed from: t  reason: collision with root package name */
    public final ImageView f1208t;

    /* renamed from: u  reason: collision with root package name */
    public final ImageView f1209u;

    /* renamed from: v  reason: collision with root package name */
    public final ImageView f1210v;

    /* renamed from: w  reason: collision with root package name */
    public final ImageView f1211w;

    /* renamed from: x  reason: collision with root package name */
    public final View f1212x;

    /* renamed from: y  reason: collision with root package name */
    public i3 f1213y;

    /* renamed from: z  reason: collision with root package name */
    public final Rect f1214z;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Object();

        /* renamed from: c  reason: collision with root package name */
        public boolean f1215c;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1215c = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        public final String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.f1215c + "}";
        }

        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeParcelable(this.f1896a, i10);
            parcel.writeValue(Boolean.valueOf(this.f1215c));
        }
    }

    public static class SearchAutoComplete extends AppCompatAutoCompleteTextView {

        /* renamed from: e  reason: collision with root package name */
        public int f1216e;

        /* renamed from: f  reason: collision with root package name */
        public SearchView f1217f;

        /* renamed from: g  reason: collision with root package name */
        public boolean f1218g;

        /* renamed from: h  reason: collision with root package name */
        public final h3 f1219h;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, R.attr.autoCompleteTextViewStyle);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i10 = configuration.screenWidthDp;
            int i11 = configuration.screenHeightDp;
            if (i10 >= 960 && i11 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i10 < 600) {
                return (i10 < 640 || i11 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                b3.b(this, 1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            f3 f3Var = SearchView.f1191l1;
            f3Var.getClass();
            f3.a();
            Method method = f3Var.f1337c;
            if (method != null) {
                try {
                    method.invoke(this, new Object[]{Boolean.TRUE});
                } catch (Exception unused) {
                }
            }
        }

        public final boolean enoughToFilter() {
            return this.f1216e <= 0 || super.enoughToFilter();
        }

        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f1218g) {
                h3 h3Var = this.f1219h;
                removeCallbacks(h3Var);
                post(h3Var);
            }
            return onCreateInputConnection;
        }

        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public final void onFocusChanged(boolean z4, int i10, Rect rect) {
            super.onFocusChanged(z4, i10, rect);
            SearchView searchView = this.f1217f;
            searchView.y(searchView.O);
            searchView.post(searchView.f1200i1);
            if (searchView.f1203p.hasFocus()) {
                searchView.n();
            }
        }

        public final boolean onKeyPreIme(int i10, KeyEvent keyEvent) {
            if (i10 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f1217f.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i10, keyEvent);
        }

        public final void onWindowFocusChanged(boolean z4) {
            super.onWindowFocusChanged(z4);
            if (z4 && this.f1217f.hasFocus() && getVisibility() == 0) {
                this.f1218g = true;
                Context context = getContext();
                f3 f3Var = SearchView.f1191l1;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        public final void performCompletion() {
        }

        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z4) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            h3 h3Var = this.f1219h;
            if (!z4) {
                this.f1218g = false;
                removeCallbacks(h3Var);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f1218g = false;
                removeCallbacks(h3Var);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f1218g = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f1217f = searchView;
        }

        public void setThreshold(int i10) {
            super.setThreshold(i10);
            this.f1216e = i10;
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i10) {
            super(context, attributeSet, i10);
            this.f1219h = new h3(this);
            this.f1216e = getThreshold();
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [androidx.appcompat.widget.f3, java.lang.Object] */
    static {
        f3 f3Var = null;
        if (Build.VERSION.SDK_INT < 29) {
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            ? obj = new Object();
            obj.f1335a = null;
            obj.f1336b = null;
            obj.f1337c = null;
            f3.a();
            try {
                Method declaredMethod = cls.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                obj.f1335a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = cls.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                obj.f1336b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                obj.f1337c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            f3Var = obj;
        }
        f1191l1 = f3Var;
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f1203p;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    public final void a() {
        if (!this.f1196e1) {
            this.f1196e1 = true;
            SearchAutoComplete searchAutoComplete = this.f1203p;
            int imeOptions = searchAutoComplete.getImeOptions();
            this.f1197f1 = imeOptions;
            searchAutoComplete.setImeOptions(imeOptions | 33554432);
            searchAutoComplete.setText("");
            setIconified(false);
        }
    }

    public final void clearFocus() {
        this.Z0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f1203p;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.Z0 = false;
    }

    public final void e() {
        SearchAutoComplete searchAutoComplete = this.f1203p;
        searchAutoComplete.setText("");
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f1195d1 = "";
        clearFocus();
        y(true);
        searchAutoComplete.setImeOptions(this.f1197f1);
        this.f1196e1 = false;
    }

    public int getImeOptions() {
        return this.f1203p.getImeOptions();
    }

    public int getInputType() {
        return this.f1203p.getInputType();
    }

    public int getMaxWidth() {
        return this.f1192a1;
    }

    public CharSequence getQuery() {
        return this.f1203p.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.X0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f1198g1;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.J : getContext().getText(this.f1198g1.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.G;
    }

    public int getSuggestionRowLayout() {
        return this.F;
    }

    public b getSuggestionsAdapter() {
        return this.f1204p0;
    }

    public final Intent l(String str, Uri uri, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f1195d1);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f1199h1;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f1198g1.getSearchActivity());
        return intent;
    }

    public final Intent m(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f1199h1;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void n() {
        int i10 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f1203p;
        if (i10 >= 29) {
            b3.a(searchAutoComplete);
            return;
        }
        f3 f3Var = f1191l1;
        f3Var.getClass();
        f3.a();
        Method method = f3Var.f1335a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused) {
            }
        }
        f3Var.getClass();
        f3.a();
        Method method2 = f3Var.f1336b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused2) {
            }
        }
    }

    public final void o() {
        SearchAutoComplete searchAutoComplete = this.f1203p;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText("");
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.N) {
            clearFocus();
            y(true);
        }
    }

    public final void onDetachedFromWindow() {
        removeCallbacks(this.f1200i1);
        post(this.f1201j1);
        super.onDetachedFromWindow();
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        super.onLayout(z4, i10, i11, i12, i13);
        if (z4) {
            int[] iArr = this.B;
            SearchAutoComplete searchAutoComplete = this.f1203p;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.C;
            getLocationInWindow(iArr2);
            int i14 = iArr[1] - iArr2[1];
            int i15 = iArr[0] - iArr2[0];
            Rect rect = this.f1214z;
            rect.set(i15, i14, searchAutoComplete.getWidth() + i15, searchAutoComplete.getHeight() + i14);
            int i16 = rect.left;
            int i17 = rect.right;
            int i18 = i13 - i11;
            Rect rect2 = this.A;
            rect2.set(i16, 0, i17, i18);
            i3 i3Var = this.f1213y;
            if (i3Var == null) {
                i3 i3Var2 = new i3(rect2, rect, searchAutoComplete);
                this.f1213y = i3Var2;
                setTouchDelegate(i3Var2);
                return;
            }
            i3Var.f1364b.set(rect2);
            Rect rect3 = i3Var.f1366d;
            rect3.set(rect2);
            int i19 = -i3Var.f1367e;
            rect3.inset(i19, i19);
            i3Var.f1365c.set(rect);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001d, code lost:
        if (r0 <= 0) goto L_0x0038;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0042  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.O
            if (r0 == 0) goto L_0x0008
            super.onMeasure(r4, r5)
            return
        L_0x0008:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x002e
            if (r0 == 0) goto L_0x0024
            if (r0 == r2) goto L_0x001b
            goto L_0x0038
        L_0x001b:
            int r0 = r3.f1192a1
            if (r0 <= 0) goto L_0x0038
        L_0x001f:
            int r4 = java.lang.Math.min(r0, r4)
            goto L_0x0038
        L_0x0024:
            int r4 = r3.f1192a1
            if (r4 <= 0) goto L_0x0029
            goto L_0x0038
        L_0x0029:
            int r4 = r3.getPreferredWidth()
            goto L_0x0038
        L_0x002e:
            int r0 = r3.f1192a1
            if (r0 <= 0) goto L_0x0033
            goto L_0x001f
        L_0x0033:
            int r0 = r3.getPreferredWidth()
            goto L_0x001f
        L_0x0038:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x004a
            if (r0 == 0) goto L_0x0045
            goto L_0x0052
        L_0x0045:
            int r5 = r3.getPreferredHeight()
            goto L_0x0052
        L_0x004a:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x0052:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1896a);
        y(savedState.f1215c);
        requestLayout();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.os.Parcelable, androidx.customview.view.AbsSavedState, androidx.appcompat.widget.SearchView$SavedState] */
    public final Parcelable onSaveInstanceState() {
        ? absSavedState = new AbsSavedState(super.onSaveInstanceState());
        absSavedState.f1215c = this.O;
        return absSavedState;
    }

    public final void onWindowFocusChanged(boolean z4) {
        super.onWindowFocusChanged(z4);
        post(this.f1200i1);
    }

    public final void p(int i10) {
        int i11;
        Uri uri;
        String q10;
        Cursor cursor = this.f1204p0.f28651c;
        if (cursor != null && cursor.moveToPosition(i10)) {
            Intent intent = null;
            try {
                int i12 = k3.f1388x;
                String q11 = k3.q(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (q11 == null) {
                    q11 = this.f1198g1.getSuggestIntentAction();
                }
                if (q11 == null) {
                    q11 = "android.intent.action.SEARCH";
                }
                String q12 = k3.q(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (q12 == null) {
                    q12 = this.f1198g1.getSuggestIntentData();
                }
                if (!(q12 == null || (q10 = k3.q(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) == null)) {
                    q12 = q12 + "/" + Uri.encode(q10);
                }
                if (q12 == null) {
                    uri = null;
                } else {
                    uri = Uri.parse(q12);
                }
                intent = l(q11, uri, k3.q(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), k3.q(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e10) {
                try {
                    i11 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i11 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i11 + " returned exception.", e10);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e11) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e11);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f1203p;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void q(int i10) {
        String c10;
        Editable text = this.f1203p.getText();
        Cursor cursor = this.f1204p0.f28651c;
        if (cursor != null) {
            if (!cursor.moveToPosition(i10) || (c10 = this.f1204p0.c(cursor)) == null) {
                setQuery(text);
            } else {
                setQuery(c10);
            }
        }
    }

    public final void r(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public final boolean requestFocus(int i10, Rect rect) {
        if (this.Z0 || !isFocusable()) {
            return false;
        }
        if (this.O) {
            return super.requestFocus(i10, rect);
        }
        boolean requestFocus = this.f1203p.requestFocus(i10, rect);
        if (requestFocus) {
            y(false);
        }
        return requestFocus;
    }

    public final void s() {
        SearchAutoComplete searchAutoComplete = this.f1203p;
        Editable text = searchAutoComplete.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            d3 d3Var = this.K;
            if (d3Var == null || !d3Var.onQueryTextSubmit(text.toString())) {
                if (this.f1198g1 != null) {
                    getContext().startActivity(l("android.intent.action.SEARCH", (Uri) null, (String) null, text.toString()));
                }
                searchAutoComplete.setImeVisibility(false);
                searchAutoComplete.dismissDropDown();
            }
        }
    }

    public void setAppSearchData(Bundle bundle) {
        this.f1199h1 = bundle;
    }

    public void setIconified(boolean z4) {
        if (z4) {
            o();
            return;
        }
        y(false);
        SearchAutoComplete searchAutoComplete = this.f1203p;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.M;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z4) {
        if (this.N != z4) {
            this.N = z4;
            y(z4);
            v();
        }
    }

    public void setImeOptions(int i10) {
        this.f1203p.setImeOptions(i10);
    }

    public void setInputType(int i10) {
        this.f1203p.setInputType(i10);
    }

    public void setMaxWidth(int i10) {
        this.f1192a1 = i10;
        requestLayout();
    }

    public void setOnCloseListener(c3 c3Var) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.L = onFocusChangeListener;
    }

    public void setOnQueryTextListener(d3 d3Var) {
        this.K = d3Var;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.M = onClickListener;
    }

    public void setOnSuggestionListener(e3 e3Var) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.X0 = charSequence;
        v();
    }

    public void setQueryRefinementEnabled(boolean z4) {
        int i10;
        this.Y0 = z4;
        b bVar = this.f1204p0;
        if (bVar instanceof k3) {
            k3 k3Var = (k3) bVar;
            if (z4) {
                i10 = 2;
            } else {
                i10 = 1;
            }
            k3Var.f1397p = i10;
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        int i10;
        this.f1198g1 = searchableInfo;
        Intent intent = null;
        boolean z4 = true;
        SearchAutoComplete searchAutoComplete = this.f1203p;
        if (searchableInfo != null) {
            searchAutoComplete.setThreshold(searchableInfo.getSuggestThreshold());
            searchAutoComplete.setImeOptions(this.f1198g1.getImeOptions());
            int inputType = this.f1198g1.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.f1198g1.getSuggestAuthority() != null) {
                    inputType |= 589824;
                }
            }
            searchAutoComplete.setInputType(inputType);
            b bVar = this.f1204p0;
            if (bVar != null) {
                bVar.b((Cursor) null);
            }
            if (this.f1198g1.getSuggestAuthority() != null) {
                k3 k3Var = new k3(getContext(), this, this.f1198g1, this.f1202k1);
                this.f1204p0 = k3Var;
                searchAutoComplete.setAdapter(k3Var);
                k3 k3Var2 = (k3) this.f1204p0;
                if (this.Y0) {
                    i10 = 2;
                } else {
                    i10 = 1;
                }
                k3Var2.f1397p = i10;
            }
            v();
        }
        SearchableInfo searchableInfo2 = this.f1198g1;
        boolean z10 = false;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.f1198g1.getVoiceSearchLaunchWebSearch()) {
                intent = this.H;
            } else if (this.f1198g1.getVoiceSearchLaunchRecognizer()) {
                intent = this.I;
            }
            if (intent != null) {
                if (getContext().getPackageManager().resolveActivity(intent, 65536) == null) {
                    z4 = false;
                }
                z10 = z4;
            }
        }
        this.f1193b1 = z10;
        if (z10) {
            searchAutoComplete.setPrivateImeOptions("nm");
        }
        y(this.O);
    }

    public void setSubmitButtonEnabled(boolean z4) {
        this.W0 = z4;
        y(this.O);
    }

    public void setSuggestionsAdapter(b bVar) {
        this.f1204p0 = bVar;
        this.f1203p.setAdapter(bVar);
    }

    public final void t() {
        boolean z4 = true;
        boolean z10 = !TextUtils.isEmpty(this.f1203p.getText());
        int i10 = 0;
        if (!z10 && (!this.N || this.f1196e1)) {
            z4 = false;
        }
        if (!z4) {
            i10 = 8;
        }
        ImageView imageView = this.f1210v;
        imageView.setVisibility(i10);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(z10 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public final void u() {
        int[] iArr = this.f1203p.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f1206r.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f1207s.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void v() {
        Drawable drawable;
        SpannableStringBuilder queryHint = getQueryHint();
        if (queryHint == null) {
            queryHint = "";
        }
        boolean z4 = this.N;
        SearchAutoComplete searchAutoComplete = this.f1203p;
        if (z4 && (drawable = this.E) != null) {
            int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
            drawable.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public final void w() {
        int i10;
        if ((this.W0 || this.f1193b1) && !this.O && (this.f1209u.getVisibility() == 0 || this.f1211w.getVisibility() == 0)) {
            i10 = 0;
        } else {
            i10 = 8;
        }
        this.f1207s.setVisibility(i10);
    }

    public final void x(boolean z4) {
        int i10;
        boolean z10 = this.W0;
        if (!z10 || ((!z10 && !this.f1193b1) || this.O || !hasFocus() || (!z4 && this.f1193b1))) {
            i10 = 8;
        } else {
            i10 = 0;
        }
        this.f1209u.setVisibility(i10);
    }

    public final void y(boolean z4) {
        int i10;
        int i11;
        int i12;
        this.O = z4;
        int i13 = 8;
        if (z4) {
            i10 = 0;
        } else {
            i10 = 8;
        }
        boolean isEmpty = TextUtils.isEmpty(this.f1203p.getText());
        this.f1208t.setVisibility(i10);
        x(!isEmpty);
        if (z4) {
            i11 = 8;
        } else {
            i11 = 0;
        }
        this.f1205q.setVisibility(i11);
        ImageView imageView = this.D;
        if (imageView.getDrawable() == null || this.N) {
            i12 = 8;
        } else {
            i12 = 0;
        }
        imageView.setVisibility(i12);
        t();
        if (this.f1193b1 && !this.O && isEmpty) {
            this.f1209u.setVisibility(8);
            i13 = 0;
        }
        this.f1211w.setVisibility(i13);
        w();
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SearchView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Context context2 = context;
        this.f1214z = new Rect();
        this.A = new Rect();
        this.B = new int[2];
        this.C = new int[2];
        this.f1200i1 = new u2(this, 0);
        this.f1201j1 = new u2(this, 1);
        this.f1202k1 = new WeakHashMap();
        x2 x2Var = new x2(this);
        y2 y2Var = new y2(this);
        z2 z2Var = new z2(this);
        a3 a3Var = new a3(this, 0);
        a2 a2Var = new a2(1, this);
        t2 t2Var = new t2(this, 0);
        int[] iArr = a.f18941w;
        w wVar = new w(context2, context2.obtainStyledAttributes(attributeSet, iArr, i10, 0));
        w wVar2 = wVar;
        t2 t2Var2 = t2Var;
        h1.q(this, context, iArr, attributeSet, (TypedArray) wVar.f619c, i10);
        LayoutInflater.from(context).inflate(wVar2.B(19, R.layout.abc_search_view), this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f1203p = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f1205q = findViewById(R.id.search_edit_frame);
        View findViewById = findViewById(R.id.search_plate);
        this.f1206r = findViewById;
        View findViewById2 = findViewById(R.id.submit_area);
        this.f1207s = findViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f1208t = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f1209u = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f1210v = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f1211w = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.D = imageView5;
        p0.q(findViewById, wVar2.w(20));
        p0.q(findViewById2, wVar2.w(25));
        imageView.setImageDrawable(wVar2.w(23));
        imageView2.setImageDrawable(wVar2.w(15));
        imageView3.setImageDrawable(wVar2.w(12));
        imageView4.setImageDrawable(wVar2.w(28));
        imageView5.setImageDrawable(wVar2.w(23));
        this.E = wVar2.w(22);
        g.j(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.F = wVar2.B(26, R.layout.abc_search_dropdown_item_icons_2line);
        this.G = wVar2.B(13, 0);
        imageView.setOnClickListener(x2Var);
        imageView3.setOnClickListener(x2Var);
        imageView2.setOnClickListener(x2Var);
        imageView4.setOnClickListener(x2Var);
        searchAutoComplete.setOnClickListener(x2Var);
        searchAutoComplete.addTextChangedListener(t2Var2);
        searchAutoComplete.setOnEditorActionListener(z2Var);
        searchAutoComplete.setOnItemClickListener(a3Var);
        searchAutoComplete.setOnItemSelectedListener(a2Var);
        searchAutoComplete.setOnKeyListener(y2Var);
        searchAutoComplete.setOnFocusChangeListener(new v2(this));
        setIconifiedByDefault(wVar2.r(18, true));
        int v10 = wVar2.v(2, -1);
        if (v10 != -1) {
            setMaxWidth(v10);
        }
        this.J = wVar2.F(14);
        this.X0 = wVar2.F(21);
        int z4 = wVar2.z(6, -1);
        if (z4 != -1) {
            setImeOptions(z4);
        }
        int z10 = wVar2.z(5, -1);
        if (z10 != -1) {
            setInputType(z10);
        }
        setFocusable(wVar2.r(1, true));
        wVar2.N();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.H = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.I = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f1212x = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new w2(0, this));
        }
        y(this.N);
        v();
    }
}
