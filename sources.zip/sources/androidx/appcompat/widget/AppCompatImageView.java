package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

public class AppCompatImageView extends ImageView {

    /* renamed from: a  reason: collision with root package name */
    public final x f1104a;

    /* renamed from: b  reason: collision with root package name */
    public final c0 f1105b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1106c;

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1104a;
        if (xVar != null) {
            xVar.a();
        }
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1104a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1104a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        q3 q3Var;
        c0 c0Var = this.f1105b;
        if (c0Var == null || (q3Var = (q3) c0Var.f1313e) == null) {
            return null;
        }
        return (ColorStateList) q3Var.f1478c;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        q3 q3Var;
        c0 c0Var = this.f1105b;
        if (c0Var == null || (q3Var = (q3) c0Var.f1313e) == null) {
            return null;
        }
        return (PorterDuff.Mode) q3Var.f1479d;
    }

    public final boolean hasOverlappingRendering() {
        if (!(!(((ImageView) this.f1105b.f1311c).getBackground() instanceof RippleDrawable)) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1104a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1104a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        c0 c0Var = this.f1105b;
        if (!(c0Var == null || drawable == null || this.f1106c)) {
            c0Var.f1310b = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (c0Var != null) {
            c0Var.a();
            if (!this.f1106c && ((ImageView) c0Var.f1311c).getDrawable() != null) {
                ((ImageView) c0Var.f1311c).getDrawable().setLevel(c0Var.f1310b);
            }
        }
    }

    public void setImageLevel(int i10) {
        super.setImageLevel(i10);
        this.f1106c = true;
    }

    public void setImageResource(int i10) {
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            c0Var.c(i10);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            c0Var.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1104a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1104a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            if (((q3) c0Var.f1313e) == null) {
                c0Var.f1313e = new Object();
            }
            q3 q3Var = (q3) c0Var.f1313e;
            q3Var.f1478c = colorStateList;
            q3Var.f1477b = true;
            c0Var.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        c0 c0Var = this.f1105b;
        if (c0Var != null) {
            if (((q3) c0Var.f1313e) == null) {
                c0Var.f1313e = new Object();
            }
            q3 q3Var = (q3) c0Var.f1313e;
            q3Var.f1479d = mode;
            q3Var.f1476a = true;
            c0Var.a();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        this.f1106c = false;
        o3.a(getContext(), this);
        x xVar = new x((View) this);
        this.f1104a = xVar;
        xVar.f(attributeSet, i10);
        c0 c0Var = new c0((ImageView) this);
        this.f1105b = c0Var;
        c0Var.b(attributeSet, i10);
    }
}
