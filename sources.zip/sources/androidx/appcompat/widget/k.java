package androidx.appcompat.widget;

import android.view.View;
import m.g0;

public final class k extends x1 {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ int f1377j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ Object f1378k;

    /* renamed from: l  reason: collision with root package name */
    public final /* synthetic */ View f1379l;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ k(View view, View view2, Object obj, int i10) {
        super(view2);
        this.f1377j = i10;
        this.f1379l = view;
        this.f1378k = obj;
    }

    public final g0 b() {
        switch (this.f1377j) {
            case 0:
                h hVar = ((l) this.f1379l).f1405d.f1437t;
                if (hVar == null) {
                    return null;
                }
                return hVar.a();
            default:
                return (n0) this.f1378k;
        }
    }

    public final boolean c() {
        int i10 = this.f1377j;
        View view = this.f1379l;
        switch (i10) {
            case 0:
                ((l) view).f1405d.n();
                return true;
            default:
                AppCompatSpinner appCompatSpinner = (AppCompatSpinner) view;
                if (!appCompatSpinner.getInternalPopup().a()) {
                    appCompatSpinner.f1123f.l(i0.b(appCompatSpinner), i0.a(appCompatSpinner));
                }
                return true;
        }
    }

    public final boolean d() {
        switch (this.f1377j) {
            case 0:
                n nVar = ((l) this.f1379l).f1405d;
                if (nVar.f1439v != null) {
                    return false;
                }
                nVar.c();
                return true;
            default:
                g0 b5 = b();
                if (b5 != null && b5.a()) {
                    b5.dismiss();
                }
                return true;
        }
    }
}
