package androidx.appcompat.widget;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageButton;
import com.blacksquircle.ui.editorkit.widget.internal.LineNumbersEditText;
import com.google.android.material.search.SearchView;
import com.google.android.material.textfield.TextInputLayout;

public final class t2 implements TextWatcher {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1503a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f1504b;

    public /* synthetic */ t2(View view, int i10) {
        this.f1503a = i10;
        this.f1504b = view;
    }

    public final void afterTextChanged(Editable editable) {
        int i10 = this.f1503a;
        View view = this.f1504b;
        switch (i10) {
            case 0:
                return;
            case 1:
                ((LineNumbersEditText) view).b(editable);
                return;
            case 2:
                return;
            default:
                TextInputLayout textInputLayout = (TextInputLayout) view;
                textInputLayout.u(!textInputLayout.C1, false);
                if (textInputLayout.f16895k) {
                    textInputLayout.n(editable);
                }
                if (textInputLayout.f16912s) {
                    textInputLayout.v(editable);
                    return;
                }
                return;
        }
    }

    public final void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        switch (this.f1503a) {
            case 1:
                ((LineNumbersEditText) this.f1504b).c(i10, i11, i12, charSequence);
                return;
            default:
                return;
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        int i13 = 8;
        int i14 = this.f1503a;
        View view = this.f1504b;
        switch (i14) {
            case 0:
                SearchView searchView = (SearchView) view;
                Editable text = searchView.f1203p.getText();
                searchView.f1195d1 = text;
                boolean isEmpty = TextUtils.isEmpty(text);
                searchView.x(!isEmpty);
                if (searchView.f1193b1 && !searchView.O && isEmpty) {
                    searchView.f1209u.setVisibility(8);
                    i13 = 0;
                }
                searchView.f1211w.setVisibility(i13);
                searchView.t();
                searchView.w();
                if (searchView.K != null && !TextUtils.equals(charSequence, searchView.f1194c1)) {
                    searchView.K.onQueryTextChange(charSequence.toString());
                }
                searchView.f1194c1 = charSequence.toString();
                return;
            case 1:
                ((LineNumbersEditText) view).d(i10, i11, i12, charSequence);
                return;
            case 2:
                ImageButton imageButton = ((SearchView) view).f16732k;
                if (charSequence.length() > 0) {
                    i13 = 0;
                }
                imageButton.setVisibility(i13);
                return;
            default:
                return;
        }
    }
}
