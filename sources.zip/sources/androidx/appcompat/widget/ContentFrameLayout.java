package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import h.a0;
import h.o0;
import m.o;
import r1.u1;

public class ContentFrameLayout extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    public TypedValue f1140a;

    /* renamed from: b  reason: collision with root package name */
    public TypedValue f1141b;

    /* renamed from: c  reason: collision with root package name */
    public TypedValue f1142c;

    /* renamed from: d  reason: collision with root package name */
    public TypedValue f1143d;

    /* renamed from: e  reason: collision with root package name */
    public TypedValue f1144e;

    /* renamed from: f  reason: collision with root package name */
    public TypedValue f1145f;

    /* renamed from: g  reason: collision with root package name */
    public final Rect f1146g;

    /* renamed from: h  reason: collision with root package name */
    public j1 f1147h;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f1144e == null) {
            this.f1144e = new TypedValue();
        }
        return this.f1144e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f1145f == null) {
            this.f1145f = new TypedValue();
        }
        return this.f1145f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f1142c == null) {
            this.f1142c = new TypedValue();
        }
        return this.f1142c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f1143d == null) {
            this.f1143d = new TypedValue();
        }
        return this.f1143d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f1140a == null) {
            this.f1140a = new TypedValue();
        }
        return this.f1140a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f1141b == null) {
            this.f1141b = new TypedValue();
        }
        return this.f1141b;
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        j1 j1Var = this.f1147h;
        if (j1Var != null) {
            j1Var.getClass();
        }
    }

    public final void onDetachedFromWindow() {
        n nVar;
        super.onDetachedFromWindow();
        j1 j1Var = this.f1147h;
        if (j1Var != null) {
            o0 o0Var = (o0) ((a0) j1Var).f19253a;
            k1 k1Var = o0Var.f19432r;
            if (k1Var != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) k1Var;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((y3) actionBarOverlayLayout.f1034e).f1570a.f1247a;
                if (!(actionMenuView == null || (nVar = actionMenuView.f1061t) == null)) {
                    nVar.c();
                    h hVar = nVar.f1438u;
                    if (hVar != null && hVar.b()) {
                        hVar.f22213j.dismiss();
                    }
                }
            }
            if (o0Var.f19437w != null) {
                o0Var.f19425l.getDecorView().removeCallbacks(o0Var.f19438x);
                if (o0Var.f19437w.isShowing()) {
                    try {
                        o0Var.f19437w.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                o0Var.f19437w = null;
            }
            u1 u1Var = o0Var.f19439y;
            if (u1Var != null) {
                u1Var.b();
            }
            o oVar = o0Var.B(0).f19372h;
            if (oVar != null) {
                oVar.c(true);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x004e  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0067  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x008a  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00bd  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00d1  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00d9  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:60:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onMeasure(int r17, int r18) {
        /*
            r16 = this;
            r0 = r16
            android.content.Context r1 = r16.getContext()
            android.content.res.Resources r1 = r1.getResources()
            android.util.DisplayMetrics r1 = r1.getDisplayMetrics()
            int r2 = r1.widthPixels
            int r3 = r1.heightPixels
            r4 = 1
            r5 = 0
            if (r2 >= r3) goto L_0x0018
            r2 = 1
            goto L_0x0019
        L_0x0018:
            r2 = 0
        L_0x0019:
            int r3 = android.view.View.MeasureSpec.getMode(r17)
            int r6 = android.view.View.MeasureSpec.getMode(r18)
            android.graphics.Rect r7 = r0.f1146g
            r8 = 6
            r9 = 5
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            r11 = 1073741824(0x40000000, float:2.0)
            if (r3 != r10) goto L_0x0062
            if (r2 == 0) goto L_0x0030
            android.util.TypedValue r12 = r0.f1143d
            goto L_0x0032
        L_0x0030:
            android.util.TypedValue r12 = r0.f1142c
        L_0x0032:
            if (r12 == 0) goto L_0x0062
            int r13 = r12.type
            if (r13 == 0) goto L_0x0062
            if (r13 != r9) goto L_0x0040
            float r12 = r12.getDimension(r1)
        L_0x003e:
            int r12 = (int) r12
            goto L_0x004c
        L_0x0040:
            if (r13 != r8) goto L_0x004b
            int r13 = r1.widthPixels
            float r14 = (float) r13
            float r13 = (float) r13
            float r12 = r12.getFraction(r14, r13)
            goto L_0x003e
        L_0x004b:
            r12 = 0
        L_0x004c:
            if (r12 <= 0) goto L_0x0062
            int r13 = r7.left
            int r14 = r7.right
            int r13 = r13 + r14
            int r12 = r12 - r13
            int r13 = android.view.View.MeasureSpec.getSize(r17)
            int r12 = java.lang.Math.min(r12, r13)
            int r12 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r11)
            r13 = 1
            goto L_0x0065
        L_0x0062:
            r12 = r17
            r13 = 0
        L_0x0065:
            if (r6 != r10) goto L_0x009d
            if (r2 == 0) goto L_0x006c
            android.util.TypedValue r6 = r0.f1144e
            goto L_0x006e
        L_0x006c:
            android.util.TypedValue r6 = r0.f1145f
        L_0x006e:
            if (r6 == 0) goto L_0x009d
            int r14 = r6.type
            if (r14 == 0) goto L_0x009d
            if (r14 != r9) goto L_0x007c
            float r6 = r6.getDimension(r1)
        L_0x007a:
            int r6 = (int) r6
            goto L_0x0088
        L_0x007c:
            if (r14 != r8) goto L_0x0087
            int r14 = r1.heightPixels
            float r15 = (float) r14
            float r14 = (float) r14
            float r6 = r6.getFraction(r15, r14)
            goto L_0x007a
        L_0x0087:
            r6 = 0
        L_0x0088:
            if (r6 <= 0) goto L_0x009d
            int r14 = r7.top
            int r15 = r7.bottom
            int r14 = r14 + r15
            int r6 = r6 - r14
            int r14 = android.view.View.MeasureSpec.getSize(r18)
            int r6 = java.lang.Math.min(r6, r14)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r11)
            goto L_0x009f
        L_0x009d:
            r6 = r18
        L_0x009f:
            super.onMeasure(r12, r6)
            int r12 = r16.getMeasuredWidth()
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r11)
            if (r13 != 0) goto L_0x00de
            if (r3 != r10) goto L_0x00de
            if (r2 == 0) goto L_0x00b3
            android.util.TypedValue r2 = r0.f1141b
            goto L_0x00b5
        L_0x00b3:
            android.util.TypedValue r2 = r0.f1140a
        L_0x00b5:
            if (r2 == 0) goto L_0x00de
            int r3 = r2.type
            if (r3 == 0) goto L_0x00de
            if (r3 != r9) goto L_0x00c3
            float r1 = r2.getDimension(r1)
        L_0x00c1:
            int r1 = (int) r1
            goto L_0x00cf
        L_0x00c3:
            if (r3 != r8) goto L_0x00ce
            int r1 = r1.widthPixels
            float r3 = (float) r1
            float r1 = (float) r1
            float r1 = r2.getFraction(r3, r1)
            goto L_0x00c1
        L_0x00ce:
            r1 = 0
        L_0x00cf:
            if (r1 <= 0) goto L_0x00d7
            int r2 = r7.left
            int r3 = r7.right
            int r2 = r2 + r3
            int r1 = r1 - r2
        L_0x00d7:
            if (r12 >= r1) goto L_0x00de
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r11)
            goto L_0x00df
        L_0x00de:
            r4 = 0
        L_0x00df:
            if (r4 == 0) goto L_0x00e4
            super.onMeasure(r14, r6)
        L_0x00e4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(j1 j1Var) {
        this.f1147h = j1Var;
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1146g = new Rect();
    }
}
