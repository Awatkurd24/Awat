package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import g.a;
import r1.h1;

public class LinearLayoutCompat extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1150a;

    /* renamed from: b  reason: collision with root package name */
    public int f1151b;

    /* renamed from: c  reason: collision with root package name */
    public int f1152c;

    /* renamed from: d  reason: collision with root package name */
    public int f1153d;

    /* renamed from: e  reason: collision with root package name */
    public int f1154e;

    /* renamed from: f  reason: collision with root package name */
    public int f1155f;

    /* renamed from: g  reason: collision with root package name */
    public float f1156g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1157h;

    /* renamed from: i  reason: collision with root package name */
    public int[] f1158i;

    /* renamed from: j  reason: collision with root package name */
    public int[] f1159j;

    /* renamed from: k  reason: collision with root package name */
    public Drawable f1160k;

    /* renamed from: l  reason: collision with root package name */
    public int f1161l;

    /* renamed from: m  reason: collision with root package name */
    public int f1162m;

    /* renamed from: n  reason: collision with root package name */
    public int f1163n;

    /* renamed from: o  reason: collision with root package name */
    public int f1164o;

    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof y1;
    }

    public final void f(Canvas canvas, int i10) {
        this.f1160k.setBounds(getPaddingLeft() + this.f1164o, i10, (getWidth() - getPaddingRight()) - this.f1164o, this.f1162m + i10);
        this.f1160k.draw(canvas);
    }

    public final void g(Canvas canvas, int i10) {
        this.f1160k.setBounds(i10, getPaddingTop() + this.f1164o, this.f1161l + i10, (getHeight() - getPaddingBottom()) - this.f1164o);
        this.f1160k.draw(canvas);
    }

    public int getBaseline() {
        int i10;
        if (this.f1151b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i11 = this.f1151b;
        if (childCount > i11) {
            View childAt = getChildAt(i11);
            int baseline = childAt.getBaseline();
            if (baseline != -1) {
                int i12 = this.f1152c;
                if (this.f1153d == 1 && (i10 = this.f1154e & 112) != 48) {
                    if (i10 == 16) {
                        i12 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f1155f) / 2;
                    } else if (i10 == 80) {
                        i12 = ((getBottom() - getTop()) - getPaddingBottom()) - this.f1155f;
                    }
                }
                return i12 + ((y1) childAt.getLayoutParams()).topMargin + baseline;
            } else if (this.f1151b == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.f1151b;
    }

    public Drawable getDividerDrawable() {
        return this.f1160k;
    }

    public int getDividerPadding() {
        return this.f1164o;
    }

    public int getDividerWidth() {
        return this.f1161l;
    }

    public int getGravity() {
        return this.f1154e;
    }

    public int getOrientation() {
        return this.f1153d;
    }

    public int getShowDividers() {
        return this.f1163n;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f1156g;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [android.widget.LinearLayout$LayoutParams, androidx.appcompat.widget.y1] */
    /* JADX WARNING: type inference failed for: r0v3, types: [android.widget.LinearLayout$LayoutParams, androidx.appcompat.widget.y1] */
    /* renamed from: h */
    public y1 generateDefaultLayoutParams() {
        int i10 = this.f1153d;
        if (i10 == 0) {
            return new LinearLayout.LayoutParams(-2, -2);
        }
        if (i10 == 1) {
            return new LinearLayout.LayoutParams(-1, -2);
        }
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.LinearLayout$LayoutParams, androidx.appcompat.widget.y1] */
    /* renamed from: i */
    public y1 generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.LinearLayout$LayoutParams, androidx.appcompat.widget.y1] */
    /* renamed from: j */
    public y1 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LinearLayout.LayoutParams(layoutParams);
    }

    public final boolean k(int i10) {
        if (i10 == 0) {
            return (this.f1163n & 1) != 0;
        }
        if (i10 == getChildCount()) {
            return (this.f1163n & 4) != 0;
        }
        if ((this.f1163n & 2) == 0) {
            return false;
        }
        for (int i11 = i10 - 1; i11 >= 0; i11--) {
            if (getChildAt(i11).getVisibility() != 8) {
                return true;
            }
        }
        return false;
    }

    public final void onDraw(Canvas canvas) {
        int i10;
        int left;
        int i11;
        int i12;
        int i13;
        if (this.f1160k != null) {
            int i14 = 0;
            if (this.f1153d == 1) {
                int virtualChildCount = getVirtualChildCount();
                while (i14 < virtualChildCount) {
                    View childAt = getChildAt(i14);
                    if (!(childAt == null || childAt.getVisibility() == 8 || !k(i14))) {
                        f(canvas, (childAt.getTop() - ((y1) childAt.getLayoutParams()).topMargin) - this.f1162m);
                    }
                    i14++;
                }
                if (k(virtualChildCount)) {
                    View childAt2 = getChildAt(virtualChildCount - 1);
                    if (childAt2 == null) {
                        i13 = (getHeight() - getPaddingBottom()) - this.f1162m;
                    } else {
                        i13 = childAt2.getBottom() + ((y1) childAt2.getLayoutParams()).bottomMargin;
                    }
                    f(canvas, i13);
                    return;
                }
                return;
            }
            int virtualChildCount2 = getVirtualChildCount();
            boolean a10 = f4.a(this);
            while (i14 < virtualChildCount2) {
                View childAt3 = getChildAt(i14);
                if (!(childAt3 == null || childAt3.getVisibility() == 8 || !k(i14))) {
                    y1 y1Var = (y1) childAt3.getLayoutParams();
                    if (a10) {
                        i12 = childAt3.getRight() + y1Var.rightMargin;
                    } else {
                        i12 = (childAt3.getLeft() - y1Var.leftMargin) - this.f1161l;
                    }
                    g(canvas, i12);
                }
                i14++;
            }
            if (k(virtualChildCount2)) {
                View childAt4 = getChildAt(virtualChildCount2 - 1);
                if (childAt4 != null) {
                    y1 y1Var2 = (y1) childAt4.getLayoutParams();
                    if (a10) {
                        left = childAt4.getLeft();
                        i11 = y1Var2.leftMargin;
                    } else {
                        i10 = childAt4.getRight() + y1Var2.rightMargin;
                        g(canvas, i10);
                    }
                } else if (a10) {
                    i10 = getPaddingLeft();
                    g(canvas, i10);
                } else {
                    left = getWidth();
                    i11 = getPaddingRight();
                }
                i10 = (left - i11) - this.f1161l;
                g(canvas, i10);
            }
        }
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0099  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0153  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x015c  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x018e  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x01a2  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r24, int r25, int r26, int r27, int r28) {
        /*
            r23 = this;
            r0 = r23
            int r1 = r0.f1153d
            r2 = 5
            r3 = 8
            r5 = 80
            r6 = 2
            r7 = 16
            r8 = 8388615(0x800007, float:1.1754953E-38)
            r9 = 1
            if (r1 != r9) goto L_0x00b0
            int r1 = r23.getPaddingLeft()
            int r10 = r27 - r25
            int r11 = r23.getPaddingRight()
            int r11 = r10 - r11
            int r10 = r10 - r1
            int r12 = r23.getPaddingRight()
            int r10 = r10 - r12
            int r12 = r23.getVirtualChildCount()
            int r13 = r0.f1154e
            r14 = r13 & 112(0x70, float:1.57E-43)
            r8 = r8 & r13
            if (r14 == r7) goto L_0x0042
            if (r14 == r5) goto L_0x0036
            int r5 = r23.getPaddingTop()
            goto L_0x004d
        L_0x0036:
            int r5 = r23.getPaddingTop()
            int r5 = r5 + r28
            int r5 = r5 - r26
            int r7 = r0.f1155f
            int r5 = r5 - r7
            goto L_0x004d
        L_0x0042:
            int r5 = r23.getPaddingTop()
            int r7 = r28 - r26
            int r13 = r0.f1155f
            int r7 = r7 - r13
            int r7 = r7 / r6
            int r5 = r5 + r7
        L_0x004d:
            r4 = 0
        L_0x004e:
            if (r4 >= r12) goto L_0x01c4
            android.view.View r7 = r0.getChildAt(r4)
            if (r7 != 0) goto L_0x0057
            goto L_0x00aa
        L_0x0057:
            int r13 = r7.getVisibility()
            if (r13 == r3) goto L_0x00aa
            int r13 = r7.getMeasuredWidth()
            int r14 = r7.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r15 = r7.getLayoutParams()
            androidx.appcompat.widget.y1 r15 = (androidx.appcompat.widget.y1) r15
            int r3 = r15.gravity
            if (r3 >= 0) goto L_0x0070
            r3 = r8
        L_0x0070:
            java.util.WeakHashMap r16 = r1.h1.f25195a
            int r6 = r1.q0.d(r23)
            int r3 = android.view.Gravity.getAbsoluteGravity(r3, r6)
            r3 = r3 & 7
            if (r3 == r9) goto L_0x008a
            if (r3 == r2) goto L_0x0084
            int r3 = r15.leftMargin
            int r3 = r3 + r1
            goto L_0x0093
        L_0x0084:
            int r3 = r11 - r13
        L_0x0086:
            int r6 = r15.rightMargin
            int r3 = r3 - r6
            goto L_0x0093
        L_0x008a:
            int r3 = r10 - r13
            r6 = 2
            int r3 = r3 / r6
            int r3 = r3 + r1
            int r6 = r15.leftMargin
            int r3 = r3 + r6
            goto L_0x0086
        L_0x0093:
            boolean r6 = r0.k(r4)
            if (r6 == 0) goto L_0x009c
            int r6 = r0.f1162m
            int r5 = r5 + r6
        L_0x009c:
            int r6 = r15.topMargin
            int r5 = r5 + r6
            int r13 = r13 + r3
            int r6 = r5 + r14
            r7.layout(r3, r5, r13, r6)
            int r3 = r15.bottomMargin
            int r14 = r14 + r3
            int r14 = r14 + r5
            r5 = r14
        L_0x00aa:
            int r4 = r4 + 1
            r3 = 8
            r6 = 2
            goto L_0x004e
        L_0x00b0:
            boolean r1 = androidx.appcompat.widget.f4.a(r23)
            int r3 = r23.getPaddingTop()
            int r6 = r28 - r26
            int r10 = r23.getPaddingBottom()
            int r10 = r6 - r10
            int r6 = r6 - r3
            int r11 = r23.getPaddingBottom()
            int r6 = r6 - r11
            int r11 = r23.getVirtualChildCount()
            int r12 = r0.f1154e
            r8 = r8 & r12
            r12 = r12 & 112(0x70, float:1.57E-43)
            boolean r13 = r0.f1150a
            int[] r14 = r0.f1158i
            int[] r15 = r0.f1159j
            java.util.WeakHashMap r17 = r1.h1.f25195a
            int r4 = r1.q0.d(r23)
            int r4 = android.view.Gravity.getAbsoluteGravity(r8, r4)
            if (r4 == r9) goto L_0x00f4
            if (r4 == r2) goto L_0x00e8
            int r2 = r23.getPaddingLeft()
            goto L_0x0100
        L_0x00e8:
            int r2 = r23.getPaddingLeft()
            int r2 = r2 + r27
            int r2 = r2 - r25
            int r4 = r0.f1155f
            int r2 = r2 - r4
            goto L_0x0100
        L_0x00f4:
            int r2 = r23.getPaddingLeft()
            int r4 = r27 - r25
            int r8 = r0.f1155f
            int r4 = r4 - r8
            r8 = 2
            int r4 = r4 / r8
            int r2 = r2 + r4
        L_0x0100:
            if (r1 == 0) goto L_0x0106
            int r1 = r11 + -1
            r8 = -1
            goto L_0x0108
        L_0x0106:
            r1 = 0
            r8 = 1
        L_0x0108:
            r9 = 0
        L_0x0109:
            if (r9 >= r11) goto L_0x01c4
            int r18 = r8 * r9
            int r5 = r18 + r1
            android.view.View r7 = r0.getChildAt(r5)
            if (r7 != 0) goto L_0x0122
            r26 = r1
        L_0x0117:
            r27 = r8
            r28 = r11
            r20 = r12
            r12 = -1
            r17 = 1
            goto L_0x01b4
        L_0x0122:
            int r4 = r7.getVisibility()
            r26 = r1
            r1 = 8
            if (r4 == r1) goto L_0x0117
            int r4 = r7.getMeasuredWidth()
            int r19 = r7.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r20 = r7.getLayoutParams()
            r1 = r20
            androidx.appcompat.widget.y1 r1 = (androidx.appcompat.widget.y1) r1
            r27 = r8
            if (r13 == 0) goto L_0x014c
            int r8 = r1.height
            r28 = r11
            r11 = -1
            if (r8 == r11) goto L_0x014e
            int r11 = r7.getBaseline()
            goto L_0x014f
        L_0x014c:
            r28 = r11
        L_0x014e:
            r11 = -1
        L_0x014f:
            int r8 = r1.gravity
            if (r8 >= 0) goto L_0x0154
            r8 = r12
        L_0x0154:
            r8 = r8 & 112(0x70, float:1.57E-43)
            r20 = r12
            r12 = 16
            if (r8 == r12) goto L_0x018e
            r12 = 48
            if (r8 == r12) goto L_0x017f
            r12 = 80
            if (r8 == r12) goto L_0x0169
            r8 = r3
            r12 = -1
        L_0x0166:
            r17 = 1
            goto L_0x019c
        L_0x0169:
            int r8 = r10 - r19
            int r12 = r1.bottomMargin
            int r8 = r8 - r12
            r12 = -1
            if (r11 == r12) goto L_0x0166
            int r21 = r7.getMeasuredHeight()
            int r21 = r21 - r11
            r11 = 2
            r22 = r15[r11]
            int r22 = r22 - r21
            int r8 = r8 - r22
            goto L_0x0166
        L_0x017f:
            r12 = -1
            int r8 = r1.topMargin
            int r8 = r8 + r3
            if (r11 == r12) goto L_0x0166
            r17 = 1
            r21 = r14[r17]
            int r21 = r21 - r11
            int r8 = r21 + r8
            goto L_0x019c
        L_0x018e:
            r12 = -1
            r17 = 1
            int r8 = r6 - r19
            r11 = 2
            int r8 = r8 / r11
            int r8 = r8 + r3
            int r11 = r1.topMargin
            int r8 = r8 + r11
            int r11 = r1.bottomMargin
            int r8 = r8 - r11
        L_0x019c:
            boolean r5 = r0.k(r5)
            if (r5 == 0) goto L_0x01a5
            int r5 = r0.f1161l
            int r2 = r2 + r5
        L_0x01a5:
            int r5 = r1.leftMargin
            int r2 = r2 + r5
            int r5 = r2 + r4
            int r11 = r8 + r19
            r7.layout(r2, r8, r5, r11)
            int r1 = r1.rightMargin
            int r4 = r4 + r1
            int r4 = r4 + r2
            r2 = r4
        L_0x01b4:
            int r9 = r9 + 1
            r1 = r26
            r8 = r27
            r11 = r28
            r12 = r20
            r5 = 80
            r7 = 16
            goto L_0x0109
        L_0x01c4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.LinearLayoutCompat.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:124:0x029c, code lost:
        if (r15 > 0) goto L_0x02a0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x02b0, code lost:
        if (r15 >= 0) goto L_0x02a0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x02d8, code lost:
        if (r13.width == -1) goto L_0x02df;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:314:0x06fc, code lost:
        if (r9 > 0) goto L_0x0700;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:319:0x0710, code lost:
        if (r9 >= 0) goto L_0x0700;
     */
    /* JADX WARNING: Removed duplicated region for block: B:201:0x047c  */
    /* JADX WARNING: Removed duplicated region for block: B:202:0x0481  */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x04a9  */
    /* JADX WARNING: Removed duplicated region for block: B:206:0x04ae  */
    /* JADX WARNING: Removed duplicated region for block: B:209:0x04b8  */
    /* JADX WARNING: Removed duplicated region for block: B:210:0x04c2  */
    /* JADX WARNING: Removed duplicated region for block: B:212:0x04d2  */
    /* JADX WARNING: Removed duplicated region for block: B:217:0x04e1  */
    /* JADX WARNING: Removed duplicated region for block: B:218:0x04e5  */
    /* JADX WARNING: Removed duplicated region for block: B:223:0x0501  */
    /* JADX WARNING: Removed duplicated region for block: B:228:0x052a  */
    /* JADX WARNING: Removed duplicated region for block: B:233:0x0538  */
    /* JADX WARNING: Removed duplicated region for block: B:234:0x053a  */
    /* JADX WARNING: Removed duplicated region for block: B:237:0x0542  */
    /* JADX WARNING: Removed duplicated region for block: B:240:0x054d  */
    /* JADX WARNING: Removed duplicated region for block: B:267:0x05d6  */
    /* JADX WARNING: Removed duplicated region for block: B:300:0x0687  */
    /* JADX WARNING: Removed duplicated region for block: B:303:0x06a3  */
    /* JADX WARNING: Removed duplicated region for block: B:344:0x078e  */
    /* JADX WARNING: Removed duplicated region for block: B:348:0x07b2  */
    /* JADX WARNING: Removed duplicated region for block: B:357:0x07e5  */
    /* JADX WARNING: Removed duplicated region for block: B:360:0x07ed  */
    /* JADX WARNING: Removed duplicated region for block: B:369:0x0847  */
    /* JADX WARNING: Removed duplicated region for block: B:419:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r38, int r39) {
        /*
            r37 = this;
            r6 = r37
            r7 = r38
            r8 = r39
            int r0 = r6.f1153d
            r10 = -2
            r11 = 1073741824(0x40000000, float:2.0)
            r12 = 8
            r14 = -2147483648(0xffffffff80000000, float:-0.0)
            r15 = 0
            r5 = 0
            r4 = 1
            if (r0 != r4) goto L_0x0379
            r6.f1155f = r5
            int r3 = r37.getVirtualChildCount()
            int r2 = android.view.View.MeasureSpec.getMode(r38)
            int r1 = android.view.View.MeasureSpec.getMode(r39)
            int r0 = r6.f1151b
            boolean r9 = r6.f1157h
            r13 = 0
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            r24 = 1
            r25 = 0
        L_0x0039:
            if (r13 >= r3) goto L_0x0173
            android.view.View r26 = r6.getChildAt(r13)
            if (r26 != 0) goto L_0x0051
            int r4 = r6.f1155f
            r6.f1155f = r4
        L_0x0045:
            r10 = r0
            r29 = r1
            r1 = r2
            r31 = r3
            r3 = r22
            r27 = 1
            goto L_0x015d
        L_0x0051:
            int r4 = r26.getVisibility()
            if (r4 != r12) goto L_0x0058
            goto L_0x0045
        L_0x0058:
            boolean r4 = r6.k(r13)
            if (r4 == 0) goto L_0x0065
            int r4 = r6.f1155f
            int r5 = r6.f1162m
            int r4 = r4 + r5
            r6.f1155f = r4
        L_0x0065:
            android.view.ViewGroup$LayoutParams r4 = r26.getLayoutParams()
            r5 = r4
            androidx.appcompat.widget.y1 r5 = (androidx.appcompat.widget.y1) r5
            float r4 = r5.weight
            float r17 = r17 + r4
            if (r1 != r11) goto L_0x0094
            int r12 = r5.height
            if (r12 != 0) goto L_0x0094
            int r12 = (r4 > r15 ? 1 : (r4 == r15 ? 0 : -1))
            if (r12 <= 0) goto L_0x0094
            int r4 = r6.f1155f
            int r12 = r5.topMargin
            int r12 = r12 + r4
            int r11 = r5.bottomMargin
            int r12 = r12 + r11
            int r4 = java.lang.Math.max(r4, r12)
            r6.f1155f = r4
            r10 = r0
            r29 = r1
            r30 = r2
            r31 = r3
            r15 = r5
            r4 = 1
            r27 = 1
            goto L_0x00e5
        L_0x0094:
            int r11 = r5.height
            if (r11 != 0) goto L_0x00a0
            int r4 = (r4 > r15 ? 1 : (r4 == r15 ? 0 : -1))
            if (r4 <= 0) goto L_0x00a0
            r5.height = r10
            r11 = 0
            goto L_0x00a2
        L_0x00a0:
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00a2:
            r4 = 0
            int r12 = (r17 > r15 ? 1 : (r17 == r15 ? 0 : -1))
            if (r12 != 0) goto L_0x00ab
            int r12 = r6.f1155f
            r10 = r0
            goto L_0x00ad
        L_0x00ab:
            r10 = r0
            r12 = 0
        L_0x00ad:
            r0 = r37
            r29 = r1
            r1 = r26
            r30 = r2
            r2 = r38
            r31 = r3
            r3 = r4
            r27 = 1
            r4 = r39
            r15 = r5
            r5 = r12
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            if (r11 == r14) goto L_0x00c7
            r15.height = r11
        L_0x00c7:
            int r0 = r26.getMeasuredHeight()
            int r1 = r6.f1155f
            int r2 = r1 + r0
            int r3 = r15.topMargin
            int r2 = r2 + r3
            int r3 = r15.bottomMargin
            int r2 = r2 + r3
            int r1 = java.lang.Math.max(r1, r2)
            r6.f1155f = r1
            r5 = r21
            if (r9 == 0) goto L_0x00e3
            int r21 = java.lang.Math.max(r0, r5)
        L_0x00e3:
            r4 = r20
        L_0x00e5:
            if (r10 < 0) goto L_0x00ef
            int r0 = r13 + 1
            if (r10 != r0) goto L_0x00ef
            int r0 = r6.f1155f
            r6.f1152c = r0
        L_0x00ef:
            if (r13 >= r10) goto L_0x00f8
            float r0 = r15.weight
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L_0x00fd
        L_0x00f8:
            r1 = r30
            r0 = 1073741824(0x40000000, float:2.0)
            goto L_0x0105
        L_0x00fd:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r0.<init>(r1)
            throw r0
        L_0x0105:
            if (r1 == r0) goto L_0x0110
            int r0 = r15.width
            r2 = -1
            if (r0 != r2) goto L_0x0110
            r5 = 1
            r25 = 1
            goto L_0x0111
        L_0x0110:
            r5 = 0
        L_0x0111:
            int r0 = r15.leftMargin
            int r2 = r15.rightMargin
            int r0 = r0 + r2
            int r2 = r26.getMeasuredWidth()
            int r2 = r2 + r0
            r3 = r22
            int r3 = java.lang.Math.max(r3, r2)
            int r11 = r26.getMeasuredState()
            r12 = r23
            int r11 = android.view.View.combineMeasuredStates(r12, r11)
            if (r24 == 0) goto L_0x0134
            int r12 = r15.width
            r14 = -1
            if (r12 != r14) goto L_0x0134
            r12 = 1
            goto L_0x0135
        L_0x0134:
            r12 = 0
        L_0x0135:
            float r14 = r15.weight
            r15 = 0
            int r14 = (r14 > r15 ? 1 : (r14 == r15 ? 0 : -1))
            if (r14 <= 0) goto L_0x0148
            if (r5 == 0) goto L_0x0141
        L_0x013e:
            r14 = r19
            goto L_0x0143
        L_0x0141:
            r0 = r2
            goto L_0x013e
        L_0x0143:
            int r19 = java.lang.Math.max(r14, r0)
            goto L_0x0157
        L_0x0148:
            r14 = r19
            if (r5 == 0) goto L_0x014f
        L_0x014c:
            r2 = r18
            goto L_0x0151
        L_0x014f:
            r0 = r2
            goto L_0x014c
        L_0x0151:
            int r18 = java.lang.Math.max(r2, r0)
            r19 = r14
        L_0x0157:
            r20 = r4
            r23 = r11
            r24 = r12
        L_0x015d:
            int r13 = r13 + 1
            r2 = r1
            r22 = r3
            r0 = r10
            r1 = r29
            r3 = r31
            r4 = 1
            r5 = 0
            r10 = -2
            r11 = 1073741824(0x40000000, float:2.0)
            r12 = 8
            r14 = -2147483648(0xffffffff80000000, float:-0.0)
            r15 = 0
            goto L_0x0039
        L_0x0173:
            r29 = r1
            r1 = r2
            r31 = r3
            r2 = r18
            r14 = r19
            r5 = r21
            r3 = r22
            r12 = r23
            r27 = 1
            int r0 = r6.f1155f
            r10 = r31
            if (r0 <= 0) goto L_0x0197
            boolean r0 = r6.k(r10)
            if (r0 == 0) goto L_0x0197
            int r0 = r6.f1155f
            int r4 = r6.f1162m
            int r0 = r0 + r4
            r6.f1155f = r0
        L_0x0197:
            r4 = r29
            if (r9 == 0) goto L_0x01d7
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r4 == r0) goto L_0x01a1
            if (r4 != 0) goto L_0x01d7
        L_0x01a1:
            r11 = 0
            r6.f1155f = r11
            r0 = 0
        L_0x01a5:
            if (r0 >= r10) goto L_0x01d7
            android.view.View r13 = r6.getChildAt(r0)
            if (r13 != 0) goto L_0x01b2
            int r13 = r6.f1155f
            r6.f1155f = r13
            goto L_0x01d3
        L_0x01b2:
            int r15 = r13.getVisibility()
            r11 = 8
            if (r15 != r11) goto L_0x01bb
            goto L_0x01d3
        L_0x01bb:
            android.view.ViewGroup$LayoutParams r11 = r13.getLayoutParams()
            androidx.appcompat.widget.y1 r11 = (androidx.appcompat.widget.y1) r11
            int r13 = r6.f1155f
            int r21 = r13 + r5
            int r15 = r11.topMargin
            int r21 = r21 + r15
            int r11 = r11.bottomMargin
            int r11 = r21 + r11
            int r11 = java.lang.Math.max(r13, r11)
            r6.f1155f = r11
        L_0x01d3:
            int r0 = r0 + 1
            r11 = 0
            goto L_0x01a5
        L_0x01d7:
            int r0 = r6.f1155f
            int r11 = r37.getPaddingTop()
            int r13 = r37.getPaddingBottom()
            int r13 = r13 + r11
            int r13 = r13 + r0
            r6.f1155f = r13
            int r0 = r37.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r13, r0)
            r11 = 0
            int r0 = android.view.View.resolveSizeAndState(r0, r8, r11)
            r11 = 16777215(0xffffff, float:2.3509886E-38)
            r11 = r11 & r0
            int r13 = r6.f1155f
            int r11 = r11 - r13
            if (r20 != 0) goto L_0x0244
            if (r11 == 0) goto L_0x0203
            r13 = 0
            int r15 = (r17 > r13 ? 1 : (r17 == r13 ? 0 : -1))
            if (r15 <= 0) goto L_0x0203
            goto L_0x0244
        L_0x0203:
            int r2 = java.lang.Math.max(r2, r14)
            if (r9 == 0) goto L_0x0240
            r9 = 1073741824(0x40000000, float:2.0)
            if (r4 == r9) goto L_0x0240
            r4 = 0
        L_0x020e:
            if (r4 >= r10) goto L_0x0240
            android.view.View r9 = r6.getChildAt(r4)
            if (r9 == 0) goto L_0x023d
            int r11 = r9.getVisibility()
            r13 = 8
            if (r11 != r13) goto L_0x021f
            goto L_0x023d
        L_0x021f:
            android.view.ViewGroup$LayoutParams r11 = r9.getLayoutParams()
            androidx.appcompat.widget.y1 r11 = (androidx.appcompat.widget.y1) r11
            float r11 = r11.weight
            r13 = 0
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 <= 0) goto L_0x023d
            int r11 = r9.getMeasuredWidth()
            r13 = 1073741824(0x40000000, float:2.0)
            int r11 = android.view.View.MeasureSpec.makeMeasureSpec(r11, r13)
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r13)
            r9.measure(r11, r14)
        L_0x023d:
            int r4 = r4 + 1
            goto L_0x020e
        L_0x0240:
            r22 = r3
            goto L_0x0319
        L_0x0244:
            float r5 = r6.f1156g
            r9 = 0
            int r13 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1))
            if (r13 <= 0) goto L_0x024d
            r17 = r5
        L_0x024d:
            r5 = 0
            r6.f1155f = r5
            r5 = 0
        L_0x0251:
            if (r5 >= r10) goto L_0x0309
            android.view.View r9 = r6.getChildAt(r5)
            int r13 = r9.getVisibility()
            r14 = 8
            if (r13 != r14) goto L_0x0263
            r29 = r4
            goto L_0x0303
        L_0x0263:
            android.view.ViewGroup$LayoutParams r13 = r9.getLayoutParams()
            androidx.appcompat.widget.y1 r13 = (androidx.appcompat.widget.y1) r13
            float r14 = r13.weight
            r15 = 0
            int r16 = (r14 > r15 ? 1 : (r14 == r15 ? 0 : -1))
            if (r16 <= 0) goto L_0x02bf
            float r15 = (float) r11
            float r15 = r15 * r14
            float r15 = r15 / r17
            int r15 = (int) r15
            float r17 = r17 - r14
            int r11 = r11 - r15
            int r14 = r37.getPaddingLeft()
            int r16 = r37.getPaddingRight()
            int r16 = r16 + r14
            int r14 = r13.leftMargin
            int r16 = r16 + r14
            int r14 = r13.rightMargin
            int r14 = r16 + r14
            r16 = r11
            int r11 = r13.width
            int r11 = android.view.ViewGroup.getChildMeasureSpec(r7, r14, r11)
            int r14 = r13.height
            if (r14 != 0) goto L_0x02a8
            r14 = 1073741824(0x40000000, float:2.0)
            if (r4 == r14) goto L_0x029c
            goto L_0x02aa
        L_0x029c:
            if (r15 <= 0) goto L_0x029f
            goto L_0x02a0
        L_0x029f:
            r15 = 0
        L_0x02a0:
            int r15 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r14)
            r9.measure(r11, r15)
            goto L_0x02b3
        L_0x02a8:
            r14 = 1073741824(0x40000000, float:2.0)
        L_0x02aa:
            int r18 = r9.getMeasuredHeight()
            int r15 = r18 + r15
            if (r15 >= 0) goto L_0x02a0
            goto L_0x029f
        L_0x02b3:
            int r11 = r9.getMeasuredState()
            r11 = r11 & -256(0xffffffffffffff00, float:NaN)
            int r12 = android.view.View.combineMeasuredStates(r12, r11)
            r11 = r16
        L_0x02bf:
            int r14 = r13.leftMargin
            int r15 = r13.rightMargin
            int r14 = r14 + r15
            int r15 = r9.getMeasuredWidth()
            int r15 = r15 + r14
            int r3 = java.lang.Math.max(r3, r15)
            r16 = r3
            r3 = 1073741824(0x40000000, float:2.0)
            if (r1 == r3) goto L_0x02db
            int r3 = r13.width
            r29 = r4
            r4 = -1
            if (r3 != r4) goto L_0x02de
            goto L_0x02df
        L_0x02db:
            r29 = r4
            r4 = -1
        L_0x02de:
            r14 = r15
        L_0x02df:
            int r2 = java.lang.Math.max(r2, r14)
            if (r24 == 0) goto L_0x02eb
            int r3 = r13.width
            if (r3 != r4) goto L_0x02eb
            r3 = 1
            goto L_0x02ec
        L_0x02eb:
            r3 = 0
        L_0x02ec:
            int r4 = r6.f1155f
            int r9 = r9.getMeasuredHeight()
            int r9 = r9 + r4
            int r14 = r13.topMargin
            int r9 = r9 + r14
            int r13 = r13.bottomMargin
            int r9 = r9 + r13
            int r4 = java.lang.Math.max(r4, r9)
            r6.f1155f = r4
            r24 = r3
            r3 = r16
        L_0x0303:
            int r5 = r5 + 1
            r4 = r29
            goto L_0x0251
        L_0x0309:
            int r4 = r6.f1155f
            int r5 = r37.getPaddingTop()
            int r9 = r37.getPaddingBottom()
            int r9 = r9 + r5
            int r9 = r9 + r4
            r6.f1155f = r9
            goto L_0x0240
        L_0x0319:
            if (r24 != 0) goto L_0x0320
            r3 = 1073741824(0x40000000, float:2.0)
            if (r1 == r3) goto L_0x0320
            goto L_0x0322
        L_0x0320:
            r2 = r22
        L_0x0322:
            int r1 = r37.getPaddingLeft()
            int r3 = r37.getPaddingRight()
            int r3 = r3 + r1
            int r3 = r3 + r2
            int r1 = r37.getSuggestedMinimumWidth()
            int r1 = java.lang.Math.max(r3, r1)
            int r1 = android.view.View.resolveSizeAndState(r1, r7, r12)
            r6.setMeasuredDimension(r1, r0)
            if (r25 == 0) goto L_0x0886
            int r0 = r37.getMeasuredWidth()
            r1 = 1073741824(0x40000000, float:2.0)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1)
            r9 = 0
        L_0x0348:
            if (r9 >= r10) goto L_0x0886
            android.view.View r1 = r6.getChildAt(r9)
            int r0 = r1.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x0376
            android.view.ViewGroup$LayoutParams r0 = r1.getLayoutParams()
            r11 = r0
            androidx.appcompat.widget.y1 r11 = (androidx.appcompat.widget.y1) r11
            int r0 = r11.width
            r2 = -1
            if (r0 != r2) goto L_0x0376
            int r12 = r11.height
            int r0 = r1.getMeasuredHeight()
            r11.height = r0
            r3 = 0
            r5 = 0
            r0 = r37
            r2 = r7
            r4 = r39
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r11.height = r12
        L_0x0376:
            int r9 = r9 + 1
            goto L_0x0348
        L_0x0379:
            r0 = 0
            r27 = 1
            r6.f1155f = r0
            int r9 = r37.getVirtualChildCount()
            int r10 = android.view.View.MeasureSpec.getMode(r38)
            int r11 = android.view.View.MeasureSpec.getMode(r39)
            int[] r0 = r6.f1158i
            r12 = 4
            if (r0 == 0) goto L_0x0393
            int[] r0 = r6.f1159j
            if (r0 != 0) goto L_0x039b
        L_0x0393:
            int[] r0 = new int[r12]
            r6.f1158i = r0
            int[] r0 = new int[r12]
            r6.f1159j = r0
        L_0x039b:
            int[] r13 = r6.f1158i
            int[] r14 = r6.f1159j
            r15 = 3
            r0 = -1
            r13[r15] = r0
            r17 = 2
            r13[r17] = r0
            r13[r27] = r0
            r1 = 0
            r13[r1] = r0
            r14[r15] = r0
            r14[r17] = r0
            r14[r27] = r0
            r14[r1] = r0
            boolean r5 = r6.f1150a
            boolean r4 = r6.f1157h
            r0 = 1073741824(0x40000000, float:2.0)
            if (r10 != r0) goto L_0x03bf
            r18 = 1
            goto L_0x03c1
        L_0x03bf:
            r18 = 0
        L_0x03c1:
            r0 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r8 = 0
            r12 = 0
            r15 = 0
            r19 = 1
            r21 = 0
            r24 = 0
        L_0x03ce:
            if (r3 >= r9) goto L_0x0569
            android.view.View r7 = r6.getChildAt(r3)
            if (r7 != 0) goto L_0x03e2
            int r7 = r6.f1155f
            r6.f1155f = r7
            r25 = r3
            r26 = r4
            r30 = r5
            goto L_0x055f
        L_0x03e2:
            r25 = r0
            int r0 = r7.getVisibility()
            r26 = r2
            r2 = 8
            if (r0 != r2) goto L_0x03fa
            r30 = r5
            r0 = r25
            r2 = r26
            r25 = r3
            r26 = r4
            goto L_0x055f
        L_0x03fa:
            boolean r0 = r6.k(r3)
            if (r0 == 0) goto L_0x0407
            int r0 = r6.f1155f
            int r2 = r6.f1161l
            int r0 = r0 + r2
            r6.f1155f = r0
        L_0x0407:
            android.view.ViewGroup$LayoutParams r0 = r7.getLayoutParams()
            r2 = r0
            androidx.appcompat.widget.y1 r2 = (androidx.appcompat.widget.y1) r2
            float r0 = r2.weight
            float r29 = r1 + r0
            r1 = 1073741824(0x40000000, float:2.0)
            if (r10 != r1) goto L_0x0465
            int r1 = r2.width
            if (r1 != 0) goto L_0x0465
            r1 = 0
            int r30 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r30 <= 0) goto L_0x0465
            if (r18 == 0) goto L_0x042e
            int r0 = r6.f1155f
            int r1 = r2.leftMargin
            r30 = r3
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r1 = r1 + r0
            r6.f1155f = r1
            goto L_0x043e
        L_0x042e:
            r30 = r3
            int r0 = r6.f1155f
            int r1 = r2.leftMargin
            int r1 = r1 + r0
            int r3 = r2.rightMargin
            int r1 = r1 + r3
            int r0 = java.lang.Math.max(r0, r1)
            r6.f1155f = r0
        L_0x043e:
            if (r5 == 0) goto L_0x0455
            r0 = 0
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0)
            r7.measure(r1, r1)
            r0 = r2
            r33 = r25
            r34 = r26
            r25 = r30
            r26 = r4
            r30 = r5
            goto L_0x04d6
        L_0x0455:
            r0 = r2
            r33 = r25
            r34 = r26
            r25 = r30
            r1 = 1073741824(0x40000000, float:2.0)
            r26 = r4
            r30 = r5
            r4 = 1
            goto L_0x04da
        L_0x0465:
            r30 = r3
            int r1 = r2.width
            if (r1 != 0) goto L_0x0475
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0476
            r0 = -2
            r2.width = r0
            r3 = 0
            goto L_0x0478
        L_0x0475:
            r1 = 0
        L_0x0476:
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x0478:
            int r0 = (r29 > r1 ? 1 : (r29 == r1 ? 0 : -1))
            if (r0 != 0) goto L_0x0481
            int r0 = r6.f1155f
            r31 = r0
            goto L_0x0483
        L_0x0481:
            r31 = 0
        L_0x0483:
            r32 = 0
            r1 = r25
            r0 = r37
            r33 = r1
            r1 = r7
            r35 = r2
            r34 = r26
            r2 = r38
            r36 = r3
            r25 = r30
            r3 = r31
            r26 = r4
            r4 = r39
            r30 = r5
            r5 = r32
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r1 = r36
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == r0) goto L_0x04ae
            r0 = r35
            r0.width = r1
            goto L_0x04b0
        L_0x04ae:
            r0 = r35
        L_0x04b0:
            int r1 = r7.getMeasuredWidth()
            int r2 = r6.f1155f
            if (r18 == 0) goto L_0x04c2
            int r3 = r0.leftMargin
            int r3 = r3 + r1
            int r4 = r0.rightMargin
            int r3 = r3 + r4
            int r3 = r3 + r2
            r6.f1155f = r3
            goto L_0x04d0
        L_0x04c2:
            int r3 = r2 + r1
            int r4 = r0.leftMargin
            int r3 = r3 + r4
            int r4 = r0.rightMargin
            int r3 = r3 + r4
            int r2 = java.lang.Math.max(r2, r3)
            r6.f1155f = r2
        L_0x04d0:
            if (r26 == 0) goto L_0x04d6
            int r12 = java.lang.Math.max(r1, r12)
        L_0x04d6:
            r4 = r21
            r1 = 1073741824(0x40000000, float:2.0)
        L_0x04da:
            if (r11 == r1) goto L_0x04e5
            int r1 = r0.height
            r2 = -1
            if (r1 != r2) goto L_0x04e5
            r5 = 1
            r24 = 1
            goto L_0x04e6
        L_0x04e5:
            r5 = 0
        L_0x04e6:
            int r1 = r0.topMargin
            int r2 = r0.bottomMargin
            int r1 = r1 + r2
            int r2 = r7.getMeasuredHeight()
            int r2 = r2 + r1
            int r3 = r7.getMeasuredState()
            int r3 = android.view.View.combineMeasuredStates(r8, r3)
            if (r30 == 0) goto L_0x052a
            int r7 = r7.getBaseline()
            r8 = -1
            if (r7 == r8) goto L_0x052a
            int r8 = r0.gravity
            if (r8 >= 0) goto L_0x0507
            int r8 = r6.f1154e
        L_0x0507:
            r8 = r8 & 112(0x70, float:1.57E-43)
            r21 = 4
            int r8 = r8 >> 4
            r21 = -2
            r8 = r8 & -2
            int r8 = r8 >> 1
            r21 = r1
            r1 = r13[r8]
            int r1 = java.lang.Math.max(r1, r7)
            r13[r8] = r1
            r1 = r14[r8]
            int r7 = r2 - r7
            int r1 = java.lang.Math.max(r1, r7)
            r14[r8] = r1
        L_0x0527:
            r7 = r34
            goto L_0x052d
        L_0x052a:
            r21 = r1
            goto L_0x0527
        L_0x052d:
            int r1 = java.lang.Math.max(r7, r2)
            if (r19 == 0) goto L_0x053a
            int r7 = r0.height
            r8 = -1
            if (r7 != r8) goto L_0x053a
            r7 = 1
            goto L_0x053b
        L_0x053a:
            r7 = 0
        L_0x053b:
            float r0 = r0.weight
            r8 = 0
            int r0 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x054d
            if (r5 == 0) goto L_0x0546
            r2 = r21
        L_0x0546:
            int r15 = java.lang.Math.max(r15, r2)
            r0 = r33
            goto L_0x0557
        L_0x054d:
            if (r5 == 0) goto L_0x0551
            r2 = r21
        L_0x0551:
            r0 = r33
            int r0 = java.lang.Math.max(r0, r2)
        L_0x0557:
            r2 = r1
            r8 = r3
            r21 = r4
            r19 = r7
            r1 = r29
        L_0x055f:
            int r3 = r25 + 1
            r7 = r38
            r4 = r26
            r5 = r30
            goto L_0x03ce
        L_0x0569:
            r7 = r2
            r26 = r4
            r30 = r5
            int r2 = r6.f1155f
            if (r2 <= 0) goto L_0x057f
            boolean r2 = r6.k(r9)
            if (r2 == 0) goto L_0x057f
            int r2 = r6.f1155f
            int r3 = r6.f1161l
            int r2 = r2 + r3
            r6.f1155f = r2
        L_0x057f:
            r2 = r13[r27]
            r3 = -1
            if (r2 != r3) goto L_0x0597
            r4 = 0
            r5 = r13[r4]
            if (r5 != r3) goto L_0x0597
            r4 = r13[r17]
            if (r4 != r3) goto L_0x0597
            r4 = 3
            r5 = r13[r4]
            if (r5 == r3) goto L_0x0593
            goto L_0x0598
        L_0x0593:
            r2 = r7
            r25 = r8
            goto L_0x05c8
        L_0x0597:
            r4 = 3
        L_0x0598:
            r3 = r13[r4]
            r5 = 0
            r4 = r13[r5]
            r5 = r13[r17]
            int r2 = java.lang.Math.max(r2, r5)
            int r2 = java.lang.Math.max(r4, r2)
            int r2 = java.lang.Math.max(r3, r2)
            r3 = 3
            r4 = r14[r3]
            r3 = 0
            r5 = r14[r3]
            r3 = r14[r27]
            r25 = r8
            r8 = r14[r17]
            int r3 = java.lang.Math.max(r3, r8)
            int r3 = java.lang.Math.max(r5, r3)
            int r3 = java.lang.Math.max(r4, r3)
            int r3 = r3 + r2
            int r2 = java.lang.Math.max(r7, r3)
        L_0x05c8:
            if (r26 == 0) goto L_0x060e
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r10 == r3) goto L_0x05d0
            if (r10 != 0) goto L_0x060e
        L_0x05d0:
            r3 = 0
            r6.f1155f = r3
            r5 = 0
        L_0x05d4:
            if (r5 >= r9) goto L_0x060e
            android.view.View r3 = r6.getChildAt(r5)
            if (r3 != 0) goto L_0x05e1
            int r3 = r6.f1155f
        L_0x05de:
            r6.f1155f = r3
            goto L_0x060b
        L_0x05e1:
            int r4 = r3.getVisibility()
            r7 = 8
            if (r4 != r7) goto L_0x05ea
            goto L_0x060b
        L_0x05ea:
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.y1 r3 = (androidx.appcompat.widget.y1) r3
            int r4 = r6.f1155f
            if (r18 == 0) goto L_0x05fe
            int r7 = r3.leftMargin
            int r7 = r7 + r12
            int r3 = r3.rightMargin
            int r7 = r7 + r3
            int r7 = r7 + r4
            r6.f1155f = r7
            goto L_0x060b
        L_0x05fe:
            int r7 = r4 + r12
            int r8 = r3.leftMargin
            int r7 = r7 + r8
            int r3 = r3.rightMargin
            int r7 = r7 + r3
            int r3 = java.lang.Math.max(r4, r7)
            goto L_0x05de
        L_0x060b:
            int r5 = r5 + 1
            goto L_0x05d4
        L_0x060e:
            int r3 = r6.f1155f
            int r4 = r37.getPaddingLeft()
            int r5 = r37.getPaddingRight()
            int r5 = r5 + r4
            int r5 = r5 + r3
            r6.f1155f = r5
            int r3 = r37.getSuggestedMinimumWidth()
            int r3 = java.lang.Math.max(r5, r3)
            r7 = r38
            r4 = 0
            int r3 = android.view.View.resolveSizeAndState(r3, r7, r4)
            r4 = 16777215(0xffffff, float:2.3509886E-38)
            r4 = r4 & r3
            int r5 = r6.f1155f
            int r4 = r4 - r5
            if (r21 != 0) goto L_0x0680
            if (r4 == 0) goto L_0x063c
            r8 = 0
            int r16 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r16 <= 0) goto L_0x063c
            goto L_0x0680
        L_0x063c:
            int r0 = java.lang.Math.max(r0, r15)
            if (r26 == 0) goto L_0x0679
            r1 = 1073741824(0x40000000, float:2.0)
            if (r10 == r1) goto L_0x0679
            r1 = 0
        L_0x0647:
            if (r1 >= r9) goto L_0x0679
            android.view.View r4 = r6.getChildAt(r1)
            if (r4 == 0) goto L_0x0676
            int r8 = r4.getVisibility()
            r10 = 8
            if (r8 != r10) goto L_0x0658
            goto L_0x0676
        L_0x0658:
            android.view.ViewGroup$LayoutParams r8 = r4.getLayoutParams()
            androidx.appcompat.widget.y1 r8 = (androidx.appcompat.widget.y1) r8
            float r8 = r8.weight
            r10 = 0
            int r8 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r8 <= 0) goto L_0x0676
            r8 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r8)
            int r13 = r4.getMeasuredHeight()
            int r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r8)
            r4.measure(r10, r13)
        L_0x0676:
            int r1 = r1 + 1
            goto L_0x0647
        L_0x0679:
            r4 = r39
            r22 = r9
            r8 = 0
            goto L_0x081d
        L_0x0680:
            float r2 = r6.f1156g
            r8 = 0
            int r12 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r12 <= 0) goto L_0x0688
            r1 = r2
        L_0x0688:
            r2 = -1
            r8 = 3
            r13[r8] = r2
            r13[r17] = r2
            r13[r27] = r2
            r12 = 0
            r13[r12] = r2
            r14[r8] = r2
            r14[r17] = r2
            r14[r27] = r2
            r14[r12] = r2
            r6.f1155f = r12
            r12 = r25
            r2 = -1
            r8 = 0
        L_0x06a1:
            if (r8 >= r9) goto L_0x07c5
            android.view.View r15 = r6.getChildAt(r8)
            if (r15 == 0) goto L_0x06b1
            int r5 = r15.getVisibility()
            r7 = 8
            if (r5 != r7) goto L_0x06be
        L_0x06b1:
            r7 = r4
            r22 = r9
            r21 = 0
            r23 = 4
            r28 = -2
            r4 = r39
            goto L_0x07bc
        L_0x06be:
            android.view.ViewGroup$LayoutParams r5 = r15.getLayoutParams()
            androidx.appcompat.widget.y1 r5 = (androidx.appcompat.widget.y1) r5
            float r7 = r5.weight
            r21 = 0
            int r22 = (r7 > r21 ? 1 : (r7 == r21 ? 0 : -1))
            if (r22 <= 0) goto L_0x0723
            r22 = r9
            float r9 = (float) r4
            float r9 = r9 * r7
            float r9 = r9 / r1
            int r9 = (int) r9
            float r1 = r1 - r7
            int r4 = r4 - r9
            int r7 = r37.getPaddingTop()
            int r25 = r37.getPaddingBottom()
            int r25 = r25 + r7
            int r7 = r5.topMargin
            int r25 = r25 + r7
            int r7 = r5.bottomMargin
            int r7 = r25 + r7
            r25 = r1
            int r1 = r5.height
            r26 = r4
            r4 = r39
            int r1 = android.view.ViewGroup.getChildMeasureSpec(r4, r7, r1)
            int r7 = r5.width
            if (r7 != 0) goto L_0x0708
            r7 = 1073741824(0x40000000, float:2.0)
            if (r10 == r7) goto L_0x06fc
            goto L_0x070a
        L_0x06fc:
            if (r9 <= 0) goto L_0x06ff
            goto L_0x0700
        L_0x06ff:
            r9 = 0
        L_0x0700:
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r7)
            r15.measure(r9, r1)
            goto L_0x0713
        L_0x0708:
            r7 = 1073741824(0x40000000, float:2.0)
        L_0x070a:
            int r28 = r15.getMeasuredWidth()
            int r9 = r28 + r9
            if (r9 >= 0) goto L_0x0700
            goto L_0x06ff
        L_0x0713:
            int r1 = r15.getMeasuredState()
            r7 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r7
            int r12 = android.view.View.combineMeasuredStates(r12, r1)
            r1 = r25
            r7 = r26
            goto L_0x0728
        L_0x0723:
            r7 = r4
            r22 = r9
            r4 = r39
        L_0x0728:
            if (r18 == 0) goto L_0x0743
            int r9 = r6.f1155f
            int r25 = r15.getMeasuredWidth()
            r26 = r1
            int r1 = r5.leftMargin
            int r25 = r25 + r1
            int r1 = r5.rightMargin
            int r25 = r25 + r1
            int r1 = r25 + r9
            r6.f1155f = r1
            r25 = r7
        L_0x0740:
            r1 = 1073741824(0x40000000, float:2.0)
            goto L_0x075b
        L_0x0743:
            r26 = r1
            int r1 = r6.f1155f
            int r9 = r15.getMeasuredWidth()
            int r9 = r9 + r1
            r25 = r7
            int r7 = r5.leftMargin
            int r9 = r9 + r7
            int r7 = r5.rightMargin
            int r9 = r9 + r7
            int r1 = java.lang.Math.max(r1, r9)
            r6.f1155f = r1
            goto L_0x0740
        L_0x075b:
            if (r11 == r1) goto L_0x0764
            int r1 = r5.height
            r7 = -1
            if (r1 != r7) goto L_0x0764
            r1 = 1
            goto L_0x0765
        L_0x0764:
            r1 = 0
        L_0x0765:
            int r7 = r5.topMargin
            int r9 = r5.bottomMargin
            int r7 = r7 + r9
            int r9 = r15.getMeasuredHeight()
            int r9 = r9 + r7
            int r2 = java.lang.Math.max(r2, r9)
            if (r1 == 0) goto L_0x0776
            goto L_0x0777
        L_0x0776:
            r7 = r9
        L_0x0777:
            int r0 = java.lang.Math.max(r0, r7)
            if (r19 == 0) goto L_0x0784
            int r1 = r5.height
            r7 = -1
            if (r1 != r7) goto L_0x0785
            r1 = 1
            goto L_0x0786
        L_0x0784:
            r7 = -1
        L_0x0785:
            r1 = 0
        L_0x0786:
            if (r30 == 0) goto L_0x07b2
            int r15 = r15.getBaseline()
            if (r15 == r7) goto L_0x07b2
            int r5 = r5.gravity
            if (r5 >= 0) goto L_0x0794
            int r5 = r6.f1154e
        L_0x0794:
            r5 = r5 & 112(0x70, float:1.57E-43)
            r23 = 4
            int r5 = r5 >> 4
            r28 = -2
            r5 = r5 & -2
            int r5 = r5 >> 1
            r7 = r13[r5]
            int r7 = java.lang.Math.max(r7, r15)
            r13[r5] = r7
            r7 = r14[r5]
            int r9 = r9 - r15
            int r7 = java.lang.Math.max(r7, r9)
            r14[r5] = r7
            goto L_0x07b6
        L_0x07b2:
            r23 = 4
            r28 = -2
        L_0x07b6:
            r19 = r1
            r7 = r25
            r1 = r26
        L_0x07bc:
            int r8 = r8 + 1
            r4 = r7
            r9 = r22
            r7 = r38
            goto L_0x06a1
        L_0x07c5:
            r4 = r39
            r22 = r9
            int r1 = r6.f1155f
            int r5 = r37.getPaddingLeft()
            int r7 = r37.getPaddingRight()
            int r7 = r7 + r5
            int r7 = r7 + r1
            r6.f1155f = r7
            r1 = r13[r27]
            r5 = -1
            if (r1 != r5) goto L_0x07ed
            r7 = 0
            r8 = r13[r7]
            if (r8 != r5) goto L_0x07ed
            r7 = r13[r17]
            if (r7 != r5) goto L_0x07ed
            r7 = 3
            r8 = r13[r7]
            if (r8 == r5) goto L_0x07eb
            goto L_0x07ee
        L_0x07eb:
            r8 = 0
            goto L_0x081b
        L_0x07ed:
            r7 = 3
        L_0x07ee:
            r5 = r13[r7]
            r8 = 0
            r9 = r13[r8]
            r10 = r13[r17]
            int r1 = java.lang.Math.max(r1, r10)
            int r1 = java.lang.Math.max(r9, r1)
            int r1 = java.lang.Math.max(r5, r1)
            r5 = r14[r7]
            r7 = r14[r8]
            r9 = r14[r27]
            r10 = r14[r17]
            int r9 = java.lang.Math.max(r9, r10)
            int r7 = java.lang.Math.max(r7, r9)
            int r5 = java.lang.Math.max(r5, r7)
            int r5 = r5 + r1
            int r1 = java.lang.Math.max(r2, r5)
            r2 = r1
        L_0x081b:
            r25 = r12
        L_0x081d:
            if (r19 != 0) goto L_0x0824
            r1 = 1073741824(0x40000000, float:2.0)
            if (r11 == r1) goto L_0x0824
            goto L_0x0825
        L_0x0824:
            r0 = r2
        L_0x0825:
            int r1 = r37.getPaddingTop()
            int r2 = r37.getPaddingBottom()
            int r2 = r2 + r1
            int r2 = r2 + r0
            int r0 = r37.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r2, r0)
            r1 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r25 & r1
            r1 = r1 | r3
            int r2 = r25 << 16
            int r0 = android.view.View.resolveSizeAndState(r0, r4, r2)
            r6.setMeasuredDimension(r1, r0)
            if (r24 == 0) goto L_0x0886
            int r0 = r37.getMeasuredHeight()
            r1 = 1073741824(0x40000000, float:2.0)
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1)
            r9 = r22
        L_0x0853:
            if (r8 >= r9) goto L_0x0886
            android.view.View r1 = r6.getChildAt(r8)
            int r0 = r1.getVisibility()
            r10 = 8
            if (r0 == r10) goto L_0x0882
            android.view.ViewGroup$LayoutParams r0 = r1.getLayoutParams()
            r11 = r0
            androidx.appcompat.widget.y1 r11 = (androidx.appcompat.widget.y1) r11
            int r0 = r11.height
            r12 = -1
            if (r0 != r12) goto L_0x0883
            int r13 = r11.width
            int r0 = r1.getMeasuredWidth()
            r11.width = r0
            r3 = 0
            r5 = 0
            r0 = r37
            r2 = r38
            r4 = r7
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            r11.width = r13
            goto L_0x0883
        L_0x0882:
            r12 = -1
        L_0x0883:
            int r8 = r8 + 1
            goto L_0x0853
        L_0x0886:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.LinearLayoutCompat.onMeasure(int, int):void");
    }

    public void setBaselineAligned(boolean z4) {
        this.f1150a = z4;
    }

    public void setBaselineAlignedChildIndex(int i10) {
        if (i10 < 0 || i10 >= getChildCount()) {
            throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
        }
        this.f1151b = i10;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.f1160k) {
            this.f1160k = drawable;
            boolean z4 = false;
            if (drawable != null) {
                this.f1161l = drawable.getIntrinsicWidth();
                this.f1162m = drawable.getIntrinsicHeight();
            } else {
                this.f1161l = 0;
                this.f1162m = 0;
            }
            if (drawable == null) {
                z4 = true;
            }
            setWillNotDraw(z4);
            requestLayout();
        }
    }

    public void setDividerPadding(int i10) {
        this.f1164o = i10;
    }

    public void setGravity(int i10) {
        if (this.f1154e != i10) {
            if ((8388615 & i10) == 0) {
                i10 |= 8388611;
            }
            if ((i10 & 112) == 0) {
                i10 |= 48;
            }
            this.f1154e = i10;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i10) {
        int i11 = i10 & 8388615;
        int i12 = this.f1154e;
        if ((8388615 & i12) != i11) {
            this.f1154e = i11 | (-8388616 & i12);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z4) {
        this.f1157h = z4;
    }

    public void setOrientation(int i10) {
        if (this.f1153d != i10) {
            this.f1153d = i10;
            requestLayout();
        }
    }

    public void setShowDividers(int i10) {
        if (i10 != this.f1163n) {
            requestLayout();
        }
        this.f1163n = i10;
    }

    public void setVerticalGravity(int i10) {
        int i11 = i10 & 112;
        int i12 = this.f1154e;
        if ((i12 & 112) != i11) {
            this.f1154e = i11 | (i12 & -113);
            requestLayout();
        }
    }

    public void setWeightSum(float f10) {
        this.f1156g = Math.max(0.0f, f10);
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1150a = true;
        this.f1151b = -1;
        this.f1152c = 0;
        this.f1154e = 8388659;
        int[] iArr = a.f18934p;
        w wVar = new w(context, context.obtainStyledAttributes(attributeSet, iArr, i10, 0));
        h1.q(this, context, iArr, attributeSet, (TypedArray) wVar.f619c, i10);
        int z4 = wVar.z(1, -1);
        if (z4 >= 0) {
            setOrientation(z4);
        }
        int z10 = wVar.z(0, -1);
        if (z10 >= 0) {
            setGravity(z10);
        }
        boolean r4 = wVar.r(2, true);
        if (!r4) {
            setBaselineAligned(r4);
        }
        this.f1156g = ((TypedArray) wVar.f619c).getFloat(4, -1.0f);
        this.f1151b = wVar.z(3, -1);
        this.f1157h = wVar.r(7, false);
        setDividerDrawable(wVar.w(5));
        this.f1163n = wVar.z(8, 0);
        this.f1164o = wVar.v(6, 0);
        wVar.N();
    }
}
