package androidx.appcompat.widget;

import android.graphics.Canvas;
import i.i;

public final class s1 extends i {

    /* renamed from: b  reason: collision with root package name */
    public boolean f1497b;

    public final void draw(Canvas canvas) {
        if (this.f1497b) {
            super.draw(canvas);
        }
    }

    public final void setHotspot(float f10, float f11) {
        if (this.f1497b) {
            super.setHotspot(f10, f11);
        }
    }

    public final void setHotspotBounds(int i10, int i11, int i12, int i13) {
        if (this.f1497b) {
            super.setHotspotBounds(i10, i11, i12, i13);
        }
    }

    public final boolean setState(int[] iArr) {
        if (this.f1497b) {
            return this.f19892a.setState(iArr);
        }
        return false;
    }

    public final boolean setVisible(boolean z4, boolean z10) {
        if (this.f1497b) {
            return super.setVisible(z4, z10);
        }
        return false;
    }
}
