package androidx.appcompat.widget;

import android.content.Intent;
import android.graphics.Typeface;
import android.widget.TextView;
import z5.j;
import z7.k6;
import z7.x3;

public final class s0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1492a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f1493b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f1494c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f1495d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ Object f1496e;

    public s0(y0 y0Var, TextView textView, Typeface typeface, int i10) {
        this.f1496e = y0Var;
        this.f1494c = textView;
        this.f1495d = typeface;
        this.f1493b = i10;
    }

    public final void run() {
        switch (this.f1492a) {
            case 0:
                ((TextView) this.f1494c).setTypeface((Typeface) this.f1495d, this.f1493b);
                return;
            default:
                j jVar = (j) this.f1494c;
                int i10 = this.f1493b;
                x3 x3Var = (x3) this.f1495d;
                Intent intent = (Intent) this.f1496e;
                if (((k6) jVar.f30695a).g(i10)) {
                    x3Var.f31358n.d("Local AppMeasurementService processed last upload request. StartId", Integer.valueOf(i10));
                    jVar.b().f31358n.c("Completed wakeful intent.");
                    ((k6) jVar.f30695a).a(intent);
                    return;
                }
                return;
        }
    }

    public /* synthetic */ s0(j jVar, int i10, x3 x3Var, Intent intent) {
        this.f1494c = jVar;
        this.f1493b = i10;
        this.f1495d = x3Var;
        this.f1496e = intent;
    }
}
