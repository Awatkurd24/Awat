package androidx.appcompat.widget;

import android.view.MenuItem;
import m.o;
import m.q;

public interface g2 {
    void h(o oVar, q qVar);

    void n(o oVar, MenuItem menuItem);
}
