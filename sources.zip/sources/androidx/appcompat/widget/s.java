package androidx.appcompat.widget;

import android.database.DataSetObservable;

public abstract class s extends DataSetObservable {
}
