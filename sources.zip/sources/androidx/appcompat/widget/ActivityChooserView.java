package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import co.vpn.plusvpn.R;
import g.a;
import m.b;
import m.e;
import r1.d;
import r1.h1;
import u7.y;

public class ActivityChooserView extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public final v f1068a;

    /* renamed from: b  reason: collision with root package name */
    public final w f1069b;

    /* renamed from: c  reason: collision with root package name */
    public final View f1070c;

    /* renamed from: d  reason: collision with root package name */
    public final FrameLayout f1071d;

    /* renamed from: e  reason: collision with root package name */
    public final ImageView f1072e;

    /* renamed from: f  reason: collision with root package name */
    public final FrameLayout f1073f;

    /* renamed from: g  reason: collision with root package name */
    public d f1074g;

    /* renamed from: h  reason: collision with root package name */
    public final e f1075h = new e(2, this);

    /* renamed from: i  reason: collision with root package name */
    public ListPopupWindow f1076i;

    /* renamed from: j  reason: collision with root package name */
    public PopupWindow.OnDismissListener f1077j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1078k;

    public static class InnerLayout extends LinearLayout {

        /* renamed from: a  reason: collision with root package name */
        public static final int[] f1079a = {16842964};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            Drawable drawable;
            int resourceId;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1079a);
            if (!obtainStyledAttributes.hasValue(0) || (resourceId = obtainStyledAttributes.getResourceId(0, 0)) == 0) {
                drawable = obtainStyledAttributes.getDrawable(0);
            } else {
                drawable = y.e(context, resourceId);
            }
            setBackgroundDrawable(drawable);
            obtainStyledAttributes.recycle();
        }
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        new t(this, 0);
        int[] iArr = a.f18923e;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        h1.q(this, context, iArr, attributeSet, obtainStyledAttributes, i10);
        obtainStyledAttributes.getInt(1, 4);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        obtainStyledAttributes.recycle();
        LayoutInflater.from(getContext()).inflate(R.layout.abc_activity_chooser_view, this, true);
        w wVar = new w(this);
        this.f1069b = wVar;
        View findViewById = findViewById(R.id.activity_chooser_view_content);
        this.f1070c = findViewById;
        findViewById.getBackground();
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.default_activity_button);
        this.f1073f = frameLayout;
        frameLayout.setOnClickListener(wVar);
        frameLayout.setOnLongClickListener(wVar);
        ImageView imageView = (ImageView) frameLayout.findViewById(R.id.image);
        FrameLayout frameLayout2 = (FrameLayout) findViewById(R.id.expand_activities_button);
        frameLayout2.setOnClickListener(wVar);
        frameLayout2.setAccessibilityDelegate(new u(0, this));
        frameLayout2.setOnTouchListener(new b(this, frameLayout2));
        this.f1071d = frameLayout2;
        ImageView imageView2 = (ImageView) frameLayout2.findViewById(R.id.image);
        this.f1072e = imageView2;
        imageView2.setImageDrawable(drawable);
        v vVar = new v(this);
        this.f1068a = vVar;
        vVar.registerDataSetObserver(new t(this, 1));
        Resources resources = context.getResources();
        Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    }

    public final void a() {
        if (b()) {
            getListPopupWindow().dismiss();
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeGlobalOnLayoutListener(this.f1075h);
            }
        }
    }

    public final boolean b() {
        return getListPopupWindow().f1190z.isShowing();
    }

    public s getDataModel() {
        this.f1068a.getClass();
        return null;
    }

    public ListPopupWindow getListPopupWindow() {
        if (this.f1076i == null) {
            ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
            this.f1076i = listPopupWindow;
            listPopupWindow.p(this.f1068a);
            ListPopupWindow listPopupWindow2 = this.f1076i;
            listPopupWindow2.f1179o = this;
            listPopupWindow2.f1189y = true;
            listPopupWindow2.f1190z.setFocusable(true);
            ListPopupWindow listPopupWindow3 = this.f1076i;
            w wVar = this.f1069b;
            listPopupWindow3.f1180p = wVar;
            listPopupWindow3.f1190z.setOnDismissListener(wVar);
        }
        return this.f1076i;
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1068a.getClass();
        this.f1078k = true;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f1068a.getClass();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1075h);
        }
        if (b()) {
            a();
        }
        this.f1078k = false;
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        this.f1070c.layout(0, 0, i12 - i10, i13 - i11);
        if (!b()) {
            a();
        }
    }

    public final void onMeasure(int i10, int i11) {
        if (this.f1073f.getVisibility() != 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i11), 1073741824);
        }
        View view = this.f1070c;
        measureChild(view, i10, i11);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public void setActivityChooserModel(s sVar) {
        v vVar = this.f1068a;
        vVar.f1524a.f1068a.getClass();
        vVar.notifyDataSetChanged();
        if (b()) {
            a();
            if (!b() && this.f1078k) {
                vVar.getClass();
                throw new IllegalStateException("No data model. Did you call #setDataModel?");
            }
        }
    }

    public void setDefaultActionButtonContentDescription(int i10) {
    }

    public void setExpandActivityOverflowButtonContentDescription(int i10) {
        this.f1072e.setContentDescription(getContext().getString(i10));
    }

    public void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.f1072e.setImageDrawable(drawable);
    }

    public void setInitialActivityCount(int i10) {
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        this.f1077j = onDismissListener;
    }

    public void setProvider(d dVar) {
        this.f1074g = dVar;
    }
}
