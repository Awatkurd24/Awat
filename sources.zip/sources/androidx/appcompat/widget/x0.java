package androidx.appcompat.widget;

import android.graphics.Typeface;

public abstract class x0 {
    public static Typeface a(Typeface typeface, int i10, boolean z4) {
        return Typeface.create(typeface, i10, z4);
    }
}
