package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import h.j;
import m.e;

public final class n0 extends ListPopupWindow implements p0 {
    public CharSequence D;
    public ListAdapter E;
    public final Rect F = new Rect();
    public int G;
    public final /* synthetic */ AppCompatSpinner H;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n0(AppCompatSpinner appCompatSpinner, Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.H = appCompatSpinner;
        this.f1179o = appCompatSpinner;
        this.f1189y = true;
        this.f1190z.setFocusable(true);
        this.f1180p = new j(this, 1, appCompatSpinner);
    }

    public final void f(CharSequence charSequence) {
        this.D = charSequence;
    }

    public final void j(int i10) {
        this.G = i10;
    }

    public final void l(int i10, int i11) {
        ViewTreeObserver viewTreeObserver;
        PopupWindow popupWindow = this.f1190z;
        boolean isShowing = popupWindow.isShowing();
        s();
        this.f1190z.setInputMethodMode(2);
        c();
        u1 u1Var = this.f1167c;
        u1Var.setChoiceMode(1);
        i0.d(u1Var, i10);
        i0.c(u1Var, i11);
        AppCompatSpinner appCompatSpinner = this.H;
        int selectedItemPosition = appCompatSpinner.getSelectedItemPosition();
        u1 u1Var2 = this.f1167c;
        if (popupWindow.isShowing() && u1Var2 != null) {
            u1Var2.setListSelectionHidden(false);
            u1Var2.setSelection(selectedItemPosition);
            if (u1Var2.getChoiceMode() != 0) {
                u1Var2.setItemChecked(selectedItemPosition, true);
            }
        }
        if (!isShowing && (viewTreeObserver = appCompatSpinner.getViewTreeObserver()) != null) {
            e eVar = new e(4, this);
            viewTreeObserver.addOnGlobalLayoutListener(eVar);
            this.f1190z.setOnDismissListener(new m0(this, eVar));
        }
    }

    public final CharSequence o() {
        return this.D;
    }

    public final void p(ListAdapter listAdapter) {
        super.p(listAdapter);
        this.E = listAdapter;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0082  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void s() {
        /*
            r9 = this;
            android.widget.PopupWindow r0 = r9.f1190z
            android.graphics.drawable.Drawable r1 = r0.getBackground()
            androidx.appcompat.widget.AppCompatSpinner r2 = r9.H
            if (r1 == 0) goto L_0x0020
            android.graphics.Rect r3 = r2.f1125h
            r1.getPadding(r3)
            boolean r1 = androidx.appcompat.widget.f4.a(r2)
            if (r1 == 0) goto L_0x001a
            android.graphics.Rect r1 = r2.f1125h
            int r1 = r1.right
            goto L_0x0028
        L_0x001a:
            android.graphics.Rect r1 = r2.f1125h
            int r1 = r1.left
            int r1 = -r1
            goto L_0x0028
        L_0x0020:
            android.graphics.Rect r1 = r2.f1125h
            r3 = 0
            r1.right = r3
            r1.left = r3
            r1 = 0
        L_0x0028:
            int r3 = r2.getPaddingLeft()
            int r4 = r2.getPaddingRight()
            int r5 = r2.getWidth()
            int r6 = r2.f1124g
            r7 = -2
            if (r6 != r7) goto L_0x0069
            android.widget.ListAdapter r6 = r9.E
            android.widget.SpinnerAdapter r6 = (android.widget.SpinnerAdapter) r6
            android.graphics.drawable.Drawable r0 = r0.getBackground()
            int r0 = r2.a(r6, r0)
            android.content.Context r6 = r2.getContext()
            android.content.res.Resources r6 = r6.getResources()
            android.util.DisplayMetrics r6 = r6.getDisplayMetrics()
            int r6 = r6.widthPixels
            android.graphics.Rect r7 = r2.f1125h
            int r8 = r7.left
            int r6 = r6 - r8
            int r7 = r7.right
            int r6 = r6 - r7
            if (r0 <= r6) goto L_0x005e
            r0 = r6
        L_0x005e:
            int r6 = r5 - r3
            int r6 = r6 - r4
            int r0 = java.lang.Math.max(r0, r6)
        L_0x0065:
            r9.r(r0)
            goto L_0x0073
        L_0x0069:
            r0 = -1
            if (r6 != r0) goto L_0x0070
            int r0 = r5 - r3
            int r0 = r0 - r4
            goto L_0x0065
        L_0x0070:
            r9.r(r6)
        L_0x0073:
            boolean r0 = androidx.appcompat.widget.f4.a(r2)
            if (r0 == 0) goto L_0x0082
            int r5 = r5 - r4
            int r0 = r9.f1169e
            int r5 = r5 - r0
            int r0 = r9.G
            int r5 = r5 - r0
            int r5 = r5 + r1
            goto L_0x0087
        L_0x0082:
            int r0 = r9.G
            int r3 = r3 + r0
            int r5 = r3 + r1
        L_0x0087:
            r9.f1170f = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.n0.s():void");
    }
}
