package androidx.appcompat.widget;

import android.view.View;

public abstract class p1 {
    public static void a(View view, float f10, float f11) {
        view.drawableHotspotChanged(f10, f11);
    }
}
