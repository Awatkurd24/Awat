package androidx.appcompat.widget;

import android.view.View;

public final class f2 implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1333a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f1334b;

    public /* synthetic */ f2(int i10, Object obj) {
        this.f1333a = i10;
        this.f1334b = obj;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0026, code lost:
        r4 = (androidx.appcompat.widget.ListPopupWindow) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouch(android.view.View r7, android.view.MotionEvent r8) {
        /*
            r6 = this;
            int r7 = r6.f1333a
            r0 = 0
            java.lang.Object r1 = r6.f1334b
            r2 = 1
            switch(r7) {
                case 0: goto L_0x0016;
                case 1: goto L_0x000a;
                default: goto L_0x0009;
            }
        L_0x0009:
            return r2
        L_0x000a:
            o6.j r1 = (o6.j) r1
            com.google.android.gms.internal.ads.l8 r7 = r1.f23629h
            if (r7 == 0) goto L_0x0015
            com.google.android.gms.internal.ads.i8 r7 = r7.f9903b
            r7.a(r8)
        L_0x0015:
            return r0
        L_0x0016:
            int r7 = r8.getAction()
            float r3 = r8.getX()
            int r3 = (int) r3
            float r8 = r8.getY()
            int r8 = (int) r8
            if (r7 != 0) goto L_0x0051
            r4 = r1
            androidx.appcompat.widget.ListPopupWindow r4 = (androidx.appcompat.widget.ListPopupWindow) r4
            android.widget.PopupWindow r5 = r4.f1190z
            if (r5 == 0) goto L_0x0051
            boolean r5 = r5.isShowing()
            if (r5 == 0) goto L_0x0051
            if (r3 < 0) goto L_0x0051
            android.widget.PopupWindow r5 = r4.f1190z
            int r5 = r5.getWidth()
            if (r3 >= r5) goto L_0x0051
            if (r8 < 0) goto L_0x0051
            android.widget.PopupWindow r3 = r4.f1190z
            int r3 = r3.getHeight()
            if (r8 >= r3) goto L_0x0051
            android.os.Handler r7 = r4.f1186v
            androidx.appcompat.widget.z1 r8 = r4.f1182r
            r1 = 250(0xfa, double:1.235E-321)
            r7.postDelayed(r8, r1)
            goto L_0x005c
        L_0x0051:
            if (r7 != r2) goto L_0x005c
            androidx.appcompat.widget.ListPopupWindow r1 = (androidx.appcompat.widget.ListPopupWindow) r1
            android.os.Handler r7 = r1.f1186v
            androidx.appcompat.widget.z1 r8 = r1.f1182r
            r7.removeCallbacks(r8)
        L_0x005c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.f2.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }
}
