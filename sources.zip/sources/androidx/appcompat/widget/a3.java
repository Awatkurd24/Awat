package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

public final class a3 implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1287a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f1288b;

    public /* synthetic */ a3(View view, int i10) {
        this.f1287a = i10;
        this.f1288b = view;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i10, long j3) {
        Object obj;
        int i11 = this.f1287a;
        View view2 = this.f1288b;
        switch (i11) {
            case 0:
                ((SearchView) view2).p(i10);
                return;
            default:
                View view3 = null;
                if (i10 < 0) {
                    ListPopupWindow listPopupWindow = ((MaterialAutoCompleteTextView) view2).f16865e;
                    if (!listPopupWindow.f1190z.isShowing()) {
                        obj = null;
                    } else {
                        obj = listPopupWindow.f1167c.getSelectedItem();
                    }
                } else {
                    obj = ((MaterialAutoCompleteTextView) view2).getAdapter().getItem(i10);
                }
                MaterialAutoCompleteTextView materialAutoCompleteTextView = (MaterialAutoCompleteTextView) view2;
                MaterialAutoCompleteTextView.a(materialAutoCompleteTextView, obj);
                AdapterView.OnItemClickListener onItemClickListener = materialAutoCompleteTextView.getOnItemClickListener();
                ListPopupWindow listPopupWindow2 = materialAutoCompleteTextView.f16865e;
                if (onItemClickListener != null) {
                    if (view == null || i10 < 0) {
                        if (listPopupWindow2.f1190z.isShowing()) {
                            view3 = listPopupWindow2.f1167c.getSelectedView();
                        }
                        view = view3;
                        if (!listPopupWindow2.f1190z.isShowing()) {
                            i10 = -1;
                        } else {
                            i10 = listPopupWindow2.f1167c.getSelectedItemPosition();
                        }
                        if (!listPopupWindow2.f1190z.isShowing()) {
                            j3 = Long.MIN_VALUE;
                        } else {
                            j3 = listPopupWindow2.f1167c.getSelectedItemId();
                        }
                    }
                    onItemClickListener.onItemClick(listPopupWindow2.f1167c, view, i10, j3);
                }
                listPopupWindow2.dismiss();
                return;
        }
    }
}
