package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import co.vpn.plusvpn.R;
import g.a;
import java.util.WeakHashMap;
import r1.h1;
import r1.p0;

public class ActionBarContainer extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1001a;

    /* renamed from: b  reason: collision with root package name */
    public View f1002b;

    /* renamed from: c  reason: collision with root package name */
    public View f1003c;

    /* renamed from: d  reason: collision with root package name */
    public Drawable f1004d;

    /* renamed from: e  reason: collision with root package name */
    public Drawable f1005e;

    /* renamed from: f  reason: collision with root package name */
    public Drawable f1006f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f1007g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1008h;

    /* renamed from: i  reason: collision with root package name */
    public final int f1009i;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        b bVar = new b(this);
        WeakHashMap weakHashMap = h1.f25195a;
        p0.q(this, bVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f18919a);
        boolean z4 = false;
        this.f1004d = obtainStyledAttributes.getDrawable(0);
        this.f1005e = obtainStyledAttributes.getDrawable(2);
        this.f1009i = obtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f1007g = true;
            this.f1006f = obtainStyledAttributes.getDrawable(1);
        }
        obtainStyledAttributes.recycle();
        if (!this.f1007g ? this.f1004d == null && this.f1005e == null : this.f1006f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1004d;
        if (drawable != null && drawable.isStateful()) {
            this.f1004d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f1005e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f1005e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f1006f;
        if (drawable3 != null && drawable3.isStateful()) {
            this.f1006f.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return null;
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1004d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f1005e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f1006f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f1002b = findViewById(R.id.action_bar);
        this.f1003c = findViewById(R.id.action_context_bar);
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1001a || super.onInterceptTouchEvent(motionEvent);
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        boolean z10;
        Drawable drawable;
        int left;
        int top;
        int right;
        View view;
        super.onLayout(z4, i10, i11, i12, i13);
        if (this.f1007g) {
            Drawable drawable2 = this.f1006f;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                return;
            }
        } else {
            if (this.f1004d != null) {
                if (this.f1002b.getVisibility() == 0) {
                    drawable = this.f1004d;
                    left = this.f1002b.getLeft();
                    top = this.f1002b.getTop();
                    right = this.f1002b.getRight();
                    view = this.f1002b;
                } else {
                    View view2 = this.f1003c;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.f1004d.setBounds(0, 0, 0, 0);
                        z10 = true;
                    } else {
                        drawable = this.f1004d;
                        left = this.f1003c.getLeft();
                        top = this.f1003c.getTop();
                        right = this.f1003c.getRight();
                        view = this.f1003c;
                    }
                }
                drawable.setBounds(left, top, right, view.getBottom());
                z10 = true;
            } else {
                z10 = false;
            }
            this.f1008h = false;
            if (!z10) {
                return;
            }
        }
        invalidate();
    }

    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f1002b == null && View.MeasureSpec.getMode(i11) == Integer.MIN_VALUE && (i12 = this.f1009i) >= 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(Math.min(i12, View.MeasureSpec.getSize(i11)), Integer.MIN_VALUE);
        }
        super.onMeasure(i10, i11);
        if (this.f1002b != null) {
            View.MeasureSpec.getMode(i11);
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f1004d;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f1004d);
        }
        this.f1004d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1002b;
            if (view != null) {
                this.f1004d.setBounds(view.getLeft(), this.f1002b.getTop(), this.f1002b.getRight(), this.f1002b.getBottom());
            }
        }
        boolean z4 = false;
        if (!this.f1007g ? this.f1004d == null && this.f1005e == null : this.f1006f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f1006f;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f1006f);
        }
        this.f1006f = drawable;
        boolean z4 = this.f1007g;
        boolean z10 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z4 && (drawable2 = this.f1006f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z4 ? this.f1004d == null && this.f1005e == null : this.f1006f == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f1005e;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f1005e);
        }
        this.f1005e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f1008h && this.f1005e != null) {
                throw null;
            }
        }
        boolean z4 = false;
        if (!this.f1007g ? this.f1004d == null && this.f1005e == null : this.f1006f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(s2 s2Var) {
    }

    public void setTransitioning(boolean z4) {
        this.f1001a = z4;
        setDescendantFocusability(z4 ? 393216 : 262144);
    }

    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z4 = i10 == 0;
        Drawable drawable = this.f1004d;
        if (drawable != null) {
            drawable.setVisible(z4, false);
        }
        Drawable drawable2 = this.f1005e;
        if (drawable2 != null) {
            drawable2.setVisible(z4, false);
        }
        Drawable drawable3 = this.f1006f;
        if (drawable3 != null) {
            drawable3.setVisible(z4, false);
        }
    }

    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1004d;
        boolean z4 = this.f1007g;
        return (drawable == drawable2 && !z4) || (drawable == this.f1005e && this.f1008h) || ((drawable == this.f1006f && z4) || super.verifyDrawable(drawable));
    }

    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i10) {
        if (i10 != 0) {
            return super.startActionModeForChild(view, callback, i10);
        }
        return null;
    }
}
