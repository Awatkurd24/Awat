package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.recyclerview.widget.b0;
import bd.c;
import bd.e;
import bd.g;
import g.a;
import j2.b;
import java.io.Serializable;
import java.util.List;
import r1.h1;
import r6.r;
import u7.y;
import v1.f;

public final class c0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1309a;

    /* renamed from: b  reason: collision with root package name */
    public int f1310b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f1311c;

    /* renamed from: d  reason: collision with root package name */
    public final Serializable f1312d;

    /* renamed from: e  reason: collision with root package name */
    public Object f1313e;

    /* renamed from: f  reason: collision with root package name */
    public Object f1314f;

    public c0(ImageView imageView) {
        this.f1309a = 0;
        this.f1310b = 0;
        this.f1311c = imageView;
    }

    public static final double[] d(List list) {
        int size = list.size();
        double[] dArr = new double[size];
        for (int i10 = 0; i10 < size; i10++) {
            dArr[i10] = ((Double) list.get(i10)).doubleValue();
        }
        return dArr;
    }

    public final void a() {
        Drawable drawable = ((ImageView) this.f1311c).getDrawable();
        if (drawable != null) {
            o1.a(drawable);
        }
        if (drawable != null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 <= 21 ? i10 == 21 : ((q3) this.f1312d) != null) {
                if (((q3) this.f1314f) == null) {
                    this.f1314f = new Object();
                }
                q3 q3Var = (q3) this.f1314f;
                q3Var.f1478c = null;
                q3Var.f1477b = false;
                q3Var.f1479d = null;
                q3Var.f1476a = false;
                ColorStateList a10 = f.a((ImageView) this.f1311c);
                if (a10 != null) {
                    q3Var.f1477b = true;
                    q3Var.f1478c = a10;
                }
                PorterDuff.Mode b5 = f.b((ImageView) this.f1311c);
                if (b5 != null) {
                    q3Var.f1476a = true;
                    q3Var.f1479d = b5;
                }
                if (q3Var.f1477b || q3Var.f1476a) {
                    z.e(drawable, q3Var, ((ImageView) this.f1311c).getDrawableState());
                    return;
                }
            }
            q3 q3Var2 = (q3) this.f1313e;
            if (q3Var2 != null) {
                z.e(drawable, q3Var2, ((ImageView) this.f1311c).getDrawableState());
                return;
            }
            q3 q3Var3 = (q3) this.f1312d;
            if (q3Var3 != null) {
                z.e(drawable, q3Var3, ((ImageView) this.f1311c).getDrawableState());
            }
        }
    }

    public final void b(AttributeSet attributeSet, int i10) {
        Drawable drawable;
        Drawable drawable2;
        int B;
        Context context = ((ImageView) this.f1311c).getContext();
        int[] iArr = a.f18925g;
        w K = w.K(context, attributeSet, iArr, i10);
        ImageView imageView = (ImageView) this.f1311c;
        h1.q(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) K.f619c, i10);
        try {
            Drawable drawable3 = ((ImageView) this.f1311c).getDrawable();
            if (!(drawable3 != null || (B = K.B(1, -1)) == -1 || (drawable3 = y.e(((ImageView) this.f1311c).getContext(), B)) == null)) {
                ((ImageView) this.f1311c).setImageDrawable(drawable3);
            }
            if (drawable3 != null) {
                o1.a(drawable3);
            }
            if (K.G(2)) {
                ImageView imageView2 = (ImageView) this.f1311c;
                ColorStateList t10 = K.t(2);
                int i11 = Build.VERSION.SDK_INT;
                f.c(imageView2, t10);
                if (!(i11 != 21 || (drawable2 = imageView2.getDrawable()) == null || f.a(imageView2) == null)) {
                    if (drawable2.isStateful()) {
                        drawable2.setState(imageView2.getDrawableState());
                    }
                    imageView2.setImageDrawable(drawable2);
                }
            }
            if (K.G(3)) {
                ImageView imageView3 = (ImageView) this.f1311c;
                PorterDuff.Mode c10 = o1.c(K.z(3, -1), (PorterDuff.Mode) null);
                int i12 = Build.VERSION.SDK_INT;
                f.d(imageView3, c10);
                if (!(i12 != 21 || (drawable = imageView3.getDrawable()) == null || f.a(imageView3) == null)) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView3.getDrawableState());
                    }
                    imageView3.setImageDrawable(drawable);
                }
            }
            K.N();
        } catch (Throwable th2) {
            K.N();
            throw th2;
        }
    }

    public final void c(int i10) {
        if (i10 != 0) {
            Drawable e10 = y.e(((ImageView) this.f1311c).getContext(), i10);
            if (e10 != null) {
                o1.a(e10);
            }
            ((ImageView) this.f1311c).setImageDrawable(e10);
        } else {
            ((ImageView) this.f1311c).setImageDrawable((Drawable) null);
        }
        a();
    }

    public final String toString() {
        switch (this.f1309a) {
            case 2:
                StringBuilder sb2 = new StringBuilder(b0.DEFAULT_DRAG_ANIMATION_DURATION);
                sb2.append("<<\n mode: ");
                sb2.append((e) this.f1311c);
                sb2.append("\n ecLevel: ");
                sb2.append((c) this.f1312d);
                sb2.append("\n version: ");
                sb2.append((g) this.f1313e);
                sb2.append("\n maskPattern: ");
                sb2.append(this.f1310b);
                if (((b) this.f1314f) == null) {
                    sb2.append("\n matrix: null\n");
                } else {
                    sb2.append("\n matrix:\n");
                    sb2.append((b) this.f1314f);
                }
                sb2.append(">>\n");
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    /* JADX WARNING: type inference failed for: r1v6, types: [double[], java.io.Serializable] */
    public /* synthetic */ c0(r rVar) {
        this.f1309a = 1;
        int size = ((List) rVar.f25507c).size();
        this.f1311c = (String[]) ((List) rVar.f25506b).toArray(new String[size]);
        this.f1312d = d((List) rVar.f25507c);
        this.f1313e = d((List) rVar.f25508d);
        this.f1314f = new int[size];
        this.f1310b = 0;
    }
}
