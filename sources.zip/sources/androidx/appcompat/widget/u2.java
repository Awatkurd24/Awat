package androidx.appcompat.widget;

import android.database.Cursor;
import w1.b;

public final class u2 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1519a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ SearchView f1520b;

    public /* synthetic */ u2(SearchView searchView, int i10) {
        this.f1519a = i10;
        this.f1520b = searchView;
    }

    public final void run() {
        int i10 = this.f1519a;
        SearchView searchView = this.f1520b;
        switch (i10) {
            case 0:
                searchView.u();
                return;
            default:
                b bVar = searchView.f1204p0;
                if (bVar instanceof k3) {
                    bVar.b((Cursor) null);
                    return;
                }
                return;
        }
    }
}
