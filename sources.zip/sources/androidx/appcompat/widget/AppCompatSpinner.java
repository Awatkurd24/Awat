package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.c;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import co.vpn.plusvpn.R;
import m.e;
import u7.y;

public class AppCompatSpinner extends Spinner {

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f1117i = {16843505};

    /* renamed from: a  reason: collision with root package name */
    public final x f1118a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f1119b;

    /* renamed from: c  reason: collision with root package name */
    public final k f1120c;

    /* renamed from: d  reason: collision with root package name */
    public SpinnerAdapter f1121d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f1122e;

    /* renamed from: f  reason: collision with root package name */
    public final p0 f1123f;

    /* renamed from: g  reason: collision with root package name */
    public int f1124g;

    /* renamed from: h  reason: collision with root package name */
    public final Rect f1125h;

    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Object();

        /* renamed from: a  reason: collision with root package name */
        public boolean f1126a;

        public final void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeByte(this.f1126a ? (byte) 1 : 0);
        }
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.spinnerStyle);
    }

    public final int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i10 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i11 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i10) {
                view = null;
                i10 = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i11 = Math.max(i11, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i11;
        }
        Rect rect = this.f1125h;
        drawable.getPadding(rect);
        return i11 + rect.left + rect.right;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1118a;
        if (xVar != null) {
            xVar.a();
        }
    }

    public int getDropDownHorizontalOffset() {
        p0 p0Var = this.f1123f;
        return p0Var != null ? p0Var.b() : super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        p0 p0Var = this.f1123f;
        return p0Var != null ? p0Var.m() : super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        return this.f1123f != null ? this.f1124g : super.getDropDownWidth();
    }

    public final p0 getInternalPopup() {
        return this.f1123f;
    }

    public Drawable getPopupBackground() {
        p0 p0Var = this.f1123f;
        return p0Var != null ? p0Var.d() : super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.f1119b;
    }

    public CharSequence getPrompt() {
        p0 p0Var = this.f1123f;
        return p0Var != null ? p0Var.o() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1118a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1118a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        p0 p0Var = this.f1123f;
        if (p0Var != null && p0Var.a()) {
            p0Var.dismiss();
        }
    }

    public final void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        if (this.f1123f != null && View.MeasureSpec.getMode(i10) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i10)), getMeasuredHeight());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.f1126a && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new e(3, this));
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.View$BaseSavedState, android.os.Parcelable, androidx.appcompat.widget.AppCompatSpinner$SavedState] */
    public final Parcelable onSaveInstanceState() {
        boolean z4;
        ? baseSavedState = new View.BaseSavedState(super.onSaveInstanceState());
        p0 p0Var = this.f1123f;
        if (p0Var == null || !p0Var.a()) {
            z4 = false;
        } else {
            z4 = true;
        }
        baseSavedState.f1126a = z4;
        return baseSavedState;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        k kVar = this.f1120c;
        if (kVar == null || !kVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public final boolean performClick() {
        p0 p0Var = this.f1123f;
        if (p0Var == null) {
            return super.performClick();
        }
        if (p0Var.a()) {
            return true;
        }
        this.f1123f.l(i0.b(this), i0.a(this));
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1118a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1118a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public void setDropDownHorizontalOffset(int i10) {
        p0 p0Var = this.f1123f;
        if (p0Var != null) {
            p0Var.j(i10);
            p0Var.k(i10);
            return;
        }
        super.setDropDownHorizontalOffset(i10);
    }

    public void setDropDownVerticalOffset(int i10) {
        p0 p0Var = this.f1123f;
        if (p0Var != null) {
            p0Var.i(i10);
        } else {
            super.setDropDownVerticalOffset(i10);
        }
    }

    public void setDropDownWidth(int i10) {
        if (this.f1123f != null) {
            this.f1124g = i10;
        } else {
            super.setDropDownWidth(i10);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        p0 p0Var = this.f1123f;
        if (p0Var != null) {
            p0Var.g(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i10) {
        setPopupBackgroundDrawable(y.e(getPopupContext(), i10));
    }

    public void setPrompt(CharSequence charSequence) {
        p0 p0Var = this.f1123f;
        if (p0Var != null) {
            p0Var.f(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1118a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1118a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0059, code lost:
        if (r5 != null) goto L_0x0049;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00d0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatSpinner(android.content.Context r11, android.util.AttributeSet r12, int r13) {
        /*
            r10 = this;
            r10.<init>(r11, r12, r13)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r10.f1125h = r0
            android.content.Context r0 = r10.getContext()
            androidx.appcompat.widget.o3.a(r0, r10)
            int[] r0 = g.a.f18942x
            r1 = 0
            android.content.res.TypedArray r2 = r11.obtainStyledAttributes(r12, r0, r13, r1)
            androidx.appcompat.widget.x r3 = new androidx.appcompat.widget.x
            r3.<init>((android.view.View) r10)
            r10.f1118a = r3
            r3 = 4
            int r3 = r2.getResourceId(r3, r1)
            if (r3 == 0) goto L_0x002e
            l.e r4 = new l.e
            r4.<init>(r11, r3)
            r10.f1119b = r4
            goto L_0x0030
        L_0x002e:
            r10.f1119b = r11
        L_0x0030:
            r3 = -1
            r4 = 0
            int[] r5 = f1117i     // Catch:{ Exception -> 0x0050, all -> 0x004d }
            android.content.res.TypedArray r5 = r11.obtainStyledAttributes(r12, r5, r13, r1)     // Catch:{ Exception -> 0x0050, all -> 0x004d }
            boolean r6 = r5.hasValue(r1)     // Catch:{ Exception -> 0x0047 }
            if (r6 == 0) goto L_0x0049
            int r3 = r5.getInt(r1, r1)     // Catch:{ Exception -> 0x0047 }
            goto L_0x0049
        L_0x0043:
            r11 = move-exception
            r4 = r5
            goto L_0x00ce
        L_0x0047:
            r6 = move-exception
            goto L_0x0052
        L_0x0049:
            r5.recycle()
            goto L_0x005c
        L_0x004d:
            r11 = move-exception
            goto L_0x00ce
        L_0x0050:
            r6 = move-exception
            r5 = r4
        L_0x0052:
            java.lang.String r7 = "AppCompatSpinner"
            java.lang.String r8 = "Could not read android:spinnerMode"
            android.util.Log.i(r7, r8, r6)     // Catch:{ all -> 0x0043 }
            if (r5 == 0) goto L_0x005c
            goto L_0x0049
        L_0x005c:
            r5 = 2
            r6 = 1
            if (r3 == 0) goto L_0x0096
            if (r3 == r6) goto L_0x0063
            goto L_0x00a3
        L_0x0063:
            androidx.appcompat.widget.n0 r3 = new androidx.appcompat.widget.n0
            android.content.Context r7 = r10.f1119b
            r3.<init>(r10, r7, r12, r13)
            android.content.Context r7 = r10.f1119b
            a4.w r0 = a4.w.K(r7, r12, r0, r13)
            java.lang.Object r7 = r0.f619c
            android.content.res.TypedArray r7 = (android.content.res.TypedArray) r7
            r8 = 3
            r9 = -2
            int r7 = r7.getLayoutDimension(r8, r9)
            r10.f1124g = r7
            android.graphics.drawable.Drawable r7 = r0.w(r6)
            r3.g(r7)
            java.lang.String r5 = r2.getString(r5)
            r3.D = r5
            r0.N()
            r10.f1123f = r3
            androidx.appcompat.widget.k r0 = new androidx.appcompat.widget.k
            r0.<init>(r10, r10, r3, r6)
            r10.f1120c = r0
            goto L_0x00a3
        L_0x0096:
            androidx.appcompat.widget.k0 r0 = new androidx.appcompat.widget.k0
            r0.<init>(r10)
            r10.f1123f = r0
            java.lang.String r3 = r2.getString(r5)
            r0.f1382c = r3
        L_0x00a3:
            java.lang.CharSequence[] r0 = r2.getTextArray(r1)
            if (r0 == 0) goto L_0x00ba
            android.widget.ArrayAdapter r1 = new android.widget.ArrayAdapter
            r3 = 17367048(0x1090008, float:2.5162948E-38)
            r1.<init>(r11, r3, r0)
            r11 = 2131558607(0x7f0d00cf, float:1.8742535E38)
            r1.setDropDownViewResource(r11)
            r10.setAdapter((android.widget.SpinnerAdapter) r1)
        L_0x00ba:
            r2.recycle()
            r10.f1122e = r6
            android.widget.SpinnerAdapter r11 = r10.f1121d
            if (r11 == 0) goto L_0x00c8
            r10.setAdapter((android.widget.SpinnerAdapter) r11)
            r10.f1121d = r4
        L_0x00c8:
            androidx.appcompat.widget.x r11 = r10.f1118a
            r11.f(r12, r13)
            return
        L_0x00ce:
            if (r4 == 0) goto L_0x00d3
            r4.recycle()
        L_0x00d3:
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSpinner.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [androidx.appcompat.widget.l0, android.widget.ListAdapter, java.lang.Object] */
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f1122e) {
            this.f1121d = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        p0 p0Var = this.f1123f;
        if (p0Var != null) {
            Context context = this.f1119b;
            if (context == null) {
                context = getContext();
            }
            Resources.Theme theme = context.getTheme();
            ? obj = new Object();
            obj.f1406a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                obj.f1407b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null && Build.VERSION.SDK_INT >= 23 && c.x(spinnerAdapter)) {
                j0.a(c.p(spinnerAdapter), theme);
            }
            p0Var.p(obj);
        }
    }
}
