package androidx.appcompat.widget;

import android.content.res.Configuration;

public abstract class j2 {
    public static int a(Configuration configuration) {
        return configuration.getLayoutDirection();
    }
}
