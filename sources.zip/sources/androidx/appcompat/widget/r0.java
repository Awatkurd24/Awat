package androidx.appcompat.widget;

import android.graphics.Typeface;
import android.os.Build;
import android.widget.TextView;
import i1.b;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import r1.h1;
import r1.s0;

public final class r0 extends b {

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ int f1480e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f1481f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ WeakReference f1482g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ y0 f1483h;

    public r0(y0 y0Var, int i10, int i11, WeakReference weakReference) {
        this.f1483h = y0Var;
        this.f1480e = i10;
        this.f1481f = i11;
        this.f1482g = weakReference;
    }

    public final void e(int i10) {
    }

    public final void f(Typeface typeface) {
        int i10;
        boolean z4;
        if (Build.VERSION.SDK_INT >= 28 && (i10 = this.f1480e) != -1) {
            if ((this.f1481f & 2) != 0) {
                z4 = true;
            } else {
                z4 = false;
            }
            typeface = x0.a(typeface, i10, z4);
        }
        y0 y0Var = this.f1483h;
        if (y0Var.f1568m) {
            y0Var.f1567l = typeface;
            TextView textView = (TextView) this.f1482g.get();
            if (textView != null) {
                WeakHashMap weakHashMap = h1.f25195a;
                if (s0.b(textView)) {
                    textView.post(new s0(y0Var, textView, typeface, y0Var.f1565j));
                } else {
                    textView.setTypeface(typeface, y0Var.f1565j);
                }
            }
        }
    }
}
