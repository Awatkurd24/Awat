package androidx.appcompat.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import androidx.appcompat.widget.AppCompatSpinner;

public final class o0 implements Parcelable.Creator {
    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.View$BaseSavedState, androidx.appcompat.widget.AppCompatSpinner$SavedState, java.lang.Object] */
    public final Object createFromParcel(Parcel parcel) {
        boolean z4;
        ? baseSavedState = new View.BaseSavedState(parcel);
        if (parcel.readByte() != 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        baseSavedState.f1126a = z4;
        return baseSavedState;
    }

    public final Object[] newArray(int i10) {
        return new AppCompatSpinner.SavedState[i10];
    }
}
