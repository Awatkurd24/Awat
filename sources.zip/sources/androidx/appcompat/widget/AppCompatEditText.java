package androidx.appcompat.widget;

import a4.e;
import a4.m;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import j2.b;
import r1.d0;
import r1.f;
import r1.g;
import r1.h1;
import r1.i;
import v1.t;
import v1.v;
import v7.je;
import w7.wa;

public class AppCompatEditText extends EditText implements d0, v {

    /* renamed from: a  reason: collision with root package name */
    public final x f1095a;

    /* renamed from: b  reason: collision with root package name */
    public final y0 f1096b;

    /* renamed from: c  reason: collision with root package name */
    public final m f1097c = new m((TextView) this);

    /* renamed from: d  reason: collision with root package name */
    public final t f1098d = new Object();

    /* renamed from: e  reason: collision with root package name */
    public final e f1099e;

    /* renamed from: f  reason: collision with root package name */
    public a0 f1100f;

    /* JADX WARNING: type inference failed for: r4v5, types: [v1.t, java.lang.Object] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        o3.a(getContext(), this);
        x xVar = new x((View) this);
        this.f1095a = xVar;
        xVar.f(attributeSet, i10);
        y0 y0Var = new y0(this);
        this.f1096b = y0Var;
        y0Var.f(attributeSet, i10);
        y0Var.b();
        e eVar = new e((EditText) this);
        this.f1099e = eVar;
        eVar.u(attributeSet, i10);
        KeyListener keyListener = getKeyListener();
        if (!(keyListener instanceof NumberKeyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener r4 = eVar.r(keyListener);
            if (r4 != keyListener) {
                super.setKeyListener(r4);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    private a0 getSuperCaller() {
        if (this.f1100f == null) {
            this.f1100f = new a0(this);
        }
        return this.f1100f;
    }

    public final i a(i iVar) {
        return this.f1098d.a(this, iVar);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1095a;
        if (xVar != null) {
            xVar.a();
        }
        y0 y0Var = this.f1096b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return je.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1095a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1095a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1096b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1096b.e();
    }

    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    public TextClassifier getTextClassifier() {
        m mVar;
        if (Build.VERSION.SDK_INT >= 28 || (mVar = this.f1097c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) mVar.f559c;
        if (textClassifier == null) {
            return q0.a((TextView) mVar.f558b);
        }
        return textClassifier;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0056, code lost:
        if (r1 != null) goto L_0x0058;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x006b, code lost:
        if (r1 != null) goto L_0x0058;
     */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0072  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo r8) {
        /*
            r7 = this;
            android.view.inputmethod.InputConnection r0 = super.onCreateInputConnection(r8)
            androidx.appcompat.widget.y0 r1 = r7.f1096b
            r1.getClass()
            androidx.appcompat.widget.y0.h(r7, r0, r8)
            yg.b0.x(r7, r8, r0)
            if (r0 == 0) goto L_0x0078
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 30
            if (r1 > r2) goto L_0x0078
            java.lang.String[] r2 = r1.h1.h(r7)
            if (r2 == 0) goto L_0x0078
            java.lang.String r3 = "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            java.lang.String r4 = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            r5 = 25
            if (r1 < r5) goto L_0x0029
            r8.contentMimeTypes = r2
            goto L_0x003e
        L_0x0029:
            android.os.Bundle r6 = r8.extras
            if (r6 != 0) goto L_0x0034
            android.os.Bundle r6 = new android.os.Bundle
            r6.<init>()
            r8.extras = r6
        L_0x0034:
            android.os.Bundle r6 = r8.extras
            r6.putStringArray(r4, r2)
            android.os.Bundle r6 = r8.extras
            r6.putStringArray(r3, r2)
        L_0x003e:
            t.f r2 = new t.f
            r6 = 12
            r2.<init>(r6, r7)
            if (r1 < r5) goto L_0x004e
            u1.d r1 = new u1.d
            r1.<init>(r0, r2)
        L_0x004c:
            r0 = r1
            goto L_0x0078
        L_0x004e:
            java.lang.String[] r6 = u1.c.f26991a
            if (r1 < r5) goto L_0x005a
            java.lang.String[] r1 = r8.contentMimeTypes
            if (r1 == 0) goto L_0x006e
        L_0x0058:
            r6 = r1
            goto L_0x006e
        L_0x005a:
            android.os.Bundle r1 = r8.extras
            if (r1 != 0) goto L_0x005f
            goto L_0x006e
        L_0x005f:
            java.lang.String[] r1 = r1.getStringArray(r4)
            if (r1 != 0) goto L_0x006b
            android.os.Bundle r1 = r8.extras
            java.lang.String[] r1 = r1.getStringArray(r3)
        L_0x006b:
            if (r1 == 0) goto L_0x006e
            goto L_0x0058
        L_0x006e:
            int r1 = r6.length
            if (r1 != 0) goto L_0x0072
            goto L_0x0078
        L_0x0072:
            u1.e r1 = new u1.e
            r1.<init>(r0, r2)
            goto L_0x004c
        L_0x0078:
            a4.e r1 = r7.f1099e
            android.view.inputmethod.InputConnection r8 = r1.v(r0, r8)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatEditText.onCreateInputConnection(android.view.inputmethod.EditorInfo):android.view.inputmethod.InputConnection");
    }

    public final boolean onDragEvent(DragEvent dragEvent) {
        Activity activity;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 31 && i10 >= 24 && dragEvent.getLocalState() == null && h1.h(this) != null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                } else if (context instanceof Activity) {
                    activity = (Activity) context;
                    break;
                } else {
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
            if (activity == null) {
                Log.i("ReceiveContent", "Can't handle drop: no activity: view=" + this);
            } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3 && f0.a(dragEvent, this, activity)) {
                return true;
            }
        }
        return super.onDragEvent(dragEvent);
    }

    public final boolean onTextContextMenuItem(int i10) {
        ClipData clipData;
        f fVar;
        int i11;
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 31 || h1.h(this) == null || (i10 != 16908322 && i10 != 16908337)) {
            return super.onTextContextMenuItem(i10);
        }
        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
        if (clipboardManager == null) {
            clipData = null;
        } else {
            clipData = clipboardManager.getPrimaryClip();
        }
        if (clipData != null && clipData.getItemCount() > 0) {
            if (i12 >= 31) {
                fVar = new r1.e(clipData, 1);
            } else {
                fVar = new g(clipData, 1);
            }
            if (i10 == 16908322) {
                i11 = 0;
            } else {
                i11 = 1;
            }
            fVar.d(i11);
            h1.n(this, fVar.a());
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1095a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1095a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1096b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1096b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(je.s(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        ((wa) ((b) this.f1099e.f542c).f20593d).o(z4);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1099e.r(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1095a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1095a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        y0 y0Var = this.f1096b;
        y0Var.l(colorStateList);
        y0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        y0 y0Var = this.f1096b;
        y0Var.m(mode);
        y0Var.b();
    }

    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        y0 y0Var = this.f1096b;
        if (y0Var != null) {
            y0Var.g(context, i10);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        m mVar;
        if (Build.VERSION.SDK_INT >= 28 || (mVar = this.f1097c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            mVar.f559c = textClassifier;
        }
    }
}
