package androidx.appcompat.widget;

import android.content.Context;
import android.view.View;
import co.vpn.plusvpn.R;
import h.z;
import m.a0;
import m.i0;
import m.o;
import m.x;

public final class h extends a0 {

    /* renamed from: m  reason: collision with root package name */
    public final /* synthetic */ int f1346m = 0;

    /* renamed from: n  reason: collision with root package name */
    public final /* synthetic */ n f1347n;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(n nVar, Context context, o oVar, l lVar) {
        super(R.attr.actionOverflowMenuStyle, 0, context, lVar, oVar, true);
        this.f1347n = nVar;
        this.f22210g = 8388613;
        z zVar = nVar.f1441x;
        this.f22212i = zVar;
        x xVar = this.f22213j;
        if (xVar != null) {
            xVar.l(zVar);
        }
    }

    public final void c() {
        int i10 = this.f1346m;
        n nVar = this.f1347n;
        switch (i10) {
            case 0:
                nVar.f1438u = null;
                nVar.f1442y = 0;
                super.c();
                return;
            default:
                o oVar = nVar.f1420c;
                if (oVar != null) {
                    oVar.c(true);
                }
                nVar.f1437t = null;
                super.c();
                return;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(n nVar, Context context, i0 i0Var, View view) {
        super(R.attr.actionOverflowMenuStyle, 0, context, view, i0Var, false);
        this.f1347n = nVar;
        if (!i0Var.A.f()) {
            View view2 = nVar.f1427j;
            this.f22209f = view2 == null ? (View) nVar.f1425h : view2;
        }
        z zVar = nVar.f1441x;
        this.f22212i = zVar;
        x xVar = this.f22213j;
        if (xVar != null) {
            xVar.l(zVar);
        }
    }
}
