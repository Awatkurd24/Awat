package androidx.appcompat.widget;

import android.content.Context;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import l.c;
import m.c0;
import m.i0;
import m.o;
import m.q;

public final class u3 implements c0 {

    /* renamed from: a  reason: collision with root package name */
    public o f1521a;

    /* renamed from: b  reason: collision with root package name */
    public q f1522b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1523c;

    public u3(Toolbar toolbar) {
        this.f1523c = toolbar;
    }

    public final void b(o oVar, boolean z4) {
    }

    public final void d(Parcelable parcelable) {
    }

    public final void f(boolean z4) {
        if (this.f1522b != null) {
            o oVar = this.f1521a;
            if (oVar != null) {
                int size = oVar.f22300f.size();
                int i10 = 0;
                while (i10 < size) {
                    if (this.f1521a.getItem(i10) != this.f1522b) {
                        i10++;
                    } else {
                        return;
                    }
                }
            }
            m(this.f1522b);
        }
    }

    public final boolean g(q qVar) {
        Toolbar toolbar = this.f1523c;
        toolbar.c();
        ViewParent parent = toolbar.f1254h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f1254h);
            }
            toolbar.addView(toolbar.f1254h);
        }
        View actionView = qVar.getActionView();
        toolbar.f1255i = actionView;
        this.f1522b = qVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f1255i);
            }
            v3 h10 = Toolbar.h();
            h10.f19252a = (toolbar.f1260n & 112) | 8388611;
            h10.f1526b = 2;
            toolbar.f1255i.setLayoutParams(h10);
            toolbar.addView(toolbar.f1255i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (!(((v3) childAt.getLayoutParams()).f1526b == 2 || childAt == toolbar.f1247a)) {
                toolbar.removeViewAt(childCount);
                toolbar.E.add(childAt);
            }
        }
        toolbar.requestLayout();
        qVar.C = true;
        qVar.f22335n.p(false);
        View view = toolbar.f1255i;
        if (view instanceof c) {
            ((c) view).a();
        }
        toolbar.x();
        return true;
    }

    public final int getId() {
        return 0;
    }

    public final void h(Context context, o oVar) {
        q qVar;
        o oVar2 = this.f1521a;
        if (!(oVar2 == null || (qVar = this.f1522b) == null)) {
            oVar2.d(qVar);
        }
        this.f1521a = oVar;
    }

    public final boolean i() {
        return false;
    }

    public final Parcelable j() {
        return null;
    }

    public final boolean k(i0 i0Var) {
        return false;
    }

    public final boolean m(q qVar) {
        Toolbar toolbar = this.f1523c;
        View view = toolbar.f1255i;
        if (view instanceof c) {
            ((c) view).e();
        }
        toolbar.removeView(toolbar.f1255i);
        toolbar.removeView(toolbar.f1254h);
        toolbar.f1255i = null;
        ArrayList arrayList = toolbar.E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.f1522b = null;
        toolbar.requestLayout();
        qVar.C = false;
        qVar.f22335n.p(false);
        toolbar.x();
        return true;
    }
}
