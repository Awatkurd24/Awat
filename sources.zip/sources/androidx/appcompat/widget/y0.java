package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import g.a;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import u1.b;
import u1.c;

public final class y0 {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1556a;

    /* renamed from: b  reason: collision with root package name */
    public q3 f1557b;

    /* renamed from: c  reason: collision with root package name */
    public q3 f1558c;

    /* renamed from: d  reason: collision with root package name */
    public q3 f1559d;

    /* renamed from: e  reason: collision with root package name */
    public q3 f1560e;

    /* renamed from: f  reason: collision with root package name */
    public q3 f1561f;

    /* renamed from: g  reason: collision with root package name */
    public q3 f1562g;

    /* renamed from: h  reason: collision with root package name */
    public q3 f1563h;

    /* renamed from: i  reason: collision with root package name */
    public final i1 f1564i;

    /* renamed from: j  reason: collision with root package name */
    public int f1565j = 0;

    /* renamed from: k  reason: collision with root package name */
    public int f1566k = -1;

    /* renamed from: l  reason: collision with root package name */
    public Typeface f1567l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1568m;

    public y0(TextView textView) {
        this.f1556a = textView;
        this.f1564i = new i1(textView);
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [androidx.appcompat.widget.q3, java.lang.Object] */
    public static q3 c(Context context, z zVar, int i10) {
        ColorStateList i11;
        synchronized (zVar) {
            i11 = zVar.f1587a.i(context, i10);
        }
        if (i11 == null) {
            return null;
        }
        ? obj = new Object();
        obj.f1477b = true;
        obj.f1478c = i11;
        return obj;
    }

    public static void h(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
        int i10;
        int i11;
        int i12;
        CharSequence charSequence;
        int i13 = Build.VERSION.SDK_INT;
        if (i13 < 30 && inputConnection != null) {
            CharSequence text = textView.getText();
            if (i13 >= 30) {
                b.a(editorInfo, text);
                return;
            }
            text.getClass();
            if (i13 >= 30) {
                b.a(editorInfo, text);
                return;
            }
            int i14 = editorInfo.initialSelStart;
            int i15 = editorInfo.initialSelEnd;
            if (i14 > i15) {
                i10 = i15;
            } else {
                i10 = i14;
            }
            if (i14 <= i15) {
                i14 = i15;
            }
            int length = text.length();
            if (i10 < 0 || i14 > length || (i11 = editorInfo.inputType & 4095) == 129 || i11 == 225 || i11 == 18) {
                c.a(editorInfo, (CharSequence) null, 0, 0);
            } else if (length <= 2048) {
                c.a(editorInfo, text, i10, i14);
            } else {
                int i16 = i14 - i10;
                if (i16 > 1024) {
                    i12 = 0;
                } else {
                    i12 = i16;
                }
                int i17 = 2048 - i12;
                int min = Math.min(text.length() - i14, i17 - Math.min(i10, (int) (((double) i17) * 0.8d)));
                int min2 = Math.min(i10, i17 - min);
                int i18 = i10 - min2;
                if (Character.isLowSurrogate(text.charAt(i18))) {
                    i18++;
                    min2--;
                }
                if (Character.isHighSurrogate(text.charAt((i14 + min) - 1))) {
                    min--;
                }
                int i19 = min2 + i12;
                int i20 = i19 + min;
                if (i12 != i16) {
                    charSequence = TextUtils.concat(new CharSequence[]{text.subSequence(i18, i18 + min2), text.subSequence(i14, min + i14)});
                } else {
                    charSequence = text.subSequence(i18, i20 + i18);
                }
                c.a(editorInfo, charSequence, min2, i19);
            }
        }
    }

    public final void a(Drawable drawable, q3 q3Var) {
        if (drawable != null && q3Var != null) {
            z.e(drawable, q3Var, this.f1556a.getDrawableState());
        }
    }

    public final void b() {
        q3 q3Var = this.f1557b;
        TextView textView = this.f1556a;
        if (!(q3Var == null && this.f1558c == null && this.f1559d == null && this.f1560e == null)) {
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            a(compoundDrawables[0], this.f1557b);
            a(compoundDrawables[1], this.f1558c);
            a(compoundDrawables[2], this.f1559d);
            a(compoundDrawables[3], this.f1560e);
        }
        if (this.f1561f != null || this.f1562g != null) {
            Drawable[] a10 = t0.a(textView);
            a(a10[0], this.f1561f);
            a(a10[2], this.f1562g);
        }
    }

    public final ColorStateList d() {
        q3 q3Var = this.f1563h;
        if (q3Var != null) {
            return (ColorStateList) q3Var.f1478c;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        q3 q3Var = this.f1563h;
        if (q3Var != null) {
            return (PorterDuff.Mode) q3Var.f1479d;
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x00ff  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0106  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0113  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0118  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(android.util.AttributeSet r29, int r30) {
        /*
            r28 = this;
            r0 = r28
            r7 = r29
            r8 = r30
            android.widget.TextView r9 = r0.f1556a
            android.content.Context r10 = r9.getContext()
            androidx.appcompat.widget.z r11 = androidx.appcompat.widget.z.a()
            int[] r3 = g.a.f18927i
            a4.w r12 = a4.w.K(r10, r7, r3, r8)
            android.content.Context r2 = r9.getContext()
            java.lang.Object r1 = r12.f619c
            r5 = r1
            android.content.res.TypedArray r5 = (android.content.res.TypedArray) r5
            r1 = r9
            r4 = r29
            r6 = r30
            r1.h1.q(r1, r2, r3, r4, r5, r6)
            r13 = 0
            r14 = -1
            int r1 = r12.B(r13, r14)
            r15 = 3
            boolean r2 = r12.G(r15)
            if (r2 == 0) goto L_0x003e
            int r2 = r12.B(r15, r13)
            androidx.appcompat.widget.q3 r2 = c(r10, r11, r2)
            r0.f1557b = r2
        L_0x003e:
            r6 = 1
            boolean r2 = r12.G(r6)
            if (r2 == 0) goto L_0x004f
            int r2 = r12.B(r6, r13)
            androidx.appcompat.widget.q3 r2 = c(r10, r11, r2)
            r0.f1558c = r2
        L_0x004f:
            r5 = 4
            boolean r2 = r12.G(r5)
            if (r2 == 0) goto L_0x0060
            int r2 = r12.B(r5, r13)
            androidx.appcompat.widget.q3 r2 = c(r10, r11, r2)
            r0.f1559d = r2
        L_0x0060:
            r4 = 2
            boolean r2 = r12.G(r4)
            if (r2 == 0) goto L_0x0071
            int r2 = r12.B(r4, r13)
            androidx.appcompat.widget.q3 r2 = c(r10, r11, r2)
            r0.f1560e = r2
        L_0x0071:
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 5
            boolean r16 = r12.G(r3)
            if (r16 == 0) goto L_0x0084
            int r4 = r12.B(r3, r13)
            androidx.appcompat.widget.q3 r4 = c(r10, r11, r4)
            r0.f1561f = r4
        L_0x0084:
            r4 = 6
            boolean r17 = r12.G(r4)
            if (r17 == 0) goto L_0x0095
            int r6 = r12.B(r4, r13)
            androidx.appcompat.widget.q3 r6 = c(r10, r11, r6)
            r0.f1562g = r6
        L_0x0095:
            r12.N()
            android.text.method.TransformationMethod r6 = r9.getTransformationMethod()
            boolean r6 = r6 instanceof android.text.method.PasswordTransformationMethod
            int[] r12 = g.a.f18944z
            r4 = 23
            r3 = 14
            r5 = 15
            if (r1 == r14) goto L_0x011e
            a4.w r14 = new a4.w
            android.content.res.TypedArray r1 = r10.obtainStyledAttributes(r1, r12)
            r14.<init>((android.content.Context) r10, (android.content.res.TypedArray) r1)
            if (r6 != 0) goto L_0x00c0
            boolean r1 = r14.G(r3)
            if (r1 == 0) goto L_0x00c0
            boolean r1 = r14.r(r3, r13)
            r23 = 1
            goto L_0x00c3
        L_0x00c0:
            r1 = 0
            r23 = 0
        L_0x00c3:
            r0.n(r10, r14)
            if (r2 >= r4) goto L_0x00f4
            boolean r24 = r14.G(r15)
            if (r24 == 0) goto L_0x00d4
            android.content.res.ColorStateList r24 = r14.t(r15)
            r15 = 4
            goto L_0x00d7
        L_0x00d4:
            r15 = 4
            r24 = 0
        L_0x00d7:
            boolean r21 = r14.G(r15)
            if (r21 == 0) goto L_0x00e3
            android.content.res.ColorStateList r25 = r14.t(r15)
            r15 = 5
            goto L_0x00e6
        L_0x00e3:
            r15 = 5
            r25 = 0
        L_0x00e6:
            boolean r18 = r14.G(r15)
            if (r18 == 0) goto L_0x00f1
            android.content.res.ColorStateList r26 = r14.t(r15)
            goto L_0x00f9
        L_0x00f1:
            r26 = 0
            goto L_0x00f9
        L_0x00f4:
            r24 = 0
            r25 = 0
            goto L_0x00f1
        L_0x00f9:
            boolean r15 = r14.G(r5)
            if (r15 == 0) goto L_0x0106
            java.lang.String r15 = r14.C(r5)
            r5 = 26
            goto L_0x0109
        L_0x0106:
            r5 = 26
            r15 = 0
        L_0x0109:
            if (r2 < r5) goto L_0x0118
            r5 = 13
            boolean r22 = r14.G(r5)
            if (r22 == 0) goto L_0x0118
            java.lang.String r27 = r14.C(r5)
            goto L_0x011a
        L_0x0118:
            r27 = 0
        L_0x011a:
            r14.N()
            goto L_0x012a
        L_0x011e:
            r1 = 0
            r15 = 0
            r23 = 0
            r24 = 0
            r25 = 0
            r26 = 0
            r27 = 0
        L_0x012a:
            a4.w r5 = new a4.w
            android.content.res.TypedArray r12 = r10.obtainStyledAttributes(r7, r12, r8, r13)
            r5.<init>((android.content.Context) r10, (android.content.res.TypedArray) r12)
            if (r6 != 0) goto L_0x0141
            boolean r12 = r5.G(r3)
            if (r12 == 0) goto L_0x0141
            boolean r1 = r5.r(r3, r13)
            r23 = 1
        L_0x0141:
            if (r2 >= r4) goto L_0x0164
            r3 = 3
            boolean r4 = r5.G(r3)
            if (r4 == 0) goto L_0x014e
            android.content.res.ColorStateList r24 = r5.t(r3)
        L_0x014e:
            r12 = 4
            boolean r3 = r5.G(r12)
            if (r3 == 0) goto L_0x0159
            android.content.res.ColorStateList r25 = r5.t(r12)
        L_0x0159:
            r3 = 5
            boolean r4 = r5.G(r3)
            if (r4 == 0) goto L_0x0164
            android.content.res.ColorStateList r26 = r5.t(r3)
        L_0x0164:
            r4 = r24
            r14 = r25
            r3 = r26
            r12 = 15
            boolean r24 = r5.G(r12)
            if (r24 == 0) goto L_0x0176
            java.lang.String r15 = r5.C(r12)
        L_0x0176:
            r12 = 26
            if (r2 < r12) goto L_0x018b
            r12 = 13
            boolean r20 = r5.G(r12)
            if (r20 == 0) goto L_0x0186
            java.lang.String r27 = r5.C(r12)
        L_0x0186:
            r20 = r11
            r12 = r27
            goto L_0x018e
        L_0x018b:
            r12 = 13
            goto L_0x0186
        L_0x018e:
            r11 = 28
            if (r2 < r11) goto L_0x01a3
            boolean r11 = r5.G(r13)
            if (r11 == 0) goto L_0x01a3
            r11 = -1
            int r24 = r5.v(r13, r11)
            if (r24 != 0) goto L_0x01a3
            r11 = 0
            r9.setTextSize(r13, r11)
        L_0x01a3:
            r0.n(r10, r5)
            r5.N()
            if (r4 == 0) goto L_0x01ae
            r9.setTextColor(r4)
        L_0x01ae:
            if (r14 == 0) goto L_0x01b3
            r9.setHintTextColor(r14)
        L_0x01b3:
            if (r3 == 0) goto L_0x01b8
            r9.setLinkTextColor(r3)
        L_0x01b8:
            if (r6 != 0) goto L_0x01bf
            if (r23 == 0) goto L_0x01bf
            r9.setAllCaps(r1)
        L_0x01bf:
            android.graphics.Typeface r1 = r0.f1567l
            if (r1 == 0) goto L_0x01d1
            int r3 = r0.f1566k
            r4 = -1
            if (r3 != r4) goto L_0x01ce
            int r3 = r0.f1565j
            r9.setTypeface(r1, r3)
            goto L_0x01d1
        L_0x01ce:
            r9.setTypeface(r1)
        L_0x01d1:
            if (r12 == 0) goto L_0x01d6
            androidx.appcompat.widget.w0.d(r9, r12)
        L_0x01d6:
            r11 = 24
            if (r15 == 0) goto L_0x01f3
            if (r2 < r11) goto L_0x01e4
            android.os.LocaleList r1 = androidx.appcompat.widget.v0.a(r15)
            androidx.appcompat.widget.v0.b(r9, r1)
            goto L_0x01f3
        L_0x01e4:
            java.lang.String r1 = ","
            java.lang.String[] r1 = r15.split(r1)
            r1 = r1[r13]
            java.util.Locale r1 = androidx.appcompat.widget.u0.a(r1)
            androidx.appcompat.widget.t0.c(r9, r1)
        L_0x01f3:
            int[] r12 = g.a.f18928j
            androidx.appcompat.widget.i1 r14 = r0.f1564i
            android.content.Context r15 = r14.f1361j
            android.content.res.TypedArray r6 = r15.obtainStyledAttributes(r7, r12, r8, r13)
            android.widget.TextView r1 = r14.f1360i
            android.content.Context r2 = r1.getContext()
            r4 = 5
            r5 = 0
            r3 = r12
            r11 = 5
            r4 = r29
            r5 = r6
            r13 = r6
            r6 = r30
            r1.h1.q(r1, r2, r3, r4, r5, r6)
            boolean r1 = r13.hasValue(r11)
            if (r1 == 0) goto L_0x021d
            r1 = 0
            int r2 = r13.getInt(r11, r1)
            r14.f1352a = r2
        L_0x021d:
            r1 = 4
            boolean r2 = r13.hasValue(r1)
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r2 == 0) goto L_0x022c
            float r1 = r13.getDimension(r1, r3)
        L_0x022a:
            r2 = 2
            goto L_0x022f
        L_0x022c:
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            goto L_0x022a
        L_0x022f:
            boolean r4 = r13.hasValue(r2)
            if (r4 == 0) goto L_0x023b
            float r4 = r13.getDimension(r2, r3)
            r2 = 1
            goto L_0x023e
        L_0x023b:
            r2 = 1
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x023e:
            boolean r5 = r13.hasValue(r2)
            if (r5 == 0) goto L_0x024a
            float r5 = r13.getDimension(r2, r3)
        L_0x0248:
            r6 = 3
            goto L_0x024d
        L_0x024a:
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            goto L_0x0248
        L_0x024d:
            boolean r8 = r13.hasValue(r6)
            if (r8 == 0) goto L_0x0284
            r8 = 0
            int r11 = r13.getResourceId(r6, r8)
            if (r11 <= 0) goto L_0x0284
            android.content.res.Resources r6 = r13.getResources()
            android.content.res.TypedArray r6 = r6.obtainTypedArray(r11)
            int r8 = r6.length()
            int[] r11 = new int[r8]
            if (r8 <= 0) goto L_0x0281
            r3 = 0
        L_0x026b:
            if (r3 >= r8) goto L_0x0278
            r2 = -1
            int r19 = r6.getDimensionPixelSize(r3, r2)
            r11[r3] = r19
            int r3 = r3 + 1
            r2 = 1
            goto L_0x026b
        L_0x0278:
            int[] r2 = androidx.appcompat.widget.i1.b(r11)
            r14.f1357f = r2
            r14.i()
        L_0x0281:
            r6.recycle()
        L_0x0284:
            r13.recycle()
            boolean r2 = r14.j()
            r3 = 1065353216(0x3f800000, float:1.0)
            if (r2 == 0) goto L_0x02c6
            int r2 = r14.f1352a
            r6 = 1
            if (r2 != r6) goto L_0x02c9
            boolean r2 = r14.f1358g
            if (r2 != 0) goto L_0x02c2
            android.content.res.Resources r2 = r15.getResources()
            android.util.DisplayMetrics r2 = r2.getDisplayMetrics()
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r8 != 0) goto L_0x02ae
            r4 = 1094713344(0x41400000, float:12.0)
            r8 = 2
            float r4 = android.util.TypedValue.applyDimension(r8, r4, r2)
            goto L_0x02af
        L_0x02ae:
            r8 = 2
        L_0x02af:
            int r11 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r11 != 0) goto L_0x02b9
            r5 = 1121976320(0x42e00000, float:112.0)
            float r5 = android.util.TypedValue.applyDimension(r8, r5, r2)
        L_0x02b9:
            int r2 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r2 != 0) goto L_0x02bf
            r1 = 1065353216(0x3f800000, float:1.0)
        L_0x02bf:
            r14.k(r4, r5, r1)
        L_0x02c2:
            r14.h()
            goto L_0x02c9
        L_0x02c6:
            r1 = 0
            r14.f1352a = r1
        L_0x02c9:
            boolean r1 = androidx.appcompat.widget.f4.f1339b
            if (r1 == 0) goto L_0x02fc
            int r1 = r14.f1352a
            if (r1 == 0) goto L_0x02fc
            int[] r1 = r14.f1357f
            int r2 = r1.length
            if (r2 <= 0) goto L_0x02fc
            int r2 = androidx.appcompat.widget.w0.a(r9)
            float r2 = (float) r2
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 == 0) goto L_0x02f8
            float r1 = r14.f1355d
            int r1 = java.lang.Math.round(r1)
            float r2 = r14.f1356e
            int r2 = java.lang.Math.round(r2)
            float r4 = r14.f1354c
            int r4 = java.lang.Math.round(r4)
            r5 = 0
            androidx.appcompat.widget.w0.b(r9, r1, r2, r4, r5)
            goto L_0x02fc
        L_0x02f8:
            r5 = 0
            androidx.appcompat.widget.w0.c(r9, r1, r5)
        L_0x02fc:
            a4.w r1 = new a4.w
            android.content.res.TypedArray r2 = r10.obtainStyledAttributes(r7, r12)
            r1.<init>((android.content.Context) r10, (android.content.res.TypedArray) r2)
            r2 = 8
            r4 = -1
            int r2 = r1.B(r2, r4)
            r5 = r20
            if (r2 == r4) goto L_0x0317
            android.graphics.drawable.Drawable r2 = r5.b(r10, r2)
        L_0x0314:
            r6 = 13
            goto L_0x0319
        L_0x0317:
            r2 = 0
            goto L_0x0314
        L_0x0319:
            int r6 = r1.B(r6, r4)
            if (r6 == r4) goto L_0x0324
            android.graphics.drawable.Drawable r6 = r5.b(r10, r6)
            goto L_0x0325
        L_0x0324:
            r6 = 0
        L_0x0325:
            r7 = 9
            int r7 = r1.B(r7, r4)
            if (r7 == r4) goto L_0x0333
            android.graphics.drawable.Drawable r7 = r5.b(r10, r7)
        L_0x0331:
            r8 = 6
            goto L_0x0335
        L_0x0333:
            r7 = 0
            goto L_0x0331
        L_0x0335:
            int r8 = r1.B(r8, r4)
            if (r8 == r4) goto L_0x0340
            android.graphics.drawable.Drawable r8 = r5.b(r10, r8)
            goto L_0x0341
        L_0x0340:
            r8 = 0
        L_0x0341:
            r11 = 10
            int r11 = r1.B(r11, r4)
            if (r11 == r4) goto L_0x034e
            android.graphics.drawable.Drawable r11 = r5.b(r10, r11)
            goto L_0x034f
        L_0x034e:
            r11 = 0
        L_0x034f:
            r12 = 7
            int r12 = r1.B(r12, r4)
            if (r12 == r4) goto L_0x035b
            android.graphics.drawable.Drawable r4 = r5.b(r10, r12)
            goto L_0x035c
        L_0x035b:
            r4 = 0
        L_0x035c:
            if (r11 != 0) goto L_0x03ab
            if (r4 == 0) goto L_0x0361
            goto L_0x03ab
        L_0x0361:
            if (r2 != 0) goto L_0x0369
            if (r6 != 0) goto L_0x0369
            if (r7 != 0) goto L_0x0369
            if (r8 == 0) goto L_0x03ca
        L_0x0369:
            android.graphics.drawable.Drawable[] r4 = androidx.appcompat.widget.t0.a(r9)
            r5 = 0
            r10 = r4[r5]
            if (r10 != 0) goto L_0x0397
            r11 = 2
            r12 = r4[r11]
            if (r12 == 0) goto L_0x0378
            goto L_0x0397
        L_0x0378:
            android.graphics.drawable.Drawable[] r4 = r9.getCompoundDrawables()
            if (r2 == 0) goto L_0x037f
            goto L_0x0381
        L_0x037f:
            r2 = r4[r5]
        L_0x0381:
            if (r6 == 0) goto L_0x0384
            goto L_0x0387
        L_0x0384:
            r5 = 1
            r6 = r4[r5]
        L_0x0387:
            if (r7 == 0) goto L_0x038a
            goto L_0x038d
        L_0x038a:
            r5 = 2
            r7 = r4[r5]
        L_0x038d:
            if (r8 == 0) goto L_0x0390
            goto L_0x0393
        L_0x0390:
            r5 = 3
            r8 = r4[r5]
        L_0x0393:
            r9.setCompoundDrawablesWithIntrinsicBounds(r2, r6, r7, r8)
            goto L_0x03ca
        L_0x0397:
            if (r6 == 0) goto L_0x039b
        L_0x0399:
            r2 = 2
            goto L_0x039f
        L_0x039b:
            r2 = 1
            r6 = r4[r2]
            goto L_0x0399
        L_0x039f:
            r2 = r4[r2]
            if (r8 == 0) goto L_0x03a4
            goto L_0x03a7
        L_0x03a4:
            r5 = 3
            r8 = r4[r5]
        L_0x03a7:
            androidx.appcompat.widget.t0.b(r9, r10, r6, r2, r8)
            goto L_0x03ca
        L_0x03ab:
            android.graphics.drawable.Drawable[] r2 = androidx.appcompat.widget.t0.a(r9)
            if (r11 == 0) goto L_0x03b2
            goto L_0x03b5
        L_0x03b2:
            r5 = 0
            r11 = r2[r5]
        L_0x03b5:
            if (r6 == 0) goto L_0x03b8
            goto L_0x03bb
        L_0x03b8:
            r5 = 1
            r6 = r2[r5]
        L_0x03bb:
            if (r4 == 0) goto L_0x03be
            goto L_0x03c1
        L_0x03be:
            r4 = 2
            r4 = r2[r4]
        L_0x03c1:
            if (r8 == 0) goto L_0x03c4
            goto L_0x03c7
        L_0x03c4:
            r5 = 3
            r8 = r2[r5]
        L_0x03c7:
            androidx.appcompat.widget.t0.b(r9, r11, r6, r4, r8)
        L_0x03ca:
            r2 = 11
            boolean r4 = r1.G(r2)
            if (r4 == 0) goto L_0x03ea
            android.content.res.ColorStateList r2 = r1.t(r2)
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 24
            if (r4 < r5) goto L_0x03e0
            v1.p.f(r9, r2)
            goto L_0x03ea
        L_0x03e0:
            boolean r4 = r9 instanceof v1.v
            if (r4 == 0) goto L_0x03ea
            r4 = r9
            v1.v r4 = (v1.v) r4
            r4.setSupportCompoundDrawablesTintList(r2)
        L_0x03ea:
            r2 = 12
            boolean r4 = r1.G(r2)
            if (r4 == 0) goto L_0x0414
            r4 = -1
            int r2 = r1.z(r2, r4)
            r4 = 0
            android.graphics.PorterDuff$Mode r2 = androidx.appcompat.widget.o1.c(r2, r4)
            int r5 = android.os.Build.VERSION.SDK_INT
            r6 = 24
            if (r5 < r6) goto L_0x0406
            v1.p.g(r9, r2)
            goto L_0x0410
        L_0x0406:
            boolean r5 = r9 instanceof v1.v
            if (r5 == 0) goto L_0x0410
            r5 = r9
            v1.v r5 = (v1.v) r5
            r5.setSupportCompoundDrawablesTintMode(r2)
        L_0x0410:
            r2 = -1
            r5 = 15
            goto L_0x0416
        L_0x0414:
            r4 = 0
            goto L_0x0410
        L_0x0416:
            int r5 = r1.v(r5, r2)
            r6 = 18
            int r6 = r1.v(r6, r2)
            r7 = 19
            int r7 = r1.v(r7, r2)
            r1.N()
            if (r5 == r2) goto L_0x042e
            v7.je.n(r9, r5)
        L_0x042e:
            if (r6 == r2) goto L_0x0433
            v7.je.o(r9, r6)
        L_0x0433:
            if (r7 == r2) goto L_0x0447
            w7.ua.e(r7)
            android.text.TextPaint r1 = r9.getPaint()
            int r1 = r1.getFontMetricsInt(r4)
            if (r7 == r1) goto L_0x0447
            int r7 = r7 - r1
            float r1 = (float) r7
            r9.setLineSpacing(r1, r3)
        L_0x0447:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.y0.f(android.util.AttributeSet, int):void");
    }

    public final void g(Context context, int i10) {
        String C;
        ColorStateList t10;
        ColorStateList t11;
        ColorStateList t12;
        w wVar = new w(context, context.obtainStyledAttributes(i10, a.f18944z));
        boolean G = wVar.G(14);
        TextView textView = this.f1556a;
        if (G) {
            textView.setAllCaps(wVar.r(14, false));
        }
        int i11 = Build.VERSION.SDK_INT;
        if (i11 < 23) {
            if (wVar.G(3) && (t12 = wVar.t(3)) != null) {
                textView.setTextColor(t12);
            }
            if (wVar.G(5) && (t11 = wVar.t(5)) != null) {
                textView.setLinkTextColor(t11);
            }
            if (wVar.G(4) && (t10 = wVar.t(4)) != null) {
                textView.setHintTextColor(t10);
            }
        }
        if (wVar.G(0) && wVar.v(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        n(context, wVar);
        if (i11 >= 26 && wVar.G(13) && (C = wVar.C(13)) != null) {
            w0.d(textView, C);
        }
        wVar.N();
        Typeface typeface = this.f1567l;
        if (typeface != null) {
            textView.setTypeface(typeface, this.f1565j);
        }
    }

    public final void i(int i10, int i11, int i12, int i13) {
        i1 i1Var = this.f1564i;
        if (i1Var.j()) {
            DisplayMetrics displayMetrics = i1Var.f1361j.getResources().getDisplayMetrics();
            i1Var.k(TypedValue.applyDimension(i13, (float) i10, displayMetrics), TypedValue.applyDimension(i13, (float) i11, displayMetrics), TypedValue.applyDimension(i13, (float) i12, displayMetrics));
            if (i1Var.h()) {
                i1Var.a();
            }
        }
    }

    public final void j(int[] iArr, int i10) {
        i1 i1Var = this.f1564i;
        if (i1Var.j()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i10 == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = i1Var.f1361j.getResources().getDisplayMetrics();
                    for (int i11 = 0; i11 < length; i11++) {
                        iArr2[i11] = Math.round(TypedValue.applyDimension(i10, (float) iArr[i11], displayMetrics));
                    }
                }
                i1Var.f1357f = i1.b(iArr2);
                if (!i1Var.i()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                i1Var.f1358g = false;
            }
            if (i1Var.h()) {
                i1Var.a();
            }
        }
    }

    public final void k(int i10) {
        i1 i1Var = this.f1564i;
        if (!i1Var.j()) {
            return;
        }
        if (i10 == 0) {
            i1Var.f1352a = 0;
            i1Var.f1355d = -1.0f;
            i1Var.f1356e = -1.0f;
            i1Var.f1354c = -1.0f;
            i1Var.f1357f = new int[0];
            i1Var.f1353b = false;
        } else if (i10 == 1) {
            DisplayMetrics displayMetrics = i1Var.f1361j.getResources().getDisplayMetrics();
            i1Var.k(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (i1Var.h()) {
                i1Var.a();
            }
        } else {
            throw new IllegalArgumentException(f.c.n("Unknown auto-size text type: ", i10));
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [androidx.appcompat.widget.q3, java.lang.Object] */
    public final void l(ColorStateList colorStateList) {
        if (this.f1563h == null) {
            this.f1563h = new Object();
        }
        q3 q3Var = this.f1563h;
        q3Var.f1478c = colorStateList;
        q3Var.f1477b = colorStateList != null;
        this.f1557b = q3Var;
        this.f1558c = q3Var;
        this.f1559d = q3Var;
        this.f1560e = q3Var;
        this.f1561f = q3Var;
        this.f1562g = q3Var;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [androidx.appcompat.widget.q3, java.lang.Object] */
    public final void m(PorterDuff.Mode mode) {
        if (this.f1563h == null) {
            this.f1563h = new Object();
        }
        q3 q3Var = this.f1563h;
        q3Var.f1479d = mode;
        q3Var.f1476a = mode != null;
        this.f1557b = q3Var;
        this.f1558c = q3Var;
        this.f1559d = q3Var;
        this.f1560e = q3Var;
        this.f1561f = q3Var;
        this.f1562g = q3Var;
    }

    public final void n(Context context, w wVar) {
        String C;
        Typeface create;
        Typeface typeface;
        this.f1565j = wVar.z(2, this.f1565j);
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 28) {
            int z4 = wVar.z(11, -1);
            this.f1566k = z4;
            if (z4 != -1) {
                this.f1565j &= 2;
            }
        }
        int i11 = 10;
        boolean z10 = false;
        if (wVar.G(10) || wVar.G(12)) {
            this.f1567l = null;
            if (wVar.G(12)) {
                i11 = 12;
            }
            int i12 = this.f1566k;
            int i13 = this.f1565j;
            if (!context.isRestricted()) {
                try {
                    Typeface y10 = wVar.y(i11, this.f1565j, new r0(this, i12, i13, new WeakReference(this.f1556a)));
                    if (y10 != null) {
                        if (i10 >= 28 && this.f1566k != -1) {
                            y10 = x0.a(Typeface.create(y10, 0), this.f1566k, (this.f1565j & 2) != 0);
                        }
                        this.f1567l = y10;
                    }
                    this.f1568m = this.f1567l == null;
                } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f1567l == null && (C = wVar.C(i11)) != null) {
                if (Build.VERSION.SDK_INT < 28 || this.f1566k == -1) {
                    create = Typeface.create(C, this.f1565j);
                } else {
                    Typeface create2 = Typeface.create(C, 0);
                    int i14 = this.f1566k;
                    if ((this.f1565j & 2) != 0) {
                        z10 = true;
                    }
                    create = x0.a(create2, i14, z10);
                }
                this.f1567l = create;
            }
        } else if (wVar.G(1)) {
            this.f1568m = false;
            int z11 = wVar.z(1, 1);
            if (z11 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (z11 == 2) {
                typeface = Typeface.SERIF;
            } else if (z11 == 3) {
                typeface = Typeface.MONOSPACE;
            } else {
                return;
            }
            this.f1567l = typeface;
        }
    }
}
