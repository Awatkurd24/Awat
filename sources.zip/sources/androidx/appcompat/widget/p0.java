package androidx.appcompat.widget;

import android.graphics.drawable.Drawable;
import android.widget.ListAdapter;

public interface p0 {
    boolean a();

    int b();

    Drawable d();

    void dismiss();

    void f(CharSequence charSequence);

    void g(Drawable drawable);

    void i(int i10);

    void j(int i10);

    void k(int i10);

    void l(int i10, int i11);

    int m();

    CharSequence o();

    void p(ListAdapter listAdapter);
}
