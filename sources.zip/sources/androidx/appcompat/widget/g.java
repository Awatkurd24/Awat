package androidx.appcompat.widget;

import android.view.ViewGroup;

public final class g extends ViewGroup.MarginLayoutParams {
}
