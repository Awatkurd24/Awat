package androidx.appcompat.widget;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class m1 {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f1411a;

    /* renamed from: b  reason: collision with root package name */
    public static final Method f1412b;

    /* renamed from: c  reason: collision with root package name */
    public static final Field f1413c;

    /* renamed from: d  reason: collision with root package name */
    public static final Field f1414d;

    /* renamed from: e  reason: collision with root package name */
    public static final Field f1415e;

    /* renamed from: f  reason: collision with root package name */
    public static final Field f1416f;

    /* JADX WARNING: Removed duplicated region for block: B:43:0x0058  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0065  */
    static {
        /*
            r0 = 1
            r1 = 0
            r2 = 0
            java.lang.String r3 = "android.graphics.Insets"
            java.lang.Class r3 = java.lang.Class.forName(r3)     // Catch:{ NoSuchMethodException -> 0x0050, ClassNotFoundException -> 0x004c, NoSuchFieldException -> 0x0048 }
            java.lang.Class<android.graphics.drawable.Drawable> r4 = android.graphics.drawable.Drawable.class
            java.lang.String r5 = "getOpticalInsets"
            java.lang.Class[] r6 = new java.lang.Class[r2]     // Catch:{ NoSuchMethodException -> 0x0050, ClassNotFoundException -> 0x004c, NoSuchFieldException -> 0x0048 }
            java.lang.reflect.Method r4 = r4.getMethod(r5, r6)     // Catch:{ NoSuchMethodException -> 0x0050, ClassNotFoundException -> 0x004c, NoSuchFieldException -> 0x0048 }
            java.lang.String r5 = "left"
            java.lang.reflect.Field r5 = r3.getField(r5)     // Catch:{ NoSuchMethodException -> 0x0044, ClassNotFoundException -> 0x0040, NoSuchFieldException -> 0x003c }
            java.lang.String r6 = "top"
            java.lang.reflect.Field r6 = r3.getField(r6)     // Catch:{ NoSuchMethodException -> 0x0039, ClassNotFoundException -> 0x0036, NoSuchFieldException -> 0x0032 }
            java.lang.String r7 = "right"
            java.lang.reflect.Field r7 = r3.getField(r7)     // Catch:{ ClassNotFoundException | NoSuchFieldException | NoSuchMethodException -> 0x002f }
            java.lang.String r8 = "bottom"
            java.lang.reflect.Field r3 = r3.getField(r8)     // Catch:{ ClassNotFoundException | NoSuchFieldException | NoSuchMethodException -> 0x002d }
            r8 = 1
            goto L_0x0056
        L_0x002d:
            goto L_0x0054
        L_0x002f:
            r7 = r1
            goto L_0x0054
        L_0x0032:
            r6 = r1
        L_0x0034:
            r7 = r6
            goto L_0x0054
        L_0x0036:
            r6 = r1
            goto L_0x0034
        L_0x0039:
            r6 = r1
            goto L_0x0034
        L_0x003c:
            r5 = r1
        L_0x003e:
            r6 = r5
            goto L_0x0034
        L_0x0040:
            r5 = r1
        L_0x0042:
            r6 = r5
            goto L_0x0034
        L_0x0044:
            r5 = r1
        L_0x0046:
            r6 = r5
            goto L_0x0034
        L_0x0048:
            r4 = r1
            r5 = r4
            goto L_0x003e
        L_0x004c:
            r4 = r1
            r5 = r4
            goto L_0x0042
        L_0x0050:
            r4 = r1
            r5 = r4
            goto L_0x0046
        L_0x0054:
            r3 = r1
            r8 = 0
        L_0x0056:
            if (r8 == 0) goto L_0x0065
            f1412b = r4
            f1413c = r5
            f1414d = r6
            f1415e = r7
            f1416f = r3
            f1411a = r0
            goto L_0x0071
        L_0x0065:
            f1412b = r1
            f1413c = r1
            f1414d = r1
            f1415e = r1
            f1416f = r1
            f1411a = r2
        L_0x0071:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.m1.<clinit>():void");
    }
}
