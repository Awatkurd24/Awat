package androidx.appcompat.widget;

import android.view.KeyEvent;
import android.widget.TextView;

public final class z2 implements TextView.OnEditorActionListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SearchView f1590a;

    public z2(SearchView searchView) {
        this.f1590a = searchView;
    }

    public final boolean onEditorAction(TextView textView, int i10, KeyEvent keyEvent) {
        this.f1590a.s();
        return true;
    }
}
