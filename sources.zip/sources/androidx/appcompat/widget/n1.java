package androidx.appcompat.widget;

import android.graphics.Insets;
import android.graphics.drawable.Drawable;

public abstract class n1 {
    public static Insets a(Drawable drawable) {
        return drawable.getOpticalInsets();
    }
}
