package androidx.appcompat.widget;

import h.a0;

public final class a1 extends a0 {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppCompatTextView f1284b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a1(AppCompatTextView appCompatTextView) {
        super((Object) appCompatTextView);
        this.f1284b = appCompatTextView;
    }

    public final void c(int i10) {
        a1.super.setLastBaselineToBottomHeight(i10);
    }

    public final void f(int i10) {
        a1.super.setFirstBaselineToTopHeight(i10);
    }
}
