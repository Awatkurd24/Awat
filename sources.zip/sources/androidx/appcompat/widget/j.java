package androidx.appcompat.widget;

import a4.s;
import android.os.IBinder;
import android.os.RemoteException;
import b4.o;
import c7.h;
import d0.g;
import java.util.concurrent.ScheduledExecutorService;
import z3.c;

public final class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1369a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f1370b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f1371c;

    public /* synthetic */ j(Object obj, int i10, Object obj2) {
        this.f1369a = i10;
        this.f1371c = obj;
        this.f1370b = obj2;
    }

    private void a() {
        s c10 = ((c) this.f1371c).f30653a.f25876f.c((String) this.f1370b);
        if (c10 != null && c10.c()) {
            synchronized (((c) this.f1371c).f30655c) {
                ((c) this.f1371c).f30658f.put(g.g(c10), c10);
                ((c) this.f1371c).f30659g.add(c10);
                Object obj = this.f1371c;
                ((c) obj).f30660h.c(((c) obj).f30659g);
            }
        }
    }

    private void b() {
        try {
            ((Runnable) this.f1371c).run();
            synchronized (((o) this.f1370b).f3532d) {
                ((o) this.f1370b).b();
            }
        } catch (Throwable th2) {
            synchronized (((o) this.f1370b).f3532d) {
                ((o) this.f1370b).b();
                throw th2;
            }
        }
    }

    private final void c() {
        c7.j jVar = (c7.j) this.f1370b;
        IBinder iBinder = (IBinder) this.f1371c;
        synchronized (jVar) {
            if (iBinder == null) {
                jVar.a(0, "Null service connection");
                return;
            }
            try {
                jVar.f4060c = new a4.c(iBinder);
                jVar.f4058a = 2;
                ((ScheduledExecutorService) jVar.f4063f.f4073d).execute(new h(jVar, 0));
            } catch (RemoteException e10) {
                jVar.a(0, e10.getMessage());
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v0, resolved type: f7.i} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v10, resolved type: f7.i} */
    /* JADX WARNING: type inference failed for: r2v47, types: [b0.q, java.lang.Exception] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r8 = this;
            int r0 = r8.f1369a
            r1 = 4
            r2 = 2
            r3 = 1
            r4 = 0
            r5 = 0
            switch(r0) {
                case 0: goto L_0x054f;
                case 1: goto L_0x000a;
                case 2: goto L_0x0547;
                case 3: goto L_0x050b;
                case 4: goto L_0x04e2;
                case 5: goto L_0x04d9;
                case 6: goto L_0x04cd;
                case 7: goto L_0x047d;
                case 8: goto L_0x0452;
                case 9: goto L_0x043a;
                case 10: goto L_0x03e9;
                case 11: goto L_0x0330;
                case 12: goto L_0x0305;
                case 13: goto L_0x0301;
                case 14: goto L_0x02fd;
                case 15: goto L_0x0275;
                case 16: goto L_0x0247;
                case 17: goto L_0x0219;
                case 18: goto L_0x0202;
                case 19: goto L_0x01ec;
                case 20: goto L_0x01b9;
                case 21: goto L_0x01a0;
                case 22: goto L_0x0182;
                case 23: goto L_0x0163;
                case 24: goto L_0x015f;
                case 25: goto L_0x011e;
                case 26: goto L_0x00ab;
                case 27: goto L_0x009c;
                case 28: goto L_0x0012;
                default: goto L_0x000a;
            }
        L_0x000a:
            java.lang.Object r0 = r8.f1371c
            e7.m r0 = (e7.m) r0
            r0.getClass()
            return
        L_0x0012:
            java.lang.Object r0 = r8.f1371c
            e7.a0 r0 = (e7.a0) r0
            java.lang.Object r3 = r8.f1370b
            com.google.android.gms.signin.internal.zak r3 = (com.google.android.gms.signin.internal.zak) r3
            h7.b r4 = e7.a0.f17996i
            com.google.android.gms.common.ConnectionResult r4 = r3.f16167b
            int r6 = r4.f5789b
            if (r6 != 0) goto L_0x0091
            com.google.android.gms.common.internal.zav r3 = r3.f16168c
            l7.a.j(r3)
            com.google.android.gms.common.ConnectionResult r4 = r3.f5868c
            int r6 = r4.f5789b
            if (r6 != 0) goto L_0x007d
            t.g1 r4 = r0.f18003h
            android.os.IBinder r3 = r3.f5867b
            if (r3 != 0) goto L_0x0034
            goto L_0x004a
        L_0x0034:
            int r5 = f7.a.f18498b
            java.lang.String r5 = "com.google.android.gms.common.internal.IAccountAccessor"
            android.os.IInterface r6 = r3.queryLocalInterface(r5)
            boolean r7 = r6 instanceof f7.i
            if (r7 == 0) goto L_0x0044
            f7.i r6 = (f7.i) r6
        L_0x0042:
            r5 = r6
            goto L_0x004a
        L_0x0044:
            f7.m0 r6 = new f7.m0
            r6.<init>(r3, r5, r2)
            goto L_0x0042
        L_0x004a:
            r4.getClass()
            if (r5 == 0) goto L_0x0068
            java.util.Set r2 = r0.f18000e
            if (r2 != 0) goto L_0x0054
            goto L_0x0068
        L_0x0054:
            r4.f26247d = r5
            r4.f26248e = r2
            boolean r1 = r4.f26244a
            if (r1 == 0) goto L_0x0096
            f7.i r5 = (f7.i) r5
            java.lang.Object r1 = r4.f26245b
            d7.c r1 = (d7.c) r1
            java.util.Set r2 = (java.util.Set) r2
            r1.e(r5, r2)
            goto L_0x0096
        L_0x0068:
            java.lang.Exception r2 = new java.lang.Exception
            r2.<init>()
            java.lang.String r3 = "GoogleApiManager"
            java.lang.String r5 = "Received null response from onSignInSuccess"
            android.util.Log.wtf(r3, r5, r2)
            com.google.android.gms.common.ConnectionResult r2 = new com.google.android.gms.common.ConnectionResult
            r2.<init>(r1)
            r4.h(r2)
            goto L_0x0096
        L_0x007d:
            java.lang.String r1 = java.lang.String.valueOf(r4)
            java.lang.Exception r2 = new java.lang.Exception
            r2.<init>()
            java.lang.String r3 = "Sign-in succeeded with resolve account failure: "
            java.lang.String r1 = r3.concat(r1)
            java.lang.String r3 = "SignInCoordinator"
            android.util.Log.wtf(r3, r1, r2)
        L_0x0091:
            t.g1 r1 = r0.f18003h
            r1.h(r4)
        L_0x0096:
            a8.c r0 = r0.f18002g
            r0.f()
            return
        L_0x009c:
            java.lang.Object r0 = r8.f1370b
            v7.j1 r0 = (v7.j1) r0
            java.lang.Object r1 = r8.f1371c
            xb.c r1 = (xb.c) r1
            r0.getClass()
            r1.getClass()
            return
        L_0x00ab:
            java.lang.Object r0 = r8.f1371c
            r1 = r0
            t.g1 r1 = (t.g1) r1
            java.lang.Object r2 = r1.f26249f
            e7.e r2 = (e7.e) r2
            java.util.concurrent.ConcurrentHashMap r2 = r2.f18028j
            java.lang.Object r4 = r1.f26246c
            e7.a r4 = (e7.a) r4
            java.lang.Object r2 = r2.get(r4)
            e7.q r2 = (e7.q) r2
            if (r2 != 0) goto L_0x00c3
            goto L_0x011d
        L_0x00c3:
            java.lang.Object r4 = r8.f1370b
            com.google.android.gms.common.ConnectionResult r4 = (com.google.android.gms.common.ConnectionResult) r4
            int r6 = r4.f5789b
            if (r6 != 0) goto L_0x011a
            r1.f26244a = r3
            java.lang.Object r3 = r1.f26245b
            d7.c r3 = (d7.c) r3
            boolean r3 = r3.g()
            if (r3 == 0) goto L_0x00ed
            boolean r0 = r1.f26244a
            if (r0 == 0) goto L_0x011d
            java.lang.Object r0 = r1.f26247d
            f7.i r0 = (f7.i) r0
            if (r0 == 0) goto L_0x011d
            java.lang.Object r2 = r1.f26245b
            d7.c r2 = (d7.c) r2
            java.lang.Object r1 = r1.f26248e
            java.util.Set r1 = (java.util.Set) r1
            r2.e(r0, r1)
            goto L_0x011d
        L_0x00ed:
            t.g1 r0 = (t.g1) r0     // Catch:{ SecurityException -> 0x00fe }
            java.lang.Object r0 = r0.f26245b     // Catch:{ SecurityException -> 0x00fe }
            r3 = r0
            d7.c r3 = (d7.c) r3     // Catch:{ SecurityException -> 0x00fe }
            d7.c r0 = (d7.c) r0     // Catch:{ SecurityException -> 0x00fe }
            java.util.Set r0 = r0.a()     // Catch:{ SecurityException -> 0x00fe }
            r3.e(r5, r0)     // Catch:{ SecurityException -> 0x00fe }
            goto L_0x011d
        L_0x00fe:
            r0 = move-exception
            java.lang.String r3 = "GoogleApiManager"
            java.lang.String r4 = "Failed to get service from broker. "
            android.util.Log.e(r3, r4, r0)
            java.lang.Object r0 = r1.f26245b
            d7.c r0 = (d7.c) r0
            java.lang.String r1 = "Failed to get service from broker."
            r0.c(r1)
            com.google.android.gms.common.ConnectionResult r0 = new com.google.android.gms.common.ConnectionResult
            r1 = 10
            r0.<init>(r1)
            r2.m(r0, r5)
            goto L_0x011d
        L_0x011a:
            r2.m(r4, r5)
        L_0x011d:
            return
        L_0x011e:
            java.lang.Object r0 = r8.f1370b
            c7.j r0 = (c7.j) r0
            java.lang.Object r1 = r8.f1371c
            c7.l r1 = (c7.l) r1
            int r1 = r1.f4065a
            java.lang.String r2 = "Timing out request: "
            monitor-enter(r0)
            android.util.SparseArray r3 = r0.f4062e     // Catch:{ all -> 0x015a }
            java.lang.Object r3 = r3.get(r1)     // Catch:{ all -> 0x015a }
            c7.l r3 = (c7.l) r3     // Catch:{ all -> 0x015a }
            if (r3 == 0) goto L_0x0158
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x015a }
            r4.<init>(r2)     // Catch:{ all -> 0x015a }
            r4.append(r1)     // Catch:{ all -> 0x015a }
            java.lang.String r2 = r4.toString()     // Catch:{ all -> 0x015a }
            java.lang.String r4 = "MessengerIpcClient"
            android.util.Log.w(r4, r2)     // Catch:{ all -> 0x015a }
            android.util.SparseArray r2 = r0.f4062e     // Catch:{ all -> 0x015a }
            r2.remove(r1)     // Catch:{ all -> 0x015a }
            java.lang.String r1 = "Timed out waiting for response"
            b0.q r2 = new b0.q     // Catch:{ all -> 0x015a }
            r2.<init>(r1, r5)     // Catch:{ all -> 0x015a }
            r3.a(r2)     // Catch:{ all -> 0x015a }
            r0.c()     // Catch:{ all -> 0x015a }
        L_0x0158:
            monitor-exit(r0)
            goto L_0x015c
        L_0x015a:
            r1 = move-exception
            goto L_0x015d
        L_0x015c:
            return
        L_0x015d:
            monitor-exit(r0)
            throw r1
        L_0x015f:
            r8.c()
            return
        L_0x0163:
            java.lang.Object r0 = r8.f1370b
            j6.h r0 = (j6.h) r0
            java.lang.Object r1 = r8.f1371c
            j6.e r1 = (j6.e) r1
            p6.c2 r2 = r0.f20689a     // Catch:{ IllegalStateException -> 0x0173 }
            p6.a2 r1 = r1.f20669a     // Catch:{ IllegalStateException -> 0x0173 }
            r2.c(r1)     // Catch:{ IllegalStateException -> 0x0173 }
            goto L_0x0181
        L_0x0173:
            r1 = move-exception
            android.content.Context r0 = r0.getContext()
            com.google.android.gms.internal.ads.pn r0 = com.google.android.gms.internal.ads.on.b(r0)
            java.lang.String r2 = "BaseAdView.loadAd"
            r0.a(r2, r1)
        L_0x0181:
            return
        L_0x0182:
            java.lang.Object r0 = r8.f1370b
            j6.d r0 = (j6.d) r0
            java.lang.Object r1 = r8.f1371c
            p6.a2 r1 = (p6.a2) r1
            r0.getClass()
            p6.b0 r2 = r0.f20668b     // Catch:{ RemoteException -> 0x0199 }
            android.content.Context r0 = r0.f20667a     // Catch:{ RemoteException -> 0x0199 }
            com.google.android.gms.ads.internal.client.zzl r0 = p6.u2.a(r0, r1)     // Catch:{ RemoteException -> 0x0199 }
            r2.v3(r0)     // Catch:{ RemoteException -> 0x0199 }
            goto L_0x019f
        L_0x0199:
            r0 = move-exception
            java.lang.String r1 = "Failed to load ad."
            com.google.android.gms.internal.ads.fr.e(r1, r0)
        L_0x019f:
            return
        L_0x01a0:
            java.lang.Object r0 = r8.f1370b
            x6.b r0 = (x6.b) r0
            java.lang.Object r1 = r8.f1371c
            com.google.android.gms.internal.ads.k90[] r1 = (com.google.android.gms.internal.ads.k90[]) r1
            r0.getClass()
            r1 = r1[r4]
            if (r1 == 0) goto L_0x01b8
            com.google.android.gms.internal.ads.z01 r1 = com.google.android.gms.internal.ads.cq0.u2(r1)
            com.google.android.gms.internal.ads.yp0 r0 = r0.f29614e
            r0.b(r1)
        L_0x01b8:
            return
        L_0x01b9:
            java.lang.Object r0 = r8.f1370b
            x6.a r0 = (x6.a) r0
            java.lang.Object r1 = r8.f1371c
            java.lang.String r1 = (java.lang.String) r1
            r0.getClass()
            android.net.Uri r1 = android.net.Uri.parse(r1)
            com.google.android.gms.internal.ads.l8 r2 = r0.f29605c     // Catch:{ m8 -> 0x01d3 }
            android.content.Context r3 = r0.f29603a     // Catch:{ m8 -> 0x01d3 }
            android.webkit.WebView r4 = r0.f29604b     // Catch:{ m8 -> 0x01d3 }
            android.net.Uri r1 = r2.a(r1, r3, r4, r5)     // Catch:{ m8 -> 0x01d3 }
            goto L_0x01e2
        L_0x01d3:
            r2 = move-exception
            java.lang.String r3 = "Failed to append the click signal to URL: "
            com.google.android.gms.internal.ads.fr.c(r3, r2)
            o6.k r3 = o6.k.A
            com.google.android.gms.internal.ads.uq r3 = r3.f23637g
            java.lang.String r4 = "TaggingLibraryJsInterface.recordClick"
            r3.h(r4, r2)
        L_0x01e2:
            com.google.android.gms.internal.ads.hs0 r0 = r0.f29610h
            java.lang.String r1 = r1.toString()
            r0.a(r1, r5)
            return
        L_0x01ec:
            java.lang.Object r0 = r8.f1370b
            q6.f r0 = (q6.f) r0
            java.lang.Object r0 = r0.f24885c
            q6.g r0 = (q6.g) r0
            android.app.Activity r0 = r0.f24887b
            android.view.Window r0 = r0.getWindow()
            java.lang.Object r1 = r8.f1371c
            android.graphics.drawable.Drawable r1 = (android.graphics.drawable.Drawable) r1
            r0.setBackgroundDrawable(r1)
            return
        L_0x0202:
            java.lang.Object r0 = r8.f1370b
            p6.c2 r0 = (p6.c2) r0
            java.lang.Object r1 = r8.f1371c
            m7.a r1 = (m7.a) r1
            r0.getClass()
            java.lang.Object r1 = m7.b.n3(r1)
            android.view.View r1 = (android.view.View) r1
            android.view.ViewGroup r0 = r0.f23946l
            r0.addView(r1)
            return
        L_0x0219:
            java.lang.Object r0 = r8.f1371c
            r1 = r0
            m.g r1 = (m.g) r1     // Catch:{ all -> 0x0231 }
            java.lang.Object r1 = r1.f22229d     // Catch:{ all -> 0x0231 }
            f4.o r1 = (f4.o) r1     // Catch:{ all -> 0x0231 }
            java.lang.Object r2 = r8.f1370b     // Catch:{ all -> 0x0231 }
            f4.f r2 = (f4.f) r2     // Catch:{ all -> 0x0231 }
            r3 = r0
            m.g r3 = (m.g) r3     // Catch:{ all -> 0x0231 }
            java.lang.Object r3 = r3.f22228c     // Catch:{ all -> 0x0231 }
            f4.m r3 = (f4.m) r3     // Catch:{ all -> 0x0231 }
            r1.W(r2, r3)     // Catch:{ all -> 0x0231 }
            goto L_0x0246
        L_0x0231:
            r1 = move-exception
            r3.u r2 = r3.u.e()
            java.lang.String r3 = androidx.work.multiprocess.RemoteWorkManagerClient.f3239i
            java.lang.String r4 = "Unable to execute"
            r2.d(r3, r4, r1)
            m.g r0 = (m.g) r0
            java.lang.Object r0 = r0.f22228c
            f4.m r0 = (f4.m) r0
            f4.i.a(r0, r1)
        L_0x0246:
            return
        L_0x0247:
            java.lang.Object r0 = r8.f1371c
            r1 = r0
            m.g r1 = (m.g) r1     // Catch:{ all -> 0x025f }
            java.lang.Object r1 = r1.f22229d     // Catch:{ all -> 0x025f }
            f4.o r1 = (f4.o) r1     // Catch:{ all -> 0x025f }
            java.lang.Object r2 = r8.f1370b     // Catch:{ all -> 0x025f }
            f4.c r2 = (f4.c) r2     // Catch:{ all -> 0x025f }
            r3 = r0
            m.g r3 = (m.g) r3     // Catch:{ all -> 0x025f }
            java.lang.Object r3 = r3.f22228c     // Catch:{ all -> 0x025f }
            f4.m r3 = (f4.m) r3     // Catch:{ all -> 0x025f }
            r1.W(r2, r3)     // Catch:{ all -> 0x025f }
            goto L_0x0274
        L_0x025f:
            r1 = move-exception
            r3.u r2 = r3.u.e()
            java.lang.String r3 = f4.k.f18445e
            java.lang.String r4 = "Unable to execute"
            r2.d(r3, r4, r1)
            m.g r0 = (m.g) r0
            java.lang.Object r0 = r0.f22228c
            f4.m r0 = (f4.m) r0
            f4.i.a(r0, r1)
        L_0x0274:
            return
        L_0x0275:
            java.lang.String r0 = "Updating notification for "
            java.lang.String r1 = "Worker was marked important ("
            java.lang.Object r2 = r8.f1371c
            b4.s r2 = (b4.s) r2
            c4.j r2 = r2.f3541a
            java.lang.Object r2 = r2.f4001a
            boolean r2 = r2 instanceof c4.a
            if (r2 == 0) goto L_0x0286
            goto L_0x02fc
        L_0x0286:
            java.lang.Object r2 = r8.f1370b     // Catch:{ all -> 0x02d2 }
            c4.j r2 = (c4.j) r2     // Catch:{ all -> 0x02d2 }
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x02d2 }
            r3.l r2 = (r3.l) r2     // Catch:{ all -> 0x02d2 }
            if (r2 == 0) goto L_0x02d4
            r3.u r1 = r3.u.e()     // Catch:{ all -> 0x02d2 }
            java.lang.String r3 = b4.s.f3540g     // Catch:{ all -> 0x02d2 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x02d2 }
            r4.<init>(r0)     // Catch:{ all -> 0x02d2 }
            java.lang.Object r0 = r8.f1371c     // Catch:{ all -> 0x02d2 }
            b4.s r0 = (b4.s) r0     // Catch:{ all -> 0x02d2 }
            a4.s r0 = r0.f3543c     // Catch:{ all -> 0x02d2 }
            java.lang.String r0 = r0.f580c     // Catch:{ all -> 0x02d2 }
            r4.append(r0)     // Catch:{ all -> 0x02d2 }
            java.lang.String r0 = r4.toString()     // Catch:{ all -> 0x02d2 }
            r1.a(r3, r0)     // Catch:{ all -> 0x02d2 }
            java.lang.Object r0 = r8.f1371c     // Catch:{ all -> 0x02d2 }
            r1 = r0
            b4.s r1 = (b4.s) r1     // Catch:{ all -> 0x02d2 }
            c4.j r1 = r1.f3541a     // Catch:{ all -> 0x02d2 }
            r3 = r0
            b4.s r3 = (b4.s) r3     // Catch:{ all -> 0x02d2 }
            r3.m r3 = r3.f3545e     // Catch:{ all -> 0x02d2 }
            r4 = r0
            b4.s r4 = (b4.s) r4     // Catch:{ all -> 0x02d2 }
            android.content.Context r4 = r4.f3542b     // Catch:{ all -> 0x02d2 }
            b4.s r0 = (b4.s) r0     // Catch:{ all -> 0x02d2 }
            r3.t r0 = r0.f3544d     // Catch:{ all -> 0x02d2 }
            java.util.UUID r0 = r0.getId()     // Catch:{ all -> 0x02d2 }
            b4.t r3 = (b4.t) r3     // Catch:{ all -> 0x02d2 }
            c4.j r0 = r3.a(r4, r0, r2)     // Catch:{ all -> 0x02d2 }
            r1.l(r0)     // Catch:{ all -> 0x02d2 }
            goto L_0x02fc
        L_0x02d2:
            r0 = move-exception
            goto L_0x02f3
        L_0x02d4:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x02d2 }
            r0.<init>(r1)     // Catch:{ all -> 0x02d2 }
            java.lang.Object r1 = r8.f1371c     // Catch:{ all -> 0x02d2 }
            b4.s r1 = (b4.s) r1     // Catch:{ all -> 0x02d2 }
            a4.s r1 = r1.f3543c     // Catch:{ all -> 0x02d2 }
            java.lang.String r1 = r1.f580c     // Catch:{ all -> 0x02d2 }
            r0.append(r1)     // Catch:{ all -> 0x02d2 }
            java.lang.String r1 = ") but did not provide ForegroundInfo"
            r0.append(r1)     // Catch:{ all -> 0x02d2 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x02d2 }
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException     // Catch:{ all -> 0x02d2 }
            r1.<init>(r0)     // Catch:{ all -> 0x02d2 }
            throw r1     // Catch:{ all -> 0x02d2 }
        L_0x02f3:
            java.lang.Object r1 = r8.f1371c
            b4.s r1 = (b4.s) r1
            c4.j r1 = r1.f3541a
            r1.k(r0)
        L_0x02fc:
            return
        L_0x02fd:
            r8.b()
            return
        L_0x0301:
            r8.a()
            return
        L_0x0305:
            r3.u r0 = r3.u.e()
            java.lang.String r1 = t3.a.f26514d
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r5 = "Scheduling work "
            r2.<init>(r5)
            java.lang.Object r5 = r8.f1370b
            a4.s r5 = (a4.s) r5
            java.lang.String r6 = r5.f578a
            r2.append(r6)
            java.lang.String r2 = r2.toString()
            r0.a(r1, r2)
            java.lang.Object r0 = r8.f1371c
            t3.a r0 = (t3.a) r0
            t3.b r0 = r0.f26515a
            a4.s[] r1 = new a4.s[r3]
            r1[r4] = r5
            r0.d(r1)
            return
        L_0x0330:
            java.lang.Object r0 = r8.f1370b
            java.lang.Object r2 = r8.f1371c
            r3 = r2
            s3.e0 r3 = (s3.e0) r3     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            c4.j r3 = r3.f25821q     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.Object r3 = r3.get()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r3.s r3 = (r3.s) r3     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            if (r3 != 0) goto L_0x036c
            r3.u r3 = r3.u.e()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r4 = s3.e0.f25804s     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r5.<init>()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r6 = r2
            s3.e0 r6 = (s3.e0) r6     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            a4.s r6 = r6.f25809e     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r6 = r6.f580c     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r5.append(r6)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r6 = " returned a null result. Treating it as a failure."
            r5.append(r6)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r5 = r5.toString()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r3.c(r4, r5)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            goto L_0x039a
        L_0x0363:
            r0 = move-exception
            goto L_0x03e3
        L_0x0366:
            r1 = move-exception
            goto L_0x03a0
        L_0x0368:
            r1 = move-exception
            goto L_0x03a0
        L_0x036a:
            r3 = move-exception
            goto L_0x03bd
        L_0x036c:
            r3.u r4 = r3.u.e()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r5 = s3.e0.f25804s     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r6.<init>()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r7 = r2
            s3.e0 r7 = (s3.e0) r7     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            a4.s r7 = r7.f25809e     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r7 = r7.f580c     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r6.append(r7)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r7 = " returned a "
            r6.append(r7)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r6.append(r3)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r7 = "."
            r6.append(r7)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            java.lang.String r6 = r6.toString()     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r4.a(r5, r6)     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r4 = r2
            s3.e0 r4 = (s3.e0) r4     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
            r4.f25812h = r3     // Catch:{ CancellationException -> 0x036a, InterruptedException -> 0x0368, ExecutionException -> 0x0366 }
        L_0x039a:
            s3.e0 r2 = (s3.e0) r2
            r2.b()
            goto L_0x03e2
        L_0x03a0:
            r3.u r3 = r3.u.e()     // Catch:{ all -> 0x0363 }
            java.lang.String r4 = s3.e0.f25804s     // Catch:{ all -> 0x0363 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x0363 }
            r5.<init>()     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ all -> 0x0363 }
            r5.append(r0)     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = " failed because it threw an exception/error"
            r5.append(r0)     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = r5.toString()     // Catch:{ all -> 0x0363 }
            r3.d(r4, r0, r1)     // Catch:{ all -> 0x0363 }
            goto L_0x039a
        L_0x03bd:
            r3.u r4 = r3.u.e()     // Catch:{ all -> 0x0363 }
            java.lang.String r5 = s3.e0.f25804s     // Catch:{ all -> 0x0363 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ all -> 0x0363 }
            r6.<init>()     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ all -> 0x0363 }
            r6.append(r0)     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = " was cancelled"
            r6.append(r0)     // Catch:{ all -> 0x0363 }
            java.lang.String r0 = r6.toString()     // Catch:{ all -> 0x0363 }
            int r4 = r4.f25386a     // Catch:{ all -> 0x0363 }
            if (r4 > r1) goto L_0x03dd
            android.util.Log.i(r5, r0, r3)     // Catch:{ all -> 0x0363 }
        L_0x03dd:
            s3.e0 r2 = (s3.e0) r2
            r2.b()
        L_0x03e2:
            return
        L_0x03e3:
            s3.e0 r2 = (s3.e0) r2
            r2.b()
            throw r0
        L_0x03e9:
            java.lang.String r0 = "Starting work for "
            java.lang.Object r1 = r8.f1371c
            s3.e0 r1 = (s3.e0) r1
            c4.j r1 = r1.f25821q
            java.lang.Object r1 = r1.f4001a
            boolean r1 = r1 instanceof c4.a
            if (r1 == 0) goto L_0x03f8
            goto L_0x0439
        L_0x03f8:
            java.lang.Object r1 = r8.f1370b     // Catch:{ all -> 0x042f }
            y9.a r1 = (y9.a) r1     // Catch:{ all -> 0x042f }
            r1.get()     // Catch:{ all -> 0x042f }
            r3.u r1 = r3.u.e()     // Catch:{ all -> 0x042f }
            java.lang.String r2 = s3.e0.f25804s     // Catch:{ all -> 0x042f }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x042f }
            r3.<init>(r0)     // Catch:{ all -> 0x042f }
            java.lang.Object r0 = r8.f1371c     // Catch:{ all -> 0x042f }
            s3.e0 r0 = (s3.e0) r0     // Catch:{ all -> 0x042f }
            a4.s r0 = r0.f25809e     // Catch:{ all -> 0x042f }
            java.lang.String r0 = r0.f580c     // Catch:{ all -> 0x042f }
            r3.append(r0)     // Catch:{ all -> 0x042f }
            java.lang.String r0 = r3.toString()     // Catch:{ all -> 0x042f }
            r1.a(r2, r0)     // Catch:{ all -> 0x042f }
            java.lang.Object r0 = r8.f1371c     // Catch:{ all -> 0x042f }
            r1 = r0
            s3.e0 r1 = (s3.e0) r1     // Catch:{ all -> 0x042f }
            c4.j r1 = r1.f25821q     // Catch:{ all -> 0x042f }
            s3.e0 r0 = (s3.e0) r0     // Catch:{ all -> 0x042f }
            r3.t r0 = r0.f25810f     // Catch:{ all -> 0x042f }
            y9.a r0 = r0.startWork()     // Catch:{ all -> 0x042f }
            r1.l(r0)     // Catch:{ all -> 0x042f }
            goto L_0x0439
        L_0x042f:
            r0 = move-exception
            java.lang.Object r1 = r8.f1371c
            s3.e0 r1 = (s3.e0) r1
            c4.j r1 = r1.f25821q
            r1.k(r0)
        L_0x0439:
            return
        L_0x043a:
            java.lang.Object r0 = r8.f1370b
            java.lang.Object r1 = r8.f1371c     // Catch:{ all -> 0x044b }
            androidx.work.Worker r1 = (androidx.work.Worker) r1     // Catch:{ all -> 0x044b }
            r3.l r1 = r1.getForegroundInfo()     // Catch:{ all -> 0x044b }
            r2 = r0
            c4.j r2 = (c4.j) r2     // Catch:{ all -> 0x044b }
            r2.j(r1)     // Catch:{ all -> 0x044b }
            goto L_0x0451
        L_0x044b:
            r1 = move-exception
            c4.j r0 = (c4.j) r0
            r0.k(r1)
        L_0x0451:
            return
        L_0x0452:
            java.lang.Object r0 = r8.f1370b
            r1 = r0
            yg.g r1 = (yg.g) r1     // Catch:{ all -> 0x0463 }
            java.lang.Object r2 = r8.f1371c     // Catch:{ all -> 0x0463 }
            y9.a r2 = (y9.a) r2     // Catch:{ all -> 0x0463 }
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x0463 }
            r1.c(r2)     // Catch:{ all -> 0x0463 }
            goto L_0x047c
        L_0x0463:
            r1 = move-exception
            java.lang.Throwable r2 = r1.getCause()
            if (r2 != 0) goto L_0x046b
            r2 = r1
        L_0x046b:
            boolean r1 = r1 instanceof java.util.concurrent.CancellationException
            yg.g r0 = (yg.g) r0
            if (r1 == 0) goto L_0x0475
            r0.i(r2)
            goto L_0x047c
        L_0x0475:
            wd.g r1 = v7.r0.m(r2)
            r0.c(r1)
        L_0x047c:
            return
        L_0x047d:
            java.lang.reflect.Method r0 = g1.j.f18961d     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            java.lang.Object r1 = r8.f1371c
            java.lang.Object r5 = r8.f1370b
            if (r0 == 0) goto L_0x049a
            r6 = 3
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r6[r4] = r1     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r6[r3] = r1     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            java.lang.String r1 = "AppCompat recreation"
            r6[r2] = r1     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r0.invoke(r5, r6)     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            goto L_0x04cc
        L_0x0496:
            r0 = move-exception
            goto L_0x04a8
        L_0x0498:
            r0 = move-exception
            goto L_0x04b0
        L_0x049a:
            java.lang.reflect.Method r0 = g1.j.f18962e     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r2[r4] = r1     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r2[r3] = r1     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            r0.invoke(r5, r2)     // Catch:{ RuntimeException -> 0x0498, all -> 0x0496 }
            goto L_0x04cc
        L_0x04a8:
            java.lang.String r1 = "ActivityRecreator"
            java.lang.String r2 = "Exception while invoking performStopActivity"
            android.util.Log.e(r1, r2, r0)
            goto L_0x04cc
        L_0x04b0:
            java.lang.Class r1 = r0.getClass()
            java.lang.Class<java.lang.RuntimeException> r2 = java.lang.RuntimeException.class
            if (r1 != r2) goto L_0x04cc
            java.lang.String r1 = r0.getMessage()
            if (r1 == 0) goto L_0x04cc
            java.lang.String r1 = r0.getMessage()
            java.lang.String r2 = "Unable to stop"
            boolean r1 = r1.startsWith(r2)
            if (r1 != 0) goto L_0x04cb
            goto L_0x04cc
        L_0x04cb:
            throw r0
        L_0x04cc:
            return
        L_0x04cd:
            java.lang.Object r0 = r8.f1370b
            android.app.Application r0 = (android.app.Application) r0
            java.lang.Object r1 = r8.f1371c
            g1.i r1 = (g1.i) r1
            r0.unregisterActivityLifecycleCallbacks(r1)
            return
        L_0x04d9:
            java.lang.Object r0 = r8.f1370b
            g1.i r0 = (g1.i) r0
            java.lang.Object r1 = r8.f1371c
            r0.f18952a = r1
            return
        L_0x04e2:
            java.lang.Object r0 = r8.f1371c
            java.lang.Object r1 = r8.f1370b     // Catch:{ ExecutionException -> 0x04f6, RuntimeException -> 0x04f4, Error -> 0x04f2 }
            java.util.concurrent.Future r1 = (java.util.concurrent.Future) r1     // Catch:{ ExecutionException -> 0x04f6, RuntimeException -> 0x04f4, Error -> 0x04f2 }
            java.lang.Object r1 = e0.f.b(r1)     // Catch:{ ExecutionException -> 0x04f6, RuntimeException -> 0x04f4, Error -> 0x04f2 }
            e0.c r0 = (e0.c) r0
            r0.onSuccess(r1)
            goto L_0x050a
        L_0x04f2:
            r1 = move-exception
            goto L_0x04f8
        L_0x04f4:
            r1 = move-exception
            goto L_0x04f8
        L_0x04f6:
            r1 = move-exception
            goto L_0x04fe
        L_0x04f8:
            e0.c r0 = (e0.c) r0
            r0.D(r1)
            goto L_0x050a
        L_0x04fe:
            java.lang.Throwable r2 = r1.getCause()
            if (r2 != 0) goto L_0x0505
            goto L_0x04f8
        L_0x0505:
            e0.c r0 = (e0.c) r0
            r0.D(r2)
        L_0x050a:
            return
        L_0x050b:
            java.lang.Object r0 = r8.f1371c     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            e0.b r0 = (e0.b) r0     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            java.lang.Object r1 = r8.f1370b     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            y9.a r1 = (y9.a) r1     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            java.lang.Object r1 = e0.f.c(r1)     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            t0.j r0 = r0.f17879b     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            if (r0 == 0) goto L_0x0539
            r0.a(r1)     // Catch:{ CancellationException -> 0x0532, ExecutionException -> 0x0521 }
            goto L_0x0539
        L_0x051f:
            r0 = move-exception
            goto L_0x0540
        L_0x0521:
            r0 = move-exception
            java.lang.Object r1 = r8.f1371c     // Catch:{ all -> 0x051f }
            e0.b r1 = (e0.b) r1     // Catch:{ all -> 0x051f }
            java.lang.Throwable r0 = r0.getCause()     // Catch:{ all -> 0x051f }
            t0.j r1 = r1.f17879b     // Catch:{ all -> 0x051f }
            if (r1 == 0) goto L_0x0539
            r1.b(r0)     // Catch:{ all -> 0x051f }
            goto L_0x0539
        L_0x0532:
            java.lang.Object r0 = r8.f1371c     // Catch:{ all -> 0x051f }
            e0.b r0 = (e0.b) r0     // Catch:{ all -> 0x051f }
            r0.cancel(r4)     // Catch:{ all -> 0x051f }
        L_0x0539:
            java.lang.Object r0 = r8.f1371c
            e0.b r0 = (e0.b) r0
            r0.f17877g = r5
            return
        L_0x0540:
            java.lang.Object r1 = r8.f1371c
            e0.b r1 = (e0.b) r1
            r1.f17877g = r5
            throw r0
        L_0x0547:
            java.lang.Object r0 = r8.f1370b
            java.lang.Runnable r0 = (java.lang.Runnable) r0
            r0.run()
            return
        L_0x054f:
            java.lang.Object r0 = r8.f1371c
            androidx.appcompat.widget.n r0 = (androidx.appcompat.widget.n) r0
            m.o r1 = r0.f1420c
            if (r1 == 0) goto L_0x055e
            m.m r2 = r1.f22299e
            if (r2 == 0) goto L_0x055e
            r2.E(r1)
        L_0x055e:
            m.e0 r1 = r0.f1425h
            android.view.View r1 = (android.view.View) r1
            if (r1 == 0) goto L_0x057f
            android.os.IBinder r1 = r1.getWindowToken()
            if (r1 == 0) goto L_0x057f
            java.lang.Object r1 = r8.f1370b
            androidx.appcompat.widget.h r1 = (androidx.appcompat.widget.h) r1
            boolean r2 = r1.b()
            if (r2 == 0) goto L_0x0575
            goto L_0x057d
        L_0x0575:
            android.view.View r2 = r1.f22209f
            if (r2 != 0) goto L_0x057a
            goto L_0x057f
        L_0x057a:
            r1.d(r4, r4, r4, r4)
        L_0x057d:
            r0.f1437t = r1
        L_0x057f:
            r0.f1439v = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.j.run():void");
    }

    public final String toString() {
        switch (this.f1369a) {
            case 4:
                return j.class.getSimpleName() + "," + ((e0.c) this.f1371c);
            default:
                return super.toString();
        }
    }

    public /* synthetic */ j(Object obj, Object obj2, int i10) {
        this.f1369a = i10;
        this.f1370b = obj;
        this.f1371c = obj2;
    }
}
