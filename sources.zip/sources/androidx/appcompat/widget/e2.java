package androidx.appcompat.widget;

import android.os.Handler;
import android.widget.AbsListView;

public final class e2 implements AbsListView.OnScrollListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ListPopupWindow f1332a;

    public e2(ListPopupWindow listPopupWindow) {
        this.f1332a = listPopupWindow;
    }

    public final void onScroll(AbsListView absListView, int i10, int i11, int i12) {
    }

    public final void onScrollStateChanged(AbsListView absListView, int i10) {
        if (i10 == 1) {
            ListPopupWindow listPopupWindow = this.f1332a;
            if (listPopupWindow.f1190z.getInputMethodMode() != 2 && listPopupWindow.f1190z.getContentView() != null) {
                Handler handler = listPopupWindow.f1186v;
                z1 z1Var = listPopupWindow.f1182r;
                handler.removeCallbacks(z1Var);
                z1Var.run();
            }
        }
    }
}
