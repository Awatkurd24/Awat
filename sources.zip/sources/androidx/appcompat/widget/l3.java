package androidx.appcompat.widget;

import a9.h;
import a9.l;
import a9.n;
import a9.p;
import a9.r;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Property;
import android.view.View;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import java.util.Arrays;
import java.util.WeakHashMap;
import k3.e;
import k3.z;
import n2.b;
import r1.h1;
import r1.q0;
import r1.r0;
import v7.h9;

public final class l3 extends Property {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1408a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ l3(int i10, Class cls, String str) {
        super(cls, str);
        this.f1408a = i10;
    }

    public final Float a(View view) {
        switch (this.f1408a) {
            case 6:
                return Float.valueOf(z.f21393a.u(view));
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return Float.valueOf((float) view.getLayoutParams().width);
            case 9:
                return Float.valueOf((float) view.getLayoutParams().height);
            case 10:
                WeakHashMap weakHashMap = h1.f25195a;
                return Float.valueOf((float) q0.f(view));
            default:
                WeakHashMap weakHashMap2 = h1.f25195a;
                return Float.valueOf((float) q0.e(view));
        }
    }

    public final void b(h hVar, Float f10) {
        switch (this.f1408a) {
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                float floatValue = f10.floatValue();
                hVar.f694i = floatValue;
                int i10 = (int) (5400.0f * floatValue);
                float[] fArr = (float[]) hVar.f22219b;
                float f11 = floatValue * 1520.0f;
                fArr[0] = -20.0f + f11;
                fArr[1] = f11;
                int i11 = 0;
                while (true) {
                    b bVar = hVar.f691f;
                    if (i11 < 4) {
                        float f12 = (float) 667;
                        float[] fArr2 = (float[]) hVar.f22219b;
                        fArr2[1] = (bVar.getInterpolation(((float) (i10 - h.f684l[i11])) / f12) * 250.0f) + fArr2[1];
                        float f13 = ((float) (i10 - h.f685m[i11])) / f12;
                        float[] fArr3 = (float[]) hVar.f22219b;
                        fArr3[0] = (bVar.getInterpolation(f13) * 250.0f) + fArr3[0];
                        i11++;
                    } else {
                        float[] fArr4 = (float[]) hVar.f22219b;
                        float f14 = fArr4[0];
                        float f15 = fArr4[1];
                        float f16 = ((f15 - f14) * hVar.f695j) + f14;
                        fArr4[0] = f16;
                        fArr4[0] = f16 / 360.0f;
                        fArr4[1] = f15 / 360.0f;
                        int i12 = 0;
                        while (true) {
                            if (i12 < 4) {
                                float f17 = ((float) (i10 - h.f686n[i12])) / ((float) 333);
                                if (f17 < 0.0f || f17 > 1.0f) {
                                    i12++;
                                } else {
                                    int i13 = i12 + hVar.f693h;
                                    CircularProgressIndicatorSpec circularProgressIndicatorSpec = hVar.f692g;
                                    int[] iArr = circularProgressIndicatorSpec.f674c;
                                    int length = i13 % iArr.length;
                                    int f18 = h9.f(iArr[length], ((n) hVar.f22218a).f715j);
                                    int f19 = h9.f(circularProgressIndicatorSpec.f674c[(length + 1) % iArr.length], ((n) hVar.f22218a).f715j);
                                    ((int[]) hVar.f22220c)[0] = f8.b.a(bVar.getInterpolation(f17), Integer.valueOf(f18), Integer.valueOf(f19)).intValue();
                                }
                            }
                        }
                        ((n) hVar.f22218a).invalidateSelf();
                        return;
                    }
                }
                break;
            default:
                hVar.f695j = f10.floatValue();
                return;
        }
    }

    public final void c(View view, PointF pointF) {
        switch (this.f1408a) {
            case 3:
                z.a(view, view.getLeft(), view.getTop(), Math.round(pointF.x), Math.round(pointF.y));
                return;
            case 4:
                z.a(view, Math.round(pointF.x), Math.round(pointF.y), view.getRight(), view.getBottom());
                return;
            default:
                int round = Math.round(pointF.x);
                int round2 = Math.round(pointF.y);
                z.a(view, round, round2, view.getWidth() + round, view.getHeight() + round2);
                return;
        }
    }

    public final void d(View view, Float f10) {
        switch (this.f1408a) {
            case 6:
                z.f21393a.v(view, f10.floatValue());
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                view.getLayoutParams().width = f10.intValue();
                view.requestLayout();
                return;
            case 9:
                view.getLayoutParams().height = f10.intValue();
                view.requestLayout();
                return;
            case 10:
                int intValue = f10.intValue();
                int paddingTop = view.getPaddingTop();
                WeakHashMap weakHashMap = h1.f25195a;
                q0.k(view, intValue, paddingTop, q0.e(view), view.getPaddingBottom());
                return;
            default:
                WeakHashMap weakHashMap2 = h1.f25195a;
                q0.k(view, q0.f(view), view.getPaddingTop(), f10.intValue(), view.getPaddingBottom());
                return;
        }
    }

    public final void e(e eVar, PointF pointF) {
        switch (this.f1408a) {
            case 1:
                eVar.getClass();
                eVar.f21303a = Math.round(pointF.x);
                int round = Math.round(pointF.y);
                eVar.f21304b = round;
                int i10 = eVar.f21308f + 1;
                eVar.f21308f = i10;
                if (i10 == eVar.f21309g) {
                    z.a(eVar.f21307e, eVar.f21303a, round, eVar.f21305c, eVar.f21306d);
                    eVar.f21308f = 0;
                    eVar.f21309g = 0;
                    return;
                }
                return;
            default:
                eVar.getClass();
                eVar.f21305c = Math.round(pointF.x);
                int round2 = Math.round(pointF.y);
                eVar.f21306d = round2;
                int i11 = eVar.f21309g + 1;
                eVar.f21309g = i11;
                if (eVar.f21308f == i11) {
                    z.a(eVar.f21307e, eVar.f21303a, eVar.f21304b, eVar.f21305c, round2);
                    eVar.f21308f = 0;
                    eVar.f21309g = 0;
                    return;
                }
                return;
        }
    }

    public final Object get(Object obj) {
        int i10 = this.f1408a;
        switch (i10) {
            case 0:
                return Float.valueOf(((SwitchCompat) obj).f1246z);
            case 1:
                e eVar = (e) obj;
                return null;
            case 2:
                e eVar2 = (e) obj;
                return null;
            case 3:
                View view = (View) obj;
                return null;
            case 4:
                View view2 = (View) obj;
                return null;
            case 5:
                View view3 = (View) obj;
                return null;
            case 6:
                return a((View) obj);
            case 7:
                WeakHashMap weakHashMap = h1.f25195a;
                return r0.a((View) obj);
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return a((View) obj);
            case 9:
                return a((View) obj);
            case 10:
                return a((View) obj);
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                return a((View) obj);
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                h hVar = (h) obj;
                switch (i10) {
                    case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                        return Float.valueOf(hVar.f694i);
                    default:
                        return Float.valueOf(hVar.f695j);
                }
            case 13:
                h hVar2 = (h) obj;
                switch (i10) {
                    case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                        return Float.valueOf(hVar2.f694i);
                    default:
                        return Float.valueOf(hVar2.f695j);
                }
            case 14:
                return Float.valueOf(((l) obj).b());
            case 15:
                return Float.valueOf(((p) obj).f730i);
            default:
                return Float.valueOf(((r) obj).f742j);
        }
    }

    public final void set(Object obj, Object obj2) {
        switch (this.f1408a) {
            case 0:
                ((SwitchCompat) obj).setThumbPosition(((Float) obj2).floatValue());
                return;
            case 1:
                e((e) obj, (PointF) obj2);
                return;
            case 2:
                e((e) obj, (PointF) obj2);
                return;
            case 3:
                c((View) obj, (PointF) obj2);
                return;
            case 4:
                c((View) obj, (PointF) obj2);
                return;
            case 5:
                c((View) obj, (PointF) obj2);
                return;
            case 6:
                d((View) obj, (Float) obj2);
                return;
            case 7:
                WeakHashMap weakHashMap = h1.f25195a;
                r0.c((View) obj, (Rect) obj2);
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                d((View) obj, (Float) obj2);
                return;
            case 9:
                d((View) obj, (Float) obj2);
                return;
            case 10:
                d((View) obj, (Float) obj2);
                return;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                d((View) obj, (Float) obj2);
                return;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                b((h) obj, (Float) obj2);
                return;
            case 13:
                b((h) obj, (Float) obj2);
                return;
            case 14:
                l lVar = (l) obj;
                float floatValue = ((Float) obj2).floatValue();
                if (lVar.f713h != floatValue) {
                    lVar.f713h = floatValue;
                    lVar.invalidateSelf();
                    return;
                }
                return;
            case 15:
                p pVar = (p) obj;
                float floatValue2 = ((Float) obj2).floatValue();
                pVar.f730i = floatValue2;
                Object obj3 = pVar.f22219b;
                ((float[]) obj3)[0] = 0.0f;
                float f10 = ((float) ((int) (floatValue2 * 333.0f))) / ((float) 667);
                float[] fArr = (float[]) obj3;
                b bVar = pVar.f726e;
                float interpolation = bVar.getInterpolation(f10);
                fArr[2] = interpolation;
                fArr[1] = interpolation;
                float[] fArr2 = (float[]) pVar.f22219b;
                float interpolation2 = bVar.getInterpolation(f10 + 0.49925038f);
                fArr2[4] = interpolation2;
                fArr2[3] = interpolation2;
                float[] fArr3 = (float[]) pVar.f22219b;
                fArr3[5] = 1.0f;
                if (pVar.f729h && fArr3[3] < 1.0f) {
                    int[] iArr = (int[]) pVar.f22220c;
                    iArr[2] = iArr[1];
                    iArr[1] = iArr[0];
                    iArr[0] = h9.f(pVar.f727f.f674c[pVar.f728g], ((n) pVar.f22218a).f715j);
                    pVar.f729h = false;
                }
                ((n) pVar.f22218a).invalidateSelf();
                return;
            default:
                r rVar = (r) obj;
                float floatValue3 = ((Float) obj2).floatValue();
                rVar.f742j = floatValue3;
                int i10 = (int) (floatValue3 * 1800.0f);
                for (int i11 = 0; i11 < 4; i11++) {
                    ((float[]) rVar.f22219b)[i11] = Math.max(0.0f, Math.min(1.0f, rVar.f738f[i11].getInterpolation(((float) (i10 - r.f734m[i11])) / ((float) r.f733l[i11]))));
                }
                if (rVar.f741i) {
                    Arrays.fill((int[]) rVar.f22220c, h9.f(rVar.f739g.f674c[rVar.f740h], ((n) rVar.f22218a).f715j));
                    rVar.f741i = false;
                }
                ((n) rVar.f22218a).invalidateSelf();
                return;
        }
    }
}
