package androidx.appcompat.widget;

import android.view.Window;

public interface k1 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
