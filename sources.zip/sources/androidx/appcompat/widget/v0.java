package androidx.appcompat.widget;

import android.os.LocaleList;
import android.widget.TextView;

public abstract class v0 {
    public static LocaleList a(String str) {
        return LocaleList.forLanguageTags(str);
    }

    public static void b(TextView textView, LocaleList localeList) {
        textView.setTextLocales(localeList);
    }
}
