package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

public final class w1 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1528a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ x1 f1529b;

    public /* synthetic */ w1(x1 x1Var, int i10) {
        this.f1528a = i10;
        this.f1529b = x1Var;
    }

    public final void run() {
        int i10 = this.f1528a;
        x1 x1Var = this.f1529b;
        switch (i10) {
            case 0:
                ViewParent parent = x1Var.f1542d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    return;
                }
                return;
            default:
                x1Var.a();
                View view = x1Var.f1542d;
                if (view.isEnabled() && !view.isLongClickable() && x1Var.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(obtain);
                    obtain.recycle();
                    x1Var.f1545g = true;
                    return;
                }
                return;
        }
    }
}
