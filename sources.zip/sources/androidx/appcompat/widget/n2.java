package androidx.appcompat.widget;

import s0.f;

public final class n2 extends f {
}
