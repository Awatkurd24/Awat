package androidx.appcompat.widget;

import android.view.View;

public final class v2 implements View.OnFocusChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SearchView f1525a;

    public v2(SearchView searchView) {
        this.f1525a = searchView;
    }

    public final void onFocusChange(View view, boolean z4) {
        SearchView searchView = this.f1525a;
        View.OnFocusChangeListener onFocusChangeListener = searchView.L;
        if (onFocusChangeListener != null) {
            onFocusChangeListener.onFocusChange(searchView, z4);
        }
    }
}
