package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import h.o0;
import ha.c;
import r1.t2;

public class FitWindowsFrameLayout extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    public v1 f1148a;

    public FitWindowsFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final boolean fitSystemWindows(Rect rect) {
        v1 v1Var = this.f1148a;
        if (v1Var != null) {
            rect.top = ((o0) ((c) v1Var).f19652b).M((t2) null, rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(v1 v1Var) {
        this.f1148a = v1Var;
    }
}
