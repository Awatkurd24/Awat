package androidx.appcompat.widget;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import co.vpn.plusvpn.R;

public final class v extends BaseAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ActivityChooserView f1524a;

    public v(ActivityChooserView activityChooserView) {
        this.f1524a = activityChooserView;
    }

    public final int getCount() {
        throw null;
    }

    public final Object getItem(int i10) {
        throw null;
    }

    public final long getItemId(int i10) {
        return (long) i10;
    }

    public final int getItemViewType(int i10) {
        return 0;
    }

    public final View getView(int i10, View view, ViewGroup viewGroup) {
        ActivityChooserView activityChooserView = this.f1524a;
        if (view == null || view.getId() != R.id.list_item) {
            view = LayoutInflater.from(activityChooserView.getContext()).inflate(R.layout.abc_activity_chooser_view_list_item, viewGroup, false);
        }
        activityChooserView.getContext().getPackageManager();
        ImageView imageView = (ImageView) view.findViewById(R.id.icon);
        getItem(i10);
        throw null;
    }

    public final int getViewTypeCount() {
        return 3;
    }
}
