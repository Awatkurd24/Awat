package androidx.appcompat.widget;

import android.os.Build;
import java.lang.reflect.Method;

public final class f3 {

    /* renamed from: a  reason: collision with root package name */
    public Method f1335a;

    /* renamed from: b  reason: collision with root package name */
    public Method f1336b;

    /* renamed from: c  reason: collision with root package name */
    public Method f1337c;

    public /* synthetic */ f3(Method method, Method method2, Method method3) {
        this.f1335a = method;
        this.f1336b = method2;
        this.f1337c = method3;
    }

    public static void a() {
        if (Build.VERSION.SDK_INT >= 29) {
            throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
        }
    }
}
