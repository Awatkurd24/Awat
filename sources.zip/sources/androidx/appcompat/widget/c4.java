package androidx.appcompat.widget;

import a4.i;
import a4.l;
import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.TextView;
import co.vpn.plusvpn.R;
import com.google.android.gms.internal.ads.a40;
import com.google.android.gms.internal.ads.b60;
import com.google.android.gms.internal.ads.co0;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.dd;
import com.google.android.gms.internal.ads.hk;
import com.google.android.gms.internal.ads.i00;
import com.google.android.gms.internal.ads.jv;
import com.google.android.gms.internal.ads.k00;
import com.google.android.gms.internal.ads.ls0;
import com.google.android.gms.internal.ads.me;
import com.google.android.gms.internal.ads.mv;
import com.google.android.gms.internal.ads.o8;
import com.google.android.gms.internal.ads.so0;
import com.google.android.gms.internal.ads.vx;
import com.google.android.gms.internal.ads.ya0;
import eb.a;
import fa.c;
import fa.s;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.atomic.AtomicMarkableReference;
import ma.g;
import ma.o;
import ma.p;
import s0.k;
import za.b;

public final class c4 implements i00, c {

    /* renamed from: a  reason: collision with root package name */
    public Object f1315a;

    /* renamed from: b  reason: collision with root package name */
    public Object f1316b;

    /* renamed from: c  reason: collision with root package name */
    public Object f1317c;

    /* renamed from: d  reason: collision with root package name */
    public Object f1318d;

    /* renamed from: e  reason: collision with root package name */
    public Object f1319e;

    /* renamed from: f  reason: collision with root package name */
    public Object f1320f;

    /* renamed from: g  reason: collision with root package name */
    public Object f1321g;

    public c4(int i10) {
        if (i10 == 5) {
            this.f1320f = new k();
            this.f1321g = new k();
        }
    }

    public static final void m(SQLiteDatabase sQLiteDatabase, ArrayList arrayList) {
        int size = arrayList.size();
        long j3 = 0;
        for (int i10 = 0; i10 < size; i10++) {
            dd ddVar = (dd) arrayList.get(i10);
            if (ddVar.S() == 2 && ddVar.B() > j3) {
                j3 = ddVar.B();
            }
        }
        if (j3 != 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("value", Long.valueOf(j3));
            sQLiteDatabase.update("offline_signal_statistics", contentValues, "statistic_name = 'last_successful_request_time'", (String[]) null);
        }
    }

    public final Object a(Class cls) {
        if (((Set) this.f1315a).contains(s.a(cls))) {
            Object a10 = ((c) this.f1321g).a(cls);
            if (!cls.equals(b.class)) {
                return a10;
            }
            b bVar = (b) a10;
            return new Object();
        }
        throw new RuntimeException(String.format("Attempting to request an undeclared dependency %s.", new Object[]{cls}));
    }

    public final Object b(s sVar) {
        if (((Set) this.f1315a).contains(sVar)) {
            return ((c) this.f1321g).b(sVar);
        }
        throw new RuntimeException(String.format("Attempting to request an undeclared dependency %s.", new Object[]{sVar}));
    }

    public final Set c(s sVar) {
        if (((Set) this.f1318d).contains(sVar)) {
            return ((c) this.f1321g).c(sVar);
        }
        throw new RuntimeException(String.format("Attempting to request an undeclared dependency Set<%s>.", new Object[]{sVar}));
    }

    public final cb.b d(s sVar) {
        if (((Set) this.f1317c).contains(sVar)) {
            return ((c) this.f1321g).d(sVar);
        }
        throw new RuntimeException(String.format("Attempting to request an undeclared dependency Deferred<%s>.", new Object[]{sVar}));
    }

    public final cb.c e(s sVar) {
        if (((Set) this.f1316b).contains(sVar)) {
            return ((c) this.f1321g).e(sVar);
        }
        throw new RuntimeException(String.format("Attempting to request an undeclared dependency Provider<%s>.", new Object[]{sVar}));
    }

    public final cb.c f(Class cls) {
        return e(s.a(cls));
    }

    public final a g() {
        String str;
        if (((eb.c) this.f1316b) == null) {
            str = " registrationStatus";
        } else {
            str = "";
        }
        if (((Long) this.f1319e) == null) {
            str = str.concat(" expiresInSecs");
        }
        if (((Long) this.f1320f) == null) {
            str = l.H(str, " tokenCreationEpochInSecs");
        }
        if (str.isEmpty()) {
            return new a((String) this.f1315a, (eb.c) this.f1316b, (String) this.f1317c, (String) this.f1318d, ((Long) this.f1319e).longValue(), ((Long) this.f1320f).longValue(), (String) this.f1321g);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final void h(String str, ArrayList arrayList) {
        String[] stringArrayExtra = ((Intent) this.f1316b).getStringArrayExtra(str);
        int length = stringArrayExtra != null ? stringArrayExtra.length : 0;
        String[] strArr = new String[(arrayList.size() + length)];
        arrayList.toArray(strArr);
        if (stringArrayExtra != null) {
            System.arraycopy(stringArrayExtra, 0, strArr, arrayList.size(), length);
        }
        ((Intent) this.f1316b).putExtra(str, strArr);
    }

    public final cb.b i(Class cls) {
        return d(s.a(cls));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002b, code lost:
        r4 = new b4.h(1, r0);
        r1 = (java.util.concurrent.atomic.AtomicReference) r0.f22495b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0039, code lost:
        if (r1.compareAndSet((java.lang.Object) null, r4) == false) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003b, code lost:
        ((a4.i) ((androidx.appcompat.widget.c4) r0.f22497d).f1316b).t(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x004b, code lost:
        if (r1.get() == null) goto L_0x0034;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void j(java.lang.String r4) {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f1319e
            ma.p r0 = (ma.p) r0
            monitor-enter(r0)
            java.lang.Object r1 = r0.f22496c     // Catch:{ all -> 0x0017 }
            java.util.concurrent.atomic.AtomicMarkableReference r1 = (java.util.concurrent.atomic.AtomicMarkableReference) r1     // Catch:{ all -> 0x0017 }
            java.lang.Object r1 = r1.getReference()     // Catch:{ all -> 0x0017 }
            ma.d r1 = (ma.d) r1     // Catch:{ all -> 0x0017 }
            boolean r4 = r1.c(r4)     // Catch:{ all -> 0x0017 }
            if (r4 != 0) goto L_0x0019
            monitor-exit(r0)     // Catch:{ all -> 0x0017 }
            goto L_0x004d
        L_0x0017:
            r4 = move-exception
            goto L_0x004e
        L_0x0019:
            java.lang.Object r4 = r0.f22496c     // Catch:{ all -> 0x0017 }
            r1 = r4
            java.util.concurrent.atomic.AtomicMarkableReference r1 = (java.util.concurrent.atomic.AtomicMarkableReference) r1     // Catch:{ all -> 0x0017 }
            java.util.concurrent.atomic.AtomicMarkableReference r4 = (java.util.concurrent.atomic.AtomicMarkableReference) r4     // Catch:{ all -> 0x0017 }
            java.lang.Object r4 = r4.getReference()     // Catch:{ all -> 0x0017 }
            ma.d r4 = (ma.d) r4     // Catch:{ all -> 0x0017 }
            r2 = 1
            r1.set(r4, r2)     // Catch:{ all -> 0x0017 }
            monitor-exit(r0)     // Catch:{ all -> 0x0017 }
            b4.h r4 = new b4.h
            r4.<init>(r2, r0)
            java.lang.Object r1 = r0.f22495b
            java.util.concurrent.atomic.AtomicReference r1 = (java.util.concurrent.atomic.AtomicReference) r1
        L_0x0034:
            r2 = 0
            boolean r2 = r1.compareAndSet(r2, r4)
            if (r2 == 0) goto L_0x0047
            java.lang.Object r0 = r0.f22497d
            androidx.appcompat.widget.c4 r0 = (androidx.appcompat.widget.c4) r0
            java.lang.Object r0 = r0.f1316b
            a4.i r0 = (a4.i) r0
            r0.t(r4)
            goto L_0x004d
        L_0x0047:
            java.lang.Object r2 = r1.get()
            if (r2 == 0) goto L_0x0034
        L_0x004d:
            return
        L_0x004e:
            monitor-exit(r0)     // Catch:{ all -> 0x0017 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.c4.j(java.lang.String):void");
    }

    public final Set k(Class cls) {
        return c(s.a(cls));
    }

    public final void l(eb.c cVar) {
        if (cVar != null) {
            this.f1316b = cVar;
            return;
        }
        throw new NullPointerException("Null registrationStatus");
    }

    public final jv n() {
        cq0.o1((a40) this.f1318d, a40.class);
        cq0.o1((k00) this.f1319e, k00.class);
        cq0.o1((b60) this.f1320f, b60.class);
        cq0.o1((vx) this.f1321g, vx.class);
        return new jv((mv) this.f1315a, (vx) this.f1321g, (b60) this.f1320f, new ya0(8), new hk(25), (a40) this.f1318d, (k00) this.f1319e, new o8(20), (so0) this.f1316b, (co0) this.f1317c);
    }

    public c4(Context context, int i10) {
        Activity activity = null;
        if (i10 != 1) {
            this.f1318d = new WindowManager.LayoutParams();
            this.f1319e = new Rect();
            this.f1320f = new int[2];
            this.f1321g = new int[2];
            this.f1315a = context;
            View inflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
            this.f1316b = inflate;
            this.f1317c = (TextView) inflate.findViewById(R.id.message);
            ((WindowManager.LayoutParams) this.f1318d).setTitle(c4.class.getSimpleName());
            ((WindowManager.LayoutParams) this.f1318d).packageName = ((Context) this.f1315a).getPackageName();
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) this.f1318d;
            layoutParams.type = 1002;
            layoutParams.width = -2;
            layoutParams.height = -2;
            layoutParams.format = -3;
            layoutParams.windowAnimations = 2132017158;
            layoutParams.flags = 24;
            return;
        }
        context.getClass();
        this.f1315a = context;
        Intent action = new Intent().setAction("android.intent.action.SEND");
        this.f1316b = action;
        action.putExtra("androidx.core.app.EXTRA_CALLING_PACKAGE", context.getPackageName());
        ((Intent) this.f1316b).putExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE", context.getPackageName());
        ((Intent) this.f1316b).addFlags(524288);
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                break;
            } else if (context instanceof Activity) {
                activity = (Activity) context;
                break;
            } else {
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        if (activity != null) {
            ComponentName componentName = activity.getComponentName();
            ((Intent) this.f1316b).putExtra("androidx.core.app.EXTRA_CALLING_ACTIVITY", componentName);
            ((Intent) this.f1316b).putExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY", componentName);
        }
    }

    public c4(me meVar, WebView webView, String str, ls0 ls0) {
        this.f1317c = new ArrayList();
        this.f1318d = new HashMap();
        this.f1315a = meVar;
        this.f1316b = webView;
        this.f1321g = ls0;
        this.f1320f = str;
        this.f1319e = "";
    }

    public /* synthetic */ c4(Object obj, String str, String str2, Serializable serializable, Serializable serializable2, Object obj2, Object obj3) {
        this.f1315a = obj;
        this.f1316b = str;
        this.f1317c = str2;
        this.f1318d = serializable;
        this.f1319e = serializable2;
        this.f1320f = obj2;
        this.f1321g = obj3;
    }

    public c4(String str, pa.b bVar, i iVar) {
        this.f1318d = new p(this, false);
        this.f1319e = new p(this, true);
        this.f1320f = new o();
        this.f1321g = new AtomicMarkableReference((Object) null, false);
        this.f1317c = str;
        this.f1315a = new g(bVar);
        this.f1316b = iVar;
    }
}
