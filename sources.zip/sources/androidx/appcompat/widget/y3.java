package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import co.vpn.plusvpn.R;
import g.a;
import r1.h1;

public final class y3 implements l1 {

    /* renamed from: a  reason: collision with root package name */
    public final Toolbar f1570a;

    /* renamed from: b  reason: collision with root package name */
    public int f1571b;

    /* renamed from: c  reason: collision with root package name */
    public final View f1572c;

    /* renamed from: d  reason: collision with root package name */
    public Drawable f1573d;

    /* renamed from: e  reason: collision with root package name */
    public Drawable f1574e;

    /* renamed from: f  reason: collision with root package name */
    public Drawable f1575f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f1576g;

    /* renamed from: h  reason: collision with root package name */
    public CharSequence f1577h;

    /* renamed from: i  reason: collision with root package name */
    public final CharSequence f1578i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f1579j;

    /* renamed from: k  reason: collision with root package name */
    public Window.Callback f1580k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f1581l;

    /* renamed from: m  reason: collision with root package name */
    public n f1582m;

    /* renamed from: n  reason: collision with root package name */
    public final int f1583n = 0;

    /* renamed from: o  reason: collision with root package name */
    public final Drawable f1584o;

    public y3(Toolbar toolbar, boolean z4) {
        boolean z10;
        Drawable drawable;
        this.f1570a = toolbar;
        this.f1577h = toolbar.getTitle();
        this.f1578i = toolbar.getSubtitle();
        if (this.f1577h != null) {
            z10 = true;
        } else {
            z10 = false;
        }
        this.f1576g = z10;
        this.f1575f = toolbar.getNavigationIcon();
        w K = w.K(toolbar.getContext(), (AttributeSet) null, a.f18919a, R.attr.actionBarStyle);
        int i10 = 15;
        this.f1584o = K.w(15);
        if (z4) {
            CharSequence F = K.F(27);
            if (!TextUtils.isEmpty(F)) {
                this.f1576g = true;
                this.f1577h = F;
                if ((this.f1571b & 8) != 0) {
                    Toolbar toolbar2 = this.f1570a;
                    toolbar2.setTitle(F);
                    if (this.f1576g) {
                        h1.s(toolbar2.getRootView(), F);
                    }
                }
            }
            CharSequence F2 = K.F(25);
            if (!TextUtils.isEmpty(F2)) {
                this.f1578i = F2;
                if ((this.f1571b & 8) != 0) {
                    toolbar.setSubtitle(F2);
                }
            }
            Drawable w10 = K.w(20);
            if (w10 != null) {
                this.f1574e = w10;
                d();
            }
            Drawable w11 = K.w(17);
            if (w11 != null) {
                this.f1573d = w11;
                d();
            }
            if (this.f1575f == null && (drawable = this.f1584o) != null) {
                this.f1575f = drawable;
                int i11 = this.f1571b & 4;
                Toolbar toolbar3 = this.f1570a;
                if (i11 != 0) {
                    toolbar3.setNavigationIcon(drawable);
                } else {
                    toolbar3.setNavigationIcon((Drawable) null);
                }
            }
            a(K.z(10, 0));
            int B = K.B(9, 0);
            if (B != 0) {
                View inflate = LayoutInflater.from(toolbar.getContext()).inflate(B, toolbar, false);
                View view = this.f1572c;
                if (!(view == null || (this.f1571b & 16) == 0)) {
                    toolbar.removeView(view);
                }
                this.f1572c = inflate;
                if (!(inflate == null || (this.f1571b & 16) == 0)) {
                    toolbar.addView(inflate);
                }
                a(this.f1571b | 16);
            }
            int layoutDimension = ((TypedArray) K.f619c).getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
                layoutParams.height = layoutDimension;
                toolbar.setLayoutParams(layoutParams);
            }
            int u10 = K.u(7, -1);
            int u11 = K.u(3, -1);
            if (u10 >= 0 || u11 >= 0) {
                int max = Math.max(u10, 0);
                int max2 = Math.max(u11, 0);
                toolbar.d();
                toolbar.f1267t.a(max, max2);
            }
            int B2 = K.B(28, 0);
            if (B2 != 0) {
                Context context = toolbar.getContext();
                toolbar.f1258l = B2;
                AppCompatTextView appCompatTextView = toolbar.f1248b;
                if (appCompatTextView != null) {
                    appCompatTextView.setTextAppearance(context, B2);
                }
            }
            int B3 = K.B(26, 0);
            if (B3 != 0) {
                Context context2 = toolbar.getContext();
                toolbar.f1259m = B3;
                AppCompatTextView appCompatTextView2 = toolbar.f1249c;
                if (appCompatTextView2 != null) {
                    appCompatTextView2.setTextAppearance(context2, B3);
                }
            }
            int B4 = K.B(22, 0);
            if (B4 != 0) {
                toolbar.setPopupTheme(B4);
            }
        } else {
            if (toolbar.getNavigationIcon() != null) {
                this.f1584o = toolbar.getNavigationIcon();
            } else {
                i10 = 11;
            }
            this.f1571b = i10;
        }
        K.N();
        if (R.string.abc_action_bar_up_description != this.f1583n) {
            this.f1583n = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                b(this.f1583n);
            }
        }
        this.f1579j = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new c(this));
    }

    public final void a(int i10) {
        View view;
        int i11 = this.f1571b ^ i10;
        this.f1571b = i10;
        if (i11 != 0) {
            if ((i11 & 4) != 0) {
                if ((i10 & 4) != 0) {
                    c();
                }
                int i12 = this.f1571b & 4;
                Toolbar toolbar = this.f1570a;
                if (i12 != 0) {
                    Drawable drawable = this.f1575f;
                    if (drawable == null) {
                        drawable = this.f1584o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i11 & 3) != 0) {
                d();
            }
            int i13 = i11 & 8;
            Toolbar toolbar2 = this.f1570a;
            if (i13 != 0) {
                if ((i10 & 8) != 0) {
                    toolbar2.setTitle(this.f1577h);
                    toolbar2.setSubtitle(this.f1578i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i11 & 16) != 0 && (view = this.f1572c) != null) {
                if ((i10 & 16) != 0) {
                    toolbar2.addView(view);
                } else {
                    toolbar2.removeView(view);
                }
            }
        }
    }

    public final void b(int i10) {
        String str;
        if (i10 == 0) {
            str = null;
        } else {
            str = this.f1570a.getContext().getString(i10);
        }
        this.f1579j = str;
        c();
    }

    public final void c() {
        if ((this.f1571b & 4) != 0) {
            boolean isEmpty = TextUtils.isEmpty(this.f1579j);
            Toolbar toolbar = this.f1570a;
            if (isEmpty) {
                toolbar.setNavigationContentDescription(this.f1583n);
            } else {
                toolbar.setNavigationContentDescription(this.f1579j);
            }
        }
    }

    public final void d() {
        Drawable drawable;
        int i10 = this.f1571b;
        if ((i10 & 2) == 0) {
            drawable = null;
        } else if ((i10 & 1) == 0 || (drawable = this.f1574e) == null) {
            drawable = this.f1573d;
        }
        this.f1570a.setLogo(drawable);
    }
}
