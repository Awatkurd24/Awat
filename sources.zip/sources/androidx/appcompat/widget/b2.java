package androidx.appcompat.widget;

import android.view.View;
import android.widget.PopupWindow;

public abstract class b2 {
    public static int a(PopupWindow popupWindow, View view, int i10, boolean z4) {
        return popupWindow.getMaxAvailableHeight(view, i10, z4);
    }
}
