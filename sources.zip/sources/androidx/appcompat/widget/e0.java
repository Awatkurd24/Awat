package androidx.appcompat.widget;

import a4.w;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import com.google.android.gms.dynamite.descriptors.com.google.mlkit.dynamite.barcode.ModuleDescriptor;
import k1.i;
import k1.j;

public class e0 {

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f1329c = {16843067, 16843068};

    /* renamed from: a  reason: collision with root package name */
    public final ProgressBar f1330a;

    /* renamed from: b  reason: collision with root package name */
    public Bitmap f1331b;

    public e0(ProgressBar progressBar) {
        this.f1330a = progressBar;
    }

    public void a(AttributeSet attributeSet, int i10) {
        ProgressBar progressBar = this.f1330a;
        w K = w.K(progressBar.getContext(), attributeSet, f1329c, i10);
        Drawable x4 = K.x(0);
        if (x4 != null) {
            if (x4 instanceof AnimationDrawable) {
                AnimationDrawable animationDrawable = (AnimationDrawable) x4;
                int numberOfFrames = animationDrawable.getNumberOfFrames();
                AnimationDrawable animationDrawable2 = new AnimationDrawable();
                animationDrawable2.setOneShot(animationDrawable.isOneShot());
                for (int i11 = 0; i11 < numberOfFrames; i11++) {
                    Drawable b5 = b(animationDrawable.getFrame(i11), true);
                    b5.setLevel(ModuleDescriptor.MODULE_VERSION);
                    animationDrawable2.addFrame(b5, animationDrawable.getDuration(i11));
                }
                animationDrawable2.setLevel(ModuleDescriptor.MODULE_VERSION);
                x4 = animationDrawable2;
            }
            progressBar.setIndeterminateDrawable(x4);
        }
        Drawable x10 = K.x(1);
        if (x10 != null) {
            progressBar.setProgressDrawable(b(x10, false));
        }
        K.N();
    }

    public final Drawable b(Drawable drawable, boolean z4) {
        boolean z10;
        if (drawable instanceof i) {
            j jVar = (j) ((i) drawable);
            Drawable drawable2 = jVar.f21244f;
            if (drawable2 != null) {
                jVar.c(b(drawable2, z4));
            }
        } else if (drawable instanceof LayerDrawable) {
            LayerDrawable layerDrawable = (LayerDrawable) drawable;
            int numberOfLayers = layerDrawable.getNumberOfLayers();
            Drawable[] drawableArr = new Drawable[numberOfLayers];
            for (int i10 = 0; i10 < numberOfLayers; i10++) {
                int id2 = layerDrawable.getId(i10);
                Drawable drawable3 = layerDrawable.getDrawable(i10);
                if (id2 == 16908301 || id2 == 16908303) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                drawableArr[i10] = b(drawable3, z10);
            }
            LayerDrawable layerDrawable2 = new LayerDrawable(drawableArr);
            for (int i11 = 0; i11 < numberOfLayers; i11++) {
                layerDrawable2.setId(i11, layerDrawable.getId(i11));
                if (Build.VERSION.SDK_INT >= 23) {
                    d0.e(layerDrawable, layerDrawable2, i11);
                }
            }
            return layerDrawable2;
        } else if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            Bitmap bitmap = bitmapDrawable.getBitmap();
            if (this.f1331b == null) {
                this.f1331b = bitmap;
            }
            ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f}, (RectF) null, (float[]) null));
            shapeDrawable.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
            shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
            if (z4) {
                return new ClipDrawable(shapeDrawable, 3, 1);
            }
            return shapeDrawable;
        }
        return drawable;
    }
}
