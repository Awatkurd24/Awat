package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.TextView;
import g.a;
import ha.c;
import u7.a0;

public final class b0 {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1292a;

    /* renamed from: b  reason: collision with root package name */
    public final c f1293b;

    public b0(TextView textView) {
        this.f1292a = textView;
        this.f1293b = new c(textView);
    }

    public final InputFilter[] a(InputFilter[] inputFilterArr) {
        return ((a0) this.f1293b.f19652b).o(inputFilterArr);
    }

    /* JADX INFO: finally extract failed */
    public final void b(AttributeSet attributeSet, int i10) {
        TypedArray obtainStyledAttributes = this.f1292a.getContext().obtainStyledAttributes(attributeSet, a.f18928j, i10, 0);
        try {
            boolean z4 = true;
            if (obtainStyledAttributes.hasValue(14)) {
                z4 = obtainStyledAttributes.getBoolean(14, true);
            }
            obtainStyledAttributes.recycle();
            d(z4);
        } catch (Throwable th2) {
            obtainStyledAttributes.recycle();
            throw th2;
        }
    }

    public final void c(boolean z4) {
        ((a0) this.f1293b.f19652b).s(z4);
    }

    public final void d(boolean z4) {
        ((a0) this.f1293b.f19652b).t(z4);
    }
}
