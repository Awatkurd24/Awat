package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import co.vpn.plusvpn.R;
import v1.v;
import v7.je;

public class AppCompatButton extends Button implements v {

    /* renamed from: a  reason: collision with root package name */
    public final x f1084a;

    /* renamed from: b  reason: collision with root package name */
    public final y0 f1085b;

    /* renamed from: c  reason: collision with root package name */
    public b0 f1086c;

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyle);
    }

    private b0 getEmojiTextViewHelper() {
        if (this.f1086c == null) {
            this.f1086c = new b0(this);
        }
        return this.f1086c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1084a;
        if (xVar != null) {
            xVar.a();
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (f4.f1339b) {
            return super.getAutoSizeMaxTextSize();
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1356e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (f4.f1339b) {
            return super.getAutoSizeMinTextSize();
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1355d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (f4.f1339b) {
            return super.getAutoSizeStepGranularity();
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1354c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (f4.f1339b) {
            return super.getAutoSizeTextAvailableSizes();
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            return y0Var.f1564i.f1357f;
        }
        return new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (!f4.f1339b) {
            y0 y0Var = this.f1085b;
            if (y0Var != null) {
                return y0Var.f1564i.f1352a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return je.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1084a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1084a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1085b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1085b.e();
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        super.onLayout(z4, i10, i11, i12, i13);
        y0 y0Var = this.f1085b;
        if (y0Var != null && !f4.f1339b) {
            y0Var.f1564i.a();
        }
    }

    public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        super.onTextChanged(charSequence, i10, i11, i12);
        y0 y0Var = this.f1085b;
        if (y0Var != null && !f4.f1339b) {
            i1 i1Var = y0Var.f1564i;
            if (i1Var.f()) {
                i1Var.a();
            }
        }
    }

    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i10, int i11, int i12, int i13) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i10, i11, i12, i13);
            return;
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.i(i10, i11, i12, i13);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i10) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i10);
            return;
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.j(iArr, i10);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i10) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeWithDefaults(i10);
            return;
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.k(i10);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1084a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1084a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(je.s(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z4) {
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.f1556a.setAllCaps(z4);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1084a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1084a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        y0 y0Var = this.f1085b;
        y0Var.l(colorStateList);
        y0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        y0 y0Var = this.f1085b;
        y0Var.m(mode);
        y0Var.b();
    }

    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        y0 y0Var = this.f1085b;
        if (y0Var != null) {
            y0Var.g(context, i10);
        }
    }

    public final void setTextSize(int i10, float f10) {
        boolean z4 = f4.f1339b;
        if (z4) {
            super.setTextSize(i10, f10);
            return;
        }
        y0 y0Var = this.f1085b;
        if (y0Var != null && !z4) {
            i1 i1Var = y0Var.f1564i;
            if (!i1Var.f()) {
                i1Var.g(i10, f10);
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        o3.a(getContext(), this);
        x xVar = new x((View) this);
        this.f1084a = xVar;
        xVar.f(attributeSet, i10);
        y0 y0Var = new y0(this);
        this.f1085b = y0Var;
        y0Var.f(attributeSet, i10);
        y0Var.b();
        getEmojiTextViewHelper().b(attributeSet, i10);
    }
}
