package androidx.appcompat.widget;

import android.widget.PopupWindow;

public abstract class i2 {
    public static void a(PopupWindow popupWindow, boolean z4) {
        popupWindow.setTouchModal(z4);
    }
}
