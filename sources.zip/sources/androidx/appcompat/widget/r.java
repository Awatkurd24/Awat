package androidx.appcompat.widget;

public interface r {
}
