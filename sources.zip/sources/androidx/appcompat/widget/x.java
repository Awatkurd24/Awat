package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Base64;
import android.view.View;
import b0.s;
import e8.a;
import f9.n;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import r1.h1;
import r1.v0;
import t.c0;
import u.b0;
import u.g;
import v7.i9;
import v7.t9;
import w7.ua;

public final class x {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1532a;

    /* renamed from: b  reason: collision with root package name */
    public int f1533b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f1534c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f1535d;

    /* renamed from: e  reason: collision with root package name */
    public Object f1536e;

    /* renamed from: f  reason: collision with root package name */
    public Object f1537f;

    /* renamed from: g  reason: collision with root package name */
    public Object f1538g;

    public x(ColorStateList colorStateList, ColorStateList colorStateList2, ColorStateList colorStateList3, int i10, n nVar, Rect rect) {
        this.f1532a = 3;
        ua.e(rect.left);
        ua.e(rect.top);
        ua.e(rect.right);
        ua.e(rect.bottom);
        this.f1534c = rect;
        this.f1535d = colorStateList2;
        this.f1536e = colorStateList;
        this.f1537f = colorStateList3;
        this.f1533b = i10;
        this.f1538g = nVar;
    }

    public static x b(Context context, int i10) {
        ua.b("Cannot create a CalendarItemStyle with a styleResId of 0", i10 != 0);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(i10, a.C);
        Rect rect = new Rect(obtainStyledAttributes.getDimensionPixelOffset(0, 0), obtainStyledAttributes.getDimensionPixelOffset(2, 0), obtainStyledAttributes.getDimensionPixelOffset(1, 0), obtainStyledAttributes.getDimensionPixelOffset(3, 0));
        ColorStateList r4 = i9.r(context, obtainStyledAttributes, 4);
        ColorStateList r5 = i9.r(context, obtainStyledAttributes, 9);
        ColorStateList r10 = i9.r(context, obtainStyledAttributes, 7);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        n a10 = n.a(obtainStyledAttributes.getResourceId(5, 0), context, obtainStyledAttributes.getResourceId(6, 0)).a();
        obtainStyledAttributes.recycle();
        return new x(r4, r5, r10, dimensionPixelSize, a10, rect);
    }

    public final void a() {
        View view = (View) this.f1534c;
        Drawable background = view.getBackground();
        if (background != null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 <= 21 ? i10 == 21 : ((q3) this.f1536e) != null) {
                if (((q3) this.f1538g) == null) {
                    this.f1538g = new Object();
                }
                q3 q3Var = (q3) this.f1538g;
                q3Var.f1478c = null;
                q3Var.f1477b = false;
                q3Var.f1479d = null;
                q3Var.f1476a = false;
                WeakHashMap weakHashMap = h1.f25195a;
                ColorStateList g10 = v0.g(view);
                if (g10 != null) {
                    q3Var.f1477b = true;
                    q3Var.f1478c = g10;
                }
                PorterDuff.Mode h10 = v0.h(view);
                if (h10 != null) {
                    q3Var.f1476a = true;
                    q3Var.f1479d = h10;
                }
                if (q3Var.f1477b || q3Var.f1476a) {
                    z.e(background, q3Var, view.getDrawableState());
                    return;
                }
            }
            q3 q3Var2 = (q3) this.f1537f;
            if (q3Var2 != null) {
                z.e(background, q3Var2, view.getDrawableState());
                return;
            }
            q3 q3Var3 = (q3) this.f1536e;
            if (q3Var3 != null) {
                z.e(background, q3Var3, view.getDrawableState());
            }
        }
    }

    public final String c(String str) {
        if (!((Map) this.f1536e).containsKey(str)) {
            return null;
        }
        for (String str2 : (List) ((Map) this.f1536e).get(str)) {
            Iterator it = ((List) this.f1537f).iterator();
            while (true) {
                if (it.hasNext()) {
                    s i10 = ((s) it.next()).i();
                    ua.b("CameraInfo doesn't contain Camera2 implementation.", i10 instanceof c0);
                    if (str2.equals(((c0) ((c0) i10).f26195c.f19253a).f26193a)) {
                        return str2;
                    }
                }
            }
        }
        return null;
    }

    public final ColorStateList d() {
        Object obj = this.f1537f;
        if (((q3) obj) != null) {
            return (ColorStateList) ((q3) obj).f1478c;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        Object obj = this.f1537f;
        if (((q3) obj) != null) {
            return (PorterDuff.Mode) ((q3) obj).f1479d;
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0046, code lost:
        r9 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00a0, code lost:
        r7.N();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00a3, code lost:
        throw r9;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(android.util.AttributeSet r9, int r10) {
        /*
            r8 = this;
            java.lang.Object r0 = r8.f1534c
            r1 = r0
            android.view.View r1 = (android.view.View) r1
            android.content.Context r2 = r1.getContext()
            int[] r3 = g.a.C
            a4.w r7 = a4.w.K(r2, r9, r3, r10)
            android.content.Context r2 = r1.getContext()
            java.lang.Object r4 = r7.f619c
            r5 = r4
            android.content.res.TypedArray r5 = (android.content.res.TypedArray) r5
            r4 = r9
            r6 = r10
            r1.h1.q(r1, r2, r3, r4, r5, r6)
            r9 = 0
            boolean r10 = r7.G(r9)     // Catch:{ all -> 0x0046 }
            r1 = -1
            if (r10 == 0) goto L_0x004b
            int r10 = r7.B(r9, r1)     // Catch:{ all -> 0x0046 }
            r8.f1533b = r10     // Catch:{ all -> 0x0046 }
            java.lang.Object r10 = r8.f1535d     // Catch:{ all -> 0x0046 }
            androidx.appcompat.widget.z r10 = (androidx.appcompat.widget.z) r10     // Catch:{ all -> 0x0046 }
            r2 = r0
            android.view.View r2 = (android.view.View) r2     // Catch:{ all -> 0x0046 }
            android.content.Context r2 = r2.getContext()     // Catch:{ all -> 0x0046 }
            int r3 = r8.f1533b     // Catch:{ all -> 0x0046 }
            monitor-enter(r10)     // Catch:{ all -> 0x0046 }
            androidx.appcompat.widget.p2 r4 = r10.f1587a     // Catch:{ all -> 0x0048 }
            android.content.res.ColorStateList r2 = r4.i(r2, r3)     // Catch:{ all -> 0x0048 }
            monitor-exit(r10)     // Catch:{ all -> 0x0046 }
            if (r2 == 0) goto L_0x004b
            r8.i(r2)     // Catch:{ all -> 0x0046 }
            goto L_0x004b
        L_0x0046:
            r9 = move-exception
            goto L_0x00a0
        L_0x0048:
            r9 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0046 }
            throw r9     // Catch:{ all -> 0x0046 }
        L_0x004b:
            r10 = 1
            boolean r2 = r7.G(r10)     // Catch:{ all -> 0x0046 }
            if (r2 == 0) goto L_0x005c
            r2 = r0
            android.view.View r2 = (android.view.View) r2     // Catch:{ all -> 0x0046 }
            android.content.res.ColorStateList r3 = r7.t(r10)     // Catch:{ all -> 0x0046 }
            r1.h1.t(r2, r3)     // Catch:{ all -> 0x0046 }
        L_0x005c:
            r2 = 2
            boolean r3 = r7.G(r2)     // Catch:{ all -> 0x0046 }
            if (r3 == 0) goto L_0x009c
            android.view.View r0 = (android.view.View) r0     // Catch:{ all -> 0x0046 }
            int r1 = r7.z(r2, r1)     // Catch:{ all -> 0x0046 }
            r2 = 0
            android.graphics.PorterDuff$Mode r1 = androidx.appcompat.widget.o1.c(r1, r2)     // Catch:{ all -> 0x0046 }
            int r2 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x0046 }
            r1.v0.r(r0, r1)     // Catch:{ all -> 0x0046 }
            r1 = 21
            if (r2 != r1) goto L_0x009c
            android.graphics.drawable.Drawable r1 = r0.getBackground()     // Catch:{ all -> 0x0046 }
            android.content.res.ColorStateList r2 = r1.v0.g(r0)     // Catch:{ all -> 0x0046 }
            if (r2 != 0) goto L_0x0087
            android.graphics.PorterDuff$Mode r2 = r1.v0.h(r0)     // Catch:{ all -> 0x0046 }
            if (r2 == 0) goto L_0x0088
        L_0x0087:
            r9 = 1
        L_0x0088:
            if (r1 == 0) goto L_0x009c
            if (r9 == 0) goto L_0x009c
            boolean r9 = r1.isStateful()     // Catch:{ all -> 0x0046 }
            if (r9 == 0) goto L_0x0099
            int[] r9 = r0.getDrawableState()     // Catch:{ all -> 0x0046 }
            r1.setState(r9)     // Catch:{ all -> 0x0046 }
        L_0x0099:
            r1.p0.q(r0, r1)     // Catch:{ all -> 0x0046 }
        L_0x009c:
            r7.N()
            return
        L_0x00a0:
            r7.N()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.x.f(android.util.AttributeSet, int):void");
    }

    public final void g() {
        this.f1533b = -1;
        i((ColorStateList) null);
        a();
    }

    public final void h(int i10) {
        ColorStateList colorStateList;
        this.f1533b = i10;
        z zVar = (z) this.f1535d;
        if (zVar != null) {
            Context context = ((View) this.f1534c).getContext();
            synchronized (zVar) {
                colorStateList = zVar.f1587a.i(context, i10);
            }
        } else {
            colorStateList = null;
        }
        i(colorStateList);
        a();
    }

    public final void i(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (((q3) this.f1536e) == null) {
                this.f1536e = new Object();
            }
            Object obj = this.f1536e;
            ((q3) obj).f1478c = colorStateList;
            ((q3) obj).f1477b = true;
        } else {
            this.f1536e = null;
        }
        a();
    }

    public final void j(ColorStateList colorStateList) {
        if (((q3) this.f1537f) == null) {
            this.f1537f = new Object();
        }
        q3 q3Var = (q3) this.f1537f;
        q3Var.f1478c = colorStateList;
        q3Var.f1477b = true;
        a();
    }

    public final void k(PorterDuff.Mode mode) {
        if (((q3) this.f1537f) == null) {
            this.f1537f = new Object();
        }
        q3 q3Var = (q3) this.f1537f;
        q3Var.f1479d = mode;
        q3Var.f1476a = true;
        a();
    }

    public final String toString() {
        switch (this.f1532a) {
            case 2:
                StringBuilder sb2 = new StringBuilder();
                sb2.append("FontRequest {mProviderAuthority: " + ((String) this.f1534c) + ", mProviderPackage: " + ((String) this.f1535d) + ", mQuery: " + ((String) this.f1536e) + ", mCertificates:");
                for (int i10 = 0; i10 < ((List) this.f1537f).size(); i10++) {
                    sb2.append(" [");
                    List list = (List) ((List) this.f1537f).get(i10);
                    for (int i11 = 0; i11 < list.size(); i11++) {
                        sb2.append(" \"");
                        sb2.append(Base64.encodeToString((byte[]) list.get(i11), 0));
                        sb2.append("\"");
                    }
                    sb2.append(" ]");
                }
                sb2.append("}");
                sb2.append("mCertificatesArray: " + this.f1533b);
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    public x(View view) {
        this.f1532a = 0;
        this.f1533b = -1;
        this.f1534c = view;
        this.f1535d = z.a();
    }

    public x(String str, String str2, String str3, List list) {
        this.f1532a = 2;
        str.getClass();
        this.f1534c = str;
        str2.getClass();
        this.f1535d = str2;
        this.f1536e = str3;
        list.getClass();
        this.f1537f = list;
        this.f1533b = 0;
        this.f1538g = str + "-" + str2 + "-" + str3;
    }

    public x(b0 b0Var) {
        this.f1532a = 1;
        this.f1533b = 0;
        this.f1534c = b0Var;
        this.f1536e = new HashMap();
        this.f1538g = new HashSet();
        this.f1535d = new ArrayList();
        this.f1537f = new ArrayList();
        try {
            this.f1538g = b0Var.f26887a.q();
        } catch (g unused) {
            t9.b("Camera2CameraCoordinator", "Failed to get concurrent camera ids");
        }
        for (Set arrayList : (Set) this.f1538g) {
            ArrayList arrayList2 = new ArrayList(arrayList);
            if (arrayList2.size() >= 2) {
                String str = (String) arrayList2.get(0);
                String str2 = (String) arrayList2.get(1);
                if (!((Map) this.f1536e).containsKey(str)) {
                    ((Map) this.f1536e).put(str, new ArrayList());
                }
                if (!((Map) this.f1536e).containsKey(str2)) {
                    ((Map) this.f1536e).put(str2, new ArrayList());
                }
                ((List) ((Map) this.f1536e).get(str)).add((String) arrayList2.get(1));
                ((List) ((Map) this.f1536e).get(str2)).add((String) arrayList2.get(0));
            }
        }
    }
}
