package androidx.appcompat.widget;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import m.e;

public final class m0 implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f1409a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ n0 f1410b;

    public m0(n0 n0Var, e eVar) {
        this.f1410b = n0Var;
        this.f1409a = eVar;
    }

    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.f1410b.H.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1409a);
        }
    }
}
