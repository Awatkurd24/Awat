package androidx.appcompat.widget;

import android.animation.ObjectAnimator;

public abstract class m3 {
    public static void a(ObjectAnimator objectAnimator, boolean z4) {
        objectAnimator.setAutoCancel(z4);
    }
}
