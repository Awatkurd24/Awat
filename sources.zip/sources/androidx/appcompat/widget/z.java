package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.Log;
import pa.b;

public final class z {

    /* renamed from: b  reason: collision with root package name */
    public static final PorterDuff.Mode f1585b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    public static z f1586c;

    /* renamed from: a  reason: collision with root package name */
    public p2 f1587a;

    public static synchronized z a() {
        z zVar;
        synchronized (z.class) {
            try {
                if (f1586c == null) {
                    d();
                }
                zVar = f1586c;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return zVar;
    }

    public static synchronized PorterDuffColorFilter c(int i10, PorterDuff.Mode mode) {
        PorterDuffColorFilter h10;
        synchronized (z.class) {
            h10 = p2.h(i10, mode);
        }
        return h10;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [androidx.appcompat.widget.z, java.lang.Object] */
    public static synchronized void d() {
        synchronized (z.class) {
            if (f1586c == null) {
                ? obj = new Object();
                f1586c = obj;
                obj.f1587a = p2.d();
                f1586c.f1587a.l(new b(1));
            }
        }
    }

    public static void e(Drawable drawable, q3 q3Var, int[] iArr) {
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        PorterDuff.Mode mode2 = p2.f1455h;
        int[] state = drawable.getState();
        int[] iArr2 = o1.f1445a;
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z4 = q3Var.f1477b;
            if (z4 || q3Var.f1476a) {
                PorterDuffColorFilter porterDuffColorFilter = null;
                if (z4) {
                    colorStateList = (ColorStateList) q3Var.f1478c;
                } else {
                    colorStateList = null;
                }
                if (q3Var.f1476a) {
                    mode = (PorterDuff.Mode) q3Var.f1479d;
                } else {
                    mode = p2.f1455h;
                }
                if (!(colorStateList == null || mode == null)) {
                    porterDuffColorFilter = p2.h(colorStateList.getColorForState(iArr, 0), mode);
                }
                drawable.setColorFilter(porterDuffColorFilter);
            } else {
                drawable.clearColorFilter();
            }
            if (Build.VERSION.SDK_INT <= 23) {
                drawable.invalidateSelf();
                return;
            }
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    public final synchronized Drawable b(Context context, int i10) {
        return this.f1587a.f(context, i10);
    }
}
