package androidx.appcompat.widget;

public interface d3 {
    boolean onQueryTextChange(String str);

    boolean onQueryTextSubmit(String str);
}
