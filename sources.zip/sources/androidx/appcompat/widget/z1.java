package androidx.appcompat.widget;

import java.util.WeakHashMap;
import r1.h1;
import r1.s0;

public final class z1 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1588a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ListPopupWindow f1589b;

    public /* synthetic */ z1(ListPopupWindow listPopupWindow, int i10) {
        this.f1588a = i10;
        this.f1589b = listPopupWindow;
    }

    public final void run() {
        int i10 = this.f1588a;
        ListPopupWindow listPopupWindow = this.f1589b;
        switch (i10) {
            case 1:
                u1 u1Var = listPopupWindow.f1167c;
                if (u1Var != null) {
                    u1Var.setListSelectionHidden(true);
                    u1Var.requestLayout();
                    return;
                }
                return;
            default:
                u1 u1Var2 = listPopupWindow.f1167c;
                if (u1Var2 != null) {
                    WeakHashMap weakHashMap = h1.f25195a;
                    if (s0.b(u1Var2) && listPopupWindow.f1167c.getCount() > listPopupWindow.f1167c.getChildCount() && listPopupWindow.f1167c.getChildCount() <= listPopupWindow.f1177m) {
                        listPopupWindow.f1190z.setInputMethodMode(2);
                        listPopupWindow.c();
                        return;
                    }
                    return;
                }
                return;
        }
    }
}
