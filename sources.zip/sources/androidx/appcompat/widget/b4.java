package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.TextView;
import co.vpn.plusvpn.R;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import r1.h1;
import r1.j1;
import r1.k1;
import r1.p0;
import r1.s0;

public final class b4 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: k  reason: collision with root package name */
    public static b4 f1294k;

    /* renamed from: l  reason: collision with root package name */
    public static b4 f1295l;

    /* renamed from: a  reason: collision with root package name */
    public final View f1296a;

    /* renamed from: b  reason: collision with root package name */
    public final CharSequence f1297b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1298c;

    /* renamed from: d  reason: collision with root package name */
    public final a4 f1299d = new a4(this, 0);

    /* renamed from: e  reason: collision with root package name */
    public final a4 f1300e = new a4(this, 1);

    /* renamed from: f  reason: collision with root package name */
    public int f1301f;

    /* renamed from: g  reason: collision with root package name */
    public int f1302g;

    /* renamed from: h  reason: collision with root package name */
    public c4 f1303h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1304i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1305j;

    public b4(View view, CharSequence charSequence) {
        int i10;
        this.f1296a = view;
        this.f1297b = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        Method method = k1.f25218a;
        if (Build.VERSION.SDK_INT >= 28) {
            i10 = j1.a(viewConfiguration);
        } else {
            i10 = viewConfiguration.getScaledTouchSlop() / 2;
        }
        this.f1298c = i10;
        this.f1305j = true;
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    public static void b(b4 b4Var) {
        b4 b4Var2 = f1294k;
        if (b4Var2 != null) {
            b4Var2.f1296a.removeCallbacks(b4Var2.f1299d);
        }
        f1294k = b4Var;
        if (b4Var != null) {
            b4Var.f1296a.postDelayed(b4Var.f1299d, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    public final void a() {
        b4 b4Var = f1295l;
        View view = this.f1296a;
        if (b4Var == this) {
            f1295l = null;
            c4 c4Var = this.f1303h;
            if (c4Var != null) {
                if (((View) c4Var.f1316b).getParent() != null) {
                    ((WindowManager) ((Context) c4Var.f1315a).getSystemService("window")).removeView((View) c4Var.f1316b);
                }
                this.f1303h = null;
                this.f1305j = true;
                view.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1294k == this) {
            b((b4) null);
        }
        view.removeCallbacks(this.f1300e);
    }

    public final void c(boolean z4) {
        int i10;
        int i11;
        int i12;
        long j3;
        long longPressTimeout;
        long j10;
        int i13;
        WeakHashMap weakHashMap = h1.f25195a;
        View view = this.f1296a;
        if (s0.b(view)) {
            b((b4) null);
            b4 b4Var = f1295l;
            if (b4Var != null) {
                b4Var.a();
            }
            f1295l = this;
            this.f1304i = z4;
            c4 c4Var = new c4(view.getContext(), 0);
            this.f1303h = c4Var;
            int i14 = this.f1301f;
            int i15 = this.f1302g;
            boolean z10 = this.f1304i;
            if (!(((View) c4Var.f1316b).getParent() == null || ((View) c4Var.f1316b).getParent() == null)) {
                ((WindowManager) ((Context) c4Var.f1315a).getSystemService("window")).removeView((View) c4Var.f1316b);
            }
            ((TextView) c4Var.f1317c).setText(this.f1297b);
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) c4Var.f1318d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = ((Context) c4Var.f1315a).getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                i14 = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = ((Context) c4Var.f1315a).getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
                i10 = i15 + dimensionPixelOffset2;
                i11 = i15 - dimensionPixelOffset2;
            } else {
                i10 = view.getHeight();
                i11 = 0;
            }
            layoutParams.gravity = 49;
            Resources resources = ((Context) c4Var.f1315a).getResources();
            if (z10) {
                i12 = R.dimen.tooltip_y_offset_touch;
            } else {
                i12 = R.dimen.tooltip_y_offset_non_touch;
            }
            int dimensionPixelOffset3 = resources.getDimensionPixelOffset(i12);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context = view.getContext();
                while (true) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else if (context instanceof Activity) {
                        rootView = ((Activity) context).getWindow().getDecorView();
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
            } else {
                rootView.getWindowVisibleDisplayFrame((Rect) c4Var.f1319e);
                Rect rect = (Rect) c4Var.f1319e;
                if (rect.left < 0 && rect.top < 0) {
                    Resources resources2 = ((Context) c4Var.f1315a).getResources();
                    int identifier = resources2.getIdentifier("status_bar_height", "dimen", "android");
                    if (identifier != 0) {
                        i13 = resources2.getDimensionPixelSize(identifier);
                    } else {
                        i13 = 0;
                    }
                    DisplayMetrics displayMetrics = resources2.getDisplayMetrics();
                    ((Rect) c4Var.f1319e).set(0, i13, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                rootView.getLocationOnScreen((int[]) c4Var.f1321g);
                view.getLocationOnScreen((int[]) c4Var.f1320f);
                int[] iArr = (int[]) c4Var.f1320f;
                int i16 = iArr[0];
                int[] iArr2 = (int[]) c4Var.f1321g;
                int i17 = i16 - iArr2[0];
                iArr[0] = i17;
                iArr[1] = iArr[1] - iArr2[1];
                layoutParams.x = (i17 + i14) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                ((View) c4Var.f1316b).measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = ((View) c4Var.f1316b).getMeasuredHeight();
                int i18 = ((int[]) c4Var.f1320f)[1];
                int i19 = ((i11 + i18) - dimensionPixelOffset3) - measuredHeight;
                int i20 = i18 + i10 + dimensionPixelOffset3;
                if (!z10 ? measuredHeight + i20 > ((Rect) c4Var.f1319e).height() : i19 >= 0) {
                    layoutParams.y = i19;
                } else {
                    layoutParams.y = i20;
                }
            }
            ((WindowManager) ((Context) c4Var.f1315a).getSystemService("window")).addView((View) c4Var.f1316b, (WindowManager.LayoutParams) c4Var.f1318d);
            view.addOnAttachStateChangeListener(this);
            if (this.f1304i) {
                j3 = 2500;
            } else {
                if ((p0.g(view) & 1) == 1) {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j10 = 3000;
                } else {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j10 = 15000;
                }
                j3 = j10 - longPressTimeout;
            }
            a4 a4Var = this.f1300e;
            view.removeCallbacks(a4Var);
            view.postDelayed(a4Var, j3);
        }
    }

    public final boolean onHover(View view, MotionEvent motionEvent) {
        int i10;
        if (this.f1303h != null && this.f1304i) {
            return false;
        }
        View view2 = this.f1296a;
        AccessibilityManager accessibilityManager = (AccessibilityManager) view2.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                this.f1305j = true;
                a();
            }
        } else if (view2.isEnabled() && this.f1303h == null) {
            int x4 = (int) motionEvent.getX();
            int y10 = (int) motionEvent.getY();
            if (this.f1305j || Math.abs(x4 - this.f1301f) > (i10 = this.f1298c) || Math.abs(y10 - this.f1302g) > i10) {
                this.f1301f = x4;
                this.f1302g = y10;
                this.f1305j = false;
                b(this);
            }
        }
        return false;
    }

    public final boolean onLongClick(View view) {
        this.f1301f = view.getWidth() / 2;
        this.f1302g = view.getHeight() / 2;
        c(true);
        return true;
    }

    public final void onViewAttachedToWindow(View view) {
    }

    public final void onViewDetachedFromWindow(View view) {
        a();
    }
}
