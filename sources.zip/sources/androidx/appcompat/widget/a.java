package androidx.appcompat.widget;

import android.view.View;
import r1.v1;

public final class a implements v1 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1280a = false;

    /* renamed from: b  reason: collision with root package name */
    public int f1281b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f1282c;

    public a(ActionBarContextView actionBarContextView) {
        this.f1282c = actionBarContextView;
    }

    public final void a() {
        if (!this.f1280a) {
            ActionBarContextView actionBarContextView = this.f1282c;
            actionBarContextView.f1015f = null;
            a.super.setVisibility(this.f1281b);
        }
    }

    public final void b(View view) {
        this.f1280a = true;
    }

    public final void c() {
        a.super.setVisibility(0);
        this.f1280a = false;
    }
}
