package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import co.vpn.plusvpn.R;
import h.y0;
import i.i;
import java.lang.reflect.InvocationTargetException;
import v1.g;

public class u1 extends ListView {

    /* renamed from: a  reason: collision with root package name */
    public final Rect f1507a = new Rect();

    /* renamed from: b  reason: collision with root package name */
    public int f1508b = 0;

    /* renamed from: c  reason: collision with root package name */
    public int f1509c = 0;

    /* renamed from: d  reason: collision with root package name */
    public int f1510d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1511e = 0;

    /* renamed from: f  reason: collision with root package name */
    public int f1512f;

    /* renamed from: g  reason: collision with root package name */
    public s1 f1513g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1514h;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f1515i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1516j;

    /* renamed from: k  reason: collision with root package name */
    public g f1517k;

    /* renamed from: l  reason: collision with root package name */
    public y0 f1518l;

    public u1(Context context, boolean z4) {
        super(context, (AttributeSet) null, R.attr.dropDownListViewStyle);
        this.f1515i = z4;
        setCacheColorHint(0);
    }

    public final int a(int i10, int i11) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        int i12 = listPaddingTop + listPaddingBottom;
        if (adapter == null) {
            return i12;
        }
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        View view = null;
        int i13 = 0;
        for (int i14 = 0; i14 < count; i14++) {
            int itemViewType = adapter.getItemViewType(i14);
            if (itemViewType != i13) {
                view = null;
                i13 = itemViewType;
            }
            view = adapter.getView(i14, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i15 = layoutParams.height;
            view.measure(i10, i15 > 0 ? View.MeasureSpec.makeMeasureSpec(i15, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i14 > 0) {
                i12 += dividerHeight;
            }
            i12 += view.getMeasuredHeight();
            if (i12 >= i11) {
                return i11;
            }
        }
        return i12;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x015f  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x0179  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(android.view.MotionEvent r17, int r18) {
        /*
            r16 = this;
            r1 = r16
            r2 = r17
            int r3 = r17.getActionMasked()
            r4 = 1
            r5 = 0
            if (r3 == r4) goto L_0x001a
            r0 = 2
            if (r3 == r0) goto L_0x0018
            r0 = 3
            if (r3 == r0) goto L_0x0015
            r0 = 1
            goto L_0x0145
        L_0x0015:
            r0 = 0
            goto L_0x0145
        L_0x0018:
            r0 = 1
            goto L_0x001b
        L_0x001a:
            r0 = 0
        L_0x001b:
            int r6 = r17.findPointerIndex(r18)
            if (r6 >= 0) goto L_0x0022
            goto L_0x0015
        L_0x0022:
            float r7 = r2.getX(r6)
            int r7 = (int) r7
            float r6 = r2.getY(r6)
            int r6 = (int) r6
            int r8 = r1.pointToPosition(r7, r6)
            r9 = -1
            if (r8 != r9) goto L_0x0036
            r5 = 1
            goto L_0x0145
        L_0x0036:
            int r0 = r16.getFirstVisiblePosition()
            int r0 = r8 - r0
            android.view.View r10 = r1.getChildAt(r0)
            float r7 = (float) r7
            float r6 = (float) r6
            r1.f1516j = r4
            androidx.appcompat.widget.p1.a(r1, r7, r6)
            boolean r0 = r16.isPressed()
            if (r0 != 0) goto L_0x0050
            r1.setPressed(r4)
        L_0x0050:
            r16.layoutChildren()
            int r0 = r1.f1512f
            if (r0 == r9) goto L_0x006d
            int r11 = r16.getFirstVisiblePosition()
            int r0 = r0 - r11
            android.view.View r0 = r1.getChildAt(r0)
            if (r0 == 0) goto L_0x006d
            if (r0 == r10) goto L_0x006d
            boolean r11 = r0.isPressed()
            if (r11 == 0) goto L_0x006d
            r0.setPressed(r5)
        L_0x006d:
            r1.f1512f = r8
            int r0 = r10.getLeft()
            float r0 = (float) r0
            float r0 = r7 - r0
            int r11 = r10.getTop()
            float r11 = (float) r11
            float r11 = r6 - r11
            androidx.appcompat.widget.p1.a(r10, r0, r11)
            boolean r0 = r10.isPressed()
            if (r0 != 0) goto L_0x0089
            r10.setPressed(r4)
        L_0x0089:
            android.graphics.drawable.Drawable r11 = r16.getSelector()
            if (r11 == 0) goto L_0x0093
            if (r8 == r9) goto L_0x0093
            r12 = 1
            goto L_0x0094
        L_0x0093:
            r12 = 0
        L_0x0094:
            if (r12 == 0) goto L_0x0099
            r11.setVisible(r5, r5)
        L_0x0099:
            int r0 = r10.getLeft()
            int r13 = r10.getTop()
            int r14 = r10.getRight()
            int r15 = r10.getBottom()
            android.graphics.Rect r5 = r1.f1507a
            r5.set(r0, r13, r14, r15)
            int r0 = r5.left
            int r13 = r1.f1508b
            int r0 = r0 - r13
            r5.left = r0
            int r0 = r5.top
            int r13 = r1.f1509c
            int r0 = r0 - r13
            r5.top = r0
            int r0 = r5.right
            int r13 = r1.f1510d
            int r0 = r0 + r13
            r5.right = r0
            int r0 = r5.bottom
            int r13 = r1.f1511e
            int r0 = r0 + r13
            r5.bottom = r0
            boolean r0 = n1.b.a()
            if (r0 == 0) goto L_0x00d5
            boolean r0 = androidx.appcompat.widget.r1.a(r16)
            goto L_0x00e4
        L_0x00d5:
            java.lang.reflect.Field r0 = androidx.appcompat.widget.t1.f1502a
            if (r0 == 0) goto L_0x00e3
            boolean r0 = r0.getBoolean(r1)     // Catch:{ IllegalAccessException -> 0x00de }
            goto L_0x00e4
        L_0x00de:
            r0 = move-exception
            r13 = r0
            r13.printStackTrace()
        L_0x00e3:
            r0 = 0
        L_0x00e4:
            boolean r13 = r10.isEnabled()
            if (r13 == r0) goto L_0x010a
            r0 = r0 ^ r4
            boolean r13 = n1.b.a()
            if (r13 == 0) goto L_0x00f5
            androidx.appcompat.widget.r1.b(r1, r0)
            goto L_0x0105
        L_0x00f5:
            java.lang.reflect.Field r13 = androidx.appcompat.widget.t1.f1502a
            if (r13 == 0) goto L_0x0105
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ IllegalAccessException -> 0x0101 }
            r13.set(r1, r0)     // Catch:{ IllegalAccessException -> 0x0101 }
            goto L_0x0105
        L_0x0101:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0105:
            if (r8 == r9) goto L_0x010a
            r16.refreshDrawableState()
        L_0x010a:
            if (r12 == 0) goto L_0x0125
            float r0 = r5.exactCenterX()
            float r5 = r5.exactCenterY()
            int r12 = r16.getVisibility()
            if (r12 != 0) goto L_0x011d
            r12 = 1
        L_0x011b:
            r13 = 0
            goto L_0x011f
        L_0x011d:
            r12 = 0
            goto L_0x011b
        L_0x011f:
            r11.setVisible(r12, r13)
            k1.b.e(r11, r0, r5)
        L_0x0125:
            android.graphics.drawable.Drawable r0 = r16.getSelector()
            if (r0 == 0) goto L_0x0130
            if (r8 == r9) goto L_0x0130
            k1.b.e(r0, r7, r6)
        L_0x0130:
            androidx.appcompat.widget.s1 r0 = r1.f1513g
            if (r0 == 0) goto L_0x0137
            r5 = 0
            r0.f1497b = r5
        L_0x0137:
            r16.refreshDrawableState()
            if (r3 != r4) goto L_0x0143
            long r5 = r1.getItemIdAtPosition(r8)
            r1.performItemClick(r10, r8, r5)
        L_0x0143:
            r0 = 1
            r5 = 0
        L_0x0145:
            if (r0 == 0) goto L_0x0149
            if (r5 == 0) goto L_0x0162
        L_0x0149:
            r3 = 0
            r1.f1516j = r3
            r1.setPressed(r3)
            r16.drawableStateChanged()
            int r5 = r1.f1512f
            int r6 = r16.getFirstVisiblePosition()
            int r5 = r5 - r6
            android.view.View r5 = r1.getChildAt(r5)
            if (r5 == 0) goto L_0x0162
            r5.setPressed(r3)
        L_0x0162:
            if (r0 == 0) goto L_0x0179
            v1.g r3 = r1.f1517k
            if (r3 != 0) goto L_0x016f
            v1.g r3 = new v1.g
            r3.<init>(r1)
            r1.f1517k = r3
        L_0x016f:
            v1.g r3 = r1.f1517k
            boolean r5 = r3.f27580p
            r3.f27580p = r4
            r3.d(r1, r2)
            goto L_0x0187
        L_0x0179:
            v1.g r2 = r1.f1517k
            if (r2 == 0) goto L_0x0187
            boolean r3 = r2.f27580p
            if (r3 == 0) goto L_0x0184
            r2.i()
        L_0x0184:
            r3 = 0
            r2.f27580p = r3
        L_0x0187:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.u1.b(android.view.MotionEvent, int):boolean");
    }

    public final void dispatchDraw(Canvas canvas) {
        Drawable selector;
        Rect rect = this.f1507a;
        if (!rect.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(rect);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    public final void drawableStateChanged() {
        if (this.f1518l == null) {
            super.drawableStateChanged();
            s1 s1Var = this.f1513g;
            if (s1Var != null) {
                s1Var.f1497b = true;
            }
            Drawable selector = getSelector();
            if (selector != null && this.f1516j && isPressed()) {
                selector.setState(getDrawableState());
            }
        }
    }

    public final boolean hasFocus() {
        return this.f1515i || super.hasFocus();
    }

    public final boolean hasWindowFocus() {
        return this.f1515i || super.hasWindowFocus();
    }

    public final boolean isFocused() {
        return this.f1515i || super.isFocused();
    }

    public final boolean isInTouchMode() {
        return (this.f1515i && this.f1514h) || super.isInTouchMode();
    }

    public final void onDetachedFromWindow() {
        this.f1518l = null;
        super.onDetachedFromWindow();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f1518l == null) {
            y0 y0Var = new y0(2, this);
            this.f1518l = y0Var;
            post(y0Var);
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    requestFocus();
                    if (i10 < 30 || !q1.f1475d) {
                        setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                    } else {
                        try {
                            q1.f1472a.invoke(this, new Object[]{Integer.valueOf(pointToPosition), childAt, Boolean.FALSE, -1, -1});
                            q1.f1473b.invoke(this, new Object[]{Integer.valueOf(pointToPosition)});
                            q1.f1474c.invoke(this, new Object[]{Integer.valueOf(pointToPosition)});
                        } catch (IllegalAccessException | InvocationTargetException e10) {
                            e10.printStackTrace();
                        }
                    }
                }
                Drawable selector = getSelector();
                if (selector != null && this.f1516j && isPressed()) {
                    selector.setState(getDrawableState());
                }
            }
        } else {
            setSelection(-1);
        }
        return onHoverEvent;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f1512f = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        y0 y0Var = this.f1518l;
        if (y0Var != null) {
            u1 u1Var = (u1) y0Var.f19483b;
            u1Var.f1518l = null;
            u1Var.removeCallbacks(y0Var);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setListSelectionHidden(boolean z4) {
        this.f1514h = z4;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [i.i, androidx.appcompat.widget.s1] */
    public void setSelector(Drawable drawable) {
        s1 s1Var;
        if (drawable != null) {
            ? iVar = new i(drawable);
            iVar.f1497b = true;
            s1Var = iVar;
        } else {
            s1Var = null;
        }
        this.f1513g = s1Var;
        super.setSelector(s1Var);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f1508b = rect.left;
        this.f1509c = rect.top;
        this.f1510d = rect.right;
        this.f1511e = rect.bottom;
    }
}
