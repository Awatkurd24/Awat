package androidx.appcompat.widget;

public final class e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1327a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ActionBarOverlayLayout f1328b;

    public /* synthetic */ e(ActionBarOverlayLayout actionBarOverlayLayout, int i10) {
        this.f1327a = i10;
        this.f1328b = actionBarOverlayLayout;
    }

    public final void run() {
        int i10 = this.f1327a;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f1328b;
        switch (i10) {
            case 0:
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f1052w = actionBarOverlayLayout.f1033d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f1053x);
                return;
            default:
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f1052w = actionBarOverlayLayout.f1033d.animate().translationY((float) (-actionBarOverlayLayout.f1033d.getHeight())).setListener(actionBarOverlayLayout.f1053x);
                return;
        }
    }
}
