package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

public final class i1 {

    /* renamed from: l  reason: collision with root package name */
    public static final RectF f1350l = new RectF();

    /* renamed from: m  reason: collision with root package name */
    public static final ConcurrentHashMap f1351m = new ConcurrentHashMap();

    /* renamed from: a  reason: collision with root package name */
    public int f1352a = 0;

    /* renamed from: b  reason: collision with root package name */
    public boolean f1353b = false;

    /* renamed from: c  reason: collision with root package name */
    public float f1354c = -1.0f;

    /* renamed from: d  reason: collision with root package name */
    public float f1355d = -1.0f;

    /* renamed from: e  reason: collision with root package name */
    public float f1356e = -1.0f;

    /* renamed from: f  reason: collision with root package name */
    public int[] f1357f = new int[0];

    /* renamed from: g  reason: collision with root package name */
    public boolean f1358g = false;

    /* renamed from: h  reason: collision with root package name */
    public TextPaint f1359h;

    /* renamed from: i  reason: collision with root package name */
    public final TextView f1360i;

    /* renamed from: j  reason: collision with root package name */
    public final Context f1361j;

    /* renamed from: k  reason: collision with root package name */
    public final h1 f1362k;

    static {
        new ConcurrentHashMap();
    }

    public i1(TextView textView) {
        this.f1360i = textView;
        this.f1361j = textView.getContext();
        int i10 = Build.VERSION.SDK_INT;
        this.f1362k = i10 >= 29 ? new g1() : i10 >= 23 ? new e1() : new h1();
    }

    public static int[] b(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i10 : iArr) {
            if (i10 > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i10)) < 0) {
                arrayList.add(Integer.valueOf(i10));
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i11 = 0; i11 < size; i11++) {
            iArr2[i11] = ((Integer) arrayList.get(i11)).intValue();
        }
        return iArr2;
    }

    public static Method d(String str) {
        try {
            ConcurrentHashMap concurrentHashMap = f1351m;
            Method method = (Method) concurrentHashMap.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                concurrentHashMap.put(str, method);
            }
            return method;
        } catch (Exception e10) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e10);
            return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x000e, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0011, code lost:
        android.util.Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + r4 + "() method", r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:?, code lost:
        return r3;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object e(java.lang.Object r2, java.lang.Object r3, java.lang.String r4) {
        /*
            java.lang.reflect.Method r0 = d(r4)     // Catch:{ Exception -> 0x000e, all -> 0x000c }
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x000e, all -> 0x000c }
            java.lang.Object r3 = r0.invoke(r2, r1)     // Catch:{ Exception -> 0x000e, all -> 0x000c }
            goto L_0x0029
        L_0x000c:
            r2 = move-exception
            goto L_0x0010
        L_0x000e:
            r2 = move-exception
            goto L_0x0011
        L_0x0010:
            throw r2
        L_0x0011:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Failed to invoke TextView#"
            r0.<init>(r1)
            r0.append(r4)
            java.lang.String r4 = "() method"
            r0.append(r4)
            java.lang.String r4 = r0.toString()
            java.lang.String r0 = "ACTVAutoSizeHelper"
            android.util.Log.w(r0, r4, r2)
        L_0x0029:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.i1.e(java.lang.Object, java.lang.Object, java.lang.String):java.lang.Object");
    }

    public final void a() {
        if (f()) {
            if (this.f1353b) {
                if (this.f1360i.getMeasuredHeight() > 0 && this.f1360i.getMeasuredWidth() > 0) {
                    int measuredWidth = this.f1362k.b(this.f1360i) ? 1048576 : (this.f1360i.getMeasuredWidth() - this.f1360i.getTotalPaddingLeft()) - this.f1360i.getTotalPaddingRight();
                    int height = (this.f1360i.getHeight() - this.f1360i.getCompoundPaddingBottom()) - this.f1360i.getCompoundPaddingTop();
                    if (measuredWidth > 0 && height > 0) {
                        RectF rectF = f1350l;
                        synchronized (rectF) {
                            try {
                                rectF.setEmpty();
                                rectF.right = (float) measuredWidth;
                                rectF.bottom = (float) height;
                                float c10 = (float) c(rectF);
                                if (c10 != this.f1360i.getTextSize()) {
                                    g(0, c10);
                                }
                            } catch (Throwable th2) {
                                throw th2;
                            }
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f1353b = true;
        }
    }

    public final int c(RectF rectF) {
        int i10;
        StaticLayout staticLayout;
        CharSequence transformation;
        RectF rectF2 = rectF;
        int length = this.f1357f.length;
        if (length != 0) {
            int i11 = length - 1;
            int i12 = 1;
            int i13 = 0;
            while (i12 <= i11) {
                int i14 = (i12 + i11) / 2;
                int i15 = this.f1357f[i14];
                TextView textView = this.f1360i;
                CharSequence text = textView.getText();
                TransformationMethod transformationMethod = textView.getTransformationMethod();
                if (!(transformationMethod == null || (transformation = transformationMethod.getTransformation(text, textView)) == null)) {
                    text = transformation;
                }
                int i16 = Build.VERSION.SDK_INT;
                int b5 = b1.b(textView);
                TextPaint textPaint = this.f1359h;
                if (textPaint == null) {
                    this.f1359h = new TextPaint();
                } else {
                    textPaint.reset();
                }
                this.f1359h.set(textView.getPaint());
                this.f1359h.setTextSize((float) i15);
                Layout.Alignment alignment = (Layout.Alignment) e(textView, Layout.Alignment.ALIGN_NORMAL, "getLayoutAlignment");
                int round = Math.round(rectF2.right);
                if (i16 >= 23) {
                    i10 = b5;
                    staticLayout = d1.a(text, alignment, round, b5, this.f1360i, this.f1359h, this.f1362k);
                } else {
                    i10 = b5;
                    staticLayout = b1.a(text, alignment, round, textView, this.f1359h);
                }
                if ((i10 == -1 || (staticLayout.getLineCount() <= i10 && staticLayout.getLineEnd(staticLayout.getLineCount() - 1) == text.length())) && ((float) staticLayout.getHeight()) <= rectF2.bottom) {
                    int i17 = i14 + 1;
                    i13 = i12;
                    i12 = i17;
                } else {
                    i13 = i14 - 1;
                    i11 = i13;
                }
            }
            return this.f1357f[i13];
        }
        throw new IllegalStateException("No available text sizes to choose from.");
    }

    public final boolean f() {
        return j() && this.f1352a != 0;
    }

    public final void g(int i10, float f10) {
        Resources resources;
        Context context = this.f1361j;
        if (context == null) {
            resources = Resources.getSystem();
        } else {
            resources = context.getResources();
        }
        float applyDimension = TypedValue.applyDimension(i10, f10, resources.getDisplayMetrics());
        TextView textView = this.f1360i;
        if (applyDimension != textView.getPaint().getTextSize()) {
            textView.getPaint().setTextSize(applyDimension);
            boolean a10 = c1.a(textView);
            if (textView.getLayout() != null) {
                this.f1353b = false;
                try {
                    Method d10 = d("nullLayouts");
                    if (d10 != null) {
                        d10.invoke(textView, new Object[0]);
                    }
                } catch (Exception e10) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e10);
                }
                if (!a10) {
                    textView.requestLayout();
                } else {
                    textView.forceLayout();
                }
                textView.invalidate();
            }
        }
    }

    public final boolean h() {
        if (!j() || this.f1352a != 1) {
            this.f1353b = false;
        } else {
            if (!this.f1358g || this.f1357f.length == 0) {
                int floor = ((int) Math.floor((double) ((this.f1356e - this.f1355d) / this.f1354c))) + 1;
                int[] iArr = new int[floor];
                for (int i10 = 0; i10 < floor; i10++) {
                    iArr[i10] = Math.round((((float) i10) * this.f1354c) + this.f1355d);
                }
                this.f1357f = b(iArr);
            }
            this.f1353b = true;
        }
        return this.f1353b;
    }

    public final boolean i() {
        int[] iArr = this.f1357f;
        int length = iArr.length;
        boolean z4 = length > 0;
        this.f1358g = z4;
        if (z4) {
            this.f1352a = 1;
            this.f1355d = (float) iArr[0];
            this.f1356e = (float) iArr[length - 1];
            this.f1354c = -1.0f;
        }
        return z4;
    }

    public final boolean j() {
        return !(this.f1360i instanceof AppCompatEditText);
    }

    public final void k(float f10, float f11, float f12) {
        if (f10 <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f10 + "px) is less or equal to (0px)");
        } else if (f11 <= f10) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f11 + "px) is less or equal to minimum auto-size text size (" + f10 + "px)");
        } else if (f12 > 0.0f) {
            this.f1352a = 1;
            this.f1355d = f10;
            this.f1356e = f11;
            this.f1354c = f12;
            this.f1358g = false;
        } else {
            throw new IllegalArgumentException("The auto-size step granularity (" + f12 + "px) is less or equal to (0px)");
        }
    }
}
