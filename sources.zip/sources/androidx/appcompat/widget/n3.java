package androidx.appcompat.widget;

import android.widget.EditText;
import h2.j;
import java.lang.ref.WeakReference;

public final class n3 extends j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1443a = 1;

    /* renamed from: b  reason: collision with root package name */
    public final WeakReference f1444b;

    public n3(EditText editText) {
        this.f1444b = new WeakReference(editText);
    }

    public final void a() {
        switch (this.f1443a) {
            case 0:
                SwitchCompat switchCompat = (SwitchCompat) this.f1444b.get();
                if (switchCompat != null) {
                    switchCompat.c();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public final void b() {
        WeakReference weakReference = this.f1444b;
        switch (this.f1443a) {
            case 0:
                SwitchCompat switchCompat = (SwitchCompat) weakReference.get();
                if (switchCompat != null) {
                    switchCompat.c();
                    return;
                }
                return;
            default:
                j2.j.a((EditText) weakReference.get(), 1);
                return;
        }
    }

    public n3(SwitchCompat switchCompat) {
        this.f1444b = new WeakReference(switchCompat);
    }
}
