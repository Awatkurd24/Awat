package androidx.appcompat.widget;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

public abstract class s2 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
