package androidx.appcompat.widget;

public final class a0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AppCompatEditText f1283a;

    public a0(AppCompatEditText appCompatEditText) {
        this.f1283a = appCompatEditText;
    }
}
