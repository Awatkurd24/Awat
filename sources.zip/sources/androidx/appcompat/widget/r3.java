package androidx.appcompat.widget;

public abstract class r3 extends q2 {
}
