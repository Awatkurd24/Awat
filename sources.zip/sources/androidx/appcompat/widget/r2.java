package androidx.appcompat.widget;

public final class r2 {

    /* renamed from: a  reason: collision with root package name */
    public int f1484a;

    /* renamed from: b  reason: collision with root package name */
    public int f1485b;

    /* renamed from: c  reason: collision with root package name */
    public int f1486c;

    /* renamed from: d  reason: collision with root package name */
    public int f1487d;

    /* renamed from: e  reason: collision with root package name */
    public int f1488e;

    /* renamed from: f  reason: collision with root package name */
    public int f1489f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1490g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1491h;

    public final void a(int i10, int i11) {
        this.f1486c = i10;
        this.f1487d = i11;
        this.f1491h = true;
        if (this.f1490g) {
            if (i11 != Integer.MIN_VALUE) {
                this.f1484a = i11;
            }
            if (i10 != Integer.MIN_VALUE) {
                this.f1485b = i10;
                return;
            }
            return;
        }
        if (i10 != Integer.MIN_VALUE) {
            this.f1484a = i10;
        }
        if (i11 != Integer.MIN_VALUE) {
            this.f1485b = i11;
        }
    }
}
