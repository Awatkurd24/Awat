package androidx.appcompat.widget;

import android.graphics.Rect;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.appcompat.widget.SearchView;

public final class i3 extends TouchDelegate {

    /* renamed from: a  reason: collision with root package name */
    public final View f1363a;

    /* renamed from: b  reason: collision with root package name */
    public final Rect f1364b;

    /* renamed from: c  reason: collision with root package name */
    public final Rect f1365c;

    /* renamed from: d  reason: collision with root package name */
    public final Rect f1366d;

    /* renamed from: e  reason: collision with root package name */
    public final int f1367e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1368f;

    public i3(Rect rect, Rect rect2, SearchView.SearchAutoComplete searchAutoComplete) {
        super(rect, searchAutoComplete);
        int scaledTouchSlop = ViewConfiguration.get(searchAutoComplete.getContext()).getScaledTouchSlop();
        this.f1367e = scaledTouchSlop;
        Rect rect3 = new Rect();
        this.f1364b = rect3;
        Rect rect4 = new Rect();
        this.f1366d = rect4;
        Rect rect5 = new Rect();
        this.f1365c = rect5;
        rect3.set(rect);
        rect4.set(rect);
        int i10 = -scaledTouchSlop;
        rect4.inset(i10, i10);
        rect5.set(rect2);
        this.f1363a = searchAutoComplete;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r8) {
        /*
            r7 = this;
            float r0 = r8.getX()
            int r0 = (int) r0
            float r1 = r8.getY()
            int r1 = (int) r1
            int r2 = r8.getAction()
            r3 = 2
            r4 = 0
            r5 = 1
            if (r2 == 0) goto L_0x0031
            if (r2 == r5) goto L_0x0022
            if (r2 == r3) goto L_0x0022
            r6 = 3
            if (r2 == r6) goto L_0x001b
            goto L_0x003c
        L_0x001b:
            boolean r2 = r7.f1368f
            r7.f1368f = r4
        L_0x001f:
            r5 = r2
        L_0x0020:
            r2 = 1
            goto L_0x003e
        L_0x0022:
            boolean r2 = r7.f1368f
            if (r2 == 0) goto L_0x001f
            android.graphics.Rect r6 = r7.f1366d
            boolean r6 = r6.contains(r0, r1)
            if (r6 != 0) goto L_0x001f
            r5 = r2
            r2 = 0
            goto L_0x003e
        L_0x0031:
            android.graphics.Rect r2 = r7.f1364b
            boolean r2 = r2.contains(r0, r1)
            if (r2 == 0) goto L_0x003c
            r7.f1368f = r5
            goto L_0x0020
        L_0x003c:
            r2 = 1
            r5 = 0
        L_0x003e:
            if (r5 == 0) goto L_0x0068
            android.graphics.Rect r4 = r7.f1365c
            android.view.View r5 = r7.f1363a
            if (r2 == 0) goto L_0x005c
            boolean r2 = r4.contains(r0, r1)
            if (r2 != 0) goto L_0x005c
            int r0 = r5.getWidth()
            int r0 = r0 / r3
            float r0 = (float) r0
            int r1 = r5.getHeight()
            int r1 = r1 / r3
        L_0x0057:
            float r1 = (float) r1
            r8.setLocation(r0, r1)
            goto L_0x0064
        L_0x005c:
            int r2 = r4.left
            int r0 = r0 - r2
            float r0 = (float) r0
            int r2 = r4.top
            int r1 = r1 - r2
            goto L_0x0057
        L_0x0064:
            boolean r4 = r5.dispatchTouchEvent(r8)
        L_0x0068:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.i3.onTouchEvent(android.view.MotionEvent):boolean");
    }
}
