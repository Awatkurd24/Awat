package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.VelocityTracker;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import co.vpn.plusvpn.R;
import h2.l;
import java.util.WeakHashMap;
import k.a;
import k1.b;
import r1.h1;
import r1.l0;
import r1.s0;
import t7.w;
import u7.a0;
import u7.y;
import v7.je;

public class SwitchCompat extends CompoundButton {
    public static final l3 X0 = new l3(0, Float.class, "thumbPos");
    public static final int[] Y0 = {16842912};
    public int A;
    public int B;
    public int C;
    public int D;
    public int E;
    public int F;
    public int G;
    public boolean H;
    public final TextPaint I;
    public final ColorStateList J;
    public StaticLayout K;
    public StaticLayout L;
    public final a M;
    public ObjectAnimator N;
    public b0 O;
    public final Rect W0;

    /* renamed from: a  reason: collision with root package name */
    public Drawable f1220a;

    /* renamed from: b  reason: collision with root package name */
    public ColorStateList f1221b;

    /* renamed from: c  reason: collision with root package name */
    public PorterDuff.Mode f1222c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1223d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1224e;

    /* renamed from: f  reason: collision with root package name */
    public Drawable f1225f;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f1226g;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f1227h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1228i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1229j;

    /* renamed from: k  reason: collision with root package name */
    public int f1230k;

    /* renamed from: l  reason: collision with root package name */
    public int f1231l;

    /* renamed from: m  reason: collision with root package name */
    public int f1232m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f1233n;

    /* renamed from: o  reason: collision with root package name */
    public CharSequence f1234o;

    /* renamed from: p  reason: collision with root package name */
    public CharSequence f1235p;

    /* renamed from: p0  reason: collision with root package name */
    public n3 f1236p0;

    /* renamed from: q  reason: collision with root package name */
    public CharSequence f1237q;

    /* renamed from: r  reason: collision with root package name */
    public CharSequence f1238r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f1239s;

    /* renamed from: t  reason: collision with root package name */
    public int f1240t;

    /* renamed from: u  reason: collision with root package name */
    public final int f1241u;

    /* renamed from: v  reason: collision with root package name */
    public float f1242v;

    /* renamed from: w  reason: collision with root package name */
    public float f1243w;

    /* renamed from: x  reason: collision with root package name */
    public final VelocityTracker f1244x;

    /* renamed from: y  reason: collision with root package name */
    public final int f1245y;

    /* renamed from: z  reason: collision with root package name */
    public float f1246z;

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.switchStyle);
    }

    private b0 getEmojiTextViewHelper() {
        if (this.O == null) {
            this.O = new b0(this);
        }
        return this.O;
    }

    private boolean getTargetCheckedState() {
        return this.f1246z > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((f4.a(this) ? 1.0f - this.f1246z : this.f1246z) * ((float) getThumbScrollRange())) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f1225f;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.W0;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f1220a;
        Rect b5 = drawable2 != null ? o1.b(drawable2) : o1.f1447c;
        return ((((this.A - this.C) - rect.left) - rect.right) - b5.left) - b5.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f1237q = charSequence;
        b0 emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod v10 = ((a0) emojiTextViewHelper.f1293b.f19652b).v(this.M);
        if (v10 != null) {
            charSequence = v10.getTransformation(charSequence, this);
        }
        this.f1238r = charSequence;
        this.L = null;
        if (this.f1239s) {
            d();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f1234o = charSequence;
        b0 emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod v10 = ((a0) emojiTextViewHelper.f1293b.f19652b).v(this.M);
        if (v10 != null) {
            charSequence = v10.getTransformation(charSequence, this);
        }
        this.f1235p = charSequence;
        this.K = null;
        if (this.f1239s) {
            d();
        }
    }

    public final void a() {
        Drawable drawable = this.f1220a;
        if (drawable == null) {
            return;
        }
        if (this.f1223d || this.f1224e) {
            Drawable mutate = w.m(drawable).mutate();
            this.f1220a = mutate;
            if (this.f1223d) {
                b.h(mutate, this.f1221b);
            }
            if (this.f1224e) {
                b.i(this.f1220a, this.f1222c);
            }
            if (this.f1220a.isStateful()) {
                this.f1220a.setState(getDrawableState());
            }
        }
    }

    public final void b() {
        Drawable drawable = this.f1225f;
        if (drawable == null) {
            return;
        }
        if (this.f1228i || this.f1229j) {
            Drawable mutate = w.m(drawable).mutate();
            this.f1225f = mutate;
            if (this.f1228i) {
                b.h(mutate, this.f1226g);
            }
            if (this.f1229j) {
                b.i(this.f1225f, this.f1227h);
            }
            if (this.f1225f.isStateful()) {
                this.f1225f.setState(getDrawableState());
            }
        }
    }

    public final void c() {
        setTextOnInternal(this.f1234o);
        setTextOffInternal(this.f1237q);
        requestLayout();
    }

    public final void d() {
        if (this.f1236p0 == null && ((a0) this.O.f1293b.f19652b).p() && l.f19504j != null) {
            l a10 = l.a();
            int b5 = a10.b();
            if (b5 == 3 || b5 == 0) {
                n3 n3Var = new n3(this);
                this.f1236p0 = n3Var;
                a10.g(n3Var);
            }
        }
    }

    public final void draw(Canvas canvas) {
        Rect rect;
        int i10;
        int i11;
        int i12 = this.D;
        int i13 = this.E;
        int i14 = this.F;
        int i15 = this.G;
        int thumbOffset = getThumbOffset() + i12;
        Drawable drawable = this.f1220a;
        if (drawable != null) {
            rect = o1.b(drawable);
        } else {
            rect = o1.f1447c;
        }
        Drawable drawable2 = this.f1225f;
        Rect rect2 = this.W0;
        if (drawable2 != null) {
            drawable2.getPadding(rect2);
            int i16 = rect2.left;
            thumbOffset += i16;
            if (rect != null) {
                int i17 = rect.left;
                if (i17 > i16) {
                    i12 += i17 - i16;
                }
                int i18 = rect.top;
                int i19 = rect2.top;
                if (i18 > i19) {
                    i10 = (i18 - i19) + i13;
                } else {
                    i10 = i13;
                }
                int i20 = rect.right;
                int i21 = rect2.right;
                if (i20 > i21) {
                    i14 -= i20 - i21;
                }
                int i22 = rect.bottom;
                int i23 = rect2.bottom;
                if (i22 > i23) {
                    i11 = i15 - (i22 - i23);
                    this.f1225f.setBounds(i12, i10, i14, i11);
                }
            } else {
                i10 = i13;
            }
            i11 = i15;
            this.f1225f.setBounds(i12, i10, i14, i11);
        }
        Drawable drawable3 = this.f1220a;
        if (drawable3 != null) {
            drawable3.getPadding(rect2);
            int i24 = thumbOffset - rect2.left;
            int i25 = thumbOffset + this.C + rect2.right;
            this.f1220a.setBounds(i24, i13, i25, i15);
            Drawable background = getBackground();
            if (background != null) {
                b.f(background, i24, i13, i25, i15);
            }
        }
        super.draw(canvas);
    }

    public final void drawableHotspotChanged(float f10, float f11) {
        super.drawableHotspotChanged(f10, f11);
        Drawable drawable = this.f1220a;
        if (drawable != null) {
            b.e(drawable, f10, f11);
        }
        Drawable drawable2 = this.f1225f;
        if (drawable2 != null) {
            b.e(drawable2, f10, f11);
        }
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1220a;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f1225f;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    public int getCompoundPaddingLeft() {
        if (!f4.a(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f1232m : compoundPaddingLeft;
    }

    public int getCompoundPaddingRight() {
        if (f4.a(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f1232m : compoundPaddingRight;
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return je.r(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f1239s;
    }

    public boolean getSplitTrack() {
        return this.f1233n;
    }

    public int getSwitchMinWidth() {
        return this.f1231l;
    }

    public int getSwitchPadding() {
        return this.f1232m;
    }

    public CharSequence getTextOff() {
        return this.f1237q;
    }

    public CharSequence getTextOn() {
        return this.f1234o;
    }

    public Drawable getThumbDrawable() {
        return this.f1220a;
    }

    public final float getThumbPosition() {
        return this.f1246z;
    }

    public int getThumbTextPadding() {
        return this.f1230k;
    }

    public ColorStateList getThumbTintList() {
        return this.f1221b;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f1222c;
    }

    public Drawable getTrackDrawable() {
        return this.f1225f;
    }

    public ColorStateList getTrackTintList() {
        return this.f1226g;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.f1227h;
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1220a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f1225f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.N;
        if (objectAnimator != null && objectAnimator.isStarted()) {
            this.N.end();
            this.N = null;
        }
    }

    public int[] onCreateDrawableState(int i10) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i10 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, Y0);
        }
        return onCreateDrawableState;
    }

    public final void onDraw(Canvas canvas) {
        int i10;
        super.onDraw(canvas);
        Drawable drawable = this.f1225f;
        Rect rect = this.W0;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i11 = this.E;
        int i12 = this.G;
        int i13 = i11 + rect.top;
        int i14 = i12 - rect.bottom;
        Drawable drawable2 = this.f1220a;
        if (drawable != null) {
            if (!this.f1233n || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect b5 = o1.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += b5.left;
                rect.right -= b5.right;
                int save = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        StaticLayout staticLayout = getTargetCheckedState() ? this.K : this.L;
        if (staticLayout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.J;
            TextPaint textPaint = this.I;
            if (colorStateList != null) {
                textPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            textPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                i10 = bounds.left + bounds.right;
            } else {
                i10 = getWidth();
            }
            canvas.translate((float) ((i10 / 2) - (staticLayout.getWidth() / 2)), (float) (((i13 + i14) / 2) - (staticLayout.getHeight() / 2)));
            staticLayout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f1234o : this.f1237q;
            if (!TextUtils.isEmpty(charSequence)) {
                CharSequence text = accessibilityNodeInfo.getText();
                if (TextUtils.isEmpty(text)) {
                    accessibilityNodeInfo.setText(charSequence);
                    return;
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append(text);
                sb2.append(' ');
                sb2.append(charSequence);
                accessibilityNodeInfo.setText(sb2);
            }
        }
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        super.onLayout(z4, i10, i11, i12, i13);
        int i19 = 0;
        if (this.f1220a != null) {
            Drawable drawable = this.f1225f;
            Rect rect = this.W0;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect b5 = o1.b(this.f1220a);
            i14 = Math.max(0, b5.left - rect.left);
            i19 = Math.max(0, b5.right - rect.right);
        } else {
            i14 = 0;
        }
        if (f4.a(this)) {
            i16 = getPaddingLeft() + i14;
            i15 = ((this.A + i16) - i14) - i19;
        } else {
            i15 = (getWidth() - getPaddingRight()) - i19;
            i16 = (i15 - this.A) + i14 + i19;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int paddingTop = getPaddingTop();
            int i20 = this.B;
            int height = (((getHeight() + paddingTop) - getPaddingBottom()) / 2) - (i20 / 2);
            int i21 = height;
            i17 = i20 + height;
            i18 = i21;
        } else if (gravity != 80) {
            i18 = getPaddingTop();
            i17 = this.B + i18;
        } else {
            i17 = getHeight() - getPaddingBottom();
            i18 = i17 - this.B;
        }
        this.D = i16;
        this.E = i18;
        this.G = i17;
        this.F = i15;
    }

    public final void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18 = 0;
        if (this.f1239s) {
            StaticLayout staticLayout = this.K;
            TextPaint textPaint = this.I;
            if (staticLayout == null) {
                CharSequence charSequence = this.f1235p;
                if (charSequence != null) {
                    i17 = (int) Math.ceil((double) Layout.getDesiredWidth(charSequence, textPaint));
                } else {
                    i17 = 0;
                }
                this.K = new StaticLayout(charSequence, textPaint, i17, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
            if (this.L == null) {
                CharSequence charSequence2 = this.f1238r;
                if (charSequence2 != null) {
                    i16 = (int) Math.ceil((double) Layout.getDesiredWidth(charSequence2, textPaint));
                } else {
                    i16 = 0;
                }
                this.L = new StaticLayout(charSequence2, textPaint, i16, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
        }
        Drawable drawable = this.f1220a;
        Rect rect = this.W0;
        if (drawable != null) {
            drawable.getPadding(rect);
            i13 = (this.f1220a.getIntrinsicWidth() - rect.left) - rect.right;
            i12 = this.f1220a.getIntrinsicHeight();
        } else {
            i13 = 0;
            i12 = 0;
        }
        if (this.f1239s) {
            i14 = (this.f1230k * 2) + Math.max(this.K.getWidth(), this.L.getWidth());
        } else {
            i14 = 0;
        }
        this.C = Math.max(i14, i13);
        Drawable drawable2 = this.f1225f;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            i18 = this.f1225f.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int i19 = rect.left;
        int i20 = rect.right;
        Drawable drawable3 = this.f1220a;
        if (drawable3 != null) {
            Rect b5 = o1.b(drawable3);
            i19 = Math.max(i19, b5.left);
            i20 = Math.max(i20, b5.right);
        }
        if (this.H) {
            i15 = Math.max(this.f1231l, (this.C * 2) + i19 + i20);
        } else {
            i15 = this.f1231l;
        }
        int max = Math.max(i18, i12);
        this.A = i15;
        this.B = max;
        super.onMeasure(i10, i11);
        if (getMeasuredHeight() < max) {
            setMeasuredDimension(getMeasuredWidthAndState(), max);
        }
    }

    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f1234o : this.f1237q;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0015, code lost:
        if (r1 != 3) goto L_0x0144;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
            r9 = this;
            android.view.VelocityTracker r0 = r9.f1244x
            r0.addMovement(r10)
            int r1 = r10.getActionMasked()
            int r2 = r9.f1241u
            r3 = 1
            if (r1 == 0) goto L_0x00f8
            r4 = 3
            r5 = 0
            r6 = 2
            if (r1 == r3) goto L_0x0090
            if (r1 == r6) goto L_0x0019
            if (r1 == r4) goto L_0x0090
            goto L_0x0144
        L_0x0019:
            int r0 = r9.f1240t
            if (r0 == r3) goto L_0x0060
            if (r0 == r6) goto L_0x0021
            goto L_0x0144
        L_0x0021:
            float r10 = r10.getX()
            int r0 = r9.getThumbScrollRange()
            float r1 = r9.f1242v
            float r1 = r10 - r1
            r2 = 1065353216(0x3f800000, float:1.0)
            if (r0 == 0) goto L_0x0034
            float r0 = (float) r0
            float r1 = r1 / r0
            goto L_0x003f
        L_0x0034:
            int r0 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r0 <= 0) goto L_0x003b
            r1 = 1065353216(0x3f800000, float:1.0)
            goto L_0x003f
        L_0x003b:
            r0 = -1082130432(0xffffffffbf800000, float:-1.0)
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x003f:
            boolean r0 = androidx.appcompat.widget.f4.a(r9)
            if (r0 == 0) goto L_0x0046
            float r1 = -r1
        L_0x0046:
            float r0 = r9.f1246z
            float r1 = r1 + r0
            int r4 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r4 >= 0) goto L_0x004e
            goto L_0x0056
        L_0x004e:
            int r4 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r4 <= 0) goto L_0x0055
            r5 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0056
        L_0x0055:
            r5 = r1
        L_0x0056:
            int r0 = (r5 > r0 ? 1 : (r5 == r0 ? 0 : -1))
            if (r0 == 0) goto L_0x005f
            r9.f1242v = r10
            r9.setThumbPosition(r5)
        L_0x005f:
            return r3
        L_0x0060:
            float r0 = r10.getX()
            float r1 = r10.getY()
            float r4 = r9.f1242v
            float r4 = r0 - r4
            float r4 = java.lang.Math.abs(r4)
            float r5 = (float) r2
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 > 0) goto L_0x0082
            float r4 = r9.f1243w
            float r4 = r1 - r4
            float r4 = java.lang.Math.abs(r4)
            float r2 = (float) r2
            int r2 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r2 <= 0) goto L_0x0144
        L_0x0082:
            r9.f1240t = r6
            android.view.ViewParent r10 = r9.getParent()
            r10.requestDisallowInterceptTouchEvent(r3)
            r9.f1242v = r0
            r9.f1243w = r1
            return r3
        L_0x0090:
            int r1 = r9.f1240t
            r2 = 0
            if (r1 != r6) goto L_0x00f2
            r9.f1240t = r2
            int r1 = r10.getAction()
            if (r1 != r3) goto L_0x00a5
            boolean r1 = r9.isEnabled()
            if (r1 == 0) goto L_0x00a5
            r1 = 1
            goto L_0x00a6
        L_0x00a5:
            r1 = 0
        L_0x00a6:
            boolean r6 = r9.isChecked()
            if (r1 == 0) goto L_0x00d8
            r1 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r1)
            float r0 = r0.getXVelocity()
            float r1 = java.lang.Math.abs(r0)
            int r7 = r9.f1245y
            float r7 = (float) r7
            int r1 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r1 <= 0) goto L_0x00d3
            boolean r1 = androidx.appcompat.widget.f4.a(r9)
            if (r1 == 0) goto L_0x00ce
            int r0 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r0 >= 0) goto L_0x00cc
        L_0x00ca:
            r0 = 1
            goto L_0x00d9
        L_0x00cc:
            r0 = 0
            goto L_0x00d9
        L_0x00ce:
            int r0 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r0 <= 0) goto L_0x00cc
            goto L_0x00ca
        L_0x00d3:
            boolean r0 = r9.getTargetCheckedState()
            goto L_0x00d9
        L_0x00d8:
            r0 = r6
        L_0x00d9:
            if (r0 == r6) goto L_0x00de
            r9.playSoundEffect(r2)
        L_0x00de:
            r9.setChecked(r0)
            android.view.MotionEvent r0 = android.view.MotionEvent.obtain(r10)
            r0.setAction(r4)
            super.onTouchEvent(r0)
            r0.recycle()
            super.onTouchEvent(r10)
            return r3
        L_0x00f2:
            r9.f1240t = r2
            r0.clear()
            goto L_0x0144
        L_0x00f8:
            float r0 = r10.getX()
            float r1 = r10.getY()
            boolean r4 = r9.isEnabled()
            if (r4 == 0) goto L_0x0144
            android.graphics.drawable.Drawable r4 = r9.f1220a
            if (r4 != 0) goto L_0x010b
            goto L_0x0144
        L_0x010b:
            int r4 = r9.getThumbOffset()
            android.graphics.drawable.Drawable r5 = r9.f1220a
            android.graphics.Rect r6 = r9.W0
            r5.getPadding(r6)
            int r5 = r9.E
            int r5 = r5 - r2
            int r7 = r9.D
            int r7 = r7 + r4
            int r7 = r7 - r2
            int r4 = r9.C
            int r4 = r4 + r7
            int r8 = r6.left
            int r4 = r4 + r8
            int r6 = r6.right
            int r4 = r4 + r6
            int r4 = r4 + r2
            int r6 = r9.G
            int r6 = r6 + r2
            float r2 = (float) r7
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 <= 0) goto L_0x0144
            float r2 = (float) r4
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x0144
            float r2 = (float) r5
            int r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r2 <= 0) goto L_0x0144
            float r2 = (float) r6
            int r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x0144
            r9.f1240t = r3
            r9.f1242v = r0
            r9.f1243w = r1
        L_0x0144:
            boolean r10 = super.onTouchEvent(r10)
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SwitchCompat.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    public void setChecked(boolean z4) {
        super.setChecked(z4);
        boolean isChecked = isChecked();
        if (isChecked) {
            if (Build.VERSION.SDK_INT >= 30) {
                Object obj = this.f1234o;
                if (obj == null) {
                    obj = getResources().getString(R.string.abc_capital_on);
                }
                WeakHashMap weakHashMap = h1.f25195a;
                new l0(R.id.tag_state_description, 64, 30, 2).g(this, obj);
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            Object obj2 = this.f1237q;
            if (obj2 == null) {
                obj2 = getResources().getString(R.string.abc_capital_off);
            }
            WeakHashMap weakHashMap2 = h1.f25195a;
            new l0(R.id.tag_state_description, 64, 30, 2).g(this, obj2);
        }
        float f10 = 0.0f;
        if (getWindowToken() != null) {
            WeakHashMap weakHashMap3 = h1.f25195a;
            if (s0.c(this)) {
                if (isChecked) {
                    f10 = 1.0f;
                }
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, X0, new float[]{f10});
                this.N = ofFloat;
                ofFloat.setDuration(250);
                m3.a(this.N, true);
                this.N.start();
                return;
            }
        }
        ObjectAnimator objectAnimator = this.N;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        if (isChecked) {
            f10 = 1.0f;
        }
        setThumbPosition(f10);
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(je.s(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
        setTextOnInternal(this.f1234o);
        setTextOffInternal(this.f1237q);
        requestLayout();
    }

    public final void setEnforceSwitchWidth(boolean z4) {
        this.H = z4;
        invalidate();
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z4) {
        if (this.f1239s != z4) {
            this.f1239s = z4;
            requestLayout();
            if (z4) {
                d();
            }
        }
    }

    public void setSplitTrack(boolean z4) {
        this.f1233n = z4;
        invalidate();
    }

    public void setSwitchMinWidth(int i10) {
        this.f1231l = i10;
        requestLayout();
    }

    public void setSwitchPadding(int i10) {
        this.f1232m = i10;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        TextPaint textPaint = this.I;
        if ((textPaint.getTypeface() != null && !textPaint.getTypeface().equals(typeface)) || (textPaint.getTypeface() == null && typeface != null)) {
            textPaint.setTypeface(typeface);
            requestLayout();
            invalidate();
        }
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (!isChecked() && Build.VERSION.SDK_INT >= 30) {
            Object obj = this.f1237q;
            if (obj == null) {
                obj = getResources().getString(R.string.abc_capital_off);
            }
            WeakHashMap weakHashMap = h1.f25195a;
            new l0(R.id.tag_state_description, 64, 30, 2).g(this, obj);
        }
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked() && Build.VERSION.SDK_INT >= 30) {
            Object obj = this.f1234o;
            if (obj == null) {
                obj = getResources().getString(R.string.abc_capital_on);
            }
            WeakHashMap weakHashMap = h1.f25195a;
            new l0(R.id.tag_state_description, 64, 30, 2).g(this, obj);
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1220a;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f1220a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f10) {
        this.f1246z = f10;
        invalidate();
    }

    public void setThumbResource(int i10) {
        setThumbDrawable(y.e(getContext(), i10));
    }

    public void setThumbTextPadding(int i10) {
        this.f1230k = i10;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f1221b = colorStateList;
        this.f1223d = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f1222c = mode;
        this.f1224e = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1225f;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f1225f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i10) {
        setTrackDrawable(y.e(getContext(), i10));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f1226g = colorStateList;
        this.f1228i = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.f1227h = mode;
        this.f1229j = true;
        b();
    }

    public final void toggle() {
        setChecked(!isChecked());
    }

    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1220a || drawable == this.f1225f;
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [java.lang.Object, k.a] */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x010d, code lost:
        r9 = h1.i.c(r12, (r9 = r7.getResourceId(3, 0)));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SwitchCompat(android.content.Context r12, android.util.AttributeSet r13, int r14) {
        /*
            r11 = this;
            r11.<init>(r12, r13, r14)
            r0 = 0
            r11.f1221b = r0
            r11.f1222c = r0
            r1 = 0
            r11.f1223d = r1
            r11.f1224e = r1
            r11.f1226g = r0
            r11.f1227h = r0
            r11.f1228i = r1
            r11.f1229j = r1
            android.view.VelocityTracker r2 = android.view.VelocityTracker.obtain()
            r11.f1244x = r2
            r2 = 1
            r11.H = r2
            android.graphics.Rect r3 = new android.graphics.Rect
            r3.<init>()
            r11.W0 = r3
            android.content.Context r3 = r11.getContext()
            androidx.appcompat.widget.o3.a(r3, r11)
            android.text.TextPaint r3 = new android.text.TextPaint
            r3.<init>(r2)
            r11.I = r3
            android.content.res.Resources r4 = r11.getResources()
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()
            float r4 = r4.density
            r3.density = r4
            int[] r7 = g.a.f18943y
            a4.w r4 = new a4.w
            android.content.res.TypedArray r5 = r12.obtainStyledAttributes(r13, r7, r14, r1)
            r4.<init>((android.content.Context) r12, (android.content.res.TypedArray) r5)
            java.lang.Object r5 = r4.f619c
            r9 = r5
            android.content.res.TypedArray r9 = (android.content.res.TypedArray) r9
            r5 = r11
            r6 = r12
            r8 = r13
            r10 = r14
            r1.h1.q(r5, r6, r7, r8, r9, r10)
            r5 = 2
            android.graphics.drawable.Drawable r6 = r4.w(r5)
            r11.f1220a = r6
            if (r6 == 0) goto L_0x0062
            r6.setCallback(r11)
        L_0x0062:
            r6 = 11
            android.graphics.drawable.Drawable r6 = r4.w(r6)
            r11.f1225f = r6
            if (r6 == 0) goto L_0x006f
            r6.setCallback(r11)
        L_0x006f:
            java.lang.CharSequence r6 = r4.F(r1)
            r11.setTextOnInternal(r6)
            java.lang.CharSequence r6 = r4.F(r2)
            r11.setTextOffInternal(r6)
            r6 = 3
            boolean r7 = r4.r(r6, r2)
            r11.f1239s = r7
            r7 = 8
            int r7 = r4.v(r7, r1)
            r11.f1230k = r7
            r7 = 5
            int r7 = r4.v(r7, r1)
            r11.f1231l = r7
            r7 = 6
            int r7 = r4.v(r7, r1)
            r11.f1232m = r7
            r7 = 4
            boolean r7 = r4.r(r7, r1)
            r11.f1233n = r7
            r7 = 9
            android.content.res.ColorStateList r7 = r4.t(r7)
            if (r7 == 0) goto L_0x00ad
            r11.f1221b = r7
            r11.f1223d = r2
        L_0x00ad:
            r7 = 10
            r8 = -1
            int r7 = r4.z(r7, r8)
            android.graphics.PorterDuff$Mode r7 = androidx.appcompat.widget.o1.c(r7, r0)
            android.graphics.PorterDuff$Mode r9 = r11.f1222c
            if (r9 == r7) goto L_0x00c0
            r11.f1222c = r7
            r11.f1224e = r2
        L_0x00c0:
            boolean r7 = r11.f1223d
            if (r7 != 0) goto L_0x00c8
            boolean r7 = r11.f1224e
            if (r7 == 0) goto L_0x00cb
        L_0x00c8:
            r11.a()
        L_0x00cb:
            r7 = 12
            android.content.res.ColorStateList r7 = r4.t(r7)
            if (r7 == 0) goto L_0x00d7
            r11.f1226g = r7
            r11.f1228i = r2
        L_0x00d7:
            r7 = 13
            int r7 = r4.z(r7, r8)
            android.graphics.PorterDuff$Mode r7 = androidx.appcompat.widget.o1.c(r7, r0)
            android.graphics.PorterDuff$Mode r9 = r11.f1227h
            if (r9 == r7) goto L_0x00e9
            r11.f1227h = r7
            r11.f1229j = r2
        L_0x00e9:
            boolean r7 = r11.f1228i
            if (r7 != 0) goto L_0x00f1
            boolean r7 = r11.f1229j
            if (r7 == 0) goto L_0x00f4
        L_0x00f1:
            r11.b()
        L_0x00f4:
            r7 = 7
            int r7 = r4.B(r7, r1)
            if (r7 == 0) goto L_0x01b2
            int[] r9 = g.a.f18944z
            android.content.res.TypedArray r7 = r12.obtainStyledAttributes(r7, r9)
            boolean r9 = r7.hasValue(r6)
            if (r9 == 0) goto L_0x0114
            int r9 = r7.getResourceId(r6, r1)
            if (r9 == 0) goto L_0x0114
            android.content.res.ColorStateList r9 = h1.i.c(r12, r9)
            if (r9 == 0) goto L_0x0114
            goto L_0x0118
        L_0x0114:
            android.content.res.ColorStateList r9 = r7.getColorStateList(r6)
        L_0x0118:
            if (r9 == 0) goto L_0x011d
        L_0x011a:
            r11.J = r9
            goto L_0x0122
        L_0x011d:
            android.content.res.ColorStateList r9 = r11.getTextColors()
            goto L_0x011a
        L_0x0122:
            int r9 = r7.getDimensionPixelSize(r1, r1)
            if (r9 == 0) goto L_0x0137
            float r9 = (float) r9
            float r10 = r3.getTextSize()
            int r10 = (r9 > r10 ? 1 : (r9 == r10 ? 0 : -1))
            if (r10 == 0) goto L_0x0137
            r3.setTextSize(r9)
            r11.requestLayout()
        L_0x0137:
            int r9 = r7.getInt(r2, r8)
            int r8 = r7.getInt(r5, r8)
            if (r9 == r2) goto L_0x014d
            if (r9 == r5) goto L_0x014a
            if (r9 == r6) goto L_0x0147
            r6 = r0
            goto L_0x014f
        L_0x0147:
            android.graphics.Typeface r6 = android.graphics.Typeface.MONOSPACE
            goto L_0x014f
        L_0x014a:
            android.graphics.Typeface r6 = android.graphics.Typeface.SERIF
            goto L_0x014f
        L_0x014d:
            android.graphics.Typeface r6 = android.graphics.Typeface.SANS_SERIF
        L_0x014f:
            r9 = 0
            if (r8 <= 0) goto L_0x017d
            if (r6 != 0) goto L_0x0159
            android.graphics.Typeface r6 = android.graphics.Typeface.defaultFromStyle(r8)
            goto L_0x015d
        L_0x0159:
            android.graphics.Typeface r6 = android.graphics.Typeface.create(r6, r8)
        L_0x015d:
            r11.setSwitchTypeface(r6)
            if (r6 == 0) goto L_0x0167
            int r6 = r6.getStyle()
            goto L_0x0168
        L_0x0167:
            r6 = 0
        L_0x0168:
            int r6 = ~r6
            r6 = r6 & r8
            r8 = r6 & 1
            if (r8 == 0) goto L_0x016f
            goto L_0x0170
        L_0x016f:
            r2 = 0
        L_0x0170:
            r3.setFakeBoldText(r2)
            r2 = r6 & 2
            if (r2 == 0) goto L_0x0179
            r9 = -1098907648(0xffffffffbe800000, float:-0.25)
        L_0x0179:
            r3.setTextSkewX(r9)
            goto L_0x0186
        L_0x017d:
            r3.setFakeBoldText(r1)
            r3.setTextSkewX(r9)
            r11.setSwitchTypeface(r6)
        L_0x0186:
            r2 = 14
            boolean r1 = r7.getBoolean(r2, r1)
            if (r1 == 0) goto L_0x01a3
            k.a r0 = new k.a
            android.content.Context r1 = r11.getContext()
            r0.<init>()
            android.content.res.Resources r1 = r1.getResources()
            android.content.res.Configuration r1 = r1.getConfiguration()
            java.util.Locale r1 = r1.locale
            r0.f21230a = r1
        L_0x01a3:
            r11.M = r0
            java.lang.CharSequence r0 = r11.f1234o
            r11.setTextOnInternal(r0)
            java.lang.CharSequence r0 = r11.f1237q
            r11.setTextOffInternal(r0)
            r7.recycle()
        L_0x01b2:
            androidx.appcompat.widget.y0 r0 = new androidx.appcompat.widget.y0
            r0.<init>(r11)
            r0.f(r13, r14)
            r4.N()
            android.view.ViewConfiguration r12 = android.view.ViewConfiguration.get(r12)
            int r0 = r12.getScaledTouchSlop()
            r11.f1241u = r0
            int r12 = r12.getScaledMinimumFlingVelocity()
            r11.f1245y = r12
            androidx.appcompat.widget.b0 r12 = r11.getEmojiTextViewHelper()
            r12.b(r13, r14)
            r11.refreshDrawableState()
            boolean r12 = r11.isChecked()
            r11.setChecked(r12)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SwitchCompat.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }
}
