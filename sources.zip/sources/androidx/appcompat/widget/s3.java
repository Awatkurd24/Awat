package androidx.appcompat.widget;

import m.q;

public final /* synthetic */ class s3 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1498a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1499b;

    public /* synthetic */ s3(Toolbar toolbar, int i10) {
        this.f1498a = i10;
        this.f1499b = toolbar;
    }

    public final void run() {
        q qVar;
        int i10 = this.f1498a;
        Toolbar toolbar = this.f1499b;
        switch (i10) {
            case 0:
                toolbar.o();
                return;
            default:
                u3 u3Var = toolbar.M;
                if (u3Var == null) {
                    qVar = null;
                } else {
                    qVar = u3Var.f1522b;
                }
                if (qVar != null) {
                    qVar.collapseActionView();
                    return;
                }
                return;
        }
    }
}
