package androidx.appcompat.widget;

import android.view.View;

public abstract class c1 {
    public static boolean a(View view) {
        return view.isInLayout();
    }
}
