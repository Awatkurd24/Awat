package androidx.appcompat.widget;

import a4.m;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import h.a0;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p1.g;
import p1.h;
import u7.y;
import v1.o;
import v1.p;
import v1.v;
import v7.je;
import w7.ua;
import xb.c;
import yg.b0;

public class AppCompatTextView extends TextView implements v {

    /* renamed from: a  reason: collision with root package name */
    public final x f1127a;

    /* renamed from: b  reason: collision with root package name */
    public final y0 f1128b;

    /* renamed from: c  reason: collision with root package name */
    public final m f1129c;

    /* renamed from: d  reason: collision with root package name */
    public b0 f1130d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1131e;

    /* renamed from: f  reason: collision with root package name */
    public a0 f1132f;

    /* renamed from: g  reason: collision with root package name */
    public Future f1133g;

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    private b0 getEmojiTextViewHelper() {
        if (this.f1130d == null) {
            this.f1130d = new b0(this);
        }
        return this.f1130d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        x xVar = this.f1127a;
        if (xVar != null) {
            xVar.a();
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (f4.f1339b) {
            return super.getAutoSizeMaxTextSize();
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1356e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (f4.f1339b) {
            return super.getAutoSizeMinTextSize();
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1355d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (f4.f1339b) {
            return super.getAutoSizeStepGranularity();
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            return Math.round(y0Var.f1564i.f1354c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (f4.f1339b) {
            return super.getAutoSizeTextAvailableSizes();
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            return y0Var.f1564i.f1357f;
        }
        return new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (!f4.f1339b) {
            y0 y0Var = this.f1128b;
            if (y0Var != null) {
                return y0Var.f1564i.f1352a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return je.r(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public z0 getSuperCaller() {
        a0 a0Var;
        if (this.f1132f == null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 28) {
                a0Var = new a1(this);
            } else if (i10 >= 26) {
                a0Var = new a0((Object) this);
            }
            this.f1132f = a0Var;
        }
        return this.f1132f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1127a;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1127a;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1128b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1128b.e();
    }

    public CharSequence getText() {
        v();
        return super.getText();
    }

    public TextClassifier getTextClassifier() {
        m mVar;
        if (Build.VERSION.SDK_INT >= 28 || (mVar = this.f1129c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) mVar.f559c;
        if (textClassifier == null) {
            return q0.a((TextView) mVar.f558b);
        }
        return textClassifier;
    }

    public g getTextMetricsParamsCompat() {
        return je.g(this);
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f1128b.getClass();
        y0.h(this, onCreateInputConnection, editorInfo);
        b0.x(this, editorInfo, onCreateInputConnection);
        return onCreateInputConnection;
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        super.onLayout(z4, i10, i11, i12, i13);
        y0 y0Var = this.f1128b;
        if (y0Var != null && !f4.f1339b) {
            y0Var.f1564i.a();
        }
    }

    public void onMeasure(int i10, int i11) {
        v();
        super.onMeasure(i10, i11);
    }

    public final void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        super.onTextChanged(charSequence, i10, i11, i12);
        y0 y0Var = this.f1128b;
        if (y0Var != null && !f4.f1339b) {
            i1 i1Var = y0Var.f1564i;
            if (i1Var.f()) {
                i1Var.a();
            }
        }
    }

    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i10, int i11, int i12, int i13) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i10, i11, i12, i13);
            return;
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.i(i10, i11, i12, i13);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i10) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i10);
            return;
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.j(iArr, i10);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i10) {
        if (f4.f1339b) {
            super.setAutoSizeTextTypeWithDefaults(i10);
            return;
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.k(i10);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1127a;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1127a;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i10, int i11, int i12, int i13) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable e10 = i10 != 0 ? y.e(context, i10) : null;
        Drawable e11 = i11 != 0 ? y.e(context, i11) : null;
        Drawable e12 = i12 != 0 ? y.e(context, i12) : null;
        if (i13 != 0) {
            drawable = y.e(context, i13);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(e10, e11, e12, drawable);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(int i10, int i11, int i12, int i13) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable e10 = i10 != 0 ? y.e(context, i10) : null;
        Drawable e11 = i11 != 0 ? y.e(context, i11) : null;
        Drawable e12 = i12 != 0 ? y.e(context, i12) : null;
        if (i13 != 0) {
            drawable = y.e(context, i13);
        }
        setCompoundDrawablesWithIntrinsicBounds(e10, e11, e12, drawable);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(je.s(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setFirstBaselineToTopHeight(int i10) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().f(i10);
        } else {
            je.n(this, i10);
        }
    }

    public void setLastBaselineToBottomHeight(int i10) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().c(i10);
        } else {
            je.o(this, i10);
        }
    }

    public void setLineHeight(int i10) {
        ua.e(i10);
        int fontMetricsInt = getPaint().getFontMetricsInt((Paint.FontMetricsInt) null);
        if (i10 != fontMetricsInt) {
            setLineSpacing((float) (i10 - fontMetricsInt), 1.0f);
        }
    }

    public void setPrecomputedText(h hVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        je.g(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1127a;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1127a;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        y0 y0Var = this.f1128b;
        y0Var.l(colorStateList);
        y0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        y0 y0Var = this.f1128b;
        y0Var.m(mode);
        y0Var.b();
    }

    public void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.g(context, i10);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        m mVar;
        if (Build.VERSION.SDK_INT >= 28 || (mVar = this.f1129c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            mVar.f559c = textClassifier;
        }
    }

    public void setTextFuture(Future<h> future) {
        this.f1133g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(g gVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        int i10 = Build.VERSION.SDK_INT;
        TextDirectionHeuristic textDirectionHeuristic2 = gVar.f23873b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i11 = 1;
        if (!(textDirectionHeuristic2 == textDirectionHeuristic3 || textDirectionHeuristic2 == (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR))) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i11 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i11 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i11 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i11 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i11 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i11 = 7;
            }
        }
        o.h(this, i11);
        TextPaint textPaint = gVar.f23872a;
        if (i10 < 23) {
            float textScaleX = textPaint.getTextScaleX();
            getPaint().set(textPaint);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
            return;
        }
        getPaint().set(textPaint);
        p.e(this, gVar.f23874c);
        p.h(this, gVar.f23875d);
    }

    public final void setTextSize(int i10, float f10) {
        boolean z4 = f4.f1339b;
        if (z4) {
            super.setTextSize(i10, f10);
            return;
        }
        y0 y0Var = this.f1128b;
        if (y0Var != null && !z4) {
            i1 i1Var = y0Var.f1564i;
            if (!i1Var.f()) {
                i1Var.g(i10, f10);
            }
        }
    }

    public final void setTypeface(Typeface typeface, int i10) {
        Typeface typeface2;
        if (!this.f1131e) {
            if (typeface == null || i10 <= 0) {
                typeface2 = null;
            } else {
                Context context = getContext();
                c cVar = j1.h.f20570a;
                if (context != null) {
                    typeface2 = Typeface.create(typeface, i10);
                } else {
                    throw new IllegalArgumentException("Context cannot be null");
                }
            }
            this.f1131e = true;
            if (typeface2 != null) {
                typeface = typeface2;
            }
            try {
                super.setTypeface(typeface, i10);
            } finally {
                this.f1131e = false;
            }
        }
    }

    public final void v() {
        Future future = this.f1133g;
        if (future != null) {
            try {
                this.f1133g = null;
                f.c.w(future.get());
                if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                }
                je.g(this);
                throw null;
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        this.f1131e = false;
        this.f1132f = null;
        o3.a(getContext(), this);
        x xVar = new x((View) this);
        this.f1127a = xVar;
        xVar.f(attributeSet, i10);
        y0 y0Var = new y0(this);
        this.f1128b = y0Var;
        y0Var.f(attributeSet, i10);
        y0Var.b();
        this.f1129c = new m((TextView) this);
        getEmojiTextViewHelper().b(attributeSet, i10);
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1128b;
        if (y0Var != null) {
            y0Var.b();
        }
    }
}
