package androidx.appcompat.widget;

import android.graphics.Insets;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import io.tooldroid.dialog.ToolDroidDialog;
import java.lang.reflect.InvocationTargetException;
import t7.w;

public abstract class o1 {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1445a = {16842912};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f1446b = new int[0];

    /* renamed from: c  reason: collision with root package name */
    public static final Rect f1447c = new Rect();

    public static void a(Drawable drawable) {
        String name = drawable.getClass().getName();
        int i10 = Build.VERSION.SDK_INT;
        int[] iArr = f1445a;
        int[] iArr2 = f1446b;
        if (i10 == 21 && "android.graphics.drawable.VectorDrawable".equals(name)) {
            int[] state = drawable.getState();
            if (state == null || state.length == 0) {
                drawable.setState(iArr);
            } else {
                drawable.setState(iArr2);
            }
            drawable.setState(state);
        } else if (i10 >= 29 && i10 < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(name)) {
            int[] state2 = drawable.getState();
            if (state2 == null || state2.length == 0) {
                drawable.setState(iArr);
            } else {
                drawable.setState(iArr2);
            }
            drawable.setState(state2);
        }
    }

    public static Rect b(Drawable drawable) {
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 29) {
            Insets a10 = n1.a(drawable);
            return new Rect(a10.left, a10.top, a10.right, a10.bottom);
        }
        Drawable l10 = w.l(drawable);
        if (i10 >= 29) {
            boolean z4 = m1.f1411a;
        } else if (m1.f1411a) {
            try {
                Object invoke = m1.f1412b.invoke(l10, new Object[0]);
                if (invoke != null) {
                    return new Rect(m1.f1413c.getInt(invoke), m1.f1414d.getInt(invoke), m1.f1415e.getInt(invoke), m1.f1416f.getInt(invoke));
                }
            } catch (IllegalAccessException | InvocationTargetException unused) {
            }
        }
        return f1447c;
    }

    public static PorterDuff.Mode c(int i10, PorterDuff.Mode mode) {
        if (i10 == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i10 == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i10 == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        switch (i10) {
            case 14:
                return PorterDuff.Mode.MULTIPLY;
            case 15:
                return PorterDuff.Mode.SCREEN;
            case ToolDroidDialog.CENTER_VERTICAL /*16*/:
                return PorterDuff.Mode.ADD;
            default:
                return mode;
        }
    }
}
