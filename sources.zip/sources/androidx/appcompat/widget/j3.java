package androidx.appcompat.widget;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import co.vpn.plusvpn.R;

public final class j3 {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1372a;

    /* renamed from: b  reason: collision with root package name */
    public final TextView f1373b;

    /* renamed from: c  reason: collision with root package name */
    public final ImageView f1374c;

    /* renamed from: d  reason: collision with root package name */
    public final ImageView f1375d;

    /* renamed from: e  reason: collision with root package name */
    public final ImageView f1376e;

    public j3(View view) {
        this.f1372a = (TextView) view.findViewById(16908308);
        this.f1373b = (TextView) view.findViewById(16908309);
        this.f1374c = (ImageView) view.findViewById(16908295);
        this.f1375d = (ImageView) view.findViewById(16908296);
        this.f1376e = (ImageView) view.findViewById(R.id.edit_query);
    }
}
