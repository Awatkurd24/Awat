package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.TypedValue;
import co.vpn.plusvpn.R;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import pa.b;
import s0.e;
import s0.f;
import s0.k;
import s0.l;

public final class p2 {

    /* renamed from: h  reason: collision with root package name */
    public static final PorterDuff.Mode f1455h = PorterDuff.Mode.SRC_IN;

    /* renamed from: i  reason: collision with root package name */
    public static p2 f1456i;

    /* renamed from: j  reason: collision with root package name */
    public static final n2 f1457j = new f(6);

    /* renamed from: a  reason: collision with root package name */
    public WeakHashMap f1458a;

    /* renamed from: b  reason: collision with root package name */
    public k f1459b;

    /* renamed from: c  reason: collision with root package name */
    public l f1460c;

    /* renamed from: d  reason: collision with root package name */
    public final WeakHashMap f1461d = new WeakHashMap(0);

    /* renamed from: e  reason: collision with root package name */
    public TypedValue f1462e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1463f;

    /* renamed from: g  reason: collision with root package name */
    public b f1464g;

    public static synchronized p2 d() {
        p2 p2Var;
        synchronized (p2.class) {
            try {
                if (f1456i == null) {
                    p2 p2Var2 = new p2();
                    f1456i = p2Var2;
                    j(p2Var2);
                }
                p2Var = f1456i;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return p2Var;
    }

    public static synchronized PorterDuffColorFilter h(int i10, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        synchronized (p2.class) {
            n2 n2Var = f1457j;
            n2Var.getClass();
            int i11 = (31 + i10) * 31;
            porterDuffColorFilter = (PorterDuffColorFilter) n2Var.c(Integer.valueOf(mode.hashCode() + i11));
            if (porterDuffColorFilter == null) {
                porterDuffColorFilter = new PorterDuffColorFilter(i10, mode);
                PorterDuffColorFilter porterDuffColorFilter2 = (PorterDuffColorFilter) n2Var.d(Integer.valueOf(mode.hashCode() + i11), porterDuffColorFilter);
            }
        }
        return porterDuffColorFilter;
    }

    public static void j(p2 p2Var) {
        if (Build.VERSION.SDK_INT < 24) {
            p2Var.a("vector", new m2(3));
            p2Var.a("animated-vector", new m2(1));
            p2Var.a("animated-selector", new m2(0));
            p2Var.a("drawable", new m2(2));
        }
    }

    public final void a(String str, m2 m2Var) {
        if (this.f1459b == null) {
            this.f1459b = new k();
        }
        this.f1459b.put(str, m2Var);
    }

    public final synchronized void b(Context context, long j3, Drawable drawable) {
        try {
            Drawable.ConstantState constantState = drawable.getConstantState();
            if (constantState != null) {
                e eVar = (e) this.f1461d.get(context);
                if (eVar == null) {
                    eVar = new e();
                    this.f1461d.put(context, eVar);
                }
                eVar.g(j3, new WeakReference(constantState));
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final Drawable c(Context context, int i10) {
        int i11;
        if (this.f1462e == null) {
            this.f1462e = new TypedValue();
        }
        TypedValue typedValue = this.f1462e;
        context.getResources().getValue(i10, typedValue, true);
        long j3 = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
        Drawable e10 = e(context, j3);
        if (e10 != null) {
            return e10;
        }
        LayerDrawable layerDrawable = null;
        if (this.f1464g != null) {
            if (i10 == R.drawable.abc_cab_background_top_material) {
                layerDrawable = new LayerDrawable(new Drawable[]{f(context, R.drawable.abc_cab_background_internal_bg), f(context, R.drawable.abc_cab_background_top_mtrl_alpha)});
            } else {
                if (i10 == R.drawable.abc_ratingbar_material) {
                    i11 = R.dimen.abc_star_big;
                } else if (i10 == R.drawable.abc_ratingbar_indicator_material) {
                    i11 = R.dimen.abc_star_medium;
                } else if (i10 == R.drawable.abc_ratingbar_small_material) {
                    i11 = R.dimen.abc_star_small;
                }
                layerDrawable = b.q(this, context, i11);
            }
        }
        if (layerDrawable != null) {
            layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
            b(context, j3, layerDrawable);
        }
        return layerDrawable;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002e, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized android.graphics.drawable.Drawable e(android.content.Context r4, long r5) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.util.WeakHashMap r0 = r3.f1461d     // Catch:{ all -> 0x0028 }
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x0028 }
            s0.e r0 = (s0.e) r0     // Catch:{ all -> 0x0028 }
            r1 = 0
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            return r1
        L_0x000e:
            java.lang.Object r2 = r0.e(r5, r1)     // Catch:{ all -> 0x0028 }
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2     // Catch:{ all -> 0x0028 }
            if (r2 == 0) goto L_0x002d
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x0028 }
            android.graphics.drawable.Drawable$ConstantState r2 = (android.graphics.drawable.Drawable.ConstantState) r2     // Catch:{ all -> 0x0028 }
            if (r2 == 0) goto L_0x002a
            android.content.res.Resources r4 = r4.getResources()     // Catch:{ all -> 0x0028 }
            android.graphics.drawable.Drawable r4 = r2.newDrawable(r4)     // Catch:{ all -> 0x0028 }
            monitor-exit(r3)
            return r4
        L_0x0028:
            r4 = move-exception
            goto L_0x002f
        L_0x002a:
            r0.h(r5)     // Catch:{ all -> 0x0028 }
        L_0x002d:
            monitor-exit(r3)
            return r1
        L_0x002f:
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.p2.e(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    public final synchronized Drawable f(Context context, int i10) {
        return g(context, i10, false);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v0, resolved type: android.graphics.drawable.LayerDrawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: android.graphics.drawable.LayerDrawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v2, resolved type: android.graphics.drawable.LayerDrawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v8, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: android.graphics.PorterDuff$Mode} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v7, resolved type: android.graphics.drawable.LayerDrawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v12, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v13, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v15, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v16, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v17, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v18, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v19, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v20, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v21, resolved type: android.graphics.drawable.Drawable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v22, resolved type: android.graphics.drawable.Drawable} */
    /* JADX WARNING: type inference failed for: r7v3, types: [android.graphics.drawable.Drawable] */
    /* JADX WARNING: type inference failed for: r7v4 */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004b, code lost:
        if (r11.f1459b.getOrDefault(r0, (java.lang.Object) null) != null) goto L_0x0057;
     */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00a0 A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00cb A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00e3 A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x00ed A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x00f5 A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x019a A[Catch:{ Exception -> 0x00be, all -> 0x00e8 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized android.graphics.drawable.Drawable g(android.content.Context r12, int r13, boolean r14) {
        /*
            r11 = this;
            monitor-enter(r11)
            boolean r0 = r11.f1463f     // Catch:{ all -> 0x00e8 }
            r1 = 1
            if (r0 == 0) goto L_0x0007
            goto L_0x0026
        L_0x0007:
            r11.f1463f = r1     // Catch:{ all -> 0x00e8 }
            r0 = 2131230838(0x7f080076, float:1.807774E38)
            android.graphics.drawable.Drawable r0 = r11.f(r12, r0)     // Catch:{ all -> 0x00e8 }
            if (r0 == 0) goto L_0x019f
            boolean r2 = r0 instanceof l3.q     // Catch:{ all -> 0x00e8 }
            if (r2 != 0) goto L_0x0026
            java.lang.Class r0 = r0.getClass()     // Catch:{ all -> 0x00e8 }
            java.lang.String r0 = r0.getName()     // Catch:{ all -> 0x00e8 }
            java.lang.String r2 = "android.graphics.drawable.VectorDrawable"
            boolean r0 = r2.equals(r0)     // Catch:{ all -> 0x00e8 }
            if (r0 == 0) goto L_0x019f
        L_0x0026:
            s0.k r0 = r11.f1459b     // Catch:{ all -> 0x00e8 }
            r2 = 0
            if (r0 == 0) goto L_0x004d
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x00e8 }
            if (r0 != 0) goto L_0x004d
            s0.l r0 = r11.f1460c     // Catch:{ all -> 0x00e8 }
            java.lang.String r3 = "appcompat_skip_skip"
            if (r0 == 0) goto L_0x0050
            java.lang.Object r0 = r0.d(r13, r2)     // Catch:{ all -> 0x00e8 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ all -> 0x00e8 }
            boolean r4 = r3.equals(r0)     // Catch:{ all -> 0x00e8 }
            if (r4 != 0) goto L_0x004d
            if (r0 == 0) goto L_0x0057
            s0.k r4 = r11.f1459b     // Catch:{ all -> 0x00e8 }
            java.lang.Object r0 = r4.getOrDefault(r0, r2)     // Catch:{ all -> 0x00e8 }
            if (r0 != 0) goto L_0x0057
        L_0x004d:
            r7 = r2
            goto L_0x00e1
        L_0x0050:
            s0.l r0 = new s0.l     // Catch:{ all -> 0x00e8 }
            r0.<init>()     // Catch:{ all -> 0x00e8 }
            r11.f1460c = r0     // Catch:{ all -> 0x00e8 }
        L_0x0057:
            android.util.TypedValue r0 = r11.f1462e     // Catch:{ all -> 0x00e8 }
            if (r0 != 0) goto L_0x0062
            android.util.TypedValue r0 = new android.util.TypedValue     // Catch:{ all -> 0x00e8 }
            r0.<init>()     // Catch:{ all -> 0x00e8 }
            r11.f1462e = r0     // Catch:{ all -> 0x00e8 }
        L_0x0062:
            android.util.TypedValue r0 = r11.f1462e     // Catch:{ all -> 0x00e8 }
            android.content.res.Resources r4 = r12.getResources()     // Catch:{ all -> 0x00e8 }
            r4.getValue(r13, r0, r1)     // Catch:{ all -> 0x00e8 }
            int r5 = r0.assetCookie     // Catch:{ all -> 0x00e8 }
            long r5 = (long) r5     // Catch:{ all -> 0x00e8 }
            r7 = 32
            long r5 = r5 << r7
            int r7 = r0.data     // Catch:{ all -> 0x00e8 }
            long r7 = (long) r7     // Catch:{ all -> 0x00e8 }
            long r5 = r5 | r7
            android.graphics.drawable.Drawable r7 = r11.e(r12, r5)     // Catch:{ all -> 0x00e8 }
            if (r7 == 0) goto L_0x007c
            goto L_0x00e1
        L_0x007c:
            java.lang.CharSequence r8 = r0.string     // Catch:{ all -> 0x00e8 }
            if (r8 == 0) goto L_0x00da
            java.lang.String r8 = r8.toString()     // Catch:{ all -> 0x00e8 }
            java.lang.String r9 = ".xml"
            boolean r8 = r8.endsWith(r9)     // Catch:{ all -> 0x00e8 }
            if (r8 == 0) goto L_0x00da
            android.content.res.XmlResourceParser r4 = r4.getXml(r13)     // Catch:{ Exception -> 0x00be }
            android.util.AttributeSet r8 = android.util.Xml.asAttributeSet(r4)     // Catch:{ Exception -> 0x00be }
        L_0x0094:
            int r9 = r4.next()     // Catch:{ Exception -> 0x00be }
            r10 = 2
            if (r9 == r10) goto L_0x009e
            if (r9 == r1) goto L_0x009e
            goto L_0x0094
        L_0x009e:
            if (r9 != r10) goto L_0x00cb
            java.lang.String r1 = r4.getName()     // Catch:{ Exception -> 0x00be }
            s0.l r9 = r11.f1460c     // Catch:{ Exception -> 0x00be }
            r9.a(r13, r1)     // Catch:{ Exception -> 0x00be }
            s0.k r9 = r11.f1459b     // Catch:{ Exception -> 0x00be }
            java.lang.Object r1 = r9.getOrDefault(r1, r2)     // Catch:{ Exception -> 0x00be }
            androidx.appcompat.widget.o2 r1 = (androidx.appcompat.widget.o2) r1     // Catch:{ Exception -> 0x00be }
            if (r1 == 0) goto L_0x00c0
            android.content.res.Resources$Theme r9 = r12.getTheme()     // Catch:{ Exception -> 0x00be }
            androidx.appcompat.widget.m2 r1 = (androidx.appcompat.widget.m2) r1     // Catch:{ Exception -> 0x00be }
            android.graphics.drawable.Drawable r7 = r1.a(r12, r4, r8, r9)     // Catch:{ Exception -> 0x00be }
            goto L_0x00c0
        L_0x00be:
            r0 = move-exception
            goto L_0x00d3
        L_0x00c0:
            if (r7 == 0) goto L_0x00da
            int r0 = r0.changingConfigurations     // Catch:{ Exception -> 0x00be }
            r7.setChangingConfigurations(r0)     // Catch:{ Exception -> 0x00be }
            r11.b(r12, r5, r7)     // Catch:{ Exception -> 0x00be }
            goto L_0x00da
        L_0x00cb:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ Exception -> 0x00be }
            java.lang.String r1 = "No start tag found"
            r0.<init>(r1)     // Catch:{ Exception -> 0x00be }
            throw r0     // Catch:{ Exception -> 0x00be }
        L_0x00d3:
            java.lang.String r1 = "ResourceManagerInternal"
            java.lang.String r4 = "Exception while inflating drawable"
            android.util.Log.e(r1, r4, r0)     // Catch:{ all -> 0x00e8 }
        L_0x00da:
            if (r7 != 0) goto L_0x00e1
            s0.l r0 = r11.f1460c     // Catch:{ all -> 0x00e8 }
            r0.a(r13, r3)     // Catch:{ all -> 0x00e8 }
        L_0x00e1:
            if (r7 != 0) goto L_0x00eb
            android.graphics.drawable.Drawable r7 = r11.c(r12, r13)     // Catch:{ all -> 0x00e8 }
            goto L_0x00eb
        L_0x00e8:
            r12 = move-exception
            goto L_0x01aa
        L_0x00eb:
            if (r7 != 0) goto L_0x00f3
            java.lang.Object r0 = h1.i.f19490a     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r7 = h1.b.b(r12, r13)     // Catch:{ all -> 0x00e8 }
        L_0x00f3:
            if (r7 == 0) goto L_0x0198
            android.content.res.ColorStateList r0 = r11.i(r12, r13)     // Catch:{ all -> 0x00e8 }
            if (r0 == 0) goto L_0x011c
            int[] r12 = androidx.appcompat.widget.o1.f1445a     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r12 = r7.mutate()     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r12 = t7.w.m(r12)     // Catch:{ all -> 0x00e8 }
            k1.b.h(r12, r0)     // Catch:{ all -> 0x00e8 }
            pa.b r14 = r11.f1464g     // Catch:{ all -> 0x00e8 }
            if (r14 != 0) goto L_0x010d
            goto L_0x0114
        L_0x010d:
            r14 = 2131230825(0x7f080069, float:1.8077714E38)
            if (r13 != r14) goto L_0x0114
            android.graphics.PorterDuff$Mode r2 = android.graphics.PorterDuff.Mode.MULTIPLY     // Catch:{ all -> 0x00e8 }
        L_0x0114:
            if (r2 == 0) goto L_0x0119
            k1.b.i(r12, r2)     // Catch:{ all -> 0x00e8 }
        L_0x0119:
            r2 = r12
            goto L_0x0197
        L_0x011c:
            pa.b r0 = r11.f1464g     // Catch:{ all -> 0x00e8 }
            if (r0 == 0) goto L_0x018d
            r0 = 2131230820(0x7f080064, float:1.8077704E38)
            r1 = 16908301(0x102000d, float:2.3877265E-38)
            r3 = 16908303(0x102000f, float:2.387727E-38)
            r4 = 16908288(0x1020000, float:2.387723E-38)
            r5 = 2130968840(0x7f040108, float:1.7546345E38)
            r6 = 2130968842(0x7f04010a, float:1.754635E38)
            if (r13 != r0) goto L_0x015a
            r13 = r7
            android.graphics.drawable.LayerDrawable r13 = (android.graphics.drawable.LayerDrawable) r13     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r14 = r13.findDrawableByLayerId(r4)     // Catch:{ all -> 0x00e8 }
            int r0 = androidx.appcompat.widget.o3.c(r12, r6)     // Catch:{ all -> 0x00e8 }
            android.graphics.PorterDuff$Mode r2 = androidx.appcompat.widget.z.f1585b     // Catch:{ all -> 0x00e8 }
            pa.b.C(r14, r0, r2)     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r14 = r13.findDrawableByLayerId(r3)     // Catch:{ all -> 0x00e8 }
            int r0 = androidx.appcompat.widget.o3.c(r12, r6)     // Catch:{ all -> 0x00e8 }
            pa.b.C(r14, r0, r2)     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r13 = r13.findDrawableByLayerId(r1)     // Catch:{ all -> 0x00e8 }
            int r12 = androidx.appcompat.widget.o3.c(r12, r5)     // Catch:{ all -> 0x00e8 }
        L_0x0156:
            pa.b.C(r13, r12, r2)     // Catch:{ all -> 0x00e8 }
            goto L_0x0196
        L_0x015a:
            r0 = 2131230811(0x7f08005b, float:1.8077685E38)
            if (r13 == r0) goto L_0x0169
            r0 = 2131230810(0x7f08005a, float:1.8077683E38)
            if (r13 == r0) goto L_0x0169
            r0 = 2131230812(0x7f08005c, float:1.8077687E38)
            if (r13 != r0) goto L_0x018d
        L_0x0169:
            r13 = r7
            android.graphics.drawable.LayerDrawable r13 = (android.graphics.drawable.LayerDrawable) r13     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r14 = r13.findDrawableByLayerId(r4)     // Catch:{ all -> 0x00e8 }
            int r0 = androidx.appcompat.widget.o3.b(r12, r6)     // Catch:{ all -> 0x00e8 }
            android.graphics.PorterDuff$Mode r2 = androidx.appcompat.widget.z.f1585b     // Catch:{ all -> 0x00e8 }
            pa.b.C(r14, r0, r2)     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r14 = r13.findDrawableByLayerId(r3)     // Catch:{ all -> 0x00e8 }
            int r0 = androidx.appcompat.widget.o3.c(r12, r5)     // Catch:{ all -> 0x00e8 }
            pa.b.C(r14, r0, r2)     // Catch:{ all -> 0x00e8 }
            android.graphics.drawable.Drawable r13 = r13.findDrawableByLayerId(r1)     // Catch:{ all -> 0x00e8 }
            int r12 = androidx.appcompat.widget.o3.c(r12, r5)     // Catch:{ all -> 0x00e8 }
            goto L_0x0156
        L_0x018d:
            boolean r12 = r11.m(r13, r12, r7)     // Catch:{ all -> 0x00e8 }
            if (r12 != 0) goto L_0x0196
            if (r14 == 0) goto L_0x0196
            goto L_0x0197
        L_0x0196:
            r2 = r7
        L_0x0197:
            r7 = r2
        L_0x0198:
            if (r7 == 0) goto L_0x019d
            androidx.appcompat.widget.o1.a(r7)     // Catch:{ all -> 0x00e8 }
        L_0x019d:
            monitor-exit(r11)
            return r7
        L_0x019f:
            r12 = 0
            r11.f1463f = r12     // Catch:{ all -> 0x00e8 }
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException     // Catch:{ all -> 0x00e8 }
            java.lang.String r13 = "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."
            r12.<init>(r13)     // Catch:{ all -> 0x00e8 }
            throw r12     // Catch:{ all -> 0x00e8 }
        L_0x01aa:
            monitor-exit(r11)
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.p2.g(android.content.Context, int, boolean):android.graphics.drawable.Drawable");
    }

    public final synchronized ColorStateList i(Context context, int i10) {
        ColorStateList colorStateList;
        l lVar;
        WeakHashMap weakHashMap = this.f1458a;
        ColorStateList colorStateList2 = null;
        if (weakHashMap == null || (lVar = (l) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            colorStateList = (ColorStateList) lVar.d(i10, (Integer) null);
        }
        if (colorStateList == null) {
            b bVar = this.f1464g;
            if (bVar != null) {
                colorStateList2 = bVar.u(context, i10);
            }
            if (colorStateList2 != null) {
                if (this.f1458a == null) {
                    this.f1458a = new WeakHashMap();
                }
                l lVar2 = (l) this.f1458a.get(context);
                if (lVar2 == null) {
                    lVar2 = new l();
                    this.f1458a.put(context, lVar2);
                }
                lVar2.a(i10, colorStateList2);
            }
            colorStateList = colorStateList2;
        }
        return colorStateList;
    }

    public final synchronized void k(Context context) {
        e eVar = (e) this.f1461d.get(context);
        if (eVar != null) {
            eVar.b();
        }
    }

    public final synchronized void l(b bVar) {
        this.f1464g = bVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean m(int r7, android.content.Context r8, android.graphics.drawable.Drawable r9) {
        /*
            r6 = this;
            pa.b r0 = r6.f1464g
            r1 = 0
            if (r0 == 0) goto L_0x0070
            android.graphics.PorterDuff$Mode r2 = androidx.appcompat.widget.z.f1585b
            java.lang.Object r3 = r0.f24099a
            int[] r3 = (int[]) r3
            boolean r3 = pa.b.e(r3, r7)
            r4 = 1
            r5 = -1
            if (r3 == 0) goto L_0x0019
            r7 = 2130968842(0x7f04010a, float:1.754635E38)
        L_0x0016:
            r0 = -1
        L_0x0017:
            r3 = 1
            goto L_0x0057
        L_0x0019:
            java.lang.Object r3 = r0.f24101c
            int[] r3 = (int[]) r3
            boolean r3 = pa.b.e(r3, r7)
            if (r3 == 0) goto L_0x0027
            r7 = 2130968840(0x7f040108, float:1.7546345E38)
            goto L_0x0016
        L_0x0027:
            java.lang.Object r0 = r0.f24102d
            int[] r0 = (int[]) r0
            boolean r0 = pa.b.e(r0, r7)
            r3 = 16842801(0x1010031, float:2.3693695E-38)
            if (r0 == 0) goto L_0x003a
            android.graphics.PorterDuff$Mode r2 = android.graphics.PorterDuff.Mode.MULTIPLY
        L_0x0036:
            r7 = 16842801(0x1010031, float:2.3693695E-38)
            goto L_0x0016
        L_0x003a:
            r0 = 2131230797(0x7f08004d, float:1.8077657E38)
            if (r7 != r0) goto L_0x004e
            r7 = 1109603123(0x42233333, float:40.8)
            int r7 = java.lang.Math.round(r7)
            r0 = 16842800(0x1010030, float:2.3693693E-38)
            r0 = r7
            r7 = 16842800(0x1010030, float:2.3693693E-38)
            goto L_0x0017
        L_0x004e:
            r0 = 2131230779(0x7f08003b, float:1.807762E38)
            if (r7 != r0) goto L_0x0054
            goto L_0x0036
        L_0x0054:
            r7 = 0
            r0 = -1
            r3 = 0
        L_0x0057:
            if (r3 == 0) goto L_0x0070
            int[] r1 = androidx.appcompat.widget.o1.f1445a
            android.graphics.drawable.Drawable r9 = r9.mutate()
            int r7 = androidx.appcompat.widget.o3.c(r8, r7)
            android.graphics.PorterDuffColorFilter r7 = androidx.appcompat.widget.z.c(r7, r2)
            r9.setColorFilter(r7)
            if (r0 == r5) goto L_0x006f
            r9.setAlpha(r0)
        L_0x006f:
            r1 = 1
        L_0x0070:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.p2.m(int, android.content.Context, android.graphics.drawable.Drawable):boolean");
    }
}
