package androidx.appcompat.widget;

public interface o {
    boolean a();

    boolean c();
}
