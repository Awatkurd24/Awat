package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import u7.y;
import v1.v;
import v7.je;
import yg.b0;

public class AppCompatCheckedTextView extends CheckedTextView implements v {

    /* renamed from: a  reason: collision with root package name */
    public final y f1091a;

    /* renamed from: b  reason: collision with root package name */
    public final x f1092b;

    /* renamed from: c  reason: collision with root package name */
    public final y0 f1093c;

    /* renamed from: d  reason: collision with root package name */
    public b0 f1094d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        p3.a(context);
        o3.a(getContext(), this);
        y0 y0Var = new y0(this);
        this.f1093c = y0Var;
        y0Var.f(attributeSet, i10);
        y0Var.b();
        x xVar = new x((View) this);
        this.f1092b = xVar;
        xVar.f(attributeSet, i10);
        y yVar = new y(this, 0);
        this.f1091a = yVar;
        yVar.c(attributeSet, i10);
        getEmojiTextViewHelper().b(attributeSet, i10);
    }

    private b0 getEmojiTextViewHelper() {
        if (this.f1094d == null) {
            this.f1094d = new b0(this);
        }
        return this.f1094d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        y0 y0Var = this.f1093c;
        if (y0Var != null) {
            y0Var.b();
        }
        x xVar = this.f1092b;
        if (xVar != null) {
            xVar.a();
        }
        y yVar = this.f1091a;
        if (yVar != null) {
            yVar.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return je.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        x xVar = this.f1092b;
        if (xVar != null) {
            return xVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        x xVar = this.f1092b;
        if (xVar != null) {
            return xVar.e();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        y yVar = this.f1091a;
        if (yVar != null) {
            return (ColorStateList) yVar.f1550b;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        y yVar = this.f1091a;
        if (yVar != null) {
            return (PorterDuff.Mode) yVar.f1551c;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1093c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1093c.e();
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        b0.x(this, editorInfo, onCreateInputConnection);
        return onCreateInputConnection;
    }

    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        x xVar = this.f1092b;
        if (xVar != null) {
            xVar.g();
        }
    }

    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        x xVar = this.f1092b;
        if (xVar != null) {
            xVar.h(i10);
        }
    }

    public void setCheckMarkDrawable(int i10) {
        setCheckMarkDrawable(y.e(getContext(), i10));
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1093c;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        y0 y0Var = this.f1093c;
        if (y0Var != null) {
            y0Var.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(je.s(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        x xVar = this.f1092b;
        if (xVar != null) {
            xVar.j(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        x xVar = this.f1092b;
        if (xVar != null) {
            xVar.k(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        y yVar = this.f1091a;
        if (yVar != null) {
            yVar.f1550b = colorStateList;
            yVar.f1552d = true;
            yVar.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        y yVar = this.f1091a;
        if (yVar != null) {
            yVar.f1551c = mode;
            yVar.f1553e = true;
            yVar.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        y0 y0Var = this.f1093c;
        y0Var.l(colorStateList);
        y0Var.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        y0 y0Var = this.f1093c;
        y0Var.m(mode);
        y0Var.b();
    }

    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        y0 y0Var = this.f1093c;
        if (y0Var != null) {
            y0Var.g(context, i10);
        }
    }

    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        y yVar = this.f1091a;
        if (yVar == null) {
            return;
        }
        if (yVar.f1554f) {
            yVar.f1554f = false;
            return;
        }
        yVar.f1554f = true;
        yVar.b();
    }
}
