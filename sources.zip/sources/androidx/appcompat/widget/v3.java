package androidx.appcompat.widget;

import h.a;

public final class v3 extends a {

    /* renamed from: b  reason: collision with root package name */
    public int f1526b;
}
