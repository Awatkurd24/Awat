package androidx.appcompat.widget;

import android.content.res.Resources;

public abstract class q2 extends Resources {
}
