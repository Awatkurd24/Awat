package androidx.appcompat.widget;

public final class q extends y1 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1466a;

    /* renamed from: b  reason: collision with root package name */
    public int f1467b;

    /* renamed from: c  reason: collision with root package name */
    public int f1468c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1469d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1470e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1471f;
}
