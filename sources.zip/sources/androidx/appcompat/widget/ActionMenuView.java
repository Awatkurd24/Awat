package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import m.b0;
import m.c0;
import m.e0;
import m.m;
import m.n;
import m.o;
import m.q;

public class ActionMenuView extends LinearLayoutCompat implements n, e0 {
    public r A;

    /* renamed from: p  reason: collision with root package name */
    public o f1057p;

    /* renamed from: q  reason: collision with root package name */
    public Context f1058q;

    /* renamed from: r  reason: collision with root package name */
    public int f1059r = 0;

    /* renamed from: s  reason: collision with root package name */
    public boolean f1060s;

    /* renamed from: t  reason: collision with root package name */
    public n f1061t;

    /* renamed from: u  reason: collision with root package name */
    public b0 f1062u;

    /* renamed from: v  reason: collision with root package name */
    public m f1063v;

    /* renamed from: w  reason: collision with root package name */
    public boolean f1064w;

    /* renamed from: x  reason: collision with root package name */
    public int f1065x;

    /* renamed from: y  reason: collision with root package name */
    public final int f1066y;

    /* renamed from: z  reason: collision with root package name */
    public final int f1067z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f10 = context.getResources().getDisplayMetrics().density;
        this.f1066y = (int) (56.0f * f10);
        this.f1067z = (int) (f10 * 4.0f);
        this.f1058q = context;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [androidx.appcompat.widget.q, android.widget.LinearLayout$LayoutParams] */
    public static q l() {
        ? layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.f1466a = false;
        layoutParams.gravity = 16;
        return layoutParams;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [android.widget.LinearLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r0v3, types: [androidx.appcompat.widget.q, android.widget.LinearLayout$LayoutParams] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static androidx.appcompat.widget.q m(android.view.ViewGroup.LayoutParams r1) {
        /*
            if (r1 == 0) goto L_0x0020
            boolean r0 = r1 instanceof androidx.appcompat.widget.q
            if (r0 == 0) goto L_0x0012
            androidx.appcompat.widget.q r0 = new androidx.appcompat.widget.q
            androidx.appcompat.widget.q r1 = (androidx.appcompat.widget.q) r1
            r0.<init>(r1)
            boolean r1 = r1.f1466a
            r0.f1466a = r1
            goto L_0x0017
        L_0x0012:
            androidx.appcompat.widget.q r0 = new androidx.appcompat.widget.q
            r0.<init>(r1)
        L_0x0017:
            int r1 = r0.gravity
            if (r1 > 0) goto L_0x001f
            r1 = 16
            r0.gravity = r1
        L_0x001f:
            return r0
        L_0x0020:
            androidx.appcompat.widget.q r1 = l()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionMenuView.m(android.view.ViewGroup$LayoutParams):androidx.appcompat.widget.q");
    }

    public final void c(o oVar) {
        this.f1057p = oVar;
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof q;
    }

    public final boolean d(q qVar) {
        return this.f1057p.q(qVar, (c0) null, 0);
    }

    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return l();
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: m.b0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v9, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: m.b0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v11, resolved type: m.b0} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.Menu getMenu() {
        /*
            r4 = this;
            m.o r0 = r4.f1057p
            if (r0 != 0) goto L_0x003e
            android.content.Context r0 = r4.getContext()
            m.o r1 = new m.o
            r1.<init>(r0)
            r4.f1057p = r1
            ha.c r2 = new ha.c
            r3 = 3
            r2.<init>(r3, r4)
            r1.f22299e = r2
            androidx.appcompat.widget.n r1 = new androidx.appcompat.widget.n
            r1.<init>(r0)
            r4.f1061t = r1
            r0 = 1
            r1.f1430m = r0
            r1.f1431n = r0
            m.b0 r0 = r4.f1062u
            if (r0 == 0) goto L_0x0028
            goto L_0x002d
        L_0x0028:
            androidx.appcompat.widget.p r0 = new androidx.appcompat.widget.p
            r0.<init>()
        L_0x002d:
            r1.f1422e = r0
            m.o r0 = r4.f1057p
            android.content.Context r2 = r4.f1058q
            r0.b(r1, r2)
            androidx.appcompat.widget.n r0 = r4.f1061t
            r0.f1425h = r4
            m.o r0 = r0.f1420c
            r4.f1057p = r0
        L_0x003e:
            m.o r0 = r4.f1057p
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionMenuView.getMenu():android.view.Menu");
    }

    public Drawable getOverflowIcon() {
        getMenu();
        n nVar = this.f1061t;
        l lVar = nVar.f1427j;
        if (lVar != null) {
            return lVar.getDrawable();
        }
        if (nVar.f1429l) {
            return nVar.f1428k;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f1059r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final /* bridge */ /* synthetic */ y1 h() {
        return l();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.LinearLayout$LayoutParams, androidx.appcompat.widget.y1] */
    public final y1 i(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    public final /* bridge */ /* synthetic */ y1 j(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }

    public final boolean n(int i10) {
        boolean z4 = false;
        if (i10 == 0) {
            return false;
        }
        View childAt = getChildAt(i10 - 1);
        View childAt2 = getChildAt(i10);
        if (i10 < getChildCount() && (childAt instanceof o)) {
            z4 = ((o) childAt).a();
        }
        return (i10 <= 0 || !(childAt2 instanceof o)) ? z4 : z4 | ((o) childAt2).c();
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        n nVar = this.f1061t;
        if (nVar != null) {
            nVar.f(false);
            if (this.f1061t.e()) {
                this.f1061t.c();
                this.f1061t.n();
            }
        }
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        n nVar = this.f1061t;
        if (nVar != null) {
            nVar.c();
            h hVar = nVar.f1438u;
            if (hVar != null && hVar.b()) {
                hVar.f22213j.dismiss();
            }
        }
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        if (!this.f1064w) {
            super.onLayout(z4, i10, i11, i12, i13);
            return;
        }
        int childCount = getChildCount();
        int i16 = (i13 - i11) / 2;
        int dividerWidth = getDividerWidth();
        int i17 = i12 - i10;
        int paddingRight = (i17 - getPaddingRight()) - getPaddingLeft();
        boolean a10 = f4.a(this);
        int i18 = 0;
        int i19 = 0;
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt = getChildAt(i20);
            if (childAt.getVisibility() != 8) {
                q qVar = (q) childAt.getLayoutParams();
                if (qVar.f1466a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (n(i20)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (a10) {
                        i14 = getPaddingLeft() + qVar.leftMargin;
                        i15 = i14 + measuredWidth;
                    } else {
                        i15 = (getWidth() - getPaddingRight()) - qVar.rightMargin;
                        i14 = i15 - measuredWidth;
                    }
                    int i21 = i16 - (measuredHeight / 2);
                    childAt.layout(i14, i21, i15, measuredHeight + i21);
                    paddingRight -= measuredWidth;
                    i18 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + qVar.leftMargin) + qVar.rightMargin;
                    n(i20);
                    i19++;
                }
            }
        }
        if (childCount == 1 && i18 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i22 = (i17 / 2) - (measuredWidth2 / 2);
            int i23 = i16 - (measuredHeight2 / 2);
            childAt2.layout(i22, i23, measuredWidth2 + i22, measuredHeight2 + i23);
            return;
        }
        int i24 = i19 - (i18 ^ 1);
        int max = Math.max(0, i24 > 0 ? paddingRight / i24 : 0);
        if (a10) {
            int width = getWidth() - getPaddingRight();
            for (int i25 = 0; i25 < childCount; i25++) {
                View childAt3 = getChildAt(i25);
                q qVar2 = (q) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !qVar2.f1466a) {
                    int i26 = width - qVar2.rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i27 = i16 - (measuredHeight3 / 2);
                    childAt3.layout(i26 - measuredWidth3, i27, i26, measuredHeight3 + i27);
                    width = i26 - ((measuredWidth3 + qVar2.leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i28 = 0; i28 < childCount; i28++) {
            View childAt4 = getChildAt(i28);
            q qVar3 = (q) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !qVar3.f1466a) {
                int i29 = paddingLeft + qVar3.leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i30 = i16 - (measuredHeight4 / 2);
                childAt4.layout(i29, i30, i29 + measuredWidth4, measuredHeight4 + i30);
                paddingLeft = measuredWidth4 + qVar3.rightMargin + max + i29;
            }
        }
    }

    public final void onMeasure(int i10, int i11) {
        boolean z4;
        int i12;
        boolean z10;
        int i13;
        int i14;
        boolean z11;
        boolean z12;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        boolean z13;
        int i20;
        int i21;
        boolean z14;
        int i22;
        ActionMenuItemView actionMenuItemView;
        boolean z15;
        int i23;
        boolean z16;
        o oVar;
        boolean z17 = this.f1064w;
        if (View.MeasureSpec.getMode(i10) == 1073741824) {
            z4 = true;
        } else {
            z4 = false;
        }
        this.f1064w = z4;
        if (z17 != z4) {
            this.f1065x = 0;
        }
        int size = View.MeasureSpec.getSize(i10);
        if (!(!this.f1064w || (oVar = this.f1057p) == null || size == this.f1065x)) {
            this.f1065x = size;
            oVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f1064w || childCount <= 0) {
            int i24 = i11;
            for (int i25 = 0; i25 < childCount; i25++) {
                q qVar = (q) getChildAt(i25).getLayoutParams();
                qVar.rightMargin = 0;
                qVar.leftMargin = 0;
            }
            super.onMeasure(i10, i11);
            return;
        }
        int mode = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i10);
        int size3 = View.MeasureSpec.getSize(i11);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i11, paddingBottom, -2);
        int i26 = size2 - paddingRight;
        int i27 = this.f1066y;
        int i28 = i26 / i27;
        int i29 = i26 % i27;
        if (i28 == 0) {
            setMeasuredDimension(i26, 0);
            return;
        }
        int i30 = (i29 / i28) + i27;
        int childCount2 = getChildCount();
        int i31 = 0;
        int i32 = 0;
        int i33 = 0;
        boolean z18 = false;
        long j3 = 0;
        int i34 = 0;
        int i35 = 0;
        while (true) {
            i12 = this.f1067z;
            if (i33 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i33);
            int i36 = size3;
            if (childAt.getVisibility() == 8) {
                i20 = i26;
                i21 = paddingBottom;
            } else {
                boolean z19 = childAt instanceof ActionMenuItemView;
                int i37 = i31 + 1;
                if (z19) {
                    childAt.setPadding(i12, 0, i12, 0);
                }
                q qVar2 = (q) childAt.getLayoutParams();
                qVar2.f1471f = false;
                qVar2.f1468c = 0;
                qVar2.f1467b = 0;
                qVar2.f1469d = false;
                qVar2.leftMargin = 0;
                qVar2.rightMargin = 0;
                if (!z19 || !(!TextUtils.isEmpty(((ActionMenuItemView) childAt).getText()))) {
                    z14 = false;
                } else {
                    z14 = true;
                }
                qVar2.f1470e = z14;
                if (qVar2.f1466a) {
                    i22 = 1;
                } else {
                    i22 = i28;
                }
                int i38 = i37;
                q qVar3 = (q) childAt.getLayoutParams();
                i20 = i26;
                i21 = paddingBottom;
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - paddingBottom, View.MeasureSpec.getMode(childMeasureSpec));
                if (z19) {
                    actionMenuItemView = (ActionMenuItemView) childAt;
                } else {
                    actionMenuItemView = null;
                }
                if (actionMenuItemView == null || !(!TextUtils.isEmpty(actionMenuItemView.getText()))) {
                    z15 = false;
                } else {
                    z15 = true;
                }
                if (i22 <= 0 || (z15 && i22 < 2)) {
                    i23 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i22 * i30, Integer.MIN_VALUE), makeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i23 = measuredWidth / i30;
                    if (measuredWidth % i30 != 0) {
                        i23++;
                    }
                    if (z15 && i23 < 2) {
                        i23 = 2;
                    }
                }
                if (qVar3.f1466a || !z15) {
                    z16 = false;
                } else {
                    z16 = true;
                }
                qVar3.f1469d = z16;
                qVar3.f1467b = i23;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i23 * i30, 1073741824), makeMeasureSpec);
                i32 = Math.max(i32, i23);
                if (qVar2.f1469d) {
                    i34++;
                }
                if (qVar2.f1466a) {
                    z18 = true;
                }
                i28 -= i23;
                i35 = Math.max(i35, childAt.getMeasuredHeight());
                if (i23 == 1) {
                    j3 |= (long) (1 << i33);
                }
                i31 = i38;
            }
            i33++;
            size3 = i36;
            paddingBottom = i21;
            i26 = i20;
        }
        int i39 = i26;
        int i40 = size3;
        int i41 = i35;
        if (!z18 || i31 != 2) {
            z10 = false;
        } else {
            z10 = true;
        }
        boolean z20 = false;
        while (true) {
            if (i34 <= 0 || i28 <= 0) {
                i13 = mode;
                i14 = i41;
                z11 = z20;
            } else {
                int i42 = Integer.MAX_VALUE;
                int i43 = 0;
                int i44 = 0;
                long j10 = 0;
                while (i44 < childCount2) {
                    int i45 = i41;
                    q qVar4 = (q) getChildAt(i44).getLayoutParams();
                    boolean z21 = z20;
                    if (qVar4.f1469d) {
                        int i46 = qVar4.f1467b;
                        if (i46 < i42) {
                            j10 = 1 << i44;
                            i42 = i46;
                            i43 = 1;
                        } else if (i46 == i42) {
                            i43++;
                            j10 |= 1 << i44;
                        }
                    }
                    i44++;
                    z20 = z21;
                    i41 = i45;
                }
                i14 = i41;
                z11 = z20;
                j3 |= j10;
                if (i43 > i28) {
                    i13 = mode;
                    break;
                }
                int i47 = i42 + 1;
                int i48 = 0;
                while (i48 < childCount2) {
                    View childAt2 = getChildAt(i48);
                    q qVar5 = (q) childAt2.getLayoutParams();
                    int i49 = mode;
                    int i50 = childMeasureSpec;
                    int i51 = childCount2;
                    long j11 = (long) (1 << i48);
                    if ((j10 & j11) != 0) {
                        if (!z10 || !qVar5.f1470e) {
                            z13 = true;
                        } else {
                            z13 = true;
                            if (i28 == 1) {
                                childAt2.setPadding(i12 + i30, 0, i12, 0);
                            }
                        }
                        qVar5.f1467b += z13 ? 1 : 0;
                        qVar5.f1471f = z13;
                        i28--;
                    } else if (qVar5.f1467b == i47) {
                        j3 |= j11;
                    }
                    i48++;
                    childMeasureSpec = i50;
                    mode = i49;
                    childCount2 = i51;
                }
                i41 = i14;
                z20 = true;
            }
        }
        i13 = mode;
        i14 = i41;
        z11 = z20;
        int i52 = childMeasureSpec;
        int i53 = childCount2;
        if (z18 || i31 != 1) {
            z12 = false;
        } else {
            z12 = true;
        }
        if (i28 <= 0 || j3 == 0 || (i28 >= i31 - 1 && !z12 && i32 <= 1)) {
            i15 = i53;
        } else {
            float bitCount = (float) Long.bitCount(j3);
            if (!z12) {
                if ((j3 & 1) != 0 && !((q) getChildAt(0).getLayoutParams()).f1470e) {
                    bitCount -= 0.5f;
                }
                int i54 = i53 - 1;
                if ((j3 & ((long) (1 << i54))) != 0 && !((q) getChildAt(i54).getLayoutParams()).f1470e) {
                    bitCount -= 0.5f;
                }
            }
            if (bitCount > 0.0f) {
                i19 = (int) (((float) (i28 * i30)) / bitCount);
            } else {
                i19 = 0;
            }
            i15 = i53;
            for (int i55 = 0; i55 < i15; i55++) {
                if ((j3 & ((long) (1 << i55))) != 0) {
                    View childAt3 = getChildAt(i55);
                    q qVar6 = (q) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        qVar6.f1468c = i19;
                        qVar6.f1471f = true;
                        if (i55 == 0 && !qVar6.f1470e) {
                            qVar6.leftMargin = (-i19) / 2;
                        }
                    } else if (qVar6.f1466a) {
                        qVar6.f1468c = i19;
                        qVar6.f1471f = true;
                        qVar6.rightMargin = (-i19) / 2;
                    } else {
                        if (i55 != 0) {
                            qVar6.leftMargin = i19 / 2;
                        }
                        if (i55 != i15 - 1) {
                            qVar6.rightMargin = i19 / 2;
                        }
                    }
                    z11 = true;
                }
            }
        }
        if (z11) {
            int i56 = 0;
            while (i56 < i15) {
                View childAt4 = getChildAt(i56);
                q qVar7 = (q) childAt4.getLayoutParams();
                if (!qVar7.f1471f) {
                    i18 = i52;
                } else {
                    i18 = i52;
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((qVar7.f1467b * i30) + qVar7.f1468c, 1073741824), i18);
                }
                i56++;
                i52 = i18;
            }
        }
        if (i13 != 1073741824) {
            i17 = i39;
            i16 = i14;
        } else {
            i16 = i40;
            i17 = i39;
        }
        setMeasuredDimension(i17, i16);
    }

    public void setExpandedActionViewsExclusive(boolean z4) {
        this.f1061t.f1435r = z4;
    }

    public void setOnMenuItemClickListener(r rVar) {
        this.A = rVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        n nVar = this.f1061t;
        l lVar = nVar.f1427j;
        if (lVar != null) {
            lVar.setImageDrawable(drawable);
            return;
        }
        nVar.f1429l = true;
        nVar.f1428k = drawable;
    }

    public void setOverflowReserved(boolean z4) {
        this.f1060s = z4;
    }

    public void setPopupTheme(int i10) {
        if (this.f1059r != i10) {
            this.f1059r = i10;
            if (i10 == 0) {
                this.f1058q = getContext();
            } else {
                this.f1058q = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setPresenter(n nVar) {
        this.f1061t = nVar;
        nVar.f1425h = this;
        this.f1057p = nVar.f1420c;
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }
}
