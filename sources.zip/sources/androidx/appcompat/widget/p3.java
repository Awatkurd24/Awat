package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;

public abstract class p3 extends ContextWrapper {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f1465a = new Object();

    public static void a(Context context) {
        if (!(context.getResources() instanceof r3)) {
            context.getResources();
            int i10 = d4.f1326a;
        }
    }
}
