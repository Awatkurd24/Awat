package androidx.appcompat.widget;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import co.vpn.plusvpn.R;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;
import w1.a;
import w1.b;

public final class k3 extends b implements View.OnClickListener {

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ int f1388x = 0;

    /* renamed from: h  reason: collision with root package name */
    public final int f1389h;

    /* renamed from: i  reason: collision with root package name */
    public final int f1390i;

    /* renamed from: j  reason: collision with root package name */
    public final LayoutInflater f1391j;

    /* renamed from: k  reason: collision with root package name */
    public final SearchView f1392k;

    /* renamed from: l  reason: collision with root package name */
    public final SearchableInfo f1393l;

    /* renamed from: m  reason: collision with root package name */
    public final Context f1394m;

    /* renamed from: n  reason: collision with root package name */
    public final WeakHashMap f1395n;

    /* renamed from: o  reason: collision with root package name */
    public final int f1396o;

    /* renamed from: p  reason: collision with root package name */
    public int f1397p = 1;

    /* renamed from: q  reason: collision with root package name */
    public ColorStateList f1398q;

    /* renamed from: r  reason: collision with root package name */
    public int f1399r = -1;

    /* renamed from: s  reason: collision with root package name */
    public int f1400s = -1;

    /* renamed from: t  reason: collision with root package name */
    public int f1401t = -1;

    /* renamed from: u  reason: collision with root package name */
    public int f1402u = -1;

    /* renamed from: v  reason: collision with root package name */
    public int f1403v = -1;

    /* renamed from: w  reason: collision with root package name */
    public int f1404w = -1;

    public k3(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap weakHashMap) {
        int suggestionRowLayout = searchView.getSuggestionRowLayout();
        this.f28650b = true;
        this.f28651c = null;
        this.f28649a = false;
        this.f28652d = -1;
        this.f28653e = new a(this);
        this.f28654f = new d2(1, this);
        this.f1390i = suggestionRowLayout;
        this.f1389h = suggestionRowLayout;
        this.f1391j = (LayoutInflater) context.getSystemService("layout_inflater");
        this.f1392k = searchView;
        this.f1393l = searchableInfo;
        this.f1396o = searchView.getSuggestionCommitIconResId();
        this.f1394m = context;
        this.f1395n = weakHashMap;
    }

    public static String q(Cursor cursor, int i10) {
        if (i10 == -1) {
            return null;
        }
        try {
            return cursor.getString(i10);
        } catch (Exception e10) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e10);
            return null;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v3, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v6, resolved type: android.text.SpannableString} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v10, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v11, resolved type: java.lang.String} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x013b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.view.View r22, android.database.Cursor r23) {
        /*
            r21 = this;
            r1 = r21
            r2 = r23
            java.lang.Object r0 = r22.getTag()
            r3 = r0
            androidx.appcompat.widget.j3 r3 = (androidx.appcompat.widget.j3) r3
            int r0 = r1.f1404w
            r4 = 0
            r5 = -1
            if (r0 == r5) goto L_0x0017
            int r0 = r2.getInt(r0)
            r6 = r0
            goto L_0x0018
        L_0x0017:
            r6 = 0
        L_0x0018:
            android.widget.TextView r7 = r3.f1372a
            r8 = 8
            if (r7 == 0) goto L_0x0034
            int r0 = r1.f1399r
            java.lang.String r0 = q(r2, r0)
            r7.setText(r0)
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto L_0x0031
            r7.setVisibility(r8)
            goto L_0x0034
        L_0x0031:
            r7.setVisibility(r4)
        L_0x0034:
            r9 = 1
            r10 = 2
            android.content.Context r11 = r1.f1394m
            android.widget.TextView r0 = r3.f1373b
            if (r0 == 0) goto L_0x00ba
            int r12 = r1.f1401t
            java.lang.String r12 = q(r2, r12)
            if (r12 == 0) goto L_0x008d
            android.content.res.ColorStateList r13 = r1.f1398q
            if (r13 != 0) goto L_0x0063
            android.util.TypedValue r13 = new android.util.TypedValue
            r13.<init>()
            android.content.res.Resources$Theme r14 = r11.getTheme()
            r15 = 2130969889(0x7f040521, float:1.7548473E38)
            r14.resolveAttribute(r15, r13, r9)
            android.content.res.Resources r14 = r11.getResources()
            int r13 = r13.resourceId
            android.content.res.ColorStateList r13 = r14.getColorStateList(r13)
            r1.f1398q = r13
        L_0x0063:
            android.text.SpannableString r13 = new android.text.SpannableString
            r13.<init>(r12)
            android.text.style.TextAppearanceSpan r15 = new android.text.style.TextAppearanceSpan
            r16 = 0
            r17 = 0
            r18 = 0
            android.content.res.ColorStateList r14 = r1.f1398q
            r19 = 0
            r20 = r14
            r14 = r15
            r5 = r15
            r15 = r16
            r16 = r17
            r17 = r18
            r18 = r20
            r14.<init>(r15, r16, r17, r18, r19)
            int r12 = r12.length()
            r14 = 33
            r13.setSpan(r5, r4, r12, r14)
            goto L_0x0093
        L_0x008d:
            int r5 = r1.f1400s
            java.lang.String r13 = q(r2, r5)
        L_0x0093:
            boolean r5 = android.text.TextUtils.isEmpty(r13)
            if (r5 == 0) goto L_0x00a2
            if (r7 == 0) goto L_0x00aa
            r7.setSingleLine(r4)
            r7.setMaxLines(r10)
            goto L_0x00aa
        L_0x00a2:
            if (r7 == 0) goto L_0x00aa
            r7.setSingleLine(r9)
            r7.setMaxLines(r9)
        L_0x00aa:
            r0.setText(r13)
            boolean r5 = android.text.TextUtils.isEmpty(r13)
            if (r5 == 0) goto L_0x00b7
            r0.setVisibility(r8)
            goto L_0x00ba
        L_0x00b7:
            r0.setVisibility(r4)
        L_0x00ba:
            android.widget.ImageView r12 = r3.f1374c
            if (r12 == 0) goto L_0x0161
            int r0 = r1.f1402u
            r13 = -1
            if (r0 != r13) goto L_0x00c6
            r0 = 0
            goto L_0x014d
        L_0x00c6:
            java.lang.String r0 = r2.getString(r0)
            android.graphics.drawable.Drawable r0 = r1.k(r0)
            if (r0 == 0) goto L_0x00d2
            goto L_0x014d
        L_0x00d2:
            android.app.SearchableInfo r0 = r1.f1393l
            android.content.ComponentName r0 = r0.getSearchActivity()
            java.lang.String r13 = r0.flattenToShortString()
            java.util.WeakHashMap r14 = r1.f1395n
            boolean r15 = r14.containsKey(r13)
            if (r15 == 0) goto L_0x00f7
            java.lang.Object r0 = r14.get(r13)
            android.graphics.drawable.Drawable$ConstantState r0 = (android.graphics.drawable.Drawable.ConstantState) r0
            if (r0 != 0) goto L_0x00ee
            r0 = 0
            goto L_0x0142
        L_0x00ee:
            android.content.res.Resources r13 = r11.getResources()
            android.graphics.drawable.Drawable r0 = r0.newDrawable(r13)
            goto L_0x0142
        L_0x00f7:
            java.lang.String r15 = "SuggestionsAdapter"
            android.content.pm.PackageManager r5 = r11.getPackageManager()
            r10 = 128(0x80, float:1.794E-43)
            android.content.pm.ActivityInfo r10 = r5.getActivityInfo(r0, r10)     // Catch:{ NameNotFoundException -> 0x0130 }
            int r8 = r10.getIconResource()
            if (r8 != 0) goto L_0x010b
        L_0x0109:
            r0 = 0
            goto L_0x0137
        L_0x010b:
            java.lang.String r9 = r0.getPackageName()
            android.content.pm.ApplicationInfo r10 = r10.applicationInfo
            android.graphics.drawable.Drawable r5 = r5.getDrawable(r9, r8, r10)
            if (r5 != 0) goto L_0x012e
            java.lang.String r5 = "Invalid icon resource "
            java.lang.String r9 = " for "
            java.lang.StringBuilder r5 = a4.l.K(r5, r8, r9)
            java.lang.String r0 = r0.flattenToShortString()
            r5.append(r0)
            java.lang.String r0 = r5.toString()
        L_0x012a:
            android.util.Log.w(r15, r0)
            goto L_0x0109
        L_0x012e:
            r0 = r5
            goto L_0x0137
        L_0x0130:
            r0 = move-exception
            r5 = r0
            java.lang.String r0 = r5.toString()
            goto L_0x012a
        L_0x0137:
            if (r0 != 0) goto L_0x013b
            r5 = 0
            goto L_0x013f
        L_0x013b:
            android.graphics.drawable.Drawable$ConstantState r5 = r0.getConstantState()
        L_0x013f:
            r14.put(r13, r5)
        L_0x0142:
            if (r0 == 0) goto L_0x0145
            goto L_0x014d
        L_0x0145:
            android.content.pm.PackageManager r0 = r11.getPackageManager()
            android.graphics.drawable.Drawable r0 = r0.getDefaultActivityIcon()
        L_0x014d:
            r12.setImageDrawable(r0)
            if (r0 != 0) goto L_0x0157
            r0 = 4
            r12.setVisibility(r0)
            goto L_0x0161
        L_0x0157:
            r12.setVisibility(r4)
            r0.setVisible(r4, r4)
            r5 = 1
            r0.setVisible(r5, r4)
        L_0x0161:
            android.widget.ImageView r0 = r3.f1375d
            if (r0 == 0) goto L_0x018a
            int r5 = r1.f1403v
            r8 = -1
            if (r5 != r8) goto L_0x016c
            r5 = 0
            goto L_0x0174
        L_0x016c:
            java.lang.String r2 = r2.getString(r5)
            android.graphics.drawable.Drawable r5 = r1.k(r2)
        L_0x0174:
            r0.setImageDrawable(r5)
            if (r5 != 0) goto L_0x017f
            r2 = 8
            r0.setVisibility(r2)
            goto L_0x018a
        L_0x017f:
            r0.setVisibility(r4)
            r5.setVisible(r4, r4)
            r2 = 1
            r5.setVisible(r2, r4)
            goto L_0x018b
        L_0x018a:
            r2 = 1
        L_0x018b:
            int r0 = r1.f1397p
            android.widget.ImageView r3 = r3.f1376e
            r5 = 2
            if (r0 == r5) goto L_0x019f
            if (r0 != r2) goto L_0x0199
            r0 = r6 & 1
            if (r0 == 0) goto L_0x0199
            goto L_0x019f
        L_0x0199:
            r2 = 8
            r3.setVisibility(r2)
            goto L_0x01ac
        L_0x019f:
            r3.setVisibility(r4)
            java.lang.CharSequence r0 = r7.getText()
            r3.setTag(r0)
            r3.setOnClickListener(r1)
        L_0x01ac:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.k3.a(android.view.View, android.database.Cursor):void");
    }

    public final void b(Cursor cursor) {
        try {
            super.b(cursor);
            if (cursor != null) {
                this.f1399r = cursor.getColumnIndex("suggest_text_1");
                this.f1400s = cursor.getColumnIndex("suggest_text_2");
                this.f1401t = cursor.getColumnIndex("suggest_text_2_url");
                this.f1402u = cursor.getColumnIndex("suggest_icon_1");
                this.f1403v = cursor.getColumnIndex("suggest_icon_2");
                this.f1404w = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e10) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e10);
        }
    }

    public final String c(Cursor cursor) {
        String q10;
        String q11;
        if (cursor == null) {
            return null;
        }
        String q12 = q(cursor, cursor.getColumnIndex("suggest_intent_query"));
        if (q12 != null) {
            return q12;
        }
        SearchableInfo searchableInfo = this.f1393l;
        if (searchableInfo.shouldRewriteQueryFromData() && (q11 = q(cursor, cursor.getColumnIndex("suggest_intent_data"))) != null) {
            return q11;
        }
        if (!searchableInfo.shouldRewriteQueryFromText() || (q10 = q(cursor, cursor.getColumnIndex("suggest_text_1"))) == null) {
            return null;
        }
        return q10;
    }

    public final View d(ViewGroup viewGroup) {
        View inflate = this.f1391j.inflate(this.f1389h, viewGroup, false);
        inflate.setTag(new j3(inflate));
        ((ImageView) inflate.findViewById(R.id.edit_query)).setImageResource(this.f1396o);
        return inflate;
    }

    public final View getDropDownView(int i10, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i10, view, viewGroup);
        } catch (RuntimeException e10) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e10);
            View inflate = this.f1391j.inflate(this.f1390i, viewGroup, false);
            if (inflate != null) {
                ((j3) inflate.getTag()).f1372a.setText(e10.toString());
            }
            return inflate;
        }
    }

    public final View getView(int i10, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i10, view, viewGroup);
        } catch (RuntimeException e10) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e10);
            View d10 = d(viewGroup);
            ((j3) d10.getTag()).f1372a.setText(e10.toString());
            return d10;
        }
    }

    public final boolean hasStableIds() {
        return false;
    }

    public final Drawable i(Uri uri) {
        int i10;
        String authority = uri.getAuthority();
        if (!TextUtils.isEmpty(authority)) {
            try {
                Resources resourcesForApplication = this.f1394m.getPackageManager().getResourcesForApplication(authority);
                List<String> pathSegments = uri.getPathSegments();
                if (pathSegments != null) {
                    int size = pathSegments.size();
                    if (size == 1) {
                        try {
                            i10 = Integer.parseInt(pathSegments.get(0));
                        } catch (NumberFormatException unused) {
                            throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                        }
                    } else if (size == 2) {
                        i10 = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
                    } else {
                        throw new FileNotFoundException("More than two path segments: " + uri);
                    }
                    if (i10 != 0) {
                        return resourcesForApplication.getDrawable(i10);
                    }
                    throw new FileNotFoundException("No resource found for: " + uri);
                }
                throw new FileNotFoundException("No path: " + uri);
            } catch (PackageManager.NameNotFoundException unused2) {
                throw new FileNotFoundException("No package found for authority: " + uri);
            }
        } else {
            throw new FileNotFoundException("No authority: " + uri);
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:34|35|36) */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00ac, code lost:
        throw new java.io.FileNotFoundException("Resource does not exist: " + r0);
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:34:0x009b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable k(java.lang.String r9) {
        /*
            r8 = this;
            java.lang.String r0 = "android.resource://"
            r1 = 0
            if (r9 == 0) goto L_0x0123
            boolean r2 = r9.isEmpty()
            if (r2 != 0) goto L_0x0123
            java.lang.String r2 = "0"
            boolean r2 = r2.equals(r9)
            if (r2 == 0) goto L_0x0015
            goto L_0x0123
        L_0x0015:
            int r2 = java.lang.Integer.parseInt(r9)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            r3.<init>(r0)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            android.content.Context r0 = r8.f1394m     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.String r0 = r0.getPackageName()     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            r3.append(r0)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.String r0 = "/"
            r3.append(r0)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            r3.append(r2)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.String r0 = r3.toString()     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.util.WeakHashMap r3 = r8.f1395n     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.Object r3 = r3.get(r0)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            android.graphics.drawable.Drawable$ConstantState r3 = (android.graphics.drawable.Drawable.ConstantState) r3     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            if (r3 != 0) goto L_0x003f
            r3 = r1
            goto L_0x0043
        L_0x003f:
            android.graphics.drawable.Drawable r3 = r3.newDrawable()     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
        L_0x0043:
            if (r3 == 0) goto L_0x0046
            return r3
        L_0x0046:
            android.content.Context r3 = r8.f1394m     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            java.lang.Object r4 = h1.i.f19490a     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            android.graphics.drawable.Drawable r2 = h1.b.b(r3, r2)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            if (r2 == 0) goto L_0x0059
            java.util.WeakHashMap r3 = r8.f1395n     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            android.graphics.drawable.Drawable$ConstantState r4 = r2.getConstantState()     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
            r3.put(r0, r4)     // Catch:{ NumberFormatException -> 0x005a, NotFoundException -> 0x005c }
        L_0x0059:
            return r2
        L_0x005a:
            goto L_0x0068
        L_0x005c:
            java.lang.String r0 = "SuggestionsAdapter"
            java.lang.String r2 = "Icon resource not found: "
            java.lang.String r9 = r2.concat(r9)
            android.util.Log.w(r0, r9)
            return r1
        L_0x0068:
            java.util.WeakHashMap r0 = r8.f1395n
            java.lang.Object r0 = r0.get(r9)
            android.graphics.drawable.Drawable$ConstantState r0 = (android.graphics.drawable.Drawable.ConstantState) r0
            if (r0 != 0) goto L_0x0074
            r0 = r1
            goto L_0x0078
        L_0x0074:
            android.graphics.drawable.Drawable r0 = r0.newDrawable()
        L_0x0078:
            if (r0 == 0) goto L_0x007b
            return r0
        L_0x007b:
            android.net.Uri r0 = android.net.Uri.parse(r9)
            java.lang.String r2 = "SuggestionsAdapter"
            java.lang.String r3 = "Error closing icon stream for "
            java.lang.String r4 = "Failed to open "
            java.lang.String r5 = "Resource does not exist: "
            java.lang.String r6 = r0.getScheme()     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.String r7 = "android.resource"
            boolean r6 = r7.equals(r6)     // Catch:{ FileNotFoundException -> 0x0099 }
            if (r6 == 0) goto L_0x00ad
            android.graphics.drawable.Drawable r1 = r8.i(r0)     // Catch:{ NotFoundException -> 0x009b }
            goto L_0x0118
        L_0x0099:
            r3 = move-exception
            goto L_0x00fb
        L_0x009b:
            java.io.FileNotFoundException r3 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0099 }
            r4.<init>(r5)     // Catch:{ FileNotFoundException -> 0x0099 }
            r4.append(r0)     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.String r4 = r4.toString()     // Catch:{ FileNotFoundException -> 0x0099 }
            r3.<init>(r4)     // Catch:{ FileNotFoundException -> 0x0099 }
            throw r3     // Catch:{ FileNotFoundException -> 0x0099 }
        L_0x00ad:
            android.content.Context r5 = r8.f1394m     // Catch:{ FileNotFoundException -> 0x0099 }
            android.content.ContentResolver r5 = r5.getContentResolver()     // Catch:{ FileNotFoundException -> 0x0099 }
            java.io.InputStream r5 = r5.openInputStream(r0)     // Catch:{ FileNotFoundException -> 0x0099 }
            if (r5 == 0) goto L_0x00e9
            android.graphics.drawable.Drawable r4 = android.graphics.drawable.Drawable.createFromStream(r5, r1)     // Catch:{ all -> 0x00d3 }
            r5.close()     // Catch:{ IOException -> 0x00c1 }
            goto L_0x00d1
        L_0x00c1:
            r5 = move-exception
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0099 }
            r6.<init>(r3)     // Catch:{ FileNotFoundException -> 0x0099 }
            r6.append(r0)     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.String r3 = r6.toString()     // Catch:{ FileNotFoundException -> 0x0099 }
            android.util.Log.e(r2, r3, r5)     // Catch:{ FileNotFoundException -> 0x0099 }
        L_0x00d1:
            r1 = r4
            goto L_0x0118
        L_0x00d3:
            r4 = move-exception
            r5.close()     // Catch:{ IOException -> 0x00d8 }
            goto L_0x00e8
        L_0x00d8:
            r5 = move-exception
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0099 }
            r6.<init>(r3)     // Catch:{ FileNotFoundException -> 0x0099 }
            r6.append(r0)     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.String r3 = r6.toString()     // Catch:{ FileNotFoundException -> 0x0099 }
            android.util.Log.e(r2, r3, r5)     // Catch:{ FileNotFoundException -> 0x0099 }
        L_0x00e8:
            throw r4     // Catch:{ FileNotFoundException -> 0x0099 }
        L_0x00e9:
            java.io.FileNotFoundException r3 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0099 }
            r5.<init>(r4)     // Catch:{ FileNotFoundException -> 0x0099 }
            r5.append(r0)     // Catch:{ FileNotFoundException -> 0x0099 }
            java.lang.String r4 = r5.toString()     // Catch:{ FileNotFoundException -> 0x0099 }
            r3.<init>(r4)     // Catch:{ FileNotFoundException -> 0x0099 }
            throw r3     // Catch:{ FileNotFoundException -> 0x0099 }
        L_0x00fb:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "Icon not found: "
            r4.<init>(r5)
            r4.append(r0)
            java.lang.String r0 = ", "
            r4.append(r0)
            java.lang.String r0 = r3.getMessage()
            r4.append(r0)
            java.lang.String r0 = r4.toString()
            android.util.Log.w(r2, r0)
        L_0x0118:
            if (r1 == 0) goto L_0x0123
            java.util.WeakHashMap r0 = r8.f1395n
            android.graphics.drawable.Drawable$ConstantState r2 = r1.getConstantState()
            r0.put(r9, r2)
        L_0x0123:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.k3.k(java.lang.String):android.graphics.drawable.Drawable");
    }

    public final void notifyDataSetChanged() {
        Bundle bundle;
        super.notifyDataSetChanged();
        Cursor cursor = this.f28651c;
        if (cursor != null) {
            bundle = cursor.getExtras();
        } else {
            bundle = null;
        }
        if (bundle != null) {
            bundle.getBoolean("in_progress");
        }
    }

    public final void notifyDataSetInvalidated() {
        Bundle bundle;
        super.notifyDataSetInvalidated();
        Cursor cursor = this.f28651c;
        if (cursor != null) {
            bundle = cursor.getExtras();
        } else {
            bundle = null;
        }
        if (bundle != null) {
            bundle.getBoolean("in_progress");
        }
    }

    public final Cursor o(SearchableInfo searchableInfo, String str) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder fragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            fragment.appendEncodedPath(suggestPath);
        }
        fragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            fragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        fragment.appendQueryParameter("limit", String.valueOf(50));
        return this.f1394m.getContentResolver().query(fragment.build(), (String[]) null, suggestSelection, strArr2, (String) null);
    }

    public final void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f1392k.r((CharSequence) tag);
        }
    }
}
