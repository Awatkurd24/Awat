package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

public class AppCompatSeekBar extends SeekBar {

    /* renamed from: a  reason: collision with root package name */
    public final g0 f1116a;

    public AppCompatSeekBar(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        o3.a(getContext(), this);
        g0 g0Var = new g0(this);
        this.f1116a = g0Var;
        g0Var.a(attributeSet, i10);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        g0 g0Var = this.f1116a;
        Drawable drawable = g0Var.f1341e;
        if (drawable != null && drawable.isStateful()) {
            SeekBar seekBar = g0Var.f1340d;
            if (drawable.setState(seekBar.getDrawableState())) {
                seekBar.invalidateDrawable(drawable);
            }
        }
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1116a.f1341e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1116a.d(canvas);
    }
}
