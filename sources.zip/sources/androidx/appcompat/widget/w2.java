package androidx.appcompat.widget;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import co.vpn.plusvpn.R;
import h8.a;
import y8.d;

public final class w2 implements View.OnLayoutChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1530a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f1531b;

    public /* synthetic */ w2(int i10, Object obj) {
        this.f1530a = i10;
        this.f1531b = obj;
    }

    public final void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
        int i18;
        a aVar;
        int i19 = 0;
        int i20 = this.f1530a;
        Object obj = this.f1531b;
        switch (i20) {
            case 0:
                SearchView searchView = (SearchView) obj;
                View view2 = searchView.f1212x;
                if (view2.getWidth() > 1) {
                    Resources resources = searchView.getContext().getResources();
                    int paddingLeft = searchView.f1206r.getPaddingLeft();
                    Rect rect = new Rect();
                    boolean a10 = f4.a(searchView);
                    if (searchView.N) {
                        i19 = resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_icon_width) + resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_text_padding_left);
                    }
                    SearchView.SearchAutoComplete searchAutoComplete = searchView.f1203p;
                    searchAutoComplete.getDropDownBackground().getPadding(rect);
                    int i21 = rect.left;
                    if (a10) {
                        i18 = -i21;
                    } else {
                        i18 = paddingLeft - (i21 + i19);
                    }
                    searchAutoComplete.setDropDownHorizontalOffset(i18);
                    searchAutoComplete.setDropDownWidth((((view2.getWidth() + rect.left) + rect.right) + i19) - paddingLeft);
                    return;
                }
                return;
            case 1:
                d dVar = (d) obj;
                if (dVar.f30122n.getVisibility() == 0 && (aVar = dVar.F) != null) {
                    Rect rect2 = new Rect();
                    ImageView imageView = dVar.f30122n;
                    imageView.getDrawingRect(rect2);
                    aVar.setBounds(rect2);
                    aVar.i(imageView, (FrameLayout) null);
                    return;
                }
                return;
            default:
                l9.a aVar2 = (l9.a) obj;
                int i22 = l9.a.O;
                aVar2.getClass();
                int[] iArr = new int[2];
                view.getLocationOnScreen(iArr);
                aVar2.J = iArr[0];
                view.getWindowVisibleDisplayFrame(aVar2.D);
                return;
        }
    }
}
