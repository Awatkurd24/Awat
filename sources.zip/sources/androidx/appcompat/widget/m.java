package androidx.appcompat.widget;

import android.os.Parcel;
import android.os.Parcelable;

public final class m implements Parcelable.Creator {
    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, androidx.appcompat.widget.ActionMenuPresenter$SavedState] */
    public final Object createFromParcel(Parcel parcel) {
        ? obj = new Object();
        obj.f1056a = parcel.readInt();
        return obj;
    }

    public final Object[] newArray(int i10) {
        return new ActionMenuPresenter$SavedState[i10];
    }
}
