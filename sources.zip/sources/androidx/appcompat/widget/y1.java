package androidx.appcompat.widget;

import android.widget.LinearLayout;

public class y1 extends LinearLayout.LayoutParams {
}
