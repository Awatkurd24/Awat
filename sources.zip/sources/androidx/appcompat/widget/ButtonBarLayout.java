package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import co.vpn.plusvpn.R;
import g.a;
import r1.h1;

public class ButtonBarLayout extends LinearLayout {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1137a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f1138b;

    /* renamed from: c  reason: collision with root package name */
    public int f1139c = -1;

    public ButtonBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int[] iArr = a.f18930l;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        h1.q(this, context, iArr, attributeSet, obtainStyledAttributes, 0);
        this.f1137a = obtainStyledAttributes.getBoolean(0, true);
        obtainStyledAttributes.recycle();
        if (getOrientation() == 1) {
            setStacked(this.f1137a);
        }
    }

    private void setStacked(boolean z4) {
        if (this.f1138b == z4) {
            return;
        }
        if (!z4 || this.f1137a) {
            this.f1138b = z4;
            setOrientation(z4 ? 1 : 0);
            setGravity(z4 ? 8388613 : 80);
            View findViewById = findViewById(R.id.spacer);
            if (findViewById != null) {
                findViewById.setVisibility(z4 ? 8 : 4);
            }
            for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
                bringChildToFront(getChildAt(childCount));
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0047, code lost:
        if (r1 != false) goto L_0x0049;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onMeasure(int r7, int r8) {
        /*
            r6 = this;
            int r0 = android.view.View.MeasureSpec.getSize(r7)
            boolean r1 = r6.f1137a
            r2 = 0
            if (r1 == 0) goto L_0x0016
            int r1 = r6.f1139c
            if (r0 <= r1) goto L_0x0014
            boolean r1 = r6.f1138b
            if (r1 == 0) goto L_0x0014
            r6.setStacked(r2)
        L_0x0014:
            r6.f1139c = r0
        L_0x0016:
            boolean r1 = r6.f1138b
            r3 = 1
            if (r1 != 0) goto L_0x002b
            int r1 = android.view.View.MeasureSpec.getMode(r7)
            r4 = 1073741824(0x40000000, float:2.0)
            if (r1 != r4) goto L_0x002b
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1)
            r1 = 1
            goto L_0x002d
        L_0x002b:
            r0 = r7
            r1 = 0
        L_0x002d:
            super.onMeasure(r0, r8)
            boolean r0 = r6.f1137a
            if (r0 == 0) goto L_0x0047
            boolean r0 = r6.f1138b
            if (r0 != 0) goto L_0x0047
            int r0 = r6.getMeasuredWidthAndState()
            r4 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r4
            r4 = 16777216(0x1000000, float:2.3509887E-38)
            if (r0 != r4) goto L_0x0047
            r6.setStacked(r3)
            goto L_0x0049
        L_0x0047:
            if (r1 == 0) goto L_0x004c
        L_0x0049:
            super.onMeasure(r7, r8)
        L_0x004c:
            int r0 = r6.getChildCount()
            r1 = 0
        L_0x0051:
            r4 = -1
            if (r1 >= r0) goto L_0x0062
            android.view.View r5 = r6.getChildAt(r1)
            int r5 = r5.getVisibility()
            if (r5 != 0) goto L_0x005f
            goto L_0x0063
        L_0x005f:
            int r1 = r1 + 1
            goto L_0x0051
        L_0x0062:
            r1 = -1
        L_0x0063:
            if (r1 < 0) goto L_0x00bd
            android.view.View r0 = r6.getChildAt(r1)
            android.view.ViewGroup$LayoutParams r2 = r0.getLayoutParams()
            android.widget.LinearLayout$LayoutParams r2 = (android.widget.LinearLayout.LayoutParams) r2
            int r5 = r6.getPaddingTop()
            int r0 = r0.getMeasuredHeight()
            int r0 = r0 + r5
            int r5 = r2.topMargin
            int r0 = r0 + r5
            int r2 = r2.bottomMargin
            int r0 = r0 + r2
            boolean r2 = r6.f1138b
            if (r2 == 0) goto L_0x00b7
            int r1 = r1 + r3
            int r2 = r6.getChildCount()
        L_0x0087:
            if (r1 >= r2) goto L_0x0098
            android.view.View r3 = r6.getChildAt(r1)
            int r3 = r3.getVisibility()
            if (r3 != 0) goto L_0x0095
            r4 = r1
            goto L_0x0098
        L_0x0095:
            int r1 = r1 + 1
            goto L_0x0087
        L_0x0098:
            if (r4 < 0) goto L_0x00b5
            android.view.View r1 = r6.getChildAt(r4)
            int r1 = r1.getPaddingTop()
            android.content.res.Resources r2 = r6.getResources()
            android.util.DisplayMetrics r2 = r2.getDisplayMetrics()
            float r2 = r2.density
            r3 = 1098907648(0x41800000, float:16.0)
            float r2 = r2 * r3
            int r2 = (int) r2
            int r1 = r1 + r2
            int r1 = r1 + r0
            r2 = r1
            goto L_0x00bd
        L_0x00b5:
            r2 = r0
            goto L_0x00bd
        L_0x00b7:
            int r1 = r6.getPaddingBottom()
            int r2 = r1 + r0
        L_0x00bd:
            java.util.WeakHashMap r0 = r1.h1.f25195a
            int r0 = r1.p0.d(r6)
            if (r0 == r2) goto L_0x00cd
            r6.setMinimumHeight(r2)
            if (r8 != 0) goto L_0x00cd
            super.onMeasure(r7, r8)
        L_0x00cd:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ButtonBarLayout.onMeasure(int, int):void");
    }

    public void setAllowStacking(boolean z4) {
        if (this.f1137a != z4) {
            this.f1137a = z4;
            if (!z4 && this.f1138b) {
                setStacked(false);
            }
            requestLayout();
        }
    }
}
