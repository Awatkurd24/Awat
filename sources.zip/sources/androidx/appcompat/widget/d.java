package androidx.appcompat.widget;

import a9.p;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.View;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.android.material.transformation.ExpandableTransformationBehavior;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import j9.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import k3.r;
import l3.c;
import l3.f;
import q6.i;
import x8.g;

public final class d extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1322a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f1323b;

    public /* synthetic */ d(int i10, Object obj) {
        this.f1322a = i10;
        this.f1323b = obj;
    }

    public final void onAnimationCancel(Animator animator) {
        int i10 = this.f1322a;
        Object obj = this.f1323b;
        switch (i10) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) obj;
                actionBarOverlayLayout.f1052w = null;
                actionBarOverlayLayout.f1040k = false;
                return;
            case 3:
                i iVar = (i) obj;
                iVar.setEnabled(true);
                iVar.f24908a.setEnabled(true);
                return;
            default:
                super.onAnimationCancel(animator);
                return;
        }
    }

    public final void onAnimationEnd(Animator animator) {
        int i10 = this.f1322a;
        Object obj = this.f1323b;
        switch (i10) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) obj;
                actionBarOverlayLayout.f1052w = null;
                actionBarOverlayLayout.f1040k = false;
                return;
            case 1:
                ((r) obj).n();
                animator.removeListener(this);
                return;
            case 2:
                f fVar = (f) obj;
                ArrayList arrayList = new ArrayList(fVar.f21585e);
                int size = arrayList.size();
                for (int i11 = 0; i11 < size; i11++) {
                    ((c) arrayList.get(i11)).a(fVar);
                }
                return;
            case 3:
                i iVar = (i) obj;
                iVar.setEnabled(true);
                iVar.f24908a.setEnabled(true);
                return;
            case 4:
                ((HideBottomViewOnScrollBehavior) obj).f16284i = null;
                return;
            case 5:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) obj;
                bottomSheetBehavior.L(5);
                WeakReference weakReference = bottomSheetBehavior.X0;
                if (weakReference != null && weakReference.get() != null) {
                    ((View) bottomSheetBehavior.X0.get()).requestLayout();
                    return;
                }
                return;
            case 6:
                f.c.w(obj);
                throw null;
            case 7:
                a4.i iVar2 = (a4.i) obj;
                if (((ValueAnimator) iVar2.f551c) == animator) {
                    iVar2.f551c = null;
                    return;
                }
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                g gVar = (g) obj;
                gVar.f29694b.setTranslationY(0.0f);
                gVar.c(0.0f);
                return;
            case 10:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) obj;
                sideSheetBehavior.x(5);
                WeakReference weakReference2 = sideSheetBehavior.f16765p;
                if (weakReference2 != null && weakReference2.get() != null) {
                    ((View) sideSheetBehavior.f16765p.get()).requestLayout();
                    return;
                }
                return;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                j jVar = (j) obj;
                jVar.q();
                jVar.f20771r.start();
                return;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                ((ExpandableTransformationBehavior) obj).f16964b = null;
                return;
            default:
                super.onAnimationEnd(animator);
                return;
        }
    }

    public final void onAnimationRepeat(Animator animator) {
        switch (this.f1322a) {
            case 9:
                super.onAnimationRepeat(animator);
                p pVar = (p) this.f1323b;
                pVar.f728g = (pVar.f728g + 1) % pVar.f727f.f674c.length;
                pVar.f729h = true;
                return;
            default:
                super.onAnimationRepeat(animator);
                return;
        }
    }

    public final void onAnimationStart(Animator animator) {
        int i10 = this.f1322a;
        Object obj = this.f1323b;
        switch (i10) {
            case 2:
                f fVar = (f) obj;
                ArrayList arrayList = new ArrayList(fVar.f21585e);
                int size = arrayList.size();
                for (int i11 = 0; i11 < size; i11++) {
                    ((c) arrayList.get(i11)).b(fVar);
                }
                return;
            case 3:
                i iVar = (i) obj;
                iVar.setEnabled(false);
                iVar.f24908a.setEnabled(false);
                return;
            case 6:
                f.c.w(obj);
                throw null;
            default:
                super.onAnimationStart(animator);
                return;
        }
    }
}
