package androidx.appcompat.widget;

import a4.w;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.customview.view.AbsSavedState;
import androidx.fragment.app.o0;
import c0.g;
import co.vpn.plusvpn.R;
import h.a;
import h.y0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import l.j;
import m.b0;
import m.m;
import m.q;
import r1.h1;
import r1.o;
import r1.p;
import r1.q0;
import r1.s0;
import r1.t;
import r1.v;
import u7.y;
import xb.c;
import yb.b;

public class Toolbar extends ViewGroup implements p {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList D;
    public final ArrayList E;
    public final int[] F;
    public final t G;
    public ArrayList H;
    public w3 I;
    public final c J;
    public y3 K;
    public n L;
    public u3 M;
    public b0 N;
    public m O;
    public OnBackInvokedCallback W0;
    public OnBackInvokedDispatcher X0;
    public boolean Y0;
    public final y0 Z0;

    /* renamed from: a  reason: collision with root package name */
    public ActionMenuView f1247a;

    /* renamed from: b  reason: collision with root package name */
    public AppCompatTextView f1248b;

    /* renamed from: c  reason: collision with root package name */
    public AppCompatTextView f1249c;

    /* renamed from: d  reason: collision with root package name */
    public AppCompatImageButton f1250d;

    /* renamed from: e  reason: collision with root package name */
    public AppCompatImageView f1251e;

    /* renamed from: f  reason: collision with root package name */
    public final Drawable f1252f;

    /* renamed from: g  reason: collision with root package name */
    public final CharSequence f1253g;

    /* renamed from: h  reason: collision with root package name */
    public AppCompatImageButton f1254h;

    /* renamed from: i  reason: collision with root package name */
    public View f1255i;

    /* renamed from: j  reason: collision with root package name */
    public Context f1256j;

    /* renamed from: k  reason: collision with root package name */
    public int f1257k;

    /* renamed from: l  reason: collision with root package name */
    public int f1258l;

    /* renamed from: m  reason: collision with root package name */
    public int f1259m;

    /* renamed from: n  reason: collision with root package name */
    public final int f1260n;

    /* renamed from: o  reason: collision with root package name */
    public final int f1261o;

    /* renamed from: p  reason: collision with root package name */
    public int f1262p;

    /* renamed from: p0  reason: collision with root package name */
    public boolean f1263p0;

    /* renamed from: q  reason: collision with root package name */
    public int f1264q;

    /* renamed from: r  reason: collision with root package name */
    public int f1265r;

    /* renamed from: s  reason: collision with root package name */
    public int f1266s;

    /* renamed from: t  reason: collision with root package name */
    public r2 f1267t;

    /* renamed from: u  reason: collision with root package name */
    public int f1268u;

    /* renamed from: v  reason: collision with root package name */
    public int f1269v;

    /* renamed from: w  reason: collision with root package name */
    public final int f1270w;

    /* renamed from: x  reason: collision with root package name */
    public CharSequence f1271x;

    /* renamed from: y  reason: collision with root package name */
    public CharSequence f1272y;

    /* renamed from: z  reason: collision with root package name */
    public ColorStateList f1273z;

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Object();

        /* renamed from: c  reason: collision with root package name */
        public int f1274c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f1275d;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1274c = parcel.readInt();
            this.f1275d = parcel.readInt() != 0;
        }

        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeParcelable(this.f1896a, i10);
            parcel.writeInt(this.f1274c);
            parcel.writeInt(this.f1275d ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.toolbarStyle);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i10 = 0; i10 < menu.size(); i10++) {
            arrayList.add(menu.getItem(i10));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new j(getContext());
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.ViewGroup$MarginLayoutParams, androidx.appcompat.widget.v3, h.a] */
    public static v3 h() {
        ? marginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -2);
        marginLayoutParams.f1526b = 0;
        marginLayoutParams.f19252a = 8388627;
        return marginLayoutParams;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [androidx.appcompat.widget.v3, h.a] */
    /* JADX WARNING: type inference failed for: r0v4, types: [android.view.ViewGroup$MarginLayoutParams, androidx.appcompat.widget.v3, h.a] */
    /* JADX WARNING: type inference failed for: r0v5, types: [androidx.appcompat.widget.v3, h.a] */
    /* JADX WARNING: type inference failed for: r0v6, types: [androidx.appcompat.widget.v3, h.a] */
    public static v3 i(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof v3) {
            v3 v3Var = (v3) layoutParams;
            ? aVar = new a((a) v3Var);
            aVar.f1526b = 0;
            aVar.f1526b = v3Var.f1526b;
            return aVar;
        } else if (layoutParams instanceof a) {
            ? aVar2 = new a((a) layoutParams);
            aVar2.f1526b = 0;
            return aVar2;
        } else if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            ? aVar3 = new a((ViewGroup.LayoutParams) marginLayoutParams);
            aVar3.f1526b = 0;
            aVar3.leftMargin = marginLayoutParams.leftMargin;
            aVar3.topMargin = marginLayoutParams.topMargin;
            aVar3.rightMargin = marginLayoutParams.rightMargin;
            aVar3.bottomMargin = marginLayoutParams.bottomMargin;
            return aVar3;
        } else {
            ? aVar4 = new a(layoutParams);
            aVar4.f1526b = 0;
            return aVar4;
        }
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return o.b(marginLayoutParams) + o.c(marginLayoutParams);
    }

    public static int m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(int i10, ArrayList arrayList) {
        boolean z4;
        WeakHashMap weakHashMap = h1.f25195a;
        if (q0.d(this) == 1) {
            z4 = true;
        } else {
            z4 = false;
        }
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, q0.d(this));
        arrayList.clear();
        if (z4) {
            for (int i11 = childCount - 1; i11 >= 0; i11--) {
                View childAt = getChildAt(i11);
                v3 v3Var = (v3) childAt.getLayoutParams();
                if (v3Var.f1526b == 0 && v(childAt) && j(v3Var.f19252a) == absoluteGravity) {
                    arrayList.add(childAt);
                }
            }
            return;
        }
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt2 = getChildAt(i12);
            v3 v3Var2 = (v3) childAt2.getLayoutParams();
            if (v3Var2.f1526b == 0 && v(childAt2) && j(v3Var2.f19252a) == absoluteGravity) {
                arrayList.add(childAt2);
            }
        }
    }

    public final void addMenuProvider(v vVar) {
        t tVar = this.G;
        tVar.f25274b.add(vVar);
        tVar.f25273a.run();
    }

    public final void b(View view, boolean z4) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        v3 h10 = layoutParams == null ? h() : !checkLayoutParams(layoutParams) ? i(layoutParams) : (v3) layoutParams;
        h10.f1526b = 1;
        if (!z4 || this.f1255i == null) {
            addView(view, h10);
            return;
        }
        view.setLayoutParams(h10);
        this.E.add(view);
    }

    public final void c() {
        if (this.f1254h == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            this.f1254h = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f1252f);
            this.f1254h.setContentDescription(this.f1253g);
            v3 h10 = h();
            h10.f19252a = (this.f1260n & 112) | 8388611;
            h10.f1526b = 2;
            this.f1254h.setLayoutParams(h10);
            this.f1254h.setOnClickListener(new h.c(2, this));
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof v3);
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [androidx.appcompat.widget.r2, java.lang.Object] */
    public final void d() {
        if (this.f1267t == null) {
            ? obj = new Object();
            obj.f1484a = 0;
            obj.f1485b = 0;
            obj.f1486c = Integer.MIN_VALUE;
            obj.f1487d = Integer.MIN_VALUE;
            obj.f1488e = 0;
            obj.f1489f = 0;
            obj.f1490g = false;
            obj.f1491h = false;
            this.f1267t = obj;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f1247a;
        if (actionMenuView.f1057p == null) {
            m.o oVar = (m.o) actionMenuView.getMenu();
            if (this.M == null) {
                this.M = new u3(this);
            }
            this.f1247a.setExpandedActionViewsExclusive(true);
            oVar.b(this.M, this.f1256j);
            x();
        }
    }

    public final void f() {
        if (this.f1247a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f1247a = actionMenuView;
            actionMenuView.setPopupTheme(this.f1257k);
            this.f1247a.setOnMenuItemClickListener(this.J);
            ActionMenuView actionMenuView2 = this.f1247a;
            b0 b0Var = this.N;
            b bVar = new b(3, this);
            actionMenuView2.f1062u = b0Var;
            actionMenuView2.f1063v = bVar;
            v3 h10 = h();
            h10.f19252a = (this.f1260n & 112) | 8388613;
            this.f1247a.setLayoutParams(h10);
            b(this.f1247a, false);
        }
    }

    public final void g() {
        if (this.f1250d == null) {
            this.f1250d = new AppCompatImageButton(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            v3 h10 = h();
            h10.f19252a = (this.f1260n & 112) | 8388611;
            this.f1250d.setLayoutParams(h10);
        }
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.view.ViewGroup$LayoutParams, android.view.ViewGroup$MarginLayoutParams, androidx.appcompat.widget.v3, h.a] */
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ? marginLayoutParams = new ViewGroup.MarginLayoutParams(context, attributeSet);
        marginLayoutParams.f19252a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, g.a.f18920b);
        marginLayoutParams.f19252a = obtainStyledAttributes.getInt(0, 0);
        obtainStyledAttributes.recycle();
        marginLayoutParams.f1526b = 0;
        return marginLayoutParams;
    }

    public CharSequence getCollapseContentDescription() {
        AppCompatImageButton appCompatImageButton = this.f1254h;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        AppCompatImageButton appCompatImageButton = this.f1254h;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        r2 r2Var = this.f1267t;
        if (r2Var == null) {
            return 0;
        }
        if (r2Var.f1490g) {
            return r2Var.f1484a;
        }
        return r2Var.f1485b;
    }

    public int getContentInsetEndWithActions() {
        int i10 = this.f1269v;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        r2 r2Var = this.f1267t;
        if (r2Var != null) {
            return r2Var.f1484a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        r2 r2Var = this.f1267t;
        if (r2Var != null) {
            return r2Var.f1485b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        r2 r2Var = this.f1267t;
        if (r2Var == null) {
            return 0;
        }
        if (r2Var.f1490g) {
            return r2Var.f1485b;
        }
        return r2Var.f1484a;
    }

    public int getContentInsetStartWithNavigation() {
        int i10 = this.f1268u;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        m.o oVar;
        ActionMenuView actionMenuView = this.f1247a;
        if (actionMenuView == null || (oVar = actionMenuView.f1057p) == null || !oVar.hasVisibleItems()) {
            return getContentInsetEnd();
        }
        return Math.max(getContentInsetEnd(), Math.max(this.f1269v, 0));
    }

    public int getCurrentContentInsetLeft() {
        WeakHashMap weakHashMap = h1.f25195a;
        if (q0.d(this) == 1) {
            return getCurrentContentInsetEnd();
        }
        return getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        WeakHashMap weakHashMap = h1.f25195a;
        if (q0.d(this) == 1) {
            return getCurrentContentInsetStart();
        }
        return getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1268u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        AppCompatImageView appCompatImageView = this.f1251e;
        if (appCompatImageView != null) {
            return appCompatImageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        AppCompatImageView appCompatImageView = this.f1251e;
        if (appCompatImageView != null) {
            return appCompatImageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f1247a.getMenu();
    }

    public View getNavButtonView() {
        return this.f1250d;
    }

    public CharSequence getNavigationContentDescription() {
        AppCompatImageButton appCompatImageButton = this.f1250d;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        AppCompatImageButton appCompatImageButton = this.f1250d;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getDrawable();
        }
        return null;
    }

    public n getOuterActionMenuPresenter() {
        return this.L;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f1247a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f1256j;
    }

    public int getPopupTheme() {
        return this.f1257k;
    }

    public CharSequence getSubtitle() {
        return this.f1272y;
    }

    public final TextView getSubtitleTextView() {
        return this.f1249c;
    }

    public CharSequence getTitle() {
        return this.f1271x;
    }

    public int getTitleMarginBottom() {
        return this.f1266s;
    }

    public int getTitleMarginEnd() {
        return this.f1264q;
    }

    public int getTitleMarginStart() {
        return this.f1262p;
    }

    public int getTitleMarginTop() {
        return this.f1265r;
    }

    public final TextView getTitleTextView() {
        return this.f1248b;
    }

    public l1 getWrapper() {
        if (this.K == null) {
            this.K = new y3(this, true);
        }
        return this.K;
    }

    public final int j(int i10) {
        WeakHashMap weakHashMap = h1.f25195a;
        int d10 = q0.d(this);
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, d10) & 7;
        if (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) {
            return absoluteGravity;
        }
        if (d10 == 1) {
            return 5;
        }
        return 3;
    }

    public final int k(View view, int i10) {
        int i11;
        v3 v3Var = (v3) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        if (i10 > 0) {
            i11 = (measuredHeight - i10) / 2;
        } else {
            i11 = 0;
        }
        int i12 = v3Var.f19252a & 112;
        if (!(i12 == 16 || i12 == 48 || i12 == 80)) {
            i12 = this.f1270w & 112;
        }
        if (i12 == 48) {
            return getPaddingTop() - i11;
        }
        if (i12 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - v3Var.bottomMargin) - i11;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i13 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i14 = v3Var.topMargin;
        if (i13 < i14) {
            i13 = i14;
        } else {
            int i15 = (((height - paddingBottom) - measuredHeight) - i13) - paddingTop;
            int i16 = v3Var.bottomMargin;
            if (i15 < i16) {
                i13 = Math.max(0, i13 - (i16 - i15));
            }
        }
        return paddingTop + i13;
    }

    public void n(int i10) {
        getMenuInflater().inflate(i10, getMenu());
    }

    public final void o() {
        Iterator it = this.H.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(((MenuItem) it.next()).getItemId());
        }
        Menu menu = getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        MenuInflater menuInflater = getMenuInflater();
        Iterator it2 = this.G.f25274b.iterator();
        while (it2.hasNext()) {
            ((o0) ((v) it2.next())).f2295a.j(menu, menuInflater);
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.H = currentMenuItems2;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        x();
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Z0);
        x();
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.C = false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:107:0x0289 A[LOOP:0: B:106:0x0287->B:107:0x0289, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x02a5 A[LOOP:1: B:109:0x02a3->B:110:0x02a5, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x02c4 A[LOOP:2: B:112:0x02c2->B:113:0x02c4, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x0305  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x0312 A[LOOP:3: B:120:0x0310->B:121:0x0312, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0060  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0075  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00c5  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00f7  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00fc  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0114  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0126  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x012a  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x012d  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x015e  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0196  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01a5  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x0213  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            r19 = this;
            r0 = r19
            java.util.WeakHashMap r1 = r1.h1.f25195a
            int r1 = r1.q0.d(r19)
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000e
            r1 = 1
            goto L_0x000f
        L_0x000e:
            r1 = 0
        L_0x000f:
            int r4 = r19.getWidth()
            int r5 = r19.getHeight()
            int r6 = r19.getPaddingLeft()
            int r7 = r19.getPaddingRight()
            int r8 = r19.getPaddingTop()
            int r9 = r19.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.F
            r11[r2] = r3
            r11[r3] = r3
            int r12 = r1.p0.d(r19)
            if (r12 < 0) goto L_0x003c
            int r13 = r24 - r22
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003d
        L_0x003c:
            r12 = 0
        L_0x003d:
            androidx.appcompat.widget.AppCompatImageButton r13 = r0.f1250d
            boolean r13 = r0.v(r13)
            if (r13 == 0) goto L_0x0056
            androidx.appcompat.widget.AppCompatImageButton r13 = r0.f1250d
            if (r1 == 0) goto L_0x0050
            int r13 = r0.s(r13, r10, r12, r11)
            r14 = r13
            r13 = r6
            goto L_0x0058
        L_0x0050:
            int r13 = r0.r(r13, r6, r12, r11)
        L_0x0054:
            r14 = r10
            goto L_0x0058
        L_0x0056:
            r13 = r6
            goto L_0x0054
        L_0x0058:
            androidx.appcompat.widget.AppCompatImageButton r15 = r0.f1254h
            boolean r15 = r0.v(r15)
            if (r15 == 0) goto L_0x006d
            androidx.appcompat.widget.AppCompatImageButton r15 = r0.f1254h
            if (r1 == 0) goto L_0x0069
            int r14 = r0.s(r15, r14, r12, r11)
            goto L_0x006d
        L_0x0069:
            int r13 = r0.r(r15, r13, r12, r11)
        L_0x006d:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1247a
            boolean r15 = r0.v(r15)
            if (r15 == 0) goto L_0x0082
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1247a
            if (r1 == 0) goto L_0x007e
            int r13 = r0.r(r15, r13, r12, r11)
            goto L_0x0082
        L_0x007e:
            int r14 = r0.s(r15, r14, r12, r11)
        L_0x0082:
            int r15 = r19.getCurrentContentInsetLeft()
            int r16 = r19.getCurrentContentInsetRight()
            int r2 = r15 - r13
            int r2 = java.lang.Math.max(r3, r2)
            r11[r3] = r2
            int r2 = r10 - r14
            int r2 = r16 - r2
            int r2 = java.lang.Math.max(r3, r2)
            r17 = 1
            r11[r17] = r2
            int r2 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.f1255i
            boolean r13 = r0.v(r13)
            if (r13 == 0) goto L_0x00bd
            android.view.View r13 = r0.f1255i
            if (r1 == 0) goto L_0x00b9
            int r10 = r0.s(r13, r10, r12, r11)
            goto L_0x00bd
        L_0x00b9:
            int r2 = r0.r(r13, r2, r12, r11)
        L_0x00bd:
            androidx.appcompat.widget.AppCompatImageView r13 = r0.f1251e
            boolean r13 = r0.v(r13)
            if (r13 == 0) goto L_0x00d2
            androidx.appcompat.widget.AppCompatImageView r13 = r0.f1251e
            if (r1 == 0) goto L_0x00ce
            int r10 = r0.s(r13, r10, r12, r11)
            goto L_0x00d2
        L_0x00ce:
            int r2 = r0.r(r13, r2, r12, r11)
        L_0x00d2:
            androidx.appcompat.widget.AppCompatTextView r13 = r0.f1248b
            boolean r13 = r0.v(r13)
            androidx.appcompat.widget.AppCompatTextView r14 = r0.f1249c
            boolean r14 = r0.v(r14)
            if (r13 == 0) goto L_0x00f7
            androidx.appcompat.widget.AppCompatTextView r15 = r0.f1248b
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            androidx.appcompat.widget.v3 r15 = (androidx.appcompat.widget.v3) r15
            int r3 = r15.topMargin
            r23 = r7
            androidx.appcompat.widget.AppCompatTextView r7 = r0.f1248b
            int r7 = r7.getMeasuredHeight()
            int r7 = r7 + r3
            int r3 = r15.bottomMargin
            int r3 = r3 + r7
            goto L_0x00fa
        L_0x00f7:
            r23 = r7
            r3 = 0
        L_0x00fa:
            if (r14 == 0) goto L_0x0114
            androidx.appcompat.widget.AppCompatTextView r7 = r0.f1249c
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.appcompat.widget.v3 r7 = (androidx.appcompat.widget.v3) r7
            int r15 = r7.topMargin
            r16 = r4
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1249c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r15
            int r7 = r7.bottomMargin
            int r4 = r4 + r7
            int r3 = r3 + r4
            goto L_0x0116
        L_0x0114:
            r16 = r4
        L_0x0116:
            if (r13 != 0) goto L_0x0121
            if (r14 == 0) goto L_0x011b
            goto L_0x0121
        L_0x011b:
            r18 = r6
            r22 = r12
            goto L_0x027b
        L_0x0121:
            if (r13 == 0) goto L_0x0126
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1248b
            goto L_0x0128
        L_0x0126:
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1249c
        L_0x0128:
            if (r14 == 0) goto L_0x012d
            androidx.appcompat.widget.AppCompatTextView r7 = r0.f1249c
            goto L_0x012f
        L_0x012d:
            androidx.appcompat.widget.AppCompatTextView r7 = r0.f1248b
        L_0x012f:
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.v3 r4 = (androidx.appcompat.widget.v3) r4
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.appcompat.widget.v3 r7 = (androidx.appcompat.widget.v3) r7
            if (r13 == 0) goto L_0x0145
            androidx.appcompat.widget.AppCompatTextView r15 = r0.f1248b
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x014f
        L_0x0145:
            if (r14 == 0) goto L_0x0152
            androidx.appcompat.widget.AppCompatTextView r15 = r0.f1249c
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x0152
        L_0x014f:
            r17 = 1
            goto L_0x0154
        L_0x0152:
            r17 = 0
        L_0x0154:
            int r15 = r0.f1270w
            r15 = r15 & 112(0x70, float:1.57E-43)
            r18 = r6
            r6 = 48
            if (r15 == r6) goto L_0x0196
            r6 = 80
            if (r15 == r6) goto L_0x018a
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r3
            int r6 = r6 / 2
            int r15 = r4.topMargin
            r22 = r12
            int r12 = r0.f1265r
            int r15 = r15 + r12
            if (r6 >= r15) goto L_0x0173
            r6 = r15
            goto L_0x0188
        L_0x0173:
            int r5 = r5 - r9
            int r5 = r5 - r3
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r3 = r4.bottomMargin
            int r4 = r0.f1266s
            int r3 = r3 + r4
            if (r5 >= r3) goto L_0x0188
            int r3 = r7.bottomMargin
            int r3 = r3 + r4
            int r3 = r3 - r5
            int r6 = r6 - r3
            r3 = 0
            int r6 = java.lang.Math.max(r3, r6)
        L_0x0188:
            int r8 = r8 + r6
            goto L_0x01a3
        L_0x018a:
            r22 = r12
            int r5 = r5 - r9
            int r4 = r7.bottomMargin
            int r5 = r5 - r4
            int r4 = r0.f1266s
            int r5 = r5 - r4
            int r8 = r5 - r3
            goto L_0x01a3
        L_0x0196:
            r22 = r12
            int r3 = r19.getPaddingTop()
            int r4 = r4.topMargin
            int r3 = r3 + r4
            int r4 = r0.f1265r
            int r8 = r3 + r4
        L_0x01a3:
            if (r1 == 0) goto L_0x0213
            if (r17 == 0) goto L_0x01ab
            int r1 = r0.f1262p
        L_0x01a9:
            r3 = 1
            goto L_0x01ad
        L_0x01ab:
            r1 = 0
            goto L_0x01a9
        L_0x01ad:
            r4 = r11[r3]
            int r1 = r1 - r4
            r4 = 0
            int r5 = java.lang.Math.max(r4, r1)
            int r10 = r10 - r5
            int r1 = -r1
            int r1 = java.lang.Math.max(r4, r1)
            r11[r3] = r1
            if (r13 == 0) goto L_0x01e3
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1248b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.v3 r1 = (androidx.appcompat.widget.v3) r1
            androidx.appcompat.widget.AppCompatTextView r3 = r0.f1248b
            int r3 = r3.getMeasuredWidth()
            int r3 = r10 - r3
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1248b
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            androidx.appcompat.widget.AppCompatTextView r5 = r0.f1248b
            r5.layout(r3, r8, r10, r4)
            int r5 = r0.f1264q
            int r3 = r3 - r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x01e4
        L_0x01e3:
            r3 = r10
        L_0x01e4:
            if (r14 == 0) goto L_0x020a
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1249c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.v3 r1 = (androidx.appcompat.widget.v3) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1249c
            int r1 = r1.getMeasuredWidth()
            int r1 = r10 - r1
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1249c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            androidx.appcompat.widget.AppCompatTextView r5 = r0.f1249c
            r5.layout(r1, r8, r10, r4)
            int r1 = r0.f1264q
            int r1 = r10 - r1
            goto L_0x020b
        L_0x020a:
            r1 = r10
        L_0x020b:
            if (r17 == 0) goto L_0x027b
            int r1 = java.lang.Math.min(r3, r1)
            r10 = r1
            goto L_0x027b
        L_0x0213:
            if (r17 == 0) goto L_0x0219
            int r1 = r0.f1262p
        L_0x0217:
            r3 = 0
            goto L_0x021b
        L_0x0219:
            r1 = 0
            goto L_0x0217
        L_0x021b:
            r4 = r11[r3]
            int r1 = r1 - r4
            int r4 = java.lang.Math.max(r3, r1)
            int r2 = r2 + r4
            int r1 = -r1
            int r1 = java.lang.Math.max(r3, r1)
            r11[r3] = r1
            if (r13 == 0) goto L_0x024f
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1248b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.v3 r1 = (androidx.appcompat.widget.v3) r1
            androidx.appcompat.widget.AppCompatTextView r3 = r0.f1248b
            int r3 = r3.getMeasuredWidth()
            int r3 = r3 + r2
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1248b
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            androidx.appcompat.widget.AppCompatTextView r5 = r0.f1248b
            r5.layout(r2, r8, r3, r4)
            int r5 = r0.f1264q
            int r3 = r3 + r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x0250
        L_0x024f:
            r3 = r2
        L_0x0250:
            if (r14 == 0) goto L_0x0274
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1249c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.v3 r1 = (androidx.appcompat.widget.v3) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            androidx.appcompat.widget.AppCompatTextView r1 = r0.f1249c
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r2
            androidx.appcompat.widget.AppCompatTextView r4 = r0.f1249c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            androidx.appcompat.widget.AppCompatTextView r5 = r0.f1249c
            r5.layout(r2, r8, r1, r4)
            int r4 = r0.f1264q
            int r1 = r1 + r4
            goto L_0x0275
        L_0x0274:
            r1 = r2
        L_0x0275:
            if (r17 == 0) goto L_0x027b
            int r2 = java.lang.Math.max(r3, r1)
        L_0x027b:
            java.util.ArrayList r1 = r0.D
            r3 = 3
            r0.a(r3, r1)
            int r3 = r1.size()
            r4 = r2
            r2 = 0
        L_0x0287:
            if (r2 >= r3) goto L_0x0298
            java.lang.Object r5 = r1.get(r2)
            android.view.View r5 = (android.view.View) r5
            r12 = r22
            int r4 = r0.r(r5, r4, r12, r11)
            int r2 = r2 + 1
            goto L_0x0287
        L_0x0298:
            r12 = r22
            r2 = 5
            r0.a(r2, r1)
            int r2 = r1.size()
            r3 = 0
        L_0x02a3:
            if (r3 >= r2) goto L_0x02b2
            java.lang.Object r5 = r1.get(r3)
            android.view.View r5 = (android.view.View) r5
            int r10 = r0.s(r5, r10, r12, r11)
            int r3 = r3 + 1
            goto L_0x02a3
        L_0x02b2:
            r3 = 1
            r0.a(r3, r1)
            r2 = 0
            r5 = r11[r2]
            r2 = r11[r3]
            int r3 = r1.size()
            r7 = r5
            r5 = 0
            r6 = 0
        L_0x02c2:
            if (r5 >= r3) goto L_0x02f5
            java.lang.Object r8 = r1.get(r5)
            android.view.View r8 = (android.view.View) r8
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.appcompat.widget.v3 r9 = (androidx.appcompat.widget.v3) r9
            int r13 = r9.leftMargin
            int r13 = r13 - r7
            int r7 = r9.rightMargin
            int r7 = r7 - r2
            r2 = 0
            int r9 = java.lang.Math.max(r2, r13)
            int r14 = java.lang.Math.max(r2, r7)
            int r13 = -r13
            int r13 = java.lang.Math.max(r2, r13)
            int r7 = -r7
            int r7 = java.lang.Math.max(r2, r7)
            int r8 = r8.getMeasuredWidth()
            int r8 = r8 + r9
            int r8 = r8 + r14
            int r6 = r6 + r8
            int r5 = r5 + 1
            r2 = r7
            r7 = r13
            goto L_0x02c2
        L_0x02f5:
            r2 = 0
            int r3 = r16 - r18
            int r3 = r3 - r23
            int r3 = r3 / 2
            int r3 = r3 + r18
            int r5 = r6 / 2
            int r3 = r3 - r5
            int r6 = r6 + r3
            if (r3 >= r4) goto L_0x0305
            goto L_0x030c
        L_0x0305:
            if (r6 <= r10) goto L_0x030b
            int r6 = r6 - r10
            int r4 = r3 - r6
            goto L_0x030c
        L_0x030b:
            r4 = r3
        L_0x030c:
            int r3 = r1.size()
        L_0x0310:
            if (r2 >= r3) goto L_0x031f
            java.lang.Object r5 = r1.get(r2)
            android.view.View r5 = (android.view.View) r5
            int r4 = r0.r(r5, r4, r12, r11)
            int r2 = r2 + 1
            goto L_0x0310
        L_0x031f:
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        char a10 = f4.a(this);
        char c10 = a10 ^ 1;
        int i19 = 0;
        if (v(this.f1250d)) {
            u(this.f1250d, i10, 0, i11, this.f1261o);
            i14 = l(this.f1250d) + this.f1250d.getMeasuredWidth();
            i13 = Math.max(0, m(this.f1250d) + this.f1250d.getMeasuredHeight());
            i12 = View.combineMeasuredStates(0, this.f1250d.getMeasuredState());
        } else {
            i14 = 0;
            i13 = 0;
            i12 = 0;
        }
        if (v(this.f1254h)) {
            u(this.f1254h, i10, 0, i11, this.f1261o);
            i14 = l(this.f1254h) + this.f1254h.getMeasuredWidth();
            i13 = Math.max(i13, m(this.f1254h) + this.f1254h.getMeasuredHeight());
            i12 = View.combineMeasuredStates(i12, this.f1254h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i14);
        int max2 = Math.max(0, currentContentInsetStart - i14);
        int[] iArr = this.F;
        iArr[a10] = max2;
        if (v(this.f1247a)) {
            u(this.f1247a, i10, max, i11, this.f1261o);
            i15 = l(this.f1247a) + this.f1247a.getMeasuredWidth();
            i13 = Math.max(i13, m(this.f1247a) + this.f1247a.getMeasuredHeight());
            i12 = View.combineMeasuredStates(i12, this.f1247a.getMeasuredState());
        } else {
            i15 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max3 = Math.max(currentContentInsetEnd, i15) + max;
        iArr[c10] = Math.max(0, currentContentInsetEnd - i15);
        if (v(this.f1255i)) {
            max3 += t(this.f1255i, i10, max3, i11, 0, iArr);
            i13 = Math.max(i13, m(this.f1255i) + this.f1255i.getMeasuredHeight());
            i12 = View.combineMeasuredStates(i12, this.f1255i.getMeasuredState());
        }
        if (v(this.f1251e)) {
            max3 += t(this.f1251e, i10, max3, i11, 0, iArr);
            i13 = Math.max(i13, m(this.f1251e) + this.f1251e.getMeasuredHeight());
            i12 = View.combineMeasuredStates(i12, this.f1251e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt = getChildAt(i20);
            if (((v3) childAt.getLayoutParams()).f1526b == 0 && v(childAt)) {
                max3 += t(childAt, i10, max3, i11, 0, iArr);
                i13 = Math.max(i13, m(childAt) + childAt.getMeasuredHeight());
                i12 = View.combineMeasuredStates(i12, childAt.getMeasuredState());
            }
        }
        int i21 = this.f1265r + this.f1266s;
        int i22 = this.f1262p + this.f1264q;
        if (v(this.f1248b)) {
            t(this.f1248b, i10, max3 + i22, i11, i21, iArr);
            int l10 = l(this.f1248b) + this.f1248b.getMeasuredWidth();
            i16 = m(this.f1248b) + this.f1248b.getMeasuredHeight();
            i18 = View.combineMeasuredStates(i12, this.f1248b.getMeasuredState());
            i17 = l10;
        } else {
            i18 = i12;
            i17 = 0;
            i16 = 0;
        }
        if (v(this.f1249c)) {
            int i23 = i16 + i21;
            i17 = Math.max(i17, t(this.f1249c, i10, max3 + i22, i11, i23, iArr));
            i16 += m(this.f1249c) + this.f1249c.getMeasuredHeight();
            i18 = View.combineMeasuredStates(i18, this.f1249c.getMeasuredState());
        } else {
            int i24 = i18;
        }
        int max4 = Math.max(i13, i16);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max4;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max3 + i17, getSuggestedMinimumWidth()), i10, -16777216 & i18);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i11, i18 << 16);
        if (this.f1263p0) {
            int childCount2 = getChildCount();
            int i25 = 0;
            while (true) {
                if (i25 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i25);
                if (v(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i25++;
            }
        }
        i19 = resolveSizeAndState2;
        setMeasuredDimension(resolveSizeAndState, i19);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        m.o oVar;
        MenuItem findItem;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f1896a);
        ActionMenuView actionMenuView = this.f1247a;
        if (actionMenuView != null) {
            oVar = actionMenuView.f1057p;
        } else {
            oVar = null;
        }
        int i10 = savedState.f1274c;
        if (!(i10 == 0 || this.M == null || oVar == null || (findItem = oVar.findItem(i10)) == null)) {
            findItem.expandActionView();
        }
        if (savedState.f1275d) {
            y0 y0Var = this.Z0;
            removeCallbacks(y0Var);
            post(y0Var);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x002c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x003a, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x002c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onRtlPropertiesChanged(int r3) {
        /*
            r2 = this;
            super.onRtlPropertiesChanged(r3)
            r2.d()
            androidx.appcompat.widget.r2 r0 = r2.f1267t
            r1 = 1
            if (r3 != r1) goto L_0x000c
            goto L_0x000d
        L_0x000c:
            r1 = 0
        L_0x000d:
            boolean r3 = r0.f1490g
            if (r1 != r3) goto L_0x0012
            goto L_0x0045
        L_0x0012:
            r0.f1490g = r1
            boolean r3 = r0.f1491h
            if (r3 == 0) goto L_0x003d
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x002f
            int r1 = r0.f1487d
            if (r1 == r3) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            int r1 = r0.f1488e
        L_0x0023:
            r0.f1484a = r1
            int r1 = r0.f1486c
            if (r1 == r3) goto L_0x002a
            goto L_0x002c
        L_0x002a:
            int r1 = r0.f1489f
        L_0x002c:
            r0.f1485b = r1
            goto L_0x0045
        L_0x002f:
            int r1 = r0.f1486c
            if (r1 == r3) goto L_0x0034
            goto L_0x0036
        L_0x0034:
            int r1 = r0.f1488e
        L_0x0036:
            r0.f1484a = r1
            int r1 = r0.f1487d
            if (r1 == r3) goto L_0x002a
            goto L_0x002c
        L_0x003d:
            int r3 = r0.f1488e
            r0.f1484a = r3
            int r3 = r0.f1489f
            r0.f1485b = r3
        L_0x0045:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onRtlPropertiesChanged(int):void");
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.os.Parcelable, androidx.customview.view.AbsSavedState, androidx.appcompat.widget.Toolbar$SavedState] */
    public Parcelable onSaveInstanceState() {
        q qVar;
        ? absSavedState = new AbsSavedState(super.onSaveInstanceState());
        u3 u3Var = this.M;
        if (!(u3Var == null || (qVar = u3Var.f1522b) == null)) {
            absSavedState.f1274c = qVar.f22322a;
        }
        absSavedState.f1275d = q();
        return absSavedState;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.B = false;
        }
        return true;
    }

    public final boolean p(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    public final boolean q() {
        n nVar;
        ActionMenuView actionMenuView = this.f1247a;
        if (actionMenuView == null || (nVar = actionMenuView.f1061t) == null || !nVar.e()) {
            return false;
        }
        return true;
    }

    public final int r(View view, int i10, int i11, int[] iArr) {
        v3 v3Var = (v3) view.getLayoutParams();
        int i12 = v3Var.leftMargin - iArr[0];
        int max = Math.max(0, i12) + i10;
        iArr[0] = Math.max(0, -i12);
        int k10 = k(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, k10, max + measuredWidth, view.getMeasuredHeight() + k10);
        return measuredWidth + v3Var.rightMargin + max;
    }

    public final void removeMenuProvider(v vVar) {
        this.G.b(vVar);
    }

    public final int s(View view, int i10, int i11, int[] iArr) {
        v3 v3Var = (v3) view.getLayoutParams();
        int i12 = v3Var.rightMargin - iArr[1];
        int max = i10 - Math.max(0, i12);
        iArr[1] = Math.max(0, -i12);
        int k10 = k(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, k10, max, view.getMeasuredHeight() + k10);
        return max - (measuredWidth + v3Var.leftMargin);
    }

    public void setBackInvokedCallbackEnabled(boolean z4) {
        if (this.Y0 != z4) {
            this.Y0 = z4;
            x();
        }
    }

    public void setCollapseContentDescription(int i10) {
        setCollapseContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setCollapseIcon(int i10) {
        setCollapseIcon(y.e(getContext(), i10));
    }

    public void setCollapsible(boolean z4) {
        this.f1263p0 = z4;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f1269v) {
            this.f1269v = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f1268u) {
            this.f1268u = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i10) {
        setLogo(y.e(getContext(), i10));
    }

    public void setLogoDescription(int i10) {
        setLogoDescription(getContext().getText(i10));
    }

    public void setNavigationContentDescription(int i10) {
        setNavigationContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setNavigationIcon(int i10) {
        setNavigationIcon(y.e(getContext(), i10));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f1250d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(w3 w3Var) {
        this.I = w3Var;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f1247a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i10) {
        if (this.f1257k != i10) {
            this.f1257k = i10;
            if (i10 == 0) {
                this.f1256j = getContext();
            } else {
                this.f1256j = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setSubtitle(int i10) {
        setSubtitle(getContext().getText(i10));
    }

    public void setSubtitleTextColor(int i10) {
        setSubtitleTextColor(ColorStateList.valueOf(i10));
    }

    public void setTitle(int i10) {
        setTitle(getContext().getText(i10));
    }

    public void setTitleMarginBottom(int i10) {
        this.f1266s = i10;
        requestLayout();
    }

    public void setTitleMarginEnd(int i10) {
        this.f1264q = i10;
        requestLayout();
    }

    public void setTitleMarginStart(int i10) {
        this.f1262p = i10;
        requestLayout();
    }

    public void setTitleMarginTop(int i10) {
        this.f1265r = i10;
        requestLayout();
    }

    public void setTitleTextColor(int i10) {
        setTitleTextColor(ColorStateList.valueOf(i10));
    }

    public final int t(View view, int i10, int i11, int i12, int i13, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i14 = marginLayoutParams.leftMargin - iArr[0];
        int i15 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i15) + Math.max(0, i14);
        iArr[0] = Math.max(0, -i14);
        iArr[1] = Math.max(0, -i15);
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + max + i11, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i13, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final void u(View view, int i10, int i11, int i12, int i13) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i13 >= 0) {
            if (mode != 0) {
                i13 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i13);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean v(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final boolean w() {
        n nVar;
        ActionMenuView actionMenuView = this.f1247a;
        if (actionMenuView == null || (nVar = actionMenuView.f1061t) == null || !nVar.n()) {
            return false;
        }
        return true;
    }

    public final void x() {
        boolean z4;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher a10 = t3.a(this);
            u3 u3Var = this.M;
            boolean z10 = false;
            if (u3Var == null || u3Var.f1522b == null) {
                z4 = false;
            } else {
                z4 = true;
            }
            if (z4 && a10 != null) {
                WeakHashMap weakHashMap = h1.f25195a;
                if (s0.b(this) && this.Y0) {
                    z10 = true;
                }
            }
            if (z10 && this.X0 == null) {
                if (this.W0 == null) {
                    this.W0 = t3.b(new s3(this, 1));
                }
                t3.c(a10, this.W0);
            } else if (!z10 && (onBackInvokedDispatcher = this.X0) != null) {
                t3.d(onBackInvokedDispatcher, this.W0);
                a10 = null;
            } else {
                return;
            }
            this.X0 = a10;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1270w = 8388627;
        this.D = new ArrayList();
        this.E = new ArrayList();
        this.F = new int[2];
        this.G = new t(new s3(this, 0));
        this.H = new ArrayList();
        this.J = new c(3, this);
        this.Z0 = new y0(3, this);
        Context context2 = getContext();
        int[] iArr = g.a.A;
        w K2 = w.K(context2, attributeSet, iArr, i10);
        h1.q(this, context, iArr, attributeSet, (TypedArray) K2.f619c, i10);
        this.f1258l = K2.B(28, 0);
        this.f1259m = K2.B(19, 0);
        this.f1270w = ((TypedArray) K2.f619c).getInteger(0, 8388627);
        this.f1260n = ((TypedArray) K2.f619c).getInteger(2, 48);
        int u10 = K2.u(22, 0);
        u10 = K2.G(27) ? K2.u(27, u10) : u10;
        this.f1266s = u10;
        this.f1265r = u10;
        this.f1264q = u10;
        this.f1262p = u10;
        int u11 = K2.u(25, -1);
        if (u11 >= 0) {
            this.f1262p = u11;
        }
        int u12 = K2.u(24, -1);
        if (u12 >= 0) {
            this.f1264q = u12;
        }
        int u13 = K2.u(26, -1);
        if (u13 >= 0) {
            this.f1265r = u13;
        }
        int u14 = K2.u(23, -1);
        if (u14 >= 0) {
            this.f1266s = u14;
        }
        this.f1261o = K2.v(13, -1);
        int u15 = K2.u(9, Integer.MIN_VALUE);
        int u16 = K2.u(5, Integer.MIN_VALUE);
        int v10 = K2.v(7, 0);
        int v11 = K2.v(8, 0);
        d();
        r2 r2Var = this.f1267t;
        r2Var.f1491h = false;
        if (v10 != Integer.MIN_VALUE) {
            r2Var.f1488e = v10;
            r2Var.f1484a = v10;
        }
        if (v11 != Integer.MIN_VALUE) {
            r2Var.f1489f = v11;
            r2Var.f1485b = v11;
        }
        if (!(u15 == Integer.MIN_VALUE && u16 == Integer.MIN_VALUE)) {
            r2Var.a(u15, u16);
        }
        this.f1268u = K2.u(10, Integer.MIN_VALUE);
        this.f1269v = K2.u(6, Integer.MIN_VALUE);
        this.f1252f = K2.w(4);
        this.f1253g = K2.F(3);
        CharSequence F2 = K2.F(21);
        if (!TextUtils.isEmpty(F2)) {
            setTitle(F2);
        }
        CharSequence F3 = K2.F(18);
        if (!TextUtils.isEmpty(F3)) {
            setSubtitle(F3);
        }
        this.f1256j = getContext();
        setPopupTheme(K2.B(17, 0));
        Drawable w10 = K2.w(16);
        if (w10 != null) {
            setNavigationIcon(w10);
        }
        CharSequence F4 = K2.F(15);
        if (!TextUtils.isEmpty(F4)) {
            setNavigationContentDescription(F4);
        }
        Drawable w11 = K2.w(11);
        if (w11 != null) {
            setLogo(w11);
        }
        CharSequence F5 = K2.F(12);
        if (!TextUtils.isEmpty(F5)) {
            setLogoDescription(F5);
        }
        if (K2.G(29)) {
            setTitleTextColor(K2.t(29));
        }
        if (K2.G(20)) {
            setSubtitleTextColor(K2.t(20));
        }
        if (K2.G(14)) {
            n(K2.B(14, 0));
        }
        K2.N();
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        AppCompatImageButton appCompatImageButton = this.f1254h;
        if (appCompatImageButton != null) {
            appCompatImageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f1254h.setImageDrawable(drawable);
            return;
        }
        AppCompatImageButton appCompatImageButton = this.f1254h;
        if (appCompatImageButton != null) {
            appCompatImageButton.setImageDrawable(this.f1252f);
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f1251e == null) {
                this.f1251e = new AppCompatImageView(getContext(), (AttributeSet) null);
            }
            if (!p(this.f1251e)) {
                b(this.f1251e, true);
            }
        } else {
            AppCompatImageView appCompatImageView = this.f1251e;
            if (appCompatImageView != null && p(appCompatImageView)) {
                removeView(this.f1251e);
                this.E.remove(this.f1251e);
            }
        }
        AppCompatImageView appCompatImageView2 = this.f1251e;
        if (appCompatImageView2 != null) {
            appCompatImageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f1251e == null) {
            this.f1251e = new AppCompatImageView(getContext(), (AttributeSet) null);
        }
        AppCompatImageView appCompatImageView = this.f1251e;
        if (appCompatImageView != null) {
            appCompatImageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        AppCompatImageButton appCompatImageButton = this.f1250d;
        if (appCompatImageButton != null) {
            appCompatImageButton.setContentDescription(charSequence);
            g.j(this.f1250d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!p(this.f1250d)) {
                b(this.f1250d, true);
            }
        } else {
            AppCompatImageButton appCompatImageButton = this.f1250d;
            if (appCompatImageButton != null && p(appCompatImageButton)) {
                removeView(this.f1250d);
                this.E.remove(this.f1250d);
            }
        }
        AppCompatImageButton appCompatImageButton2 = this.f1250d;
        if (appCompatImageButton2 != null) {
            appCompatImageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1249c == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f1249c = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f1249c.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f1259m;
                if (i10 != 0) {
                    this.f1249c.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f1249c.setTextColor(colorStateList);
                }
            }
            if (!p(this.f1249c)) {
                b(this.f1249c, true);
            }
        } else {
            AppCompatTextView appCompatTextView2 = this.f1249c;
            if (appCompatTextView2 != null && p(appCompatTextView2)) {
                removeView(this.f1249c);
                this.E.remove(this.f1249c);
            }
        }
        AppCompatTextView appCompatTextView3 = this.f1249c;
        if (appCompatTextView3 != null) {
            appCompatTextView3.setText(charSequence);
        }
        this.f1272y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        AppCompatTextView appCompatTextView = this.f1249c;
        if (appCompatTextView != null) {
            appCompatTextView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1248b == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f1248b = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f1248b.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f1258l;
                if (i10 != 0) {
                    this.f1248b.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f1273z;
                if (colorStateList != null) {
                    this.f1248b.setTextColor(colorStateList);
                }
            }
            if (!p(this.f1248b)) {
                b(this.f1248b, true);
            }
        } else {
            AppCompatTextView appCompatTextView2 = this.f1248b;
            if (appCompatTextView2 != null && p(appCompatTextView2)) {
                removeView(this.f1248b);
                this.E.remove(this.f1248b);
            }
        }
        AppCompatTextView appCompatTextView3 = this.f1248b;
        if (appCompatTextView3 != null) {
            appCompatTextView3.setText(charSequence);
        }
        this.f1271x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f1273z = colorStateList;
        AppCompatTextView appCompatTextView = this.f1248b;
        if (appCompatTextView != null) {
            appCompatTextView.setTextColor(colorStateList);
        }
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }
}
