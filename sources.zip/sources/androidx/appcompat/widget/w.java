package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import m.o;
import r1.d;

public final class w implements AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener, PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ActivityChooserView f1527a;

    public w(ActivityChooserView activityChooserView) {
        this.f1527a = activityChooserView;
    }

    public final void onClick(View view) {
        ActivityChooserView activityChooserView = this.f1527a;
        FrameLayout frameLayout = activityChooserView.f1073f;
        v vVar = activityChooserView.f1068a;
        if (view == frameLayout) {
            activityChooserView.a();
            vVar.getClass();
            throw null;
        } else if (view == activityChooserView.f1071d) {
            vVar.getClass();
            throw new IllegalStateException("No data model. Did you call #setDataModel?");
        } else {
            throw new IllegalArgumentException();
        }
    }

    public final void onDismiss() {
        n nVar;
        o oVar;
        ActivityChooserView activityChooserView = this.f1527a;
        PopupWindow.OnDismissListener onDismissListener = activityChooserView.f1077j;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
        d dVar = activityChooserView.f1074g;
        if (dVar != null && (nVar = dVar.f25166a) != null && (oVar = nVar.f1420c) != null) {
            oVar.c(false);
        }
    }

    public final void onItemClick(AdapterView adapterView, View view, int i10, long j3) {
        ((v) adapterView.getAdapter()).getClass();
        ActivityChooserView activityChooserView = this.f1527a;
        activityChooserView.a();
        activityChooserView.f1068a.getClass();
        throw null;
    }

    public final boolean onLongClick(View view) {
        ActivityChooserView activityChooserView = this.f1527a;
        if (view == activityChooserView.f1073f) {
            activityChooserView.f1068a.getClass();
            throw null;
        }
        throw new IllegalArgumentException();
    }
}
