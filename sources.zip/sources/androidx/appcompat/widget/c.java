package androidx.appcompat.widget;

import android.view.View;
import android.view.Window;
import l.b;
import m.a;

public final class c implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1306a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final Object f1307b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f1308c;

    public c(ActionBarContextView actionBarContextView, b bVar) {
        this.f1308c = actionBarContextView;
        this.f1307b = bVar;
    }

    public final void onClick(View view) {
        int i10 = this.f1306a;
        Object obj = this.f1307b;
        switch (i10) {
            case 0:
                ((b) obj).a();
                return;
            default:
                y3 y3Var = (y3) this.f1308c;
                Window.Callback callback = y3Var.f1580k;
                if (callback != null && y3Var.f1581l) {
                    callback.onMenuItemSelected(0, (a) obj);
                    return;
                }
                return;
        }
    }

    public c(y3 y3Var) {
        this.f1308c = y3Var;
        this.f1307b = new a(y3Var.f1570a.getContext(), y3Var.f1577h);
    }
}
