package androidx.appcompat.widget;

import android.view.View;

public abstract class z3 {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
