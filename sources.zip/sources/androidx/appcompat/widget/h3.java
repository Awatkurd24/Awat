package androidx.appcompat.widget;

import android.view.inputmethod.InputMethodManager;
import androidx.appcompat.widget.SearchView;

public final class h3 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SearchView.SearchAutoComplete f1348a;

    public h3(SearchView.SearchAutoComplete searchAutoComplete) {
        this.f1348a = searchAutoComplete;
    }

    public final void run() {
        SearchView.SearchAutoComplete searchAutoComplete = this.f1348a;
        if (searchAutoComplete.f1218g) {
            ((InputMethodManager) searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchAutoComplete, 0);
            searchAutoComplete.f1218g = false;
        }
    }
}
