package androidx.appcompat.widget;

import m.c;

public final class i extends c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ n f1349a;

    public i(n nVar) {
        this.f1349a = nVar;
    }
}
