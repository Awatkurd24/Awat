package androidx.appcompat.widget;

import android.media.MediaCodecInfo;

public abstract /* synthetic */ class f1 {
    public static /* synthetic */ MediaCodecInfo.VideoCapabilities.PerformancePoint e(int i10, int i11, int i12) {
        return new MediaCodecInfo.VideoCapabilities.PerformancePoint(i10, i11, i12);
    }

    public static /* bridge */ /* synthetic */ MediaCodecInfo.VideoCapabilities.PerformancePoint f(Object obj) {
        return (MediaCodecInfo.VideoCapabilities.PerformancePoint) obj;
    }
}
