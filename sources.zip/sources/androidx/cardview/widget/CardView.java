package androidx.cardview.widget;

import a2.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import co.vpn.plusvpn.R;
import wb.a;

public class CardView extends FrameLayout {

    /* renamed from: f  reason: collision with root package name */
    public static final int[] f1606f = {16842801};

    /* renamed from: g  reason: collision with root package name */
    public static final h f1607g = new Object();

    /* renamed from: a  reason: collision with root package name */
    public boolean f1608a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f1609b;

    /* renamed from: c  reason: collision with root package name */
    public final Rect f1610c;

    /* renamed from: d  reason: collision with root package name */
    public final Rect f1611d;

    /* renamed from: e  reason: collision with root package name */
    public final a f1612e;

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.cardViewStyle);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((r0.a) ((Drawable) this.f1612e.f29275b)).f25149h;
    }

    public float getCardElevation() {
        return ((CardView) this.f1612e.f29276c).getElevation();
    }

    public int getContentPaddingBottom() {
        return this.f1610c.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f1610c.left;
    }

    public int getContentPaddingRight() {
        return this.f1610c.right;
    }

    public int getContentPaddingTop() {
        return this.f1610c.top;
    }

    public float getMaxCardElevation() {
        return ((r0.a) ((Drawable) this.f1612e.f29275b)).f25146e;
    }

    public boolean getPreventCornerOverlap() {
        return this.f1609b;
    }

    public float getRadius() {
        return ((r0.a) ((Drawable) this.f1612e.f29275b)).f25142a;
    }

    public boolean getUseCompatPadding() {
        return this.f1608a;
    }

    public void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
    }

    public void setCardBackgroundColor(int i10) {
        a aVar = this.f1612e;
        ColorStateList valueOf = ColorStateList.valueOf(i10);
        r0.a aVar2 = (r0.a) ((Drawable) aVar.f29275b);
        if (valueOf == null) {
            aVar2.getClass();
            valueOf = ColorStateList.valueOf(0);
        }
        aVar2.f25149h = valueOf;
        aVar2.f25143b.setColor(valueOf.getColorForState(aVar2.getState(), aVar2.f25149h.getDefaultColor()));
        aVar2.invalidateSelf();
    }

    public void setCardElevation(float f10) {
        ((CardView) this.f1612e.f29276c).setElevation(f10);
    }

    public void setMaxCardElevation(float f10) {
        f1607g.f(f10, this.f1612e);
    }

    public void setMinimumHeight(int i10) {
        super.setMinimumHeight(i10);
    }

    public void setMinimumWidth(int i10) {
        super.setMinimumWidth(i10);
    }

    public final void setPadding(int i10, int i11, int i12, int i13) {
    }

    public final void setPaddingRelative(int i10, int i11, int i12, int i13) {
    }

    public void setPreventCornerOverlap(boolean z4) {
        if (z4 != this.f1609b) {
            this.f1609b = z4;
            h hVar = f1607g;
            a aVar = this.f1612e;
            hVar.f(((r0.a) ((Drawable) aVar.f29275b)).f25146e, aVar);
        }
    }

    public void setRadius(float f10) {
        r0.a aVar = (r0.a) ((Drawable) this.f1612e.f29275b);
        if (f10 != aVar.f25142a) {
            aVar.f25142a = f10;
            aVar.b((Rect) null);
            aVar.invalidateSelf();
        }
    }

    public void setUseCompatPadding(boolean z4) {
        if (this.f1608a != z4) {
            this.f1608a = z4;
            h hVar = f1607g;
            a aVar = this.f1612e;
            hVar.f(((r0.a) ((Drawable) aVar.f29275b)).f25146e, aVar);
        }
    }

    public CardView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        ColorStateList colorStateList;
        Resources resources;
        int i11;
        Rect rect = new Rect();
        this.f1610c = rect;
        this.f1611d = new Rect();
        a aVar = new a(this);
        this.f1612e = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, q0.a.f24806a, i10, R.style.CardView);
        if (obtainStyledAttributes.hasValue(2)) {
            colorStateList = obtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f1606f);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i11 = R.color.cardview_light_background;
            } else {
                resources = getResources();
                i11 = R.color.cardview_dark_background;
            }
            colorStateList = ColorStateList.valueOf(resources.getColor(i11));
        }
        float dimension = obtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(5, 0.0f);
        this.f1608a = obtainStyledAttributes.getBoolean(7, false);
        this.f1609b = obtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        h hVar = f1607g;
        r0.a aVar2 = new r0.a(dimension, colorStateList);
        aVar.f29275b = aVar2;
        ((CardView) aVar.f29276c).setBackgroundDrawable(aVar2);
        CardView cardView = (CardView) aVar.f29276c;
        cardView.setClipToOutline(true);
        cardView.setElevation(dimension2);
        hVar.f(dimension3, aVar);
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        r0.a aVar = (r0.a) ((Drawable) this.f1612e.f29275b);
        if (colorStateList == null) {
            aVar.getClass();
            colorStateList = ColorStateList.valueOf(0);
        }
        aVar.f25149h = colorStateList;
        aVar.f25143b.setColor(colorStateList.getColorForState(aVar.getState(), aVar.f25149h.getDefaultColor()));
        aVar.invalidateSelf();
    }
}
