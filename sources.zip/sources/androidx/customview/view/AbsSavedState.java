package androidx.customview.view;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import y1.a;

@SuppressLint({"BanParcelableUsage"})
public abstract class AbsSavedState implements Parcelable {
    public static final Parcelable.Creator<AbsSavedState> CREATOR = new a(0);

    /* renamed from: b  reason: collision with root package name */
    public static final AbsSavedState f1895b = new AbsSavedState();

    /* renamed from: a  reason: collision with root package name */
    public final Parcelable f1896a;

    /* renamed from: androidx.customview.view.AbsSavedState$1  reason: invalid class name */
    public class AnonymousClass1 extends AbsSavedState {
    }

    public AbsSavedState() {
        this.f1896a = null;
    }

    public final int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeParcelable(this.f1896a, i10);
    }

    public AbsSavedState(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f1896a = readParcelable == null ? f1895b : readParcelable;
    }

    public AbsSavedState(Parcelable parcelable) {
        if (parcelable != null) {
            this.f1896a = parcelable == f1895b ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }
}
