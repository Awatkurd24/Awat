package androidx.constraintlayout.motion.widget;

import a1.u;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import c1.p;
import java.util.HashMap;

public class MotionHelper extends ConstraintHelper implements u {

    /* renamed from: i  reason: collision with root package name */
    public boolean f1665i = false;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1666j = false;

    /* renamed from: k  reason: collision with root package name */
    public float f1667k;

    /* renamed from: l  reason: collision with root package name */
    public View[] f1668l;

    public MotionHelper(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        l(attributeSet);
    }

    public void a(int i10) {
    }

    public void b() {
    }

    public float getProgress() {
        return this.f1667k;
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3916p);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 1) {
                    this.f1665i = obtainStyledAttributes.getBoolean(index, this.f1665i);
                } else if (index == 0) {
                    this.f1666j = obtainStyledAttributes.getBoolean(index, this.f1666j);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void s(MotionLayout motionLayout, HashMap hashMap) {
    }

    public void setProgress(float f10) {
        this.f1667k = f10;
        int i10 = 0;
        if (this.f1790b > 0) {
            this.f1668l = k((ConstraintLayout) getParent());
            while (i10 < this.f1790b) {
                View view = this.f1668l[i10];
                i10++;
            }
            return;
        }
        ViewGroup viewGroup = (ViewGroup) getParent();
        int childCount = viewGroup.getChildCount();
        while (i10 < childCount) {
            boolean z4 = viewGroup.getChildAt(i10) instanceof MotionHelper;
            i10++;
        }
    }
}
