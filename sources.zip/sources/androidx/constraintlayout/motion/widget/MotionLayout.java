package androidx.constraintlayout.motion.widget;

import a1.a;
import a1.a0;
import a1.n;
import a1.o;
import a1.p;
import a1.q;
import a1.r;
import a1.t;
import a1.u;
import a1.v;
import a1.x;
import a1.y;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.View;
import android.view.animation.Interpolator;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import c1.d;
import c1.l;
import com.google.android.gms.internal.ads.nl;
import f.c;
import h.n0;
import h.y0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import r1.z;
import v7.ke;
import w0.e;
import w0.f;
import yg.b0;

public class MotionLayout extends ConstraintLayout implements z {
    public static boolean K1;
    public int A;
    public Runnable A1;
    public boolean B;
    public final Rect B1;
    public final HashMap C;
    public boolean C1;
    public long D;
    public v D1;
    public float E;
    public final r E1;
    public float F;
    public boolean F1;
    public float G;
    public final RectF G1;
    public long H;
    public View H1;
    public float I;
    public Matrix I1;
    public boolean J;
    public final ArrayList J1;
    public boolean K;
    public u L;
    public int M;
    public q N;
    public boolean O;
    public final p W0;
    public a X0;
    public int Y0;
    public int Z0;

    /* renamed from: a1  reason: collision with root package name */
    public boolean f1669a1;

    /* renamed from: b1  reason: collision with root package name */
    public float f1670b1;

    /* renamed from: c1  reason: collision with root package name */
    public float f1671c1;

    /* renamed from: d1  reason: collision with root package name */
    public long f1672d1;

    /* renamed from: e1  reason: collision with root package name */
    public float f1673e1;

    /* renamed from: f1  reason: collision with root package name */
    public boolean f1674f1;

    /* renamed from: g1  reason: collision with root package name */
    public ArrayList f1675g1;

    /* renamed from: h1  reason: collision with root package name */
    public ArrayList f1676h1;

    /* renamed from: i1  reason: collision with root package name */
    public ArrayList f1677i1;

    /* renamed from: j1  reason: collision with root package name */
    public CopyOnWriteArrayList f1678j1;

    /* renamed from: k1  reason: collision with root package name */
    public int f1679k1;

    /* renamed from: l1  reason: collision with root package name */
    public long f1680l1;

    /* renamed from: m1  reason: collision with root package name */
    public float f1681m1;

    /* renamed from: n1  reason: collision with root package name */
    public int f1682n1;

    /* renamed from: o1  reason: collision with root package name */
    public float f1683o1;

    /* renamed from: p0  reason: collision with root package name */
    public final z0.a f1684p0;

    /* renamed from: p1  reason: collision with root package name */
    public boolean f1685p1;

    /* renamed from: q1  reason: collision with root package name */
    public int f1686q1;

    /* renamed from: r1  reason: collision with root package name */
    public int f1687r1;

    /* renamed from: s  reason: collision with root package name */
    public a1.z f1688s;

    /* renamed from: s1  reason: collision with root package name */
    public int f1689s1;

    /* renamed from: t  reason: collision with root package name */
    public o f1690t;

    /* renamed from: t1  reason: collision with root package name */
    public int f1691t1;

    /* renamed from: u  reason: collision with root package name */
    public Interpolator f1692u = null;

    /* renamed from: u1  reason: collision with root package name */
    public int f1693u1;

    /* renamed from: v  reason: collision with root package name */
    public float f1694v = 0.0f;

    /* renamed from: v1  reason: collision with root package name */
    public int f1695v1;

    /* renamed from: w  reason: collision with root package name */
    public int f1696w;

    /* renamed from: w1  reason: collision with root package name */
    public float f1697w1;

    /* renamed from: x  reason: collision with root package name */
    public int f1698x;

    /* renamed from: x1  reason: collision with root package name */
    public final n0 f1699x1;

    /* renamed from: y  reason: collision with root package name */
    public int f1700y;

    /* renamed from: y1  reason: collision with root package name */
    public boolean f1701y1;

    /* renamed from: z  reason: collision with root package name */
    public int f1702z;

    /* renamed from: z1  reason: collision with root package name */
    public t f1703z1;

    /* JADX WARNING: type inference failed for: r3v3, types: [z0.a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r4v0, types: [java.lang.Object, v0.n, v0.m] */
    /* JADX WARNING: type inference failed for: r3v10, types: [a1.r, java.lang.Object] */
    public MotionLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        a1.z zVar;
        int i11 = -1;
        this.f1696w = -1;
        this.f1698x = -1;
        this.f1700y = -1;
        this.f1702z = 0;
        this.A = 0;
        this.B = true;
        this.C = new HashMap();
        this.D = 0;
        this.E = 1.0f;
        this.F = 0.0f;
        this.G = 0.0f;
        this.I = 0.0f;
        this.K = false;
        this.M = 0;
        this.O = false;
        ? obj = new Object();
        ? obj2 = new Object();
        obj2.f27540k = false;
        obj.f30584a = obj2;
        obj.f30586c = obj2;
        this.f1684p0 = obj;
        this.W0 = new p(this);
        this.f1669a1 = false;
        this.f1674f1 = false;
        this.f1675g1 = null;
        this.f1676h1 = null;
        this.f1677i1 = null;
        this.f1678j1 = null;
        this.f1679k1 = 0;
        this.f1680l1 = -1;
        this.f1681m1 = 0.0f;
        this.f1682n1 = 0;
        this.f1683o1 = 0.0f;
        this.f1685p1 = false;
        this.f1699x1 = new n0(7);
        this.f1701y1 = false;
        this.A1 = null;
        new HashMap();
        this.B1 = new Rect();
        this.C1 = false;
        this.D1 = v.f235a;
        ? obj3 = new Object();
        obj3.f227g = this;
        obj3.f224d = new f();
        obj3.f225e = new f();
        obj3.f221a = null;
        obj3.f226f = null;
        this.E1 = obj3;
        this.F1 = false;
        this.G1 = new RectF();
        this.H1 = null;
        this.I1 = null;
        this.J1 = new ArrayList();
        K1 = isInEditMode();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, c1.p.f3918r);
            int indexCount = obtainStyledAttributes.getIndexCount();
            boolean z4 = true;
            for (int i12 = 0; i12 < indexCount; i12++) {
                int index = obtainStyledAttributes.getIndex(i12);
                int i13 = 2;
                if (index == 2) {
                    this.f1688s = new a1.z(getContext(), this, obtainStyledAttributes.getResourceId(index, -1));
                } else if (index == 1) {
                    this.f1698x = obtainStyledAttributes.getResourceId(index, -1);
                } else if (index == 4) {
                    this.I = obtainStyledAttributes.getFloat(index, 0.0f);
                    this.K = true;
                } else if (index == 0) {
                    z4 = obtainStyledAttributes.getBoolean(index, z4);
                } else if (index == 5) {
                    if (this.M == 0) {
                        this.M = !obtainStyledAttributes.getBoolean(index, false) ? 0 : i13;
                    }
                } else if (index == 3) {
                    this.M = obtainStyledAttributes.getInt(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
            if (this.f1688s == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z4) {
                this.f1688s = null;
            }
        }
        if (this.M != 0) {
            a1.z zVar2 = this.f1688s;
            if (zVar2 == null) {
                Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int h10 = zVar2.h();
                a1.z zVar3 = this.f1688s;
                l b5 = zVar3.b(zVar3.h());
                String m10 = b0.m(getContext(), h10);
                int childCount = getChildCount();
                for (int i14 = 0; i14 < childCount; i14++) {
                    View childAt = getChildAt(i14);
                    int id2 = childAt.getId();
                    if (id2 == -1) {
                        StringBuilder r4 = nl.r("CHECK: ", m10, " ALL VIEWS SHOULD HAVE ID's ");
                        r4.append(childAt.getClass().getName());
                        r4.append(" does not!");
                        Log.w("MotionLayout", r4.toString());
                    }
                    if (b5.i(id2) == null) {
                        StringBuilder r5 = nl.r("CHECK: ", m10, " NO CONSTRAINTS for ");
                        r5.append(b0.n(childAt));
                        Log.w("MotionLayout", r5.toString());
                    }
                }
                Integer[] numArr = (Integer[]) b5.f3891f.keySet().toArray(new Integer[0]);
                int length = numArr.length;
                int[] iArr = new int[length];
                for (int i15 = 0; i15 < length; i15++) {
                    iArr[i15] = numArr[i15].intValue();
                }
                for (int i16 = 0; i16 < length; i16++) {
                    int i17 = iArr[i16];
                    String m11 = b0.m(getContext(), i17);
                    if (findViewById(iArr[i16]) == null) {
                        Log.w("MotionLayout", "CHECK: " + m10 + " NO View matches id " + m11);
                    }
                    if (b5.h(i17).f3802e.f3813d == -1) {
                        Log.w("MotionLayout", "CHECK: " + m10 + "(" + m11 + ") no LAYOUT_HEIGHT");
                    }
                    if (b5.h(i17).f3802e.f3811c == -1) {
                        Log.w("MotionLayout", "CHECK: " + m10 + "(" + m11 + ") no LAYOUT_HEIGHT");
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                Iterator it = this.f1688s.f282d.iterator();
                while (it.hasNext()) {
                    y yVar = (y) it.next();
                    if (yVar == this.f1688s.f281c) {
                        Log.v("MotionLayout", "CHECK: CURRENT");
                    }
                    if (yVar.f264d == yVar.f263c) {
                        Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int i18 = yVar.f264d;
                    int i19 = yVar.f263c;
                    String m12 = b0.m(getContext(), i18);
                    String m13 = b0.m(getContext(), i19);
                    if (sparseIntArray.get(i18) == i19) {
                        Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + m12 + "->" + m13);
                    }
                    if (sparseIntArray2.get(i19) == i18) {
                        Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + m12 + "->" + m13);
                    }
                    sparseIntArray.put(i18, i19);
                    sparseIntArray2.put(i19, i18);
                    if (this.f1688s.b(i18) == null) {
                        Log.e("MotionLayout", " no such constraintSetStart " + m12);
                    }
                    if (this.f1688s.b(i19) == null) {
                        Log.e("MotionLayout", " no such constraintSetEnd " + m12);
                    }
                }
            }
        }
        if (this.f1698x == -1 && (zVar = this.f1688s) != null) {
            this.f1698x = zVar.h();
            this.f1696w = this.f1688s.h();
            y yVar2 = this.f1688s.f281c;
            this.f1700y = yVar2 != null ? yVar2.f263c : i11;
        }
    }

    public static Rect q(MotionLayout motionLayout, e eVar) {
        motionLayout.getClass();
        int u10 = eVar.u();
        Rect rect = motionLayout.B1;
        rect.top = u10;
        rect.left = eVar.t();
        rect.right = eVar.s() + rect.left;
        rect.bottom = eVar.m() + rect.top;
        return rect;
    }

    public final void A() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if (this.L != null || ((copyOnWriteArrayList = this.f1678j1) != null && !copyOnWriteArrayList.isEmpty())) {
            ArrayList arrayList = this.J1;
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                Integer num = (Integer) it.next();
                u uVar = this.L;
                if (uVar != null) {
                    uVar.a(num.intValue());
                }
                CopyOnWriteArrayList copyOnWriteArrayList2 = this.f1678j1;
                if (copyOnWriteArrayList2 != null) {
                    Iterator it2 = copyOnWriteArrayList2.iterator();
                    while (it2.hasNext()) {
                        ((u) it2.next()).a(num.intValue());
                    }
                }
            }
            arrayList.clear();
        }
    }

    public final void B() {
        this.E1.i();
        invalidate();
    }

    public final void C(int i10) {
        l lVar;
        Object obj;
        l lVar2;
        setState(v.f236b);
        this.f1698x = i10;
        this.f1696w = -1;
        this.f1700y = -1;
        r rVar = this.f1808k;
        if (rVar != null) {
            float f10 = (float) -1;
            int i11 = rVar.f222b;
            int i12 = 0;
            if (i11 == i10) {
                if (i10 == -1) {
                    obj = ((SparseArray) rVar.f225e).valueAt(0);
                } else {
                    obj = ((SparseArray) rVar.f225e).get(i11);
                }
                d dVar = (d) obj;
                int i13 = rVar.f223c;
                if (i13 == -1 || !((c1.e) dVar.f3777b.get(i13)).a(f10, f10)) {
                    while (true) {
                        ArrayList arrayList = dVar.f3777b;
                        if (i12 >= arrayList.size()) {
                            i12 = -1;
                            break;
                        } else if (((c1.e) arrayList.get(i12)).a(f10, f10)) {
                            break;
                        } else {
                            i12++;
                        }
                    }
                    if (rVar.f223c != i12) {
                        ArrayList arrayList2 = dVar.f3777b;
                        if (i12 == -1) {
                            lVar2 = (l) rVar.f221a;
                        } else {
                            lVar2 = ((c1.e) arrayList2.get(i12)).f3785f;
                        }
                        if (i12 != -1) {
                            int i14 = ((c1.e) arrayList2.get(i12)).f3784e;
                        }
                        if (lVar2 != null) {
                            rVar.f223c = i12;
                            c.w(rVar.f227g);
                            lVar2.b((ConstraintLayout) rVar.f224d);
                            c.w(rVar.f227g);
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            rVar.f222b = i10;
            d dVar2 = (d) ((SparseArray) rVar.f225e).get(i10);
            while (true) {
                ArrayList arrayList3 = dVar2.f3777b;
                if (i12 >= arrayList3.size()) {
                    i12 = -1;
                    break;
                } else if (((c1.e) arrayList3.get(i12)).a(f10, f10)) {
                    break;
                } else {
                    i12++;
                }
            }
            ArrayList arrayList4 = dVar2.f3777b;
            if (i12 == -1) {
                lVar = dVar2.f3779d;
            } else {
                lVar = ((c1.e) arrayList4.get(i12)).f3785f;
            }
            if (i12 != -1) {
                int i15 = ((c1.e) arrayList4.get(i12)).f3784e;
            }
            if (lVar == null) {
                Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i10 + ", dim =-1.0, -1.0");
                return;
            }
            rVar.f223c = i12;
            c.w(rVar.f227g);
            lVar.b((ConstraintLayout) rVar.f224d);
            c.w(rVar.f227g);
            return;
        }
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            zVar.b(i10).b(this);
        }
    }

    public final void D(int i10, int i11) {
        if (!isAttachedToWindow()) {
            if (this.f1703z1 == null) {
                this.f1703z1 = new t(this);
            }
            t tVar = this.f1703z1;
            tVar.f232c = i10;
            tVar.f233d = i11;
            return;
        }
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            this.f1696w = i10;
            this.f1700y = i11;
            zVar.n(i10, i11);
            this.E1.g(this.f1688s.b(i10), this.f1688s.b(i11));
            B();
            this.G = 0.0f;
            r(0.0f);
        }
    }

    /* JADX WARNING: type inference failed for: r7v6, types: [v0.k, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0046, code lost:
        if (r1 != 7) goto L_0x012f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0065, code lost:
        if ((((r4 * r6) - (((r2 * r6) * r6) / 2.0f)) + r1) > 1.0f) goto L_0x0077;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0075, code lost:
        if ((((((r2 * r3) * r3) / 2.0f) + (r4 * r3)) + r1) < 0.0f) goto L_0x0077;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0089, code lost:
        r1 = r0.f1684p0;
        r2 = r0.G;
        r5 = r0.E;
        r6 = r0.f1688s.g();
        r3 = r0.f1688s.f281c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0099, code lost:
        if (r3 == null) goto L_0x00a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x009b, code lost:
        r3 = r3.f272l;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x009d, code lost:
        if (r3 == null) goto L_0x00a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009f, code lost:
        r7 = r3.f82s;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00a3, code lost:
        r7 = 0.0f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00a4, code lost:
        r1.b(r2, r17, r18, r5, r6, r7);
        r0.f1694v = 0.0f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void E(int r16, float r17, float r18) {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r8 = r17
            r4 = r18
            a1.z r2 = r0.f1688s
            if (r2 != 0) goto L_0x000c
            return
        L_0x000c:
            float r2 = r0.G
            int r2 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r2 != 0) goto L_0x0013
            return
        L_0x0013:
            r2 = 1
            r0.O = r2
            long r5 = r15.getNanoTime()
            r0.D = r5
            a1.z r3 = r0.f1688s
            int r3 = r3.c()
            float r3 = (float) r3
            r5 = 1148846080(0x447a0000, float:1000.0)
            float r5 = r3 / r5
            r0.E = r5
            r0.I = r8
            r0.K = r2
            z0.a r9 = r0.f1684p0
            r10 = 0
            r3 = 1065353216(0x3f800000, float:1.0)
            r6 = 7
            r7 = 6
            r11 = 2
            r12 = 0
            if (r1 == 0) goto L_0x00c0
            if (r1 == r2) goto L_0x00c0
            if (r1 == r11) goto L_0x00c0
            a1.p r13 = r0.W0
            r14 = 4
            if (r1 == r14) goto L_0x00b7
            r14 = 5
            if (r1 == r14) goto L_0x004a
            if (r1 == r7) goto L_0x00c0
            if (r1 == r6) goto L_0x00c0
            goto L_0x012f
        L_0x004a:
            float r1 = r0.G
            a1.z r2 = r0.f1688s
            float r2 = r2.g()
            r5 = 1073741824(0x40000000, float:2.0)
            int r6 = (r4 > r10 ? 1 : (r4 == r10 ? 0 : -1))
            if (r6 <= 0) goto L_0x0068
            float r6 = r4 / r2
            float r7 = r4 * r6
            float r2 = r2 * r6
            float r2 = r2 * r6
            float r2 = r2 / r5
            float r7 = r7 - r2
            float r7 = r7 + r1
            int r1 = (r7 > r3 ? 1 : (r7 == r3 ? 0 : -1))
            if (r1 <= 0) goto L_0x0089
            goto L_0x0077
        L_0x0068:
            float r3 = -r4
            float r3 = r3 / r2
            float r6 = r4 * r3
            float r2 = r2 * r3
            float r2 = r2 * r3
            float r2 = r2 / r5
            float r2 = r2 + r6
            float r2 = r2 + r1
            int r1 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1))
            if (r1 >= 0) goto L_0x0089
        L_0x0077:
            float r1 = r0.G
            a1.z r2 = r0.f1688s
            float r2 = r2.g()
        L_0x007f:
            r13.f203a = r4
            r13.f204b = r1
            r13.f205c = r2
            r0.f1690t = r13
            goto L_0x012f
        L_0x0089:
            z0.a r1 = r0.f1684p0
            float r2 = r0.G
            float r5 = r0.E
            a1.z r3 = r0.f1688s
            float r6 = r3.g()
            a1.z r3 = r0.f1688s
            a1.y r3 = r3.f281c
            if (r3 == 0) goto L_0x00a3
            a1.b0 r3 = r3.f272l
            if (r3 == 0) goto L_0x00a3
            float r3 = r3.f82s
            r7 = r3
            goto L_0x00a4
        L_0x00a3:
            r7 = 0
        L_0x00a4:
            r3 = r17
            r4 = r18
            r1.b(r2, r3, r4, r5, r6, r7)
            r0.f1694v = r10
        L_0x00ad:
            int r1 = r0.f1698x
            r0.I = r8
            r0.f1698x = r1
            r0.f1690t = r9
            goto L_0x012f
        L_0x00b7:
            float r1 = r0.G
            a1.z r2 = r0.f1688s
            float r2 = r2.g()
            goto L_0x007f
        L_0x00c0:
            if (r1 == r2) goto L_0x00cc
            if (r1 != r6) goto L_0x00c5
            goto L_0x00cc
        L_0x00c5:
            if (r1 == r11) goto L_0x00c9
            if (r1 != r7) goto L_0x00cd
        L_0x00c9:
            r8 = 1065353216(0x3f800000, float:1.0)
            goto L_0x00cd
        L_0x00cc:
            r8 = 0
        L_0x00cd:
            a1.z r1 = r0.f1688s
            a1.y r2 = r1.f281c
            if (r2 == 0) goto L_0x0111
            a1.b0 r2 = r2.f272l
            if (r2 == 0) goto L_0x0111
            int r3 = r2.D
            if (r3 != 0) goto L_0x00dc
            goto L_0x0111
        L_0x00dc:
            float r1 = r0.G
            float r3 = r2.f89z
            float r4 = r2.A
            float r5 = r2.f88y
            float r6 = r2.B
            int r2 = r2.C
            v0.k r7 = r9.f30585b
            if (r7 != 0) goto L_0x00f9
            v0.k r7 = new v0.k
            r7.<init>()
            r13 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            r7.f27520a = r13
            r7.f27528i = r12
            r9.f30585b = r7
        L_0x00f9:
            v0.k r7 = r9.f30585b
            r9.f30586c = r7
            double r13 = (double) r8
            r7.f27522c = r13
            double r13 = (double) r5
            r7.f27520a = r13
            r7.f27524e = r1
            double r4 = (double) r4
            r7.f27521b = r4
            r7.f27526g = r3
            r7.f27527h = r6
            r7.f27528i = r2
            r7.f27523d = r10
            goto L_0x00ad
        L_0x0111:
            float r2 = r0.G
            float r6 = r1.g()
            a1.z r1 = r0.f1688s
            a1.y r1 = r1.f281c
            if (r1 == 0) goto L_0x0125
            a1.b0 r1 = r1.f272l
            if (r1 == 0) goto L_0x0125
            float r1 = r1.f82s
            r7 = r1
            goto L_0x0126
        L_0x0125:
            r7 = 0
        L_0x0126:
            r1 = r9
            r3 = r8
            r4 = r18
            r1.b(r2, r3, r4, r5, r6, r7)
            goto L_0x00ad
        L_0x012f:
            r0.J = r12
            long r1 = r15.getNanoTime()
            r0.D = r1
            r15.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.E(int, float, float):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00e5, code lost:
        if (r15 > 0) goto L_0x00e0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void F(int r14, int r15) {
        /*
            r13 = this;
            a1.z r0 = r13.f1688s
            r1 = -1
            r2 = 0
            if (r0 == 0) goto L_0x0067
            c1.u r0 = r0.f280b
            if (r0 == 0) goto L_0x0067
            int r3 = r13.f1698x
            float r4 = (float) r1
            java.lang.Object r0 = r0.f3939d
            android.util.SparseArray r0 = (android.util.SparseArray) r0
            java.lang.Object r0 = r0.get(r14)
            c1.s r0 = (c1.s) r0
            if (r0 != 0) goto L_0x001b
            r3 = r14
            goto L_0x0064
        L_0x001b:
            java.util.ArrayList r5 = r0.f3929b
            int r0 = r0.f3930c
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r6 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r6 == 0) goto L_0x004d
            if (r6 != 0) goto L_0x0028
            goto L_0x004d
        L_0x0028:
            java.util.Iterator r5 = r5.iterator()
            r6 = r2
        L_0x002d:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L_0x0046
            java.lang.Object r7 = r5.next()
            c1.t r7 = (c1.t) r7
            boolean r8 = r7.a(r4, r4)
            if (r8 == 0) goto L_0x002d
            int r6 = r7.f3935e
            if (r3 != r6) goto L_0x0044
            goto L_0x0064
        L_0x0044:
            r6 = r7
            goto L_0x002d
        L_0x0046:
            if (r6 == 0) goto L_0x004b
            int r3 = r6.f3935e
            goto L_0x0064
        L_0x004b:
            r3 = r0
            goto L_0x0064
        L_0x004d:
            if (r0 != r3) goto L_0x0050
            goto L_0x0064
        L_0x0050:
            java.util.Iterator r4 = r5.iterator()
        L_0x0054:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x004b
            java.lang.Object r5 = r4.next()
            c1.t r5 = (c1.t) r5
            int r5 = r5.f3935e
            if (r3 != r5) goto L_0x0054
        L_0x0064:
            if (r3 == r1) goto L_0x0067
            r14 = r3
        L_0x0067:
            int r0 = r13.f1698x
            if (r0 != r14) goto L_0x006c
            return
        L_0x006c:
            int r3 = r13.f1696w
            r4 = 0
            r5 = 1148846080(0x447a0000, float:1000.0)
            if (r3 != r14) goto L_0x007d
            r13.r(r4)
            if (r15 <= 0) goto L_0x007c
            float r14 = (float) r15
            float r14 = r14 / r5
            r13.E = r14
        L_0x007c:
            return
        L_0x007d:
            int r3 = r13.f1700y
            r6 = 1065353216(0x3f800000, float:1.0)
            if (r3 != r14) goto L_0x008d
            r13.r(r6)
            if (r15 <= 0) goto L_0x008c
            float r14 = (float) r15
            float r14 = r14 / r5
            r13.E = r14
        L_0x008c:
            return
        L_0x008d:
            r13.f1700y = r14
            if (r0 == r1) goto L_0x00a5
            r13.D(r0, r14)
            r13.r(r6)
            r13.G = r4
            r13.r(r6)
            r13.A1 = r2
            if (r15 <= 0) goto L_0x00a4
            float r14 = (float) r15
            float r14 = r14 / r5
            r13.E = r14
        L_0x00a4:
            return
        L_0x00a5:
            r0 = 0
            r13.O = r0
            r13.I = r6
            r13.F = r4
            r13.G = r4
            long r7 = r13.getNanoTime()
            r13.H = r7
            long r7 = r13.getNanoTime()
            r13.D = r7
            r13.J = r0
            r13.f1690t = r2
            if (r15 != r1) goto L_0x00ca
            a1.z r3 = r13.f1688s
            int r3 = r3.c()
            float r3 = (float) r3
            float r3 = r3 / r5
            r13.E = r3
        L_0x00ca:
            r13.f1696w = r1
            a1.z r3 = r13.f1688s
            int r7 = r13.f1700y
            r3.n(r1, r7)
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            if (r15 != 0) goto L_0x00e5
            a1.z r15 = r13.f1688s
            int r15 = r15.c()
        L_0x00e0:
            float r15 = (float) r15
            float r15 = r15 / r5
            r13.E = r15
            goto L_0x00e8
        L_0x00e5:
            if (r15 <= 0) goto L_0x00e8
            goto L_0x00e0
        L_0x00e8:
            int r15 = r13.getChildCount()
            java.util.HashMap r3 = r13.C
            r3.clear()
            r5 = 0
        L_0x00f2:
            if (r5 >= r15) goto L_0x0110
            android.view.View r7 = r13.getChildAt(r5)
            a1.n r8 = new a1.n
            r8.<init>(r7)
            r3.put(r7, r8)
            int r8 = r7.getId()
            java.lang.Object r7 = r3.get(r7)
            a1.n r7 = (a1.n) r7
            r1.put(r8, r7)
            int r5 = r5 + 1
            goto L_0x00f2
        L_0x0110:
            r1 = 1
            r13.K = r1
            a1.z r5 = r13.f1688s
            c1.l r14 = r5.b(r14)
            a1.r r5 = r13.E1
            r5.g(r2, r14)
            r13.B()
            r5.c()
            int r14 = r13.getChildCount()
            r2 = 0
        L_0x0129:
            if (r2 >= r14) goto L_0x01bf
            android.view.View r5 = r13.getChildAt(r2)
            java.lang.Object r7 = r3.get(r5)
            a1.n r7 = (a1.n) r7
            if (r7 != 0) goto L_0x0139
            goto L_0x01bb
        L_0x0139:
            a1.w r8 = r7.f182f
            r8.f243c = r4
            r8.f244d = r4
            float r9 = r5.getX()
            float r10 = r5.getY()
            int r11 = r5.getWidth()
            float r11 = (float) r11
            int r12 = r5.getHeight()
            float r12 = (float) r12
            r8.f(r9, r10, r11, r12)
            a1.l r7 = r7.f184h
            r7.getClass()
            r5.getX()
            r5.getY()
            r5.getWidth()
            r5.getHeight()
            int r8 = r5.getVisibility()
            r7.f160c = r8
            int r8 = r5.getVisibility()
            if (r8 == 0) goto L_0x0173
            r8 = 0
            goto L_0x0177
        L_0x0173:
            float r8 = r5.getAlpha()
        L_0x0177:
            r7.f158a = r8
            float r8 = r5.getElevation()
            r7.f161d = r8
            float r8 = r5.getRotation()
            r7.f162e = r8
            float r8 = r5.getRotationX()
            r7.f163f = r8
            float r8 = r5.getRotationY()
            r7.f164g = r8
            float r8 = r5.getScaleX()
            r7.f165h = r8
            float r8 = r5.getScaleY()
            r7.f166i = r8
            float r8 = r5.getPivotX()
            r7.f167j = r8
            float r8 = r5.getPivotY()
            r7.f168k = r8
            float r8 = r5.getTranslationX()
            r7.f169l = r8
            float r8 = r5.getTranslationY()
            r7.f170m = r8
            float r5 = r5.getTranslationZ()
            r7.f171n = r5
        L_0x01bb:
            int r2 = r2 + 1
            goto L_0x0129
        L_0x01bf:
            int r14 = r13.getWidth()
            int r2 = r13.getHeight()
            java.util.ArrayList r5 = r13.f1677i1
            if (r5 == 0) goto L_0x0213
            r5 = 0
        L_0x01cc:
            if (r5 >= r15) goto L_0x01e3
            android.view.View r7 = r13.getChildAt(r5)
            java.lang.Object r7 = r3.get(r7)
            a1.n r7 = (a1.n) r7
            if (r7 != 0) goto L_0x01db
            goto L_0x01e0
        L_0x01db:
            a1.z r8 = r13.f1688s
            r8.f(r7)
        L_0x01e0:
            int r5 = r5 + 1
            goto L_0x01cc
        L_0x01e3:
            java.util.ArrayList r5 = r13.f1677i1
            java.util.Iterator r5 = r5.iterator()
        L_0x01e9:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L_0x01f9
            java.lang.Object r7 = r5.next()
            androidx.constraintlayout.motion.widget.MotionHelper r7 = (androidx.constraintlayout.motion.widget.MotionHelper) r7
            r7.s(r13, r3)
            goto L_0x01e9
        L_0x01f9:
            r5 = 0
        L_0x01fa:
            if (r5 >= r15) goto L_0x0232
            android.view.View r7 = r13.getChildAt(r5)
            java.lang.Object r7 = r3.get(r7)
            a1.n r7 = (a1.n) r7
            if (r7 != 0) goto L_0x0209
            goto L_0x0210
        L_0x0209:
            long r8 = r13.getNanoTime()
            r7.h(r14, r2, r8)
        L_0x0210:
            int r5 = r5 + 1
            goto L_0x01fa
        L_0x0213:
            r5 = 0
        L_0x0214:
            if (r5 >= r15) goto L_0x0232
            android.view.View r7 = r13.getChildAt(r5)
            java.lang.Object r7 = r3.get(r7)
            a1.n r7 = (a1.n) r7
            if (r7 != 0) goto L_0x0223
            goto L_0x022f
        L_0x0223:
            a1.z r8 = r13.f1688s
            r8.f(r7)
            long r8 = r13.getNanoTime()
            r7.h(r14, r2, r8)
        L_0x022f:
            int r5 = r5 + 1
            goto L_0x0214
        L_0x0232:
            a1.z r14 = r13.f1688s
            a1.y r14 = r14.f281c
            if (r14 == 0) goto L_0x023b
            float r14 = r14.f269i
            goto L_0x023c
        L_0x023b:
            r14 = 0
        L_0x023c:
            int r2 = (r14 > r4 ? 1 : (r14 == r4 ? 0 : -1))
            if (r2 == 0) goto L_0x028b
            r2 = 2139095039(0x7f7fffff, float:3.4028235E38)
            r5 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
            r7 = 0
        L_0x0247:
            if (r7 >= r15) goto L_0x0265
            android.view.View r8 = r13.getChildAt(r7)
            java.lang.Object r8 = r3.get(r8)
            a1.n r8 = (a1.n) r8
            a1.w r8 = r8.f183g
            float r9 = r8.f245e
            float r8 = r8.f246f
            float r8 = r8 + r9
            float r2 = java.lang.Math.min(r2, r8)
            float r5 = java.lang.Math.max(r5, r8)
            int r7 = r7 + 1
            goto L_0x0247
        L_0x0265:
            if (r0 >= r15) goto L_0x028b
            android.view.View r7 = r13.getChildAt(r0)
            java.lang.Object r7 = r3.get(r7)
            a1.n r7 = (a1.n) r7
            a1.w r8 = r7.f183g
            float r9 = r8.f245e
            float r8 = r8.f246f
            float r10 = r6 - r14
            float r10 = r6 / r10
            r7.f190n = r10
            float r9 = r9 + r8
            float r9 = r9 - r2
            float r9 = r9 * r14
            float r8 = r5 - r2
            float r9 = r9 / r8
            float r8 = r14 - r9
            r7.f189m = r8
            int r0 = r0 + 1
            goto L_0x0265
        L_0x028b:
            r13.F = r4
            r13.G = r4
            r13.K = r1
            r13.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.F(int, int):void");
    }

    public final void G(int i10, l lVar) {
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            zVar.f285g.put(i10, lVar);
        }
        this.E1.g(this.f1688s.b(this.f1696w), this.f1688s.b(this.f1700y));
        B();
        if (this.f1698x == i10) {
            lVar.b(this);
        }
    }

    public final void a(View view, View view2, int i10, int i11) {
        this.f1672d1 = getNanoTime();
        this.f1673e1 = 0.0f;
        this.f1670b1 = 0.0f;
        this.f1671c1 = 0.0f;
    }

    public final void b(View view, int i10) {
        a1.b0 b0Var;
        float f10;
        boolean z4;
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            float f11 = this.f1673e1;
            float f12 = 0.0f;
            if (f11 != 0.0f) {
                float f13 = this.f1670b1 / f11;
                float f14 = this.f1671c1 / f11;
                y yVar = zVar.f281c;
                if (yVar != null && (b0Var = yVar.f272l) != null) {
                    boolean z10 = false;
                    b0Var.f76m = false;
                    MotionLayout motionLayout = b0Var.f81r;
                    float progress = motionLayout.getProgress();
                    b0Var.f81r.w(b0Var.f67d, progress, b0Var.f71h, b0Var.f70g, b0Var.f77n);
                    float f15 = b0Var.f74k;
                    float[] fArr = b0Var.f77n;
                    float f16 = fArr[0];
                    float f17 = b0Var.f75l;
                    float f18 = fArr[1];
                    if (f15 != 0.0f) {
                        f10 = (f13 * f15) / f16;
                    } else {
                        f10 = (f14 * f17) / f18;
                    }
                    if (!Float.isNaN(f10)) {
                        progress += f10 / 3.0f;
                    }
                    if (progress != 0.0f) {
                        if (progress != 1.0f) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        int i11 = b0Var.f66c;
                        if (i11 != 3) {
                            z10 = true;
                        }
                        if (z10 && z4) {
                            if (((double) progress) >= 0.5d) {
                                f12 = 1.0f;
                            }
                            motionLayout.E(i11, f12, f10);
                        }
                    }
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [boolean] */
    /* JADX WARNING: type inference failed for: r1v4 */
    /* JADX WARNING: type inference failed for: r1v5 */
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        y yVar;
        boolean z4;
        ? r12;
        a1.b0 b0Var;
        float f10;
        float f11;
        a1.b0 b0Var2;
        a1.b0 b0Var3;
        a1.b0 b0Var4;
        int i13;
        View view2 = view;
        int i14 = i10;
        int i15 = i11;
        a1.z zVar = this.f1688s;
        if (zVar != null && (yVar = zVar.f281c) != null && z4) {
            int i16 = -1;
            if (!(!yVar.f275o) || (b0Var4 = yVar.f272l) == null || (i13 = b0Var4.f68e) == -1 || view.getId() == i13) {
                y yVar2 = zVar.f281c;
                if (!(yVar2 == null || (b0Var3 = yVar2.f272l) == null || !b0Var3.f84u)) {
                    a1.b0 b0Var5 = yVar.f272l;
                    if (!(b0Var5 == null || (b0Var5.f86w & 4) == 0)) {
                        i16 = i15;
                    }
                    float f12 = this.F;
                    if ((f12 == 1.0f || f12 == 0.0f) && view2.canScrollVertically(i16)) {
                        return;
                    }
                }
                a1.b0 b0Var6 = yVar.f272l;
                if (!(b0Var6 == null || (b0Var6.f86w & 1) == 0)) {
                    float f13 = (float) i14;
                    float f14 = (float) i15;
                    y yVar3 = zVar.f281c;
                    if (yVar3 == null || (b0Var2 = yVar3.f272l) == null) {
                        f11 = 0.0f;
                    } else {
                        float progress = b0Var2.f81r.getProgress();
                        b0Var2.f81r.w(b0Var2.f67d, progress, b0Var2.f71h, b0Var2.f70g, b0Var2.f77n);
                        float f15 = b0Var2.f74k;
                        float[] fArr = b0Var2.f77n;
                        if (f15 != 0.0f) {
                            if (fArr[0] == 0.0f) {
                                fArr[0] = 1.0E-7f;
                            }
                            f11 = (f13 * f15) / fArr[0];
                        } else {
                            if (fArr[1] == 0.0f) {
                                fArr[1] = 1.0E-7f;
                            }
                            f11 = (f14 * b0Var2.f75l) / fArr[1];
                        }
                    }
                    float f16 = this.G;
                    if ((f16 <= 0.0f && f11 < 0.0f) || (f16 >= 1.0f && f11 > 0.0f)) {
                        view2.setNestedScrollingEnabled(false);
                        view2.post(new y0(view2));
                        return;
                    }
                }
                float f17 = this.F;
                long nanoTime = getNanoTime();
                float f18 = (float) i14;
                this.f1670b1 = f18;
                float f19 = (float) i15;
                this.f1671c1 = f19;
                this.f1673e1 = (float) (((double) (nanoTime - this.f1672d1)) * 1.0E-9d);
                this.f1672d1 = nanoTime;
                y yVar4 = zVar.f281c;
                if (!(yVar4 == null || (b0Var = yVar4.f272l) == null)) {
                    MotionLayout motionLayout = b0Var.f81r;
                    float progress2 = motionLayout.getProgress();
                    if (!b0Var.f76m) {
                        b0Var.f76m = true;
                        motionLayout.setProgress(progress2);
                    }
                    b0Var.f81r.w(b0Var.f67d, progress2, b0Var.f71h, b0Var.f70g, b0Var.f77n);
                    float f20 = b0Var.f74k;
                    float[] fArr2 = b0Var.f77n;
                    if (((double) Math.abs((b0Var.f75l * fArr2[1]) + (f20 * fArr2[0]))) < 0.01d) {
                        fArr2[0] = 0.01f;
                        fArr2[1] = 0.01f;
                    }
                    float f21 = b0Var.f74k;
                    if (f21 != 0.0f) {
                        f10 = (f18 * f21) / fArr2[0];
                    } else {
                        f10 = (f19 * b0Var.f75l) / fArr2[1];
                    }
                    float max = Math.max(Math.min(progress2 + f10, 1.0f), 0.0f);
                    if (max != motionLayout.getProgress()) {
                        motionLayout.setProgress(max);
                    }
                }
                if (f17 != this.F) {
                    iArr[0] = i14;
                    r12 = 1;
                    iArr[1] = i15;
                } else {
                    r12 = 1;
                }
                t(false);
                if (iArr[0] != 0 || iArr[r12] != 0) {
                    this.f1669a1 = r12;
                }
            }
        }
    }

    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        if (!(!this.f1669a1 && i10 == 0 && i11 == 0)) {
            iArr[0] = iArr[0] + i12;
            iArr[1] = iArr[1] + i13;
        }
        this.f1669a1 = false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:118:0x031a  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0345  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0362  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x0372  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0393  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x039d  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x03aa  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x03b8  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0100  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0103  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void dispatchDraw(android.graphics.Canvas r35) {
        /*
            r34 = this;
            r0 = r34
            r1 = r35
            java.util.ArrayList r2 = r0.f1677i1
            if (r2 == 0) goto L_0x001c
            java.util.Iterator r2 = r2.iterator()
        L_0x000c:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x001c
            java.lang.Object r3 = r2.next()
            androidx.constraintlayout.motion.widget.MotionHelper r3 = (androidx.constraintlayout.motion.widget.MotionHelper) r3
            r3.getClass()
            goto L_0x000c
        L_0x001c:
            r2 = 0
            r0.t(r2)
            a1.z r3 = r0.f1688s
            r4 = 0
            if (r3 == 0) goto L_0x0062
            pa.b r3 = r3.f295q
            if (r3 == 0) goto L_0x0062
            java.lang.Object r5 = r3.f24103e
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            if (r5 != 0) goto L_0x0030
            goto L_0x0062
        L_0x0030:
            java.util.Iterator r5 = r5.iterator()
        L_0x0034:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0044
            java.lang.Object r6 = r5.next()
            a1.c0 r6 = (a1.c0) r6
            r6.a()
            goto L_0x0034
        L_0x0044:
            java.lang.Object r5 = r3.f24103e
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            java.lang.Object r6 = r3.f24104f
            java.util.ArrayList r6 = (java.util.ArrayList) r6
            r5.removeAll(r6)
            java.lang.Object r5 = r3.f24104f
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            r5.clear()
            java.lang.Object r5 = r3.f24103e
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            boolean r5 = r5.isEmpty()
            if (r5 == 0) goto L_0x0062
            r3.f24103e = r4
        L_0x0062:
            super.dispatchDraw(r35)
            a1.z r3 = r0.f1688s
            if (r3 != 0) goto L_0x006a
            return
        L_0x006a:
            int r3 = r0.M
            r5 = 1
            r3 = r3 & r5
            r6 = 1093664768(0x41300000, float:11.0)
            r7 = 1092616192(0x41200000, float:10.0)
            if (r3 != r5) goto L_0x012d
            boolean r3 = r34.isInEditMode()
            if (r3 != 0) goto L_0x012d
            int r3 = r0.f1679k1
            int r3 = r3 + r5
            r0.f1679k1 = r3
            long r8 = r34.getNanoTime()
            long r10 = r0.f1680l1
            r12 = -1
            int r3 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r3 == 0) goto L_0x00a9
            long r10 = r8 - r10
            r12 = 200000000(0xbebc200, double:9.8813129E-316)
            int r3 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r3 <= 0) goto L_0x00ab
            int r3 = r0.f1679k1
            float r3 = (float) r3
            float r10 = (float) r10
            r11 = 814313567(0x3089705f, float:1.0E-9)
            float r10 = r10 * r11
            float r3 = r3 / r10
            r10 = 1120403456(0x42c80000, float:100.0)
            float r3 = r3 * r10
            int r3 = (int) r3
            float r3 = (float) r3
            float r3 = r3 / r10
            r0.f1681m1 = r3
            r0.f1679k1 = r2
        L_0x00a9:
            r0.f1680l1 = r8
        L_0x00ab:
            android.graphics.Paint r3 = new android.graphics.Paint
            r3.<init>()
            r8 = 1109917696(0x42280000, float:42.0)
            r3.setTextSize(r8)
            float r8 = r34.getProgress()
            r9 = 1148846080(0x447a0000, float:1000.0)
            float r8 = r8 * r9
            int r8 = (int) r8
            float r8 = (float) r8
            float r8 = r8 / r7
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            float r10 = r0.f1681m1
            r9.append(r10)
            java.lang.String r10 = " fps "
            r9.append(r10)
            int r10 = r0.f1696w
            java.lang.String r10 = yg.b0.q(r10, r0)
            r9.append(r10)
            java.lang.String r10 = " -> "
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            java.lang.StringBuilder r9 = f.c.o(r9)
            int r10 = r0.f1700y
            java.lang.String r10 = yg.b0.q(r10, r0)
            r9.append(r10)
            java.lang.String r10 = " (progress: "
            r9.append(r10)
            r9.append(r8)
            java.lang.String r8 = " ) state="
            r9.append(r8)
            int r8 = r0.f1698x
            r10 = -1
            if (r8 != r10) goto L_0x0103
            java.lang.String r8 = "undefined"
            goto L_0x0107
        L_0x0103:
            java.lang.String r8 = yg.b0.q(r8, r0)
        L_0x0107:
            r9.append(r8)
            java.lang.String r8 = r9.toString()
            r9 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r3.setColor(r9)
            int r9 = r34.getHeight()
            int r9 = r9 + -29
            float r9 = (float) r9
            r1.drawText(r8, r6, r9, r3)
            r9 = -7864184(0xffffffffff880088, float:NaN)
            r3.setColor(r9)
            int r9 = r34.getHeight()
            int r9 = r9 + -30
            float r9 = (float) r9
            r1.drawText(r8, r7, r9, r3)
        L_0x012d:
            int r3 = r0.M
            if (r3 <= r5) goto L_0x0511
            a1.q r3 = r0.N
            if (r3 != 0) goto L_0x013c
            a1.q r3 = new a1.q
            r3.<init>(r0)
            r0.N = r3
        L_0x013c:
            a1.q r3 = r0.N
            java.util.HashMap r8 = r0.C
            a1.z r9 = r0.f1688s
            int r9 = r9.c()
            int r10 = r0.M
            r3.getClass()
            if (r8 == 0) goto L_0x0511
            int r11 = r8.size()
            if (r11 != 0) goto L_0x0155
            goto L_0x0511
        L_0x0155:
            r35.save()
            androidx.constraintlayout.motion.widget.MotionLayout r11 = r3.f220n
            boolean r12 = r11.isInEditMode()
            android.graphics.Paint r13 = r3.f211e
            r14 = 2
            if (r12 != 0) goto L_0x01a3
            r12 = r10 & 1
            if (r12 != r14) goto L_0x01a3
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            android.content.Context r15 = r11.getContext()
            android.content.res.Resources r15 = r15.getResources()
            int r14 = r11.f1700y
            java.lang.String r14 = r15.getResourceName(r14)
            r12.append(r14)
            java.lang.String r14 = ":"
            r12.append(r14)
            float r14 = r11.getProgress()
            r12.append(r14)
            java.lang.String r12 = r12.toString()
            int r14 = r11.getHeight()
            int r14 = r14 + -30
            float r14 = (float) r14
            android.graphics.Paint r15 = r3.f214h
            r1.drawText(r12, r7, r14, r15)
            int r7 = r11.getHeight()
            int r7 = r7 + -29
            float r7 = (float) r7
            r1.drawText(r12, r6, r7, r13)
        L_0x01a3:
            java.util.Collection r6 = r8.values()
            java.util.Iterator r6 = r6.iterator()
        L_0x01ab:
            boolean r7 = r6.hasNext()
            if (r7 == 0) goto L_0x050d
            java.lang.Object r7 = r6.next()
            a1.n r7 = (a1.n) r7
            a1.w r8 = r7.f182f
            int r8 = r8.f242b
            java.util.ArrayList r11 = r7.f197u
            java.util.Iterator r12 = r11.iterator()
        L_0x01c1:
            boolean r14 = r12.hasNext()
            if (r14 == 0) goto L_0x01d4
            java.lang.Object r14 = r12.next()
            a1.w r14 = (a1.w) r14
            int r14 = r14.f242b
            int r8 = java.lang.Math.max(r8, r14)
            goto L_0x01c1
        L_0x01d4:
            a1.w r12 = r7.f183g
            int r12 = r12.f242b
            int r8 = java.lang.Math.max(r8, r12)
            if (r10 <= 0) goto L_0x01e1
            if (r8 != 0) goto L_0x01e1
            r8 = 1
        L_0x01e1:
            if (r8 != 0) goto L_0x01e4
            goto L_0x01ab
        L_0x01e4:
            float[] r12 = r3.f209c
            if (r12 == 0) goto L_0x024c
            v7.d9[] r14 = r7.f186j
            r14 = r14[r2]
            double[] r14 = r14.g()
            int[] r15 = r3.f208b
            if (r15 == 0) goto L_0x0212
            java.util.Iterator r16 = r11.iterator()
            r17 = 0
        L_0x01fa:
            boolean r18 = r16.hasNext()
            if (r18 == 0) goto L_0x0212
            java.lang.Object r18 = r16.next()
            r4 = r18
            a1.w r4 = (a1.w) r4
            int r18 = r17 + 1
            int r4 = r4.f255o
            r15[r17] = r4
            r17 = r18
            r4 = 0
            goto L_0x01fa
        L_0x0212:
            r4 = 0
            r15 = 0
        L_0x0214:
            int r5 = r14.length
            if (r4 >= r5) goto L_0x0245
            v7.d9[] r5 = r7.f186j
            r5 = r5[r2]
            r23 = r3
            r2 = r14[r4]
            r24 = r6
            double[] r6 = r7.f192p
            r5.c(r2, r6)
            a1.w r2 = r7.f182f
            r17 = r14[r4]
            int[] r3 = r7.f191o
            double[] r5 = r7.f192p
            r16 = r2
            r19 = r3
            r20 = r5
            r21 = r12
            r22 = r15
            r16.d(r17, r19, r20, r21, r22)
            int r15 = r15 + 2
            int r4 = r4 + 1
            r3 = r23
            r6 = r24
            r2 = 0
            goto L_0x0214
        L_0x0245:
            r23 = r3
            r24 = r6
            int r2 = r15 / 2
            goto L_0x024f
        L_0x024c:
            r24 = r6
            r2 = 0
        L_0x024f:
            r3.f217k = r2
            r2 = 1
            if (r8 < r2) goto L_0x04f9
            int r2 = r9 / 16
            float[] r4 = r3.f207a
            if (r4 == 0) goto L_0x025f
            int r4 = r4.length
            int r5 = r2 * 2
            if (r4 == r5) goto L_0x026c
        L_0x025f:
            int r4 = r2 * 2
            float[] r4 = new float[r4]
            r3.f207a = r4
            android.graphics.Path r4 = new android.graphics.Path
            r4.<init>()
            r3.f210d = r4
        L_0x026c:
            int r4 = r3.f219m
            float r5 = (float) r4
            r1.translate(r5, r5)
            r5 = 1996488704(0x77000000, float:2.5961484E33)
            r13.setColor(r5)
            android.graphics.Paint r6 = r3.f215i
            r6.setColor(r5)
            android.graphics.Paint r12 = r3.f212f
            r12.setColor(r5)
            android.graphics.Paint r14 = r3.f213g
            r14.setColor(r5)
            float[] r5 = r3.f207a
            int r15 = r2 + -1
            float r15 = (float) r15
            r23 = r9
            r9 = 1065353216(0x3f800000, float:1.0)
            float r15 = r9 / r15
            java.util.HashMap r9 = r7.f201y
            r25 = r10
            java.lang.String r10 = "translationX"
            if (r9 != 0) goto L_0x029b
            r9 = 0
            goto L_0x02a1
        L_0x029b:
            java.lang.Object r9 = r9.get(r10)
            z0.k r9 = (z0.k) r9
        L_0x02a1:
            java.util.HashMap r0 = r7.f201y
            r26 = r4
            java.lang.String r4 = "translationY"
            if (r0 != 0) goto L_0x02ad
            r27 = r14
            r0 = 0
            goto L_0x02b5
        L_0x02ad:
            java.lang.Object r0 = r0.get(r4)
            z0.k r0 = (z0.k) r0
            r27 = r14
        L_0x02b5:
            java.util.HashMap r14 = r7.f202z
            if (r14 != 0) goto L_0x02bb
            r10 = 0
            goto L_0x02c1
        L_0x02bb:
            java.lang.Object r10 = r14.get(r10)
            z0.f r10 = (z0.f) r10
        L_0x02c1:
            java.util.HashMap r14 = r7.f202z
            if (r14 != 0) goto L_0x02c7
            r4 = 0
            goto L_0x02cd
        L_0x02c7:
            java.lang.Object r4 = r14.get(r4)
            z0.f r4 = (z0.f) r4
        L_0x02cd:
            r28 = r6
            r14 = 0
        L_0x02d0:
            a1.w r6 = r7.f182f
            r16 = 2143289344(0x7fc00000, float:NaN)
            r29 = r12
            if (r14 >= r2) goto L_0x03d4
            float r12 = (float) r14
            float r12 = r12 * r15
            r30 = r2
            float r2 = r7.f190n
            r18 = 1065353216(0x3f800000, float:1.0)
            int r19 = (r2 > r18 ? 1 : (r2 == r18 ? 0 : -1))
            if (r19 == 0) goto L_0x0305
            r31 = r15
            float r15 = r7.f189m
            int r18 = (r12 > r15 ? 1 : (r12 == r15 ? 0 : -1))
            if (r18 >= 0) goto L_0x02ee
            r12 = 0
        L_0x02ee:
            int r18 = (r12 > r15 ? 1 : (r12 == r15 ? 0 : -1))
            r32 = r0
            if (r18 <= 0) goto L_0x0309
            double r0 = (double) r12
            r18 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r20 = (r0 > r18 ? 1 : (r0 == r18 ? 0 : -1))
            if (r20 >= 0) goto L_0x0309
            float r12 = r12 - r15
            float r12 = r12 * r2
            r0 = 1065353216(0x3f800000, float:1.0)
            float r12 = java.lang.Math.min(r12, r0)
            goto L_0x030b
        L_0x0305:
            r32 = r0
            r31 = r15
        L_0x0309:
            r0 = 1065353216(0x3f800000, float:1.0)
        L_0x030b:
            double r1 = (double) r12
            v0.e r6 = r6.f241a
            java.util.Iterator r15 = r11.iterator()
            r17 = 0
        L_0x0314:
            boolean r18 = r15.hasNext()
            if (r18 == 0) goto L_0x0341
            java.lang.Object r18 = r15.next()
            r0 = r18
            a1.w r0 = (a1.w) r0
            r18 = r1
            v0.e r1 = r0.f241a
            if (r1 == 0) goto L_0x033c
            float r2 = r0.f243c
            int r20 = (r2 > r12 ? 1 : (r2 == r12 ? 0 : -1))
            if (r20 >= 0) goto L_0x0332
            r6 = r1
            r17 = r2
            goto L_0x033c
        L_0x0332:
            boolean r1 = java.lang.Float.isNaN(r16)
            if (r1 == 0) goto L_0x033c
            float r0 = r0.f243c
            r16 = r0
        L_0x033c:
            r1 = r18
            r0 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0314
        L_0x0341:
            r18 = r1
            if (r6 == 0) goto L_0x0362
            boolean r0 = java.lang.Float.isNaN(r16)
            if (r0 == 0) goto L_0x034e
            r18 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0350
        L_0x034e:
            r18 = r16
        L_0x0350:
            float r0 = r12 - r17
            float r18 = r18 - r17
            float r0 = r0 / r18
            double r0 = (double) r0
            double r0 = r6.a(r0)
            float r0 = (float) r0
            float r0 = r0 * r18
            float r0 = r0 + r17
            double r0 = (double) r0
            goto L_0x0364
        L_0x0362:
            r0 = r18
        L_0x0364:
            v7.d9[] r2 = r7.f186j
            r6 = 0
            r2 = r2[r6]
            double[] r6 = r7.f192p
            r2.c(r0, r6)
            v0.b r2 = r7.f187k
            if (r2 == 0) goto L_0x037a
            double[] r6 = r7.f192p
            int r15 = r6.length
            if (r15 <= 0) goto L_0x037a
            r2.c(r0, r6)
        L_0x037a:
            a1.w r2 = r7.f182f
            int[] r6 = r7.f191o
            double[] r15 = r7.f192p
            int r33 = r14 * 2
            r16 = r2
            r17 = r0
            r19 = r6
            r20 = r15
            r21 = r5
            r22 = r33
            r16.d(r17, r19, r20, r21, r22)
            if (r10 == 0) goto L_0x039d
            r0 = r5[r33]
            float r1 = r10.a(r12)
            float r1 = r1 + r0
            r5[r33] = r1
            goto L_0x03a8
        L_0x039d:
            if (r9 == 0) goto L_0x03a8
            r0 = r5[r33]
            float r1 = r9.a(r12)
            float r1 = r1 + r0
            r5[r33] = r1
        L_0x03a8:
            if (r4 == 0) goto L_0x03b8
            int r33 = r33 + 1
            r0 = r5[r33]
            float r1 = r4.a(r12)
            float r1 = r1 + r0
            r5[r33] = r1
        L_0x03b5:
            r1 = r32
            goto L_0x03c7
        L_0x03b8:
            if (r32 == 0) goto L_0x03b5
            int r33 = r33 + 1
            r0 = r5[r33]
            r1 = r32
            float r2 = r1.a(r12)
            float r2 = r2 + r0
            r5[r33] = r2
        L_0x03c7:
            int r14 = r14 + 1
            r0 = r1
            r12 = r29
            r2 = r30
            r15 = r31
            r1 = r35
            goto L_0x02d0
        L_0x03d4:
            int r0 = r3.f217k
            r1 = r35
            r3.a(r1, r8, r0, r7)
            r0 = -21965(0xffffffffffffaa33, float:NaN)
            r13.setColor(r0)
            r0 = -2067046(0xffffffffffe0759a, float:NaN)
            r2 = r29
            r2.setColor(r0)
            r2 = r28
            r2.setColor(r0)
            r0 = -13391360(0xffffffffff33aa00, float:-2.388145E38)
            r2 = r27
            r2.setColor(r0)
            r0 = r26
            int r0 = -r0
            float r0 = (float) r0
            r1.translate(r0, r0)
            int r0 = r3.f217k
            r3.a(r1, r8, r0, r7)
            r0 = 5
            if (r8 != r0) goto L_0x04f4
            android.graphics.Path r2 = r3.f210d
            r2.reset()
            r2 = 0
        L_0x040a:
            r5 = 50
            if (r2 > r5) goto L_0x04d0
            float r8 = (float) r2
            float r5 = (float) r5
            float r8 = r8 / r5
            r5 = 0
            float r8 = r7.b(r8, r5)
            v7.d9[] r9 = r7.f186j
            r10 = 0
            r9 = r9[r10]
            double r10 = (double) r8
            double[] r8 = r7.f192p
            r9.c(r10, r8)
            int[] r8 = r7.f191o
            double[] r9 = r7.f192p
            float r10 = r6.f245e
            float r11 = r6.f246f
            float r12 = r6.f247g
            float r14 = r6.f248h
            r15 = r14
            r14 = r12
            r12 = r11
            r11 = r10
            r10 = 0
        L_0x0432:
            int r5 = r8.length
            r4 = 3
            if (r10 >= r5) goto L_0x0454
            r0 = r9[r10]
            float r0 = (float) r0
            r1 = r8[r10]
            r5 = 1
            if (r1 == r5) goto L_0x044d
            r5 = 2
            if (r1 == r5) goto L_0x044b
            if (r1 == r4) goto L_0x0449
            r4 = 4
            if (r1 == r4) goto L_0x0447
            goto L_0x044e
        L_0x0447:
            r15 = r0
            goto L_0x044e
        L_0x0449:
            r14 = r0
            goto L_0x044e
        L_0x044b:
            r12 = r0
            goto L_0x044e
        L_0x044d:
            r11 = r0
        L_0x044e:
            int r10 = r10 + 1
            r1 = r35
            r0 = 5
            goto L_0x0432
        L_0x0454:
            a1.n r0 = r6.f253m
            if (r0 == 0) goto L_0x0479
            r0 = 0
            double r8 = (double) r0
            double r0 = (double) r11
            double r10 = (double) r12
            double r20 = java.lang.Math.sin(r10)
            double r20 = r20 * r0
            double r20 = r20 + r8
            r12 = 1073741824(0x40000000, float:2.0)
            float r5 = r14 / r12
            double r4 = (double) r5
            double r4 = r20 - r4
            float r4 = (float) r4
            double r10 = java.lang.Math.cos(r10)
            double r10 = r10 * r0
            double r8 = r8 - r10
            float r0 = r15 / r12
            double r0 = (double) r0
            double r8 = r8 - r0
            float r12 = (float) r8
            r11 = r4
        L_0x0479:
            float r14 = r14 + r11
            float r15 = r15 + r12
            java.lang.Float.isNaN(r16)
            java.lang.Float.isNaN(r16)
            r0 = 0
            float r11 = r11 + r0
            float r12 = r12 + r0
            float r14 = r14 + r0
            float r15 = r15 + r0
            float[] r1 = r3.f216j
            r4 = 0
            r1[r4] = r11
            r8 = 1
            r1[r8] = r12
            r5 = 2
            r1[r5] = r14
            r5 = 3
            r1[r5] = r12
            r5 = 4
            r1[r5] = r14
            r9 = 5
            r1[r9] = r15
            r9 = 6
            r1[r9] = r11
            r10 = 7
            r1[r10] = r15
            android.graphics.Path r14 = r3.f210d
            r14.moveTo(r11, r12)
            android.graphics.Path r11 = r3.f210d
            r12 = 2
            r14 = r1[r12]
            r15 = 3
            r15 = r1[r15]
            r11.lineTo(r14, r15)
            android.graphics.Path r11 = r3.f210d
            r5 = 4
            r5 = r1[r5]
            r14 = 5
            r15 = r1[r14]
            r11.lineTo(r5, r15)
            android.graphics.Path r5 = r3.f210d
            r9 = r1[r9]
            r1 = r1[r10]
            r5.lineTo(r9, r1)
            android.graphics.Path r1 = r3.f210d
            r1.close()
            int r2 = r2 + 1
            r1 = r35
            r0 = 5
            goto L_0x040a
        L_0x04d0:
            r4 = 0
            r8 = 1
            r12 = 2
            r0 = 1140850688(0x44000000, float:512.0)
            r13.setColor(r0)
            r0 = r35
            r1 = 1073741824(0x40000000, float:2.0)
            r0.translate(r1, r1)
            android.graphics.Path r1 = r3.f210d
            r0.drawPath(r1, r13)
            r1 = -1073741824(0xffffffffc0000000, float:-2.0)
            r0.translate(r1, r1)
            r1 = -65536(0xffffffffffff0000, float:NaN)
            r13.setColor(r1)
            android.graphics.Path r1 = r3.f210d
            r0.drawPath(r1, r13)
            goto L_0x04ff
        L_0x04f4:
            r0 = r1
        L_0x04f5:
            r4 = 0
            r8 = 1
            r12 = 2
            goto L_0x04ff
        L_0x04f9:
            r0 = r1
            r23 = r9
            r25 = r10
            goto L_0x04f5
        L_0x04ff:
            r2 = 0
            r4 = 0
            r5 = 1
            r1 = r0
            r9 = r23
            r6 = r24
            r10 = r25
            r0 = r34
            goto L_0x01ab
        L_0x050d:
            r0 = r1
            r35.restore()
        L_0x0511:
            r0 = r34
            java.util.ArrayList r1 = r0.f1677i1
            if (r1 == 0) goto L_0x052b
            java.util.Iterator r1 = r1.iterator()
        L_0x051b:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x052b
            java.lang.Object r2 = r1.next()
            androidx.constraintlayout.motion.widget.MotionHelper r2 = (androidx.constraintlayout.motion.widget.MotionHelper) r2
            r2.getClass()
            goto L_0x051b
        L_0x052b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.dispatchDraw(android.graphics.Canvas):void");
    }

    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
    }

    public final boolean f(View view, View view2, int i10, int i11) {
        y yVar;
        a1.b0 b0Var;
        a1.z zVar = this.f1688s;
        if (zVar == null || (yVar = zVar.f281c) == null || (b0Var = yVar.f272l) == null || (b0Var.f86w & 2) != 0) {
            return false;
        }
        return true;
    }

    public int[] getConstraintSetIds() {
        a1.z zVar = this.f1688s;
        if (zVar == null) {
            return null;
        }
        SparseArray sparseArray = zVar.f285g;
        int size = sparseArray.size();
        int[] iArr = new int[size];
        for (int i10 = 0; i10 < size; i10++) {
            iArr[i10] = sparseArray.keyAt(i10);
        }
        return iArr;
    }

    public int getCurrentState() {
        return this.f1698x;
    }

    public ArrayList<y> getDefinedTransitions() {
        a1.z zVar = this.f1688s;
        if (zVar == null) {
            return null;
        }
        return zVar.f282d;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, a1.a] */
    public a getDesignTool() {
        if (this.X0 == null) {
            this.X0 = new Object();
        }
        return this.X0;
    }

    public int getEndState() {
        return this.f1700y;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.G;
    }

    public a1.z getScene() {
        return this.f1688s;
    }

    public int getStartState() {
        return this.f1696w;
    }

    public float getTargetPosition() {
        return this.I;
    }

    public Bundle getTransitionState() {
        if (this.f1703z1 == null) {
            this.f1703z1 = new t(this);
        }
        t tVar = this.f1703z1;
        MotionLayout motionLayout = tVar.f234e;
        tVar.f233d = motionLayout.f1700y;
        tVar.f232c = motionLayout.f1696w;
        tVar.f231b = motionLayout.getVelocity();
        tVar.f230a = motionLayout.getProgress();
        t tVar2 = this.f1703z1;
        tVar2.getClass();
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", tVar2.f230a);
        bundle.putFloat("motion.velocity", tVar2.f231b);
        bundle.putInt("motion.StartState", tVar2.f232c);
        bundle.putInt("motion.EndState", tVar2.f233d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            this.E = ((float) zVar.c()) / 1000.0f;
        }
        return (long) (this.E * 1000.0f);
    }

    public float getVelocity() {
        return this.f1694v;
    }

    public final boolean isAttachedToWindow() {
        return super.isAttachedToWindow();
    }

    public final void l(int i10) {
        this.f1808k = null;
    }

    public final void onAttachedToWindow() {
        y yVar;
        int i10;
        super.onAttachedToWindow();
        Display display = getDisplay();
        if (display != null) {
            display.getRotation();
        }
        a1.z zVar = this.f1688s;
        if (!(zVar == null || (i10 = this.f1698x) == -1)) {
            l b5 = zVar.b(i10);
            a1.z zVar2 = this.f1688s;
            int i11 = 0;
            loop0:
            while (true) {
                SparseArray sparseArray = zVar2.f285g;
                if (i11 >= sparseArray.size()) {
                    break;
                }
                int keyAt = sparseArray.keyAt(i11);
                SparseIntArray sparseIntArray = zVar2.f287i;
                int i12 = sparseIntArray.get(keyAt);
                int size = sparseIntArray.size();
                while (i12 > 0) {
                    if (i12 == keyAt) {
                        break loop0;
                    }
                    int i13 = size - 1;
                    if (size < 0) {
                        break loop0;
                    }
                    i12 = sparseIntArray.get(i12);
                    size = i13;
                }
                zVar2.m(keyAt, this);
                i11++;
            }
            Log.e("MotionScene", "Cannot be derived from yourself");
            ArrayList arrayList = this.f1677i1;
            if (arrayList != null) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((MotionHelper) it.next()).getClass();
                }
            }
            if (b5 != null) {
                b5.b(this);
            }
            this.f1696w = this.f1698x;
        }
        z();
        t tVar = this.f1703z1;
        if (tVar == null) {
            a1.z zVar3 = this.f1688s;
            if (zVar3 != null && (yVar = zVar3.f281c) != null && yVar.f274n == 4) {
                r(1.0f);
                this.A1 = null;
                setState(v.f236b);
                setState(v.f237c);
            }
        } else if (this.C1) {
            post(new y0(10, this));
        } else {
            tVar.a();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v10, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v12, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v54, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r9v14, types: [a1.g, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r4v53 */
    /* JADX WARNING: type inference failed for: r4v55 */
    /* JADX WARNING: Incorrect type for immutable var: ssa=int, code=?, for r4v9, types: [boolean, int] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onInterceptTouchEvent(android.view.MotionEvent r25) {
        /*
            r24 = this;
            r0 = r24
            a1.z r1 = r0.f1688s
            r2 = 0
            if (r1 == 0) goto L_0x000b
            boolean r3 = r0.B
            if (r3 != 0) goto L_0x000e
        L_0x000b:
            r1 = 0
            goto L_0x04c3
        L_0x000e:
            r3 = -1
            r4 = 1
            pa.b r1 = r1.f295q
            if (r1 == 0) goto L_0x042e
            java.lang.Object r5 = r1.f24099a
            androidx.constraintlayout.motion.widget.MotionLayout r5 = (androidx.constraintlayout.motion.widget.MotionLayout) r5
            int r14 = r5.getCurrentState()
            if (r14 != r3) goto L_0x0020
            goto L_0x042e
        L_0x0020:
            java.lang.Object r5 = r1.f24101c
            java.util.HashSet r5 = (java.util.HashSet) r5
            if (r5 != 0) goto L_0x0067
            java.util.HashSet r5 = new java.util.HashSet
            r5.<init>()
            r1.f24101c = r5
            java.lang.Object r5 = r1.f24100b
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            java.util.Iterator r5 = r5.iterator()
        L_0x0035:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0067
            java.lang.Object r6 = r5.next()
            a1.d0 r6 = (a1.d0) r6
            java.lang.Object r7 = r1.f24099a
            androidx.constraintlayout.motion.widget.MotionLayout r7 = (androidx.constraintlayout.motion.widget.MotionLayout) r7
            int r7 = r7.getChildCount()
            r8 = 0
        L_0x004a:
            if (r8 >= r7) goto L_0x0035
            java.lang.Object r9 = r1.f24099a
            androidx.constraintlayout.motion.widget.MotionLayout r9 = (androidx.constraintlayout.motion.widget.MotionLayout) r9
            android.view.View r9 = r9.getChildAt(r8)
            boolean r10 = r6.a(r9)
            if (r10 == 0) goto L_0x0064
            r9.getId()
            java.lang.Object r10 = r1.f24101c
            java.util.HashSet r10 = (java.util.HashSet) r10
            r10.add(r9)
        L_0x0064:
            int r8 = r8 + 1
            goto L_0x004a
        L_0x0067:
            float r15 = r25.getX()
            float r13 = r25.getY()
            android.graphics.Rect r12 = new android.graphics.Rect
            r12.<init>()
            int r11 = r25.getAction()
            java.lang.Object r5 = r1.f24103e
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            r10 = 2
            if (r5 == 0) goto L_0x00bf
            boolean r5 = r5.isEmpty()
            if (r5 != 0) goto L_0x00bf
            java.lang.Object r5 = r1.f24103e
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            java.util.Iterator r5 = r5.iterator()
        L_0x008d:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x00bf
            java.lang.Object r6 = r5.next()
            a1.c0 r6 = (a1.c0) r6
            if (r11 == r4) goto L_0x00ba
            if (r11 == r10) goto L_0x00a1
            r6.getClass()
            goto L_0x008d
        L_0x00a1:
            a1.n r7 = r6.f96c
            android.view.View r7 = r7.f178b
            android.graphics.Rect r8 = r6.f105l
            r7.getHitRect(r8)
            int r7 = (int) r15
            int r9 = (int) r13
            boolean r7 = r8.contains(r7, r9)
            if (r7 != 0) goto L_0x008d
            boolean r7 = r6.f101h
            if (r7 != 0) goto L_0x008d
        L_0x00b6:
            r6.b()
            goto L_0x008d
        L_0x00ba:
            boolean r7 = r6.f101h
            if (r7 != 0) goto L_0x008d
            goto L_0x00b6
        L_0x00bf:
            if (r11 == 0) goto L_0x00c5
            if (r11 == r4) goto L_0x00c5
            goto L_0x042e
        L_0x00c5:
            java.lang.Object r5 = r1.f24099a
            androidx.constraintlayout.motion.widget.MotionLayout r5 = (androidx.constraintlayout.motion.widget.MotionLayout) r5
            a1.z r5 = r5.f1688s
            r16 = 0
            if (r5 != 0) goto L_0x00d2
            r9 = r16
            goto L_0x00d7
        L_0x00d2:
            c1.l r5 = r5.b(r14)
            r9 = r5
        L_0x00d7:
            java.lang.Object r5 = r1.f24100b
            java.util.ArrayList r5 = (java.util.ArrayList) r5
            java.util.Iterator r17 = r5.iterator()
        L_0x00df:
            boolean r5 = r17.hasNext()
            if (r5 == 0) goto L_0x042e
            java.lang.Object r5 = r17.next()
            r8 = r5
            a1.d0 r8 = (a1.d0) r8
            int r5 = r8.f109b
            if (r5 != r4) goto L_0x00f3
            if (r11 != 0) goto L_0x0416
            goto L_0x00fd
        L_0x00f3:
            if (r5 != r10) goto L_0x00f8
            if (r11 != r4) goto L_0x0416
            goto L_0x00fd
        L_0x00f8:
            r6 = 3
            if (r5 != r6) goto L_0x0416
            if (r11 != 0) goto L_0x0416
        L_0x00fd:
            java.lang.Object r5 = r1.f24101c
            java.util.HashSet r5 = (java.util.HashSet) r5
            java.util.Iterator r18 = r5.iterator()
        L_0x0105:
            boolean r5 = r18.hasNext()
            if (r5 == 0) goto L_0x0416
            java.lang.Object r5 = r18.next()
            android.view.View r5 = (android.view.View) r5
            boolean r6 = r8.a(r5)
            if (r6 != 0) goto L_0x0118
            goto L_0x0105
        L_0x0118:
            r5.getHitRect(r12)
            int r6 = (int) r15
            int r7 = (int) r13
            boolean r6 = r12.contains(r6, r7)
            if (r6 == 0) goto L_0x03fc
            java.lang.Object r6 = r1.f24099a
            androidx.constraintlayout.motion.widget.MotionLayout r6 = (androidx.constraintlayout.motion.widget.MotionLayout) r6
            android.view.View[] r7 = new android.view.View[r4]
            r7[r2] = r5
            boolean r2 = r8.f110c
            if (r2 == 0) goto L_0x0131
            goto L_0x03fc
        L_0x0131:
            int r2 = r8.f112e
            a1.g r3 = r8.f113f
            if (r2 != r10) goto L_0x02e4
            a1.n r7 = new a1.n
            r7.<init>(r5)
            a1.w r2 = r7.f182f
            r10 = 0
            r2.f243c = r10
            r2.f244d = r10
            r7.G = r4
            float r10 = r5.getX()
            float r4 = r5.getY()
            r21 = r9
            int r9 = r5.getWidth()
            float r9 = (float) r9
            r22 = r11
            int r11 = r5.getHeight()
            float r11 = (float) r11
            r2.f(r10, r4, r9, r11)
            float r2 = r5.getX()
            float r4 = r5.getY()
            int r9 = r5.getWidth()
            float r9 = (float) r9
            int r10 = r5.getHeight()
            float r10 = (float) r10
            a1.w r11 = r7.f183g
            r11.f(r2, r4, r9, r10)
            a1.l r2 = r7.f184h
            r2.getClass()
            r5.getX()
            r5.getY()
            r5.getWidth()
            r5.getHeight()
            int r4 = r5.getVisibility()
            r2.f160c = r4
            int r4 = r5.getVisibility()
            if (r4 == 0) goto L_0x0194
            r4 = 0
            goto L_0x0198
        L_0x0194:
            float r4 = r5.getAlpha()
        L_0x0198:
            r2.f158a = r4
            float r4 = r5.getElevation()
            r2.f161d = r4
            float r4 = r5.getRotation()
            r2.f162e = r4
            float r4 = r5.getRotationX()
            r2.f163f = r4
            float r4 = r5.getRotationY()
            r2.f164g = r4
            float r4 = r5.getScaleX()
            r2.f165h = r4
            float r4 = r5.getScaleY()
            r2.f166i = r4
            float r4 = r5.getPivotX()
            r2.f167j = r4
            float r4 = r5.getPivotY()
            r2.f168k = r4
            float r4 = r5.getTranslationX()
            r2.f169l = r4
            float r4 = r5.getTranslationY()
            r2.f170m = r4
            float r4 = r5.getTranslationZ()
            r2.f171n = r4
            a1.l r2 = r7.f185i
            r2.getClass()
            r5.getX()
            r5.getY()
            r5.getWidth()
            r5.getHeight()
            int r4 = r5.getVisibility()
            r2.f160c = r4
            int r4 = r5.getVisibility()
            if (r4 == 0) goto L_0x01fb
            r10 = 0
            goto L_0x01ff
        L_0x01fb:
            float r10 = r5.getAlpha()
        L_0x01ff:
            r2.f158a = r10
            float r4 = r5.getElevation()
            r2.f161d = r4
            float r4 = r5.getRotation()
            r2.f162e = r4
            float r4 = r5.getRotationX()
            r2.f163f = r4
            float r4 = r5.getRotationY()
            r2.f164g = r4
            float r4 = r5.getScaleX()
            r2.f165h = r4
            float r4 = r5.getScaleY()
            r2.f166i = r4
            float r4 = r5.getPivotX()
            r2.f167j = r4
            float r4 = r5.getPivotY()
            r2.f168k = r4
            float r4 = r5.getTranslationX()
            r2.f169l = r4
            float r4 = r5.getTranslationY()
            r2.f170m = r4
            float r4 = r5.getTranslationZ()
            r2.f171n = r4
            r2 = -1
            java.lang.Integer r4 = java.lang.Integer.valueOf(r2)
            java.util.HashMap r2 = r3.f145a
            java.lang.Object r2 = r2.get(r4)
            java.util.ArrayList r2 = (java.util.ArrayList) r2
            if (r2 == 0) goto L_0x0257
            java.util.ArrayList r3 = r7.f199w
            r3.addAll(r2)
        L_0x0257:
            int r2 = r6.getWidth()
            int r3 = r6.getHeight()
            long r4 = java.lang.System.nanoTime()
            r7.h(r2, r3, r4)
            a1.c0 r5 = new a1.c0
            int r2 = r8.f115h
            int r9 = r8.f116i
            int r10 = r8.f109b
            android.content.Context r3 = r6.getContext()
            int r4 = r8.f119l
            r6 = -2
            if (r4 == r6) goto L_0x02c1
            r6 = -1
            if (r4 == r6) goto L_0x02b3
            if (r4 == 0) goto L_0x02ad
            r3 = 1
            if (r4 == r3) goto L_0x02a7
            r3 = 2
            if (r4 == r3) goto L_0x02a1
            r3 = 4
            if (r4 == r3) goto L_0x029b
            r3 = 5
            if (r4 == r3) goto L_0x0295
            r3 = 6
            if (r4 == r3) goto L_0x028f
            r3 = r16
        L_0x028d:
            r11 = 2
            goto L_0x02c8
        L_0x028f:
            android.view.animation.AnticipateInterpolator r3 = new android.view.animation.AnticipateInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x0295:
            android.view.animation.OvershootInterpolator r3 = new android.view.animation.OvershootInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x029b:
            android.view.animation.BounceInterpolator r3 = new android.view.animation.BounceInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x02a1:
            android.view.animation.DecelerateInterpolator r3 = new android.view.animation.DecelerateInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x02a7:
            android.view.animation.AccelerateInterpolator r3 = new android.view.animation.AccelerateInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x02ad:
            android.view.animation.AccelerateDecelerateInterpolator r3 = new android.view.animation.AccelerateDecelerateInterpolator
            r3.<init>()
            goto L_0x028d
        L_0x02b3:
            java.lang.String r3 = r8.f120m
            v0.e r3 = v0.e.c(r3)
            a1.m r4 = new a1.m
            r11 = 2
            r4.<init>(r3, r11)
            r3 = r4
            goto L_0x02c8
        L_0x02c1:
            r11 = 2
            int r4 = r8.f121n
            android.view.animation.Interpolator r3 = android.view.animation.AnimationUtils.loadInterpolator(r3, r4)
        L_0x02c8:
            int r4 = r8.f123p
            int r6 = r8.f124q
            r19 = r6
            r6 = r1
            r20 = r1
            r1 = r8
            r8 = r2
            r2 = r21
            r21 = 2
            r11 = r3
            r23 = r12
            r12 = r4
            r4 = r13
            r13 = r19
            r5.<init>(r6, r7, r8, r9, r10, r11, r12, r13)
            r5 = r2
            goto L_0x0407
        L_0x02e4:
            r20 = r1
            r1 = r8
            r5 = r9
            r22 = r11
            r23 = r12
            r4 = r13
            r21 = 2
            c1.g r8 = r1.f114g
            r9 = 1
            if (r2 != r9) goto L_0x032b
            int[] r2 = r6.getConstraintSetIds()
            r9 = 0
        L_0x02f9:
            int r10 = r2.length
            if (r9 >= r10) goto L_0x032b
            r10 = r2[r9]
            if (r10 != r14) goto L_0x0301
            goto L_0x0328
        L_0x0301:
            a1.z r11 = r6.f1688s
            if (r11 != 0) goto L_0x0309
            r10 = r16
        L_0x0307:
            r11 = 0
            goto L_0x030e
        L_0x0309:
            c1.l r10 = r11.b(r10)
            goto L_0x0307
        L_0x030e:
            r12 = r7[r11]
            int r11 = r12.getId()
            c1.g r10 = r10.i(r11)
            if (r8 == 0) goto L_0x0328
            c1.f r11 = r8.f3805h
            if (r11 == 0) goto L_0x0321
            r11.e(r10)
        L_0x0321:
            java.util.HashMap r10 = r10.f3804g
            java.util.HashMap r11 = r8.f3804g
            r10.putAll(r11)
        L_0x0328:
            int r9 = r9 + 1
            goto L_0x02f9
        L_0x032b:
            c1.l r2 = new c1.l
            r2.<init>()
            java.util.HashMap r9 = r2.f3891f
            r9.clear()
            java.util.HashMap r10 = r5.f3891f
            java.util.Set r10 = r10.keySet()
            java.util.Iterator r10 = r10.iterator()
        L_0x033f:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x035e
            java.lang.Object r11 = r10.next()
            java.lang.Integer r11 = (java.lang.Integer) r11
            java.util.HashMap r12 = r5.f3891f
            java.lang.Object r12 = r12.get(r11)
            c1.g r12 = (c1.g) r12
            if (r12 != 0) goto L_0x0356
            goto L_0x033f
        L_0x0356:
            c1.g r12 = r12.clone()
            r9.put(r11, r12)
            goto L_0x033f
        L_0x035e:
            r11 = 0
            r9 = r7[r11]
            int r9 = r9.getId()
            c1.g r9 = r2.i(r9)
            if (r8 == 0) goto L_0x0379
            c1.f r10 = r8.f3805h
            if (r10 == 0) goto L_0x0372
            r10.e(r9)
        L_0x0372:
            java.util.HashMap r9 = r9.f3804g
            java.util.HashMap r8 = r8.f3804g
            r9.putAll(r8)
        L_0x0379:
            r6.G(r14, r2)
            r2 = 2131362707(0x7f0a0393, float:1.8345202E38)
            r6.G(r2, r5)
            r6.C(r2)
            a1.y r2 = new a1.y
            a1.z r8 = r6.f1688s
            r2.<init>((a1.z) r8, (int) r14)
            r8 = 0
            r9 = r7[r8]
            int r8 = r1.f115h
            r10 = -1
            if (r8 == r10) goto L_0x039c
            r10 = 8
            int r8 = java.lang.Math.max(r8, r10)
            r2.f268h = r8
        L_0x039c:
            int r8 = r1.f111d
            r2.f276p = r8
            int r8 = r1.f119l
            java.lang.String r10 = r1.f120m
            int r11 = r1.f121n
            r2.f265e = r8
            r2.f266f = r10
            r2.f267g = r11
            int r8 = r9.getId()
            if (r3 == 0) goto L_0x03ea
            java.util.HashMap r3 = r3.f145a
            r9 = -1
            java.lang.Integer r10 = java.lang.Integer.valueOf(r9)
            java.lang.Object r3 = r3.get(r10)
            java.util.ArrayList r3 = (java.util.ArrayList) r3
            a1.g r9 = new a1.g
            r9.<init>()
            java.util.HashMap r10 = new java.util.HashMap
            r10.<init>()
            r9.f145a = r10
            java.util.Iterator r3 = r3.iterator()
        L_0x03cf:
            boolean r10 = r3.hasNext()
            if (r10 == 0) goto L_0x03e5
            java.lang.Object r10 = r3.next()
            a1.c r10 = (a1.c) r10
            a1.c r10 = r10.b()
            r10.f91b = r8
            r9.b(r10)
            goto L_0x03cf
        L_0x03e5:
            java.util.ArrayList r3 = r2.f271k
            r3.add(r9)
        L_0x03ea:
            r6.setTransition((a1.y) r2)
            h.v0 r2 = new h.v0
            r3 = 29
            r2.<init>(r1, r3, r7)
            r3 = 1065353216(0x3f800000, float:1.0)
            r6.r(r3)
            r6.A1 = r2
            goto L_0x0407
        L_0x03fc:
            r20 = r1
            r1 = r8
            r5 = r9
            r22 = r11
            r23 = r12
            r4 = r13
            r21 = 2
        L_0x0407:
            r8 = r1
            r13 = r4
            r9 = r5
            r1 = r20
            r11 = r22
            r12 = r23
            r2 = 0
            r3 = -1
            r4 = 1
            r10 = 2
            goto L_0x0105
        L_0x0416:
            r20 = r1
            r5 = r9
            r22 = r11
            r23 = r12
            r4 = r13
            r21 = 2
            r13 = r4
            r9 = r5
            r1 = r20
            r11 = r22
            r12 = r23
            r2 = 0
            r3 = -1
            r4 = 1
            r10 = 2
            goto L_0x00df
        L_0x042e:
            a1.z r1 = r0.f1688s
            a1.y r1 = r1.f281c
            if (r1 == 0) goto L_0x04c2
            boolean r2 = r1.f275o
            r3 = 1
            r2 = r2 ^ r3
            if (r2 == 0) goto L_0x04c2
            a1.b0 r1 = r1.f272l
            if (r1 == 0) goto L_0x04c2
            int r2 = r25.getAction()
            if (r2 != 0) goto L_0x045f
            android.graphics.RectF r2 = new android.graphics.RectF
            r2.<init>()
            android.graphics.RectF r2 = r1.b(r0, r2)
            if (r2 == 0) goto L_0x045f
            float r3 = r25.getX()
            float r4 = r25.getY()
            boolean r2 = r2.contains(r3, r4)
            if (r2 != 0) goto L_0x045f
            r2 = 0
            return r2
        L_0x045f:
            int r1 = r1.f68e
            r2 = -1
            if (r1 == r2) goto L_0x04c2
            android.view.View r2 = r0.H1
            if (r2 == 0) goto L_0x046e
            int r2 = r2.getId()
            if (r2 == r1) goto L_0x0474
        L_0x046e:
            android.view.View r1 = r0.findViewById(r1)
            r0.H1 = r1
        L_0x0474:
            android.view.View r1 = r0.H1
            if (r1 == 0) goto L_0x04c2
            android.graphics.RectF r2 = r0.G1
            int r1 = r1.getLeft()
            float r1 = (float) r1
            android.view.View r3 = r0.H1
            int r3 = r3.getTop()
            float r3 = (float) r3
            android.view.View r4 = r0.H1
            int r4 = r4.getRight()
            float r4 = (float) r4
            android.view.View r5 = r0.H1
            int r5 = r5.getBottom()
            float r5 = (float) r5
            r2.set(r1, r3, r4, r5)
            float r1 = r25.getX()
            float r3 = r25.getY()
            boolean r1 = r2.contains(r1, r3)
            if (r1 == 0) goto L_0x04c2
            android.view.View r1 = r0.H1
            int r1 = r1.getLeft()
            float r1 = (float) r1
            android.view.View r2 = r0.H1
            int r2 = r2.getTop()
            float r2 = (float) r2
            android.view.View r3 = r0.H1
            r4 = r25
            boolean r1 = r0.y(r1, r2, r4, r3)
            if (r1 != 0) goto L_0x04c2
            boolean r1 = r24.onTouchEvent(r25)
            return r1
        L_0x04c2:
            r1 = 0
        L_0x04c3:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        this.f1701y1 = true;
        try {
            if (this.f1688s == null) {
                super.onLayout(z4, i10, i11, i12, i13);
                return;
            }
            int i14 = i12 - i10;
            int i15 = i13 - i11;
            if (!(this.Y0 == i14 && this.Z0 == i15)) {
                B();
                t(true);
            }
            this.Y0 = i14;
            this.Z0 = i15;
            this.f1701y1 = false;
        } finally {
            this.f1701y1 = false;
        }
    }

    public final void onMeasure(int i10, int i11) {
        boolean z4;
        int i12;
        boolean z10;
        float f10;
        int i13 = i10;
        int i14 = i11;
        if (this.f1688s == null) {
            super.onMeasure(i10, i11);
            return;
        }
        boolean z11 = true;
        if (this.f1702z == i13 && this.A == i14) {
            z4 = false;
        } else {
            z4 = true;
        }
        if (this.F1) {
            this.F1 = false;
            z();
            A();
            z4 = true;
        }
        if (this.f1805h) {
            z4 = true;
        }
        this.f1702z = i13;
        this.A = i14;
        int h10 = this.f1688s.h();
        y yVar = this.f1688s.f281c;
        if (yVar == null) {
            i12 = -1;
        } else {
            i12 = yVar.f263c;
        }
        f fVar = this.f1800c;
        r rVar = this.E1;
        if ((!z4 && h10 == rVar.f222b && i12 == rVar.f223c) || this.f1696w == -1) {
            if (z4) {
                super.onMeasure(i10, i11);
            }
            z10 = true;
        } else {
            super.onMeasure(i10, i11);
            rVar.g(this.f1688s.b(h10), this.f1688s.b(i12));
            rVar.i();
            rVar.f222b = h10;
            rVar.f223c = i12;
            z10 = false;
        }
        if (this.f1685p1 || z10) {
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int s10 = fVar.s() + getPaddingRight() + getPaddingLeft();
            int m10 = fVar.m() + paddingBottom;
            int i15 = this.f1693u1;
            if (i15 == Integer.MIN_VALUE || i15 == 0) {
                int i16 = this.f1686q1;
                s10 = (int) ((this.f1697w1 * ((float) (this.f1689s1 - i16))) + ((float) i16));
                requestLayout();
            }
            int i17 = this.f1695v1;
            if (i17 == Integer.MIN_VALUE || i17 == 0) {
                int i18 = this.f1687r1;
                m10 = (int) ((this.f1697w1 * ((float) (this.f1691t1 - i18))) + ((float) i18));
                requestLayout();
            }
            setMeasuredDimension(s10, m10);
        }
        float signum = Math.signum(this.I - this.G);
        long nanoTime = getNanoTime();
        o oVar = this.f1690t;
        if (!(oVar instanceof z0.a)) {
            f10 = ((((float) (nanoTime - this.H)) * signum) * 1.0E-9f) / this.E;
        } else {
            f10 = 0.0f;
        }
        float f11 = this.G + f10;
        if (this.J) {
            f11 = this.I;
        }
        int i19 = (signum > 0.0f ? 1 : (signum == 0.0f ? 0 : -1));
        if ((i19 <= 0 || f11 < this.I) && (signum > 0.0f || f11 > this.I)) {
            z11 = false;
        } else {
            f11 = this.I;
        }
        if (oVar != null && !z11) {
            if (this.O) {
                f11 = oVar.getInterpolation(((float) (nanoTime - this.D)) * 1.0E-9f);
            } else {
                f11 = oVar.getInterpolation(f11);
            }
        }
        if ((i19 > 0 && f11 >= this.I) || (signum <= 0.0f && f11 <= this.I)) {
            f11 = this.I;
        }
        this.f1697w1 = f11;
        int childCount = getChildCount();
        long nanoTime2 = getNanoTime();
        Interpolator interpolator = this.f1692u;
        if (interpolator != null) {
            f11 = interpolator.getInterpolation(f11);
        }
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt = getChildAt(i20);
            n nVar = (n) this.C.get(childAt);
            if (nVar != null) {
                nVar.e(f11, nanoTime2, childAt, this.f1699x1);
            }
        }
        if (this.f1685p1) {
            requestLayout();
        }
    }

    public final boolean onNestedFling(View view, float f10, float f11, boolean z4) {
        return false;
    }

    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    public final void onRtlPropertiesChanged(int i10) {
        a1.b0 b0Var;
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            boolean k10 = k();
            zVar.f294p = k10;
            y yVar = zVar.f281c;
            if (yVar != null && (b0Var = yVar.f272l) != null) {
                b0Var.c(k10);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:224:0x0560, code lost:
        if (1.0f > r4) goto L_0x0583;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:228:0x056c, code lost:
        if (1.0f > r11) goto L_0x0583;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:340:0x0772, code lost:
        if (1.0f > r4) goto L_0x0796;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:345:0x0781, code lost:
        if (1.0f > r2) goto L_0x0796;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00ee, code lost:
        if (r9.contains(r14.getX(), r14.getY()) == false) goto L_0x0109;
     */
    /* JADX WARNING: Removed duplicated region for block: B:192:0x04b9  */
    /* JADX WARNING: Removed duplicated region for block: B:193:0x04dc  */
    /* JADX WARNING: Removed duplicated region for block: B:196:0x04f7  */
    /* JADX WARNING: Removed duplicated region for block: B:198:0x0506  */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x0517  */
    /* JADX WARNING: Removed duplicated region for block: B:225:0x0563  */
    /* JADX WARNING: Removed duplicated region for block: B:362:0x07d4  */
    /* JADX WARNING: Removed duplicated region for block: B:364:0x07d9 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r35) {
        /*
            r34 = this;
            r0 = r34
            r1 = r35
            a1.z r2 = r0.f1688s
            if (r2 == 0) goto L_0x07db
            boolean r3 = r0.B
            if (r3 == 0) goto L_0x07db
            boolean r2 = r2.o()
            if (r2 == 0) goto L_0x07db
            a1.z r2 = r0.f1688s
            a1.y r3 = r2.f281c
            r4 = 1
            if (r3 == 0) goto L_0x0023
            boolean r3 = r3.f275o
            r3 = r3 ^ r4
            if (r3 != 0) goto L_0x0023
            boolean r1 = super.onTouchEvent(r35)
            return r1
        L_0x0023:
            int r3 = r34.getCurrentState()
            android.graphics.RectF r5 = new android.graphics.RectF
            r5.<init>()
            a1.s r6 = r2.f293o
            androidx.constraintlayout.motion.widget.MotionLayout r7 = r2.f279a
            if (r6 != 0) goto L_0x003f
            r7.getClass()
            a1.s r6 = a1.s.f228b
            android.view.VelocityTracker r8 = android.view.VelocityTracker.obtain()
            r6.f229a = r8
            r2.f293o = r6
        L_0x003f:
            a1.s r6 = r2.f293o
            android.view.VelocityTracker r6 = r6.f229a
            if (r6 == 0) goto L_0x0048
            r6.addMovement(r1)
        L_0x0048:
            r8 = 2
            r10 = -1
            if (r3 == r10) goto L_0x022e
            int r12 = r35.getAction()
            if (r12 == 0) goto L_0x01c6
            if (r12 == r8) goto L_0x0056
            goto L_0x022e
        L_0x0056:
            boolean r12 = r2.f291m
            if (r12 == 0) goto L_0x005c
            goto L_0x022e
        L_0x005c:
            float r12 = r35.getRawY()
            float r13 = r2.f297s
            float r12 = r12 - r13
            float r13 = r35.getRawX()
            float r14 = r2.f296r
            float r13 = r13 - r14
            double r14 = (double) r13
            r16 = 0
            int r18 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r18 != 0) goto L_0x0076
            double r14 = (double) r12
            int r18 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r18 == 0) goto L_0x07ca
        L_0x0076:
            android.view.MotionEvent r14 = r2.f290l
            if (r14 != 0) goto L_0x007c
            goto L_0x07ca
        L_0x007c:
            if (r3 == r10) goto L_0x018d
            c1.u r15 = r2.f280b
            if (r15 == 0) goto L_0x0089
            int r15 = r15.b(r3)
            if (r15 == r10) goto L_0x0089
            goto L_0x008a
        L_0x0089:
            r15 = r3
        L_0x008a:
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.ArrayList r10 = r2.f282d
            java.util.Iterator r10 = r10.iterator()
        L_0x0095:
            boolean r18 = r10.hasNext()
            if (r18 == 0) goto L_0x00b1
            java.lang.Object r18 = r10.next()
            r8 = r18
            a1.y r8 = (a1.y) r8
            int r4 = r8.f264d
            if (r4 == r15) goto L_0x00ab
            int r4 = r8.f263c
            if (r4 != r15) goto L_0x00ae
        L_0x00ab:
            r6.add(r8)
        L_0x00ae:
            r4 = 1
            r8 = 2
            goto L_0x0095
        L_0x00b1:
            android.graphics.RectF r4 = new android.graphics.RectF
            r4.<init>()
            java.util.Iterator r6 = r6.iterator()
            r8 = 0
            r10 = 0
        L_0x00bc:
            boolean r15 = r6.hasNext()
            if (r15 == 0) goto L_0x0189
            java.lang.Object r15 = r6.next()
            a1.y r15 = (a1.y) r15
            boolean r9 = r15.f275o
            if (r9 == 0) goto L_0x00cf
            r20 = r6
            goto L_0x0109
        L_0x00cf:
            a1.b0 r9 = r15.f272l
            if (r9 == 0) goto L_0x0171
            boolean r11 = r2.f294p
            r9.c(r11)
            a1.b0 r9 = r15.f272l
            android.graphics.RectF r9 = r9.b(r7, r4)
            if (r9 == 0) goto L_0x00f1
            float r11 = r14.getX()
            r20 = r6
            float r6 = r14.getY()
            boolean r6 = r9.contains(r11, r6)
            if (r6 != 0) goto L_0x00f3
            goto L_0x0109
        L_0x00f1:
            r20 = r6
        L_0x00f3:
            a1.b0 r6 = r15.f272l
            android.graphics.RectF r6 = r6.a(r7, r4)
            if (r6 == 0) goto L_0x010c
            float r9 = r14.getX()
            float r11 = r14.getY()
            boolean r6 = r6.contains(r9, r11)
            if (r6 != 0) goto L_0x010c
        L_0x0109:
            r6 = r20
            goto L_0x00bc
        L_0x010c:
            a1.b0 r6 = r15.f272l
            float r9 = r6.f74k
            float r9 = r9 * r13
            float r11 = r6.f75l
            float r11 = r11 * r12
            float r11 = r11 + r9
            boolean r6 = r6.f73j
            if (r6 == 0) goto L_0x0154
            float r6 = r14.getX()
            a1.b0 r9 = r15.f272l
            r9.getClass()
            r9 = 1056964608(0x3f000000, float:0.5)
            float r6 = r6 - r9
            float r11 = r14.getY()
            a1.b0 r9 = r15.f272l
            r9.getClass()
            r9 = 1056964608(0x3f000000, float:0.5)
            float r11 = r11 - r9
            float r9 = r13 + r6
            r21 = r4
            float r4 = r12 + r11
            r22 = r12
            r23 = r13
            double r12 = (double) r4
            r4 = r10
            double r9 = (double) r9
            double r9 = java.lang.Math.atan2(r12, r9)
            double r12 = (double) r6
            r24 = r4
            r6 = r5
            double r4 = (double) r11
            double r4 = java.lang.Math.atan2(r12, r4)
            double r9 = r9 - r4
            float r4 = (float) r9
            r5 = 1092616192(0x41200000, float:10.0)
            float r11 = r4 * r5
            goto L_0x015d
        L_0x0154:
            r21 = r4
            r6 = r5
            r24 = r10
            r22 = r12
            r23 = r13
        L_0x015d:
            int r4 = r15.f263c
            if (r4 != r3) goto L_0x0166
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
        L_0x0163:
            float r11 = r11 * r4
            goto L_0x016a
        L_0x0166:
            r4 = 1066192077(0x3f8ccccd, float:1.1)
            goto L_0x0163
        L_0x016a:
            int r4 = (r11 > r8 ? 1 : (r11 == r8 ? 0 : -1))
            if (r4 <= 0) goto L_0x017c
            r8 = r11
            r10 = r15
            goto L_0x017e
        L_0x0171:
            r21 = r4
            r20 = r6
            r24 = r10
            r22 = r12
            r23 = r13
            r6 = r5
        L_0x017c:
            r10 = r24
        L_0x017e:
            r5 = r6
            r6 = r20
            r4 = r21
            r12 = r22
            r13 = r23
            goto L_0x00bc
        L_0x0189:
            r6 = r5
            r24 = r10
            goto L_0x0190
        L_0x018d:
            r6 = r5
            a1.y r10 = r2.f281c
        L_0x0190:
            if (r10 == 0) goto L_0x022e
            r0.setTransition((a1.y) r10)
            a1.y r3 = r2.f281c
            a1.b0 r3 = r3.f272l
            android.graphics.RectF r3 = r3.b(r7, r6)
            if (r3 == 0) goto L_0x01b3
            android.view.MotionEvent r4 = r2.f290l
            float r4 = r4.getX()
            android.view.MotionEvent r5 = r2.f290l
            float r5 = r5.getY()
            boolean r3 = r3.contains(r4, r5)
            if (r3 != 0) goto L_0x01b3
            r3 = 1
            goto L_0x01b4
        L_0x01b3:
            r3 = 0
        L_0x01b4:
            r2.f292n = r3
            a1.y r3 = r2.f281c
            a1.b0 r3 = r3.f272l
            float r4 = r2.f296r
            float r5 = r2.f297s
            r3.f79p = r4
            r3.f80q = r5
            r4 = 0
            r3.f76m = r4
            goto L_0x022e
        L_0x01c6:
            r6 = r5
            r4 = 0
            float r3 = r35.getRawX()
            r2.f296r = r3
            float r3 = r35.getRawY()
            r2.f297s = r3
            r2.f290l = r1
            r2.f291m = r4
            a1.y r1 = r2.f281c
            a1.b0 r1 = r1.f272l
            if (r1 == 0) goto L_0x07ca
            android.graphics.RectF r1 = r1.a(r7, r6)
            if (r1 == 0) goto L_0x01fe
            android.view.MotionEvent r3 = r2.f290l
            float r3 = r3.getX()
            android.view.MotionEvent r4 = r2.f290l
            float r4 = r4.getY()
            boolean r1 = r1.contains(r3, r4)
            if (r1 != 0) goto L_0x01fe
            r1 = 0
            r2.f290l = r1
            r1 = 1
            r2.f291m = r1
            goto L_0x07ca
        L_0x01fe:
            a1.y r1 = r2.f281c
            a1.b0 r1 = r1.f272l
            android.graphics.RectF r1 = r1.b(r7, r6)
            if (r1 == 0) goto L_0x021e
            android.view.MotionEvent r3 = r2.f290l
            float r3 = r3.getX()
            android.view.MotionEvent r4 = r2.f290l
            float r4 = r4.getY()
            boolean r1 = r1.contains(r3, r4)
            if (r1 != 0) goto L_0x021e
            r1 = 1
        L_0x021b:
            r2.f292n = r1
            goto L_0x0220
        L_0x021e:
            r1 = 0
            goto L_0x021b
        L_0x0220:
            a1.y r1 = r2.f281c
            a1.b0 r1 = r1.f272l
            float r3 = r2.f296r
            float r2 = r2.f297s
            r1.f79p = r3
            r1.f80q = r2
            goto L_0x07ca
        L_0x022e:
            boolean r3 = r2.f291m
            if (r3 == 0) goto L_0x0234
            goto L_0x07ca
        L_0x0234:
            a1.y r3 = r2.f281c
            if (r3 == 0) goto L_0x0794
            a1.b0 r3 = r3.f272l
            if (r3 == 0) goto L_0x0794
            boolean r4 = r2.f292n
            if (r4 != 0) goto L_0x0794
            a1.s r4 = r2.f293o
            boolean r5 = r3.f73j
            a1.v r6 = a1.v.f238d
            float[] r7 = r3.f77n
            androidx.constraintlayout.motion.widget.MotionLayout r8 = r3.f81r
            if (r5 == 0) goto L_0x0587
            android.view.VelocityTracker r5 = r4.f229a
            if (r5 == 0) goto L_0x0253
            r5.addMovement(r1)
        L_0x0253:
            int r5 = r35.getAction()
            if (r5 == 0) goto L_0x0572
            int[] r9 = r3.f78o
            r24 = 1135869952(0x43b40000, float:360.0)
            r25 = 1073741824(0x40000000, float:2.0)
            r10 = 1
            if (r5 == r10) goto L_0x0407
            r10 = 2
            if (r5 == r10) goto L_0x0269
        L_0x0265:
            r32 = r2
            goto L_0x0583
        L_0x0269:
            r35.getRawY()
            r35.getRawX()
            int r5 = r8.getWidth()
            float r5 = (float) r5
            float r5 = r5 / r25
            int r6 = r8.getHeight()
            float r6 = (float) r6
            float r6 = r6 / r25
            int r10 = r3.f72i
            r11 = -1
            if (r10 == r11) goto L_0x02b1
            android.view.View r5 = r8.findViewById(r10)
            r8.getLocationOnScreen(r9)
            r6 = 0
            r6 = r9[r6]
            float r6 = (float) r6
            int r10 = r5.getLeft()
            int r11 = r5.getRight()
            int r11 = r11 + r10
            float r10 = (float) r11
            float r10 = r10 / r25
            float r6 = r6 + r10
            r10 = 1
            r9 = r9[r10]
            float r9 = (float) r9
            int r10 = r5.getTop()
            int r5 = r5.getBottom()
            int r5 = r5 + r10
            float r5 = (float) r5
            float r5 = r5 / r25
            float r5 = r5 + r9
            r33 = r6
            r6 = r5
            r5 = r33
            goto L_0x02f9
        L_0x02b1:
            int r10 = r3.f67d
            r11 = -1
            if (r10 == r11) goto L_0x02f9
            java.util.HashMap r11 = r8.C
            android.view.View r10 = r8.findViewById(r10)
            java.lang.Object r10 = r11.get(r10)
            a1.n r10 = (a1.n) r10
            a1.w r10 = r10.f182f
            int r10 = r10.f251k
            android.view.View r10 = r8.findViewById(r10)
            if (r10 != 0) goto L_0x02d4
            java.lang.String r9 = "TouchResponse"
            java.lang.String r10 = "could not find view to animate to"
            android.util.Log.e(r9, r10)
            goto L_0x02f9
        L_0x02d4:
            r8.getLocationOnScreen(r9)
            r5 = 0
            r5 = r9[r5]
            float r5 = (float) r5
            int r6 = r10.getLeft()
            int r11 = r10.getRight()
            int r11 = r11 + r6
            float r6 = (float) r11
            float r6 = r6 / r25
            float r5 = r5 + r6
            r6 = 1
            r9 = r9[r6]
            float r6 = (float) r9
            int r9 = r10.getTop()
            int r10 = r10.getBottom()
            int r10 = r10 + r9
            float r9 = (float) r10
            float r9 = r9 / r25
            float r6 = r6 + r9
        L_0x02f9:
            float r9 = r35.getRawX()
            float r9 = r9 - r5
            float r10 = r35.getRawY()
            float r10 = r10 - r6
            float r11 = r35.getRawY()
            float r11 = r11 - r6
            double r14 = (double) r11
            float r11 = r35.getRawX()
            float r11 = r11 - r5
            double r12 = (double) r11
            double r11 = java.lang.Math.atan2(r14, r12)
            float r13 = r3.f80q
            float r13 = r13 - r6
            double r13 = (double) r13
            float r6 = r3.f79p
            float r6 = r6 - r5
            double r5 = (double) r6
            double r5 = java.lang.Math.atan2(r13, r5)
            double r5 = r11 - r5
            r13 = 4640537203540230144(0x4066800000000000, double:180.0)
            double r5 = r5 * r13
            r13 = 4614256656552045848(0x400921fb54442d18, double:3.141592653589793)
            double r5 = r5 / r13
            float r5 = (float) r5
            r6 = 1134886912(0x43a50000, float:330.0)
            int r6 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r6 <= 0) goto L_0x0338
            float r5 = r5 - r24
            goto L_0x0340
        L_0x0338:
            r6 = -1012596736(0xffffffffc3a50000, float:-330.0)
            int r6 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r6 >= 0) goto L_0x0340
            float r5 = r5 + r24
        L_0x0340:
            float r6 = java.lang.Math.abs(r5)
            double r13 = (double) r6
            r19 = 4576918229304087675(0x3f847ae147ae147b, double:0.01)
            int r6 = (r13 > r19 ? 1 : (r13 == r19 ? 0 : -1))
            if (r6 > 0) goto L_0x0352
            boolean r6 = r3.f76m
            if (r6 == 0) goto L_0x0265
        L_0x0352:
            float r6 = r8.getProgress()
            boolean r13 = r3.f76m
            if (r13 != 0) goto L_0x0360
            r13 = 1
            r3.f76m = r13
            r8.setProgress(r6)
        L_0x0360:
            int r13 = r3.f67d
            r14 = -1
            if (r13 == r14) goto L_0x038a
            androidx.constraintlayout.motion.widget.MotionLayout r14 = r3.f81r
            float r15 = r3.f71h
            float r0 = r3.f70g
            r32 = r2
            float[] r2 = r3.f77n
            r26 = r14
            r27 = r13
            r28 = r6
            r29 = r15
            r30 = r0
            r31 = r2
            r26.w(r27, r28, r29, r30, r31)
            r0 = 1
            r2 = r7[r0]
            double r13 = (double) r2
            double r13 = java.lang.Math.toDegrees(r13)
            float r2 = (float) r13
            r7[r0] = r2
            goto L_0x038f
        L_0x038a:
            r32 = r2
            r0 = 1
            r7[r0] = r24
        L_0x038f:
            float r2 = r3.f85v
            float r5 = r5 * r2
            r2 = r7[r0]
            float r5 = r5 / r2
            float r5 = r5 + r6
            r0 = 1065353216(0x3f800000, float:1.0)
            float r2 = java.lang.Math.min(r5, r0)
            r5 = 0
            float r2 = java.lang.Math.max(r2, r5)
            float r6 = r8.getProgress()
            int r7 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r7 == 0) goto L_0x03f7
            int r7 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1))
            if (r7 == 0) goto L_0x03b2
            int r0 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x03b5
        L_0x03b2:
            r8.s()
        L_0x03b5:
            r8.setProgress(r2)
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x03c1
            r2 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r2)
        L_0x03c1:
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x03ca
            float r0 = r0.getXVelocity()
            goto L_0x03cb
        L_0x03ca:
            r0 = 0
        L_0x03cb:
            android.view.VelocityTracker r2 = r4.f229a
            if (r2 == 0) goto L_0x03d4
            float r6 = r2.getYVelocity()
            goto L_0x03d5
        L_0x03d4:
            r6 = 0
        L_0x03d5:
            double r4 = (double) r6
            double r6 = (double) r0
            double r13 = java.lang.Math.hypot(r4, r6)
            double r4 = java.lang.Math.atan2(r4, r6)
            double r4 = r4 - r11
            double r4 = java.lang.Math.sin(r4)
            double r4 = r4 * r13
            double r6 = (double) r9
            double r9 = (double) r10
            double r6 = java.lang.Math.hypot(r6, r9)
            double r4 = r4 / r6
            float r0 = (float) r4
            double r4 = (double) r0
            double r4 = java.lang.Math.toDegrees(r4)
            float r0 = (float) r4
        L_0x03f4:
            r8.f1694v = r0
            goto L_0x03f9
        L_0x03f7:
            r0 = 0
            goto L_0x03f4
        L_0x03f9:
            float r0 = r35.getRawX()
            r3.f79p = r0
            float r0 = r35.getRawY()
            r3.f80q = r0
            goto L_0x0583
        L_0x0407:
            r32 = r2
            r0 = 0
            r3.f76m = r0
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x0415
            r2 = 16
            r0.computeCurrentVelocity(r2)
        L_0x0415:
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x041e
            float r0 = r0.getXVelocity()
            goto L_0x041f
        L_0x041e:
            r0 = 0
        L_0x041f:
            android.view.VelocityTracker r2 = r4.f229a
            if (r2 == 0) goto L_0x0428
            float r2 = r2.getYVelocity()
            goto L_0x0429
        L_0x0428:
            r2 = 0
        L_0x0429:
            float r4 = r8.getProgress()
            int r5 = r8.getWidth()
            float r5 = (float) r5
            float r5 = r5 / r25
            int r10 = r8.getHeight()
            float r10 = (float) r10
            float r10 = r10 / r25
            int r12 = r3.f72i
            r13 = -1
            if (r12 == r13) goto L_0x046f
            android.view.View r5 = r8.findViewById(r12)
            r8.getLocationOnScreen(r9)
            r10 = 0
            r10 = r9[r10]
            float r10 = (float) r10
            int r12 = r5.getLeft()
            int r13 = r5.getRight()
            int r13 = r13 + r12
            float r12 = (float) r13
            float r12 = r12 / r25
            float r10 = r10 + r12
            r12 = 1
            r9 = r9[r12]
        L_0x045b:
            float r9 = (float) r9
            int r12 = r5.getTop()
            int r5 = r5.getBottom()
            int r5 = r5 + r12
            float r5 = (float) r5
            float r5 = r5 / r25
            float r5 = r5 + r9
            r33 = r10
            r10 = r5
            r5 = r33
            goto L_0x04a0
        L_0x046f:
            int r12 = r3.f67d
            r13 = -1
            if (r12 == r13) goto L_0x04a0
            java.util.HashMap r5 = r8.C
            android.view.View r10 = r8.findViewById(r12)
            java.lang.Object r5 = r5.get(r10)
            a1.n r5 = (a1.n) r5
            a1.w r5 = r5.f182f
            int r5 = r5.f251k
            android.view.View r5 = r8.findViewById(r5)
            r8.getLocationOnScreen(r9)
            r10 = 0
            r10 = r9[r10]
            float r10 = (float) r10
            int r12 = r5.getLeft()
            int r13 = r5.getRight()
            int r13 = r13 + r12
            float r12 = (float) r13
            float r12 = r12 / r25
            float r10 = r10 + r12
            r12 = 1
            r9 = r9[r12]
            goto L_0x045b
        L_0x04a0:
            float r9 = r35.getRawX()
            float r9 = r9 - r5
            float r5 = r35.getRawY()
            float r5 = r5 - r10
            double r12 = (double) r5
            double r14 = (double) r9
            double r12 = java.lang.Math.atan2(r12, r14)
            double r12 = java.lang.Math.toDegrees(r12)
            int r10 = r3.f67d
            r14 = -1
            if (r10 == r14) goto L_0x04dc
            androidx.constraintlayout.motion.widget.MotionLayout r14 = r3.f81r
            float r15 = r3.f71h
            float r11 = r3.f70g
            float[] r1 = r3.f77n
            r26 = r14
            r27 = r10
            r28 = r4
            r29 = r15
            r30 = r11
            r31 = r1
            r26.w(r27, r28, r29, r30, r31)
            r1 = 1
            r10 = r7[r1]
            double r10 = (double) r10
            double r10 = java.lang.Math.toDegrees(r10)
            float r10 = (float) r10
            r7[r1] = r10
            goto L_0x04df
        L_0x04dc:
            r1 = 1
            r7[r1] = r24
        L_0x04df:
            float r2 = r2 + r5
            double r1 = (double) r2
            float r0 = r0 + r9
            double r9 = (double) r0
            double r0 = java.lang.Math.atan2(r1, r9)
            double r0 = java.lang.Math.toDegrees(r0)
            double r0 = r0 - r12
            float r0 = (float) r0
            r1 = 1115291648(0x427a0000, float:62.5)
            float r0 = r0 * r1
            boolean r1 = java.lang.Float.isNaN(r0)
            if (r1 != 0) goto L_0x0506
            r1 = 1077936128(0x40400000, float:3.0)
            float r11 = r0 * r1
            float r1 = r3.f85v
            float r11 = r11 * r1
            r1 = 1
            r2 = r7[r1]
            float r11 = r11 / r2
            float r11 = r11 + r4
        L_0x0504:
            r1 = 0
            goto L_0x0508
        L_0x0506:
            r11 = r4
            goto L_0x0504
        L_0x0508:
            int r2 = (r11 > r1 ? 1 : (r11 == r1 ? 0 : -1))
            if (r2 == 0) goto L_0x0563
            r1 = 1065353216(0x3f800000, float:1.0)
            int r2 = (r11 > r1 ? 1 : (r11 == r1 ? 0 : -1))
            if (r2 == 0) goto L_0x0563
            int r1 = r3.f66c
            r2 = 3
            if (r1 == r2) goto L_0x0563
            float r2 = r3.f85v
            float r0 = r0 * r2
            r2 = 1
            r5 = r7[r2]
            float r0 = r0 / r5
            double r9 = (double) r11
            r11 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            int r2 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r2 >= 0) goto L_0x0529
            r2 = 0
        L_0x0527:
            r5 = 6
            goto L_0x052c
        L_0x0529:
            r2 = 1065353216(0x3f800000, float:1.0)
            goto L_0x0527
        L_0x052c:
            if (r1 != r5) goto L_0x053b
            float r1 = r4 + r0
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 >= 0) goto L_0x0539
            float r0 = java.lang.Math.abs(r0)
        L_0x0539:
            r2 = 1065353216(0x3f800000, float:1.0)
        L_0x053b:
            int r1 = r3.f66c
            r5 = 7
            if (r1 != r5) goto L_0x054e
            float r1 = r4 + r0
            r2 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L_0x054d
            float r0 = java.lang.Math.abs(r0)
            float r0 = -r0
        L_0x054d:
            r2 = 0
        L_0x054e:
            int r1 = r3.f66c
            r3 = 1077936128(0x40400000, float:3.0)
            float r0 = r0 * r3
            r8.E(r1, r2, r0)
            r0 = 0
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 >= 0) goto L_0x056e
            r0 = 1065353216(0x3f800000, float:1.0)
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 > 0) goto L_0x0583
            goto L_0x056e
        L_0x0563:
            r0 = 0
            int r0 = (r0 > r11 ? 1 : (r0 == r11 ? 0 : -1))
            if (r0 >= 0) goto L_0x056e
            r0 = 1065353216(0x3f800000, float:1.0)
            int r0 = (r0 > r11 ? 1 : (r0 == r11 ? 0 : -1))
            if (r0 > 0) goto L_0x0583
        L_0x056e:
            r8.setState(r6)
            goto L_0x0583
        L_0x0572:
            r32 = r2
            float r0 = r35.getRawX()
            r3.f79p = r0
            float r0 = r35.getRawY()
            r3.f80q = r0
            r0 = 0
            r3.f76m = r0
        L_0x0583:
            r1 = r35
            goto L_0x0796
        L_0x0587:
            r32 = r2
            android.view.VelocityTracker r0 = r4.f229a
            r1 = r35
            if (r0 == 0) goto L_0x0592
            r0.addMovement(r1)
        L_0x0592:
            int r0 = r35.getAction()
            if (r0 == 0) goto L_0x0784
            r2 = 1
            if (r0 == r2) goto L_0x06b5
            r2 = 2
            if (r0 == r2) goto L_0x05a0
            goto L_0x0796
        L_0x05a0:
            float r0 = r35.getRawY()
            float r2 = r3.f80q
            float r0 = r0 - r2
            float r2 = r35.getRawX()
            float r5 = r3.f79p
            float r2 = r2 - r5
            float r5 = r3.f74k
            float r5 = r5 * r2
            float r6 = r3.f75l
            float r6 = r6 * r0
            float r6 = r6 + r5
            float r5 = java.lang.Math.abs(r6)
            float r6 = r3.f87x
            int r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1))
            if (r5 > 0) goto L_0x05c5
            boolean r5 = r3.f76m
            if (r5 == 0) goto L_0x0796
        L_0x05c5:
            float r5 = r8.getProgress()
            boolean r6 = r3.f76m
            if (r6 != 0) goto L_0x05d3
            r6 = 1
            r3.f76m = r6
            r8.setProgress(r5)
        L_0x05d3:
            int r10 = r3.f67d
            r6 = -1
            if (r10 == r6) goto L_0x05e7
            androidx.constraintlayout.motion.widget.MotionLayout r9 = r3.f81r
            float r12 = r3.f71h
            float r13 = r3.f70g
            float[] r14 = r3.f77n
            r11 = r5
            r9.w(r10, r11, r12, r13, r14)
            r9 = 0
            r10 = 1
            goto L_0x0602
        L_0x05e7:
            int r6 = r8.getWidth()
            int r9 = r8.getHeight()
            int r6 = java.lang.Math.min(r6, r9)
            float r6 = (float) r6
            float r9 = r3.f75l
            float r9 = r9 * r6
            r10 = 1
            r7[r10] = r9
            float r9 = r3.f74k
            float r6 = r6 * r9
            r9 = 0
            r7[r9] = r6
        L_0x0602:
            float r6 = r3.f74k
            r11 = r7[r9]
            float r6 = r6 * r11
            float r9 = r3.f75l
            r11 = r7[r10]
            float r9 = r9 * r11
            float r9 = r9 + r6
            float r6 = r3.f85v
            float r9 = r9 * r6
            float r6 = java.lang.Math.abs(r9)
            double r11 = (double) r6
            r6 = 1008981770(0x3c23d70a, float:0.01)
            r13 = 4576918229304087675(0x3f847ae147ae147b, double:0.01)
            int r9 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r9 >= 0) goto L_0x062a
            r9 = 0
            r7[r9] = r6
            r7[r10] = r6
            goto L_0x062b
        L_0x062a:
            r9 = 0
        L_0x062b:
            float r11 = r3.f74k
            r12 = 0
            int r11 = (r11 > r12 ? 1 : (r11 == r12 ? 0 : -1))
            if (r11 == 0) goto L_0x0636
            r0 = r7[r9]
            float r2 = r2 / r0
            goto L_0x063a
        L_0x0636:
            r2 = r7[r10]
            float r2 = r0 / r2
        L_0x063a:
            float r5 = r5 + r2
            r0 = 1065353216(0x3f800000, float:1.0)
            float r2 = java.lang.Math.min(r5, r0)
            float r0 = java.lang.Math.max(r2, r12)
            int r2 = r3.f66c
            r5 = 6
            if (r2 != r5) goto L_0x064e
            float r0 = java.lang.Math.max(r0, r6)
        L_0x064e:
            int r2 = r3.f66c
            r5 = 7
            if (r2 != r5) goto L_0x065a
            r2 = 1065185444(0x3f7d70a4, float:0.99)
            float r0 = java.lang.Math.min(r0, r2)
        L_0x065a:
            float r2 = r8.getProgress()
            int r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r5 == 0) goto L_0x06a4
            r5 = 0
            int r6 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r6 == 0) goto L_0x066d
            r5 = 1065353216(0x3f800000, float:1.0)
            int r2 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r2 != 0) goto L_0x0670
        L_0x066d:
            r8.s()
        L_0x0670:
            r8.setProgress(r0)
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x067c
            r2 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r2)
        L_0x067c:
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x0685
            float r0 = r0.getXVelocity()
            goto L_0x0686
        L_0x0685:
            r0 = 0
        L_0x0686:
            android.view.VelocityTracker r2 = r4.f229a
            if (r2 == 0) goto L_0x068f
            float r2 = r2.getYVelocity()
            goto L_0x0690
        L_0x068f:
            r2 = 0
        L_0x0690:
            float r4 = r3.f74k
            r5 = 0
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 == 0) goto L_0x069c
            r4 = 0
            r2 = r7[r4]
            float r0 = r0 / r2
            goto L_0x06a1
        L_0x069c:
            r0 = 1
            r4 = r7[r0]
            float r0 = r2 / r4
        L_0x06a1:
            r8.f1694v = r0
            goto L_0x06a7
        L_0x06a4:
            r5 = 0
            r8.f1694v = r5
        L_0x06a7:
            float r0 = r35.getRawX()
            r3.f79p = r0
            float r0 = r35.getRawY()
            r3.f80q = r0
            goto L_0x0796
        L_0x06b5:
            r0 = 0
            r3.f76m = r0
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x06c1
            r2 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r2)
        L_0x06c1:
            android.view.VelocityTracker r0 = r4.f229a
            if (r0 == 0) goto L_0x06ca
            float r0 = r0.getXVelocity()
            goto L_0x06cb
        L_0x06ca:
            r0 = 0
        L_0x06cb:
            android.view.VelocityTracker r2 = r4.f229a
            if (r2 == 0) goto L_0x06d4
            float r2 = r2.getYVelocity()
            goto L_0x06d5
        L_0x06d4:
            r2 = 0
        L_0x06d5:
            float r4 = r8.getProgress()
            int r10 = r3.f67d
            r5 = -1
            if (r10 == r5) goto L_0x06ed
            androidx.constraintlayout.motion.widget.MotionLayout r9 = r3.f81r
            float r12 = r3.f71h
            float r13 = r3.f70g
            float[] r14 = r3.f77n
            r11 = r4
            r9.w(r10, r11, r12, r13, r14)
            r9 = 0
            r10 = 1
            goto L_0x0708
        L_0x06ed:
            int r5 = r8.getWidth()
            int r9 = r8.getHeight()
            int r5 = java.lang.Math.min(r5, r9)
            float r5 = (float) r5
            float r9 = r3.f75l
            float r9 = r9 * r5
            r10 = 1
            r7[r10] = r9
            float r9 = r3.f74k
            float r5 = r5 * r9
            r9 = 0
            r7[r9] = r5
        L_0x0708:
            float r5 = r3.f74k
            r9 = r7[r9]
            r7 = r7[r10]
            r10 = 0
            int r5 = (r5 > r10 ? 1 : (r5 == r10 ? 0 : -1))
            if (r5 == 0) goto L_0x0715
            float r0 = r0 / r9
            goto L_0x0717
        L_0x0715:
            float r0 = r2 / r7
        L_0x0717:
            boolean r2 = java.lang.Float.isNaN(r0)
            if (r2 != 0) goto L_0x0724
            r2 = 1077936128(0x40400000, float:3.0)
            float r2 = r0 / r2
            float r2 = r2 + r4
        L_0x0722:
            r5 = 0
            goto L_0x0726
        L_0x0724:
            r2 = r4
            goto L_0x0722
        L_0x0726:
            int r7 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r7 == 0) goto L_0x0778
            r5 = 1065353216(0x3f800000, float:1.0)
            int r7 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r7 == 0) goto L_0x0778
            int r5 = r3.f66c
            r7 = 3
            if (r5 == r7) goto L_0x0778
            double r9 = (double) r2
            r11 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            int r2 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r2 >= 0) goto L_0x073f
            r2 = 0
        L_0x073d:
            r7 = 6
            goto L_0x0742
        L_0x073f:
            r2 = 1065353216(0x3f800000, float:1.0)
            goto L_0x073d
        L_0x0742:
            if (r5 != r7) goto L_0x0751
            float r2 = r4 + r0
            r5 = 0
            int r2 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r2 >= 0) goto L_0x074f
            float r0 = java.lang.Math.abs(r0)
        L_0x074f:
            r2 = 1065353216(0x3f800000, float:1.0)
        L_0x0751:
            int r5 = r3.f66c
            r7 = 7
            if (r5 != r7) goto L_0x0764
            float r2 = r4 + r0
            r5 = 1065353216(0x3f800000, float:1.0)
            int r2 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r2 <= 0) goto L_0x0763
            float r0 = java.lang.Math.abs(r0)
            float r0 = -r0
        L_0x0763:
            r2 = 0
        L_0x0764:
            int r3 = r3.f66c
            r8.E(r3, r2, r0)
            r0 = 0
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 >= 0) goto L_0x0774
            r0 = 1065353216(0x3f800000, float:1.0)
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 > 0) goto L_0x0796
        L_0x0774:
            r8.setState(r6)
            goto L_0x0796
        L_0x0778:
            r0 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 >= 0) goto L_0x0774
            r0 = 1065353216(0x3f800000, float:1.0)
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 > 0) goto L_0x0796
            goto L_0x0774
        L_0x0784:
            float r0 = r35.getRawX()
            r3.f79p = r0
            float r0 = r35.getRawY()
            r3.f80q = r0
            r0 = 0
            r3.f76m = r0
            goto L_0x0796
        L_0x0794:
            r32 = r2
        L_0x0796:
            float r0 = r35.getRawX()
            r2 = r32
            r2.f296r = r0
            float r0 = r35.getRawY()
            r2.f297s = r0
            int r0 = r35.getAction()
            r1 = 1
            if (r0 != r1) goto L_0x07c8
            a1.s r0 = r2.f293o
            if (r0 == 0) goto L_0x07c8
            android.view.VelocityTracker r1 = r0.f229a
            if (r1 == 0) goto L_0x07ba
            r1.recycle()
            r1 = 0
            r0.f229a = r1
            goto L_0x07bb
        L_0x07ba:
            r1 = 0
        L_0x07bb:
            r2.f293o = r1
            r0 = r34
            int r1 = r0.f1698x
            r3 = -1
            if (r1 == r3) goto L_0x07ca
            r2.a(r1, r0)
            goto L_0x07ca
        L_0x07c8:
            r0 = r34
        L_0x07ca:
            a1.z r1 = r0.f1688s
            a1.y r1 = r1.f281c
            int r2 = r1.f278r
            r2 = r2 & 4
            if (r2 == 0) goto L_0x07d9
            a1.b0 r1 = r1.f272l
            boolean r1 = r1.f76m
            return r1
        L_0x07d9:
            r1 = 1
            return r1
        L_0x07db:
            boolean r1 = super.onTouchEvent(r35)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof MotionHelper) {
            MotionHelper motionHelper = (MotionHelper) view;
            if (this.f1678j1 == null) {
                this.f1678j1 = new CopyOnWriteArrayList();
            }
            this.f1678j1.add(motionHelper);
            if (motionHelper.f1665i) {
                if (this.f1675g1 == null) {
                    this.f1675g1 = new ArrayList();
                }
                this.f1675g1.add(motionHelper);
            }
            if (motionHelper.f1666j) {
                if (this.f1676h1 == null) {
                    this.f1676h1 = new ArrayList();
                }
                this.f1676h1.add(motionHelper);
            }
            if (motionHelper instanceof MotionEffect) {
                if (this.f1677i1 == null) {
                    this.f1677i1 = new ArrayList();
                }
                this.f1677i1.add(motionHelper);
            }
        }
    }

    public final void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList arrayList = this.f1675g1;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList arrayList2 = this.f1676h1;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    public final void r(float f10) {
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            float f11 = this.G;
            float f12 = this.F;
            if (f11 != f12 && this.J) {
                this.G = f12;
            }
            float f13 = this.G;
            if (f13 != f10) {
                this.O = false;
                this.I = f10;
                this.E = ((float) zVar.c()) / 1000.0f;
                setProgress(this.I);
                this.f1690t = null;
                this.f1692u = this.f1688s.e();
                this.J = false;
                this.D = getNanoTime();
                this.K = true;
                this.F = f13;
                this.G = f13;
                invalidate();
            }
        }
    }

    public final void requestLayout() {
        a1.z zVar;
        y yVar;
        if (!this.f1685p1 && this.f1698x == -1 && (zVar = this.f1688s) != null && (yVar = zVar.f281c) != null) {
            int i10 = yVar.f277q;
            if (i10 != 0) {
                if (i10 == 2) {
                    int childCount = getChildCount();
                    for (int i11 = 0; i11 < childCount; i11++) {
                        ((n) this.C.get(getChildAt(i11))).f180d = true;
                    }
                    return;
                }
            } else {
                return;
            }
        }
        super.requestLayout();
    }

    public final void s() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            n nVar = (n) this.C.get(getChildAt(i10));
            if (nVar != null) {
                "button".equals(b0.n(nVar.f178b));
            }
        }
    }

    public void setDebugMode(int i10) {
        this.M = i10;
        invalidate();
    }

    public void setDelayedApplicationOfInitialState(boolean z4) {
        this.C1 = z4;
    }

    public void setInteractionEnabled(boolean z4) {
        this.B = z4;
    }

    public void setInterpolatedProgress(float f10) {
        if (this.f1688s != null) {
            setState(v.f237c);
            Interpolator e10 = this.f1688s.e();
            if (e10 != null) {
                setProgress(e10.getInterpolation(f10));
                return;
            }
        }
        setProgress(f10);
    }

    public void setOnHide(float f10) {
        ArrayList arrayList = this.f1676h1;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((MotionHelper) this.f1676h1.get(i10)).setProgress(f10);
            }
        }
    }

    public void setOnShow(float f10) {
        ArrayList arrayList = this.f1675g1;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((MotionHelper) this.f1675g1.get(i10)).setProgress(f10);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0045, code lost:
        if (r5.G == 0.0f) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0066, code lost:
        if (r5.G == 1.0f) goto L_0x0047;
     */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0073 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0074  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setProgress(float r6) {
        /*
            r5 = this;
            r0 = 1065353216(0x3f800000, float:1.0)
            r1 = 0
            int r2 = (r6 > r1 ? 1 : (r6 == r1 ? 0 : -1))
            if (r2 < 0) goto L_0x000b
            int r3 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
            if (r3 <= 0) goto L_0x0012
        L_0x000b:
            java.lang.String r3 = "MotionLayout"
            java.lang.String r4 = "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"
            android.util.Log.w(r3, r4)
        L_0x0012:
            boolean r3 = r5.isAttachedToWindow()
            if (r3 != 0) goto L_0x0028
            a1.t r0 = r5.f1703z1
            if (r0 != 0) goto L_0x0023
            a1.t r0 = new a1.t
            r0.<init>(r5)
            r5.f1703z1 = r0
        L_0x0023:
            a1.t r0 = r5.f1703z1
            r0.f230a = r6
            return
        L_0x0028:
            a1.v r3 = a1.v.f238d
            a1.v r4 = a1.v.f237c
            if (r2 > 0) goto L_0x004b
            float r2 = r5.G
            int r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x003d
            int r0 = r5.f1698x
            int r2 = r5.f1700y
            if (r0 != r2) goto L_0x003d
            r5.setState(r4)
        L_0x003d:
            int r0 = r5.f1696w
            r5.f1698x = r0
            float r0 = r5.G
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 != 0) goto L_0x006f
        L_0x0047:
            r5.setState(r3)
            goto L_0x006f
        L_0x004b:
            int r2 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
            if (r2 < 0) goto L_0x0069
            float r2 = r5.G
            int r1 = (r2 > r1 ? 1 : (r2 == r1 ? 0 : -1))
            if (r1 != 0) goto L_0x005e
            int r1 = r5.f1698x
            int r2 = r5.f1696w
            if (r1 != r2) goto L_0x005e
            r5.setState(r4)
        L_0x005e:
            int r1 = r5.f1700y
            r5.f1698x = r1
            float r1 = r5.G
            int r0 = (r1 > r0 ? 1 : (r1 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x006f
            goto L_0x0047
        L_0x0069:
            r0 = -1
            r5.f1698x = r0
            r5.setState(r4)
        L_0x006f:
            a1.z r0 = r5.f1688s
            if (r0 != 0) goto L_0x0074
            return
        L_0x0074:
            r0 = 1
            r5.J = r0
            r5.I = r6
            r5.F = r6
            r1 = -1
            r5.H = r1
            r5.D = r1
            r6 = 0
            r5.f1690t = r6
            r5.K = r0
            r5.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.setProgress(float):void");
    }

    public void setScene(a1.z zVar) {
        a1.b0 b0Var;
        this.f1688s = zVar;
        boolean k10 = k();
        zVar.f294p = k10;
        y yVar = zVar.f281c;
        if (!(yVar == null || (b0Var = yVar.f272l) == null)) {
            b0Var.c(k10);
        }
        B();
    }

    public void setStartState(int i10) {
        if (!isAttachedToWindow()) {
            if (this.f1703z1 == null) {
                this.f1703z1 = new t(this);
            }
            t tVar = this.f1703z1;
            tVar.f232c = i10;
            tVar.f233d = i10;
            return;
        }
        this.f1698x = i10;
    }

    public void setState(v vVar) {
        v vVar2 = v.f238d;
        if (vVar != vVar2 || this.f1698x != -1) {
            v vVar3 = this.D1;
            this.D1 = vVar;
            v vVar4 = v.f237c;
            if (vVar3 == vVar4 && vVar == vVar4) {
                u();
            }
            int ordinal = vVar3.ordinal();
            if (ordinal == 0 || ordinal == 1) {
                if (vVar == vVar4) {
                    u();
                }
                if (vVar != vVar2) {
                    return;
                }
            } else if (!(ordinal == 2 && vVar == vVar2)) {
                return;
            }
            v();
        }
    }

    public void setTransition(int i10) {
        a1.z zVar;
        int i11;
        if (this.f1688s != null) {
            y x4 = x(i10);
            this.f1696w = x4.f264d;
            this.f1700y = x4.f263c;
            if (!isAttachedToWindow()) {
                if (this.f1703z1 == null) {
                    this.f1703z1 = new t(this);
                }
                t tVar = this.f1703z1;
                tVar.f232c = this.f1696w;
                tVar.f233d = this.f1700y;
                return;
            }
            int i12 = this.f1698x;
            float f10 = i12 == this.f1696w ? 0.0f : i12 == this.f1700y ? 1.0f : Float.NaN;
            a1.z zVar2 = this.f1688s;
            zVar2.f281c = x4;
            a1.b0 b0Var = x4.f272l;
            if (b0Var != null) {
                b0Var.c(zVar2.f294p);
            }
            this.E1.g(this.f1688s.b(this.f1696w), this.f1688s.b(this.f1700y));
            B();
            if (this.G != f10) {
                if (f10 == 0.0f) {
                    s();
                    zVar = this.f1688s;
                    i11 = this.f1696w;
                } else if (f10 == 1.0f) {
                    s();
                    zVar = this.f1688s;
                    i11 = this.f1700y;
                }
                zVar.b(i11).b(this);
            }
            this.G = Float.isNaN(f10) ? 0.0f : f10;
            if (Float.isNaN(f10)) {
                Log.v("MotionLayout", b0.l() + " transitionToStart ");
                r(0.0f);
                return;
            }
            setProgress(f10);
        }
    }

    public void setTransitionDuration(int i10) {
        a1.z zVar = this.f1688s;
        if (zVar == null) {
            Log.e("MotionLayout", "MotionScene not defined");
            return;
        }
        y yVar = zVar.f281c;
        if (yVar != null) {
            yVar.f268h = Math.max(i10, 8);
        } else {
            zVar.f288j = i10;
        }
    }

    public void setTransitionListener(u uVar) {
        this.L = uVar;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.f1703z1 == null) {
            this.f1703z1 = new t(this);
        }
        t tVar = this.f1703z1;
        tVar.getClass();
        tVar.f230a = bundle.getFloat("motion.progress");
        tVar.f231b = bundle.getFloat("motion.velocity");
        tVar.f232c = bundle.getInt("motion.StartState");
        tVar.f233d = bundle.getInt("motion.EndState");
        if (isAttachedToWindow()) {
            this.f1703z1.a();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:159:0x0249, code lost:
        if (r1 != r2) goto L_0x024d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:165:0x0259, code lost:
        if (r1 != r2) goto L_0x024d;
     */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x01ab  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01ad  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x01bf  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x01d5  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x01e5  */
    /* JADX WARNING: Removed duplicated region for block: B:135:0x020b A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x021f  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0113  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x011c A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0151  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0153  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x015b  */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0172  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void t(boolean r23) {
        /*
            r22 = this;
            r0 = r22
            long r1 = r0.H
            r3 = -1
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 != 0) goto L_0x0010
            long r1 = r22.getNanoTime()
            r0.H = r1
        L_0x0010:
            float r1 = r0.G
            r2 = -1
            r3 = 1065353216(0x3f800000, float:1.0)
            r4 = 0
            int r5 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r5 <= 0) goto L_0x0020
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 >= 0) goto L_0x0020
            r0.f1698x = r2
        L_0x0020:
            boolean r5 = r0.f1674f1
            r6 = 1
            r7 = 0
            if (r5 != 0) goto L_0x0032
            boolean r5 = r0.K
            if (r5 == 0) goto L_0x023d
            if (r23 != 0) goto L_0x0032
            float r5 = r0.I
            int r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r5 == 0) goto L_0x023d
        L_0x0032:
            float r5 = r0.I
            float r5 = r5 - r1
            float r1 = java.lang.Math.signum(r5)
            long r8 = r22.getNanoTime()
            a1.o r5 = r0.f1690t
            boolean r10 = r5 instanceof a1.o
            r11 = 814313567(0x3089705f, float:1.0E-9)
            if (r10 != 0) goto L_0x0053
            long r12 = r0.H
            long r12 = r8 - r12
            float r10 = (float) r12
            float r10 = r10 * r1
            float r10 = r10 * r11
            float r12 = r0.E
            float r10 = r10 / r12
            goto L_0x0054
        L_0x0053:
            r10 = 0
        L_0x0054:
            float r12 = r0.G
            float r12 = r12 + r10
            boolean r13 = r0.J
            if (r13 == 0) goto L_0x005d
            float r12 = r0.I
        L_0x005d:
            int r13 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r13 <= 0) goto L_0x0067
            float r14 = r0.I
            int r14 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r14 >= 0) goto L_0x0071
        L_0x0067:
            int r14 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r14 > 0) goto L_0x0077
            float r14 = r0.I
            int r14 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r14 > 0) goto L_0x0077
        L_0x0071:
            float r12 = r0.I
            r0.K = r7
            r14 = 1
            goto L_0x0078
        L_0x0077:
            r14 = 0
        L_0x0078:
            r0.G = r12
            r0.F = r12
            r0.H = r8
            r15 = 925353388(0x3727c5ac, float:1.0E-5)
            if (r5 == 0) goto L_0x0106
            if (r14 != 0) goto L_0x0106
            boolean r14 = r0.O
            if (r14 == 0) goto L_0x00e8
            long r2 = r0.D
            long r2 = r8 - r2
            float r2 = (float) r2
            float r2 = r2 * r11
            float r2 = r5.getInterpolation(r2)
            a1.o r3 = r0.f1690t
            z0.a r5 = r0.f1684p0
            r10 = 2
            if (r3 != r5) goto L_0x00a7
            v0.m r3 = r5.f30586c
            boolean r3 = r3.a()
            if (r3 == 0) goto L_0x00a5
            r3 = 2
            goto L_0x00a8
        L_0x00a5:
            r3 = 1
            goto L_0x00a8
        L_0x00a7:
            r3 = 0
        L_0x00a8:
            r0.G = r2
            r0.H = r8
            a1.o r5 = r0.f1690t
            boolean r8 = r5 instanceof a1.o
            if (r8 == 0) goto L_0x00e6
            float r5 = r5.a()
            r0.f1694v = r5
            float r8 = java.lang.Math.abs(r5)
            float r9 = r0.E
            float r8 = r8 * r9
            int r8 = (r8 > r15 ? 1 : (r8 == r15 ? 0 : -1))
            if (r8 > 0) goto L_0x00c8
            if (r3 != r10) goto L_0x00c8
            r0.K = r7
        L_0x00c8:
            int r8 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1))
            if (r8 <= 0) goto L_0x00d8
            r8 = 1065353216(0x3f800000, float:1.0)
            int r9 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r9 < 0) goto L_0x00d8
            r0.G = r8
            r0.K = r7
            r2 = 1065353216(0x3f800000, float:1.0)
        L_0x00d8:
            int r5 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1))
            if (r5 >= 0) goto L_0x00e6
            int r5 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r5 > 0) goto L_0x00e6
            r0.G = r4
            r0.K = r7
            r12 = 0
            goto L_0x0109
        L_0x00e6:
            r12 = r2
            goto L_0x0109
        L_0x00e8:
            float r2 = r5.getInterpolation(r12)
            a1.o r3 = r0.f1690t
            boolean r5 = r3 instanceof a1.o
            if (r5 == 0) goto L_0x00f9
            float r3 = r3.a()
        L_0x00f6:
            r0.f1694v = r3
            goto L_0x0103
        L_0x00f9:
            float r12 = r12 + r10
            float r3 = r3.getInterpolation(r12)
            float r3 = r3 - r2
            float r3 = r3 * r1
            float r3 = r3 / r10
            goto L_0x00f6
        L_0x0103:
            r12 = r2
        L_0x0104:
            r3 = 0
            goto L_0x0109
        L_0x0106:
            r0.f1694v = r10
            goto L_0x0104
        L_0x0109:
            float r2 = r0.f1694v
            float r2 = java.lang.Math.abs(r2)
            int r2 = (r2 > r15 ? 1 : (r2 == r15 ? 0 : -1))
            if (r2 <= 0) goto L_0x0118
            a1.v r2 = a1.v.f237c
            r0.setState(r2)
        L_0x0118:
            a1.v r2 = a1.v.f238d
            if (r3 == r6) goto L_0x0141
            if (r13 <= 0) goto L_0x0124
            float r3 = r0.I
            int r3 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r3 >= 0) goto L_0x012e
        L_0x0124:
            int r3 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r3 > 0) goto L_0x0132
            float r3 = r0.I
            int r3 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r3 > 0) goto L_0x0132
        L_0x012e:
            float r12 = r0.I
            r0.K = r7
        L_0x0132:
            r3 = 1065353216(0x3f800000, float:1.0)
            int r5 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r5 >= 0) goto L_0x013c
            int r3 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r3 > 0) goto L_0x0141
        L_0x013c:
            r0.K = r7
            r0.setState(r2)
        L_0x0141:
            int r3 = r22.getChildCount()
            r0.f1674f1 = r7
            long r8 = r22.getNanoTime()
            r0.f1697w1 = r12
            android.view.animation.Interpolator r5 = r0.f1692u
            if (r5 != 0) goto L_0x0153
            r5 = r12
            goto L_0x0157
        L_0x0153:
            float r5 = r5.getInterpolation(r12)
        L_0x0157:
            android.view.animation.Interpolator r10 = r0.f1692u
            if (r10 == 0) goto L_0x016f
            float r11 = r0.E
            float r11 = r1 / r11
            float r11 = r11 + r12
            float r10 = r10.getInterpolation(r11)
            r0.f1694v = r10
            android.view.animation.Interpolator r11 = r0.f1692u
            float r11 = r11.getInterpolation(r12)
            float r10 = r10 - r11
            r0.f1694v = r10
        L_0x016f:
            r10 = 0
        L_0x0170:
            if (r10 >= r3) goto L_0x0199
            android.view.View r11 = r0.getChildAt(r10)
            java.util.HashMap r15 = r0.C
            java.lang.Object r15 = r15.get(r11)
            r16 = r15
            a1.n r16 = (a1.n) r16
            if (r16 == 0) goto L_0x0195
            boolean r15 = r0.f1674f1
            h.n0 r7 = r0.f1699x1
            r17 = r5
            r18 = r8
            r20 = r11
            r21 = r7
            boolean r7 = r16.e(r17, r18, r20, r21)
            r7 = r7 | r15
            r0.f1674f1 = r7
        L_0x0195:
            int r10 = r10 + 1
            r7 = 0
            goto L_0x0170
        L_0x0199:
            if (r13 <= 0) goto L_0x01a1
            float r3 = r0.I
            int r3 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r3 >= 0) goto L_0x01ab
        L_0x01a1:
            int r3 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r3 > 0) goto L_0x01ad
            float r3 = r0.I
            int r3 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r3 > 0) goto L_0x01ad
        L_0x01ab:
            r3 = 1
            goto L_0x01ae
        L_0x01ad:
            r3 = 0
        L_0x01ae:
            boolean r5 = r0.f1674f1
            if (r5 != 0) goto L_0x01bb
            boolean r5 = r0.K
            if (r5 != 0) goto L_0x01bb
            if (r3 == 0) goto L_0x01bb
            r0.setState(r2)
        L_0x01bb:
            boolean r5 = r0.f1685p1
            if (r5 == 0) goto L_0x01c2
            r22.requestLayout()
        L_0x01c2:
            boolean r5 = r0.f1674f1
            r3 = r3 ^ r6
            r3 = r3 | r5
            r0.f1674f1 = r3
            int r3 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r3 > 0) goto L_0x01e5
            int r3 = r0.f1696w
            r5 = -1
            if (r3 == r5) goto L_0x01e5
            int r5 = r0.f1698x
            if (r5 == r3) goto L_0x01e5
            r0.f1698x = r3
            a1.z r5 = r0.f1688s
            c1.l r3 = r5.b(r3)
            r3.a(r0)
            r0.setState(r2)
            r7 = 1
            goto L_0x01e6
        L_0x01e5:
            r7 = 0
        L_0x01e6:
            double r8 = (double) r12
            r10 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r3 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r3 < 0) goto L_0x0202
            int r3 = r0.f1698x
            int r5 = r0.f1700y
            if (r3 == r5) goto L_0x0202
            r0.f1698x = r5
            a1.z r3 = r0.f1688s
            c1.l r3 = r3.b(r5)
            r3.a(r0)
            r0.setState(r2)
            r7 = 1
        L_0x0202:
            boolean r3 = r0.f1674f1
            if (r3 != 0) goto L_0x021f
            boolean r3 = r0.K
            if (r3 == 0) goto L_0x020b
            goto L_0x021f
        L_0x020b:
            if (r13 <= 0) goto L_0x0213
            r3 = 1065353216(0x3f800000, float:1.0)
            int r5 = (r12 > r3 ? 1 : (r12 == r3 ? 0 : -1))
            if (r5 == 0) goto L_0x021b
        L_0x0213:
            int r3 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x0222
            int r3 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r3 != 0) goto L_0x0222
        L_0x021b:
            r0.setState(r2)
            goto L_0x0222
        L_0x021f:
            r22.invalidate()
        L_0x0222:
            boolean r2 = r0.f1674f1
            if (r2 != 0) goto L_0x023d
            boolean r2 = r0.K
            if (r2 != 0) goto L_0x023d
            if (r13 <= 0) goto L_0x0232
            r2 = 1065353216(0x3f800000, float:1.0)
            int r3 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r3 == 0) goto L_0x023a
        L_0x0232:
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 >= 0) goto L_0x023d
            int r1 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1))
            if (r1 != 0) goto L_0x023d
        L_0x023a:
            r22.z()
        L_0x023d:
            float r1 = r0.G
            r2 = 1065353216(0x3f800000, float:1.0)
            int r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r2 < 0) goto L_0x0251
            int r1 = r0.f1698x
            int r2 = r0.f1700y
            if (r1 == r2) goto L_0x024c
            goto L_0x024d
        L_0x024c:
            r6 = r7
        L_0x024d:
            r0.f1698x = r2
            r7 = r6
            goto L_0x025c
        L_0x0251:
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 > 0) goto L_0x025c
            int r1 = r0.f1698x
            int r2 = r0.f1696w
            if (r1 == r2) goto L_0x024c
            goto L_0x024d
        L_0x025c:
            boolean r1 = r0.F1
            r1 = r1 | r7
            r0.F1 = r1
            if (r7 == 0) goto L_0x026a
            boolean r1 = r0.f1701y1
            if (r1 != 0) goto L_0x026a
            r22.requestLayout()
        L_0x026a:
            float r1 = r0.G
            r0.F = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.t(boolean):void");
    }

    public final String toString() {
        Context context = getContext();
        return b0.m(context, this.f1696w) + "->" + b0.m(context, this.f1700y) + " (pos:" + this.G + " Dpos/Dt:" + this.f1694v;
    }

    public final void u() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        CopyOnWriteArrayList copyOnWriteArrayList2;
        if ((this.L != null || ((copyOnWriteArrayList2 = this.f1678j1) != null && !copyOnWriteArrayList2.isEmpty())) && this.f1683o1 != this.F) {
            if (!(this.f1682n1 == -1 || (copyOnWriteArrayList = this.f1678j1) == null)) {
                Iterator it = copyOnWriteArrayList.iterator();
                while (it.hasNext()) {
                    ((u) it.next()).getClass();
                }
            }
            this.f1682n1 = -1;
            this.f1683o1 = this.F;
            u uVar = this.L;
            if (uVar != null) {
                uVar.b();
            }
            CopyOnWriteArrayList copyOnWriteArrayList3 = this.f1678j1;
            if (copyOnWriteArrayList3 != null) {
                Iterator it2 = copyOnWriteArrayList3.iterator();
                while (it2.hasNext()) {
                    ((u) it2.next()).b();
                }
            }
        }
    }

    public final void v() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if ((this.L != null || ((copyOnWriteArrayList = this.f1678j1) != null && !copyOnWriteArrayList.isEmpty())) && this.f1682n1 == -1) {
            this.f1682n1 = this.f1698x;
            ArrayList arrayList = this.J1;
            int intValue = !arrayList.isEmpty() ? ((Integer) arrayList.get(arrayList.size() - 1)).intValue() : -1;
            int i10 = this.f1698x;
            if (!(intValue == i10 || i10 == -1)) {
                arrayList.add(Integer.valueOf(i10));
            }
        }
        A();
        Runnable runnable = this.A1;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void w(int i10, float f10, float f11, float f12, float[] fArr) {
        String str;
        HashMap hashMap = this.C;
        View h10 = h(i10);
        n nVar = (n) hashMap.get(h10);
        if (nVar != null) {
            nVar.d(f10, f11, f12, fArr);
            h10.getY();
            return;
        }
        if (h10 == null) {
            str = c.n("", i10);
        } else {
            str = h10.getContext().getResources().getResourceName(i10);
        }
        Log.w("MotionLayout", "WARNING could not find view id " + str);
    }

    public final y x(int i10) {
        Iterator it = this.f1688s.f282d.iterator();
        while (it.hasNext()) {
            y yVar = (y) it.next();
            if (yVar.f261a == i10) {
                return yVar;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0039  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean y(float r8, float r9, android.view.MotionEvent r10, android.view.View r11) {
        /*
            r7 = this;
            boolean r0 = r11 instanceof android.view.ViewGroup
            r1 = 1
            if (r0 == 0) goto L_0x0036
            r0 = r11
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            int r2 = r0.getChildCount()
            int r2 = r2 - r1
        L_0x000d:
            if (r2 < 0) goto L_0x0036
            android.view.View r3 = r0.getChildAt(r2)
            int r4 = r3.getLeft()
            float r4 = (float) r4
            float r4 = r4 + r8
            int r5 = r11.getScrollX()
            float r5 = (float) r5
            float r4 = r4 - r5
            int r5 = r3.getTop()
            float r5 = (float) r5
            float r5 = r5 + r9
            int r6 = r11.getScrollY()
            float r6 = (float) r6
            float r5 = r5 - r6
            boolean r3 = r7.y(r4, r5, r10, r3)
            if (r3 == 0) goto L_0x0033
            r0 = 1
            goto L_0x0037
        L_0x0033:
            int r2 = r2 + -1
            goto L_0x000d
        L_0x0036:
            r0 = 0
        L_0x0037:
            if (r0 != 0) goto L_0x00a9
            android.graphics.RectF r2 = r7.G1
            int r3 = r11.getRight()
            float r3 = (float) r3
            float r3 = r3 + r8
            int r4 = r11.getLeft()
            float r4 = (float) r4
            float r3 = r3 - r4
            int r4 = r11.getBottom()
            float r4 = (float) r4
            float r4 = r4 + r9
            int r5 = r11.getTop()
            float r5 = (float) r5
            float r4 = r4 - r5
            r2.set(r8, r9, r3, r4)
            int r3 = r10.getAction()
            if (r3 != 0) goto L_0x006a
            float r3 = r10.getX()
            float r4 = r10.getY()
            boolean r2 = r2.contains(r3, r4)
            if (r2 == 0) goto L_0x00a9
        L_0x006a:
            float r8 = -r8
            float r9 = -r9
            android.graphics.Matrix r2 = r11.getMatrix()
            boolean r3 = r2.isIdentity()
            if (r3 == 0) goto L_0x0083
            r10.offsetLocation(r8, r9)
            boolean r11 = r11.onTouchEvent(r10)
            float r8 = -r8
            float r9 = -r9
            r10.offsetLocation(r8, r9)
            goto L_0x00a6
        L_0x0083:
            android.view.MotionEvent r10 = android.view.MotionEvent.obtain(r10)
            r10.offsetLocation(r8, r9)
            android.graphics.Matrix r8 = r7.I1
            if (r8 != 0) goto L_0x0095
            android.graphics.Matrix r8 = new android.graphics.Matrix
            r8.<init>()
            r7.I1 = r8
        L_0x0095:
            android.graphics.Matrix r8 = r7.I1
            r2.invert(r8)
            android.graphics.Matrix r8 = r7.I1
            r10.transform(r8)
            boolean r11 = r11.onTouchEvent(r10)
            r10.recycle()
        L_0x00a6:
            if (r11 == 0) goto L_0x00a9
            goto L_0x00aa
        L_0x00a9:
            r1 = r0
        L_0x00aa:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.y(float, float, android.view.MotionEvent, android.view.View):boolean");
    }

    public final void z() {
        y yVar;
        a1.b0 b0Var;
        View view;
        a1.z zVar = this.f1688s;
        if (zVar != null) {
            if (zVar.a(this.f1698x, this)) {
                requestLayout();
                return;
            }
            int i10 = this.f1698x;
            if (i10 != -1) {
                a1.z zVar2 = this.f1688s;
                ArrayList arrayList = zVar2.f282d;
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    y yVar2 = (y) it.next();
                    if (yVar2.f273m.size() > 0) {
                        Iterator it2 = yVar2.f273m.iterator();
                        while (it2.hasNext()) {
                            ((x) it2.next()).b(this);
                        }
                    }
                }
                ArrayList arrayList2 = zVar2.f284f;
                Iterator it3 = arrayList2.iterator();
                while (it3.hasNext()) {
                    y yVar3 = (y) it3.next();
                    if (yVar3.f273m.size() > 0) {
                        Iterator it4 = yVar3.f273m.iterator();
                        while (it4.hasNext()) {
                            ((x) it4.next()).b(this);
                        }
                    }
                }
                Iterator it5 = arrayList.iterator();
                while (it5.hasNext()) {
                    y yVar4 = (y) it5.next();
                    if (yVar4.f273m.size() > 0) {
                        Iterator it6 = yVar4.f273m.iterator();
                        while (it6.hasNext()) {
                            ((x) it6.next()).a(this, i10, yVar4);
                        }
                    }
                }
                Iterator it7 = arrayList2.iterator();
                while (it7.hasNext()) {
                    y yVar5 = (y) it7.next();
                    if (yVar5.f273m.size() > 0) {
                        Iterator it8 = yVar5.f273m.iterator();
                        while (it8.hasNext()) {
                            ((x) it8.next()).a(this, i10, yVar5);
                        }
                    }
                }
            }
            if (this.f1688s.o() && (yVar = this.f1688s.f281c) != null && (b0Var = yVar.f272l) != null) {
                int i11 = b0Var.f67d;
                if (i11 != -1) {
                    MotionLayout motionLayout = b0Var.f81r;
                    view = motionLayout.findViewById(i11);
                    if (view == null) {
                        Log.e("TouchResponse", "cannot find TouchAnchorId @id/" + b0.m(motionLayout.getContext(), b0Var.f67d));
                    }
                } else {
                    view = null;
                }
                if (view instanceof NestedScrollView) {
                    NestedScrollView nestedScrollView = (NestedScrollView) view;
                    nestedScrollView.setOnTouchListener(new a0(0));
                    nestedScrollView.setOnScrollChangeListener(new ke());
                }
            }
        }
    }

    public void setTransition(y yVar) {
        int i10;
        long j3;
        a1.b0 b0Var;
        a1.z zVar = this.f1688s;
        zVar.f281c = yVar;
        if (!(yVar == null || (b0Var = yVar.f272l) == null)) {
            b0Var.c(zVar.f294p);
        }
        setState(v.f236b);
        int i11 = this.f1698x;
        y yVar2 = this.f1688s.f281c;
        int i12 = -1;
        if (yVar2 == null) {
            i10 = -1;
        } else {
            i10 = yVar2.f263c;
        }
        float f10 = i11 == i10 ? 1.0f : 0.0f;
        this.G = f10;
        this.F = f10;
        this.I = f10;
        if ((yVar.f278r & 1) != 0) {
            j3 = -1;
        } else {
            j3 = getNanoTime();
        }
        this.H = j3;
        int h10 = this.f1688s.h();
        a1.z zVar2 = this.f1688s;
        y yVar3 = zVar2.f281c;
        if (yVar3 != null) {
            i12 = yVar3.f263c;
        }
        if (h10 != this.f1696w || i12 != this.f1700y) {
            this.f1696w = h10;
            this.f1700y = i12;
            zVar2.n(h10, i12);
            l b5 = this.f1688s.b(this.f1696w);
            l b10 = this.f1688s.b(this.f1700y);
            r rVar = this.E1;
            rVar.g(b5, b10);
            int i13 = this.f1696w;
            int i14 = this.f1700y;
            rVar.f222b = i13;
            rVar.f223c = i14;
            rVar.i();
            B();
        }
    }
}
