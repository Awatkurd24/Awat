package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.VirtualLayout;
import c1.g;
import c1.m;
import c1.p;
import w0.e;
import w0.h;
import w0.k;
import w0.n;

public class Flow extends VirtualLayout {

    /* renamed from: k  reason: collision with root package name */
    public h f1638k;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        this.f1638k = new h();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 0) {
                    this.f1638k.f28628a1 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    h hVar = this.f1638k;
                    int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                    hVar.f28643x0 = dimensionPixelSize;
                    hVar.f28644y0 = dimensionPixelSize;
                    hVar.f28645z0 = dimensionPixelSize;
                    hVar.A0 = dimensionPixelSize;
                } else if (index == 18) {
                    h hVar2 = this.f1638k;
                    int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                    hVar2.f28645z0 = dimensionPixelSize2;
                    hVar2.B0 = dimensionPixelSize2;
                    hVar2.C0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f1638k.A0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f1638k.B0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f1638k.f28643x0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f1638k.C0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f1638k.f28644y0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f1638k.Y0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f1638k.I0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f1638k.J0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f1638k.K0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f1638k.M0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f1638k.L0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f1638k.N0 = obtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f1638k.O0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f1638k.Q0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f1638k.S0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f1638k.R0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f1638k.T0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f1638k.P0 = obtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f1638k.W0 = obtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f1638k.X0 = obtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f1638k.U0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f1638k.V0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f1638k.Z0 = obtainStyledAttributes.getInt(index, -1);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1792d = this.f1638k;
        r();
    }

    public final void m(g gVar, k kVar, m mVar, SparseArray sparseArray) {
        super.m(gVar, kVar, mVar, sparseArray);
        if (kVar instanceof h) {
            h hVar = (h) kVar;
            int i10 = mVar.V;
            if (i10 != -1) {
                hVar.f28628a1 = i10;
            }
        }
    }

    public final void n(e eVar, boolean z4) {
        h hVar = this.f1638k;
        int i10 = hVar.f28645z0;
        if (i10 <= 0 && hVar.A0 <= 0) {
            return;
        }
        if (z4) {
            hVar.B0 = hVar.A0;
            hVar.C0 = i10;
            return;
        }
        hVar.B0 = i10;
        hVar.C0 = hVar.A0;
    }

    public final void onMeasure(int i10, int i11) {
        s(this.f1638k, i10, i11);
    }

    public final void s(n nVar, int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (nVar != null) {
            nVar.V(mode, size, mode2, size2);
            setMeasuredDimension(nVar.E0, nVar.F0);
            return;
        }
        setMeasuredDimension(0, 0);
    }

    public void setFirstHorizontalBias(float f10) {
        this.f1638k.Q0 = f10;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i10) {
        this.f1638k.K0 = i10;
        requestLayout();
    }

    public void setFirstVerticalBias(float f10) {
        this.f1638k.R0 = f10;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i10) {
        this.f1638k.L0 = i10;
        requestLayout();
    }

    public void setHorizontalAlign(int i10) {
        this.f1638k.W0 = i10;
        requestLayout();
    }

    public void setHorizontalBias(float f10) {
        this.f1638k.O0 = f10;
        requestLayout();
    }

    public void setHorizontalGap(int i10) {
        this.f1638k.U0 = i10;
        requestLayout();
    }

    public void setHorizontalStyle(int i10) {
        this.f1638k.I0 = i10;
        requestLayout();
    }

    public void setLastHorizontalBias(float f10) {
        this.f1638k.S0 = f10;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i10) {
        this.f1638k.M0 = i10;
        requestLayout();
    }

    public void setLastVerticalBias(float f10) {
        this.f1638k.T0 = f10;
        requestLayout();
    }

    public void setLastVerticalStyle(int i10) {
        this.f1638k.N0 = i10;
        requestLayout();
    }

    public void setMaxElementsWrap(int i10) {
        this.f1638k.Z0 = i10;
        requestLayout();
    }

    public void setOrientation(int i10) {
        this.f1638k.f28628a1 = i10;
        requestLayout();
    }

    public void setPadding(int i10) {
        h hVar = this.f1638k;
        hVar.f28643x0 = i10;
        hVar.f28644y0 = i10;
        hVar.f28645z0 = i10;
        hVar.A0 = i10;
        requestLayout();
    }

    public void setPaddingBottom(int i10) {
        this.f1638k.f28644y0 = i10;
        requestLayout();
    }

    public void setPaddingLeft(int i10) {
        this.f1638k.B0 = i10;
        requestLayout();
    }

    public void setPaddingRight(int i10) {
        this.f1638k.C0 = i10;
        requestLayout();
    }

    public void setPaddingTop(int i10) {
        this.f1638k.f28643x0 = i10;
        requestLayout();
    }

    public void setVerticalAlign(int i10) {
        this.f1638k.X0 = i10;
        requestLayout();
    }

    public void setVerticalBias(float f10) {
        this.f1638k.P0 = f10;
        requestLayout();
    }

    public void setVerticalGap(int i10) {
        this.f1638k.V0 = i10;
        requestLayout();
    }

    public void setVerticalStyle(int i10) {
        this.f1638k.J0 = i10;
        requestLayout();
    }

    public void setWrapMode(int i10) {
        this.f1638k.Y0 = i10;
        requestLayout();
    }

    public Flow(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }
}
