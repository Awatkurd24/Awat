package androidx.constraintlayout.helper.widget;

import a1.b0;
import a1.y;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;
import java.util.ArrayList;
import y0.a;

public class Carousel extends MotionHelper {

    /* renamed from: m  reason: collision with root package name */
    public final ArrayList f1613m = new ArrayList();

    /* renamed from: n  reason: collision with root package name */
    public int f1614n;

    /* renamed from: o  reason: collision with root package name */
    public MotionLayout f1615o;

    /* renamed from: p  reason: collision with root package name */
    public final int f1616p;

    /* renamed from: q  reason: collision with root package name */
    public final boolean f1617q;

    /* renamed from: r  reason: collision with root package name */
    public final int f1618r;

    /* renamed from: s  reason: collision with root package name */
    public final int f1619s;

    /* renamed from: t  reason: collision with root package name */
    public final int f1620t;

    /* renamed from: u  reason: collision with root package name */
    public final int f1621u;

    /* renamed from: v  reason: collision with root package name */
    public final float f1622v;

    /* renamed from: w  reason: collision with root package name */
    public final int f1623w;

    /* renamed from: x  reason: collision with root package name */
    public final int f1624x;

    /* renamed from: y  reason: collision with root package name */
    public final float f1625y;

    public Carousel(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1614n = 0;
        this.f1616p = -1;
        this.f1617q = false;
        this.f1618r = -1;
        this.f1619s = -1;
        this.f1620t = -1;
        this.f1621u = -1;
        this.f1622v = 0.9f;
        this.f1623w = 4;
        this.f1624x = 1;
        this.f1625y = 2.0f;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3901a);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 3) {
                    this.f1616p = obtainStyledAttributes.getResourceId(index, this.f1616p);
                } else if (index == 1) {
                    this.f1618r = obtainStyledAttributes.getResourceId(index, this.f1618r);
                } else if (index == 4) {
                    this.f1619s = obtainStyledAttributes.getResourceId(index, this.f1619s);
                } else if (index == 2) {
                    this.f1623w = obtainStyledAttributes.getInt(index, this.f1623w);
                } else if (index == 7) {
                    this.f1620t = obtainStyledAttributes.getResourceId(index, this.f1620t);
                } else if (index == 6) {
                    this.f1621u = obtainStyledAttributes.getResourceId(index, this.f1621u);
                } else if (index == 9) {
                    this.f1622v = obtainStyledAttributes.getFloat(index, this.f1622v);
                } else if (index == 8) {
                    this.f1624x = obtainStyledAttributes.getInt(index, this.f1624x);
                } else if (index == 10) {
                    this.f1625y = obtainStyledAttributes.getFloat(index, this.f1625y);
                } else if (index == 5) {
                    this.f1617q = obtainStyledAttributes.getBoolean(index, this.f1617q);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public final void a(int i10) {
        int i11;
        int i12 = this.f1614n;
        if (i10 == this.f1621u) {
            i11 = i12 + 1;
        } else {
            if (i10 == this.f1620t) {
                i11 = i12 - 1;
            }
            boolean z4 = this.f1617q;
            throw null;
        }
        this.f1614n = i11;
        boolean z42 = this.f1617q;
        throw null;
    }

    public final void b() {
    }

    public int getCount() {
        return 0;
    }

    public int getCurrentIndex() {
        return this.f1614n;
    }

    public final void onAttachedToWindow() {
        b0 b0Var;
        b0 b0Var2;
        super.onAttachedToWindow();
        if (getParent() instanceof MotionLayout) {
            MotionLayout motionLayout = (MotionLayout) getParent();
            for (int i10 = 0; i10 < this.f1790b; i10++) {
                this.f1613m.add(motionLayout.h(this.f1789a[i10]));
            }
            this.f1615o = motionLayout;
            if (this.f1624x == 2) {
                y x4 = motionLayout.x(this.f1619s);
                if (!(x4 == null || (b0Var2 = x4.f272l) == null)) {
                    b0Var2.f66c = 5;
                }
                y x10 = this.f1615o.x(this.f1618r);
                if (x10 != null && (b0Var = x10.f272l) != null) {
                    b0Var.f66c = 5;
                }
            }
        }
    }

    public void setAdapter(a aVar) {
    }
}
