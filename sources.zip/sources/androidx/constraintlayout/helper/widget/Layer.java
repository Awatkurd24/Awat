package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import c1.c;
import c1.p;
import w0.e;

public class Layer extends ConstraintHelper {

    /* renamed from: i  reason: collision with root package name */
    public float f1639i = Float.NaN;

    /* renamed from: j  reason: collision with root package name */
    public float f1640j = Float.NaN;

    /* renamed from: k  reason: collision with root package name */
    public float f1641k = Float.NaN;

    /* renamed from: l  reason: collision with root package name */
    public ConstraintLayout f1642l;

    /* renamed from: m  reason: collision with root package name */
    public float f1643m = 1.0f;

    /* renamed from: n  reason: collision with root package name */
    public float f1644n = 1.0f;

    /* renamed from: o  reason: collision with root package name */
    public float f1645o = Float.NaN;

    /* renamed from: p  reason: collision with root package name */
    public float f1646p = Float.NaN;

    /* renamed from: q  reason: collision with root package name */
    public float f1647q = Float.NaN;

    /* renamed from: r  reason: collision with root package name */
    public float f1648r = Float.NaN;

    /* renamed from: s  reason: collision with root package name */
    public float f1649s = Float.NaN;

    /* renamed from: t  reason: collision with root package name */
    public float f1650t = Float.NaN;

    /* renamed from: u  reason: collision with root package name */
    public final boolean f1651u = true;

    /* renamed from: v  reason: collision with root package name */
    public View[] f1652v = null;

    /* renamed from: w  reason: collision with root package name */
    public float f1653w = 0.0f;

    /* renamed from: x  reason: collision with root package name */
    public float f1654x = 0.0f;

    /* renamed from: y  reason: collision with root package name */
    public boolean f1655y;

    /* renamed from: z  reason: collision with root package name */
    public boolean f1656z;

    public Layer(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }

    public final void h(ConstraintLayout constraintLayout) {
        g(constraintLayout);
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 6) {
                    this.f1655y = true;
                } else if (index == 22) {
                    this.f1656z = true;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public final void o() {
        t();
        this.f1645o = Float.NaN;
        this.f1646p = Float.NaN;
        e eVar = ((c) getLayoutParams()).f3766q0;
        eVar.Q(0);
        eVar.N(0);
        s();
        layout(((int) this.f1649s) - getPaddingLeft(), ((int) this.f1650t) - getPaddingTop(), getPaddingRight() + ((int) this.f1647q), getPaddingBottom() + ((int) this.f1648r));
        u();
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1642l = (ConstraintLayout) getParent();
        if (this.f1655y || this.f1656z) {
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i10 = 0; i10 < this.f1790b; i10++) {
                View h10 = this.f1642l.h(this.f1789a[i10]);
                if (h10 != null) {
                    if (this.f1655y) {
                        h10.setVisibility(visibility);
                    }
                    if (this.f1656z && elevation > 0.0f) {
                        h10.setTranslationZ(h10.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    public final void p(ConstraintLayout constraintLayout) {
        this.f1642l = constraintLayout;
        float rotation = getRotation();
        if (rotation != 0.0f || !Float.isNaN(this.f1641k)) {
            this.f1641k = rotation;
        }
    }

    public final void s() {
        if (this.f1642l != null) {
            if (!this.f1651u && !Float.isNaN(this.f1645o) && !Float.isNaN(this.f1646p)) {
                return;
            }
            if (Float.isNaN(this.f1639i) || Float.isNaN(this.f1640j)) {
                View[] k10 = k(this.f1642l);
                int left = k10[0].getLeft();
                int top = k10[0].getTop();
                int right = k10[0].getRight();
                int bottom = k10[0].getBottom();
                for (int i10 = 0; i10 < this.f1790b; i10++) {
                    View view = k10[i10];
                    left = Math.min(left, view.getLeft());
                    top = Math.min(top, view.getTop());
                    right = Math.max(right, view.getRight());
                    bottom = Math.max(bottom, view.getBottom());
                }
                this.f1647q = (float) right;
                this.f1648r = (float) bottom;
                this.f1649s = (float) left;
                this.f1650t = (float) top;
                this.f1645o = Float.isNaN(this.f1639i) ? (float) ((left + right) / 2) : this.f1639i;
                this.f1646p = Float.isNaN(this.f1640j) ? (float) ((top + bottom) / 2) : this.f1640j;
                return;
            }
            this.f1646p = this.f1640j;
            this.f1645o = this.f1639i;
        }
    }

    public void setElevation(float f10) {
        super.setElevation(f10);
        f();
    }

    public void setPivotX(float f10) {
        this.f1639i = f10;
        u();
    }

    public void setPivotY(float f10) {
        this.f1640j = f10;
        u();
    }

    public void setRotation(float f10) {
        this.f1641k = f10;
        u();
    }

    public void setScaleX(float f10) {
        this.f1643m = f10;
        u();
    }

    public void setScaleY(float f10) {
        this.f1644n = f10;
        u();
    }

    public void setTranslationX(float f10) {
        this.f1653w = f10;
        u();
    }

    public void setTranslationY(float f10) {
        this.f1654x = f10;
        u();
    }

    public void setVisibility(int i10) {
        super.setVisibility(i10);
        f();
    }

    public final void t() {
        int i10;
        if (this.f1642l != null && (i10 = this.f1790b) != 0) {
            View[] viewArr = this.f1652v;
            if (viewArr == null || viewArr.length != i10) {
                this.f1652v = new View[i10];
            }
            for (int i11 = 0; i11 < this.f1790b; i11++) {
                this.f1652v[i11] = this.f1642l.h(this.f1789a[i11]);
            }
        }
    }

    public final void u() {
        if (this.f1642l != null) {
            if (this.f1652v == null) {
                t();
            }
            s();
            double radians = Float.isNaN(this.f1641k) ? 0.0d : Math.toRadians((double) this.f1641k);
            float sin = (float) Math.sin(radians);
            float cos = (float) Math.cos(radians);
            float f10 = this.f1643m;
            float f11 = f10 * cos;
            float f12 = this.f1644n;
            float f13 = (-f12) * sin;
            float f14 = f10 * sin;
            float f15 = f12 * cos;
            for (int i10 = 0; i10 < this.f1790b; i10++) {
                View view = this.f1652v[i10];
                int left = view.getLeft();
                int top = view.getTop();
                float right = ((float) ((view.getRight() + left) / 2)) - this.f1645o;
                float bottom = ((float) ((view.getBottom() + top) / 2)) - this.f1646p;
                view.setTranslationX((((f13 * bottom) + (f11 * right)) - right) + this.f1653w);
                view.setTranslationY((((f15 * bottom) + (right * f14)) - bottom) + this.f1654x);
                view.setScaleY(this.f1644n);
                view.setScaleX(this.f1643m);
                if (!Float.isNaN(this.f1641k)) {
                    view.setRotation(this.f1641k);
                }
            }
        }
    }
}
