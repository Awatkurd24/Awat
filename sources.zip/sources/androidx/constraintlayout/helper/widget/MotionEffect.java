package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import c1.p;

public class MotionEffect extends MotionHelper {

    /* renamed from: m  reason: collision with root package name */
    public final float f1657m = 0.1f;

    /* renamed from: n  reason: collision with root package name */
    public final int f1658n = 49;

    /* renamed from: o  reason: collision with root package name */
    public final int f1659o = 50;

    /* renamed from: p  reason: collision with root package name */
    public final int f1660p = 0;

    /* renamed from: q  reason: collision with root package name */
    public final int f1661q = 0;

    /* renamed from: r  reason: collision with root package name */
    public final boolean f1662r = true;

    /* renamed from: s  reason: collision with root package name */
    public final int f1663s = -1;

    /* renamed from: t  reason: collision with root package name */
    public final int f1664t = -1;

    public MotionEffect(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3915o);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 3) {
                    int i12 = obtainStyledAttributes.getInt(index, this.f1658n);
                    this.f1658n = i12;
                    this.f1658n = Math.max(Math.min(i12, 99), 0);
                } else if (index == 1) {
                    int i13 = obtainStyledAttributes.getInt(index, this.f1659o);
                    this.f1659o = i13;
                    this.f1659o = Math.max(Math.min(i13, 99), 0);
                } else if (index == 5) {
                    this.f1660p = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1660p);
                } else if (index == 6) {
                    this.f1661q = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1661q);
                } else if (index == 0) {
                    this.f1657m = obtainStyledAttributes.getFloat(index, this.f1657m);
                } else if (index == 2) {
                    this.f1664t = obtainStyledAttributes.getInt(index, this.f1664t);
                } else if (index == 4) {
                    this.f1662r = obtainStyledAttributes.getBoolean(index, this.f1662r);
                } else if (index == 7) {
                    this.f1663s = obtainStyledAttributes.getResourceId(index, this.f1663s);
                }
            }
            int i14 = this.f1658n;
            int i15 = this.f1659o;
            if (i14 == i15) {
                if (i14 > 0) {
                    this.f1658n = i14 - 1;
                } else {
                    this.f1659o = i15 + 1;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:55:0x0181, code lost:
        if (r14 == 0.0f) goto L_0x0187;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x0197, code lost:
        if (r14 == 0.0f) goto L_0x0187;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x01bb, code lost:
        if (r1 == 0.0f) goto L_0x015e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x01c3  */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x01ee  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void s(androidx.constraintlayout.motion.widget.MotionLayout r20, java.util.HashMap r21) {
        /*
            r19 = this;
            r0 = r19
            r1 = r21
            android.view.ViewParent r2 = r19.getParent()
            androidx.constraintlayout.widget.ConstraintLayout r2 = (androidx.constraintlayout.widget.ConstraintLayout) r2
            android.view.View[] r2 = r0.k(r2)
            if (r2 != 0) goto L_0x002b
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = yg.b0.k()
            r1.append(r2)
            java.lang.String r2 = " views = null"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            java.lang.String r2 = "FadeMove"
            android.util.Log.v(r2, r1)
            return
        L_0x002b:
            a1.e r3 = new a1.e
            r3.<init>()
            a1.e r4 = new a1.e
            r4.<init>()
            float r5 = r0.f1657m
            java.lang.Float r5 = java.lang.Float.valueOf(r5)
            java.lang.String r6 = "alpha"
            r3.g(r6, r5)
            float r5 = r0.f1657m
            java.lang.Float r5 = java.lang.Float.valueOf(r5)
            r4.g(r6, r5)
            int r5 = r0.f1658n
            r3.f90a = r5
            int r6 = r0.f1659o
            r4.f90a = r6
            a1.i r6 = new a1.i
            r6.<init>()
            r6.f90a = r5
            r5 = 0
            r6.f157o = r5
            java.lang.Integer r7 = java.lang.Integer.valueOf(r5)
            java.lang.String r8 = "percentX"
            r6.g(r8, r7)
            java.lang.Integer r7 = java.lang.Integer.valueOf(r5)
            java.lang.String r9 = "percentY"
            r6.g(r9, r7)
            a1.i r7 = new a1.i
            r7.<init>()
            int r10 = r0.f1659o
            r7.f90a = r10
            r7.f157o = r5
            r10 = 1
            java.lang.Integer r11 = java.lang.Integer.valueOf(r10)
            r7.g(r8, r11)
            java.lang.Integer r8 = java.lang.Integer.valueOf(r10)
            r7.g(r9, r8)
            int r8 = r0.f1660p
            r9 = 0
            if (r8 <= 0) goto L_0x00b2
            a1.e r8 = new a1.e
            r8.<init>()
            a1.e r11 = new a1.e
            r11.<init>()
            int r12 = r0.f1660p
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)
            java.lang.String r13 = "translationX"
            r8.g(r13, r12)
            int r12 = r0.f1659o
            r8.f90a = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r5)
            r11.g(r13, r12)
            int r12 = r0.f1659o
            int r12 = r12 - r10
            r11.f90a = r12
            goto L_0x00b4
        L_0x00b2:
            r8 = r9
            r11 = r8
        L_0x00b4:
            int r12 = r0.f1661q
            if (r12 <= 0) goto L_0x00de
            a1.e r9 = new a1.e
            r9.<init>()
            a1.e r12 = new a1.e
            r12.<init>()
            int r13 = r0.f1661q
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            java.lang.String r14 = "translationY"
            r9.g(r14, r13)
            int r13 = r0.f1659o
            r9.f90a = r13
            java.lang.Integer r13 = java.lang.Integer.valueOf(r5)
            r12.g(r14, r13)
            int r13 = r0.f1659o
            int r13 = r13 - r10
            r12.f90a = r13
            goto L_0x00df
        L_0x00de:
            r12 = r9
        L_0x00df:
            int r13 = r0.f1664t
            r14 = -1
            r16 = 0
            if (r13 != r14) goto L_0x014e
            r13 = 4
            int[] r14 = new int[r13]
            r13 = 0
        L_0x00ea:
            int r15 = r2.length
            if (r13 >= r15) goto L_0x013b
            r15 = r2[r13]
            java.lang.Object r15 = r1.get(r15)
            a1.n r15 = (a1.n) r15
            if (r15 != 0) goto L_0x00fa
            r18 = r12
            goto L_0x0134
        L_0x00fa:
            a1.w r5 = r15.f183g
            float r10 = r5.f245e
            a1.w r15 = r15.f182f
            r18 = r12
            float r12 = r15.f245e
            float r10 = r10 - r12
            float r5 = r5.f246f
            float r12 = r15.f246f
            float r5 = r5 - r12
            int r12 = (r5 > r16 ? 1 : (r5 == r16 ? 0 : -1))
            if (r12 >= 0) goto L_0x0115
            r12 = 1
            r15 = r14[r12]
            int r15 = r15 + r12
            r14[r12] = r15
            goto L_0x0116
        L_0x0115:
            r12 = 1
        L_0x0116:
            int r5 = (r5 > r16 ? 1 : (r5 == r16 ? 0 : -1))
            if (r5 <= 0) goto L_0x0120
            r5 = 0
            r15 = r14[r5]
            int r15 = r15 + r12
            r14[r5] = r15
        L_0x0120:
            int r5 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1))
            if (r5 <= 0) goto L_0x012a
            r5 = 3
            r15 = r14[r5]
            int r15 = r15 + r12
            r14[r5] = r15
        L_0x012a:
            int r5 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1))
            if (r5 >= 0) goto L_0x0134
            r5 = 2
            r10 = r14[r5]
            int r10 = r10 + r12
            r14[r5] = r10
        L_0x0134:
            int r13 = r13 + 1
            r12 = r18
            r5 = 0
            r10 = 1
            goto L_0x00ea
        L_0x013b:
            r18 = r12
            r10 = r14[r5]
            r12 = 1
            r13 = 0
            r15 = 4
        L_0x0142:
            if (r12 >= r15) goto L_0x0150
            r5 = r14[r12]
            if (r10 >= r5) goto L_0x014a
            r10 = r5
            r13 = r12
        L_0x014a:
            int r12 = r12 + 1
            r5 = 0
            goto L_0x0142
        L_0x014e:
            r18 = r12
        L_0x0150:
            r5 = 0
        L_0x0151:
            int r10 = r2.length
            if (r5 >= r10) goto L_0x023c
            r10 = r2[r5]
            java.lang.Object r10 = r1.get(r10)
            a1.n r10 = (a1.n) r10
            if (r10 != 0) goto L_0x0167
        L_0x015e:
            r12 = r20
            r17 = r2
            r14 = r18
        L_0x0164:
            r2 = -1
            goto L_0x0230
        L_0x0167:
            a1.w r12 = r10.f183g
            float r14 = r12.f245e
            a1.w r15 = r10.f182f
            float r1 = r15.f245e
            float r14 = r14 - r1
            float r1 = r12.f246f
            float r12 = r15.f246f
            float r1 = r1 - r12
            if (r13 != 0) goto L_0x018a
            int r1 = (r1 > r16 ? 1 : (r1 == r16 ? 0 : -1))
            if (r1 <= 0) goto L_0x0184
            boolean r1 = r0.f1662r
            if (r1 == 0) goto L_0x0187
            int r1 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r1 != 0) goto L_0x0184
            goto L_0x0187
        L_0x0184:
            r12 = 3
            r15 = 2
            goto L_0x01be
        L_0x0187:
            r12 = 3
            r15 = 2
            goto L_0x01bd
        L_0x018a:
            r12 = 1
            if (r13 != r12) goto L_0x019a
            int r1 = (r1 > r16 ? 1 : (r1 == r16 ? 0 : -1))
            if (r1 >= 0) goto L_0x0184
            boolean r1 = r0.f1662r
            if (r1 == 0) goto L_0x0187
            int r1 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r1 != 0) goto L_0x0184
            goto L_0x0187
        L_0x019a:
            r15 = 2
            if (r13 != r15) goto L_0x01ae
            int r14 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r14 >= 0) goto L_0x01aa
            boolean r14 = r0.f1662r
            if (r14 == 0) goto L_0x01ac
            int r1 = (r1 > r16 ? 1 : (r1 == r16 ? 0 : -1))
            if (r1 != 0) goto L_0x01aa
            goto L_0x01ac
        L_0x01aa:
            r12 = 3
            goto L_0x01be
        L_0x01ac:
            r12 = 3
            goto L_0x01bd
        L_0x01ae:
            r12 = 3
            if (r13 != r12) goto L_0x01be
            int r14 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r14 <= 0) goto L_0x01be
            boolean r14 = r0.f1662r
            if (r14 == 0) goto L_0x015e
            int r1 = (r1 > r16 ? 1 : (r1 == r16 ? 0 : -1))
            if (r1 != 0) goto L_0x01be
        L_0x01bd:
            goto L_0x015e
        L_0x01be:
            int r1 = r0.f1663s
            r14 = -1
            if (r1 != r14) goto L_0x01ee
            r10.a(r3)
            r10.a(r4)
            r10.a(r6)
            r10.a(r7)
            int r1 = r0.f1660p
            if (r1 <= 0) goto L_0x01d9
            r10.a(r8)
            r10.a(r11)
        L_0x01d9:
            int r1 = r0.f1661q
            if (r1 <= 0) goto L_0x01eb
            r10.a(r9)
            r14 = r18
            r10.a(r14)
        L_0x01e5:
            r12 = r20
        L_0x01e7:
            r17 = r2
            goto L_0x0164
        L_0x01eb:
            r14 = r18
            goto L_0x01e5
        L_0x01ee:
            r12 = r20
            r14 = r18
            a1.z r15 = r12.f1688s
            if (r15 == 0) goto L_0x01e7
            pa.b r15 = r15.f295q
            java.lang.Object r15 = r15.f24100b
            java.util.ArrayList r15 = (java.util.ArrayList) r15
            java.util.Iterator r15 = r15.iterator()
        L_0x0200:
            boolean r17 = r15.hasNext()
            if (r17 == 0) goto L_0x01e7
            java.lang.Object r17 = r15.next()
            r0 = r17
            a1.d0 r0 = (a1.d0) r0
            r17 = r2
            int r2 = r0.f108a
            if (r2 != r1) goto L_0x022b
            a1.g r0 = r0.f113f
            r2 = -1
            java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
            java.util.HashMap r0 = r0.f145a
            java.lang.Object r0 = r0.get(r1)
            java.util.ArrayList r0 = (java.util.ArrayList) r0
            if (r0 == 0) goto L_0x0230
            java.util.ArrayList r1 = r10.f199w
            r1.addAll(r0)
            goto L_0x0230
        L_0x022b:
            r0 = r19
            r2 = r17
            goto L_0x0200
        L_0x0230:
            int r5 = r5 + 1
            r0 = r19
            r1 = r21
            r18 = r14
            r2 = r17
            goto L_0x0151
        L_0x023c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.helper.widget.MotionEffect.s(androidx.constraintlayout.motion.widget.MotionLayout, java.util.HashMap):void");
    }
}
