package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.VirtualLayout;
import w0.j;
import w0.n;

public class MotionPlaceholder extends VirtualLayout {
    public MotionPlaceholder(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        this.f1792d = new n();
        r();
    }

    public final void onMeasure(int i10, int i11) {
        s((n) null, i10, i11);
    }

    public final void q(j jVar, SparseArray sparseArray) {
    }

    public final void s(n nVar, int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (nVar != null) {
            nVar.V(mode, size, mode2, size2);
            setMeasuredDimension(nVar.E0, nVar.F0);
            return;
        }
        setMeasuredDimension(0, 0);
    }
}
