package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.VirtualLayout;
import c1.c;
import c1.p;
import java.util.Arrays;
import java.util.HashMap;

public class CircularFlow extends VirtualLayout {

    /* renamed from: u  reason: collision with root package name */
    public static int f1626u;

    /* renamed from: v  reason: collision with root package name */
    public static float f1627v;

    /* renamed from: k  reason: collision with root package name */
    public ConstraintLayout f1628k;

    /* renamed from: l  reason: collision with root package name */
    public int f1629l;

    /* renamed from: m  reason: collision with root package name */
    public float[] f1630m;

    /* renamed from: n  reason: collision with root package name */
    public int[] f1631n;

    /* renamed from: o  reason: collision with root package name */
    public int f1632o;

    /* renamed from: p  reason: collision with root package name */
    public int f1633p;

    /* renamed from: q  reason: collision with root package name */
    public String f1634q;

    /* renamed from: r  reason: collision with root package name */
    public String f1635r;

    /* renamed from: s  reason: collision with root package name */
    public Float f1636s;

    /* renamed from: t  reason: collision with root package name */
    public Integer f1637t;

    public CircularFlow(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }

    private void setAngles(String str) {
        if (str != null) {
            int i10 = 0;
            this.f1633p = 0;
            while (true) {
                int indexOf = str.indexOf(44, i10);
                if (indexOf == -1) {
                    t(str.substring(i10).trim());
                    return;
                } else {
                    t(str.substring(i10, indexOf).trim());
                    i10 = indexOf + 1;
                }
            }
        }
    }

    private void setRadius(String str) {
        if (str != null) {
            int i10 = 0;
            this.f1632o = 0;
            while (true) {
                int indexOf = str.indexOf(44, i10);
                if (indexOf == -1) {
                    u(str.substring(i10).trim());
                    return;
                } else {
                    u(str.substring(i10, indexOf).trim());
                    i10 = indexOf + 1;
                }
            }
        }
    }

    public float[] getAngles() {
        return Arrays.copyOf(this.f1630m, this.f1633p);
    }

    public int[] getRadius() {
        return Arrays.copyOf(this.f1631n, this.f1632o);
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 33) {
                    this.f1629l = obtainStyledAttributes.getResourceId(index, 0);
                } else if (index == 29) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1634q = string;
                    setAngles(string);
                } else if (index == 32) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1635r = string2;
                    setRadius(string2);
                } else if (index == 30) {
                    Float valueOf = Float.valueOf(obtainStyledAttributes.getFloat(index, f1627v));
                    this.f1636s = valueOf;
                    setDefaultAngle(valueOf.floatValue());
                } else if (index == 31) {
                    Integer valueOf2 = Integer.valueOf(obtainStyledAttributes.getDimensionPixelSize(index, f1626u));
                    this.f1637t = valueOf2;
                    setDefaultRadius(valueOf2.intValue());
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1634q;
        if (str != null) {
            this.f1630m = new float[1];
            setAngles(str);
        }
        String str2 = this.f1635r;
        if (str2 != null) {
            this.f1631n = new int[1];
            setRadius(str2);
        }
        Float f10 = this.f1636s;
        if (f10 != null) {
            setDefaultAngle(f10.floatValue());
        }
        Integer num = this.f1637t;
        if (num != null) {
            setDefaultRadius(num.intValue());
        }
        this.f1628k = (ConstraintLayout) getParent();
        for (int i10 = 0; i10 < this.f1790b; i10++) {
            View h10 = this.f1628k.h(this.f1789a[i10]);
            if (h10 != null) {
                int i11 = f1626u;
                float f11 = f1627v;
                int[] iArr = this.f1631n;
                HashMap hashMap = this.f1796h;
                if (iArr == null || i10 >= iArr.length) {
                    Integer num2 = this.f1637t;
                    if (num2 == null || num2.intValue() == -1) {
                        Log.e("CircularFlow", "Added radius to view with id: " + ((String) hashMap.get(Integer.valueOf(h10.getId()))));
                    } else {
                        this.f1632o++;
                        if (this.f1631n == null) {
                            this.f1631n = new int[1];
                        }
                        int[] radius = getRadius();
                        this.f1631n = radius;
                        radius[this.f1632o - 1] = i11;
                    }
                } else {
                    i11 = iArr[i10];
                }
                float[] fArr = this.f1630m;
                if (fArr == null || i10 >= fArr.length) {
                    Float f12 = this.f1636s;
                    if (f12 == null || f12.floatValue() == -1.0f) {
                        Log.e("CircularFlow", "Added angle to view with id: " + ((String) hashMap.get(Integer.valueOf(h10.getId()))));
                    } else {
                        this.f1633p++;
                        if (this.f1630m == null) {
                            this.f1630m = new float[1];
                        }
                        float[] angles = getAngles();
                        this.f1630m = angles;
                        angles[this.f1633p - 1] = f11;
                    }
                } else {
                    f11 = fArr[i10];
                }
                c cVar = (c) h10.getLayoutParams();
                cVar.f3767r = f11;
                cVar.f3763p = this.f1629l;
                cVar.f3765q = i11;
                h10.setLayoutParams(cVar);
            }
        }
        f();
    }

    public void setDefaultAngle(float f10) {
        f1627v = f10;
    }

    public void setDefaultRadius(int i10) {
        f1626u = i10;
    }

    public final void t(String str) {
        float[] fArr;
        if (str != null && str.length() != 0 && this.f1791c != null && (fArr = this.f1630m) != null) {
            if (this.f1633p + 1 > fArr.length) {
                this.f1630m = Arrays.copyOf(fArr, fArr.length + 1);
            }
            this.f1630m[this.f1633p] = (float) Integer.parseInt(str);
            this.f1633p++;
        }
    }

    public final void u(String str) {
        Context context;
        int[] iArr;
        if (str != null && str.length() != 0 && (context = this.f1791c) != null && (iArr = this.f1631n) != null) {
            if (this.f1632o + 1 > iArr.length) {
                this.f1631n = Arrays.copyOf(iArr, iArr.length + 1);
            }
            this.f1631n[this.f1632o] = (int) (((float) Integer.parseInt(str)) * context.getResources().getDisplayMetrics().density);
            this.f1632o++;
        }
    }
}
