package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import c1.c;
import c1.l;
import c1.p;
import c1.r;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import u0.d;
import w0.e;
import w0.f;
import w0.i;
import w0.k;
import w0.o;
import x0.n;

public class ConstraintLayout extends ViewGroup {

    /* renamed from: r  reason: collision with root package name */
    public static r f1797r;

    /* renamed from: a  reason: collision with root package name */
    public final SparseArray f1798a = new SparseArray();

    /* renamed from: b  reason: collision with root package name */
    public final ArrayList f1799b = new ArrayList(4);

    /* renamed from: c  reason: collision with root package name */
    public final f f1800c = new f();

    /* renamed from: d  reason: collision with root package name */
    public int f1801d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1802e = 0;

    /* renamed from: f  reason: collision with root package name */
    public int f1803f = Integer.MAX_VALUE;

    /* renamed from: g  reason: collision with root package name */
    public int f1804g = Integer.MAX_VALUE;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1805h = true;

    /* renamed from: i  reason: collision with root package name */
    public int f1806i = 257;

    /* renamed from: j  reason: collision with root package name */
    public l f1807j = null;

    /* renamed from: k  reason: collision with root package name */
    public a1.r f1808k = null;

    /* renamed from: l  reason: collision with root package name */
    public int f1809l = -1;

    /* renamed from: m  reason: collision with root package name */
    public HashMap f1810m = new HashMap();

    /* renamed from: n  reason: collision with root package name */
    public final SparseArray f1811n = new SparseArray();

    /* renamed from: o  reason: collision with root package name */
    public final n f1812o = new n(this, this);

    /* renamed from: p  reason: collision with root package name */
    public int f1813p = 0;

    /* renamed from: q  reason: collision with root package name */
    public int f1814q = 0;

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        j(attributeSet, 0);
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int max2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return max2 > 0 ? max2 : max;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, c1.r] */
    public static r getSharedValues() {
        if (f1797r == null) {
            ? obj = new Object();
            new SparseIntArray();
            obj.f3927a = new HashMap();
            f1797r = obj;
        }
        return f1797r;
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof c;
    }

    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.f1799b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i10 = 0; i10 < size; i10++) {
                ((ConstraintHelper) arrayList.get(i10)).p(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = (float) getWidth();
            float height = (float) getHeight();
            int childCount = getChildCount();
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (!(childAt.getVisibility() == 8 || (tag = childAt.getTag()) == null || !(tag instanceof String))) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i12 = (int) ((((float) parseInt) / 1080.0f) * width);
                        int i13 = (int) ((((float) parseInt2) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f10 = (float) i12;
                        float f11 = (float) i13;
                        float f12 = (float) (i12 + ((int) ((((float) parseInt3) / 1080.0f) * width)));
                        Canvas canvas2 = canvas;
                        float f13 = f11;
                        float f14 = f11;
                        float f15 = f12;
                        float f16 = f10;
                        Paint paint2 = paint;
                        canvas2.drawLine(f10, f13, f15, f14, paint);
                        float parseInt4 = (float) (i13 + ((int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * height)));
                        float f17 = f12;
                        float f18 = parseInt4;
                        canvas2.drawLine(f17, f14, f15, f18, paint);
                        float f19 = parseInt4;
                        float f20 = f16;
                        canvas2.drawLine(f17, f19, f20, f18, paint);
                        float f21 = f16;
                        canvas2.drawLine(f21, f19, f20, f14, paint);
                        paint.setColor(-16711936);
                        float f22 = f12;
                        Paint paint3 = paint;
                        canvas2.drawLine(f21, f14, f22, parseInt4, paint);
                        canvas2.drawLine(f21, parseInt4, f22, f14, paint);
                    }
                }
            }
        }
    }

    public final void forceLayout() {
        this.f1805h = true;
        super.forceLayout();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v50, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v23, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v52, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v25, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v56, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v28, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v58, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v30, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v61, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v33, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v63, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v35, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v66, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v38, resolved type: w0.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v68, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v40, resolved type: w0.e} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x02c4  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00ee A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0109  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x011b  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0169  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0176  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0197  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x019f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void g(boolean r20, android.view.View r21, w0.e r22, c1.c r23, android.util.SparseArray r24) {
        /*
            r19 = this;
            r0 = r21
            r6 = r22
            r7 = r23
            r8 = r24
            r23.a()
            int r1 = r21.getVisibility()
            r6.f28576i0 = r1
            boolean r1 = r7.f3744f0
            r9 = 1
            if (r1 == 0) goto L_0x001c
            r6.F = r9
            r1 = 8
            r6.f28576i0 = r1
        L_0x001c:
            r6.f28574h0 = r0
            boolean r1 = r0 instanceof androidx.constraintlayout.widget.ConstraintHelper
            if (r1 == 0) goto L_0x002e
            androidx.constraintlayout.widget.ConstraintHelper r0 = (androidx.constraintlayout.widget.ConstraintHelper) r0
            r10 = r19
            w0.f r1 = r10.f1800c
            boolean r1 = r1.A0
            r0.n(r6, r1)
            goto L_0x0030
        L_0x002e:
            r10 = r19
        L_0x0030:
            boolean r0 = r7.f3740d0
            r11 = -1
            if (r0 == 0) goto L_0x0066
            r0 = r6
            w0.i r0 = (w0.i) r0
            int r1 = r7.f3760n0
            int r2 = r7.f3762o0
            float r3 = r7.f3764p0
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r5 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r5 == 0) goto L_0x004e
            if (r5 <= 0) goto L_0x032c
            r0.f28635v0 = r3
            r0.f28636w0 = r11
            r0.f28637x0 = r11
            goto L_0x032c
        L_0x004e:
            if (r1 == r11) goto L_0x005a
            if (r1 <= r11) goto L_0x032c
            r0.f28635v0 = r4
            r0.f28636w0 = r1
            r0.f28637x0 = r11
            goto L_0x032c
        L_0x005a:
            if (r2 == r11) goto L_0x032c
            if (r2 <= r11) goto L_0x032c
            r0.f28635v0 = r4
            r0.f28636w0 = r11
            r0.f28637x0 = r2
            goto L_0x032c
        L_0x0066:
            int r0 = r7.f3746g0
            int r1 = r7.f3748h0
            int r12 = r7.f3750i0
            int r13 = r7.f3752j0
            int r5 = r7.f3754k0
            int r14 = r7.f3756l0
            float r15 = r7.f3758m0
            int r2 = r7.f3763p
            r4 = 4
            r3 = 2
            r9 = 0
            if (r2 == r11) goto L_0x00a0
            java.lang.Object r0 = r8.get(r2)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0098
            float r8 = r7.f3767r
            int r5 = r7.f3765q
            r12 = 7
            r13 = 0
            r0 = r22
            r1 = r12
            r14 = 2
            r3 = r12
            r12 = 4
            r4 = r5
            r5 = r13
            r0.x(r1, r2, r3, r4, r5)
            r6.D = r8
            goto L_0x009a
        L_0x0098:
            r12 = 4
            r14 = 2
        L_0x009a:
            r17 = 2
            r18 = 4
            goto L_0x01a1
        L_0x00a0:
            if (r0 == r11) goto L_0x00c0
            java.lang.Object r0 = r8.get(r0)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x00bb
            int r1 = r7.leftMargin
            r0 = r22
            r16 = r1
            r1 = r3
            r17 = 2
            r3 = r17
            r18 = 4
            r4 = r16
            goto L_0x00d7
        L_0x00bb:
            r17 = 2
            r18 = 4
            goto L_0x00da
        L_0x00c0:
            r17 = 2
            r18 = 4
            if (r1 == r11) goto L_0x00da
            java.lang.Object r0 = r8.get(r1)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x00da
            int r4 = r7.leftMargin
            r0 = r22
            r1 = r17
            r3 = r18
        L_0x00d7:
            r0.x(r1, r2, r3, r4, r5)
        L_0x00da:
            if (r12 == r11) goto L_0x00ee
            java.lang.Object r0 = r8.get(r12)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0105
            int r4 = r7.rightMargin
            r0 = r22
            r1 = r18
            r3 = r17
            goto L_0x0101
        L_0x00ee:
            if (r13 == r11) goto L_0x0105
            java.lang.Object r0 = r8.get(r13)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0105
            int r4 = r7.rightMargin
            r0 = r22
            r1 = r18
            r3 = r18
        L_0x0101:
            r5 = r14
            r0.x(r1, r2, r3, r4, r5)
        L_0x0105:
            int r0 = r7.f3749i
            if (r0 == r11) goto L_0x011b
            java.lang.Object r0 = r8.get(r0)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0135
            int r4 = r7.topMargin
            int r5 = r7.f3773x
            r0 = r22
            r12 = 3
            r1 = r12
            goto L_0x0131
        L_0x011b:
            int r0 = r7.f3751j
            if (r0 == r11) goto L_0x0135
            java.lang.Object r0 = r8.get(r0)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0135
            int r4 = r7.topMargin
            int r5 = r7.f3773x
            r0 = r22
            r3 = 3
            r1 = r3
            r12 = 5
        L_0x0131:
            r3 = r12
            r0.x(r1, r2, r3, r4, r5)
        L_0x0135:
            int r0 = r7.f3753k
            if (r0 == r11) goto L_0x014c
            java.lang.Object r0 = r8.get(r0)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0165
            int r4 = r7.bottomMargin
            int r5 = r7.f3775z
            r0 = r22
            r3 = 5
            r1 = r3
            r12 = 3
            goto L_0x0161
        L_0x014c:
            int r0 = r7.f3755l
            if (r0 == r11) goto L_0x0165
            java.lang.Object r0 = r8.get(r0)
            r2 = r0
            w0.e r2 = (w0.e) r2
            if (r2 == 0) goto L_0x0165
            int r4 = r7.bottomMargin
            int r5 = r7.f3775z
            r0 = r22
            r12 = 5
            r1 = r12
        L_0x0161:
            r3 = r12
            r0.x(r1, r2, r3, r4, r5)
        L_0x0165:
            int r4 = r7.f3757m
            if (r4 == r11) goto L_0x0176
            r5 = 6
            r0 = r19
            r1 = r22
            r2 = r23
            r3 = r24
        L_0x0172:
            r0.p(r1, r2, r3, r4, r5)
            goto L_0x0193
        L_0x0176:
            int r4 = r7.f3759n
            if (r4 == r11) goto L_0x0185
            r0 = r19
            r1 = r22
            r2 = r23
            r3 = r24
            r8 = 3
        L_0x0183:
            r5 = r8
            goto L_0x0172
        L_0x0185:
            int r4 = r7.f3761o
            if (r4 == r11) goto L_0x0193
            r0 = r19
            r1 = r22
            r2 = r23
            r3 = r24
            r8 = 5
            goto L_0x0183
        L_0x0193:
            int r0 = (r15 > r9 ? 1 : (r15 == r9 ? 0 : -1))
            if (r0 < 0) goto L_0x0199
            r6.f28570f0 = r15
        L_0x0199:
            float r0 = r7.F
            int r1 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r1 < 0) goto L_0x01a1
            r6.f28572g0 = r0
        L_0x01a1:
            if (r20 == 0) goto L_0x01b1
            int r0 = r7.T
            if (r0 != r11) goto L_0x01ab
            int r1 = r7.U
            if (r1 == r11) goto L_0x01b1
        L_0x01ab:
            int r1 = r7.U
            r6.f28560a0 = r0
            r6.f28562b0 = r1
        L_0x01b1:
            boolean r0 = r7.f3734a0
            w0.d r1 = w0.d.f28555b
            w0.d r2 = w0.d.f28554a
            w0.d r3 = w0.d.f28557d
            w0.d r4 = w0.d.f28556c
            r5 = -2
            r8 = 0
            if (r0 != 0) goto L_0x01e9
            int r0 = r7.width
            if (r0 != r11) goto L_0x01e2
            boolean r0 = r7.W
            if (r0 == 0) goto L_0x01cc
            r6.O(r4)
        L_0x01ca:
            r0 = 2
            goto L_0x01d0
        L_0x01cc:
            r6.O(r3)
            goto L_0x01ca
        L_0x01d0:
            w0.c r0 = r6.k(r0)
            int r12 = r7.leftMargin
            r0.f28551g = r12
            r0 = 4
            w0.c r0 = r6.k(r0)
            int r12 = r7.rightMargin
            r0.f28551g = r12
            goto L_0x01f8
        L_0x01e2:
            r6.O(r4)
            r6.Q(r8)
            goto L_0x01f8
        L_0x01e9:
            r6.O(r2)
            int r0 = r7.width
            r6.Q(r0)
            int r0 = r7.width
            if (r0 != r5) goto L_0x01f8
            r6.O(r1)
        L_0x01f8:
            boolean r0 = r7.f3736b0
            if (r0 != 0) goto L_0x0226
            int r0 = r7.height
            if (r0 != r11) goto L_0x021f
            boolean r0 = r7.X
            if (r0 == 0) goto L_0x0209
            r6.P(r4)
        L_0x0207:
            r0 = 3
            goto L_0x020d
        L_0x0209:
            r6.P(r3)
            goto L_0x0207
        L_0x020d:
            w0.c r0 = r6.k(r0)
            int r1 = r7.topMargin
            r0.f28551g = r1
            r0 = 5
            w0.c r0 = r6.k(r0)
            int r1 = r7.bottomMargin
            r0.f28551g = r1
            goto L_0x0235
        L_0x021f:
            r6.P(r4)
            r6.N(r8)
            goto L_0x0235
        L_0x0226:
            r6.P(r2)
            int r0 = r7.height
            r6.N(r0)
            int r0 = r7.height
            if (r0 != r5) goto L_0x0235
            r6.P(r1)
        L_0x0235:
            java.lang.String r0 = r7.G
            if (r0 == 0) goto L_0x02c9
            int r1 = r0.length()
            if (r1 != 0) goto L_0x0241
            goto L_0x02c9
        L_0x0241:
            int r1 = r0.length()
            r2 = 44
            int r2 = r0.indexOf(r2)
            if (r2 <= 0) goto L_0x026e
            int r3 = r1 + -1
            if (r2 >= r3) goto L_0x026e
            java.lang.String r3 = r0.substring(r8, r2)
            java.lang.String r4 = "W"
            boolean r4 = r3.equalsIgnoreCase(r4)
            if (r4 == 0) goto L_0x0260
            r3 = 1
            r11 = 0
            goto L_0x026c
        L_0x0260:
            java.lang.String r4 = "H"
            boolean r3 = r3.equalsIgnoreCase(r4)
            if (r3 == 0) goto L_0x026b
            r3 = 1
            r11 = 1
            goto L_0x026c
        L_0x026b:
            r3 = 1
        L_0x026c:
            int r2 = r2 + r3
            goto L_0x0270
        L_0x026e:
            r3 = 1
            r2 = 0
        L_0x0270:
            r4 = 58
            int r4 = r0.indexOf(r4)
            if (r4 < 0) goto L_0x02af
            int r1 = r1 - r3
            if (r4 >= r1) goto L_0x02af
            java.lang.String r1 = r0.substring(r2, r4)
            int r4 = r4 + r3
            java.lang.String r0 = r0.substring(r4)
            int r2 = r1.length()
            if (r2 <= 0) goto L_0x02bf
            int r2 = r0.length()
            if (r2 <= 0) goto L_0x02bf
            float r1 = java.lang.Float.parseFloat(r1)     // Catch:{ NumberFormatException -> 0x02be }
            float r0 = java.lang.Float.parseFloat(r0)     // Catch:{ NumberFormatException -> 0x02be }
            int r2 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r2 <= 0) goto L_0x02bf
            int r2 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r2 <= 0) goto L_0x02bf
            r2 = 1
            if (r11 != r2) goto L_0x02a9
            float r0 = r0 / r1
            float r0 = java.lang.Math.abs(r0)     // Catch:{ NumberFormatException -> 0x02be }
            goto L_0x02c0
        L_0x02a9:
            float r1 = r1 / r0
            float r0 = java.lang.Math.abs(r1)     // Catch:{ NumberFormatException -> 0x02be }
            goto L_0x02c0
        L_0x02af:
            java.lang.String r0 = r0.substring(r2)
            int r1 = r0.length()
            if (r1 <= 0) goto L_0x02bf
            float r0 = java.lang.Float.parseFloat(r0)     // Catch:{ NumberFormatException -> 0x02be }
            goto L_0x02c0
        L_0x02be:
        L_0x02bf:
            r0 = 0
        L_0x02c0:
            int r1 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r1 <= 0) goto L_0x02cb
            r6.Y = r0
            r6.Z = r11
            goto L_0x02cb
        L_0x02c9:
            r6.Y = r9
        L_0x02cb:
            float r0 = r7.H
            float[] r1 = r6.f28588o0
            r1[r8] = r0
            float r0 = r7.I
            r2 = 1
            r1[r2] = r0
            int r0 = r7.J
            r6.f28584m0 = r0
            int r0 = r7.K
            r6.f28586n0 = r0
            int r0 = r7.Z
            if (r0 < 0) goto L_0x02e7
            r1 = 3
            if (r0 > r1) goto L_0x02e7
            r6.f28591q = r0
        L_0x02e7:
            int r0 = r7.L
            int r1 = r7.N
            int r2 = r7.P
            float r3 = r7.R
            r6.f28593r = r0
            r6.f28599u = r1
            r1 = 2147483647(0x7fffffff, float:NaN)
            if (r2 != r1) goto L_0x02f9
            r2 = 0
        L_0x02f9:
            r6.f28601v = r2
            r6.f28602w = r3
            r2 = 2
            r4 = 1065353216(0x3f800000, float:1.0)
            int r5 = (r3 > r9 ? 1 : (r3 == r9 ? 0 : -1))
            if (r5 <= 0) goto L_0x030c
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x030c
            if (r0 != 0) goto L_0x030c
            r6.f28593r = r2
        L_0x030c:
            int r0 = r7.M
            int r3 = r7.O
            int r5 = r7.Q
            float r7 = r7.S
            r6.f28595s = r0
            r6.f28603x = r3
            if (r5 != r1) goto L_0x031b
            goto L_0x031c
        L_0x031b:
            r8 = r5
        L_0x031c:
            r6.f28604y = r8
            r6.f28605z = r7
            int r1 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r1 <= 0) goto L_0x032c
            int r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r1 >= 0) goto L_0x032c
            if (r0 != 0) goto L_0x032c
            r6.f28595s = r2
        L_0x032c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.g(boolean, android.view.View, w0.e, c1.c, android.util.SparseArray):void");
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new c(-2);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    public int getMaxHeight() {
        return this.f1804g;
    }

    public int getMaxWidth() {
        return this.f1803f;
    }

    public int getMinHeight() {
        return this.f1802e;
    }

    public int getMinWidth() {
        return this.f1801d;
    }

    public int getOptimizationLevel() {
        return this.f1800c.I0;
    }

    public String getSceneString() {
        int id2;
        String str;
        StringBuilder sb2 = new StringBuilder();
        f fVar = this.f1800c;
        if (fVar.f28577j == null) {
            int id3 = getId();
            if (id3 != -1) {
                str = getContext().getResources().getResourceEntryName(id3);
            } else {
                str = "parent";
            }
            fVar.f28577j = str;
        }
        if (fVar.f28580k0 == null) {
            fVar.f28580k0 = fVar.f28577j;
            Log.v("ConstraintLayout", " setDebugName " + fVar.f28580k0);
        }
        Iterator it = fVar.f28646v0.iterator();
        while (it.hasNext()) {
            e eVar = (e) it.next();
            View view = (View) eVar.f28574h0;
            if (view != null) {
                if (eVar.f28577j == null && (id2 = view.getId()) != -1) {
                    eVar.f28577j = getContext().getResources().getResourceEntryName(id2);
                }
                if (eVar.f28580k0 == null) {
                    eVar.f28580k0 = eVar.f28577j;
                    Log.v("ConstraintLayout", " setDebugName " + eVar.f28580k0);
                }
            }
        }
        fVar.p(sb2);
        return sb2.toString();
    }

    public final View h(int i10) {
        return (View) this.f1798a.get(i10);
    }

    public final e i(View view) {
        if (view == this) {
            return this.f1800c;
        }
        if (view == null) {
            return null;
        }
        if (!(view.getLayoutParams() instanceof c)) {
            view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
            if (!(view.getLayoutParams() instanceof c)) {
                return null;
            }
        }
        return ((c) view.getLayoutParams()).f3766q0;
    }

    public final void j(AttributeSet attributeSet, int i10) {
        f fVar = this.f1800c;
        fVar.f28574h0 = this;
        n nVar = this.f1812o;
        fVar.f28609z0 = nVar;
        fVar.f28607x0.f29519h = nVar;
        this.f1798a.put(getId(), this);
        this.f1807j = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c, i10, 0);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 16) {
                    this.f1801d = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1801d);
                } else if (index == 17) {
                    this.f1802e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1802e);
                } else if (index == 14) {
                    this.f1803f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1803f);
                } else if (index == 15) {
                    this.f1804g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1804g);
                } else if (index == 113) {
                    this.f1806i = obtainStyledAttributes.getInt(index, this.f1806i);
                } else if (index == 56) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            l(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1808k = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        l lVar = new l();
                        this.f1807j = lVar;
                        lVar.j(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1807j = null;
                    }
                    this.f1809l = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        fVar.I0 = this.f1806i;
        d.f26953p = fVar.Y(512);
    }

    public final boolean k() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [a1.r, java.lang.Object] */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void l(int r11) {
        /*
            r10 = this;
            a1.r r0 = new a1.r
            android.content.Context r1 = r10.getContext()
            r0.<init>()
            r2 = -1
            r0.f222b = r2
            r0.f223c = r2
            android.util.SparseArray r3 = new android.util.SparseArray
            r3.<init>()
            r0.f225e = r3
            android.util.SparseArray r3 = new android.util.SparseArray
            r3.<init>()
            r0.f226f = r3
            r3 = 0
            r0.f227g = r3
            r0.f224d = r10
            android.content.res.Resources r4 = r1.getResources()
            android.content.res.XmlResourceParser r11 = r4.getXml(r11)
            int r4 = r11.getEventType()     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
        L_0x002d:
            r5 = 1
            if (r4 == r5) goto L_0x00b1
            if (r4 == 0) goto L_0x00a2
            r6 = 2
            if (r4 == r6) goto L_0x0037
            goto L_0x00a5
        L_0x0037:
            java.lang.String r4 = r11.getName()     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            int r7 = r4.hashCode()     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            r8 = 4
            r9 = 3
            switch(r7) {
                case -1349929691: goto L_0x0070;
                case 80204913: goto L_0x0066;
                case 1382829617: goto L_0x005d;
                case 1657696882: goto L_0x0053;
                case 1901439077: goto L_0x0045;
                default: goto L_0x0044;
            }     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
        L_0x0044:
            goto L_0x007a
        L_0x0045:
            java.lang.String r5 = "Variant"
            boolean r4 = r4.equals(r5)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r4 == 0) goto L_0x007a
            r5 = 3
            goto L_0x007b
        L_0x004f:
            r11 = move-exception
            goto L_0x00aa
        L_0x0051:
            r11 = move-exception
            goto L_0x00ae
        L_0x0053:
            java.lang.String r5 = "layoutDescription"
            boolean r4 = r4.equals(r5)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r4 == 0) goto L_0x007a
            r5 = 0
            goto L_0x007b
        L_0x005d:
            java.lang.String r7 = "StateSet"
            boolean r4 = r4.equals(r7)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r4 == 0) goto L_0x007a
            goto L_0x007b
        L_0x0066:
            java.lang.String r5 = "State"
            boolean r4 = r4.equals(r5)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r4 == 0) goto L_0x007a
            r5 = 2
            goto L_0x007b
        L_0x0070:
            java.lang.String r5 = "ConstraintSet"
            boolean r4 = r4.equals(r5)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r4 == 0) goto L_0x007a
            r5 = 4
            goto L_0x007b
        L_0x007a:
            r5 = -1
        L_0x007b:
            if (r5 == r6) goto L_0x0093
            if (r5 == r9) goto L_0x0086
            if (r5 == r8) goto L_0x0082
            goto L_0x00a5
        L_0x0082:
            r0.h(r1, r11)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            goto L_0x00a5
        L_0x0086:
            c1.e r4 = new c1.e     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            r4.<init>(r1, r11)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            if (r3 == 0) goto L_0x00a5
            java.util.ArrayList r5 = r3.f3777b     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            r5.add(r4)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            goto L_0x00a5
        L_0x0093:
            c1.d r3 = new c1.d     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            r3.<init>(r1, r11)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            java.lang.Object r4 = r0.f225e     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            android.util.SparseArray r4 = (android.util.SparseArray) r4     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            int r5 = r3.f3776a     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            r4.put(r5, r3)     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            goto L_0x00a5
        L_0x00a2:
            r11.getName()     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
        L_0x00a5:
            int r4 = r11.next()     // Catch:{ XmlPullParserException -> 0x0051, IOException -> 0x004f }
            goto L_0x002d
        L_0x00aa:
            r11.printStackTrace()
            goto L_0x00b1
        L_0x00ae:
            r11.printStackTrace()
        L_0x00b1:
            r10.f1808k = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.l(int):void");
    }

    public final void m(int i10, int i11, int i12, int i13, boolean z4, boolean z10) {
        n nVar = this.f1812o;
        int i14 = nVar.f29543d;
        int resolveSizeAndState = View.resolveSizeAndState(i12 + nVar.f29542c, i10, 0);
        int min = Math.min(this.f1803f, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.f1804g, View.resolveSizeAndState(i13 + i14, i11, 0) & 16777215);
        if (z4) {
            min |= 16777216;
        }
        if (z10) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:259:0x0522, code lost:
        if (r10.Y > 0.0f) goto L_0x0527;
     */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x046f  */
    /* JADX WARNING: Removed duplicated region for block: B:207:0x0486  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:419:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0131  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0167  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0169  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x016e  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x01ca A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x01d4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void n(w0.f r26, int r27, int r28, int r29) {
        /*
            r25 = this;
            r0 = r25
            r1 = r26
            r2 = r27
            int r3 = android.view.View.MeasureSpec.getMode(r28)
            int r4 = android.view.View.MeasureSpec.getSize(r28)
            int r5 = android.view.View.MeasureSpec.getMode(r29)
            int r6 = android.view.View.MeasureSpec.getSize(r29)
            int r7 = r25.getPaddingTop()
            r8 = 0
            int r7 = java.lang.Math.max(r8, r7)
            int r9 = r25.getPaddingBottom()
            int r9 = java.lang.Math.max(r8, r9)
            int r10 = r7 + r9
            int r11 = r25.getPaddingWidth()
            x0.n r12 = r0.f1812o
            r12.f29540a = r7
            r12.f29541b = r9
            r12.f29542c = r11
            r12.f29543d = r10
            r9 = r28
            r12.f29544e = r9
            r9 = r29
            r12.f29545f = r9
            int r9 = r25.getPaddingStart()
            int r9 = java.lang.Math.max(r8, r9)
            int r13 = r25.getPaddingEnd()
            int r13 = java.lang.Math.max(r8, r13)
            if (r9 > 0) goto L_0x005d
            if (r13 <= 0) goto L_0x0054
            goto L_0x005d
        L_0x0054:
            int r9 = r25.getPaddingLeft()
            int r9 = java.lang.Math.max(r8, r9)
            goto L_0x0064
        L_0x005d:
            boolean r14 = r25.k()
            if (r14 == 0) goto L_0x0064
            r9 = r13
        L_0x0064:
            int r4 = r4 - r11
            int r6 = r6 - r10
            int r10 = r12.f29543d
            int r11 = r12.f29542c
            w0.d r12 = w0.d.f28554a
            int r13 = r25.getChildCount()
            w0.d r14 = w0.d.f28555b
            r15 = 1073741824(0x40000000, float:2.0)
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r8) goto L_0x00a2
            if (r3 == 0) goto L_0x008a
            if (r3 == r15) goto L_0x0080
            r29 = r12
        L_0x007e:
            r15 = 0
            goto L_0x00b1
        L_0x0080:
            int r15 = r0.f1803f
            int r15 = r15 - r11
            int r15 = java.lang.Math.min(r15, r4)
            r29 = r12
            goto L_0x00b1
        L_0x008a:
            if (r13 != 0) goto L_0x009b
            int r15 = r0.f1801d
            r8 = 0
            int r16 = java.lang.Math.max(r8, r15)
            r29 = r12
            r12 = r14
            r15 = r16
        L_0x0098:
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x00b1
        L_0x009b:
            r8 = 0
            r29 = r12
            r12 = r14
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x007e
        L_0x00a2:
            r8 = 0
            if (r13 != 0) goto L_0x00af
            int r15 = r0.f1801d
            int r15 = java.lang.Math.max(r8, r15)
        L_0x00ab:
            r29 = r12
            r12 = r14
            goto L_0x0098
        L_0x00af:
            r15 = r4
            goto L_0x00ab
        L_0x00b1:
            if (r5 == r8) goto L_0x00e0
            if (r5 == 0) goto L_0x00cc
            r8 = 1073741824(0x40000000, float:2.0)
            if (r5 == r8) goto L_0x00bf
            r8 = r29
            r17 = r14
            r13 = 0
            goto L_0x00ec
        L_0x00bf:
            int r8 = r0.f1804g
            int r8 = r8 - r10
            int r8 = java.lang.Math.min(r8, r6)
            r13 = r8
            r17 = r14
            r8 = r29
            goto L_0x00ec
        L_0x00cc:
            if (r13 != 0) goto L_0x00db
            int r8 = r0.f1802e
            r13 = 0
            int r16 = java.lang.Math.max(r13, r8)
            r8 = r14
            r17 = r8
            r13 = r16
            goto L_0x00ec
        L_0x00db:
            r13 = 0
        L_0x00dc:
            r8 = r14
            r17 = r8
            goto L_0x00ec
        L_0x00e0:
            r8 = 0
            if (r13 != 0) goto L_0x00ea
            int r13 = r0.f1802e
            int r13 = java.lang.Math.max(r8, r13)
            goto L_0x00dc
        L_0x00ea:
            r13 = r6
            goto L_0x00dc
        L_0x00ec:
            int r14 = r26.s()
            r18 = r6
            x0.e r6 = r1.f28607x0
            r19 = r4
            r4 = 1
            if (r15 != r14) goto L_0x0102
            int r14 = r26.m()
            if (r13 == r14) goto L_0x0100
            goto L_0x0102
        L_0x0100:
            r14 = 0
            goto L_0x0105
        L_0x0102:
            r6.f29513b = r4
            goto L_0x0100
        L_0x0105:
            r1.f28560a0 = r14
            r1.f28562b0 = r14
            int r4 = r0.f1803f
            int r4 = r4 - r11
            r21 = r6
            int[] r6 = r1.C
            r6[r14] = r4
            int r4 = r0.f1804g
            int r4 = r4 - r10
            r16 = 1
            r6[r16] = r4
            r1.f28566d0 = r14
            r1.f28568e0 = r14
            r1.O(r12)
            r1.Q(r15)
            r1.P(r8)
            r1.N(r13)
            int r4 = r0.f1801d
            int r4 = r4 - r11
            if (r4 >= 0) goto L_0x0131
            r1.f28566d0 = r14
            goto L_0x0133
        L_0x0131:
            r1.f28566d0 = r4
        L_0x0133:
            int r4 = r0.f1802e
            int r4 = r4 - r10
            if (r4 >= 0) goto L_0x013b
            r1.f28568e0 = r14
            goto L_0x013d
        L_0x013b:
            r1.f28568e0 = r4
        L_0x013d:
            r1.C0 = r9
            r1.D0 = r7
            a4.w r4 = r1.f28606w0
            r4.getClass()
            x0.n r6 = r1.f28609z0
            java.util.ArrayList r7 = r1.f28646v0
            int r7 = r7.size()
            int r8 = r26.s()
            int r9 = r26.m()
            r10 = 128(0x80, float:1.794E-43)
            boolean r10 = w0.l.b(r2, r10)
            r11 = 64
            if (r10 != 0) goto L_0x0169
            boolean r2 = w0.l.b(r2, r11)
            if (r2 == 0) goto L_0x0167
            goto L_0x0169
        L_0x0167:
            r2 = 0
            goto L_0x016a
        L_0x0169:
            r2 = 1
        L_0x016a:
            w0.d r12 = w0.d.f28556c
            if (r2 == 0) goto L_0x01a5
            r14 = 0
        L_0x016f:
            if (r14 >= r7) goto L_0x01a5
            java.util.ArrayList r15 = r1.f28646v0
            java.lang.Object r15 = r15.get(r14)
            w0.e r15 = (w0.e) r15
            w0.d[] r11 = r15.U
            r16 = 0
            r13 = r11[r16]
            if (r13 != r12) goto L_0x0185
            r13 = 1
        L_0x0182:
            r20 = 1
            goto L_0x0187
        L_0x0185:
            r13 = 0
            goto L_0x0182
        L_0x0187:
            r11 = r11[r20]
            if (r11 != r12) goto L_0x018d
            r11 = 1
            goto L_0x018e
        L_0x018d:
            r11 = 0
        L_0x018e:
            if (r13 == 0) goto L_0x019b
            if (r11 == 0) goto L_0x019b
            float r11 = r15.Y
            r13 = 0
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 <= 0) goto L_0x019b
            r11 = 1
            goto L_0x019c
        L_0x019b:
            r11 = 0
        L_0x019c:
            boolean r13 = r15.z()
            if (r13 == 0) goto L_0x01a8
            if (r11 == 0) goto L_0x01a8
        L_0x01a4:
            r2 = 0
        L_0x01a5:
            r11 = 1073741824(0x40000000, float:2.0)
            goto L_0x01c8
        L_0x01a8:
            boolean r13 = r15.A()
            if (r13 == 0) goto L_0x01b1
            if (r11 == 0) goto L_0x01b1
            goto L_0x01a4
        L_0x01b1:
            boolean r11 = r15 instanceof w0.n
            if (r11 == 0) goto L_0x01b6
            goto L_0x01a4
        L_0x01b6:
            boolean r11 = r15.z()
            if (r11 != 0) goto L_0x01a4
            boolean r11 = r15.A()
            if (r11 == 0) goto L_0x01c3
            goto L_0x01a4
        L_0x01c3:
            int r14 = r14 + 1
            r11 = 64
            goto L_0x016f
        L_0x01c8:
            if (r3 != r11) goto L_0x01cc
            if (r5 == r11) goto L_0x01ce
        L_0x01cc:
            if (r10 == 0) goto L_0x01d0
        L_0x01ce:
            r11 = 1
            goto L_0x01d1
        L_0x01d0:
            r11 = 0
        L_0x01d1:
            r2 = r2 & r11
            if (r2 == 0) goto L_0x046f
            int[] r13 = r1.C
            r14 = 0
            r13 = r13[r14]
            r14 = r19
            int r13 = java.lang.Math.min(r13, r14)
            int[] r14 = r1.C
            r15 = 1
            r14 = r14[r15]
            r11 = r18
            int r11 = java.lang.Math.min(r14, r11)
            r14 = 1073741824(0x40000000, float:2.0)
            if (r3 != r14) goto L_0x01fb
            int r14 = r26.s()
            if (r14 == r13) goto L_0x01fb
            r1.Q(r13)
            x0.e r13 = r1.f28607x0
            r13.f29512a = r15
        L_0x01fb:
            r13 = 1073741824(0x40000000, float:2.0)
            if (r5 != r13) goto L_0x020c
            int r14 = r26.m()
            if (r14 == r11) goto L_0x020c
            r1.N(r11)
            x0.e r11 = r1.f28607x0
            r11.f29512a = r15
        L_0x020c:
            if (r3 != r13) goto L_0x03bb
            if (r5 != r13) goto L_0x03bb
            r10 = r10 & r15
            r11 = r21
            boolean r13 = r11.f29512a
            java.lang.Object r14 = r11.f29514c
            if (r13 != 0) goto L_0x0220
            boolean r13 = r11.f29513b
            if (r13 == 0) goto L_0x021e
            goto L_0x0220
        L_0x021e:
            r0 = 0
            goto L_0x0260
        L_0x0220:
            r13 = r14
            w0.f r13 = (w0.f) r13
            java.util.ArrayList r15 = r13.f28646v0
            java.util.Iterator r15 = r15.iterator()
        L_0x0229:
            boolean r18 = r15.hasNext()
            if (r18 == 0) goto L_0x024e
            java.lang.Object r18 = r15.next()
            r0 = r18
            w0.e r0 = (w0.e) r0
            r0.j()
            r18 = r15
            r15 = 0
            r0.f28559a = r15
            x0.k r15 = r0.f28565d
            r15.n()
            x0.m r0 = r0.f28567e
            r0.m()
            r0 = r25
            r15 = r18
            goto L_0x0229
        L_0x024e:
            r13.j()
            r0 = 0
            r13.f28559a = r0
            x0.k r15 = r13.f28565d
            r15.n()
            x0.m r13 = r13.f28567e
            r13.m()
            r11.f29513b = r0
        L_0x0260:
            java.lang.Object r13 = r11.f29515d
            w0.f r13 = (w0.f) r13
            r11.b(r13)
            w0.f r14 = (w0.f) r14
            r14.f28560a0 = r0
            r14.f28562b0 = r0
            w0.d r13 = r14.l(r0)
            r0 = 1
            w0.d r15 = r14.l(r0)
            boolean r0 = r11.f29512a
            if (r0 == 0) goto L_0x027d
            r11.c()
        L_0x027d:
            int r0 = r14.t()
            r18 = r2
            int r2 = r14.u()
            r21 = r6
            x0.k r6 = r14.f28565d
            x0.f r6 = r6.f29561h
            r6.d(r0)
            x0.m r6 = r14.f28567e
            x0.f r6 = r6.f29561h
            r6.d(r2)
            r11.g()
            java.lang.Object r6 = r11.f29516e
            r23 = r8
            r8 = r17
            if (r13 == r8) goto L_0x02ae
            if (r15 != r8) goto L_0x02a5
            goto L_0x02ae
        L_0x02a5:
            r24 = r4
            r17 = r9
            r9 = r29
            r29 = r12
            goto L_0x0310
        L_0x02ae:
            if (r10 == 0) goto L_0x02cb
            r17 = r6
            java.util.ArrayList r17 = (java.util.ArrayList) r17
            java.util.Iterator r17 = r17.iterator()
        L_0x02b8:
            boolean r24 = r17.hasNext()
            if (r24 == 0) goto L_0x02cb
            java.lang.Object r24 = r17.next()
            x0.p r24 = (x0.p) r24
            boolean r24 = r24.k()
            if (r24 != 0) goto L_0x02b8
            r10 = 0
        L_0x02cb:
            if (r10 == 0) goto L_0x02ee
            if (r13 != r8) goto L_0x02ee
            r17 = r9
            r9 = r29
            r14.O(r9)
            r24 = r4
            r29 = r12
            r4 = 0
            int r12 = r11.d(r14, r4)
            r14.Q(r12)
            x0.k r4 = r14.f28565d
            x0.g r4 = r4.f29558e
            int r12 = r14.s()
            r4.d(r12)
            goto L_0x02f6
        L_0x02ee:
            r24 = r4
            r17 = r9
            r9 = r29
            r29 = r12
        L_0x02f6:
            if (r10 == 0) goto L_0x0310
            if (r15 != r8) goto L_0x0310
            r14.P(r9)
            r4 = 1
            int r10 = r11.d(r14, r4)
            r14.N(r10)
            x0.m r4 = r14.f28567e
            x0.g r4 = r4.f29558e
            int r10 = r14.m()
            r4.d(r10)
        L_0x0310:
            w0.d[] r4 = r14.U
            r10 = 0
            r4 = r4[r10]
            w0.d r10 = w0.d.f28557d
            if (r4 == r9) goto L_0x031e
            if (r4 != r10) goto L_0x031c
            goto L_0x031e
        L_0x031c:
            r0 = 0
            goto L_0x0356
        L_0x031e:
            int r4 = r14.s()
            int r4 = r4 + r0
            x0.k r12 = r14.f28565d
            x0.f r12 = r12.f29562i
            r12.d(r4)
            x0.k r12 = r14.f28565d
            x0.g r12 = r12.f29558e
            int r4 = r4 - r0
            r12.d(r4)
            r11.g()
            w0.d[] r0 = r14.U
            r4 = 1
            r0 = r0[r4]
            if (r0 == r9) goto L_0x033e
            if (r0 != r10) goto L_0x0352
        L_0x033e:
            int r0 = r14.m()
            int r0 = r0 + r2
            x0.m r4 = r14.f28567e
            x0.f r4 = r4.f29562i
            r4.d(r0)
            x0.m r4 = r14.f28567e
            x0.g r4 = r4.f29558e
            int r0 = r0 - r2
            r4.d(r0)
        L_0x0352:
            r11.g()
            r0 = 1
        L_0x0356:
            java.util.ArrayList r6 = (java.util.ArrayList) r6
            java.util.Iterator r2 = r6.iterator()
        L_0x035c:
            boolean r4 = r2.hasNext()
            if (r4 == 0) goto L_0x0375
            java.lang.Object r4 = r2.next()
            x0.p r4 = (x0.p) r4
            w0.e r10 = r4.f29555b
            if (r10 != r14) goto L_0x0371
            boolean r10 = r4.f29560g
            if (r10 != 0) goto L_0x0371
            goto L_0x035c
        L_0x0371:
            r4.e()
            goto L_0x035c
        L_0x0375:
            java.util.Iterator r2 = r6.iterator()
        L_0x0379:
            boolean r4 = r2.hasNext()
            if (r4 == 0) goto L_0x03ae
            java.lang.Object r4 = r2.next()
            x0.p r4 = (x0.p) r4
            if (r0 != 0) goto L_0x038c
            w0.e r6 = r4.f29555b
            if (r6 != r14) goto L_0x038c
            goto L_0x0379
        L_0x038c:
            x0.f r6 = r4.f29561h
            boolean r6 = r6.f29530j
            if (r6 != 0) goto L_0x0394
        L_0x0392:
            r0 = 0
            goto L_0x03af
        L_0x0394:
            x0.f r6 = r4.f29562i
            boolean r6 = r6.f29530j
            if (r6 != 0) goto L_0x039f
            boolean r6 = r4 instanceof x0.i
            if (r6 != 0) goto L_0x039f
            goto L_0x0392
        L_0x039f:
            x0.g r6 = r4.f29558e
            boolean r6 = r6.f29530j
            if (r6 != 0) goto L_0x0379
            boolean r6 = r4 instanceof x0.c
            if (r6 != 0) goto L_0x0379
            boolean r4 = r4 instanceof x0.i
            if (r4 != 0) goto L_0x0379
            goto L_0x0392
        L_0x03ae:
            r0 = 1
        L_0x03af:
            r14.O(r13)
            r14.P(r15)
            r4 = r0
            r0 = 1073741824(0x40000000, float:2.0)
            r2 = 2
            goto L_0x045f
        L_0x03bb:
            r18 = r2
            r24 = r4
            r23 = r8
            r8 = r17
            r11 = r21
            r21 = r6
            r17 = r9
            r9 = r29
            r29 = r12
            boolean r0 = r11.f29512a
            java.lang.Object r2 = r11.f29514c
            if (r0 == 0) goto L_0x0425
            r0 = r2
            w0.f r0 = (w0.f) r0
            java.util.ArrayList r4 = r0.f28646v0
            java.util.Iterator r4 = r4.iterator()
        L_0x03dc:
            boolean r6 = r4.hasNext()
            if (r6 == 0) goto L_0x0405
            java.lang.Object r6 = r4.next()
            w0.e r6 = (w0.e) r6
            r6.j()
            r12 = 0
            r6.f28559a = r12
            x0.k r13 = r6.f28565d
            x0.g r14 = r13.f29558e
            r14.f29530j = r12
            r13.f29560g = r12
            r13.n()
            x0.m r6 = r6.f28567e
            x0.g r13 = r6.f29558e
            r13.f29530j = r12
            r6.f29560g = r12
            r6.m()
            goto L_0x03dc
        L_0x0405:
            r12 = 0
            r0.j()
            r0.f28559a = r12
            x0.k r4 = r0.f28565d
            x0.g r6 = r4.f29558e
            r6.f29530j = r12
            r4.f29560g = r12
            r4.n()
            x0.m r0 = r0.f28567e
            x0.g r4 = r0.f29558e
            r4.f29530j = r12
            r0.f29560g = r12
            r0.m()
            r11.c()
            goto L_0x0426
        L_0x0425:
            r12 = 0
        L_0x0426:
            java.lang.Object r0 = r11.f29515d
            w0.f r0 = (w0.f) r0
            r11.b(r0)
            w0.f r2 = (w0.f) r2
            r2.f28560a0 = r12
            r2.f28562b0 = r12
            x0.k r0 = r2.f28565d
            x0.f r0 = r0.f29561h
            r0.d(r12)
            x0.m r0 = r2.f28567e
            x0.f r0 = r0.f29561h
            r0.d(r12)
            r0 = 1073741824(0x40000000, float:2.0)
            if (r3 != r0) goto L_0x0450
            boolean r2 = r1.W(r12, r10)
            r4 = 1
            r20 = r4 & r2
            r6 = r20
            r2 = 1
            goto L_0x0453
        L_0x0450:
            r4 = 1
            r2 = 0
            r6 = 1
        L_0x0453:
            if (r5 != r0) goto L_0x045e
            boolean r10 = r1.W(r4, r10)
            r4 = r6 & r10
            int r2 = r2 + 1
            goto L_0x045f
        L_0x045e:
            r4 = r6
        L_0x045f:
            if (r4 == 0) goto L_0x0481
            if (r3 != r0) goto L_0x0465
            r3 = 1
            goto L_0x0466
        L_0x0465:
            r3 = 0
        L_0x0466:
            if (r5 != r0) goto L_0x046a
            r0 = 1
            goto L_0x046b
        L_0x046a:
            r0 = 0
        L_0x046b:
            r1.R(r3, r0)
            goto L_0x0481
        L_0x046f:
            r18 = r2
            r24 = r4
            r21 = r6
            r23 = r8
            r8 = r17
            r17 = r9
            r9 = r29
            r29 = r12
            r2 = 0
            r4 = 0
        L_0x0481:
            if (r4 == 0) goto L_0x0486
            r0 = 2
            if (r2 == r0) goto L_0x0785
        L_0x0486:
            int r0 = r1.I0
            r2 = 8
            if (r7 <= 0) goto L_0x05a6
            java.util.ArrayList r3 = r1.f28646v0
            int r3 = r3.size()
            r4 = 64
            boolean r4 = r1.Y(r4)
            x0.n r5 = r1.f28609z0
            r6 = 0
        L_0x049b:
            if (r6 >= r3) goto L_0x0538
            java.util.ArrayList r10 = r1.f28646v0
            java.lang.Object r10 = r10.get(r6)
            w0.e r10 = (w0.e) r10
            boolean r11 = r10 instanceof w0.i
            if (r11 == 0) goto L_0x04b0
        L_0x04a9:
            r14 = r29
            r13 = r24
            r12 = 0
            goto L_0x0530
        L_0x04b0:
            boolean r11 = r10 instanceof w0.a
            if (r11 == 0) goto L_0x04b5
            goto L_0x04a9
        L_0x04b5:
            boolean r11 = r10.G
            if (r11 == 0) goto L_0x04ba
            goto L_0x04a9
        L_0x04ba:
            if (r4 == 0) goto L_0x04d1
            x0.k r11 = r10.f28565d
            if (r11 == 0) goto L_0x04d1
            x0.m r12 = r10.f28567e
            if (r12 == 0) goto L_0x04d1
            x0.g r11 = r11.f29558e
            boolean r11 = r11.f29530j
            if (r11 == 0) goto L_0x04d1
            x0.g r11 = r12.f29558e
            boolean r11 = r11.f29530j
            if (r11 == 0) goto L_0x04d1
            goto L_0x04a9
        L_0x04d1:
            r11 = 0
            w0.d r12 = r10.l(r11)
            r11 = 1
            w0.d r13 = r10.l(r11)
            r14 = r29
            if (r12 != r14) goto L_0x04eb
            int r15 = r10.f28593r
            if (r15 == r11) goto L_0x04eb
            if (r13 != r14) goto L_0x04eb
            int r15 = r10.f28595s
            if (r15 == r11) goto L_0x04eb
            r15 = 1
            goto L_0x04ec
        L_0x04eb:
            r15 = 0
        L_0x04ec:
            if (r15 != 0) goto L_0x051b
            boolean r22 = r1.Y(r11)
            if (r22 == 0) goto L_0x051b
            boolean r11 = r10 instanceof w0.n
            if (r11 != 0) goto L_0x051b
            if (r12 != r14) goto L_0x0507
            int r11 = r10.f28593r
            if (r11 != 0) goto L_0x0507
            if (r13 == r14) goto L_0x0507
            boolean r11 = r10.z()
            if (r11 != 0) goto L_0x0507
            r15 = 1
        L_0x0507:
            if (r13 != r14) goto L_0x0516
            int r11 = r10.f28595s
            if (r11 != 0) goto L_0x0516
            if (r12 == r14) goto L_0x0516
            boolean r11 = r10.z()
            if (r11 != 0) goto L_0x0516
            r15 = 1
        L_0x0516:
            if (r12 == r14) goto L_0x051d
            if (r13 != r14) goto L_0x051b
            goto L_0x051d
        L_0x051b:
            r12 = 0
            goto L_0x0525
        L_0x051d:
            float r11 = r10.Y
            r12 = 0
            int r11 = (r11 > r12 ? 1 : (r11 == r12 ? 0 : -1))
            if (r11 <= 0) goto L_0x0525
            goto L_0x0527
        L_0x0525:
            if (r15 == 0) goto L_0x052a
        L_0x0527:
            r13 = r24
            goto L_0x0530
        L_0x052a:
            r13 = r24
            r11 = 0
            r13.J(r11, r10, r5)
        L_0x0530:
            int r6 = r6 + 1
            r24 = r13
            r29 = r14
            goto L_0x049b
        L_0x0538:
            r13 = r24
            java.lang.Object r3 = r5.f29546g
            androidx.constraintlayout.widget.ConstraintLayout r3 = (androidx.constraintlayout.widget.ConstraintLayout) r3
            int r4 = r3.getChildCount()
            r5 = 0
        L_0x0543:
            if (r5 >= r4) goto L_0x058f
            android.view.View r6 = r3.getChildAt(r5)
            boolean r10 = r6 instanceof androidx.constraintlayout.widget.Placeholder
            if (r10 == 0) goto L_0x058c
            androidx.constraintlayout.widget.Placeholder r6 = (androidx.constraintlayout.widget.Placeholder) r6
            android.view.View r10 = r6.f1818b
            if (r10 != 0) goto L_0x0554
            goto L_0x058c
        L_0x0554:
            android.view.ViewGroup$LayoutParams r10 = r6.getLayoutParams()
            c1.c r10 = (c1.c) r10
            android.view.View r6 = r6.f1818b
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            c1.c r6 = (c1.c) r6
            w0.e r11 = r6.f3766q0
            r12 = 0
            r11.f28576i0 = r12
            w0.e r14 = r10.f3766q0
            w0.d[] r15 = r14.U
            r15 = r15[r12]
            if (r15 == r9) goto L_0x0576
            int r11 = r11.s()
            r14.Q(r11)
        L_0x0576:
            w0.e r10 = r10.f3766q0
            w0.d[] r11 = r10.U
            r12 = 1
            r11 = r11[r12]
            if (r11 == r9) goto L_0x0588
            w0.e r11 = r6.f3766q0
            int r11 = r11.m()
            r10.N(r11)
        L_0x0588:
            w0.e r6 = r6.f3766q0
            r6.f28576i0 = r2
        L_0x058c:
            int r5 = r5 + 1
            goto L_0x0543
        L_0x058f:
            java.util.ArrayList r3 = r3.f1799b
            int r4 = r3.size()
            if (r4 <= 0) goto L_0x05a8
            r5 = 0
        L_0x0598:
            if (r5 >= r4) goto L_0x05a8
            java.lang.Object r6 = r3.get(r5)
            androidx.constraintlayout.widget.ConstraintHelper r6 = (androidx.constraintlayout.widget.ConstraintHelper) r6
            r6.getClass()
            int r5 = r5 + 1
            goto L_0x0598
        L_0x05a6:
            r13 = r24
        L_0x05a8:
            r13.R(r1)
            java.lang.Object r3 = r13.f618b
            java.util.ArrayList r3 = (java.util.ArrayList) r3
            int r3 = r3.size()
            r6 = r17
            r5 = r23
            r4 = 0
            if (r7 <= 0) goto L_0x05bd
            r13.Q(r1, r4, r5, r6)
        L_0x05bd:
            if (r3 <= 0) goto L_0x0778
            w0.d[] r7 = r1.U
            r9 = r7[r4]
            if (r9 != r8) goto L_0x05c8
            r9 = 1
        L_0x05c6:
            r10 = 1
            goto L_0x05ca
        L_0x05c8:
            r9 = 0
            goto L_0x05c6
        L_0x05ca:
            r7 = r7[r10]
            if (r7 != r8) goto L_0x05d0
            r8 = 1
            goto L_0x05d1
        L_0x05d0:
            r8 = 0
        L_0x05d1:
            int r7 = r26.s()
            java.lang.Object r10 = r13.f620d
            w0.f r10 = (w0.f) r10
            int r10 = r10.f28566d0
            int r7 = java.lang.Math.max(r7, r10)
            int r10 = r26.m()
            java.lang.Object r11 = r13.f620d
            w0.f r11 = (w0.f) r11
            int r11 = r11.f28568e0
            int r10 = java.lang.Math.max(r10, r11)
            r12 = r10
            r10 = 0
            r11 = 0
        L_0x05f0:
            if (r10 >= r3) goto L_0x0683
            java.lang.Object r4 = r13.f618b
            java.util.ArrayList r4 = (java.util.ArrayList) r4
            java.lang.Object r4 = r4.get(r10)
            w0.e r4 = (w0.e) r4
            boolean r2 = r4 instanceof w0.n
            if (r2 != 0) goto L_0x0606
            r17 = r0
            r0 = r21
            goto L_0x0678
        L_0x0606:
            int r2 = r4.s()
            int r14 = r4.m()
            r17 = r0
            r0 = r21
            r15 = 1
            boolean r21 = r13.J(r15, r4, r0)
            r11 = r11 | r21
            int r15 = r4.s()
            r21 = r11
            int r11 = r4.m()
            if (r15 == r2) goto L_0x064a
            r4.Q(r15)
            if (r9 == 0) goto L_0x0648
            int r2 = r4.t()
            int r15 = r4.W
            int r2 = r2 + r15
            if (r2 <= r7) goto L_0x0648
            int r2 = r4.t()
            int r15 = r4.W
            int r2 = r2 + r15
            r15 = 4
            w0.c r15 = r4.k(r15)
            int r15 = r15.e()
            int r15 = r15 + r2
            int r7 = java.lang.Math.max(r7, r15)
        L_0x0648:
            r21 = 1
        L_0x064a:
            if (r11 == r14) goto L_0x0671
            r4.N(r11)
            if (r8 == 0) goto L_0x066f
            int r2 = r4.u()
            int r11 = r4.X
            int r2 = r2 + r11
            if (r2 <= r12) goto L_0x066f
            int r2 = r4.u()
            int r11 = r4.X
            int r2 = r2 + r11
            r11 = 5
            w0.c r11 = r4.k(r11)
            int r11 = r11.e()
            int r11 = r11 + r2
            int r12 = java.lang.Math.max(r12, r11)
        L_0x066f:
            r21 = 1
        L_0x0671:
            w0.n r4 = (w0.n) r4
            boolean r2 = r4.D0
            r2 = r21 | r2
            r11 = r2
        L_0x0678:
            int r10 = r10 + 1
            r21 = r0
            r0 = r17
            r2 = 8
            r4 = 0
            goto L_0x05f0
        L_0x0683:
            r17 = r0
            r0 = r21
            r2 = 0
            r4 = 2
        L_0x0689:
            if (r2 >= r4) goto L_0x0776
            r10 = 0
        L_0x068c:
            if (r10 >= r3) goto L_0x0758
            java.lang.Object r14 = r13.f618b
            java.util.ArrayList r14 = (java.util.ArrayList) r14
            java.lang.Object r14 = r14.get(r10)
            w0.e r14 = (w0.e) r14
            boolean r15 = r14 instanceof w0.j
            if (r15 == 0) goto L_0x06a4
            boolean r15 = r14 instanceof w0.n
            if (r15 == 0) goto L_0x06a1
            goto L_0x06a4
        L_0x06a1:
            r4 = 8
            goto L_0x06c7
        L_0x06a4:
            boolean r15 = r14 instanceof w0.i
            if (r15 == 0) goto L_0x06a9
            goto L_0x06a1
        L_0x06a9:
            int r15 = r14.f28576i0
            r4 = 8
            if (r15 != r4) goto L_0x06b0
            goto L_0x06c7
        L_0x06b0:
            if (r18 == 0) goto L_0x06c3
            x0.k r15 = r14.f28565d
            x0.g r15 = r15.f29558e
            boolean r15 = r15.f29530j
            if (r15 == 0) goto L_0x06c3
            x0.m r15 = r14.f28567e
            x0.g r15 = r15.f29558e
            boolean r15 = r15.f29530j
            if (r15 == 0) goto L_0x06c3
            goto L_0x06c7
        L_0x06c3:
            boolean r15 = r14 instanceof w0.n
            if (r15 == 0) goto L_0x06cf
        L_0x06c7:
            r22 = r0
            r21 = r3
            r4 = 5
            r15 = 4
            goto L_0x074d
        L_0x06cf:
            int r15 = r14.s()
            int r4 = r14.m()
            r21 = r3
            int r3 = r14.f28564c0
            r1 = 1
            if (r2 != r1) goto L_0x06df
            r1 = 2
        L_0x06df:
            boolean r1 = r13.J(r1, r14, r0)
            r1 = r1 | r11
            int r11 = r14.s()
            r22 = r0
            int r0 = r14.m()
            if (r11 == r15) goto L_0x0717
            r14.Q(r11)
            if (r9 == 0) goto L_0x0714
            int r1 = r14.t()
            int r11 = r14.W
            int r1 = r1 + r11
            if (r1 <= r7) goto L_0x0714
            int r1 = r14.t()
            int r11 = r14.W
            int r1 = r1 + r11
            r15 = 4
            w0.c r11 = r14.k(r15)
            int r11 = r11.e()
            int r11 = r11 + r1
            int r7 = java.lang.Math.max(r7, r11)
            goto L_0x0715
        L_0x0714:
            r15 = 4
        L_0x0715:
            r1 = 1
            goto L_0x0718
        L_0x0717:
            r15 = 4
        L_0x0718:
            if (r0 == r4) goto L_0x0741
            r14.N(r0)
            if (r8 == 0) goto L_0x073e
            int r0 = r14.u()
            int r1 = r14.X
            int r0 = r0 + r1
            if (r0 <= r12) goto L_0x073e
            int r0 = r14.u()
            int r1 = r14.X
            int r0 = r0 + r1
            r4 = 5
            w0.c r1 = r14.k(r4)
            int r1 = r1.e()
            int r1 = r1 + r0
            int r12 = java.lang.Math.max(r12, r1)
            goto L_0x073f
        L_0x073e:
            r4 = 5
        L_0x073f:
            r1 = 1
            goto L_0x0742
        L_0x0741:
            r4 = 5
        L_0x0742:
            boolean r0 = r14.E
            if (r0 == 0) goto L_0x074c
            int r0 = r14.f28564c0
            if (r3 == r0) goto L_0x074c
            r11 = 1
            goto L_0x074d
        L_0x074c:
            r11 = r1
        L_0x074d:
            int r10 = r10 + 1
            r1 = r26
            r3 = r21
            r0 = r22
            r4 = 2
            goto L_0x068c
        L_0x0758:
            r22 = r0
            r21 = r3
            r4 = 5
            r15 = 4
            if (r11 == 0) goto L_0x0771
            int r2 = r2 + 1
            r0 = r26
            r1 = 1
            r13.Q(r0, r2, r5, r6)
            r1 = r0
            r3 = r21
            r0 = r22
            r4 = 2
            r11 = 0
            goto L_0x0689
        L_0x0771:
            r0 = r26
        L_0x0773:
            r1 = r17
            goto L_0x077b
        L_0x0776:
            r0 = r1
            goto L_0x0773
        L_0x0778:
            r17 = r0
            goto L_0x0776
        L_0x077b:
            r0.I0 = r1
            r1 = 512(0x200, float:7.175E-43)
            boolean r0 = r0.Y(r1)
            u0.d.f26953p = r0
        L_0x0785:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.n(w0.f, int, int, int):void");
    }

    public final void o(String str, Integer num) {
        if ((str instanceof String) && (num instanceof Integer)) {
            if (this.f1810m == null) {
                this.f1810m = new HashMap();
            }
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.f1810m.put(str, Integer.valueOf(num.intValue()));
        }
    }

    public void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            c cVar = (c) childAt.getLayoutParams();
            e eVar = cVar.f3766q0;
            if ((childAt.getVisibility() != 8 || cVar.f3740d0 || cVar.f3742e0 || isInEditMode) && !cVar.f3744f0) {
                int t10 = eVar.t();
                int u10 = eVar.u();
                int s10 = eVar.s() + t10;
                int m10 = eVar.m() + u10;
                childAt.layout(t10, u10, s10, m10);
                if ((childAt instanceof Placeholder) && (content = ((Placeholder) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(t10, u10, s10, m10);
                }
            }
        }
        ArrayList arrayList = this.f1799b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i15 = 0; i15 < size; i15++) {
                ((ConstraintHelper) arrayList.get(i15)).o();
            }
        }
    }

    public void onMeasure(int i10, int i11) {
        boolean z4;
        e eVar;
        int i12 = i10;
        int i13 = i11;
        if (this.f1813p == i12) {
            int i14 = this.f1814q;
        }
        int i15 = 0;
        if (!this.f1805h) {
            int childCount = getChildCount();
            int i16 = 0;
            while (true) {
                if (i16 >= childCount) {
                    break;
                } else if (getChildAt(i16).isLayoutRequested()) {
                    this.f1805h = true;
                    break;
                } else {
                    i16++;
                }
            }
        }
        this.f1813p = i12;
        this.f1814q = i13;
        boolean k10 = k();
        f fVar = this.f1800c;
        fVar.A0 = k10;
        if (this.f1805h) {
            this.f1805h = false;
            int childCount2 = getChildCount();
            int i17 = 0;
            while (true) {
                if (i17 >= childCount2) {
                    z4 = false;
                    break;
                } else if (getChildAt(i17).isLayoutRequested()) {
                    z4 = true;
                    break;
                } else {
                    i17++;
                }
            }
            if (z4) {
                boolean isInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i18 = 0; i18 < childCount3; i18++) {
                    e i19 = i(getChildAt(i18));
                    if (i19 != null) {
                        i19.E();
                    }
                }
                Object obj = null;
                if (isInEditMode) {
                    for (int i20 = 0; i20 < childCount3; i20++) {
                        View childAt = getChildAt(i20);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            o(resourceName, Integer.valueOf(childAt.getId()));
                            int indexOf = resourceName.indexOf(47);
                            if (indexOf != -1) {
                                resourceName = resourceName.substring(indexOf + 1);
                            }
                            int id2 = childAt.getId();
                            if (id2 != 0) {
                                View view = (View) this.f1798a.get(id2);
                                if (view == null && (view = findViewById(id2)) != null && view != this && view.getParent() == this) {
                                    onViewAdded(view);
                                }
                                if (view != this) {
                                    if (view == null) {
                                        eVar = null;
                                    } else {
                                        eVar = ((c) view.getLayoutParams()).f3766q0;
                                    }
                                    eVar.f28580k0 = resourceName;
                                }
                            }
                            eVar = fVar;
                            eVar.f28580k0 = resourceName;
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (this.f1809l != -1) {
                    for (int i21 = 0; i21 < childCount3; i21++) {
                        View childAt2 = getChildAt(i21);
                        if (childAt2.getId() == this.f1809l && (childAt2 instanceof Constraints)) {
                            this.f1807j = ((Constraints) childAt2).getConstraintSet();
                        }
                    }
                }
                l lVar = this.f1807j;
                if (lVar != null) {
                    lVar.c(this);
                }
                fVar.f28646v0.clear();
                ArrayList arrayList = this.f1799b;
                int size = arrayList.size();
                if (size > 0) {
                    int i22 = 0;
                    while (i22 < size) {
                        ConstraintHelper constraintHelper = (ConstraintHelper) arrayList.get(i22);
                        if (constraintHelper.isInEditMode()) {
                            constraintHelper.setIds(constraintHelper.f1793e);
                        }
                        k kVar = constraintHelper.f1792d;
                        if (kVar != null) {
                            kVar.f28641w0 = i15;
                            Arrays.fill(kVar.f28640v0, obj);
                            for (int i23 = 0; i23 < constraintHelper.f1790b; i23++) {
                                int i24 = constraintHelper.f1789a[i23];
                                View h10 = h(i24);
                                if (h10 == null) {
                                    Integer valueOf = Integer.valueOf(i24);
                                    HashMap hashMap = constraintHelper.f1796h;
                                    String str = (String) hashMap.get(valueOf);
                                    int i25 = constraintHelper.i(this, str);
                                    if (i25 != 0) {
                                        constraintHelper.f1789a[i23] = i25;
                                        hashMap.put(Integer.valueOf(i25), str);
                                        h10 = h(i25);
                                    }
                                }
                                View view2 = h10;
                                if (view2 != null) {
                                    constraintHelper.f1792d.T(i(view2));
                                }
                            }
                            constraintHelper.f1792d.a();
                        }
                        i22++;
                        obj = null;
                        i15 = 0;
                    }
                }
                for (int i26 = 0; i26 < childCount3; i26++) {
                    View childAt3 = getChildAt(i26);
                    if (childAt3 instanceof Placeholder) {
                        Placeholder placeholder = (Placeholder) childAt3;
                        if (placeholder.f1817a == -1 && !placeholder.isInEditMode()) {
                            placeholder.setVisibility(placeholder.f1819c);
                        }
                        View findViewById = findViewById(placeholder.f1817a);
                        placeholder.f1818b = findViewById;
                        if (findViewById != null) {
                            ((c) findViewById.getLayoutParams()).f3744f0 = true;
                            placeholder.f1818b.setVisibility(0);
                            placeholder.setVisibility(0);
                        }
                    }
                }
                SparseArray sparseArray = this.f1811n;
                sparseArray.clear();
                sparseArray.put(0, fVar);
                sparseArray.put(getId(), fVar);
                for (int i27 = 0; i27 < childCount3; i27++) {
                    View childAt4 = getChildAt(i27);
                    sparseArray.put(childAt4.getId(), i(childAt4));
                }
                for (int i28 = 0; i28 < childCount3; i28++) {
                    View childAt5 = getChildAt(i28);
                    e i29 = i(childAt5);
                    if (i29 != null) {
                        c cVar = (c) childAt5.getLayoutParams();
                        fVar.f28646v0.add(i29);
                        e eVar2 = i29.V;
                        if (eVar2 != null) {
                            ((o) eVar2).f28646v0.remove(i29);
                            i29.E();
                        }
                        i29.V = fVar;
                        g(isInEditMode, childAt5, i29, cVar, sparseArray);
                    }
                }
            }
            if (z4) {
                fVar.f28606w0.R(fVar);
            }
        }
        n(fVar, this.f1806i, i12, i13);
        m(i10, i11, fVar.s(), fVar.m(), fVar.J0, fVar.K0);
    }

    public void onViewAdded(View view) {
        super.onViewAdded(view);
        e i10 = i(view);
        if ((view instanceof Guideline) && !(i10 instanceof i)) {
            c cVar = (c) view.getLayoutParams();
            i iVar = new i();
            cVar.f3766q0 = iVar;
            cVar.f3740d0 = true;
            iVar.U(cVar.V);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.r();
            ((c) view.getLayoutParams()).f3742e0 = true;
            ArrayList arrayList = this.f1799b;
            if (!arrayList.contains(constraintHelper)) {
                arrayList.add(constraintHelper);
            }
        }
        this.f1798a.put(view.getId(), view);
        this.f1805h = true;
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f1798a.remove(view.getId());
        e i10 = i(view);
        this.f1800c.f28646v0.remove(i10);
        i10.E();
        this.f1799b.remove(view);
        this.f1805h = true;
    }

    public final void p(e eVar, c cVar, SparseArray sparseArray, int i10, int i11) {
        View view = (View) this.f1798a.get(i10);
        e eVar2 = (e) sparseArray.get(i10);
        if (eVar2 != null && view != null && (view.getLayoutParams() instanceof c)) {
            cVar.f3738c0 = true;
            if (i11 == 6) {
                c cVar2 = (c) view.getLayoutParams();
                cVar2.f3738c0 = true;
                cVar2.f3766q0.E = true;
            }
            eVar.k(6).b(eVar2.k(i11), cVar.D, cVar.C, true);
            eVar.E = true;
            eVar.k(3).j();
            eVar.k(5).j();
        }
    }

    public void requestLayout() {
        this.f1805h = true;
        super.requestLayout();
    }

    public void setConstraintSet(l lVar) {
        this.f1807j = lVar;
    }

    public void setId(int i10) {
        int id2 = getId();
        SparseArray sparseArray = this.f1798a;
        sparseArray.remove(id2);
        super.setId(i10);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i10) {
        if (i10 != this.f1804g) {
            this.f1804g = i10;
            requestLayout();
        }
    }

    public void setMaxWidth(int i10) {
        if (i10 != this.f1803f) {
            this.f1803f = i10;
            requestLayout();
        }
    }

    public void setMinHeight(int i10) {
        if (i10 != this.f1802e) {
            this.f1802e = i10;
            requestLayout();
        }
    }

    public void setMinWidth(int i10) {
        if (i10 != this.f1801d) {
            this.f1801d = i10;
            requestLayout();
        }
    }

    public void setOnConstraintsChanged(c1.n nVar) {
        a1.r rVar = this.f1808k;
        if (rVar != null) {
            rVar.f227g = nVar;
        }
    }

    public void setOptimizationLevel(int i10) {
        this.f1806i = i10;
        f fVar = this.f1800c;
        fVar.I0 = i10;
        d.f26953p = fVar.Y(512);
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        j(attributeSet, i10);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new c(layoutParams);
    }
}
