package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import c1.c;

public class Guideline extends View {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1816a = true;

    public Guideline(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public final void draw(Canvas canvas) {
    }

    public final void onMeasure(int i10, int i11) {
        setMeasuredDimension(0, 0);
    }

    public void setFilterRedundantCalls(boolean z4) {
        this.f1816a = z4;
    }

    public void setGuidelineBegin(int i10) {
        c cVar = (c) getLayoutParams();
        if (!this.f1816a || cVar.f3733a != i10) {
            cVar.f3733a = i10;
            setLayoutParams(cVar);
        }
    }

    public void setGuidelineEnd(int i10) {
        c cVar = (c) getLayoutParams();
        if (!this.f1816a || cVar.f3735b != i10) {
            cVar.f3735b = i10;
            setLayoutParams(cVar);
        }
    }

    public void setGuidelinePercent(float f10) {
        c cVar = (c) getLayoutParams();
        if (!this.f1816a || cVar.f3737c != f10) {
            cVar.f3737c = f10;
            setLayoutParams(cVar);
        }
    }

    public void setVisibility(int i10) {
    }

    public Guideline(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public Guideline(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        super.setVisibility(8);
    }
}
