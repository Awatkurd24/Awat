package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import c1.c;
import c1.p;
import c1.q;
import c1.r;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class ReactiveGuide extends View implements q {

    /* renamed from: a  reason: collision with root package name */
    public int f1820a = -1;

    /* renamed from: b  reason: collision with root package name */
    public boolean f1821b;

    /* renamed from: c  reason: collision with root package name */
    public int f1822c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f1823d;

    public ReactiveGuide(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1821b = false;
        this.f1822c = 0;
        this.f1823d = true;
        super.setVisibility(8);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3904d);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 3) {
                    this.f1820a = obtainStyledAttributes.getResourceId(index, this.f1820a);
                } else if (index == 0) {
                    this.f1821b = obtainStyledAttributes.getBoolean(index, this.f1821b);
                } else if (index == 2) {
                    this.f1822c = obtainStyledAttributes.getResourceId(index, this.f1822c);
                } else if (index == 1) {
                    this.f1823d = obtainStyledAttributes.getBoolean(index, this.f1823d);
                }
            }
            obtainStyledAttributes.recycle();
        }
        if (this.f1820a != -1) {
            ConstraintLayout.getSharedValues().a(this.f1820a, this);
        }
    }

    public final void draw(Canvas canvas) {
    }

    public int getApplyToConstraintSetId() {
        return this.f1822c;
    }

    public int getAttributeId() {
        return this.f1820a;
    }

    public final void onMeasure(int i10, int i11) {
        setMeasuredDimension(0, 0);
    }

    public void setAnimateChange(boolean z4) {
        this.f1821b = z4;
    }

    public void setApplyToConstraintSetId(int i10) {
        this.f1822c = i10;
    }

    public void setAttributeId(int i10) {
        HashSet hashSet;
        r sharedValues = ConstraintLayout.getSharedValues();
        int i11 = this.f1820a;
        if (!(i11 == -1 || (hashSet = (HashSet) sharedValues.f3927a.get(Integer.valueOf(i11))) == null)) {
            ArrayList arrayList = new ArrayList();
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                q qVar = (q) weakReference.get();
                if (qVar == null || qVar == this) {
                    arrayList.add(weakReference);
                }
            }
            hashSet.removeAll(arrayList);
        }
        this.f1820a = i10;
        if (i10 != -1) {
            sharedValues.a(i10, this);
        }
    }

    public void setGuidelineBegin(int i10) {
        c cVar = (c) getLayoutParams();
        cVar.f3733a = i10;
        setLayoutParams(cVar);
    }

    public void setGuidelineEnd(int i10) {
        c cVar = (c) getLayoutParams();
        cVar.f3735b = i10;
        setLayoutParams(cVar);
    }

    public void setGuidelinePercent(float f10) {
        c cVar = (c) getLayoutParams();
        cVar.f3737c = f10;
        setLayoutParams(cVar);
    }

    public void setVisibility(int i10) {
    }
}
