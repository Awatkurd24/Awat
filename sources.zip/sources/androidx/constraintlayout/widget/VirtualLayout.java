package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import c1.p;
import w0.n;

public abstract class VirtualLayout extends ConstraintHelper {

    /* renamed from: i  reason: collision with root package name */
    public boolean f1824i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1825j;

    public VirtualLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }

    public final void h(ConstraintLayout constraintLayout) {
        g(constraintLayout);
    }

    public void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 6) {
                    this.f1824i = true;
                } else if (index == 22) {
                    this.f1825j = true;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f1824i || this.f1825j) {
            ViewParent parent = getParent();
            if (parent instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) parent;
                int visibility = getVisibility();
                float elevation = getElevation();
                for (int i10 = 0; i10 < this.f1790b; i10++) {
                    View h10 = constraintLayout.h(this.f1789a[i10]);
                    if (h10 != null) {
                        if (this.f1824i) {
                            h10.setVisibility(visibility);
                        }
                        if (this.f1825j && elevation > 0.0f) {
                            h10.setTranslationZ(h10.getTranslationZ() + elevation);
                        }
                    }
                }
            }
        }
    }

    public void s(n nVar, int i10, int i11) {
    }

    public void setElevation(float f10) {
        super.setElevation(f10);
        f();
    }

    public void setVisibility(int i10) {
        super.setVisibility(i10);
        f();
    }
}
