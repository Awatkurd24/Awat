package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import c1.g;
import c1.h;
import c1.m;
import c1.p;
import java.util.HashMap;
import w0.a;
import w0.e;
import w0.f;
import w0.k;

public class Barrier extends ConstraintHelper {

    /* renamed from: i  reason: collision with root package name */
    public int f1786i;

    /* renamed from: j  reason: collision with root package name */
    public int f1787j;

    /* renamed from: k  reason: collision with root package name */
    public a f1788k;

    public Barrier(Context context) {
        super(context);
        this.f1789a = new int[32];
        this.f1795g = null;
        this.f1796h = new HashMap();
        this.f1791c = context;
        l((AttributeSet) null);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.f1788k.f28526y0;
    }

    public int getMargin() {
        return this.f1788k.f28527z0;
    }

    public int getType() {
        return this.f1786i;
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
        this.f1788k = new a();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 26) {
                    setType(obtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.f1788k.f28526y0 = obtainStyledAttributes.getBoolean(index, true);
                } else if (index == 27) {
                    this.f1788k.f28527z0 = obtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1792d = this.f1788k;
        r();
    }

    public final void m(g gVar, k kVar, m mVar, SparseArray sparseArray) {
        super.m(gVar, kVar, mVar, sparseArray);
        if (kVar instanceof a) {
            a aVar = (a) kVar;
            boolean z4 = ((f) kVar.V).A0;
            h hVar = gVar.f3802e;
            s(aVar, hVar.f3820g0, z4);
            aVar.f28526y0 = hVar.f3836o0;
            aVar.f28527z0 = hVar.f3822h0;
        }
    }

    public final void n(e eVar, boolean z4) {
        s(eVar, this.f1786i, z4);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x000f, code lost:
        if (r6 == 6) goto L_0x0011;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0019, code lost:
        if (r6 == 6) goto L_0x000c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void s(w0.e r4, int r5, boolean r6) {
        /*
            r3 = this;
            r3.f1787j = r5
            r5 = 0
            r0 = 6
            r1 = 1
            r2 = 5
            if (r6 == 0) goto L_0x0014
            int r6 = r3.f1786i
            if (r6 != r2) goto L_0x000f
        L_0x000c:
            r3.f1787j = r1
            goto L_0x001c
        L_0x000f:
            if (r6 != r0) goto L_0x001c
        L_0x0011:
            r3.f1787j = r5
            goto L_0x001c
        L_0x0014:
            int r6 = r3.f1786i
            if (r6 != r2) goto L_0x0019
            goto L_0x0011
        L_0x0019:
            if (r6 != r0) goto L_0x001c
            goto L_0x000c
        L_0x001c:
            boolean r5 = r4 instanceof w0.a
            if (r5 == 0) goto L_0x0026
            w0.a r4 = (w0.a) r4
            int r5 = r3.f1787j
            r4.f28525x0 = r5
        L_0x0026:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.Barrier.s(w0.e, int, boolean):void");
    }

    public void setAllowsGoneWidget(boolean z4) {
        this.f1788k.f28526y0 = z4;
    }

    public void setDpMargin(int i10) {
        this.f1788k.f28527z0 = (int) ((((float) i10) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i10) {
        this.f1788k.f28527z0 = i10;
    }

    public void setType(int i10) {
        this.f1786i = i10;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        super.setVisibility(8);
    }
}
