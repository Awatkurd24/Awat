package androidx.constraintlayout.widget;

import android.content.Context;
import android.util.AttributeSet;
import c1.c;

public class Group extends ConstraintHelper {
    public Group(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
    }

    public final void h(ConstraintLayout constraintLayout) {
        g(constraintLayout);
    }

    public final void l(AttributeSet attributeSet) {
        super.l(attributeSet);
    }

    public final void o() {
        c cVar = (c) getLayoutParams();
        cVar.f3766q0.Q(0);
        cVar.f3766q0.N(0);
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        f();
    }

    public void setElevation(float f10) {
        super.setElevation(f10);
        f();
    }

    public void setVisibility(int i10) {
        super.setVisibility(i10);
        f();
    }
}
