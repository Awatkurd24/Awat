package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import c1.c;
import c1.g;
import c1.h;
import c1.l;
import c1.m;
import c1.p;
import java.util.HashMap;

public class Constraints extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public l f1815a;

    public Constraints(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        Log.v("Constraints", " ################# init");
        super.setVisibility(8);
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new m();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [c1.m, android.view.ViewGroup$LayoutParams, c1.c] */
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ? cVar = new c(context, attributeSet);
        cVar.f3892r0 = 1.0f;
        cVar.f3893s0 = false;
        cVar.f3894t0 = 0.0f;
        cVar.f3895u0 = 0.0f;
        cVar.f3896v0 = 0.0f;
        cVar.f3897w0 = 0.0f;
        cVar.f3898x0 = 1.0f;
        cVar.f3899y0 = 1.0f;
        cVar.f3900z0 = 0.0f;
        cVar.A0 = 0.0f;
        cVar.B0 = 0.0f;
        cVar.C0 = 0.0f;
        cVar.D0 = 0.0f;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3907g);
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = obtainStyledAttributes.getIndex(i10);
            if (index == 15) {
                cVar.f3892r0 = obtainStyledAttributes.getFloat(index, cVar.f3892r0);
            } else if (index == 28) {
                cVar.f3894t0 = obtainStyledAttributes.getFloat(index, cVar.f3894t0);
                cVar.f3893s0 = true;
            } else if (index == 23) {
                cVar.f3896v0 = obtainStyledAttributes.getFloat(index, cVar.f3896v0);
            } else if (index == 24) {
                cVar.f3897w0 = obtainStyledAttributes.getFloat(index, cVar.f3897w0);
            } else if (index == 22) {
                cVar.f3895u0 = obtainStyledAttributes.getFloat(index, cVar.f3895u0);
            } else if (index == 20) {
                cVar.f3898x0 = obtainStyledAttributes.getFloat(index, cVar.f3898x0);
            } else if (index == 21) {
                cVar.f3899y0 = obtainStyledAttributes.getFloat(index, cVar.f3899y0);
            } else if (index == 16) {
                cVar.f3900z0 = obtainStyledAttributes.getFloat(index, cVar.f3900z0);
            } else if (index == 17) {
                cVar.A0 = obtainStyledAttributes.getFloat(index, cVar.A0);
            } else if (index == 18) {
                cVar.B0 = obtainStyledAttributes.getFloat(index, cVar.B0);
            } else if (index == 19) {
                cVar.C0 = obtainStyledAttributes.getFloat(index, cVar.C0);
            } else if (index == 27) {
                cVar.D0 = obtainStyledAttributes.getFloat(index, cVar.D0);
            }
        }
        obtainStyledAttributes.recycle();
        return cVar;
    }

    public l getConstraintSet() {
        if (this.f1815a == null) {
            this.f1815a = new l();
        }
        l lVar = this.f1815a;
        lVar.getClass();
        int childCount = getChildCount();
        HashMap hashMap = lVar.f3891f;
        hashMap.clear();
        int i10 = 0;
        while (i10 < childCount) {
            View childAt = getChildAt(i10);
            m mVar = (m) childAt.getLayoutParams();
            int id2 = childAt.getId();
            if (!lVar.f3890e || id2 != -1) {
                if (!hashMap.containsKey(Integer.valueOf(id2))) {
                    hashMap.put(Integer.valueOf(id2), new g());
                }
                g gVar = (g) hashMap.get(Integer.valueOf(id2));
                if (gVar != null) {
                    if (childAt instanceof ConstraintHelper) {
                        ConstraintHelper constraintHelper = (ConstraintHelper) childAt;
                        gVar.d(id2, mVar);
                        if (constraintHelper instanceof Barrier) {
                            h hVar = gVar.f3802e;
                            hVar.f3824i0 = 1;
                            Barrier barrier = (Barrier) constraintHelper;
                            hVar.f3820g0 = barrier.getType();
                            hVar.f3826j0 = barrier.getReferencedIds();
                            hVar.f3822h0 = barrier.getMargin();
                        }
                    }
                    gVar.d(id2, mVar);
                }
                i10++;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
        return this.f1815a;
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new c(layoutParams);
    }
}
