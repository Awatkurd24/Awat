package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import c1.c;
import c1.g;
import c1.h;
import c1.m;
import c1.p;
import java.util.Arrays;
import java.util.HashMap;
import w0.e;
import w0.j;
import w0.k;

public abstract class ConstraintHelper extends View {

    /* renamed from: a  reason: collision with root package name */
    public int[] f1789a = new int[32];

    /* renamed from: b  reason: collision with root package name */
    public int f1790b;

    /* renamed from: c  reason: collision with root package name */
    public Context f1791c;

    /* renamed from: d  reason: collision with root package name */
    public k f1792d;

    /* renamed from: e  reason: collision with root package name */
    public String f1793e;

    /* renamed from: f  reason: collision with root package name */
    public String f1794f;

    /* renamed from: g  reason: collision with root package name */
    public View[] f1795g = null;

    /* renamed from: h  reason: collision with root package name */
    public HashMap f1796h = new HashMap();

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1791c = context;
        l(attributeSet);
    }

    public final void c(String str) {
        if (str != null && str.length() != 0 && this.f1791c != null) {
            String trim = str.trim();
            if (getParent() instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) getParent();
            }
            int j3 = j(trim);
            if (j3 != 0) {
                this.f1796h.put(Integer.valueOf(j3), trim);
                d(j3);
                return;
            }
            Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
        }
    }

    public final void d(int i10) {
        if (i10 != getId()) {
            int i11 = this.f1790b + 1;
            int[] iArr = this.f1789a;
            if (i11 > iArr.length) {
                this.f1789a = Arrays.copyOf(iArr, iArr.length * 2);
            }
            int[] iArr2 = this.f1789a;
            int i12 = this.f1790b;
            iArr2[i12] = i10;
            this.f1790b = i12 + 1;
        }
    }

    public final void e(String str) {
        if (str != null && str.length() != 0 && this.f1791c != null) {
            String trim = str.trim();
            ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
            if (constraintLayout == null) {
                Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
                return;
            }
            int childCount = constraintLayout.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = constraintLayout.getChildAt(i10);
                ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
                if ((layoutParams instanceof c) && trim.equals(((c) layoutParams).Y)) {
                    if (childAt.getId() == -1) {
                        Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                    } else {
                        d(childAt.getId());
                    }
                }
            }
        }
    }

    public final void f() {
        ViewParent parent = getParent();
        if (parent != null && (parent instanceof ConstraintLayout)) {
            g((ConstraintLayout) parent);
        }
    }

    public final void g(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i10 = 0; i10 < this.f1790b; i10++) {
            View h10 = constraintLayout.h(this.f1789a[i10]);
            if (h10 != null) {
                h10.setVisibility(visibility);
                if (elevation > 0.0f) {
                    h10.setTranslationZ(h10.getTranslationZ() + elevation);
                }
            }
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1789a, this.f1790b);
    }

    public void h(ConstraintLayout constraintLayout) {
    }

    public final int i(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String str2;
        if (str == null || constraintLayout == null || (resources = this.f1791c.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            if (childAt.getId() != -1) {
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    str2 = null;
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int j(java.lang.String r5) {
        /*
            r4 = this;
            android.view.ViewParent r0 = r4.getParent()
            boolean r0 = r0 instanceof androidx.constraintlayout.widget.ConstraintLayout
            r1 = 0
            if (r0 == 0) goto L_0x0010
            android.view.ViewParent r0 = r4.getParent()
            androidx.constraintlayout.widget.ConstraintLayout r0 = (androidx.constraintlayout.widget.ConstraintLayout) r0
            goto L_0x0011
        L_0x0010:
            r0 = r1
        L_0x0011:
            boolean r2 = r4.isInEditMode()
            if (r2 == 0) goto L_0x003a
            if (r0 == 0) goto L_0x003a
            boolean r2 = r5 instanceof java.lang.String
            if (r2 == 0) goto L_0x002e
            java.util.HashMap r2 = r0.f1810m
            if (r2 == 0) goto L_0x002e
            boolean r2 = r2.containsKey(r5)
            if (r2 == 0) goto L_0x002e
            java.util.HashMap r2 = r0.f1810m
            java.lang.Object r2 = r2.get(r5)
            goto L_0x002f
        L_0x002e:
            r2 = r1
        L_0x002f:
            boolean r3 = r2 instanceof java.lang.Integer
            if (r3 == 0) goto L_0x003a
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            goto L_0x003b
        L_0x003a:
            r2 = 0
        L_0x003b:
            if (r2 != 0) goto L_0x0043
            if (r0 == 0) goto L_0x0043
            int r2 = r4.i(r0, r5)
        L_0x0043:
            if (r2 != 0) goto L_0x0051
            java.lang.Class<c1.o> r0 = c1.o.class
            java.lang.reflect.Field r0 = r0.getField(r5)     // Catch:{ Exception -> 0x0050 }
            int r2 = r0.getInt(r1)     // Catch:{ Exception -> 0x0050 }
            goto L_0x0051
        L_0x0050:
        L_0x0051:
            if (r2 != 0) goto L_0x0063
            android.content.Context r0 = r4.f1791c
            android.content.res.Resources r1 = r0.getResources()
            java.lang.String r2 = "id"
            java.lang.String r0 = r0.getPackageName()
            int r2 = r1.getIdentifier(r5, r2, r0)
        L_0x0063:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintHelper.j(java.lang.String):int");
    }

    public final View[] k(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f1795g;
        if (viewArr == null || viewArr.length != this.f1790b) {
            this.f1795g = new View[this.f1790b];
        }
        for (int i10 = 0; i10 < this.f1790b; i10++) {
            this.f1795g[i10] = constraintLayout.h(this.f1789a[i10]);
        }
        return this.f1795g;
    }

    public void l(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3903c);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = obtainStyledAttributes.getIndex(i10);
                if (index == 35) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1793e = string;
                    setIds(string);
                } else if (index == 36) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1794f = string2;
                    setReferenceTags(string2);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void m(g gVar, k kVar, m mVar, SparseArray sparseArray) {
        h hVar = gVar.f3802e;
        int[] iArr = hVar.f3826j0;
        int i10 = 0;
        if (iArr != null) {
            setReferencedIds(iArr);
        } else {
            String str = hVar.f3828k0;
            if (str != null) {
                if (str.length() > 0) {
                    String[] split = hVar.f3828k0.split(",");
                    getContext();
                    int[] iArr2 = new int[split.length];
                    int i11 = 0;
                    for (String trim : split) {
                        int j3 = j(trim.trim());
                        if (j3 != 0) {
                            iArr2[i11] = j3;
                            i11++;
                        }
                    }
                    if (i11 != split.length) {
                        iArr2 = Arrays.copyOf(iArr2, i11);
                    }
                    hVar.f3826j0 = iArr2;
                } else {
                    hVar.f3826j0 = null;
                }
            }
        }
        kVar.f28641w0 = 0;
        Arrays.fill(kVar.f28640v0, (Object) null);
        if (hVar.f3826j0 != null) {
            while (true) {
                int[] iArr3 = hVar.f3826j0;
                if (i10 < iArr3.length) {
                    e eVar = (e) sparseArray.get(iArr3[i10]);
                    if (eVar != null) {
                        kVar.T(eVar);
                    }
                    i10++;
                } else {
                    return;
                }
            }
        }
    }

    public void n(e eVar, boolean z4) {
    }

    public void o() {
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1793e;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f1794f;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    public final void onDraw(Canvas canvas) {
    }

    public void onMeasure(int i10, int i11) {
        setMeasuredDimension(0, 0);
    }

    public void p(ConstraintLayout constraintLayout) {
    }

    public void q(j jVar, SparseArray sparseArray) {
        k kVar = (k) jVar;
        kVar.f28641w0 = 0;
        Arrays.fill(kVar.f28640v0, (Object) null);
        for (int i10 = 0; i10 < this.f1790b; i10++) {
            kVar.T((e) sparseArray.get(this.f1789a[i10]));
        }
    }

    public final void r() {
        if (this.f1792d != null) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof c) {
                ((c) layoutParams).f3766q0 = this.f1792d;
            }
        }
    }

    public void setIds(String str) {
        this.f1793e = str;
        if (str != null) {
            int i10 = 0;
            this.f1790b = 0;
            while (true) {
                int indexOf = str.indexOf(44, i10);
                if (indexOf == -1) {
                    c(str.substring(i10));
                    return;
                } else {
                    c(str.substring(i10, indexOf));
                    i10 = indexOf + 1;
                }
            }
        }
    }

    public void setReferenceTags(String str) {
        this.f1794f = str;
        if (str != null) {
            int i10 = 0;
            this.f1790b = 0;
            while (true) {
                int indexOf = str.indexOf(44, i10);
                if (indexOf == -1) {
                    e(str.substring(i10));
                    return;
                } else {
                    e(str.substring(i10, indexOf));
                    i10 = indexOf + 1;
                }
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1793e = null;
        this.f1790b = 0;
        for (int d10 : iArr) {
            d(d10);
        }
    }

    public final void setTag(int i10, Object obj) {
        super.setTag(i10, obj);
        if (obj == null && this.f1793e == null) {
            d(i10);
        }
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1791c = context;
        l(attributeSet);
    }
}
