package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.recyclerview.widget.b0;
import c1.p;

public class MockView extends View {

    /* renamed from: a  reason: collision with root package name */
    public final Paint f1736a = new Paint();

    /* renamed from: b  reason: collision with root package name */
    public final Paint f1737b = new Paint();

    /* renamed from: c  reason: collision with root package name */
    public final Paint f1738c = new Paint();

    /* renamed from: d  reason: collision with root package name */
    public final boolean f1739d = true;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f1740e = true;

    /* renamed from: f  reason: collision with root package name */
    public String f1741f = null;

    /* renamed from: g  reason: collision with root package name */
    public final Rect f1742g = new Rect();

    /* renamed from: h  reason: collision with root package name */
    public final int f1743h;

    /* renamed from: i  reason: collision with root package name */
    public final int f1744i;

    /* renamed from: j  reason: collision with root package name */
    public final int f1745j;

    /* renamed from: k  reason: collision with root package name */
    public final int f1746k;

    public MockView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1743h = Color.argb(255, 0, 0, 0);
        this.f1744i = Color.argb(255, b0.DEFAULT_DRAG_ANIMATION_DURATION, b0.DEFAULT_DRAG_ANIMATION_DURATION, b0.DEFAULT_DRAG_ANIMATION_DURATION);
        this.f1745j = Color.argb(255, 50, 50, 50);
        this.f1746k = 4;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3913m);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 1) {
                    this.f1741f = obtainStyledAttributes.getString(index);
                } else if (index == 4) {
                    this.f1739d = obtainStyledAttributes.getBoolean(index, this.f1739d);
                } else if (index == 0) {
                    this.f1743h = obtainStyledAttributes.getColor(index, this.f1743h);
                } else if (index == 2) {
                    this.f1745j = obtainStyledAttributes.getColor(index, this.f1745j);
                } else if (index == 3) {
                    this.f1744i = obtainStyledAttributes.getColor(index, this.f1744i);
                } else if (index == 5) {
                    this.f1740e = obtainStyledAttributes.getBoolean(index, this.f1740e);
                }
            }
            obtainStyledAttributes.recycle();
        }
        if (this.f1741f == null) {
            try {
                this.f1741f = context.getResources().getResourceEntryName(getId());
            } catch (Exception unused) {
            }
        }
        int i12 = this.f1743h;
        Paint paint = this.f1736a;
        paint.setColor(i12);
        paint.setAntiAlias(true);
        int i13 = this.f1744i;
        Paint paint2 = this.f1737b;
        paint2.setColor(i13);
        paint2.setAntiAlias(true);
        this.f1738c.setColor(this.f1745j);
        this.f1746k = Math.round((getResources().getDisplayMetrics().xdpi / 160.0f) * ((float) this.f1746k));
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f1739d) {
            width--;
            height--;
            float f10 = (float) width;
            float f11 = (float) height;
            Paint paint = this.f1736a;
            canvas.drawLine(0.0f, 0.0f, f10, f11, paint);
            Canvas canvas2 = canvas;
            float f12 = f10;
            Paint paint2 = paint;
            canvas2.drawLine(0.0f, f11, f12, 0.0f, paint2);
            canvas2.drawLine(0.0f, 0.0f, f12, 0.0f, paint2);
            float f13 = f10;
            float f14 = f11;
            canvas2.drawLine(f13, 0.0f, f12, f14, paint2);
            float f15 = f11;
            canvas2.drawLine(f13, f15, 0.0f, f14, paint2);
            canvas2.drawLine(0.0f, f15, 0.0f, 0.0f, paint2);
        }
        String str = this.f1741f;
        if (str != null && this.f1740e) {
            Paint paint3 = this.f1737b;
            int length = str.length();
            Rect rect = this.f1742g;
            paint3.getTextBounds(str, 0, length, rect);
            float width2 = ((float) (width - rect.width())) / 2.0f;
            float height2 = (((float) (height - rect.height())) / 2.0f) + ((float) rect.height());
            rect.offset((int) width2, (int) height2);
            int i10 = rect.left;
            int i11 = this.f1746k;
            rect.set(i10 - i11, rect.top - i11, rect.right + i11, rect.bottom + i11);
            canvas.drawRect(rect, this.f1738c);
            canvas.drawText(this.f1741f, width2, height2, paint3);
        }
    }
}
