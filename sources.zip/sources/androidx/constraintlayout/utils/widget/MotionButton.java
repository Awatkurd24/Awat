package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatButton;
import b1.d;
import c1.p;

public class MotionButton extends AppCompatButton {

    /* renamed from: d  reason: collision with root package name */
    public float f1747d = 0.0f;

    /* renamed from: e  reason: collision with root package name */
    public float f1748e = Float.NaN;

    /* renamed from: f  reason: collision with root package name */
    public Path f1749f;

    /* renamed from: g  reason: collision with root package name */
    public d f1750g;

    /* renamed from: h  reason: collision with root package name */
    public RectF f1751h;

    public MotionButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3909i);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 10) {
                    setRound(obtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(obtainStyledAttributes.getFloat(index, 0.0f));
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public float getRound() {
        return this.f1748e;
    }

    public float getRoundPercent() {
        return this.f1747d;
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1748e = f10;
            float f11 = this.f1747d;
            this.f1747d = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z4 = this.f1748e != f10;
        this.f1748e = f10;
        if (f10 != 0.0f) {
            if (this.f1749f == null) {
                this.f1749f = new Path();
            }
            if (this.f1751h == null) {
                this.f1751h = new RectF();
            }
            if (this.f1750g == null) {
                d dVar = new d(this, 1);
                this.f1750g = dVar;
                setOutlineProvider(dVar);
            }
            setClipToOutline(true);
            this.f1751h.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
            this.f1749f.reset();
            Path path = this.f1749f;
            RectF rectF = this.f1751h;
            float f12 = this.f1748e;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z4 = this.f1747d != f10;
        this.f1747d = f10;
        if (f10 != 0.0f) {
            if (this.f1749f == null) {
                this.f1749f = new Path();
            }
            if (this.f1751h == null) {
                this.f1751h = new RectF();
            }
            if (this.f1750g == null) {
                d dVar = new d(this, 0);
                this.f1750g = dVar;
                setOutlineProvider(dVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1747d) / 2.0f;
            this.f1751h.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1749f.reset();
            this.f1749f.addRoundRect(this.f1751h, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }
}
