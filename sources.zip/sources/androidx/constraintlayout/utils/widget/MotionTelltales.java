package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionLayout;
import c1.p;

public class MotionTelltales extends MockView {

    /* renamed from: l  reason: collision with root package name */
    public final Paint f1779l = new Paint();

    /* renamed from: m  reason: collision with root package name */
    public MotionLayout f1780m;

    /* renamed from: n  reason: collision with root package name */
    public final float[] f1781n = new float[2];

    /* renamed from: o  reason: collision with root package name */
    public final Matrix f1782o = new Matrix();

    /* renamed from: p  reason: collision with root package name */
    public final int f1783p;

    /* renamed from: q  reason: collision with root package name */
    public final int f1784q;

    /* renamed from: r  reason: collision with root package name */
    public final float f1785r;

    public MotionTelltales(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1783p = 0;
        this.f1784q = -65281;
        this.f1785r = 0.25f;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p.f3920t);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 0) {
                    this.f1784q = obtainStyledAttributes.getColor(index, this.f1784q);
                } else if (index == 2) {
                    this.f1783p = obtainStyledAttributes.getInt(index, this.f1783p);
                } else if (index == 1) {
                    this.f1785r = obtainStyledAttributes.getFloat(index, this.f1785r);
                }
            }
            obtainStyledAttributes.recycle();
        }
        int i12 = this.f1784q;
        Paint paint = this.f1779l;
        paint.setColor(i12);
        paint.setStrokeWidth(5.0f);
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v14, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r20v1, resolved type: z0.f} */
    /* JADX WARNING: type inference failed for: r8v9, types: [java.lang.Object, v0.p] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onDraw(android.graphics.Canvas r33) {
        /*
            r32 = this;
            r0 = r32
            super.onDraw(r33)
            android.graphics.Matrix r1 = r32.getMatrix()
            android.graphics.Matrix r2 = r0.f1782o
            r1.invert(r2)
            androidx.constraintlayout.motion.widget.MotionLayout r1 = r0.f1780m
            if (r1 != 0) goto L_0x001f
            android.view.ViewParent r1 = r32.getParent()
            boolean r2 = r1 instanceof androidx.constraintlayout.motion.widget.MotionLayout
            if (r2 == 0) goto L_0x001e
            androidx.constraintlayout.motion.widget.MotionLayout r1 = (androidx.constraintlayout.motion.widget.MotionLayout) r1
            r0.f1780m = r1
        L_0x001e:
            return
        L_0x001f:
            int r1 = r32.getWidth()
            int r3 = r32.getHeight()
            r4 = 5
            float[] r5 = new float[r4]
            r5 = {1036831949, 1048576000, 1056964608, 1061158912, 1063675494} // fill-array
            r7 = 0
        L_0x002e:
            if (r7 >= r4) goto L_0x0397
            r14 = r5[r7]
            r15 = 0
        L_0x0033:
            if (r15 >= r4) goto L_0x0387
            r13 = r5[r15]
            androidx.constraintlayout.motion.widget.MotionLayout r8 = r0.f1780m
            float[] r12 = r0.f1781n
            int r11 = r0.f1783p
            float r9 = r8.f1694v
            float r10 = r8.G
            a1.o r4 = r8.f1690t
            if (r4 == 0) goto L_0x0069
            float r4 = r8.I
            float r4 = r4 - r10
            float r4 = java.lang.Math.signum(r4)
            a1.o r9 = r8.f1690t
            float r10 = r8.G
            r16 = 925353388(0x3727c5ac, float:1.0E-5)
            float r10 = r10 + r16
            float r9 = r9.getInterpolation(r10)
            a1.o r10 = r8.f1690t
            float r6 = r8.G
            float r10 = r10.getInterpolation(r6)
            float r9 = r9 - r10
            float r9 = r9 / r16
            float r9 = r9 * r4
            float r4 = r8.E
            float r9 = r9 / r4
        L_0x0069:
            a1.o r4 = r8.f1690t
            boolean r6 = r4 instanceof a1.o
            if (r6 == 0) goto L_0x0073
            float r9 = r4.a()
        L_0x0073:
            r4 = r9
            java.util.HashMap r6 = r8.C
            java.lang.Object r6 = r6.get(r0)
            a1.n r6 = (a1.n) r6
            r8 = r11 & 1
            r16 = 1
            if (r8 != 0) goto L_0x0326
            int r17 = r32.getWidth()
            int r18 = r32.getHeight()
            float[] r8 = r6.f198v
            float r9 = r6.b(r10, r8)
            java.util.HashMap r10 = r6.f201y
            r19 = r5
            java.lang.String r5 = "translationX"
            r20 = 0
            if (r10 != 0) goto L_0x009f
            r21 = r11
            r10 = r20
            goto L_0x00a7
        L_0x009f:
            java.lang.Object r10 = r10.get(r5)
            z0.k r10 = (z0.k) r10
            r21 = r11
        L_0x00a7:
            java.util.HashMap r11 = r6.f201y
            r22 = r7
            java.lang.String r7 = "translationY"
            if (r11 != 0) goto L_0x00b4
            r23 = r15
            r11 = r20
            goto L_0x00bc
        L_0x00b4:
            java.lang.Object r11 = r11.get(r7)
            z0.k r11 = (z0.k) r11
            r23 = r15
        L_0x00bc:
            java.util.HashMap r15 = r6.f201y
            r24 = r3
            java.lang.String r3 = "rotation"
            if (r15 != 0) goto L_0x00c9
            r25 = r1
            r15 = r20
            goto L_0x00d1
        L_0x00c9:
            java.lang.Object r15 = r15.get(r3)
            z0.k r15 = (z0.k) r15
            r25 = r1
        L_0x00d1:
            java.util.HashMap r1 = r6.f201y
            r26 = r2
            java.lang.String r2 = "scaleX"
            if (r1 != 0) goto L_0x00dc
            r1 = r20
            goto L_0x00e2
        L_0x00dc:
            java.lang.Object r1 = r1.get(r2)
            z0.k r1 = (z0.k) r1
        L_0x00e2:
            java.util.HashMap r0 = r6.f201y
            r27 = r4
            java.lang.String r4 = "scaleY"
            if (r0 != 0) goto L_0x00ef
            r28 = r8
            r0 = r20
            goto L_0x00f7
        L_0x00ef:
            java.lang.Object r0 = r0.get(r4)
            z0.k r0 = (z0.k) r0
            r28 = r8
        L_0x00f7:
            java.util.HashMap r8 = r6.f202z
            if (r8 != 0) goto L_0x00fe
            r5 = r20
            goto L_0x0104
        L_0x00fe:
            java.lang.Object r5 = r8.get(r5)
            z0.f r5 = (z0.f) r5
        L_0x0104:
            java.util.HashMap r8 = r6.f202z
            if (r8 != 0) goto L_0x010b
            r7 = r20
            goto L_0x0111
        L_0x010b:
            java.lang.Object r7 = r8.get(r7)
            z0.f r7 = (z0.f) r7
        L_0x0111:
            java.util.HashMap r8 = r6.f202z
            if (r8 != 0) goto L_0x0118
            r3 = r20
            goto L_0x011e
        L_0x0118:
            java.lang.Object r3 = r8.get(r3)
            z0.f r3 = (z0.f) r3
        L_0x011e:
            java.util.HashMap r8 = r6.f202z
            if (r8 != 0) goto L_0x0125
            r2 = r20
            goto L_0x012b
        L_0x0125:
            java.lang.Object r2 = r8.get(r2)
            z0.f r2 = (z0.f) r2
        L_0x012b:
            java.util.HashMap r8 = r6.f202z
            if (r8 != 0) goto L_0x0132
        L_0x012f:
            r4 = r20
            goto L_0x013b
        L_0x0132:
            java.lang.Object r4 = r8.get(r4)
            r20 = r4
            z0.f r20 = (z0.f) r20
            goto L_0x012f
        L_0x013b:
            v0.p r8 = new v0.p
            r8.<init>()
            r20 = r12
            r12 = 0
            r8.f27553e = r12
            r8.f27552d = r12
            r8.f27551c = r12
            r8.f27550b = r12
            r8.f27549a = r12
            if (r15 == 0) goto L_0x0164
            v7.d9 r12 = r15.f30597a
            r30 = r13
            r29 = r14
            double r13 = (double) r9
            double r12 = r12.e(r13)
            float r12 = (float) r12
            r8.f27553e = r12
            float r12 = r15.a(r9)
            r8.f27554f = r12
            goto L_0x0168
        L_0x0164:
            r30 = r13
            r29 = r14
        L_0x0168:
            if (r10 == 0) goto L_0x0174
            v7.d9 r12 = r10.f30597a
            double r13 = (double) r9
            double r12 = r12.e(r13)
            float r12 = (float) r12
            r8.f27551c = r12
        L_0x0174:
            if (r11 == 0) goto L_0x0180
            v7.d9 r12 = r11.f30597a
            double r13 = (double) r9
            double r12 = r12.e(r13)
            float r12 = (float) r12
            r8.f27552d = r12
        L_0x0180:
            if (r1 == 0) goto L_0x018c
            v7.d9 r12 = r1.f30597a
            double r13 = (double) r9
            double r12 = r12.e(r13)
            float r12 = (float) r12
            r8.f27549a = r12
        L_0x018c:
            if (r0 == 0) goto L_0x0198
            v7.d9 r12 = r0.f30597a
            double r13 = (double) r9
            double r12 = r12.e(r13)
            float r12 = (float) r12
            r8.f27550b = r12
        L_0x0198:
            if (r3 == 0) goto L_0x01a0
            float r12 = r3.b(r9)
            r8.f27553e = r12
        L_0x01a0:
            if (r5 == 0) goto L_0x01a8
            float r12 = r5.b(r9)
            r8.f27551c = r12
        L_0x01a8:
            if (r7 == 0) goto L_0x01b0
            float r12 = r7.b(r9)
            r8.f27552d = r12
        L_0x01b0:
            if (r2 == 0) goto L_0x01b8
            float r12 = r2.b(r9)
            r8.f27549a = r12
        L_0x01b8:
            if (r4 == 0) goto L_0x01c0
            float r12 = r4.b(r9)
            r8.f27550b = r12
        L_0x01c0:
            v0.b r12 = r6.f187k
            if (r12 == 0) goto L_0x0205
            double[] r0 = r6.f192p
            int r1 = r0.length
            if (r1 <= 0) goto L_0x01f0
            double r1 = (double) r9
            r12.c(r1, r0)
            v0.b r0 = r6.f187k
            double[] r3 = r6.f193q
            r0.f(r1, r3)
            a1.w r0 = r6.f182f
            int[] r11 = r6.f191o
            double[] r12 = r6.f193q
            double[] r13 = r6.f192p
            r0.getClass()
            r14 = r8
            r8 = r30
            r9 = r29
            r10 = r20
            r0 = r21
            r1 = r20
            r2 = r30
            a1.w.g(r8, r9, r10, r11, r12, r13)
            goto L_0x01f7
        L_0x01f0:
            r14 = r8
            r1 = r20
            r0 = r21
            r2 = r30
        L_0x01f7:
            r8 = r14
            r9 = r2
            r10 = r29
            r11 = r17
            r12 = r18
            r13 = r1
            r8.a(r9, r10, r11, r12, r13)
            goto L_0x0323
        L_0x0205:
            r14 = r8
            r12 = r20
            r13 = r30
            v7.d9[] r8 = r6.f186j
            if (r8 == 0) goto L_0x025f
            r8 = r28
            float r0 = r6.b(r9, r8)
            v7.d9[] r1 = r6.f186j
            r2 = 0
            r1 = r1[r2]
            double r3 = (double) r0
            double[] r0 = r6.f193q
            r1.f(r3, r0)
            v7.d9[] r0 = r6.f186j
            r0 = r0[r2]
            double[] r1 = r6.f192p
            r0.c(r3, r1)
            r0 = r8[r2]
            r1 = 0
        L_0x022b:
            double[] r2 = r6.f193q
            int r3 = r2.length
            if (r1 >= r3) goto L_0x023a
            r3 = r2[r1]
            double r7 = (double) r0
            double r3 = r3 * r7
            r2[r1] = r3
            int r1 = r1 + 1
            goto L_0x022b
        L_0x023a:
            a1.w r0 = r6.f182f
            int[] r11 = r6.f191o
            double[] r1 = r6.f192p
            r0.getClass()
            r0 = r21
            r8 = r13
            r9 = r29
            r10 = r12
            r3 = r12
            r12 = r2
            r2 = r13
            r13 = r1
            a1.w.g(r8, r9, r10, r11, r12, r13)
            r8 = r14
            r9 = r2
            r10 = r29
            r11 = r17
            r12 = r18
            r13 = r3
            r8.a(r9, r10, r11, r12, r13)
            r1 = r3
            goto L_0x0323
        L_0x025f:
            a1.w r8 = r6.f183g
            r20 = r4
            float r4 = r8.f245e
            a1.w r6 = r6.f182f
            r28 = r2
            float r2 = r6.f245e
            float r4 = r4 - r2
            float r2 = r8.f246f
            r30 = r7
            float r7 = r6.f246f
            float r2 = r2 - r7
            float r7 = r8.f247g
            r31 = r5
            float r5 = r6.f247g
            float r7 = r7 - r5
            float r5 = r8.f248h
            float r6 = r6.f248h
            float r5 = r5 - r6
            float r7 = r7 + r4
            float r5 = r5 + r2
            r6 = 1065353216(0x3f800000, float:1.0)
            float r8 = r6 - r13
            float r8 = r8 * r4
            float r7 = r7 * r13
            float r7 = r7 + r8
            r4 = 0
            r12[r4] = r7
            float r6 = r6 - r29
            float r6 = r6 * r2
            float r5 = r5 * r29
            float r5 = r5 + r6
            r12[r16] = r5
            r2 = 0
            r14.f27553e = r2
            r14.f27552d = r2
            r14.f27551c = r2
            r14.f27550b = r2
            r14.f27549a = r2
            if (r15 == 0) goto L_0x02b3
            v7.d9 r2 = r15.f30597a
            double r4 = (double) r9
            double r4 = r2.e(r4)
            float r2 = (float) r4
            r14.f27553e = r2
            float r2 = r15.a(r9)
            r14.f27554f = r2
        L_0x02b3:
            if (r10 == 0) goto L_0x02bf
            v7.d9 r2 = r10.f30597a
            double r4 = (double) r9
            double r4 = r2.e(r4)
            float r2 = (float) r4
            r14.f27551c = r2
        L_0x02bf:
            if (r11 == 0) goto L_0x02cb
            v7.d9 r2 = r11.f30597a
            double r4 = (double) r9
            double r4 = r2.e(r4)
            float r2 = (float) r4
            r14.f27552d = r2
        L_0x02cb:
            if (r1 == 0) goto L_0x02d7
            v7.d9 r1 = r1.f30597a
            double r4 = (double) r9
            double r1 = r1.e(r4)
            float r1 = (float) r1
            r14.f27549a = r1
        L_0x02d7:
            if (r0 == 0) goto L_0x02e3
            v7.d9 r0 = r0.f30597a
            double r1 = (double) r9
            double r0 = r0.e(r1)
            float r0 = (float) r0
            r14.f27550b = r0
        L_0x02e3:
            if (r3 == 0) goto L_0x02eb
            float r0 = r3.b(r9)
            r14.f27553e = r0
        L_0x02eb:
            if (r31 == 0) goto L_0x02f5
            r5 = r31
            float r0 = r5.b(r9)
            r14.f27551c = r0
        L_0x02f5:
            if (r30 == 0) goto L_0x02ff
            r7 = r30
            float r0 = r7.b(r9)
            r14.f27552d = r0
        L_0x02ff:
            if (r28 == 0) goto L_0x0309
            r2 = r28
            float r0 = r2.b(r9)
            r14.f27549a = r0
        L_0x0309:
            if (r20 == 0) goto L_0x0313
            r0 = r20
            float r0 = r0.b(r9)
            r14.f27550b = r0
        L_0x0313:
            r0 = r21
            r8 = r14
            r9 = r13
            r10 = r29
            r11 = r17
            r1 = r12
            r12 = r18
            r2 = r13
            r13 = r1
            r8.a(r9, r10, r11, r12, r13)
        L_0x0323:
            r3 = r29
            goto L_0x033b
        L_0x0326:
            r25 = r1
            r26 = r2
            r24 = r3
            r27 = r4
            r19 = r5
            r22 = r7
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r23 = r15
            r6.d(r10, r2, r3, r1)
        L_0x033b:
            r4 = 2
            if (r0 >= r4) goto L_0x034b
            r0 = 0
            r4 = r1[r0]
            float r4 = r4 * r27
            r1[r0] = r4
            r0 = r1[r16]
            float r0 = r0 * r27
            r1[r16] = r0
        L_0x034b:
            r0 = r32
            float[] r1 = r0.f1781n
            r4 = r26
            r4.mapVectors(r1)
            r5 = r25
            float r6 = (float) r5
            float r8 = r6 * r2
            r2 = r24
            float r6 = (float) r2
            float r9 = r6 * r3
            r6 = 0
            r7 = r1[r6]
            float r10 = r0.f1785r
            float r7 = r7 * r10
            float r11 = r8 - r7
            r7 = r1[r16]
            float r7 = r7 * r10
            float r12 = r9 - r7
            r4.mapVectors(r1)
            android.graphics.Paint r1 = r0.f1779l
            r7 = r33
            r10 = r11
            r11 = r12
            r12 = r1
            r7.drawLine(r8, r9, r10, r11, r12)
            int r15 = r23 + 1
            r14 = r3
            r1 = r5
            r5 = r19
            r7 = r22
            r3 = r2
            r2 = r4
            r4 = 5
            goto L_0x0033
        L_0x0387:
            r4 = r2
            r2 = r3
            r19 = r5
            r22 = r7
            r6 = 0
            r5 = r1
            int r7 = r22 + 1
            r2 = r4
            r5 = r19
            r4 = 5
            goto L_0x002e
        L_0x0397:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.utils.widget.MotionTelltales.onDraw(android.graphics.Canvas):void");
    }

    public final void onLayout(boolean z4, int i10, int i11, int i12, int i13) {
        super.onLayout(z4, i10, i11, i12, i13);
        postInvalidate();
    }

    public void setText(CharSequence charSequence) {
        this.f1741f = charSequence.toString();
        requestLayout();
    }
}
