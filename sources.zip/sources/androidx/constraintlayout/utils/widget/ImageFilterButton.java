package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageButton;
import b1.a;
import b1.c;
import c1.p;
import u7.y;

public class ImageFilterButton extends AppCompatImageButton {

    /* renamed from: d  reason: collision with root package name */
    public final c f1704d = new c();

    /* renamed from: e  reason: collision with root package name */
    public float f1705e = 0.0f;

    /* renamed from: f  reason: collision with root package name */
    public float f1706f = 0.0f;

    /* renamed from: g  reason: collision with root package name */
    public float f1707g = Float.NaN;

    /* renamed from: h  reason: collision with root package name */
    public Path f1708h;

    /* renamed from: i  reason: collision with root package name */
    public a f1709i;

    /* renamed from: j  reason: collision with root package name */
    public RectF f1710j;

    /* renamed from: k  reason: collision with root package name */
    public final Drawable[] f1711k = new Drawable[2];

    /* renamed from: l  reason: collision with root package name */
    public LayerDrawable f1712l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1713m = true;

    /* renamed from: n  reason: collision with root package name */
    public Drawable f1714n = null;

    /* renamed from: o  reason: collision with root package name */
    public Drawable f1715o = null;

    /* renamed from: p  reason: collision with root package name */
    public float f1716p = Float.NaN;

    /* renamed from: q  reason: collision with root package name */
    public float f1717q = Float.NaN;

    /* renamed from: r  reason: collision with root package name */
    public float f1718r = Float.NaN;

    /* renamed from: s  reason: collision with root package name */
    public float f1719s = Float.NaN;

    public ImageFilterButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3909i);
            int indexCount = obtainStyledAttributes.getIndexCount();
            this.f1714n = obtainStyledAttributes.getDrawable(0);
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 4) {
                    this.f1705e = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 13) {
                    setWarmth(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 12) {
                    setSaturation(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 3) {
                    setContrast(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 10) {
                    setRound(obtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 9) {
                    setOverlay(obtainStyledAttributes.getBoolean(index, this.f1713m));
                } else if (index == 5) {
                    setImagePanX(obtainStyledAttributes.getFloat(index, this.f1716p));
                } else if (index == 6) {
                    setImagePanY(obtainStyledAttributes.getFloat(index, this.f1717q));
                } else if (index == 7) {
                    setImageRotate(obtainStyledAttributes.getFloat(index, this.f1719s));
                } else if (index == 8) {
                    setImageZoom(obtainStyledAttributes.getFloat(index, this.f1718r));
                }
            }
            obtainStyledAttributes.recycle();
            Drawable drawable = getDrawable();
            this.f1715o = drawable;
            Drawable drawable2 = this.f1714n;
            Drawable[] drawableArr = this.f1711k;
            if (drawable2 == null || drawable == null) {
                Drawable drawable3 = getDrawable();
                this.f1715o = drawable3;
                if (drawable3 != null) {
                    Drawable mutate = drawable3.mutate();
                    this.f1715o = mutate;
                    drawableArr[0] = mutate;
                    return;
                }
                return;
            }
            Drawable mutate2 = getDrawable().mutate();
            this.f1715o = mutate2;
            drawableArr[0] = mutate2;
            drawableArr[1] = this.f1714n.mutate();
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f1712l = layerDrawable;
            layerDrawable.getDrawable(1).setAlpha((int) (this.f1705e * 255.0f));
            if (!this.f1713m) {
                this.f1712l.getDrawable(0).setAlpha((int) ((1.0f - this.f1705e) * 255.0f));
            }
            super.setImageDrawable(this.f1712l);
        }
    }

    private void setOverlay(boolean z4) {
        this.f1713m = z4;
    }

    public final void a() {
        if (!Float.isNaN(this.f1716p) || !Float.isNaN(this.f1717q) || !Float.isNaN(this.f1718r) || !Float.isNaN(this.f1719s)) {
            float f10 = 0.0f;
            float f11 = Float.isNaN(this.f1716p) ? 0.0f : this.f1716p;
            float f12 = Float.isNaN(this.f1717q) ? 0.0f : this.f1717q;
            float f13 = Float.isNaN(this.f1718r) ? 1.0f : this.f1718r;
            if (!Float.isNaN(this.f1719s)) {
                f10 = this.f1719s;
            }
            Matrix matrix = new Matrix();
            matrix.reset();
            float intrinsicWidth = (float) getDrawable().getIntrinsicWidth();
            float intrinsicHeight = (float) getDrawable().getIntrinsicHeight();
            float width = (float) getWidth();
            float height = (float) getHeight();
            float f14 = f13 * (intrinsicWidth * height < intrinsicHeight * width ? width / intrinsicWidth : height / intrinsicHeight);
            matrix.postScale(f14, f14);
            float f15 = intrinsicWidth * f14;
            float f16 = f14 * intrinsicHeight;
            matrix.postTranslate(((((width - f15) * f11) + width) - f15) * 0.5f, ((((height - f16) * f12) + height) - f16) * 0.5f);
            matrix.postRotate(f10, width / 2.0f, height / 2.0f);
            setImageMatrix(matrix);
            setScaleType(ImageView.ScaleType.MATRIX);
        }
    }

    public final void b() {
        if (!Float.isNaN(this.f1716p) || !Float.isNaN(this.f1717q) || !Float.isNaN(this.f1718r) || !Float.isNaN(this.f1719s)) {
            a();
        } else {
            setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public float getContrast() {
        return this.f1704d.f3494f;
    }

    public float getCrossfade() {
        return this.f1705e;
    }

    public float getImagePanX() {
        return this.f1716p;
    }

    public float getImagePanY() {
        return this.f1717q;
    }

    public float getImageRotate() {
        return this.f1719s;
    }

    public float getImageZoom() {
        return this.f1718r;
    }

    public float getRound() {
        return this.f1707g;
    }

    public float getRoundPercent() {
        return this.f1706f;
    }

    public float getSaturation() {
        return this.f1704d.f3493e;
    }

    public float getWarmth() {
        return this.f1704d.f3495g;
    }

    public final void layout(int i10, int i11, int i12, int i13) {
        super.layout(i10, i11, i12, i13);
        a();
    }

    public void setAltImageResource(int i10) {
        Drawable mutate = y.e(getContext(), i10).mutate();
        this.f1714n = mutate;
        Drawable drawable = this.f1715o;
        Drawable[] drawableArr = this.f1711k;
        drawableArr[0] = drawable;
        drawableArr[1] = mutate;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f1712l = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f1705e);
    }

    public void setBrightness(float f10) {
        c cVar = this.f1704d;
        cVar.f3492d = f10;
        cVar.a(this);
    }

    public void setContrast(float f10) {
        c cVar = this.f1704d;
        cVar.f3494f = f10;
        cVar.a(this);
    }

    public void setCrossfade(float f10) {
        this.f1705e = f10;
        if (this.f1711k != null) {
            if (!this.f1713m) {
                this.f1712l.getDrawable(0).setAlpha((int) ((1.0f - this.f1705e) * 255.0f));
            }
            this.f1712l.getDrawable(1).setAlpha((int) (this.f1705e * 255.0f));
            super.setImageDrawable(this.f1712l);
        }
    }

    public void setImageDrawable(Drawable drawable) {
        if (this.f1714n == null || drawable == null) {
            super.setImageDrawable(drawable);
            return;
        }
        Drawable mutate = drawable.mutate();
        this.f1715o = mutate;
        Drawable[] drawableArr = this.f1711k;
        drawableArr[0] = mutate;
        drawableArr[1] = this.f1714n;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f1712l = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f1705e);
    }

    public void setImagePanX(float f10) {
        this.f1716p = f10;
        b();
    }

    public void setImagePanY(float f10) {
        this.f1717q = f10;
        b();
    }

    public void setImageResource(int i10) {
        if (this.f1714n != null) {
            Drawable mutate = y.e(getContext(), i10).mutate();
            this.f1715o = mutate;
            Drawable[] drawableArr = this.f1711k;
            drawableArr[0] = mutate;
            drawableArr[1] = this.f1714n;
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f1712l = layerDrawable;
            super.setImageDrawable(layerDrawable);
            setCrossfade(this.f1705e);
            return;
        }
        super.setImageResource(i10);
    }

    public void setImageRotate(float f10) {
        this.f1719s = f10;
        b();
    }

    public void setImageZoom(float f10) {
        this.f1718r = f10;
        b();
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1707g = f10;
            float f11 = this.f1706f;
            this.f1706f = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z4 = this.f1707g != f10;
        this.f1707g = f10;
        if (f10 != 0.0f) {
            if (this.f1708h == null) {
                this.f1708h = new Path();
            }
            if (this.f1710j == null) {
                this.f1710j = new RectF();
            }
            if (this.f1709i == null) {
                a aVar = new a(this, 1);
                this.f1709i = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            this.f1710j.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
            this.f1708h.reset();
            Path path = this.f1708h;
            RectF rectF = this.f1710j;
            float f12 = this.f1707g;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z4 = this.f1706f != f10;
        this.f1706f = f10;
        if (f10 != 0.0f) {
            if (this.f1708h == null) {
                this.f1708h = new Path();
            }
            if (this.f1710j == null) {
                this.f1710j = new RectF();
            }
            if (this.f1709i == null) {
                a aVar = new a(this, 0);
                this.f1709i = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1706f) / 2.0f;
            this.f1710j.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1708h.reset();
            this.f1708h.addRoundRect(this.f1710j, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        c cVar = this.f1704d;
        cVar.f3493e = f10;
        cVar.a(this);
    }

    public void setWarmth(float f10) {
        c cVar = this.f1704d;
        cVar.f3495g = f10;
        cVar.a(this);
    }
}
