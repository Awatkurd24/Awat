package androidx.constraintlayout.utils.widget;

import a1.b;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.Log;
import android.view.View;
import b1.e;
import yg.b0;

public class MotionLabel extends View implements b {
    public float A;
    public float B;
    public final Drawable C;
    public Matrix D;
    public final Bitmap E;
    public final BitmapShader F;
    public final Matrix G;
    public float H;
    public float I;
    public float J;
    public float K;
    public final Paint L;
    public final int M;
    public Rect N;
    public Paint O;
    public float W0;
    public float X0;
    public float Y0;
    public float Z0;

    /* renamed from: a  reason: collision with root package name */
    public final TextPaint f1752a;

    /* renamed from: b  reason: collision with root package name */
    public Path f1753b = new Path();

    /* renamed from: c  reason: collision with root package name */
    public int f1754c = 65535;

    /* renamed from: d  reason: collision with root package name */
    public int f1755d = 65535;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1756e;

    /* renamed from: f  reason: collision with root package name */
    public float f1757f;

    /* renamed from: g  reason: collision with root package name */
    public float f1758g;

    /* renamed from: h  reason: collision with root package name */
    public e f1759h;

    /* renamed from: i  reason: collision with root package name */
    public RectF f1760i;

    /* renamed from: j  reason: collision with root package name */
    public float f1761j;

    /* renamed from: k  reason: collision with root package name */
    public float f1762k;

    /* renamed from: l  reason: collision with root package name */
    public final int f1763l;

    /* renamed from: m  reason: collision with root package name */
    public final int f1764m;

    /* renamed from: n  reason: collision with root package name */
    public float f1765n;

    /* renamed from: o  reason: collision with root package name */
    public String f1766o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f1767p;

    /* renamed from: p0  reason: collision with root package name */
    public float f1768p0;

    /* renamed from: q  reason: collision with root package name */
    public final Rect f1769q;

    /* renamed from: r  reason: collision with root package name */
    public int f1770r;

    /* renamed from: s  reason: collision with root package name */
    public int f1771s;

    /* renamed from: t  reason: collision with root package name */
    public int f1772t;

    /* renamed from: u  reason: collision with root package name */
    public int f1773u;

    /* renamed from: v  reason: collision with root package name */
    public final String f1774v;

    /* renamed from: w  reason: collision with root package name */
    public int f1775w;

    /* renamed from: x  reason: collision with root package name */
    public final int f1776x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f1777y;

    /* renamed from: z  reason: collision with root package name */
    public float f1778z;

    /* JADX WARNING: Code restructure failed: missing block: B:104:0x0299, code lost:
        if (r12 != null) goto L_0x029b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MotionLabel(android.content.Context r11, android.util.AttributeSet r12, int r13) {
        /*
            r10 = this;
            r10.<init>(r11, r12, r13)
            android.text.TextPaint r13 = new android.text.TextPaint
            r13.<init>()
            r10.f1752a = r13
            android.graphics.Path r0 = new android.graphics.Path
            r0.<init>()
            r10.f1753b = r0
            r0 = 65535(0xffff, float:9.1834E-41)
            r10.f1754c = r0
            r10.f1755d = r0
            r0 = 0
            r10.f1756e = r0
            r1 = 0
            r10.f1757f = r1
            r2 = 2143289344(0x7fc00000, float:NaN)
            r10.f1758g = r2
            r3 = 1111490560(0x42400000, float:48.0)
            r10.f1761j = r3
            r10.f1762k = r2
            r10.f1765n = r1
            java.lang.String r3 = "Hello World"
            r10.f1766o = r3
            r3 = 1
            r10.f1767p = r3
            android.graphics.Rect r4 = new android.graphics.Rect
            r4.<init>()
            r10.f1769q = r4
            r10.f1770r = r3
            r10.f1771s = r3
            r10.f1772t = r3
            r10.f1773u = r3
            r4 = 8388659(0x800033, float:1.1755015E-38)
            r10.f1775w = r4
            r10.f1776x = r0
            r10.f1777y = r0
            r10.H = r2
            r10.I = r2
            r10.J = r1
            r10.K = r1
            android.graphics.Paint r4 = new android.graphics.Paint
            r4.<init>()
            r10.L = r4
            r10.M = r0
            r10.W0 = r2
            r10.X0 = r2
            r10.Y0 = r2
            r10.Z0 = r2
            android.util.TypedValue r2 = new android.util.TypedValue
            r2.<init>()
            android.content.res.Resources$Theme r11 = r11.getTheme()
            r4 = 2130968870(0x7f040126, float:1.7546406E38)
            r11.resolveAttribute(r4, r2, r3)
            int r11 = r2.data
            r10.f1754c = r11
            r13.setColor(r11)
            r11 = 2
            r2 = 4
            r4 = 3
            if (r12 == 0) goto L_0x01c9
            android.content.Context r5 = r10.getContext()
            int[] r6 = c1.p.f3917q
            android.content.res.TypedArray r12 = r5.obtainStyledAttributes(r12, r6)
            int r5 = r12.getIndexCount()
            r6 = 0
        L_0x008c:
            if (r6 >= r5) goto L_0x01c6
            int r7 = r12.getIndex(r6)
            r8 = 5
            if (r7 != r8) goto L_0x009e
            java.lang.CharSequence r7 = r12.getText(r7)
            r10.setText(r7)
            goto L_0x01c2
        L_0x009e:
            r8 = 7
            if (r7 != r8) goto L_0x00a9
            java.lang.String r7 = r12.getString(r7)
            r10.f1774v = r7
            goto L_0x01c2
        L_0x00a9:
            r8 = 11
            if (r7 != r8) goto L_0x00b9
            float r8 = r10.f1762k
            int r8 = (int) r8
            int r7 = r12.getDimensionPixelSize(r7, r8)
            float r7 = (float) r7
            r10.f1762k = r7
            goto L_0x01c2
        L_0x00b9:
            if (r7 != 0) goto L_0x00c7
            float r8 = r10.f1761j
            int r8 = (int) r8
            int r7 = r12.getDimensionPixelSize(r7, r8)
            float r7 = (float) r7
            r10.f1761j = r7
            goto L_0x01c2
        L_0x00c7:
            if (r7 != r11) goto L_0x00d3
            int r8 = r10.f1763l
            int r7 = r12.getInt(r7, r8)
            r10.f1763l = r7
            goto L_0x01c2
        L_0x00d3:
            if (r7 != r3) goto L_0x00df
            int r8 = r10.f1764m
            int r7 = r12.getInt(r7, r8)
            r10.f1764m = r7
            goto L_0x01c2
        L_0x00df:
            if (r7 != r4) goto L_0x00eb
            int r8 = r10.f1754c
            int r7 = r12.getColor(r7, r8)
            r10.f1754c = r7
            goto L_0x01c2
        L_0x00eb:
            r8 = 9
            if (r7 != r8) goto L_0x00fc
            float r8 = r10.f1758g
            float r7 = r12.getDimension(r7, r8)
            r10.f1758g = r7
            r10.setRound(r7)
            goto L_0x01c2
        L_0x00fc:
            r8 = 10
            if (r7 != r8) goto L_0x010d
            float r8 = r10.f1757f
            float r7 = r12.getFloat(r7, r8)
            r10.f1757f = r7
            r10.setRoundPercent(r7)
            goto L_0x01c2
        L_0x010d:
            if (r7 != r2) goto L_0x0119
            r8 = -1
            int r7 = r12.getInt(r7, r8)
            r10.setGravity(r7)
            goto L_0x01c2
        L_0x0119:
            r8 = 8
            if (r7 != r8) goto L_0x0125
            int r7 = r12.getInt(r7, r0)
            r10.f1776x = r7
            goto L_0x01c2
        L_0x0125:
            r8 = 17
            if (r7 != r8) goto L_0x0135
            int r8 = r10.f1755d
            int r7 = r12.getInt(r7, r8)
            r10.f1755d = r7
        L_0x0131:
            r10.f1756e = r3
            goto L_0x01c2
        L_0x0135:
            r8 = 18
            if (r7 != r8) goto L_0x0142
            float r8 = r10.f1765n
            float r7 = r12.getDimension(r7, r8)
            r10.f1765n = r7
            goto L_0x0131
        L_0x0142:
            r8 = 12
            if (r7 != r8) goto L_0x014d
            android.graphics.drawable.Drawable r7 = r12.getDrawable(r7)
            r10.C = r7
            goto L_0x0131
        L_0x014d:
            r8 = 13
            if (r7 != r8) goto L_0x015b
            float r8 = r10.W0
            float r7 = r12.getFloat(r7, r8)
            r10.W0 = r7
            goto L_0x01c2
        L_0x015b:
            r8 = 14
            if (r7 != r8) goto L_0x0168
            float r8 = r10.X0
            float r7 = r12.getFloat(r7, r8)
            r10.X0 = r7
            goto L_0x01c2
        L_0x0168:
            r8 = 19
            if (r7 != r8) goto L_0x0175
            float r8 = r10.J
            float r7 = r12.getFloat(r7, r8)
            r10.J = r7
            goto L_0x01c2
        L_0x0175:
            r8 = 20
            if (r7 != r8) goto L_0x0182
            float r8 = r10.K
            float r7 = r12.getFloat(r7, r8)
            r10.K = r7
            goto L_0x01c2
        L_0x0182:
            r8 = 15
            if (r7 != r8) goto L_0x018f
            float r8 = r10.Z0
            float r7 = r12.getFloat(r7, r8)
            r10.Z0 = r7
            goto L_0x01c2
        L_0x018f:
            r8 = 16
            if (r7 != r8) goto L_0x019c
            float r8 = r10.Y0
            float r7 = r12.getFloat(r7, r8)
            r10.Y0 = r7
            goto L_0x01c2
        L_0x019c:
            r8 = 23
            if (r7 != r8) goto L_0x01a9
            float r8 = r10.H
            float r7 = r12.getDimension(r7, r8)
            r10.H = r7
            goto L_0x01c2
        L_0x01a9:
            r8 = 24
            if (r7 != r8) goto L_0x01b6
            float r8 = r10.I
            float r7 = r12.getDimension(r7, r8)
            r10.I = r7
            goto L_0x01c2
        L_0x01b6:
            r8 = 22
            if (r7 != r8) goto L_0x01c2
            int r8 = r10.M
            int r7 = r12.getInt(r7, r8)
            r10.M = r7
        L_0x01c2:
            int r6 = r6 + 1
            goto L_0x008c
        L_0x01c6:
            r12.recycle()
        L_0x01c9:
            android.graphics.drawable.Drawable r12 = r10.C
            r5 = 128(0x80, float:1.794E-43)
            if (r12 == 0) goto L_0x0275
            android.graphics.Matrix r12 = new android.graphics.Matrix
            r12.<init>()
            r10.G = r12
            android.graphics.drawable.Drawable r12 = r10.C
            int r12 = r12.getIntrinsicWidth()
            android.graphics.drawable.Drawable r6 = r10.C
            int r6 = r6.getIntrinsicHeight()
            if (r12 > 0) goto L_0x01f8
            int r12 = r10.getWidth()
            if (r12 != 0) goto L_0x01f8
            float r12 = r10.I
            boolean r12 = java.lang.Float.isNaN(r12)
            if (r12 == 0) goto L_0x01f5
            r12 = 128(0x80, float:1.794E-43)
            goto L_0x01f8
        L_0x01f5:
            float r12 = r10.I
            int r12 = (int) r12
        L_0x01f8:
            if (r6 > 0) goto L_0x020e
            int r6 = r10.getHeight()
            if (r6 != 0) goto L_0x020e
            float r6 = r10.H
            boolean r6 = java.lang.Float.isNaN(r6)
            if (r6 == 0) goto L_0x020b
            r6 = 128(0x80, float:1.794E-43)
            goto L_0x020e
        L_0x020b:
            float r6 = r10.H
            int r6 = (int) r6
        L_0x020e:
            int r7 = r10.M
            if (r7 == 0) goto L_0x0216
            int r12 = r12 / 2
            int r6 = r6 / 2
        L_0x0216:
            android.graphics.Bitmap$Config r7 = android.graphics.Bitmap.Config.ARGB_8888
            android.graphics.Bitmap r12 = android.graphics.Bitmap.createBitmap(r12, r6, r7)
            r10.E = r12
            android.graphics.Canvas r12 = new android.graphics.Canvas
            android.graphics.Bitmap r6 = r10.E
            r12.<init>(r6)
            android.graphics.drawable.Drawable r6 = r10.C
            int r7 = r12.getWidth()
            int r8 = r12.getHeight()
            r6.setBounds(r0, r0, r7, r8)
            android.graphics.drawable.Drawable r6 = r10.C
            r6.setFilterBitmap(r3)
            android.graphics.drawable.Drawable r6 = r10.C
            r6.draw(r12)
            int r12 = r10.M
            if (r12 == 0) goto L_0x026a
            android.graphics.Bitmap r12 = r10.E
            java.lang.System.nanoTime()
            int r6 = r12.getWidth()
            int r7 = r12.getHeight()
            int r6 = r6 / r11
            int r7 = r7 / r11
            android.graphics.Bitmap r12 = android.graphics.Bitmap.createScaledBitmap(r12, r6, r7, r3)
            r8 = 0
        L_0x0254:
            if (r8 >= r2) goto L_0x0268
            r9 = 32
            if (r6 < r9) goto L_0x0268
            if (r7 >= r9) goto L_0x025d
            goto L_0x0268
        L_0x025d:
            int r6 = r6 / 2
            int r7 = r7 / 2
            android.graphics.Bitmap r12 = android.graphics.Bitmap.createScaledBitmap(r12, r6, r7, r3)
            int r8 = r8 + 1
            goto L_0x0254
        L_0x0268:
            r10.E = r12
        L_0x026a:
            android.graphics.BitmapShader r12 = new android.graphics.BitmapShader
            android.graphics.Bitmap r2 = r10.E
            android.graphics.Shader$TileMode r6 = android.graphics.Shader.TileMode.REPEAT
            r12.<init>(r2, r6, r6)
            r10.F = r12
        L_0x0275:
            int r12 = r10.getPaddingLeft()
            r10.f1770r = r12
            int r12 = r10.getPaddingRight()
            r10.f1771s = r12
            int r12 = r10.getPaddingTop()
            r10.f1772t = r12
            int r12 = r10.getPaddingBottom()
            r10.f1773u = r12
            java.lang.String r12 = r10.f1774v
            int r2 = r10.f1764m
            int r6 = r10.f1763l
            if (r12 == 0) goto L_0x029f
            android.graphics.Typeface r12 = android.graphics.Typeface.create(r12, r6)
            if (r12 == 0) goto L_0x02a0
        L_0x029b:
            r10.setTypeface(r12)
            goto L_0x02e1
        L_0x029f:
            r12 = 0
        L_0x02a0:
            if (r2 == r3) goto L_0x02ad
            if (r2 == r11) goto L_0x02aa
            if (r2 == r4) goto L_0x02a7
            goto L_0x02af
        L_0x02a7:
            android.graphics.Typeface r12 = android.graphics.Typeface.MONOSPACE
            goto L_0x02af
        L_0x02aa:
            android.graphics.Typeface r12 = android.graphics.Typeface.SERIF
            goto L_0x02af
        L_0x02ad:
            android.graphics.Typeface r12 = android.graphics.Typeface.SANS_SERIF
        L_0x02af:
            if (r6 <= 0) goto L_0x02da
            if (r12 != 0) goto L_0x02b8
            android.graphics.Typeface r12 = android.graphics.Typeface.defaultFromStyle(r6)
            goto L_0x02bc
        L_0x02b8:
            android.graphics.Typeface r12 = android.graphics.Typeface.create(r12, r6)
        L_0x02bc:
            r10.setTypeface(r12)
            if (r12 == 0) goto L_0x02c6
            int r12 = r12.getStyle()
            goto L_0x02c7
        L_0x02c6:
            r12 = 0
        L_0x02c7:
            int r12 = ~r12
            r12 = r12 & r6
            r2 = r12 & 1
            if (r2 == 0) goto L_0x02ce
            r0 = 1
        L_0x02ce:
            r13.setFakeBoldText(r0)
            r11 = r11 & r12
            if (r11 == 0) goto L_0x02d6
            r1 = -1098907648(0xffffffffbe800000, float:-0.25)
        L_0x02d6:
            r13.setTextSkewX(r1)
            goto L_0x02e1
        L_0x02da:
            r13.setFakeBoldText(r0)
            r13.setTextSkewX(r1)
            goto L_0x029b
        L_0x02e1:
            int r11 = r10.f1754c
            r13.setColor(r11)
            float r11 = r10.f1765n
            r13.setStrokeWidth(r11)
            android.graphics.Paint$Style r11 = android.graphics.Paint.Style.FILL_AND_STROKE
            r13.setStyle(r11)
            r13.setFlags(r5)
            float r11 = r10.f1761j
            r10.setTextSize(r11)
            r13.setAntiAlias(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.utils.widget.MotionLabel.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private float getHorizontalOffset() {
        float f10 = Float.isNaN(this.f1762k) ? 1.0f : this.f1761j / this.f1762k;
        TextPaint textPaint = this.f1752a;
        String str = this.f1766o;
        return ((this.J + 1.0f) * ((((Float.isNaN(this.A) ? (float) getMeasuredWidth() : this.A) - ((float) getPaddingLeft())) - ((float) getPaddingRight())) - (textPaint.measureText(str, 0, str.length()) * f10))) / 2.0f;
    }

    private float getVerticalOffset() {
        float f10 = Float.isNaN(this.f1762k) ? 1.0f : this.f1761j / this.f1762k;
        Paint.FontMetrics fontMetrics = this.f1752a.getFontMetrics();
        float measuredHeight = ((Float.isNaN(this.B) ? (float) getMeasuredHeight() : this.B) - ((float) getPaddingTop())) - ((float) getPaddingBottom());
        float f11 = fontMetrics.descent;
        float f12 = fontMetrics.ascent;
        return (((1.0f - this.K) * (measuredHeight - ((f11 - f12) * f10))) / 2.0f) - (f10 * f12);
    }

    public final void a(float f10) {
        if (this.f1756e || f10 != 1.0f) {
            this.f1753b.reset();
            String str = this.f1766o;
            int length = str.length();
            TextPaint textPaint = this.f1752a;
            Rect rect = this.f1769q;
            textPaint.getTextBounds(str, 0, length, rect);
            textPaint.getTextPath(str, 0, length, 0.0f, 0.0f, this.f1753b);
            if (f10 != 1.0f) {
                Log.v("MotionLabel", b0.k() + " scale " + f10);
                Matrix matrix = new Matrix();
                matrix.postScale(f10, f10);
                this.f1753b.transform(matrix);
            }
            rect.right--;
            rect.left++;
            rect.bottom++;
            rect.top--;
            RectF rectF = new RectF();
            rectF.bottom = (float) getHeight();
            rectF.right = (float) getWidth();
            this.f1767p = false;
        }
    }

    public final void b(float f10, float f11, float f12, float f13) {
        float f14;
        int i10 = (int) (f10 + 0.5f);
        this.f1778z = f10 - ((float) i10);
        int i11 = (int) (f12 + 0.5f);
        int i12 = i11 - i10;
        int i13 = (int) (f13 + 0.5f);
        int i14 = (int) (0.5f + f11);
        int i15 = i13 - i14;
        float f15 = f12 - f10;
        this.A = f15;
        float f16 = f13 - f11;
        this.B = f16;
        if (this.G != null) {
            this.A = f15;
            this.B = f16;
            c();
        }
        if (!(getMeasuredHeight() == i15 && getMeasuredWidth() == i12)) {
            measure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), View.MeasureSpec.makeMeasureSpec(i15, 1073741824));
        }
        super.layout(i10, i14, i11, i13);
        if (this.f1777y) {
            Rect rect = this.N;
            TextPaint textPaint = this.f1752a;
            if (rect == null) {
                this.O = new Paint();
                this.N = new Rect();
                this.O.set(textPaint);
                this.f1768p0 = this.O.getTextSize();
            }
            this.A = f15;
            this.B = f16;
            Paint paint = this.O;
            String str = this.f1766o;
            paint.getTextBounds(str, 0, str.length(), this.N);
            int width = this.N.width();
            float height = ((float) this.N.height()) * 1.3f;
            float f17 = (f15 - ((float) this.f1771s)) - ((float) this.f1770r);
            float f18 = (f16 - ((float) this.f1773u)) - ((float) this.f1772t);
            float f19 = (float) width;
            if (f19 * f18 > height * f17) {
                textPaint.setTextSize((this.f1768p0 * f17) / f19);
            } else {
                textPaint.setTextSize((this.f1768p0 * f18) / height);
            }
            if (this.f1756e || !Float.isNaN(this.f1762k)) {
                if (Float.isNaN(this.f1762k)) {
                    f14 = 1.0f;
                } else {
                    f14 = this.f1761j / this.f1762k;
                }
                a(f14);
            }
        }
    }

    public final void c() {
        float f10 = 0.0f;
        float f11 = Float.isNaN(this.W0) ? 0.0f : this.W0;
        float f12 = Float.isNaN(this.X0) ? 0.0f : this.X0;
        float f13 = Float.isNaN(this.Y0) ? 1.0f : this.Y0;
        if (!Float.isNaN(this.Z0)) {
            f10 = this.Z0;
        }
        this.G.reset();
        float width = (float) this.E.getWidth();
        float height = (float) this.E.getHeight();
        float f14 = Float.isNaN(this.I) ? this.A : this.I;
        float f15 = Float.isNaN(this.H) ? this.B : this.H;
        float f16 = f13 * (width * f15 < height * f14 ? f14 / width : f15 / height);
        this.G.postScale(f16, f16);
        float f17 = width * f16;
        float f18 = f14 - f17;
        float f19 = f16 * height;
        float f20 = f15 - f19;
        if (!Float.isNaN(this.H)) {
            f20 = this.H / 2.0f;
        }
        if (!Float.isNaN(this.I)) {
            f18 = this.I / 2.0f;
        }
        this.G.postTranslate((((f11 * f18) + f14) - f17) * 0.5f, (((f12 * f20) + f15) - f19) * 0.5f);
        this.G.postRotate(f10, f14 / 2.0f, f15 / 2.0f);
        this.F.setLocalMatrix(this.G);
    }

    public float getRound() {
        return this.f1758g;
    }

    public float getRoundPercent() {
        return this.f1757f;
    }

    public float getScaleFromTextSize() {
        return this.f1762k;
    }

    public float getTextBackgroundPanX() {
        return this.W0;
    }

    public float getTextBackgroundPanY() {
        return this.X0;
    }

    public float getTextBackgroundRotate() {
        return this.Z0;
    }

    public float getTextBackgroundZoom() {
        return this.Y0;
    }

    public int getTextOutlineColor() {
        return this.f1755d;
    }

    public float getTextPanX() {
        return this.J;
    }

    public float getTextPanY() {
        return this.K;
    }

    public float getTextureHeight() {
        return this.H;
    }

    public float getTextureWidth() {
        return this.I;
    }

    public Typeface getTypeface() {
        return this.f1752a.getTypeface();
    }

    public final void layout(int i10, int i11, int i12, int i13) {
        float f10;
        super.layout(i10, i11, i12, i13);
        boolean isNaN = Float.isNaN(this.f1762k);
        if (isNaN) {
            f10 = 1.0f;
        } else {
            f10 = this.f1761j / this.f1762k;
        }
        this.A = (float) (i12 - i10);
        this.B = (float) (i13 - i11);
        if (this.f1777y) {
            Rect rect = this.N;
            TextPaint textPaint = this.f1752a;
            if (rect == null) {
                this.O = new Paint();
                this.N = new Rect();
                this.O.set(textPaint);
                this.f1768p0 = this.O.getTextSize();
            }
            Paint paint = this.O;
            String str = this.f1766o;
            paint.getTextBounds(str, 0, str.length(), this.N);
            int width = this.N.width();
            int height = (int) (((float) this.N.height()) * 1.3f);
            float f11 = (this.A - ((float) this.f1771s)) - ((float) this.f1770r);
            float f12 = (this.B - ((float) this.f1773u)) - ((float) this.f1772t);
            if (isNaN) {
                float f13 = (float) width;
                float f14 = (float) height;
                if (f13 * f12 > f14 * f11) {
                    textPaint.setTextSize((this.f1768p0 * f11) / f13);
                } else {
                    textPaint.setTextSize((this.f1768p0 * f12) / f14);
                }
            } else {
                float f15 = (float) width;
                float f16 = (float) height;
                if (f15 * f12 > f16 * f11) {
                    f10 = f11 / f15;
                } else {
                    f10 = f12 / f16;
                }
            }
        }
        if (this.f1756e || !isNaN) {
            float f17 = (float) i10;
            float f18 = (float) i11;
            float f19 = (float) i12;
            float f20 = (float) i13;
            if (this.G != null) {
                this.A = f19 - f17;
                this.B = f20 - f18;
                c();
            }
            a(f10);
        }
    }

    public final void onDraw(Canvas canvas) {
        float f10 = Float.isNaN(this.f1762k) ? 1.0f : this.f1761j / this.f1762k;
        super.onDraw(canvas);
        boolean z4 = this.f1756e;
        TextPaint textPaint = this.f1752a;
        if (z4 || f10 != 1.0f) {
            if (this.f1767p) {
                a(f10);
            }
            if (this.D == null) {
                this.D = new Matrix();
            }
            if (this.f1756e) {
                Paint paint = this.L;
                paint.set(textPaint);
                this.D.reset();
                float horizontalOffset = ((float) this.f1770r) + getHorizontalOffset();
                float verticalOffset = ((float) this.f1772t) + getVerticalOffset();
                this.D.postTranslate(horizontalOffset, verticalOffset);
                this.D.preScale(f10, f10);
                this.f1753b.transform(this.D);
                if (this.F != null) {
                    textPaint.setFilterBitmap(true);
                    textPaint.setShader(this.F);
                } else {
                    textPaint.setColor(this.f1754c);
                }
                textPaint.setStyle(Paint.Style.FILL);
                textPaint.setStrokeWidth(this.f1765n);
                canvas.drawPath(this.f1753b, textPaint);
                if (this.F != null) {
                    textPaint.setShader((Shader) null);
                }
                textPaint.setColor(this.f1755d);
                textPaint.setStyle(Paint.Style.STROKE);
                textPaint.setStrokeWidth(this.f1765n);
                canvas.drawPath(this.f1753b, textPaint);
                this.D.reset();
                this.D.postTranslate(-horizontalOffset, -verticalOffset);
                this.f1753b.transform(this.D);
                textPaint.set(paint);
                return;
            }
            float horizontalOffset2 = ((float) this.f1770r) + getHorizontalOffset();
            float verticalOffset2 = ((float) this.f1772t) + getVerticalOffset();
            this.D.reset();
            this.D.preTranslate(horizontalOffset2, verticalOffset2);
            this.f1753b.transform(this.D);
            textPaint.setColor(this.f1754c);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            textPaint.setStrokeWidth(this.f1765n);
            canvas.drawPath(this.f1753b, textPaint);
            this.D.reset();
            this.D.preTranslate(-horizontalOffset2, -verticalOffset2);
            this.f1753b.transform(this.D);
            return;
        }
        canvas.drawText(this.f1766o, this.f1778z + ((float) this.f1770r) + getHorizontalOffset(), ((float) this.f1772t) + getVerticalOffset(), textPaint);
    }

    public final void onMeasure(int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        this.f1777y = false;
        this.f1770r = getPaddingLeft();
        this.f1771s = getPaddingRight();
        this.f1772t = getPaddingTop();
        this.f1773u = getPaddingBottom();
        if (mode != 1073741824 || mode2 != 1073741824) {
            TextPaint textPaint = this.f1752a;
            String str = this.f1766o;
            int length = str.length();
            Rect rect = this.f1769q;
            textPaint.getTextBounds(str, 0, length, rect);
            if (mode != 1073741824) {
                size = (int) (((float) rect.width()) + 0.99999f);
            }
            size += this.f1770r + this.f1771s;
            if (mode2 != 1073741824) {
                int fontMetricsInt = (int) (((float) textPaint.getFontMetricsInt((Paint.FontMetricsInt) null)) + 0.99999f);
                if (mode2 == Integer.MIN_VALUE) {
                    fontMetricsInt = Math.min(size2, fontMetricsInt);
                }
                size2 = this.f1772t + this.f1773u + fontMetricsInt;
            }
        } else if (this.f1776x != 0) {
            this.f1777y = true;
        }
        setMeasuredDimension(size, size2);
    }

    @SuppressLint({"RtlHardcoded"})
    public void setGravity(int i10) {
        if ((i10 & 8388615) == 0) {
            i10 |= 8388611;
        }
        if ((i10 & 112) == 0) {
            i10 |= 48;
        }
        if (i10 != this.f1775w) {
            invalidate();
        }
        this.f1775w = i10;
        int i11 = i10 & 112;
        if (i11 == 48) {
            this.K = -1.0f;
        } else if (i11 != 80) {
            this.K = 0.0f;
        } else {
            this.K = 1.0f;
        }
        int i12 = i10 & 8388615;
        if (i12 != 3) {
            if (i12 != 5) {
                if (i12 != 8388611) {
                    if (i12 != 8388613) {
                        this.J = 0.0f;
                        return;
                    }
                }
            }
            this.J = 1.0f;
            return;
        }
        this.J = -1.0f;
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1758g = f10;
            float f11 = this.f1757f;
            this.f1757f = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z4 = this.f1758g != f10;
        this.f1758g = f10;
        if (f10 != 0.0f) {
            if (this.f1753b == null) {
                this.f1753b = new Path();
            }
            if (this.f1760i == null) {
                this.f1760i = new RectF();
            }
            if (this.f1759h == null) {
                e eVar = new e(this, 1);
                this.f1759h = eVar;
                setOutlineProvider(eVar);
            }
            setClipToOutline(true);
            this.f1760i.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
            this.f1753b.reset();
            Path path = this.f1753b;
            RectF rectF = this.f1760i;
            float f12 = this.f1758g;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z4 = this.f1757f != f10;
        this.f1757f = f10;
        if (f10 != 0.0f) {
            if (this.f1753b == null) {
                this.f1753b = new Path();
            }
            if (this.f1760i == null) {
                this.f1760i = new RectF();
            }
            if (this.f1759h == null) {
                e eVar = new e(this, 0);
                this.f1759h = eVar;
                setOutlineProvider(eVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1757f) / 2.0f;
            this.f1760i.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1753b.reset();
            this.f1753b.addRoundRect(this.f1760i, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setScaleFromTextSize(float f10) {
        this.f1762k = f10;
    }

    public void setText(CharSequence charSequence) {
        this.f1766o = charSequence.toString();
        invalidate();
    }

    public void setTextBackgroundPanX(float f10) {
        this.W0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundPanY(float f10) {
        this.X0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundRotate(float f10) {
        this.Z0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundZoom(float f10) {
        this.Y0 = f10;
        c();
        invalidate();
    }

    public void setTextFillColor(int i10) {
        this.f1754c = i10;
        invalidate();
    }

    public void setTextOutlineColor(int i10) {
        this.f1755d = i10;
        this.f1756e = true;
        invalidate();
    }

    public void setTextOutlineThickness(float f10) {
        this.f1765n = f10;
        this.f1756e = true;
        if (Float.isNaN(f10)) {
            this.f1765n = 1.0f;
            this.f1756e = false;
        }
        invalidate();
    }

    public void setTextPanX(float f10) {
        this.J = f10;
        invalidate();
    }

    public void setTextPanY(float f10) {
        this.K = f10;
        invalidate();
    }

    public void setTextSize(float f10) {
        this.f1761j = f10;
        Log.v("MotionLabel", b0.k() + "  " + f10 + " / " + this.f1762k);
        TextPaint textPaint = this.f1752a;
        if (!Float.isNaN(this.f1762k)) {
            f10 = this.f1762k;
        }
        textPaint.setTextSize(f10);
        a(Float.isNaN(this.f1762k) ? 1.0f : this.f1761j / this.f1762k);
        requestLayout();
        invalidate();
    }

    public void setTextureHeight(float f10) {
        this.H = f10;
        c();
        invalidate();
    }

    public void setTextureWidth(float f10) {
        this.I = f10;
        c();
        invalidate();
    }

    public void setTypeface(Typeface typeface) {
        TextPaint textPaint = this.f1752a;
        if (textPaint.getTypeface() != typeface) {
            textPaint.setTypeface(typeface);
        }
    }
}
