package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import b1.b;
import b1.c;
import c1.p;
import u7.y;

public class ImageFilterView extends AppCompatImageView {

    /* renamed from: d  reason: collision with root package name */
    public final c f1720d = new c();

    /* renamed from: e  reason: collision with root package name */
    public boolean f1721e = true;

    /* renamed from: f  reason: collision with root package name */
    public Drawable f1722f = null;

    /* renamed from: g  reason: collision with root package name */
    public Drawable f1723g = null;

    /* renamed from: h  reason: collision with root package name */
    public float f1724h = 0.0f;

    /* renamed from: i  reason: collision with root package name */
    public float f1725i = 0.0f;

    /* renamed from: j  reason: collision with root package name */
    public float f1726j = Float.NaN;

    /* renamed from: k  reason: collision with root package name */
    public Path f1727k;

    /* renamed from: l  reason: collision with root package name */
    public b f1728l;

    /* renamed from: m  reason: collision with root package name */
    public RectF f1729m;

    /* renamed from: n  reason: collision with root package name */
    public final Drawable[] f1730n = new Drawable[2];

    /* renamed from: o  reason: collision with root package name */
    public LayerDrawable f1731o;

    /* renamed from: p  reason: collision with root package name */
    public float f1732p = Float.NaN;

    /* renamed from: q  reason: collision with root package name */
    public float f1733q = Float.NaN;

    /* renamed from: r  reason: collision with root package name */
    public float f1734r = Float.NaN;

    /* renamed from: s  reason: collision with root package name */
    public float f1735s = Float.NaN;

    public ImageFilterView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p.f3909i);
            int indexCount = obtainStyledAttributes.getIndexCount();
            this.f1722f = obtainStyledAttributes.getDrawable(0);
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = obtainStyledAttributes.getIndex(i11);
                if (index == 4) {
                    this.f1724h = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 13) {
                    setWarmth(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 12) {
                    setSaturation(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 3) {
                    setContrast(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 2) {
                    setBrightness(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 10) {
                    setRound(obtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(obtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 9) {
                    setOverlay(obtainStyledAttributes.getBoolean(index, this.f1721e));
                } else if (index == 5) {
                    setImagePanX(obtainStyledAttributes.getFloat(index, this.f1732p));
                } else if (index == 6) {
                    setImagePanY(obtainStyledAttributes.getFloat(index, this.f1733q));
                } else if (index == 7) {
                    setImageRotate(obtainStyledAttributes.getFloat(index, this.f1735s));
                } else if (index == 8) {
                    setImageZoom(obtainStyledAttributes.getFloat(index, this.f1734r));
                }
            }
            obtainStyledAttributes.recycle();
            Drawable drawable = getDrawable();
            this.f1723g = drawable;
            Drawable drawable2 = this.f1722f;
            Drawable[] drawableArr = this.f1730n;
            if (drawable2 == null || drawable == null) {
                Drawable drawable3 = getDrawable();
                this.f1723g = drawable3;
                if (drawable3 != null) {
                    Drawable mutate = drawable3.mutate();
                    this.f1723g = mutate;
                    drawableArr[0] = mutate;
                    return;
                }
                return;
            }
            Drawable mutate2 = getDrawable().mutate();
            this.f1723g = mutate2;
            drawableArr[0] = mutate2;
            drawableArr[1] = this.f1722f.mutate();
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f1731o = layerDrawable;
            layerDrawable.getDrawable(1).setAlpha((int) (this.f1724h * 255.0f));
            if (!this.f1721e) {
                this.f1731o.getDrawable(0).setAlpha((int) ((1.0f - this.f1724h) * 255.0f));
            }
            super.setImageDrawable(this.f1731o);
        }
    }

    private void setOverlay(boolean z4) {
        this.f1721e = z4;
    }

    public final void b() {
        if (!Float.isNaN(this.f1732p) || !Float.isNaN(this.f1733q) || !Float.isNaN(this.f1734r) || !Float.isNaN(this.f1735s)) {
            float f10 = 0.0f;
            float f11 = Float.isNaN(this.f1732p) ? 0.0f : this.f1732p;
            float f12 = Float.isNaN(this.f1733q) ? 0.0f : this.f1733q;
            float f13 = Float.isNaN(this.f1734r) ? 1.0f : this.f1734r;
            if (!Float.isNaN(this.f1735s)) {
                f10 = this.f1735s;
            }
            Matrix matrix = new Matrix();
            matrix.reset();
            float intrinsicWidth = (float) getDrawable().getIntrinsicWidth();
            float intrinsicHeight = (float) getDrawable().getIntrinsicHeight();
            float width = (float) getWidth();
            float height = (float) getHeight();
            float f14 = f13 * (intrinsicWidth * height < intrinsicHeight * width ? width / intrinsicWidth : height / intrinsicHeight);
            matrix.postScale(f14, f14);
            float f15 = intrinsicWidth * f14;
            float f16 = f14 * intrinsicHeight;
            matrix.postTranslate(((((width - f15) * f11) + width) - f15) * 0.5f, ((((height - f16) * f12) + height) - f16) * 0.5f);
            matrix.postRotate(f10, width / 2.0f, height / 2.0f);
            setImageMatrix(matrix);
            setScaleType(ImageView.ScaleType.MATRIX);
        }
    }

    public final void d() {
        if (!Float.isNaN(this.f1732p) || !Float.isNaN(this.f1733q) || !Float.isNaN(this.f1734r) || !Float.isNaN(this.f1735s)) {
            b();
        } else {
            setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public float getBrightness() {
        return this.f1720d.f3492d;
    }

    public float getContrast() {
        return this.f1720d.f3494f;
    }

    public float getCrossfade() {
        return this.f1724h;
    }

    public float getImagePanX() {
        return this.f1732p;
    }

    public float getImagePanY() {
        return this.f1733q;
    }

    public float getImageRotate() {
        return this.f1735s;
    }

    public float getImageZoom() {
        return this.f1734r;
    }

    public float getRound() {
        return this.f1726j;
    }

    public float getRoundPercent() {
        return this.f1725i;
    }

    public float getSaturation() {
        return this.f1720d.f3493e;
    }

    public float getWarmth() {
        return this.f1720d.f3495g;
    }

    public final void layout(int i10, int i11, int i12, int i13) {
        super.layout(i10, i11, i12, i13);
        b();
    }

    public void setAltImageResource(int i10) {
        Drawable mutate = y.e(getContext(), i10).mutate();
        this.f1722f = mutate;
        Drawable drawable = this.f1723g;
        Drawable[] drawableArr = this.f1730n;
        drawableArr[0] = drawable;
        drawableArr[1] = mutate;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f1731o = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f1724h);
    }

    public void setBrightness(float f10) {
        c cVar = this.f1720d;
        cVar.f3492d = f10;
        cVar.a(this);
    }

    public void setContrast(float f10) {
        c cVar = this.f1720d;
        cVar.f3494f = f10;
        cVar.a(this);
    }

    public void setCrossfade(float f10) {
        this.f1724h = f10;
        if (this.f1730n != null) {
            if (!this.f1721e) {
                this.f1731o.getDrawable(0).setAlpha((int) ((1.0f - this.f1724h) * 255.0f));
            }
            this.f1731o.getDrawable(1).setAlpha((int) (this.f1724h * 255.0f));
            super.setImageDrawable(this.f1731o);
        }
    }

    public void setImageDrawable(Drawable drawable) {
        if (this.f1722f == null || drawable == null) {
            super.setImageDrawable(drawable);
            return;
        }
        Drawable mutate = drawable.mutate();
        this.f1723g = mutate;
        Drawable[] drawableArr = this.f1730n;
        drawableArr[0] = mutate;
        drawableArr[1] = this.f1722f;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f1731o = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f1724h);
    }

    public void setImagePanX(float f10) {
        this.f1732p = f10;
        d();
    }

    public void setImagePanY(float f10) {
        this.f1733q = f10;
        d();
    }

    public void setImageResource(int i10) {
        if (this.f1722f != null) {
            Drawable mutate = y.e(getContext(), i10).mutate();
            this.f1723g = mutate;
            Drawable[] drawableArr = this.f1730n;
            drawableArr[0] = mutate;
            drawableArr[1] = this.f1722f;
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f1731o = layerDrawable;
            super.setImageDrawable(layerDrawable);
            setCrossfade(this.f1724h);
            return;
        }
        super.setImageResource(i10);
    }

    public void setImageRotate(float f10) {
        this.f1735s = f10;
        d();
    }

    public void setImageZoom(float f10) {
        this.f1734r = f10;
        d();
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1726j = f10;
            float f11 = this.f1725i;
            this.f1725i = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z4 = this.f1726j != f10;
        this.f1726j = f10;
        if (f10 != 0.0f) {
            if (this.f1727k == null) {
                this.f1727k = new Path();
            }
            if (this.f1729m == null) {
                this.f1729m = new RectF();
            }
            if (this.f1728l == null) {
                b bVar = new b(this, 1);
                this.f1728l = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            this.f1729m.set(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
            this.f1727k.reset();
            Path path = this.f1727k;
            RectF rectF = this.f1729m;
            float f12 = this.f1726j;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z4 = this.f1725i != f10;
        this.f1725i = f10;
        if (f10 != 0.0f) {
            if (this.f1727k == null) {
                this.f1727k = new Path();
            }
            if (this.f1729m == null) {
                this.f1729m = new RectF();
            }
            if (this.f1728l == null) {
                b bVar = new b(this, 0);
                this.f1728l = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float min = (((float) Math.min(width, height)) * this.f1725i) / 2.0f;
            this.f1729m.set(0.0f, 0.0f, (float) width, (float) height);
            this.f1727k.reset();
            this.f1727k.addRoundRect(this.f1729m, min, min, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z4) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        c cVar = this.f1720d;
        cVar.f3493e = f10;
        cVar.a(this);
    }

    public void setWarmth(float f10) {
        c cVar = this.f1720d;
        cVar.f3495g = f10;
        cVar.a(this);
    }
}
