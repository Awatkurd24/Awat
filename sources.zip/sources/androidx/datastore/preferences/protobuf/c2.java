package androidx.datastore.preferences.protobuf;

public final class c2 extends y0 {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f1912c;

    public /* synthetic */ c2(int i10) {
        this.f1912c = i10;
    }

    public static int n(long j3, byte[] bArr, int i10, int i11) {
        if (i11 == 0) {
            c2 c2Var = e2.f1924a;
            if (i10 > -12) {
                return -1;
            }
            return i10;
        } else if (i11 == 1) {
            return e2.c(i10, b2.f(bArr, j3));
        } else {
            if (i11 == 2) {
                return e2.d(i10, b2.f(bArr, j3), b2.f(bArr, j3 + 1));
            }
            throw new AssertionError();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x010a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String k(byte[] r12, int r13, int r14) {
        /*
            r11 = this;
            r0 = -16
            r1 = -32
            int r2 = r11.f1912c
            java.lang.String r3 = "buffer length=%d, index=%d, size=%d"
            r4 = 0
            r5 = 3
            r6 = 2
            r7 = 1
            switch(r2) {
                case 0: goto L_0x00e7;
                default: goto L_0x000f;
            }
        L_0x000f:
            r2 = r13 | r14
            int r8 = r12.length
            int r8 = r8 - r13
            int r8 = r8 - r14
            r2 = r2 | r8
            if (r2 < 0) goto L_0x00c8
            int r2 = r13 + r14
            char[] r14 = new char[r14]
            r3 = 0
        L_0x001c:
            if (r13 >= r2) goto L_0x0033
            long r5 = (long) r13
            byte r5 = androidx.datastore.preferences.protobuf.b2.f(r12, r5)
            boolean r6 = androidx.datastore.preferences.protobuf.y0.b(r5)
            if (r6 != 0) goto L_0x002a
            goto L_0x0033
        L_0x002a:
            int r13 = r13 + 1
            int r6 = r3 + 1
            char r5 = (char) r5
            r14[r3] = r5
            r3 = r6
            goto L_0x001c
        L_0x0033:
            if (r13 >= r2) goto L_0x00c2
            int r5 = r13 + 1
            long r6 = (long) r13
            byte r6 = androidx.datastore.preferences.protobuf.b2.f(r12, r6)
            boolean r7 = androidx.datastore.preferences.protobuf.y0.b(r6)
            if (r7 == 0) goto L_0x0061
            int r13 = r3 + 1
            char r6 = (char) r6
            r14[r3] = r6
        L_0x0047:
            if (r5 >= r2) goto L_0x005e
            long r6 = (long) r5
            byte r3 = androidx.datastore.preferences.protobuf.b2.f(r12, r6)
            boolean r6 = androidx.datastore.preferences.protobuf.y0.b(r3)
            if (r6 != 0) goto L_0x0055
            goto L_0x005e
        L_0x0055:
            int r5 = r5 + 1
            int r6 = r13 + 1
            char r3 = (char) r3
            r14[r13] = r3
            r13 = r6
            goto L_0x0047
        L_0x005e:
            r3 = r13
            r13 = r5
            goto L_0x0033
        L_0x0061:
            if (r6 >= r1) goto L_0x0078
            if (r5 >= r2) goto L_0x0073
            int r13 = r13 + 2
            long r7 = (long) r5
            byte r5 = androidx.datastore.preferences.protobuf.b2.f(r12, r7)
            int r7 = r3 + 1
            androidx.datastore.preferences.protobuf.y0.c(r6, r5, r14, r3)
            r3 = r7
            goto L_0x0033
        L_0x0073:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x0078:
            if (r6 >= r0) goto L_0x0098
            int r7 = r2 + -1
            if (r5 >= r7) goto L_0x0093
            int r7 = r13 + 2
            long r8 = (long) r5
            byte r5 = androidx.datastore.preferences.protobuf.b2.f(r12, r8)
            int r13 = r13 + 3
            long r7 = (long) r7
            byte r7 = androidx.datastore.preferences.protobuf.b2.f(r12, r7)
            int r8 = r3 + 1
            androidx.datastore.preferences.protobuf.y0.d(r6, r5, r7, r14, r3)
            r3 = r8
            goto L_0x0033
        L_0x0093:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x0098:
            int r7 = r2 + -2
            if (r5 >= r7) goto L_0x00bd
            int r7 = r13 + 2
            long r8 = (long) r5
            byte r8 = androidx.datastore.preferences.protobuf.b2.f(r12, r8)
            int r5 = r13 + 3
            long r9 = (long) r7
            byte r7 = androidx.datastore.preferences.protobuf.b2.f(r12, r9)
            int r13 = r13 + 4
            long r9 = (long) r5
            byte r9 = androidx.datastore.preferences.protobuf.b2.f(r12, r9)
            r5 = r6
            r6 = r8
            r8 = r9
            r9 = r14
            r10 = r3
            androidx.datastore.preferences.protobuf.y0.a(r5, r6, r7, r8, r9, r10)
            int r3 = r3 + 2
            goto L_0x0033
        L_0x00bd:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x00c2:
            java.lang.String r12 = new java.lang.String
            r12.<init>(r14, r4, r3)
            return r12
        L_0x00c8:
            java.lang.ArrayIndexOutOfBoundsException r0 = new java.lang.ArrayIndexOutOfBoundsException
            java.lang.Object[] r1 = new java.lang.Object[r5]
            int r12 = r12.length
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)
            r1[r4] = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r13)
            r1[r7] = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r14)
            r1[r6] = r12
            java.lang.String r12 = java.lang.String.format(r3, r1)
            r0.<init>(r12)
            throw r0
        L_0x00e7:
            r2 = r13 | r14
            int r8 = r12.length
            int r8 = r8 - r13
            int r8 = r8 - r14
            r2 = r2 | r8
            if (r2 < 0) goto L_0x0184
            int r2 = r13 + r14
            char[] r14 = new char[r14]
            r3 = 0
        L_0x00f4:
            if (r13 >= r2) goto L_0x0108
            byte r5 = r12[r13]
            boolean r6 = androidx.datastore.preferences.protobuf.y0.b(r5)
            if (r6 != 0) goto L_0x00ff
            goto L_0x0108
        L_0x00ff:
            int r13 = r13 + 1
            int r6 = r3 + 1
            char r5 = (char) r5
            r14[r3] = r5
            r3 = r6
            goto L_0x00f4
        L_0x0108:
            if (r13 >= r2) goto L_0x017e
            int r5 = r13 + 1
            byte r6 = r12[r13]
            boolean r7 = androidx.datastore.preferences.protobuf.y0.b(r6)
            if (r7 == 0) goto L_0x0130
            int r13 = r3 + 1
            char r6 = (char) r6
            r14[r3] = r6
        L_0x0119:
            if (r5 >= r2) goto L_0x012d
            byte r3 = r12[r5]
            boolean r6 = androidx.datastore.preferences.protobuf.y0.b(r3)
            if (r6 != 0) goto L_0x0124
            goto L_0x012d
        L_0x0124:
            int r5 = r5 + 1
            int r6 = r13 + 1
            char r3 = (char) r3
            r14[r13] = r3
            r13 = r6
            goto L_0x0119
        L_0x012d:
            r3 = r13
            r13 = r5
            goto L_0x0108
        L_0x0130:
            if (r6 >= r1) goto L_0x0144
            if (r5 >= r2) goto L_0x013f
            int r13 = r13 + 2
            byte r5 = r12[r5]
            int r7 = r3 + 1
            androidx.datastore.preferences.protobuf.y0.c(r6, r5, r14, r3)
            r3 = r7
            goto L_0x0108
        L_0x013f:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x0144:
            if (r6 >= r0) goto L_0x015e
            int r7 = r2 + -1
            if (r5 >= r7) goto L_0x0159
            int r7 = r13 + 2
            byte r5 = r12[r5]
            int r13 = r13 + 3
            byte r7 = r12[r7]
            int r8 = r3 + 1
            androidx.datastore.preferences.protobuf.y0.d(r6, r5, r7, r14, r3)
            r3 = r8
            goto L_0x0108
        L_0x0159:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x015e:
            int r7 = r2 + -2
            if (r5 >= r7) goto L_0x0179
            int r7 = r13 + 2
            byte r8 = r12[r5]
            int r5 = r13 + 3
            byte r7 = r12[r7]
            int r13 = r13 + 4
            byte r9 = r12[r5]
            r5 = r6
            r6 = r8
            r8 = r9
            r9 = r14
            r10 = r3
            androidx.datastore.preferences.protobuf.y0.a(r5, r6, r7, r8, r9, r10)
            int r3 = r3 + 2
            goto L_0x0108
        L_0x0179:
            androidx.datastore.preferences.protobuf.g0 r12 = androidx.datastore.preferences.protobuf.g0.a()
            throw r12
        L_0x017e:
            java.lang.String r12 = new java.lang.String
            r12.<init>(r14, r4, r3)
            return r12
        L_0x0184:
            java.lang.ArrayIndexOutOfBoundsException r0 = new java.lang.ArrayIndexOutOfBoundsException
            java.lang.Object[] r1 = new java.lang.Object[r5]
            int r12 = r12.length
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)
            r1[r4] = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r13)
            r1[r7] = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r14)
            r1[r6] = r12
            java.lang.String r12 = java.lang.String.format(r3, r1)
            r0.<init>(r12)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.c2.k(byte[], int, int):java.lang.String");
    }

    /* JADX WARNING: Removed duplicated region for block: B:67:0x018a  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x018e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int l(java.lang.CharSequence r26, byte[] r27, int r28, int r29) {
        /*
            r25 = this;
            r0 = r26
            r1 = r27
            r2 = r28
            r3 = r25
            r4 = r29
            int r5 = r3.f1912c
            r8 = 2048(0x800, float:2.87E-42)
            r9 = 128(0x80, float:1.794E-43)
            java.lang.String r11 = "Failed writing "
            java.lang.String r12 = " at index "
            switch(r5) {
                case 0: goto L_0x016d;
                default: goto L_0x0017;
            }
        L_0x0017:
            long r13 = (long) r2
            r15 = r11
            long r10 = (long) r4
            long r10 = r10 + r13
            int r5 = r26.length()
            if (r5 > r4) goto L_0x014c
            int r7 = r1.length
            int r7 = r7 - r4
            if (r7 < r2) goto L_0x014c
            r2 = 0
        L_0x0026:
            r16 = 1
            if (r2 >= r5) goto L_0x003b
            char r4 = r0.charAt(r2)
            if (r4 >= r9) goto L_0x003b
            long r16 = r13 + r16
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r13, r4)
            int r2 = r2 + 1
            r13 = r16
            goto L_0x0026
        L_0x003b:
            if (r2 != r5) goto L_0x0040
        L_0x003d:
            int r0 = (int) r13
            goto L_0x014b
        L_0x0040:
            if (r2 >= r5) goto L_0x003d
            char r4 = r0.charAt(r2)
            if (r4 >= r9) goto L_0x0058
            int r7 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1))
            if (r7 >= 0) goto L_0x0058
            long r18 = r13 + r16
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r13, r4)
            r22 = r10
            r13 = r18
            goto L_0x00fe
        L_0x0058:
            r18 = 2
            if (r4 >= r8) goto L_0x0079
            long r20 = r10 - r18
            int r7 = (r13 > r20 ? 1 : (r13 == r20 ? 0 : -1))
            if (r7 > 0) goto L_0x0079
            long r6 = r13 + r16
            int r8 = r4 >>> 6
            r8 = r8 | 960(0x3c0, float:1.345E-42)
            byte r8 = (byte) r8
            androidx.datastore.preferences.protobuf.b2.m(r1, r13, r8)
            long r13 = r13 + r18
            r4 = r4 & 63
            r4 = r4 | r9
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r6, r4)
            r22 = r10
            goto L_0x00fe
        L_0x0079:
            r6 = 3
            r8 = 55296(0xd800, float:7.7486E-41)
            if (r4 < r8) goto L_0x0089
            r8 = 57343(0xdfff, float:8.0355E-41)
            if (r8 >= r4) goto L_0x0086
            goto L_0x0089
        L_0x0086:
            r22 = r10
            goto L_0x00b3
        L_0x0089:
            long r22 = r10 - r6
            int r8 = (r13 > r22 ? 1 : (r13 == r22 ? 0 : -1))
            if (r8 > 0) goto L_0x0086
            long r6 = r13 + r16
            int r8 = r4 >>> 12
            r8 = r8 | 480(0x1e0, float:6.73E-43)
            byte r8 = (byte) r8
            androidx.datastore.preferences.protobuf.b2.m(r1, r13, r8)
            r22 = r10
            long r9 = r13 + r18
            int r11 = r4 >>> 6
            r11 = r11 & 63
            r8 = 128(0x80, float:1.794E-43)
            r11 = r11 | r8
            byte r11 = (byte) r11
            androidx.datastore.preferences.protobuf.b2.m(r1, r6, r11)
            r6 = 3
            long r13 = r13 + r6
            r4 = r4 & 63
            r4 = r4 | r8
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r9, r4)
            goto L_0x00fe
        L_0x00b3:
            r6 = 4
            long r10 = r22 - r6
            int r9 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1))
            if (r9 > 0) goto L_0x0114
            int r9 = r2 + 1
            if (r9 == r5) goto L_0x010c
            char r2 = r0.charAt(r9)
            boolean r10 = java.lang.Character.isSurrogatePair(r4, r2)
            if (r10 == 0) goto L_0x0108
            int r2 = java.lang.Character.toCodePoint(r4, r2)
            long r10 = r13 + r16
            int r4 = r2 >>> 18
            r4 = r4 | 240(0xf0, float:3.36E-43)
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r13, r4)
            r24 = r9
            long r8 = r13 + r18
            int r4 = r2 >>> 12
            r4 = r4 & 63
            r6 = 128(0x80, float:1.794E-43)
            r4 = r4 | r6
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r10, r4)
            r10 = 3
            long r10 = r10 + r13
            int r4 = r2 >>> 6
            r4 = r4 & 63
            r4 = r4 | r6
            byte r4 = (byte) r4
            androidx.datastore.preferences.protobuf.b2.m(r1, r8, r4)
            r7 = 4
            long r13 = r13 + r7
            r2 = r2 & 63
            r2 = r2 | r6
            byte r2 = (byte) r2
            androidx.datastore.preferences.protobuf.b2.m(r1, r10, r2)
            r2 = r24
        L_0x00fe:
            int r2 = r2 + 1
            r10 = r22
            r8 = 2048(0x800, float:2.87E-42)
            r9 = 128(0x80, float:1.794E-43)
            goto L_0x0040
        L_0x0108:
            r24 = r9
            r2 = r24
        L_0x010c:
            androidx.datastore.preferences.protobuf.d2 r0 = new androidx.datastore.preferences.protobuf.d2
            int r2 = r2 + -1
            r0.<init>(r2, r5)
            throw r0
        L_0x0114:
            r1 = 55296(0xd800, float:7.7486E-41)
            if (r1 > r4) goto L_0x0132
            r1 = 57343(0xdfff, float:8.0355E-41)
            if (r4 > r1) goto L_0x0132
            int r1 = r2 + 1
            if (r1 == r5) goto L_0x012c
            char r0 = r0.charAt(r1)
            boolean r0 = java.lang.Character.isSurrogatePair(r4, r0)
            if (r0 != 0) goto L_0x0132
        L_0x012c:
            androidx.datastore.preferences.protobuf.d2 r0 = new androidx.datastore.preferences.protobuf.d2
            r0.<init>(r2, r5)
            throw r0
        L_0x0132:
            java.lang.ArrayIndexOutOfBoundsException r0 = new java.lang.ArrayIndexOutOfBoundsException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r6 = r15
            r1.<init>(r6)
            r1.append(r4)
            r1.append(r12)
            r1.append(r13)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x014b:
            return r0
        L_0x014c:
            r6 = r15
            java.lang.ArrayIndexOutOfBoundsException r1 = new java.lang.ArrayIndexOutOfBoundsException
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>(r6)
            int r5 = r5 + -1
            char r0 = r0.charAt(r5)
            r7.append(r0)
            r7.append(r12)
            int r0 = r2 + r4
            r7.append(r0)
            java.lang.String r0 = r7.toString()
            r1.<init>(r0)
            throw r1
        L_0x016d:
            r6 = r11
            int r5 = r26.length()
            int r4 = r4 + r2
            r10 = 0
        L_0x0174:
            if (r10 >= r5) goto L_0x0188
            int r7 = r10 + r2
            if (r7 >= r4) goto L_0x0188
            char r9 = r0.charAt(r10)
            r8 = 128(0x80, float:1.794E-43)
            if (r9 >= r8) goto L_0x0188
            byte r9 = (byte) r9
            r1[r7] = r9
            int r10 = r10 + 1
            goto L_0x0174
        L_0x0188:
            if (r10 != r5) goto L_0x018e
            int r0 = r2 + r5
            goto L_0x027b
        L_0x018e:
            int r2 = r2 + r10
        L_0x018f:
            if (r10 >= r5) goto L_0x027a
            char r7 = r0.charAt(r10)
            r8 = 128(0x80, float:1.794E-43)
            if (r7 >= r8) goto L_0x01a7
            if (r2 >= r4) goto L_0x01a7
            int r9 = r2 + 1
            byte r7 = (byte) r7
            r1[r2] = r7
            r2 = r9
            r8 = 128(0x80, float:1.794E-43)
            r9 = 2048(0x800, float:2.87E-42)
            goto L_0x0233
        L_0x01a7:
            r9 = 2048(0x800, float:2.87E-42)
            if (r7 >= r9) goto L_0x01c5
            int r11 = r4 + -2
            if (r2 > r11) goto L_0x01c5
            int r11 = r2 + 1
            int r13 = r7 >>> 6
            r13 = r13 | 960(0x3c0, float:1.345E-42)
            byte r13 = (byte) r13
            r1[r2] = r13
            int r2 = r2 + 2
            r7 = r7 & 63
            r8 = 128(0x80, float:1.794E-43)
            r7 = r7 | r8
            byte r7 = (byte) r7
            r1[r11] = r7
        L_0x01c2:
            r8 = 128(0x80, float:1.794E-43)
            goto L_0x0233
        L_0x01c5:
            r11 = 55296(0xd800, float:7.7486E-41)
            if (r7 < r11) goto L_0x01cf
            r11 = 57343(0xdfff, float:8.0355E-41)
            if (r11 >= r7) goto L_0x01f1
        L_0x01cf:
            int r11 = r4 + -3
            if (r2 > r11) goto L_0x01f1
            int r11 = r2 + 1
            int r13 = r7 >>> 12
            r13 = r13 | 480(0x1e0, float:6.73E-43)
            byte r13 = (byte) r13
            r1[r2] = r13
            int r13 = r2 + 2
            int r14 = r7 >>> 6
            r14 = r14 & 63
            r8 = 128(0x80, float:1.794E-43)
            r14 = r14 | r8
            byte r14 = (byte) r14
            r1[r11] = r14
            int r2 = r2 + 3
            r7 = r7 & 63
            r7 = r7 | r8
            byte r7 = (byte) r7
            r1[r13] = r7
            goto L_0x01c2
        L_0x01f1:
            int r11 = r4 + -4
            if (r2 > r11) goto L_0x0240
            int r11 = r10 + 1
            int r13 = r26.length()
            if (r11 == r13) goto L_0x0238
            char r10 = r0.charAt(r11)
            boolean r13 = java.lang.Character.isSurrogatePair(r7, r10)
            if (r13 == 0) goto L_0x0237
            int r7 = java.lang.Character.toCodePoint(r7, r10)
            int r10 = r2 + 1
            int r13 = r7 >>> 18
            r13 = r13 | 240(0xf0, float:3.36E-43)
            byte r13 = (byte) r13
            r1[r2] = r13
            int r13 = r2 + 2
            int r14 = r7 >>> 12
            r14 = r14 & 63
            r8 = 128(0x80, float:1.794E-43)
            r14 = r14 | r8
            byte r14 = (byte) r14
            r1[r10] = r14
            int r10 = r2 + 3
            int r14 = r7 >>> 6
            r14 = r14 & 63
            r14 = r14 | r8
            byte r14 = (byte) r14
            r1[r13] = r14
            int r2 = r2 + 4
            r7 = r7 & 63
            r7 = r7 | r8
            byte r7 = (byte) r7
            r1[r10] = r7
            r10 = r11
        L_0x0233:
            int r10 = r10 + 1
            goto L_0x018f
        L_0x0237:
            r10 = r11
        L_0x0238:
            androidx.datastore.preferences.protobuf.d2 r0 = new androidx.datastore.preferences.protobuf.d2
            int r10 = r10 + -1
            r0.<init>(r10, r5)
            throw r0
        L_0x0240:
            r1 = 55296(0xd800, float:7.7486E-41)
            if (r1 > r7) goto L_0x0262
            r1 = 57343(0xdfff, float:8.0355E-41)
            if (r7 > r1) goto L_0x0262
            int r1 = r10 + 1
            int r4 = r26.length()
            if (r1 == r4) goto L_0x025c
            char r0 = r0.charAt(r1)
            boolean r0 = java.lang.Character.isSurrogatePair(r7, r0)
            if (r0 != 0) goto L_0x0262
        L_0x025c:
            androidx.datastore.preferences.protobuf.d2 r0 = new androidx.datastore.preferences.protobuf.d2
            r0.<init>(r10, r5)
            throw r0
        L_0x0262:
            java.lang.ArrayIndexOutOfBoundsException r0 = new java.lang.ArrayIndexOutOfBoundsException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r6)
            r1.append(r7)
            r1.append(r12)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x027a:
            r0 = r2
        L_0x027b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.c2.l(java.lang.CharSequence, byte[], int, int):int");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:143:?, code lost:
        return n(r11, r3, r0, r13);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int m(int r20, int r21, byte[] r22) {
        /*
            r19 = this;
            r0 = r20
            r1 = r21
            r2 = r19
            r3 = r22
            int r4 = r2.f1912c
            r5 = -65
            r6 = -32
            r7 = -96
            r8 = -62
            r9 = -16
            r10 = -19
            switch(r4) {
                case 0: goto L_0x00ed;
                default: goto L_0x0019;
            }
        L_0x0019:
            r4 = r0 | r1
            int r13 = r3.length
            int r13 = r13 - r1
            r4 = r4 | r13
            if (r4 < 0) goto L_0x00c8
            long r11 = (long) r0
            long r0 = (long) r1
            long r0 = r0 - r11
            int r1 = (int) r0
            r0 = 16
            r15 = 1
            if (r1 >= r0) goto L_0x002c
            r0 = 0
            goto L_0x003f
        L_0x002c:
            r13 = r11
            r0 = 0
        L_0x002e:
            if (r0 >= r1) goto L_0x003e
            long r17 = r13 + r15
            byte r13 = androidx.datastore.preferences.protobuf.b2.f(r3, r13)
            if (r13 >= 0) goto L_0x0039
            goto L_0x003f
        L_0x0039:
            int r0 = r0 + 1
            r13 = r17
            goto L_0x002e
        L_0x003e:
            r0 = r1
        L_0x003f:
            int r1 = r1 - r0
            long r13 = (long) r0
            long r11 = r11 + r13
        L_0x0042:
            r0 = 0
        L_0x0043:
            if (r1 <= 0) goto L_0x0052
            long r13 = r11 + r15
            byte r0 = androidx.datastore.preferences.protobuf.b2.f(r3, r11)
            if (r0 < 0) goto L_0x0051
            int r1 = r1 + -1
            r11 = r13
            goto L_0x0043
        L_0x0051:
            r11 = r13
        L_0x0052:
            if (r1 != 0) goto L_0x0057
            r11 = 0
            goto L_0x00c7
        L_0x0057:
            int r13 = r1 + -1
            if (r0 >= r6) goto L_0x0071
            if (r13 != 0) goto L_0x0060
            r11 = r0
            goto L_0x00c7
        L_0x0060:
            int r1 = r1 + -2
            if (r0 < r8) goto L_0x006f
            long r13 = r11 + r15
            byte r0 = androidx.datastore.preferences.protobuf.b2.f(r3, r11)
            if (r0 <= r5) goto L_0x006d
            goto L_0x006f
        L_0x006d:
            r11 = r13
            goto L_0x00c1
        L_0x006f:
            r11 = -1
            goto L_0x00c7
        L_0x0071:
            r17 = 2
            if (r0 >= r9) goto L_0x0098
            r14 = 2
            if (r13 >= r14) goto L_0x007d
        L_0x0078:
            int r11 = n(r11, r3, r0, r13)
            goto L_0x00c7
        L_0x007d:
            int r1 = r1 + -3
            long r13 = r11 + r15
            byte r4 = androidx.datastore.preferences.protobuf.b2.f(r3, r11)
            if (r4 > r5) goto L_0x006f
            if (r0 != r6) goto L_0x008b
            if (r4 < r7) goto L_0x006f
        L_0x008b:
            if (r0 != r10) goto L_0x008f
            if (r4 >= r7) goto L_0x006f
        L_0x008f:
            long r11 = r11 + r17
            byte r0 = androidx.datastore.preferences.protobuf.b2.f(r3, r13)
            if (r0 <= r5) goto L_0x00c1
            goto L_0x006f
        L_0x0098:
            r4 = 3
            if (r13 >= r4) goto L_0x009c
            goto L_0x0078
        L_0x009c:
            int r1 = r1 + -4
            long r13 = r11 + r15
            byte r4 = androidx.datastore.preferences.protobuf.b2.f(r3, r11)
            if (r4 > r5) goto L_0x006f
            int r0 = r0 << 28
            int r4 = r4 + 112
            int r4 = r4 + r0
            int r0 = r4 >> 30
            if (r0 != 0) goto L_0x006f
            long r9 = r11 + r17
            byte r0 = androidx.datastore.preferences.protobuf.b2.f(r3, r13)
            if (r0 > r5) goto L_0x006f
            r13 = 3
            long r11 = r11 + r13
            byte r0 = androidx.datastore.preferences.protobuf.b2.f(r3, r9)
            if (r0 <= r5) goto L_0x00c1
            goto L_0x006f
        L_0x00c1:
            r9 = -16
            r10 = -19
            goto L_0x0042
        L_0x00c7:
            return r11
        L_0x00c8:
            java.lang.ArrayIndexOutOfBoundsException r4 = new java.lang.ArrayIndexOutOfBoundsException
            r5 = 3
            java.lang.Object[] r5 = new java.lang.Object[r5]
            int r3 = r3.length
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r9 = 0
            r5[r9] = r3
            java.lang.Integer r0 = java.lang.Integer.valueOf(r20)
            r3 = 1
            r5[r3] = r0
            java.lang.Integer r0 = java.lang.Integer.valueOf(r21)
            r1 = 2
            r5[r1] = r0
            java.lang.String r0 = "Array length=%d, index=%d, limit=%d"
            java.lang.String r0 = java.lang.String.format(r0, r5)
            r4.<init>(r0)
            throw r4
        L_0x00ed:
            r9 = 0
        L_0x00ee:
            if (r0 >= r1) goto L_0x00f7
            byte r10 = r3[r0]
            if (r10 < 0) goto L_0x00f7
            int r0 = r0 + 1
            goto L_0x00ee
        L_0x00f7:
            if (r0 < r1) goto L_0x00fc
        L_0x00f9:
            r11 = 0
            goto L_0x0161
        L_0x00fc:
            if (r0 < r1) goto L_0x00ff
            goto L_0x00f9
        L_0x00ff:
            int r10 = r0 + 1
            byte r11 = r3[r0]
            if (r11 >= 0) goto L_0x0162
            if (r11 >= r6) goto L_0x011a
            if (r10 < r1) goto L_0x010a
            goto L_0x0161
        L_0x010a:
            if (r11 < r8) goto L_0x0118
            int r0 = r0 + 2
            byte r10 = r3[r10]
            if (r10 <= r5) goto L_0x0113
            goto L_0x0118
        L_0x0113:
            r4 = -16
            r13 = -19
            goto L_0x00fc
        L_0x0118:
            r11 = -1
            goto L_0x0161
        L_0x011a:
            r4 = -16
            if (r11 >= r4) goto L_0x013e
            int r12 = r1 + -1
            if (r10 < r12) goto L_0x0127
        L_0x0122:
            int r11 = androidx.datastore.preferences.protobuf.e2.a(r3, r10, r1)
            goto L_0x0161
        L_0x0127:
            int r12 = r0 + 2
            byte r10 = r3[r10]
            if (r10 > r5) goto L_0x0118
            if (r11 != r6) goto L_0x0131
            if (r10 < r7) goto L_0x0118
        L_0x0131:
            r13 = -19
            if (r11 != r13) goto L_0x0137
            if (r10 >= r7) goto L_0x0118
        L_0x0137:
            int r0 = r0 + 3
            byte r10 = r3[r12]
            if (r10 <= r5) goto L_0x00fc
            goto L_0x0118
        L_0x013e:
            r13 = -19
            int r12 = r1 + -2
            if (r10 < r12) goto L_0x0145
            goto L_0x0122
        L_0x0145:
            int r12 = r0 + 2
            byte r10 = r3[r10]
            if (r10 > r5) goto L_0x0118
            int r11 = r11 << 28
            int r10 = r10 + 112
            int r10 = r10 + r11
            int r10 = r10 >> 30
            if (r10 != 0) goto L_0x0118
            int r10 = r0 + 3
            byte r11 = r3[r12]
            if (r11 > r5) goto L_0x0118
            int r0 = r0 + 4
            byte r10 = r3[r10]
            if (r10 <= r5) goto L_0x00fc
            goto L_0x0118
        L_0x0161:
            return r11
        L_0x0162:
            r4 = -16
            r0 = r10
            goto L_0x00fc
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.c2.m(int, int, byte[]):int");
    }
}
