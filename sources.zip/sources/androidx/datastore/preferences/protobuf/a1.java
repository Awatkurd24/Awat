package androidx.datastore.preferences.protobuf;

import f.c;
import h.z;

public final class a1 implements j1 {

    /* renamed from: a  reason: collision with root package name */
    public final b f1897a;

    /* renamed from: b  reason: collision with root package name */
    public final t1 f1898b;

    /* renamed from: c  reason: collision with root package name */
    public final t f1899c;

    public a1(t1 t1Var, t tVar, b bVar) {
        this.f1898b = t1Var;
        tVar.getClass();
        this.f1899c = tVar;
        this.f1897a = bVar;
    }

    public final void a(Object obj, i1 i1Var, s sVar) {
        this.f1898b.getClass();
        b0 b0Var = (b0) obj;
        if (b0Var.unknownFields == s1.f2028f) {
            b0Var.unknownFields = s1.b();
        }
        this.f1899c.getClass();
        c.w(obj);
        throw null;
    }

    public final void b(Object obj, Object obj2) {
        k1.B(this.f1898b, obj, obj2);
    }

    public final void c(Object obj) {
        this.f1898b.getClass();
        ((b0) obj).unknownFields.f2033e = false;
        this.f1899c.getClass();
        c.w(obj);
        throw null;
    }

    public final void d(Object obj, z zVar) {
        this.f1899c.getClass();
        c.w(obj);
        throw null;
    }

    public final boolean e(Object obj) {
        this.f1899c.getClass();
        c.w(obj);
        throw null;
    }

    public final boolean f(Object obj, Object obj2) {
        t1 t1Var = this.f1898b;
        t1Var.getClass();
        s1 s1Var = ((b0) obj).unknownFields;
        t1Var.getClass();
        if (!s1Var.equals(((b0) obj2).unknownFields)) {
            return false;
        }
        return true;
    }

    public final int g(Object obj) {
        this.f1898b.getClass();
        s1 s1Var = ((b0) obj).unknownFields;
        int i10 = s1Var.f2032d;
        if (i10 != -1) {
            return i10;
        }
        int i11 = 0;
        for (int i12 = 0; i12 < s1Var.f2029a; i12++) {
            int C = p.C(2, s1Var.f2030b[i12] >>> 3);
            i11 += p.l(3, (j) s1Var.f2031c[i12]) + C + (p.B(1) * 2);
        }
        s1Var.f2032d = i11;
        return i11;
    }

    public final Object h() {
        return ((z) ((b0) this.f1897a).d(5)).b();
    }

    public final int i(Object obj) {
        this.f1898b.getClass();
        return ((b0) obj).unknownFields.hashCode();
    }
}
