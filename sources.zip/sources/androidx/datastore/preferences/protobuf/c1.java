package androidx.datastore.preferences.protobuf;

public abstract class c1 {

    /* renamed from: a  reason: collision with root package name */
    public static final b1 f1910a;

    /* renamed from: b  reason: collision with root package name */
    public static final b1 f1911b = new Object();

    /* JADX WARNING: type inference failed for: r0v2, types: [androidx.datastore.preferences.protobuf.b1, java.lang.Object] */
    static {
        b1 b1Var;
        try {
            b1Var = (b1) Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            b1Var = null;
        }
        f1910a = b1Var;
    }
}
