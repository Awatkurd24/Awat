package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.security.AccessController;
import java.util.logging.Logger;
import sun.misc.Unsafe;

public abstract class b2 {

    /* renamed from: a  reason: collision with root package name */
    public static final Logger f1901a = Logger.getLogger(b2.class.getName());

    /* renamed from: b  reason: collision with root package name */
    public static final Unsafe f1902b;

    /* renamed from: c  reason: collision with root package name */
    public static final Class f1903c = d.f1913a;

    /* renamed from: d  reason: collision with root package name */
    public static final a2 f1904d;

    /* renamed from: e  reason: collision with root package name */
    public static final boolean f1905e;

    /* renamed from: f  reason: collision with root package name */
    public static final boolean f1906f;

    /* renamed from: g  reason: collision with root package name */
    public static final long f1907g = ((long) b(byte[].class));

    /* renamed from: h  reason: collision with root package name */
    public static final boolean f1908h;

    /* JADX WARNING: Removed duplicated region for block: B:65:0x025e  */
    static {
        /*
            java.lang.Class<androidx.datastore.preferences.protobuf.b2> r0 = androidx.datastore.preferences.protobuf.b2.class
            java.lang.String r0 = r0.getName()
            java.util.logging.Logger r0 = java.util.logging.Logger.getLogger(r0)
            f1901a = r0
            sun.misc.Unsafe r0 = l()
            f1902b = r0
            java.lang.Class r1 = androidx.datastore.preferences.protobuf.d.f1913a
            f1903c = r1
            java.lang.Class r1 = java.lang.Long.TYPE
            boolean r2 = e(r1)
            java.lang.Class r3 = java.lang.Integer.TYPE
            boolean r4 = e(r3)
            r5 = 0
            r6 = 1
            r7 = 0
            if (r0 != 0) goto L_0x0028
            goto L_0x0043
        L_0x0028:
            boolean r8 = androidx.datastore.preferences.protobuf.d.a()
            if (r8 == 0) goto L_0x003e
            if (r2 == 0) goto L_0x0036
            androidx.datastore.preferences.protobuf.y1 r7 = new androidx.datastore.preferences.protobuf.y1
            r7.<init>(r0, r6)
            goto L_0x0043
        L_0x0036:
            if (r4 == 0) goto L_0x0043
            androidx.datastore.preferences.protobuf.y1 r7 = new androidx.datastore.preferences.protobuf.y1
            r7.<init>(r0, r5)
            goto L_0x0043
        L_0x003e:
            androidx.datastore.preferences.protobuf.z1 r7 = new androidx.datastore.preferences.protobuf.z1
            r7.<init>(r0)
        L_0x0043:
            f1904d = r7
            java.lang.String r2 = "copyMemory"
            java.lang.String r4 = "platform method missing - proto runtime falling back to safer methods: "
            java.lang.String r8 = "putLong"
            java.lang.String r9 = "putInt"
            java.lang.String r10 = "getInt"
            java.lang.String r11 = "putByte"
            java.lang.String r12 = "getByte"
            java.lang.Class<java.lang.reflect.Field> r14 = java.lang.reflect.Field.class
            java.lang.String r15 = "objectFieldOffset"
            java.lang.Class<java.lang.Object> r16 = java.lang.Object.class
            java.lang.String r7 = "getLong"
            if (r0 != 0) goto L_0x005f
            goto L_0x00f2
        L_0x005f:
            java.lang.Class r0 = r0.getClass()     // Catch:{ all -> 0x00dd }
            java.lang.Class[] r13 = new java.lang.Class[r6]     // Catch:{ all -> 0x00dd }
            r13[r5] = r14     // Catch:{ all -> 0x00dd }
            r0.getMethod(r15, r13)     // Catch:{ all -> 0x00dd }
            r13 = 2
            java.lang.Class[] r6 = new java.lang.Class[r13]     // Catch:{ all -> 0x00dd }
            r6[r5] = r16     // Catch:{ all -> 0x00dd }
            r13 = 1
            r6[r13] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r7, r6)     // Catch:{ all -> 0x00dd }
            java.lang.reflect.Field r6 = d()     // Catch:{ all -> 0x00dd }
            if (r6 != 0) goto L_0x007c
            goto L_0x00f2
        L_0x007c:
            boolean r6 = androidx.datastore.preferences.protobuf.d.a()     // Catch:{ all -> 0x00dd }
            if (r6 == 0) goto L_0x0084
        L_0x0082:
            r5 = 1
            goto L_0x00f2
        L_0x0084:
            r6 = 1
            java.lang.Class[] r13 = new java.lang.Class[r6]     // Catch:{ all -> 0x00dd }
            r13[r5] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r12, r13)     // Catch:{ all -> 0x00dd }
            r6 = 2
            java.lang.Class[] r13 = new java.lang.Class[r6]     // Catch:{ all -> 0x00dd }
            r13[r5] = r1     // Catch:{ all -> 0x00dd }
            java.lang.Class r6 = java.lang.Byte.TYPE     // Catch:{ all -> 0x00dd }
            r5 = 1
            r13[r5] = r6     // Catch:{ all -> 0x00dd }
            r0.getMethod(r11, r13)     // Catch:{ all -> 0x00dd }
            java.lang.Class[] r6 = new java.lang.Class[r5]     // Catch:{ all -> 0x00dd }
            r13 = 0
            r6[r13] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r10, r6)     // Catch:{ all -> 0x00dd }
            r6 = 2
            java.lang.Class[] r5 = new java.lang.Class[r6]     // Catch:{ all -> 0x00dd }
            r5[r13] = r1     // Catch:{ all -> 0x00dd }
            r6 = 1
            r5[r6] = r3     // Catch:{ all -> 0x00dd }
            r0.getMethod(r9, r5)     // Catch:{ all -> 0x00dd }
            java.lang.Class[] r3 = new java.lang.Class[r6]     // Catch:{ all -> 0x00dd }
            r3[r13] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r7, r3)     // Catch:{ all -> 0x00dd }
            r3 = 2
            java.lang.Class[] r5 = new java.lang.Class[r3]     // Catch:{ all -> 0x00dd }
            r5[r13] = r1     // Catch:{ all -> 0x00dd }
            r5[r6] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r8, r5)     // Catch:{ all -> 0x00dd }
            r3 = 3
            java.lang.Class[] r5 = new java.lang.Class[r3]     // Catch:{ all -> 0x00dd }
            r5[r13] = r1     // Catch:{ all -> 0x00dd }
            r5[r6] = r1     // Catch:{ all -> 0x00dd }
            r3 = 2
            r5[r3] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r2, r5)     // Catch:{ all -> 0x00dd }
            r5 = 5
            java.lang.Class[] r5 = new java.lang.Class[r5]     // Catch:{ all -> 0x00dd }
            r5[r13] = r16     // Catch:{ all -> 0x00dd }
            r5[r6] = r1     // Catch:{ all -> 0x00dd }
            r5[r3] = r16     // Catch:{ all -> 0x00dd }
            r3 = 3
            r5[r3] = r1     // Catch:{ all -> 0x00dd }
            r3 = 4
            r5[r3] = r1     // Catch:{ all -> 0x00dd }
            r0.getMethod(r2, r5)     // Catch:{ all -> 0x00dd }
            goto L_0x0082
        L_0x00dd:
            r0 = move-exception
            java.util.logging.Level r1 = java.util.logging.Level.WARNING
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r4)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            java.util.logging.Logger r2 = f1901a
            r2.log(r1, r0)
            r5 = 0
        L_0x00f2:
            f1905e = r5
            java.lang.Class<java.lang.Class> r0 = java.lang.Class.class
            sun.misc.Unsafe r1 = f1902b
            if (r1 != 0) goto L_0x0100
            r5 = 0
            r13 = 1
        L_0x00fc:
            r17 = 0
            goto L_0x020d
        L_0x0100:
            java.lang.Class r1 = r1.getClass()     // Catch:{ all -> 0x01f5 }
            r2 = 1
            java.lang.Class[] r3 = new java.lang.Class[r2]     // Catch:{ all -> 0x01f5 }
            r5 = 0
            r3[r5] = r14     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r15, r3)     // Catch:{ all -> 0x01f2 }
            java.lang.String r3 = "arrayBaseOffset"
            java.lang.Class[] r6 = new java.lang.Class[r2]     // Catch:{ all -> 0x01f2 }
            r6[r5] = r0     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r3, r6)     // Catch:{ all -> 0x01f2 }
            java.lang.String r3 = "arrayIndexScale"
            java.lang.Class[] r6 = new java.lang.Class[r2]     // Catch:{ all -> 0x01f2 }
            r6[r5] = r0     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r3, r6)     // Catch:{ all -> 0x01f2 }
            r2 = 2
            java.lang.Class[] r0 = new java.lang.Class[r2]     // Catch:{ all -> 0x01f2 }
            r0[r5] = r16     // Catch:{ all -> 0x01f2 }
            java.lang.Class r2 = java.lang.Long.TYPE     // Catch:{ all -> 0x01f2 }
            r3 = 1
            r0[r3] = r2     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r10, r0)     // Catch:{ all -> 0x01f2 }
            r6 = 3
            java.lang.Class[] r0 = new java.lang.Class[r6]     // Catch:{ all -> 0x01f2 }
            r0[r5] = r16     // Catch:{ all -> 0x01f2 }
            r0[r3] = r2     // Catch:{ all -> 0x01f5 }
            java.lang.Class r3 = java.lang.Integer.TYPE     // Catch:{ all -> 0x01f5 }
            r5 = 2
            r0[r5] = r3     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r9, r0)     // Catch:{ all -> 0x01f5 }
            java.lang.Class[] r0 = new java.lang.Class[r5]     // Catch:{ all -> 0x01f5 }
            r3 = 0
            r0[r3] = r16     // Catch:{ all -> 0x01f5 }
            r5 = 1
            r0[r5] = r2     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r7, r0)     // Catch:{ all -> 0x01f5 }
            r6 = 3
            java.lang.Class[] r0 = new java.lang.Class[r6]     // Catch:{ all -> 0x01f5 }
            r0[r3] = r16     // Catch:{ all -> 0x01f5 }
            r0[r5] = r2     // Catch:{ all -> 0x01f5 }
            r3 = 2
            r0[r3] = r2     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r8, r0)     // Catch:{ all -> 0x01f5 }
            java.lang.String r0 = "getObject"
            java.lang.Class[] r5 = new java.lang.Class[r3]     // Catch:{ all -> 0x01f5 }
            r3 = 0
            r5[r3] = r16     // Catch:{ all -> 0x01f5 }
            r6 = 1
            r5[r6] = r2     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r0, r5)     // Catch:{ all -> 0x01f5 }
            java.lang.String r0 = "putObject"
            r5 = 3
            java.lang.Class[] r7 = new java.lang.Class[r5]     // Catch:{ all -> 0x01f5 }
            r7[r3] = r16     // Catch:{ all -> 0x01f5 }
            r7[r6] = r2     // Catch:{ all -> 0x01f5 }
            r3 = 2
            r7[r3] = r16     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r0, r7)     // Catch:{ all -> 0x01f5 }
            boolean r0 = androidx.datastore.preferences.protobuf.d.a()     // Catch:{ all -> 0x01f5 }
            if (r0 == 0) goto L_0x017b
            r5 = 0
            r13 = 1
        L_0x0177:
            r17 = 1
            goto L_0x020d
        L_0x017b:
            java.lang.Class[] r0 = new java.lang.Class[r3]     // Catch:{ all -> 0x01f5 }
            r3 = 0
            r0[r3] = r16     // Catch:{ all -> 0x01f5 }
            r5 = 1
            r0[r5] = r2     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r12, r0)     // Catch:{ all -> 0x01f5 }
            r6 = 3
            java.lang.Class[] r0 = new java.lang.Class[r6]     // Catch:{ all -> 0x01f5 }
            r0[r3] = r16     // Catch:{ all -> 0x01f5 }
            r0[r5] = r2     // Catch:{ all -> 0x01f5 }
            java.lang.Class r3 = java.lang.Byte.TYPE     // Catch:{ all -> 0x01f5 }
            r5 = 2
            r0[r5] = r3     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r11, r0)     // Catch:{ all -> 0x01f5 }
            java.lang.String r0 = "getBoolean"
            java.lang.Class[] r3 = new java.lang.Class[r5]     // Catch:{ all -> 0x01f5 }
            r5 = 0
            r3[r5] = r16     // Catch:{ all -> 0x01f2 }
            r6 = 1
            r3[r6] = r2     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r0, r3)     // Catch:{ all -> 0x01f2 }
            java.lang.String r0 = "putBoolean"
            r3 = 3
            java.lang.Class[] r7 = new java.lang.Class[r3]     // Catch:{ all -> 0x01f2 }
            r7[r5] = r16     // Catch:{ all -> 0x01f2 }
            r7[r6] = r2     // Catch:{ all -> 0x01f5 }
            java.lang.Class r3 = java.lang.Boolean.TYPE     // Catch:{ all -> 0x01f5 }
            r5 = 2
            r7[r5] = r3     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r0, r7)     // Catch:{ all -> 0x01f5 }
            java.lang.String r0 = "getFloat"
            java.lang.Class[] r3 = new java.lang.Class[r5]     // Catch:{ all -> 0x01f5 }
            r5 = 0
            r3[r5] = r16     // Catch:{ all -> 0x01f2 }
            r6 = 1
            r3[r6] = r2     // Catch:{ all -> 0x01f2 }
            r1.getMethod(r0, r3)     // Catch:{ all -> 0x01f2 }
            java.lang.String r0 = "putFloat"
            r3 = 3
            java.lang.Class[] r7 = new java.lang.Class[r3]     // Catch:{ all -> 0x01f2 }
            r7[r5] = r16     // Catch:{ all -> 0x01f2 }
            r7[r6] = r2     // Catch:{ all -> 0x01f5 }
            java.lang.Class r3 = java.lang.Float.TYPE     // Catch:{ all -> 0x01f5 }
            r5 = 2
            r7[r5] = r3     // Catch:{ all -> 0x01f5 }
            r1.getMethod(r0, r7)     // Catch:{ all -> 0x01f5 }
            java.lang.String r0 = "getDouble"
            java.lang.Class[] r3 = new java.lang.Class[r5]     // Catch:{ all -> 0x01f5 }
            r5 = 0
            r3[r5] = r16     // Catch:{ all -> 0x01f2 }
            r13 = 1
            r3[r13] = r2     // Catch:{ all -> 0x01f0 }
            r1.getMethod(r0, r3)     // Catch:{ all -> 0x01f0 }
            java.lang.String r0 = "putDouble"
            r3 = 3
            java.lang.Class[] r3 = new java.lang.Class[r3]     // Catch:{ all -> 0x01f0 }
            r3[r5] = r16     // Catch:{ all -> 0x01f0 }
            r3[r13] = r2     // Catch:{ all -> 0x01f0 }
            java.lang.Class r2 = java.lang.Double.TYPE     // Catch:{ all -> 0x01f0 }
            r6 = 2
            r3[r6] = r2     // Catch:{ all -> 0x01f0 }
            r1.getMethod(r0, r3)     // Catch:{ all -> 0x01f0 }
            goto L_0x0177
        L_0x01f0:
            r0 = move-exception
            goto L_0x01f8
        L_0x01f2:
            r0 = move-exception
        L_0x01f3:
            r13 = 1
            goto L_0x01f8
        L_0x01f5:
            r0 = move-exception
            r5 = 0
            goto L_0x01f3
        L_0x01f8:
            java.util.logging.Level r1 = java.util.logging.Level.WARNING
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r4)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            java.util.logging.Logger r2 = f1901a
            r2.log(r1, r0)
            goto L_0x00fc
        L_0x020d:
            f1906f = r17
            java.lang.Class<byte[]> r0 = byte[].class
            int r0 = b(r0)
            long r0 = (long) r0
            f1907g = r0
            java.lang.Class<boolean[]> r0 = boolean[].class
            b(r0)
            c(r0)
            java.lang.Class<int[]> r0 = int[].class
            b(r0)
            c(r0)
            java.lang.Class<long[]> r0 = long[].class
            b(r0)
            c(r0)
            java.lang.Class<float[]> r0 = float[].class
            b(r0)
            c(r0)
            java.lang.Class<double[]> r0 = double[].class
            b(r0)
            c(r0)
            java.lang.Class<java.lang.Object[]> r0 = java.lang.Object[].class
            b(r0)
            c(r0)
            java.lang.reflect.Field r0 = d()
            if (r0 == 0) goto L_0x0256
            androidx.datastore.preferences.protobuf.a2 r1 = f1904d
            if (r1 != 0) goto L_0x0253
            goto L_0x0256
        L_0x0253:
            r1.j(r0)
        L_0x0256:
            java.nio.ByteOrder r0 = java.nio.ByteOrder.nativeOrder()
            java.nio.ByteOrder r1 = java.nio.ByteOrder.BIG_ENDIAN
            if (r0 != r1) goto L_0x025f
            r5 = 1
        L_0x025f:
            f1908h = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.b2.<clinit>():void");
    }

    public static Object a(Class cls) {
        try {
            return f1902b.allocateInstance(cls);
        } catch (InstantiationException e10) {
            throw new IllegalStateException(e10);
        }
    }

    public static int b(Class cls) {
        if (f1906f) {
            return f1904d.a(cls);
        }
        return -1;
    }

    public static void c(Class cls) {
        if (f1906f) {
            f1904d.b(cls);
        }
    }

    public static Field d() {
        Field field;
        Field field2;
        Class<Buffer> cls = Buffer.class;
        if (d.a()) {
            try {
                field2 = cls.getDeclaredField("effectiveDirectAddress");
            } catch (Throwable unused) {
                field2 = null;
            }
            if (field2 != null) {
                return field2;
            }
        }
        try {
            field = cls.getDeclaredField("address");
        } catch (Throwable unused2) {
            field = null;
        }
        if (field == null || field.getType() != Long.TYPE) {
            return null;
        }
        return field;
    }

    public static boolean e(Class cls) {
        Class<byte[]> cls2 = byte[].class;
        if (!d.a()) {
            return false;
        }
        try {
            Class cls3 = f1903c;
            Class cls4 = Boolean.TYPE;
            cls3.getMethod("peekLong", new Class[]{cls, cls4});
            cls3.getMethod("pokeLong", new Class[]{cls, Long.TYPE, cls4});
            Class cls5 = Integer.TYPE;
            cls3.getMethod("pokeInt", new Class[]{cls, cls5, cls4});
            cls3.getMethod("peekInt", new Class[]{cls, cls4});
            cls3.getMethod("pokeByte", new Class[]{cls, Byte.TYPE});
            cls3.getMethod("peekByte", new Class[]{cls});
            cls3.getMethod("pokeByteArray", new Class[]{cls, cls2, cls5, cls5});
            cls3.getMethod("peekByteArray", new Class[]{cls, cls2, cls5, cls5});
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static byte f(byte[] bArr, long j3) {
        return f1904d.d(f1907g + j3, bArr);
    }

    public static byte g(long j3, Object obj) {
        return (byte) ((f1904d.g(-4 & j3, obj) >>> ((int) (((~j3) & 3) << 3))) & 255);
    }

    public static byte h(long j3, Object obj) {
        return (byte) ((f1904d.g(-4 & j3, obj) >>> ((int) ((j3 & 3) << 3))) & 255);
    }

    public static int i(long j3, Object obj) {
        return f1904d.g(j3, obj);
    }

    public static long j(long j3, Object obj) {
        return f1904d.h(j3, obj);
    }

    public static Object k(long j3, Object obj) {
        return f1904d.i(j3, obj);
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, java.security.PrivilegedExceptionAction] */
    public static Unsafe l() {
        try {
            return (Unsafe) AccessController.doPrivileged(new Object());
        } catch (Throwable unused) {
            return null;
        }
    }

    public static void m(byte[] bArr, long j3, byte b5) {
        f1904d.l(bArr, f1907g + j3, b5);
    }

    public static void n(Object obj, long j3, byte b5) {
        long j10 = -4 & j3;
        int g10 = f1904d.g(j10, obj);
        int i10 = ((~((int) j3)) & 3) << 3;
        p(j10, obj, ((255 & b5) << i10) | (g10 & (~(255 << i10))));
    }

    public static void o(Object obj, long j3, byte b5) {
        long j10 = -4 & j3;
        int i10 = (((int) j3) & 3) << 3;
        p(j10, obj, ((255 & b5) << i10) | (f1904d.g(j10, obj) & (~(255 << i10))));
    }

    public static void p(long j3, Object obj, int i10) {
        f1904d.o(j3, obj, i10);
    }

    public static void q(Object obj, long j3, long j10) {
        f1904d.p(obj, j3, j10);
    }

    public static void r(long j3, Object obj, Object obj2) {
        f1904d.q(j3, obj, obj2);
    }
}
