package androidx.datastore.preferences.protobuf;

public final class b1 {
}
