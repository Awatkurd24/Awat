package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

public abstract class a2 {

    /* renamed from: a  reason: collision with root package name */
    public final Unsafe f1900a;

    public a2(Unsafe unsafe) {
        this.f1900a = unsafe;
    }

    public final int a(Class cls) {
        return this.f1900a.arrayBaseOffset(cls);
    }

    public final int b(Class cls) {
        return this.f1900a.arrayIndexScale(cls);
    }

    public abstract boolean c(long j3, Object obj);

    public abstract byte d(long j3, Object obj);

    public abstract double e(long j3, Object obj);

    public abstract float f(long j3, Object obj);

    public final int g(long j3, Object obj) {
        return this.f1900a.getInt(obj, j3);
    }

    public final long h(long j3, Object obj) {
        return this.f1900a.getLong(obj, j3);
    }

    public final Object i(long j3, Object obj) {
        return this.f1900a.getObject(obj, j3);
    }

    public final long j(Field field) {
        return this.f1900a.objectFieldOffset(field);
    }

    public abstract void k(Object obj, long j3, boolean z4);

    public abstract void l(Object obj, long j3, byte b5);

    public abstract void m(Object obj, long j3, double d10);

    public abstract void n(Object obj, long j3, float f10);

    public final void o(long j3, Object obj, int i10) {
        this.f1900a.putInt(obj, j3, i10);
    }

    public final void p(Object obj, long j3, long j10) {
        this.f1900a.putLong(obj, j3, j10);
    }

    public final void q(long j3, Object obj, Object obj2) {
        this.f1900a.putObject(obj, j3, obj2);
    }
}
