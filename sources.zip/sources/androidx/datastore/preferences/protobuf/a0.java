package androidx.datastore.preferences.protobuf;

public final class a0 implements d1 {
    static {
        s.a();
    }
}
