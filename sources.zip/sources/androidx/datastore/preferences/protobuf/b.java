package androidx.datastore.preferences.protobuf;

public abstract class b {
    protected int memoizedHashCode;

    public abstract int a();

    public final int b(j1 j1Var) {
        b0 b0Var = (b0) this;
        int i10 = b0Var.memoizedSerializedSize;
        if (i10 != -1) {
            return i10;
        }
        int g10 = j1Var.g(this);
        b0Var.memoizedSerializedSize = g10;
        return g10;
    }

    public abstract void c(p pVar);
}
