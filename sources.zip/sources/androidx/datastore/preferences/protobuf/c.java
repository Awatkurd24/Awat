package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public abstract class c extends AbstractList implements d0 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1909a = true;

    public boolean add(Object obj) {
        d();
        return super.add(obj);
    }

    public boolean addAll(int i10, Collection collection) {
        d();
        return super.addAll(i10, collection);
    }

    public void clear() {
        d();
        super.clear();
    }

    public final void d() {
        if (!this.f1909a) {
            throw new UnsupportedOperationException();
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        if (!(obj instanceof RandomAccess)) {
            return super.equals(obj);
        }
        List list = (List) obj;
        int size = size();
        if (size != list.size()) {
            return false;
        }
        for (int i10 = 0; i10 < size; i10++) {
            if (!get(i10).equals(list.get(i10))) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int size = size();
        int i10 = 1;
        for (int i11 = 0; i11 < size; i11++) {
            i10 = (i10 * 31) + get(i11).hashCode();
        }
        return i10;
    }

    public final boolean remove(Object obj) {
        d();
        return super.remove(obj);
    }

    public final boolean removeAll(Collection collection) {
        d();
        return super.removeAll(collection);
    }

    public final boolean retainAll(Collection collection) {
        d();
        return super.retainAll(collection);
    }

    public boolean addAll(Collection collection) {
        d();
        return super.addAll(collection);
    }
}
