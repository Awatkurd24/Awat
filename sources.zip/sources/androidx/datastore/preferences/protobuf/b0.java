package androidx.datastore.preferences.protobuf;

import h.z;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class b0 extends b {
    private static Map<Object, b0> defaultInstanceMap = new ConcurrentHashMap();
    protected int memoizedSerializedSize = -1;
    protected s1 unknownFields = s1.f2028f;

    public b0() {
        this.memoizedHashCode = 0;
    }

    public static b0 e(Class cls) {
        b0 b0Var = defaultInstanceMap.get(cls);
        if (b0Var == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                b0Var = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e10) {
                throw new IllegalStateException("Class initialization cannot fail.", e10);
            }
        }
        if (b0Var == null) {
            b0Var = (b0) ((b0) b2.a(cls)).d(6);
            if (b0Var != null) {
                defaultInstanceMap.put(cls, b0Var);
            } else {
                throw new IllegalStateException();
            }
        }
        return b0Var;
    }

    public static Object f(Object obj, Method method, Object... objArr) {
        try {
            return method.invoke(obj, objArr);
        } catch (IllegalAccessException e10) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e10);
        } catch (InvocationTargetException e11) {
            Throwable cause = e11.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else if (cause instanceof Error) {
                throw ((Error) cause);
            } else {
                throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
            }
        }
    }

    public static void h(Class cls, b0 b0Var) {
        defaultInstanceMap.put(cls, b0Var);
    }

    public final int a() {
        if (this.memoizedSerializedSize == -1) {
            f1 f1Var = f1.f1925c;
            f1Var.getClass();
            this.memoizedSerializedSize = f1Var.a(getClass()).g(this);
        }
        return this.memoizedSerializedSize;
    }

    public final void c(p pVar) {
        f1 f1Var = f1.f1925c;
        f1Var.getClass();
        j1 a10 = f1Var.a(getClass());
        z zVar = pVar.f2011c;
        if (zVar == null) {
            zVar = new z(pVar);
        }
        a10.d(this, zVar);
    }

    public abstract Object d(int i10);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!((b0) d(6)).getClass().isInstance(obj)) {
            return false;
        }
        f1 f1Var = f1.f1925c;
        f1Var.getClass();
        return f1Var.a(getClass()).f(this, (b0) obj);
    }

    public final boolean g() {
        byte byteValue = ((Byte) d(1)).byteValue();
        if (byteValue == 1) {
            return true;
        }
        if (byteValue == 0) {
            return false;
        }
        f1 f1Var = f1.f1925c;
        f1Var.getClass();
        boolean e10 = f1Var.a(getClass()).e(this);
        d(2);
        return e10;
    }

    public final int hashCode() {
        int i10 = this.memoizedHashCode;
        if (i10 != 0) {
            return i10;
        }
        f1 f1Var = f1.f1925c;
        f1Var.getClass();
        int i11 = f1Var.a(getClass()).i(this);
        this.memoizedHashCode = i11;
        return i11;
    }

    public final String toString() {
        String obj = super.toString();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("# ");
        sb2.append(obj);
        y0.i(this, sb2, 0);
        return sb2.toString();
    }
}
