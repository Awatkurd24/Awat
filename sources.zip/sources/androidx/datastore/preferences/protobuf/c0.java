package androidx.datastore.preferences.protobuf;

import java.util.RandomAccess;

public abstract class c0 extends c implements RandomAccess, e1 {
}
