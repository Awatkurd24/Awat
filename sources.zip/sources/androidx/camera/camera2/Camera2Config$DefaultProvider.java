package androidx.camera.camera2;

import a4.f;
import b0.v0;
import b0.x0;
import z.u;

public final class Camera2Config$DefaultProvider {
    public u getCameraXConfig() {
        Object obj = new Object();
        Object obj2 = new Object();
        Object obj3 = new Object();
        f fVar = new f(6);
        ((v0) fVar.f543a).k(u.f30543b, obj);
        ((v0) fVar.f543a).k(u.f30544c, obj2);
        ((v0) fVar.f543a).k(u.f30545d, obj3);
        return new u(x0.a((v0) fVar.f543a));
    }
}
