package androidx.camera.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Rational;
import android.util.Size;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.FrameLayout;
import androidx.lifecycle.g0;
import androidx.lifecycle.i0;
import b0.s;
import h.z;
import java.util.concurrent.atomic.AtomicReference;
import n0.d;
import n0.e;
import n0.f;
import n0.g;
import n0.h;
import n0.i;
import n0.j;
import n0.k;
import n0.l;
import n0.m;
import n0.n;
import n0.v;
import o0.a;
import o0.b;
import o0.c;
import r1.h1;
import v7.je;
import v7.t9;
import z.b1;
import z.o1;
import z.r1;
import z.y0;

public final class PreviewView extends FrameLayout {

    /* renamed from: l  reason: collision with root package name */
    public static final /* synthetic */ int f1594l = 0;

    /* renamed from: a  reason: collision with root package name */
    public h f1595a;

    /* renamed from: b  reason: collision with root package name */
    public l f1596b;

    /* renamed from: c  reason: collision with root package name */
    public final d f1597c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1598d;

    /* renamed from: e  reason: collision with root package name */
    public final i0 f1599e;

    /* renamed from: f  reason: collision with root package name */
    public final AtomicReference f1600f;

    /* renamed from: g  reason: collision with root package name */
    public final m f1601g;

    /* renamed from: h  reason: collision with root package name */
    public s f1602h;

    /* renamed from: i  reason: collision with root package name */
    public final g f1603i;

    /* renamed from: j  reason: collision with root package name */
    public final e f1604j;

    /* renamed from: k  reason: collision with root package name */
    public final f f1605k;

    public PreviewView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public static boolean b(o1 o1Var, h hVar) {
        boolean z4;
        boolean equals = o1Var.f30493c.l().d().equals("androidx.camera.camera2.legacy");
        z zVar = a.f23536a;
        if (zVar.f(c.class) == null && zVar.f(b.class) == null) {
            z4 = false;
        } else {
            z4 = true;
        }
        if (Build.VERSION.SDK_INT <= 24 || equals || z4) {
            return true;
        }
        int ordinal = hVar.ordinal();
        if (ordinal == 0) {
            return false;
        }
        if (ordinal == 1) {
            return true;
        }
        throw new IllegalArgumentException("Invalid implementation mode: " + hVar);
    }

    private DisplayManager getDisplayManager() {
        Context context = getContext();
        if (context == null) {
            return null;
        }
        return (DisplayManager) context.getApplicationContext().getSystemService("display");
    }

    private int getViewPortScaleType() {
        int ordinal = getScaleType().ordinal();
        if (ordinal == 0) {
            return 0;
        }
        int i10 = 1;
        if (ordinal != 1) {
            i10 = 2;
            if (ordinal != 2) {
                i10 = 3;
                if (!(ordinal == 3 || ordinal == 4 || ordinal == 5)) {
                    throw new IllegalStateException("Unexpected scale type: " + getScaleType());
                }
            }
        }
        return i10;
    }

    public final void a() {
        Display display;
        s sVar;
        je.a();
        if (this.f1596b != null) {
            if (!(!this.f1598d || (display = getDisplay()) == null || (sVar = this.f1602h) == null)) {
                int g10 = sVar.g(display.getRotation());
                int rotation = display.getRotation();
                d dVar = this.f1597c;
                if (dVar.f22835g) {
                    dVar.f22831c = g10;
                    dVar.f22833e = rotation;
                }
            }
            this.f1596b.f();
        }
        m mVar = this.f1601g;
        Size size = new Size(getWidth(), getHeight());
        int layoutDirection = getLayoutDirection();
        mVar.getClass();
        je.a();
        synchronized (mVar) {
            try {
                if (size.getWidth() != 0) {
                    if (size.getHeight() != 0) {
                        mVar.f22857a.a(layoutDirection, size);
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public Bitmap getBitmap() {
        Bitmap b5;
        je.a();
        l lVar = this.f1596b;
        if (lVar == null || (b5 = lVar.b()) == null) {
            return null;
        }
        FrameLayout frameLayout = lVar.f22854b;
        Size size = new Size(frameLayout.getWidth(), frameLayout.getHeight());
        int layoutDirection = frameLayout.getLayoutDirection();
        d dVar = lVar.f22855c;
        if (!dVar.f()) {
            return b5;
        }
        Matrix d10 = dVar.d();
        RectF e10 = dVar.e(layoutDirection, size);
        Bitmap createBitmap = Bitmap.createBitmap(size.getWidth(), size.getHeight(), b5.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        Matrix matrix = new Matrix();
        matrix.postConcat(d10);
        matrix.postScale(e10.width() / ((float) dVar.f22829a.getWidth()), e10.height() / ((float) dVar.f22829a.getHeight()));
        matrix.postTranslate(e10.left, e10.top);
        canvas.drawBitmap(b5, matrix, new Paint(7));
        return createBitmap;
    }

    public n0.a getController() {
        je.a();
        return null;
    }

    public h getImplementationMode() {
        je.a();
        return this.f1595a;
    }

    public y0 getMeteringPointFactory() {
        je.a();
        return this.f1601g;
    }

    /* JADX WARNING: type inference failed for: r1v5, types: [p0.a, java.lang.Object] */
    public p0.a getOutputTransform() {
        Matrix matrix;
        d dVar = this.f1597c;
        je.a();
        try {
            matrix = dVar.c(getLayoutDirection(), new Size(getWidth(), getHeight()));
        } catch (IllegalStateException unused) {
            matrix = null;
        }
        Rect rect = dVar.f22830b;
        if (matrix == null || rect == null) {
            t9.a("PreviewView", "Transform info is not ready");
            return null;
        }
        RectF rectF = c0.h.f3723a;
        RectF rectF2 = new RectF(rect);
        Matrix matrix2 = new Matrix();
        matrix2.setRectToRect(c0.h.f3723a, rectF2, Matrix.ScaleToFit.FILL);
        matrix.preConcat(matrix2);
        if (this.f1596b instanceof v) {
            matrix.postConcat(getMatrix());
        } else if (!getMatrix().isIdentity()) {
            t9.g("PreviewView", "PreviewView needs to be in COMPATIBLE mode for the transform to work correctly.");
        }
        new Size(rect.width(), rect.height());
        return new Object();
    }

    public g0 getPreviewStreamState() {
        return this.f1599e;
    }

    public j getScaleType() {
        je.a();
        return this.f1597c.f22836h;
    }

    public Matrix getSensorToViewTransform() {
        je.a();
        Size size = new Size(getWidth(), getHeight());
        int layoutDirection = getLayoutDirection();
        d dVar = this.f1597c;
        if (!dVar.f()) {
            return null;
        }
        Matrix matrix = new Matrix(dVar.f22832d);
        matrix.postConcat(dVar.c(layoutDirection, size));
        return matrix;
    }

    public b1 getSurfaceProvider() {
        je.a();
        return this.f1605k;
    }

    /* JADX WARNING: type inference failed for: r4v0, types: [java.lang.Object, z.r1] */
    public r1 getViewPort() {
        je.a();
        if (getDisplay() == null) {
            return null;
        }
        int rotation = getDisplay().getRotation();
        je.a();
        if (getWidth() == 0 || getHeight() == 0) {
            return null;
        }
        Rational rational = new Rational(getWidth(), getHeight());
        int viewPortScaleType = getViewPortScaleType();
        int layoutDirection = getLayoutDirection();
        ? obj = new Object();
        obj.f30521a = viewPortScaleType;
        obj.f30522b = rational;
        obj.f30523c = rotation;
        obj.f30524d = layoutDirection;
        return obj;
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        DisplayManager displayManager = getDisplayManager();
        if (displayManager != null) {
            displayManager.registerDisplayListener(this.f1603i, new Handler(Looper.getMainLooper()));
        }
        addOnLayoutChangeListener(this.f1604j);
        l lVar = this.f1596b;
        if (lVar != null) {
            lVar.c();
        }
        je.a();
        getViewPort();
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeOnLayoutChangeListener(this.f1604j);
        l lVar = this.f1596b;
        if (lVar != null) {
            lVar.d();
        }
        DisplayManager displayManager = getDisplayManager();
        if (displayManager != null) {
            displayManager.unregisterDisplayListener(this.f1603i);
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    public final boolean performClick() {
        return super.performClick();
    }

    public void setController(n0.a aVar) {
        je.a();
        je.a();
        getViewPort();
    }

    public void setImplementationMode(h hVar) {
        je.a();
        this.f1595a = hVar;
    }

    public void setScaleType(j jVar) {
        je.a();
        this.f1597c.f22836h = jVar;
        a();
        je.a();
        getViewPort();
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, n0.d] */
    /* JADX WARNING: type inference failed for: r3v0, types: [androidx.lifecycle.g0, androidx.lifecycle.i0] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PreviewView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10, 0);
        this.f1595a = h.PERFORMANCE;
        ? obj = new Object();
        obj.f22836h = j.FILL_CENTER;
        this.f1597c = obj;
        this.f1598d = true;
        this.f1599e = new g0(k.f22850a);
        this.f1600f = new AtomicReference();
        this.f1601g = new m(obj);
        this.f1603i = new g(this);
        this.f1604j = new e(this);
        this.f1605k = new f(this);
        je.a();
        Resources.Theme theme = context.getTheme();
        int[] iArr = n.f22858a;
        TypedArray obtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        h1.q(this, context, iArr, attributeSet, obtainStyledAttributes, i10);
        try {
            int integer = obtainStyledAttributes.getInteger(1, obj.f22836h.f22849a);
            for (j jVar : j.values()) {
                if (jVar.f22849a == integer) {
                    setScaleType(jVar);
                    int integer2 = obtainStyledAttributes.getInteger(0, 0);
                    for (h hVar : h.values()) {
                        if (hVar.f22842a == integer2) {
                            setImplementationMode(hVar);
                            obtainStyledAttributes.recycle();
                            new ScaleGestureDetector(context, new i(this));
                            if (getBackground() == null) {
                                setBackgroundColor(h1.i.b(getContext(), 17170444));
                                return;
                            }
                            return;
                        }
                    }
                    throw new IllegalArgumentException("Unknown implementation mode id " + integer2);
                }
            }
            throw new IllegalArgumentException("Unknown scale type id " + integer);
        } catch (Throwable th2) {
            obtainStyledAttributes.recycle();
            throw th2;
        }
    }
}
