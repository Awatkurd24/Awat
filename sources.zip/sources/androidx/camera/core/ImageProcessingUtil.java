package androidx.camera.core;

import android.graphics.Bitmap;
import android.media.Image;
import android.media.ImageWriter;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import androidx.appcompat.widget.d0;
import he.j;
import java.nio.ByteBuffer;
import java.util.Locale;
import t.u;
import v7.t9;
import w7.ua;
import z.e1;
import z.l0;
import z.r0;
import z.t0;

public abstract class ImageProcessingUtil {

    /* renamed from: a  reason: collision with root package name */
    public static int f1593a;

    static {
        System.loadLibrary("image_processing_util_jni");
    }

    public static void a(t0 t0Var) {
        if (!e(t0Var)) {
            t9.b("ImageProcessingUtil", "Unsupported format for YUV to RGB");
            return;
        }
        int width = t0Var.getWidth();
        int height = t0Var.getHeight();
        int a10 = t0Var.g()[0].a();
        int a11 = t0Var.g()[1].a();
        int a12 = t0Var.g()[2].a();
        int c10 = t0Var.g()[0].c();
        int c11 = t0Var.g()[1].c();
        if (nativeShiftPixel(t0Var.g()[0].b(), a10, t0Var.g()[1].b(), a11, t0Var.g()[2].b(), a12, c10, c11, width, height, c10, c11, c11) != 0) {
            t9.b("ImageProcessingUtil", "One pixel shift for YUV failure");
        }
    }

    public static t0 b(e1 e1Var, byte[] bArr) {
        boolean z4;
        if (e1Var.c() == 256) {
            z4 = true;
        } else {
            z4 = false;
        }
        ua.c(z4);
        bArr.getClass();
        Surface a10 = e1Var.a();
        a10.getClass();
        if (nativeWriteJpegToSurface(bArr, a10) != 0) {
            t9.b("ImageProcessingUtil", "Failed to enqueue JPEG image.");
            return null;
        }
        t0 b5 = e1Var.b();
        if (b5 == null) {
            t9.b("ImageProcessingUtil", "Failed to get acquire JPEG image.");
        }
        return b5;
    }

    public static l0 c(t0 t0Var, e1 e1Var, ByteBuffer byteBuffer, int i10, boolean z4) {
        int i11;
        int i12;
        int i13;
        int i14;
        int i15 = i10;
        if (!e(t0Var)) {
            t9.b("ImageProcessingUtil", "Unsupported format for YUV to RGB");
            return null;
        }
        long currentTimeMillis = System.currentTimeMillis();
        if (i15 == 0 || i15 == 90 || i15 == 180 || i15 == 270) {
            Surface a10 = e1Var.a();
            int width = t0Var.getWidth();
            int height = t0Var.getHeight();
            int a11 = t0Var.g()[0].a();
            int a12 = t0Var.g()[1].a();
            int a13 = t0Var.g()[2].a();
            int c10 = t0Var.g()[0].c();
            int c11 = t0Var.g()[1].c();
            if (z4) {
                i11 = c10;
            } else {
                i11 = 0;
            }
            if (z4) {
                i12 = c11;
            } else {
                i12 = 0;
            }
            if (z4) {
                i13 = c11;
            } else {
                i13 = 0;
            }
            String str = "ImageProcessingUtil";
            if (nativeConvertAndroid420ToABGR(t0Var.g()[0].b(), a11, t0Var.g()[1].b(), a12, t0Var.g()[2].b(), a13, c10, c11, a10, byteBuffer, width, height, i11, i12, i13, i10) != 0) {
                t9.b(str, "YUV to RGB conversion failure");
                return null;
            }
            String str2 = str;
            if (Log.isLoggable("MH", 3)) {
                i14 = 0;
                t9.a(str2, String.format(Locale.US, "Image processing performance profiling, duration: [%d], image count: %d", new Object[]{Long.valueOf(System.currentTimeMillis() - currentTimeMillis), Integer.valueOf(f1593a)}));
                f1593a++;
            } else {
                i14 = 0;
            }
            t0 b5 = e1Var.b();
            if (b5 == null) {
                t9.b(str2, "YUV to RGB acquireLatestImage failure");
                return null;
            }
            l0 l0Var = new l0(b5);
            l0Var.a(new r0(b5, t0Var, i14));
            return l0Var;
        }
        t9.b("ImageProcessingUtil", "Unsupported rotation degrees for rotate RGB");
        return null;
    }

    public static void d(Bitmap bitmap, ByteBuffer byteBuffer, int i10) {
        nativeCopyBetweenByteBufferAndBitmap(bitmap, byteBuffer, i10, bitmap.getRowBytes(), bitmap.getWidth(), bitmap.getHeight(), true);
    }

    public static boolean e(t0 t0Var) {
        return t0Var.O() == 35 && t0Var.g().length == 3;
    }

    public static l0 f(t0 t0Var, e1 e1Var, ImageWriter imageWriter, ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int i10) {
        String str;
        int i11 = i10;
        if (!e(t0Var)) {
            t9.b("ImageProcessingUtil", "Unsupported format for rotate YUV");
            return null;
        } else if (i11 == 0 || i11 == 90 || i11 == 180 || i11 == 270) {
            int i12 = Build.VERSION.SDK_INT;
            if (i12 >= 23 && i11 > 0) {
                int width = t0Var.getWidth();
                int height = t0Var.getHeight();
                int a10 = t0Var.g()[0].a();
                int a11 = t0Var.g()[1].a();
                int a12 = t0Var.g()[2].a();
                int c10 = t0Var.g()[1].c();
                if (i12 >= 23) {
                    Image b5 = d0.b(imageWriter);
                    if (b5 != null) {
                        Image image = b5;
                        String str2 = "ImageProcessingUtil";
                        if (nativeRotateYUV(t0Var.g()[0].b(), a10, t0Var.g()[1].b(), a11, t0Var.g()[2].b(), a12, c10, b5.getPlanes()[0].getBuffer(), b5.getPlanes()[0].getRowStride(), b5.getPlanes()[0].getPixelStride(), b5.getPlanes()[1].getBuffer(), b5.getPlanes()[1].getRowStride(), b5.getPlanes()[1].getPixelStride(), b5.getPlanes()[2].getBuffer(), b5.getPlanes()[2].getRowStride(), b5.getPlanes()[2].getPixelStride(), byteBuffer, byteBuffer2, byteBuffer3, width, height, i10) != 0) {
                            str = str2;
                            t9.b(str, "rotate YUV failure");
                            return null;
                        }
                        j.e(imageWriter, image);
                        t0 b10 = e1Var.b();
                        if (b10 == null) {
                            t9.b(str2, "YUV rotation acquireLatestImage failure");
                            return null;
                        }
                        l0 l0Var = new l0(b10);
                        l0Var.a(new r0(b10, t0Var, 1));
                        return l0Var;
                    }
                } else {
                    throw new RuntimeException(u.c("Unable to call dequeueInputImage() on API ", i12, ". Version 23 or higher required."));
                }
            }
            str = "ImageProcessingUtil";
            t9.b(str, "rotate YUV failure");
            return null;
        } else {
            t9.b("ImageProcessingUtil", "Unsupported rotation degrees for rotate YUV");
            return null;
        }
    }

    public static void g(byte[] bArr, Surface surface) {
        surface.getClass();
        if (nativeWriteJpegToSurface(bArr, surface) != 0) {
            t9.b("ImageProcessingUtil", "Failed to enqueue JPEG image.");
        }
    }

    private static native int nativeConvertAndroid420ToABGR(ByteBuffer byteBuffer, int i10, ByteBuffer byteBuffer2, int i11, ByteBuffer byteBuffer3, int i12, int i13, int i14, Surface surface, ByteBuffer byteBuffer4, int i15, int i16, int i17, int i18, int i19, int i20);

    private static native int nativeCopyBetweenByteBufferAndBitmap(Bitmap bitmap, ByteBuffer byteBuffer, int i10, int i11, int i12, int i13, boolean z4);

    private static native int nativeRotateYUV(ByteBuffer byteBuffer, int i10, ByteBuffer byteBuffer2, int i11, ByteBuffer byteBuffer3, int i12, int i13, ByteBuffer byteBuffer4, int i14, int i15, ByteBuffer byteBuffer5, int i16, int i17, ByteBuffer byteBuffer6, int i18, int i19, ByteBuffer byteBuffer7, ByteBuffer byteBuffer8, ByteBuffer byteBuffer9, int i20, int i21, int i22);

    private static native int nativeShiftPixel(ByteBuffer byteBuffer, int i10, ByteBuffer byteBuffer2, int i11, ByteBuffer byteBuffer3, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19);

    private static native int nativeWriteJpegToSurface(byte[] bArr, Surface surface);
}
