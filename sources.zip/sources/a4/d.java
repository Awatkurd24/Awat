package a4;

import v7.r0;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final String f538a;

    /* renamed from: b  reason: collision with root package name */
    public final Long f539b;

    public d(String str, Long l10) {
        this.f538a = str;
        this.f539b = l10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return r0.b(this.f538a, dVar.f538a) && r0.b(this.f539b, dVar.f539b);
    }

    public final int hashCode() {
        int hashCode = this.f538a.hashCode() * 31;
        Long l10 = this.f539b;
        return hashCode + (l10 == null ? 0 : l10.hashCode());
    }

    public final String toString() {
        return "Preference(key=" + this.f538a + ", value=" + this.f539b + ')';
    }
}
