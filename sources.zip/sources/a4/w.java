package a4;

import a3.a0;
import a3.e;
import a3.x;
import android.content.ClipDescription;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Size;
import android.util.TypedValue;
import android.view.Surface;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.a1;
import androidx.lifecycle.c1;
import androidx.lifecycle.e1;
import androidx.lifecycle.i1;
import androidx.lifecycle.j1;
import androidx.lifecycle.p;
import androidx.lifecycle.w0;
import androidx.lifecycle.x0;
import androidx.lifecycle.y;
import androidx.work.multiprocess.RemoteListenableWorker;
import androidx.work.multiprocess.parcelable.ParcelableRemoteWorkRequest;
import b0.s;
import com.v2ray.ang.dto.V2rayConfig;
import d4.a;
import e0.c;
import f4.m;
import f4.o;
import h.d;
import h.y0;
import i1.q;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import ne.c0;
import s3.z;
import t.g1;
import t.n;
import t0.j;
import u0.h;
import u1.g;
import v1.k;
import v7.r0;
import v7.t9;
import w.l;
import w0.f;
import w7.ua;
import x0.b;
import z.i;
import z.m1;
import z.r;
import z.t;

public final class w implements d, k, c, t0.k, g, a, o {

    /* renamed from: e  reason: collision with root package name */
    public static w f616e;

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f617a;

    /* renamed from: b  reason: collision with root package name */
    public Object f618b;

    /* renamed from: c  reason: collision with root package name */
    public Object f619c;

    /* renamed from: d  reason: collision with root package name */
    public Object f620d;

    public w(int i10) {
        this.f617a = i10;
        if (i10 == 22) {
            this.f618b = Collections.emptyList();
            this.f619c = Collections.emptyList();
        } else if (i10 == 27) {
        } else {
            if (i10 != 28) {
                this.f618b = new Object();
                this.f619c = new LinkedHashMap();
                this.f620d = new HashSet();
            }
        }
    }

    public static w K(Context context, AttributeSet attributeSet, int[] iArr, int i10) {
        return new w(context, context.obtainStyledAttributes(attributeSet, iArr, i10, 0));
    }

    public final Location A(String str) {
        try {
            if (((LocationManager) this.f619c).isProviderEnabled(str)) {
                return ((LocationManager) this.f619c).getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e10) {
            Log.d("TwilightManager", "Failed to get last known location", e10);
            return null;
        }
    }

    public final int B(int i10, int i11) {
        return ((TypedArray) this.f619c).getResourceId(i10, i11);
    }

    public final String C(int i10) {
        return ((TypedArray) this.f619c).getString(i10);
    }

    public final void D(Throwable th2) {
        boolean a10;
        switch (this.f617a) {
            case 6:
                throw new IllegalStateException("Future should never fail. Did it get completed by GC?", th2);
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                if (th2 instanceof m1) {
                    a10 = ((y9.a) this.f619c).cancel(false);
                } else {
                    a10 = ((j) this.f618b).a((Object) null);
                }
                ua.g((String) null, a10);
                return;
            case 9:
                ua.g("Camera surface session should only fail with request cancellation. Instead failed due to:\n" + th2, th2 instanceof m1);
                ((q1.a) this.f618b).accept(new i(1, (Surface) this.f619c));
                return;
            case 13:
                ((j) this.f618b).b(th2);
                return;
            default:
                ((g1) this.f620d).f26249f = null;
                if (!((List) this.f618b).isEmpty()) {
                    for (b0.i j3 : (List) this.f618b) {
                        ((s) this.f619c).j(j3);
                    }
                    ((List) this.f618b).clear();
                    return;
                }
                return;
        }
    }

    public final ArrayList E(String str) {
        a0 p5 = a0.p(1, "SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        ((x) this.f618b).b();
        Cursor i10 = c0.i((x) this.f618b, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                arrayList.add(i10.isNull(0) ? null : i10.getString(0));
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final CharSequence F(int i10) {
        return ((TypedArray) this.f619c).getText(i10);
    }

    public final boolean G(int i10) {
        return ((TypedArray) this.f619c).hasValue(i10);
    }

    public final void H(n nVar) {
        synchronized (this.f618b) {
            try {
                nVar.getClass();
                for (String str : new LinkedHashSet(nVar.f26338e)) {
                    t9.a("CameraRepository", "Added camera: " + str);
                    ((Map) this.f619c).put(str, nVar.a(str));
                }
            } catch (r e10) {
                throw new Exception(e10);
            }
        }
    }

    public final void I(String str, Set set) {
        r0.j("tags", set);
        Iterator it = set.iterator();
        while (it.hasNext()) {
            v vVar = new v((String) it.next(), str);
            ((x) this.f618b).b();
            ((x) this.f618b).c();
            try {
                ((e) this.f619c).M(vVar);
                ((x) this.f618b).n();
            } finally {
                ((x) this.f618b).j();
            }
        }
    }

    public final boolean J(int i10, w0.e eVar, x0.n nVar) {
        boolean z4;
        boolean z10;
        boolean z11;
        boolean z12;
        b bVar = (b) this.f619c;
        w0.d[] dVarArr = eVar.U;
        bVar.f29500a = dVarArr[0];
        bVar.f29501b = dVarArr[1];
        bVar.f29502c = eVar.s();
        ((b) this.f619c).f29503d = eVar.m();
        b bVar2 = (b) this.f619c;
        bVar2.f29508i = false;
        bVar2.f29509j = i10;
        w0.d dVar = bVar2.f29500a;
        w0.d dVar2 = w0.d.f28556c;
        if (dVar == dVar2) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (bVar2.f29501b == dVar2) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!z4 || eVar.Y <= 0.0f) {
            z11 = false;
        } else {
            z11 = true;
        }
        if (!z10 || eVar.Y <= 0.0f) {
            z12 = false;
        } else {
            z12 = true;
        }
        w0.d dVar3 = w0.d.f28554a;
        int[] iArr = eVar.f28597t;
        if (z11 && iArr[0] == 4) {
            bVar2.f29500a = dVar3;
        }
        if (z12 && iArr[1] == 4) {
            bVar2.f29501b = dVar3;
        }
        nVar.b(eVar, bVar2);
        eVar.Q(((b) this.f619c).f29504e);
        eVar.N(((b) this.f619c).f29505f);
        b bVar3 = (b) this.f619c;
        eVar.E = bVar3.f29507h;
        eVar.K(bVar3.f29506g);
        b bVar4 = (b) this.f619c;
        bVar4.f29509j = 0;
        return bVar4.f29508i;
    }

    public final void L() {
        switch (this.f617a) {
            case 6:
                ((Surface) this.f618b).release();
                ((SurfaceTexture) this.f619c).release();
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                ua.g((String) null, ((j) this.f618b).a((Object) null));
                return;
            case 9:
                ((q1.a) this.f618b).accept(new i(0, (Surface) this.f619c));
                return;
            case 13:
                ((j) this.f618b).a((t) this.f619c);
                return;
            default:
                ((g1) this.f620d).f26249f = null;
                return;
        }
    }

    public final void M(p pVar) {
        t.w wVar = (t.w) this.f620d;
        if (wVar != null) {
            wVar.run();
        }
        t.w wVar2 = new t.w((androidx.lifecycle.a0) this.f618b, pVar);
        this.f620d = wVar2;
        ((Handler) this.f619c).postAtFrontOfQueue(wVar2);
    }

    public final void N() {
        ((TypedArray) this.f619c).recycle();
    }

    public final void O(String str) {
        if (str != null) {
            this.f618b = str;
            return;
        }
        throw new NullPointerException("Null backendName");
    }

    public final void P(w5.d dVar) {
        if (dVar != null) {
            this.f620d = dVar;
            return;
        }
        throw new NullPointerException("Null priority");
    }

    public final void Q(f fVar, int i10, int i11, int i12) {
        int i13 = fVar.f28566d0;
        int i14 = fVar.f28568e0;
        fVar.f28566d0 = 0;
        fVar.f28568e0 = 0;
        fVar.Q(i11);
        fVar.N(i12);
        if (i13 < 0) {
            fVar.f28566d0 = 0;
        } else {
            fVar.f28566d0 = i13;
        }
        if (i14 < 0) {
            fVar.f28568e0 = 0;
        } else {
            fVar.f28568e0 = i14;
        }
        f fVar2 = (f) this.f620d;
        fVar2.f28608y0 = i10;
        fVar2.T();
    }

    public final void R(f fVar) {
        ((ArrayList) this.f618b).clear();
        int size = fVar.f28646v0.size();
        for (int i10 = 0; i10 < size; i10++) {
            w0.e eVar = (w0.e) fVar.f28646v0.get(i10);
            w0.d[] dVarArr = eVar.U;
            w0.d dVar = dVarArr[0];
            w0.d dVar2 = w0.d.f28556c;
            if (dVar == dVar2 || dVarArr[1] == dVar2) {
                ((ArrayList) this.f618b).add(eVar);
            }
        }
        fVar.f28607x0.f29512a = true;
    }

    public final void W(IInterface iInterface, m mVar) {
        s j3 = ((z) this.f618b).f25873c.v().j((String) this.f619c);
        String str = j3.f580c;
        ((RemoteListenableWorker) this.f620d).getClass();
        byte[] g10 = c0.g(new ParcelableRemoteWorkRequest(j3.f580c, ((RemoteListenableWorker) this.f620d).f3236a));
        f4.a aVar = (f4.a) ((f4.c) iInterface);
        aVar.getClass();
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("androidx.work.multiprocess.IListenableWorkerImpl");
            obtain.writeByteArray(g10);
            obtain.writeStrongInterface(mVar);
            aVar.f18436a.transact(1, obtain, (Parcel) null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final ClipDescription a() {
        return (ClipDescription) this.f619c;
    }

    public final void b(i.j jVar, int i10) {
        ((Toolbar) this.f618b).setNavigationIcon((Drawable) jVar);
        f(i10);
    }

    public final boolean c() {
        return true;
    }

    public final Object d() {
        return null;
    }

    public final Uri e() {
        return (Uri) this.f618b;
    }

    public final void f(int i10) {
        if (i10 == 0) {
            ((Toolbar) this.f618b).setNavigationContentDescription((CharSequence) this.f620d);
        } else {
            ((Toolbar) this.f618b).setNavigationContentDescription(i10);
        }
    }

    public final Object g(j jVar) {
        y0 y0Var = new y0(4, this);
        d0.a k10 = ua.k();
        t0.n nVar = jVar.f26506c;
        if (nVar != null) {
            nVar.a(y0Var, k10);
        }
        ((d0.c) this.f620d).f17615a.set(jVar);
        return "HandlerScheduledFuture-" + ((Callable) this.f619c).toString();
    }

    public final void h() {
    }

    public final Uri i() {
        return (Uri) this.f620d;
    }

    public final Context j() {
        return ((Toolbar) this.f618b).getContext();
    }

    public final Size[] k(Size[] sizeArr, int i10) {
        List list;
        boolean z4;
        boolean z10;
        ArrayList arrayList;
        Size size;
        Size size2;
        ArrayList arrayList2;
        int i11 = i10;
        ArrayList arrayList3 = new ArrayList(Arrays.asList(sizeArr));
        if (((w.n) this.f619c) != null) {
            Size[] sizeArr2 = (i11 != 34 || !"motorola".equalsIgnoreCase(Build.BRAND) || !"moto e5 play".equalsIgnoreCase(Build.MODEL)) ? new Size[0] : new Size[]{new Size(1920, 1080), new Size(1440, 1080), new Size(1280, 720), new Size(960, 720), new Size(864, 480), new Size(720, 480)};
            if (sizeArr2.length > 0) {
                arrayList3.addAll(Arrays.asList(sizeArr2));
            }
        }
        x.b bVar = (x.b) this.f620d;
        bVar.getClass();
        if (((l) w.k.f28507a.f(l.class)) == null) {
            list = new ArrayList();
        } else {
            String str = bVar.f29484b;
            String str2 = Build.BRAND;
            if (!"OnePlus".equalsIgnoreCase(str2) || !"OnePlus6".equalsIgnoreCase(Build.DEVICE)) {
                z4 = false;
            } else {
                z4 = true;
            }
            if (z4) {
                arrayList2 = new ArrayList();
                if (str.equals("0") && i11 == 256) {
                    arrayList2.add(new Size(4160, 3120));
                    arrayList2.add(new Size(4000, 3000));
                }
            } else if (!"OnePlus".equalsIgnoreCase(str2) || !"OnePlus6T".equalsIgnoreCase(Build.DEVICE)) {
                if (!"HUAWEI".equalsIgnoreCase(str2) || !"HWANE".equalsIgnoreCase(Build.DEVICE)) {
                    z10 = false;
                } else {
                    z10 = true;
                }
                if (z10) {
                    arrayList = new ArrayList();
                    if (str.equals("0") && (i11 == 34 || i11 == 35)) {
                        arrayList.add(new Size(720, 720));
                        arrayList.add(new Size(400, 400));
                    }
                } else if (l.b()) {
                    arrayList = new ArrayList();
                    if (str.equals("0")) {
                        if (i11 == 34) {
                            arrayList.add(new Size(4128, 3096));
                            arrayList.add(new Size(4128, 2322));
                            arrayList.add(new Size(3088, 3088));
                            arrayList.add(new Size(3264, 2448));
                            arrayList.add(new Size(3264, 1836));
                            arrayList.add(new Size(2048, 1536));
                            arrayList.add(new Size(2048, 1152));
                            size2 = new Size(1920, 1080);
                        } else if (i11 == 35) {
                            arrayList.add(new Size(4128, 2322));
                            arrayList.add(new Size(3088, 3088));
                            arrayList.add(new Size(3264, 2448));
                            arrayList.add(new Size(3264, 1836));
                            arrayList.add(new Size(2048, 1536));
                            arrayList.add(new Size(2048, 1152));
                            size2 = new Size(1920, 1080);
                        }
                    } else if (str.equals("1") && (i11 == 34 || i11 == 35)) {
                        arrayList.add(new Size(3264, 2448));
                        arrayList.add(new Size(3264, 1836));
                        arrayList.add(new Size(2448, 2448));
                        arrayList.add(new Size(1920, 1920));
                        arrayList.add(new Size(2048, 1536));
                        arrayList.add(new Size(2048, 1152));
                        size2 = new Size(1920, 1080);
                    }
                    arrayList.add(size2);
                } else if (l.a()) {
                    arrayList = new ArrayList();
                    if (str.equals("0")) {
                        if (i11 == 34) {
                            arrayList.add(new Size(4128, 3096));
                            arrayList.add(new Size(4128, 2322));
                            arrayList.add(new Size(3088, 3088));
                            arrayList.add(new Size(3264, 2448));
                            arrayList.add(new Size(3264, 1836));
                            arrayList.add(new Size(2048, 1536));
                            arrayList.add(new Size(2048, 1152));
                            size = new Size(1920, 1080);
                        } else if (i11 == 35) {
                            arrayList.add(new Size(2048, 1536));
                            arrayList.add(new Size(2048, 1152));
                            size = new Size(1920, 1080);
                        }
                    } else if (str.equals("1") && (i11 == 34 || i11 == 35)) {
                        arrayList.add(new Size(2576, 1932));
                        arrayList.add(new Size(2560, 1440));
                        arrayList.add(new Size(1920, 1920));
                        arrayList.add(new Size(2048, 1536));
                        arrayList.add(new Size(2048, 1152));
                        size = new Size(1920, 1080);
                    }
                    arrayList.add(size);
                } else {
                    t9.g("ExcludedSupportedSizesQuirk", "Cannot retrieve list of supported sizes to exclude on this device.");
                    list = Collections.emptyList();
                }
                list = arrayList;
            } else {
                arrayList2 = new ArrayList();
                if (str.equals("0") && i11 == 256) {
                    arrayList2.add(new Size(4160, 3120));
                    arrayList2.add(new Size(4000, 3000));
                }
            }
            list = arrayList2;
        }
        if (!list.isEmpty()) {
            arrayList3.removeAll(list);
        }
        if (arrayList3.isEmpty()) {
            t9.g("OutputSizesCorrector", "Sizes array becomes empty after excluding problematic output sizes.");
        }
        return (Size[]) arrayList3.toArray(new Size[0]);
    }

    public final e6.b l() {
        String str;
        if (((Long) this.f618b) == null) {
            str = " delta";
        } else {
            str = "";
        }
        if (((Long) this.f619c) == null) {
            str = str.concat(" maxAllowedDelay");
        }
        if (((Set) this.f620d) == null) {
            str = l.H(str, " flags");
        }
        if (str.isEmpty()) {
            return new e6.b(((Long) this.f618b).longValue(), ((Long) this.f619c).longValue(), (Set) this.f620d);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final void m(NestedScrollView nestedScrollView) {
        h.o.b(nestedScrollView, (View) this.f618b, (View) this.f619c);
    }

    public final z5.i n() {
        String str = ((String) this.f618b) == null ? " backendName" : "";
        if (((w5.d) this.f620d) == null) {
            str = str.concat(" priority");
        }
        if (str.isEmpty()) {
            return new z5.i((String) this.f618b, (byte[]) this.f619c, (w5.d) this.f620d);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final void o(Runnable runnable) {
        ((b4.o) this.f618b).execute(runnable);
    }

    public final /* bridge */ /* synthetic */ void onSuccess(Object obj) {
        switch (this.f617a) {
            case 6:
                Void voidR = (Void) obj;
                L();
                return;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                Void voidR2 = (Void) obj;
                L();
                return;
            case 9:
                Void voidR3 = (Void) obj;
                L();
                return;
            case 13:
                Void voidR4 = (Void) obj;
                L();
                return;
            default:
                Void voidR5 = (Void) obj;
                L();
                return;
        }
    }

    public final c1 p(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return q(cls, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName));
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public final c1 q(Class cls, String str) {
        c1 c1Var;
        a1 a1Var;
        r0.j("key", str);
        i1 i1Var = (i1) this.f618b;
        i1Var.getClass();
        c1 c1Var2 = (c1) i1Var.f2441a.get(str);
        if (cls.isInstance(c1Var2)) {
            androidx.lifecycle.g1 g1Var = (androidx.lifecycle.g1) this.f619c;
            if (g1Var instanceof a1) {
                a1Var = (a1) g1Var;
            } else {
                a1Var = null;
            }
            if (a1Var != null) {
                r0.g(c1Var2);
                androidx.lifecycle.r rVar = a1Var.f2390d;
                if (rVar != null) {
                    d3.e eVar = a1Var.f2391e;
                    r0.g(eVar);
                    x0.a(c1Var2, eVar, rVar);
                }
            }
            r0.h("null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get", c1Var2);
            return c1Var2;
        }
        p2.d dVar = new p2.d((p2.c) this.f620d);
        dVar.a(e1.f2413b, str);
        try {
            c1Var = ((androidx.lifecycle.g1) this.f619c).b(cls, dVar);
        } catch (AbstractMethodError unused) {
            c1Var = ((androidx.lifecycle.g1) this.f619c).a(cls);
        }
        i1 i1Var2 = (i1) this.f618b;
        i1Var2.getClass();
        r0.j("viewModel", c1Var);
        c1 c1Var3 = (c1) i1Var2.f2441a.put(str, c1Var);
        if (c1Var3 != null) {
            c1Var3.onCleared();
        }
        return c1Var;
    }

    public final boolean r(int i10, boolean z4) {
        return ((TypedArray) this.f619c).getBoolean(i10, z4);
    }

    public final LinkedHashSet s() {
        LinkedHashSet linkedHashSet;
        synchronized (this.f618b) {
            linkedHashSet = new LinkedHashSet(((Map) this.f619c).values());
        }
        return linkedHashSet;
    }

    public final ColorStateList t(int i10) {
        int resourceId;
        ColorStateList c10;
        if (!((TypedArray) this.f619c).hasValue(i10) || (resourceId = ((TypedArray) this.f619c).getResourceId(i10, 0)) == 0 || (c10 = h1.i.c((Context) this.f618b, resourceId)) == null) {
            return ((TypedArray) this.f619c).getColorStateList(i10);
        }
        return c10;
    }

    public final String toString() {
        switch (this.f617a) {
            case 15:
                String str = "[ ";
                if (((h) this.f618b) != null) {
                    for (int i10 = 0; i10 < 9; i10++) {
                        StringBuilder o10 = f.c.o(str);
                        o10.append(((h) this.f618b).f26986h[i10]);
                        o10.append(" ");
                        str = o10.toString();
                    }
                }
                return str + "] " + ((h) this.f618b);
            default:
                return super.toString();
        }
    }

    public final int u(int i10, int i11) {
        return ((TypedArray) this.f619c).getDimensionPixelOffset(i10, i11);
    }

    public final int v(int i10, int i11) {
        return ((TypedArray) this.f619c).getDimensionPixelSize(i10, i11);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000a, code lost:
        r0 = ((android.content.res.TypedArray) r2.f619c).getResourceId(r3, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.graphics.drawable.Drawable w(int r3) {
        /*
            r2 = this;
            java.lang.Object r0 = r2.f619c
            android.content.res.TypedArray r0 = (android.content.res.TypedArray) r0
            boolean r0 = r0.hasValue(r3)
            if (r0 == 0) goto L_0x001e
            java.lang.Object r0 = r2.f619c
            android.content.res.TypedArray r0 = (android.content.res.TypedArray) r0
            r1 = 0
            int r0 = r0.getResourceId(r3, r1)
            if (r0 == 0) goto L_0x001e
            java.lang.Object r3 = r2.f618b
            android.content.Context r3 = (android.content.Context) r3
            android.graphics.drawable.Drawable r3 = u7.y.e(r3, r0)
            return r3
        L_0x001e:
            java.lang.Object r0 = r2.f619c
            android.content.res.TypedArray r0 = (android.content.res.TypedArray) r0
            android.graphics.drawable.Drawable r3 = r0.getDrawable(r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.w.w(int):android.graphics.drawable.Drawable");
    }

    public final Drawable x(int i10) {
        int resourceId;
        Drawable g10;
        if (!((TypedArray) this.f619c).hasValue(i10) || (resourceId = ((TypedArray) this.f619c).getResourceId(i10, 0)) == 0) {
            return null;
        }
        androidx.appcompat.widget.z a10 = androidx.appcompat.widget.z.a();
        Context context = (Context) this.f618b;
        synchronized (a10) {
            g10 = a10.f1587a.g(context, resourceId, true);
        }
        return g10;
    }

    public final Typeface y(int i10, int i11, androidx.appcompat.widget.r0 r0Var) {
        int resourceId = ((TypedArray) this.f619c).getResourceId(i10, 0);
        if (resourceId == 0) {
            return null;
        }
        if (((TypedValue) this.f620d) == null) {
            this.f620d = new TypedValue();
        }
        Context context = (Context) this.f618b;
        TypedValue typedValue = (TypedValue) this.f620d;
        ThreadLocal threadLocal = q.f19953a;
        if (context.isRestricted()) {
            return null;
        }
        return q.c(context, resourceId, typedValue, i11, r0Var, true, false);
    }

    public final int z(int i10, int i11) {
        return ((TypedArray) this.f619c).getInt(i10, i11);
    }

    public w(x xVar) {
        this.f617a = 0;
        this.f618b = xVar;
        this.f619c = new b(this, xVar, 6);
        this.f620d = new h(this, xVar, 2);
    }

    public w(Context context, TypedArray typedArray) {
        this.f617a = 5;
        this.f618b = context;
        this.f619c = typedArray;
    }

    public w(Context context, LocationManager locationManager) {
        this.f617a = 4;
        this.f620d = new Object();
        this.f618b = context;
        this.f619c = locationManager;
    }

    public w(Toolbar toolbar) {
        this.f617a = 1;
        this.f618b = toolbar;
        this.f619c = toolbar.getNavigationIcon();
        this.f620d = toolbar.getNavigationContentDescription();
    }

    public w(y yVar) {
        this.f617a = 18;
        r0.j("provider", yVar);
        this.f618b = new androidx.lifecycle.a0(yVar);
        this.f619c = new Handler();
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public w(i1 i1Var, androidx.lifecycle.g1 g1Var) {
        this(i1Var, g1Var, 0);
        this.f617a = 19;
        r0.j("store", i1Var);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ w(i1 i1Var, androidx.lifecycle.g1 g1Var, int i10) {
        this(i1Var, g1Var, (p2.c) p2.a.f23883b);
        this.f617a = 19;
    }

    public w(i1 i1Var, androidx.lifecycle.g1 g1Var, p2.c cVar) {
        this.f617a = 19;
        r0.j("store", i1Var);
        r0.j("factory", g1Var);
        r0.j("defaultCreationExtras", cVar);
        this.f618b = i1Var;
        this.f619c = g1Var;
        this.f620d = cVar;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public w(j1 j1Var, w0 w0Var) {
        this(j1Var.getViewModelStore(), (androidx.lifecycle.g1) w0Var, j1Var instanceof androidx.lifecycle.l ? ((androidx.lifecycle.l) j1Var).getDefaultViewModelCreationExtras() : p2.a.f23883b);
        this.f617a = 19;
        r0.j("owner", j1Var);
    }

    public w(androidx.viewpager2.adapter.i iVar, androidx.fragment.app.a0 a0Var, FrameLayout frameLayout) {
        this.f617a = 20;
        this.f620d = iVar;
        this.f618b = a0Var;
        this.f619c = frameLayout;
    }

    public /* synthetic */ w(Object obj, Object obj2, Object obj3, int i10) {
        this.f617a = i10;
        this.f620d = obj;
        this.f618b = obj2;
        this.f619c = obj3;
    }

    public /* synthetic */ w(Object obj, Object obj2, Object obj3, int i10, int i11) {
        this.f617a = i10;
        this.f618b = obj;
        this.f619c = obj2;
        this.f620d = obj3;
    }

    public w(String str) {
        this.f617a = 7;
        this.f619c = (w.n) w.k.f28507a.f(w.n.class);
        this.f618b = str;
        this.f620d = new x.b(str, 0);
    }

    public w(ExecutorService executorService) {
        this.f617a = 23;
        this.f619c = new Handler(Looper.getMainLooper());
        this.f620d = new d0.f(1, this);
        this.f618b = new b4.o(executorService);
    }

    public w(u0.g gVar, u0.g gVar2) {
        this.f617a = 15;
        this.f620d = gVar;
        this.f619c = gVar2;
    }

    public w(f fVar) {
        this.f617a = 16;
        this.f618b = new ArrayList();
        this.f619c = new Object();
        this.f620d = fVar;
    }
}
