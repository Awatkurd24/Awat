package a4;

import android.animation.ValueAnimator;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import android.os.Parcel;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import android.view.MenuItem;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.profileinstaller.ProfileInstallReceiver;
import androidx.recyclerview.widget.w0;
import androidx.recyclerview.widget.y0;
import b0.c0;
import b0.d0;
import b0.o;
import b0.v0;
import b0.x0;
import b6.b;
import com.google.android.gms.appset.zza;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import d8.i;
import f0.j;
import h2.k;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import jh.v;
import jh.w;
import ld.i0;
import m.g;
import m.m;
import r1.b0;
import r1.h1;
import r1.l;
import r1.q0;
import r1.r2;
import r1.t2;
import t.h;
import t7.p0;
import t7.s0;
import v5.a;
import v7.s1;
import w8.g0;
import xa.d;
import xa.e;
import y2.c;
import z.t;
import z7.k4;
import z7.n4;
import z7.t4;
import z7.w6;
import z7.x3;
import z7.y3;
import z7.z6;

public final class f implements o, b0, l, k, c, a, b, e7.k, p0, z6, g0, m, d8.a, com.google.gson.internal.l, w0, v {

    /* renamed from: a  reason: collision with root package name */
    public Object f543a;

    public f() {
        this.f543a = new Stack();
    }

    public static f c0(int i10, int i11, int i12) {
        return new f((Object) AccessibilityNodeInfo.CollectionInfo.obtain(i10, i11, false, i12));
    }

    public /* synthetic */ Object A(b0.c cVar, c0 c0Var) {
        return l.o(this, cVar, c0Var);
    }

    public void D(int i10, Object obj) {
        String str;
        switch (i10) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case 2:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case 3:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case 4:
                str = "RESULT_NOT_WRITABLE";
                break;
            case 5:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case 6:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case 7:
                str = "RESULT_IO_EXCEPTION";
                break;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
            default:
                str = "";
                break;
        }
        if (i10 == 6 || i10 == 7 || i10 == 8) {
            Log.e("ProfileInstaller", str, (Throwable) obj);
        } else {
            Log.d("ProfileInstaller", str);
        }
        ((ProfileInstallReceiver) this.f543a).setResultCode(i10);
    }

    public void E(m.o oVar) {
    }

    public /* synthetic */ boolean H(b0.c cVar) {
        return l.a(this, cVar);
    }

    public void I(s1 s1Var) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15, TimeUnit.SECONDS, new LinkedBlockingDeque(), new h2.a("EmojiCompatInitializer"));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new h(this, s1Var, threadPoolExecutor, 8));
    }

    public /* synthetic */ Set J() {
        return l.l(this);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v6, resolved type: s0.k} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v7, resolved type: s0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v8, resolved type: s0.k} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v9, resolved type: s0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: s0.a} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void N(s0.a r9) {
        /*
            r8 = this;
            java.util.Set r0 = r9.keySet()
            s0.h r0 = (s0.h) r0
            boolean r1 = r0.isEmpty()
            if (r1 == 0) goto L_0x000d
            return
        L_0x000d:
            int r1 = r9.f25752c
            r2 = 999(0x3e7, float:1.4E-42)
            r3 = 0
            if (r1 <= r2) goto L_0x0043
            s0.a r0 = new s0.a
            r0.<init>((int) r2)
            int r1 = r9.f25752c
            r4 = 0
        L_0x001c:
            r5 = 0
        L_0x001d:
            if (r4 >= r1) goto L_0x003d
            java.lang.Object r6 = r9.i(r4)
            java.lang.String r6 = (java.lang.String) r6
            java.lang.Object r7 = r9.k(r4)
            java.util.ArrayList r7 = (java.util.ArrayList) r7
            r0.put(r6, r7)
            int r4 = r4 + 1
            int r5 = r5 + 1
            if (r5 != r2) goto L_0x001d
            r8.N(r0)
            s0.a r0 = new s0.a
            r0.<init>((int) r2)
            goto L_0x001c
        L_0x003d:
            if (r5 <= 0) goto L_0x0042
            r8.N(r0)
        L_0x0042:
            return
        L_0x0043:
            java.lang.String r1 = "SELECT `progress`,`work_spec_id` FROM `WorkProgress` WHERE `work_spec_id` IN ("
            java.lang.StringBuilder r1 = f.c.o(r1)
            int r2 = r0.size()
            u7.y.a(r2, r1)
            java.lang.String r4 = ")"
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            a3.a0 r1 = a3.a0.p(r2, r1)
            java.util.Iterator r0 = r0.iterator()
            r2 = 1
        L_0x0062:
            boolean r4 = r0.hasNext()
            if (r4 == 0) goto L_0x007a
            java.lang.Object r4 = r0.next()
            java.lang.String r4 = (java.lang.String) r4
            if (r4 != 0) goto L_0x0074
            r1.t(r2)
            goto L_0x0077
        L_0x0074:
            r1.m(r2, r4)
        L_0x0077:
            int r2 = r2 + 1
            goto L_0x0062
        L_0x007a:
            java.lang.Object r0 = r8.f543a
            a3.x r0 = (a3.x) r0
            android.database.Cursor r0 = ne.c0.i(r0, r1, r3)
            java.lang.String r1 = "work_spec_id"
            int r1 = he.j.b(r0, r1)     // Catch:{ all -> 0x00b5 }
            r2 = -1
            if (r1 != r2) goto L_0x008f
            r0.close()
            return
        L_0x008f:
            boolean r2 = r0.moveToNext()     // Catch:{ all -> 0x00b5 }
            if (r2 == 0) goto L_0x00b7
            java.lang.String r2 = r0.getString(r1)     // Catch:{ all -> 0x00b5 }
            r4 = 0
            java.lang.Object r2 = r9.getOrDefault(r2, r4)     // Catch:{ all -> 0x00b5 }
            java.util.ArrayList r2 = (java.util.ArrayList) r2     // Catch:{ all -> 0x00b5 }
            if (r2 == 0) goto L_0x008f
            boolean r5 = r0.isNull(r3)     // Catch:{ all -> 0x00b5 }
            if (r5 == 0) goto L_0x00a9
            goto L_0x00ad
        L_0x00a9:
            byte[] r4 = r0.getBlob(r3)     // Catch:{ all -> 0x00b5 }
        L_0x00ad:
            r3.j r4 = r3.j.a(r4)     // Catch:{ all -> 0x00b5 }
            r2.add(r4)     // Catch:{ all -> 0x00b5 }
            goto L_0x008f
        L_0x00b5:
            r9 = move-exception
            goto L_0x00bb
        L_0x00b7:
            r0.close()
            return
        L_0x00bb:
            r0.close()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.f.N(s0.a):void");
    }

    public ValueAnimator O() {
        return (ValueAnimator) this.f543a;
    }

    public /* synthetic */ c0 T(b0.c cVar) {
        return l.f(this, cVar);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v6, resolved type: s0.k} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v7, resolved type: s0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v8, resolved type: s0.k} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v9, resolved type: s0.a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: s0.a} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void W(s0.a r9) {
        /*
            r8 = this;
            java.util.Set r0 = r9.keySet()
            s0.h r0 = (s0.h) r0
            boolean r1 = r0.isEmpty()
            if (r1 == 0) goto L_0x000d
            return
        L_0x000d:
            int r1 = r9.f25752c
            r2 = 999(0x3e7, float:1.4E-42)
            r3 = 0
            if (r1 <= r2) goto L_0x0043
            s0.a r0 = new s0.a
            r0.<init>((int) r2)
            int r1 = r9.f25752c
            r4 = 0
        L_0x001c:
            r5 = 0
        L_0x001d:
            if (r4 >= r1) goto L_0x003d
            java.lang.Object r6 = r9.i(r4)
            java.lang.String r6 = (java.lang.String) r6
            java.lang.Object r7 = r9.k(r4)
            java.util.ArrayList r7 = (java.util.ArrayList) r7
            r0.put(r6, r7)
            int r4 = r4 + 1
            int r5 = r5 + 1
            if (r5 != r2) goto L_0x001d
            r8.W(r0)
            s0.a r0 = new s0.a
            r0.<init>((int) r2)
            goto L_0x001c
        L_0x003d:
            if (r5 <= 0) goto L_0x0042
            r8.W(r0)
        L_0x0042:
            return
        L_0x0043:
            java.lang.String r1 = "SELECT `tag`,`work_spec_id` FROM `WorkTag` WHERE `work_spec_id` IN ("
            java.lang.StringBuilder r1 = f.c.o(r1)
            int r2 = r0.size()
            u7.y.a(r2, r1)
            java.lang.String r4 = ")"
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            a3.a0 r1 = a3.a0.p(r2, r1)
            java.util.Iterator r0 = r0.iterator()
            r2 = 1
        L_0x0062:
            boolean r4 = r0.hasNext()
            if (r4 == 0) goto L_0x007a
            java.lang.Object r4 = r0.next()
            java.lang.String r4 = (java.lang.String) r4
            if (r4 != 0) goto L_0x0074
            r1.t(r2)
            goto L_0x0077
        L_0x0074:
            r1.m(r2, r4)
        L_0x0077:
            int r2 = r2 + 1
            goto L_0x0062
        L_0x007a:
            java.lang.Object r0 = r8.f543a
            a3.x r0 = (a3.x) r0
            android.database.Cursor r0 = ne.c0.i(r0, r1, r3)
            java.lang.String r1 = "work_spec_id"
            int r1 = he.j.b(r0, r1)     // Catch:{ all -> 0x00b1 }
            r2 = -1
            if (r1 != r2) goto L_0x008f
            r0.close()
            return
        L_0x008f:
            boolean r2 = r0.moveToNext()     // Catch:{ all -> 0x00b1 }
            if (r2 == 0) goto L_0x00b3
            java.lang.String r2 = r0.getString(r1)     // Catch:{ all -> 0x00b1 }
            r4 = 0
            java.lang.Object r2 = r9.getOrDefault(r2, r4)     // Catch:{ all -> 0x00b1 }
            java.util.ArrayList r2 = (java.util.ArrayList) r2     // Catch:{ all -> 0x00b1 }
            if (r2 == 0) goto L_0x008f
            boolean r5 = r0.isNull(r3)     // Catch:{ all -> 0x00b1 }
            if (r5 == 0) goto L_0x00a9
            goto L_0x00ad
        L_0x00a9:
            java.lang.String r4 = r0.getString(r3)     // Catch:{ all -> 0x00b1 }
        L_0x00ad:
            r2.add(r4)     // Catch:{ all -> 0x00b1 }
            goto L_0x008f
        L_0x00b1:
            r9 = move-exception
            goto L_0x00b7
        L_0x00b3:
            r0.close()
            return
        L_0x00b7:
            r0.close()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.f.W(s0.a):void");
    }

    public void X(vf.f fVar) {
        if (fVar.w()) {
            int size = fVar.size();
            int[] iArr = vf.b0.f28377h;
            int binarySearch = Arrays.binarySearch(iArr, size);
            if (binarySearch < 0) {
                binarySearch = (-(binarySearch + 1)) - 1;
            }
            int i10 = iArr[binarySearch + 1];
            Stack stack = (Stack) this.f543a;
            if (stack.isEmpty() || ((vf.f) stack.peek()).size() >= i10) {
                stack.push(fVar);
                return;
            }
            int i11 = iArr[binarySearch];
            vf.f fVar2 = (vf.f) stack.pop();
            while (!stack.isEmpty() && ((vf.f) stack.peek()).size() < i11) {
                fVar2 = new vf.b0((vf.f) stack.pop(), fVar2);
            }
            vf.b0 b0Var = new vf.b0(fVar2, fVar);
            while (!stack.isEmpty()) {
                int[] iArr2 = vf.b0.f28377h;
                int binarySearch2 = Arrays.binarySearch(iArr2, b0Var.f28378b);
                if (binarySearch2 < 0) {
                    binarySearch2 = (-(binarySearch2 + 1)) - 1;
                }
                if (((vf.f) stack.peek()).size() >= iArr2[binarySearch2 + 1]) {
                    break;
                }
                b0Var = new vf.b0((vf.f) stack.pop(), b0Var);
            }
            stack.push(b0Var);
        } else if (fVar instanceof vf.b0) {
            vf.b0 b0Var2 = (vf.b0) fVar;
            X(b0Var2.f28379c);
            X(b0Var2.f28380d);
        } else {
            String valueOf = String.valueOf(fVar.getClass());
            throw new IllegalArgumentException(l.J(new StringBuilder(valueOf.length() + 49), "Has a new type of ByteString been created? Found ", valueOf));
        }
    }

    public Object Y() {
        Object obj = this.f543a;
        if (((Type) obj) instanceof ParameterizedType) {
            Type type = ((ParameterizedType) ((Type) obj)).getActualTypeArguments()[0];
            if (type instanceof Class) {
                return new EnumMap((Class) type);
            }
            throw new RuntimeException("Invalid EnumMap type: " + ((Type) this.f543a).toString());
        }
        throw new RuntimeException("Invalid EnumMap type: " + ((Type) this.f543a).toString());
    }

    public Object a() {
        return new ContextWrapper((Application) ((s0) this.f543a).a());
    }

    public String a0(Object obj) {
        StringWriter stringWriter = new StringWriter();
        try {
            b0(obj, stringWriter);
        } catch (IOException unused) {
        }
        return stringWriter.toString();
    }

    public void b(String str, String str2, Bundle bundle) {
        if (TextUtils.isEmpty(str)) {
            t4 t4Var = ((w6) this.f543a).f31328l;
            if (t4Var != null) {
                x3 x3Var = t4Var.f31254i;
                t4.f(x3Var);
                x3Var.f31350f.d("AppId not known when logging event", str2);
                return;
            }
            return;
        }
        ((w6) this.f543a).m().G(new g(this, str, str2, bundle, 17));
    }

    public void b0(Object obj, Writer writer) {
        d dVar = (d) this.f543a;
        e eVar = new e(writer, dVar.f29794a, dVar.f29795b, dVar.f29796c, dVar.f29797d);
        eVar.h(obj);
        eVar.j();
        eVar.f29799b.flush();
    }

    public /* synthetic */ void c(ib.g gVar) {
        l.b(this, gVar);
    }

    public w create(jh.k kVar) {
        return (w) this.f543a;
    }

    public void d0(int i10, String str, List list, boolean z4, boolean z10) {
        y3 y3Var;
        int[] iArr = n4.f31074a;
        if (i10 != 0) {
            int i11 = iArr[i10 - 1];
            if (i11 == 1) {
                y3Var = ((k4) this.f543a).h().f31357m;
            } else if (i11 == 2) {
                x3 h10 = ((k4) this.f543a).h();
                y3Var = z4 ? h10.f31351g : !z10 ? h10.f31352h : h10.f31350f;
            } else if (i11 != 3) {
                y3Var = i11 != 4 ? ((k4) this.f543a).h().f31356l : ((k4) this.f543a).h().f31358n;
            } else {
                x3 h11 = ((k4) this.f543a).h();
                y3Var = z4 ? h11.f31354j : !z10 ? h11.f31355k : h11.f31353i;
            }
            int size = list.size();
            if (size == 1) {
                y3Var.d(str, list.get(0));
            } else if (size == 2) {
                y3Var.b(list.get(0), list.get(1), str);
            } else if (size != 3) {
                y3Var.c(str);
            } else {
                y3Var.e(str, list.get(0), list.get(1), list.get(2));
            }
        } else {
            throw null;
        }
    }

    public t2 f(View view, t2 t2Var, y0 y0Var) {
        int i10;
        y0Var.f3018d = t2Var.a() + y0Var.f3018d;
        WeakHashMap weakHashMap = h1.f25195a;
        boolean z4 = true;
        if (q0.d(view) != 1) {
            z4 = false;
        }
        int b5 = t2Var.b();
        int c10 = t2Var.c();
        int i11 = y0Var.f3015a;
        if (z4) {
            i10 = c10;
        } else {
            i10 = b5;
        }
        int i12 = i11 + i10;
        y0Var.f3015a = i12;
        int i13 = y0Var.f3017c;
        if (!z4) {
            b5 = c10;
        }
        int i14 = i13 + b5;
        y0Var.f3017c = i14;
        q0.k(view, i12, y0Var.f3016b, i14, y0Var.f3018d);
        return t2Var;
    }

    public Object get() {
        String packageName = ((Context) ((vd.a) this.f543a).get()).getPackageName();
        if (packageName != null) {
            return packageName;
        }
        throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
    }

    public void i(f7.g gVar, Object obj) {
        p7.d dVar = (p7.d) ((p7.b) gVar).p();
        zza zza = new zza((String) null, (String) null);
        p7.h hVar = new p7.h((i) obj);
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken("com.google.android.gms.appset.internal.IAppSetService");
        int i10 = p7.a.f24038a;
        obtain.writeInt(1);
        zza.writeToParcel(obtain, 0);
        obtain.writeStrongBinder(hVar);
        Parcel obtain2 = Parcel.obtain();
        try {
            dVar.f24039a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain.recycle();
            obtain2.recycle();
        }
    }

    public boolean k(m.o oVar, MenuItem menuItem) {
        int i10 = com.google.android.material.navigation.d.f16683e;
        ((com.google.android.material.navigation.d) this.f543a).getClass();
        ((com.google.android.material.navigation.d) this.f543a).getClass();
        return false;
    }

    public /* bridge */ /* synthetic */ Object l(d8.h hVar) {
        return null;
    }

    public /* synthetic */ Object m(b0.c cVar, Object obj) {
        return l.n(this, cVar, obj);
    }

    public t2 o(View view, t2 t2Var) {
        boolean z4;
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) this.f543a;
        if (!q1.b.a(coordinatorLayout.f1844n, t2Var)) {
            coordinatorLayout.f1844n = t2Var;
            boolean z10 = true;
            if (t2Var.d() > 0) {
                z4 = true;
            } else {
                z4 = false;
            }
            coordinatorLayout.f1845o = z4;
            if (z4 || coordinatorLayout.getBackground() != null) {
                z10 = false;
            }
            coordinatorLayout.setWillNotDraw(z10);
            r2 r2Var = t2Var.f25277a;
            if (!r2Var.m()) {
                int childCount = coordinatorLayout.getChildCount();
                for (int i10 = 0; i10 < childCount; i10++) {
                    View childAt = coordinatorLayout.getChildAt(i10);
                    WeakHashMap weakHashMap = h1.f25195a;
                    if (r1.p0.b(childAt) && ((e1.e) childAt.getLayoutParams()).f17892a != null && r2Var.m()) {
                        break;
                    }
                }
            }
            coordinatorLayout.requestLayout();
        }
        return t2Var;
    }

    public /* synthetic */ Set p(b0.c cVar) {
        return l.g(this, cVar);
    }

    public /* synthetic */ Object r(b0.c cVar) {
        return l.m(this, cVar);
    }

    public void x() {
        Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    public d0 z() {
        return x0.f3474c;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(int i10) {
        this((Object) (w.m) w.k.f28507a.f(w.m.class));
        Object obj;
        if (i10 == 5) {
        } else if (i10 == 6) {
            v0 b5 = v0.b();
            this.f543a = b5;
            Object obj2 = null;
            try {
                obj = b5.r(j.K0);
            } catch (IllegalArgumentException unused) {
                obj = null;
            }
            Class cls = (Class) obj;
            Class<t> cls2 = t.class;
            if (cls == null || cls.equals(cls2)) {
                ((v0) this.f543a).k(j.K0, cls2);
                v0 v0Var = (v0) this.f543a;
                b0.c cVar = j.J0;
                v0Var.getClass();
                try {
                    obj2 = v0Var.r(cVar);
                } catch (IllegalArgumentException unused2) {
                }
                if (obj2 == null) {
                    ((v0) this.f543a).k(j.J0, cls2.getCanonicalName() + "-" + UUID.randomUUID());
                    return;
                }
                return;
            }
            throw new IllegalArgumentException("Invalid target class configuration for " + this + ": " + cls);
        } else if (i10 != 7) {
            this.f543a = new ArrayDeque();
        } else {
            this.f543a = new b0.d(new Object());
        }
    }

    public /* synthetic */ f(Context context, int i10) {
        if (i10 != 27) {
            this.f543a = context.getApplicationContext();
            return;
        }
        StringBuilder sb2 = i0.f21962a;
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        this.f543a = new LruCache((int) ((((long) ((context.getApplicationInfo().flags & 1048576) != 0 ? activityManager.getLargeMemoryClass() : activityManager.getMemoryClass())) * 1048576) / 7));
    }

    public /* synthetic */ f(Object obj) {
        this.f543a = obj;
    }
}
