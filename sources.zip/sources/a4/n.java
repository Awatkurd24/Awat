package a4;

import r3.j;
import v7.r0;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public final String f560a;

    /* renamed from: b  reason: collision with root package name */
    public final j f561b;

    public n(String str, j jVar) {
        r0.j("workSpecId", str);
        r0.j("progress", jVar);
        this.f560a = str;
        this.f561b = jVar;
    }
}
