package a4;

import java.util.ArrayList;
import java.util.List;
import r3.f0;
import r3.j;
import v7.r0;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public final String f569a;

    /* renamed from: b  reason: collision with root package name */
    public final f0 f570b;

    /* renamed from: c  reason: collision with root package name */
    public final j f571c;

    /* renamed from: d  reason: collision with root package name */
    public final int f572d;

    /* renamed from: e  reason: collision with root package name */
    public final int f573e;

    /* renamed from: f  reason: collision with root package name */
    public final List f574f;

    /* renamed from: g  reason: collision with root package name */
    public final List f575g;

    public r(String str, f0 f0Var, j jVar, int i10, int i11, ArrayList arrayList, ArrayList arrayList2) {
        r0.j("id", str);
        r0.j("state", f0Var);
        r0.j("output", jVar);
        this.f569a = str;
        this.f570b = f0Var;
        this.f571c = jVar;
        this.f572d = i10;
        this.f573e = i11;
        this.f574f = arrayList;
        this.f575g = arrayList2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r)) {
            return false;
        }
        r rVar = (r) obj;
        return r0.b(this.f569a, rVar.f569a) && this.f570b == rVar.f570b && r0.b(this.f571c, rVar.f571c) && this.f572d == rVar.f572d && this.f573e == rVar.f573e && r0.b(this.f574f, rVar.f574f) && r0.b(this.f575g, rVar.f575g);
    }

    public final int hashCode() {
        int hashCode = this.f570b.hashCode();
        int hashCode2 = this.f571c.hashCode();
        int hashCode3 = this.f574f.hashCode();
        return this.f575g.hashCode() + ((hashCode3 + ((((((hashCode2 + ((hashCode + (this.f569a.hashCode() * 31)) * 31)) * 31) + this.f572d) * 31) + this.f573e) * 31)) * 31);
    }

    public final String toString() {
        return "WorkInfoPojo(id=" + this.f569a + ", state=" + this.f570b + ", output=" + this.f571c + ", runAttemptCount=" + this.f572d + ", generation=" + this.f573e + ", tags=" + this.f574f + ", progress=" + this.f575g + ')';
    }
}
