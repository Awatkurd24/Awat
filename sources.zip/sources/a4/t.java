package a4;

import a3.x;
import com.v2ray.ang.dto.V2rayConfig;
import f3.i;
import m.d;
import r3.f;
import r3.j;
import v7.r0;

public final class t extends d {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ int f598d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public t(x xVar) {
        super(xVar);
        this.f598d = 4;
        r0.j("database", xVar);
    }

    public final void L(i iVar, Object obj) {
        s sVar = (s) obj;
        String str = sVar.f578a;
        if (str == null) {
            iVar.t(1);
        } else {
            iVar.m(1, str);
        }
        iVar.D(2, (long) gc.d.j(sVar.f579b));
        String str2 = sVar.f580c;
        if (str2 == null) {
            iVar.t(3);
        } else {
            iVar.m(3, str2);
        }
        String str3 = sVar.f581d;
        if (str3 == null) {
            iVar.t(4);
        } else {
            iVar.m(4, str3);
        }
        byte[] c10 = j.c(sVar.f582e);
        if (c10 == null) {
            iVar.t(5);
        } else {
            iVar.G(5, c10);
        }
        byte[] c11 = j.c(sVar.f583f);
        if (c11 == null) {
            iVar.t(6);
        } else {
            iVar.G(6, c11);
        }
        iVar.D(7, sVar.f584g);
        iVar.D(8, sVar.f585h);
        iVar.D(9, sVar.f586i);
        iVar.D(10, (long) sVar.f588k);
        iVar.D(11, (long) gc.d.a(sVar.f589l));
        iVar.D(12, sVar.f590m);
        iVar.D(13, sVar.f591n);
        iVar.D(14, sVar.f592o);
        iVar.D(15, sVar.f593p);
        iVar.D(16, sVar.f594q ? 1 : 0);
        iVar.D(17, (long) gc.d.h(sVar.f595r));
        iVar.D(18, (long) sVar.f596s);
        iVar.D(19, (long) sVar.f597t);
        f fVar = sVar.f587j;
        if (fVar != null) {
            iVar.D(20, (long) gc.d.g(fVar.f25332a));
            iVar.D(21, fVar.f25333b ? 1 : 0);
            iVar.D(22, fVar.f25334c ? 1 : 0);
            iVar.D(23, fVar.f25335d ? 1 : 0);
            iVar.D(24, fVar.f25336e ? 1 : 0);
            iVar.D(25, fVar.f25337f);
            iVar.D(26, fVar.f25338g);
            iVar.G(27, gc.d.i(fVar.f25339h));
        } else {
            iVar.t(20);
            iVar.t(21);
            iVar.t(22);
            iVar.t(23);
            iVar.t(24);
            iVar.t(25);
            iVar.t(26);
            iVar.t(27);
        }
        if (str == null) {
            iVar.t(28);
        } else {
            iVar.m(28, str);
        }
    }

    public final String p() {
        switch (this.f598d) {
            case 0:
                return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
            case 1:
                return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
            case 2:
                return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
            case 3:
                return "UPDATE workspec SET generation=generation+1 WHERE id=?";
            case 4:
                return "UPDATE OR ABORT `WorkSpec` SET `id` = ?,`state` = ?,`worker_class_name` = ?,`input_merger_class_name` = ?,`input` = ?,`output` = ?,`initial_delay` = ?,`interval_duration` = ?,`flex_duration` = ?,`run_attempt_count` = ?,`backoff_policy` = ?,`backoff_delay_duration` = ?,`last_enqueue_time` = ?,`minimum_retention_duration` = ?,`schedule_requested_at` = ?,`run_in_foreground` = ?,`out_of_quota_policy` = ?,`period_count` = ?,`generation` = ?,`required_network_type` = ?,`requires_charging` = ?,`requires_device_idle` = ?,`requires_battery_not_low` = ?,`requires_storage_not_low` = ?,`trigger_content_update_delay` = ?,`trigger_max_content_delay` = ?,`content_uri_triggers` = ? WHERE `id` = ?";
            case 5:
                return "DELETE FROM workspec WHERE id=?";
            case 6:
                return "UPDATE workspec SET state=? WHERE id=?";
            case 7:
                return "UPDATE workspec SET period_count=period_count+1 WHERE id=?";
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return "UPDATE workspec SET output=? WHERE id=?";
            case 9:
                return "UPDATE workspec SET last_enqueue_time=? WHERE id=?";
            case 10:
                return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
            default:
                return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(x xVar, int i10) {
        super(xVar);
        this.f598d = i10;
    }
}
