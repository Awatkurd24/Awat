package a4;

import v7.r0;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final String f544a;

    /* renamed from: b  reason: collision with root package name */
    public final int f545b;

    /* renamed from: c  reason: collision with root package name */
    public final int f546c;

    public g(String str, int i10, int i11) {
        r0.j("workSpecId", str);
        this.f544a = str;
        this.f545b = i10;
        this.f546c = i11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return r0.b(this.f544a, gVar.f544a) && this.f545b == gVar.f545b && this.f546c == gVar.f546c;
    }

    public final int hashCode() {
        return (((this.f544a.hashCode() * 31) + this.f545b) * 31) + this.f546c;
    }

    public final String toString() {
        return "SystemIdInfo(workSpecId=" + this.f544a + ", generation=" + this.f545b + ", systemId=" + this.f546c + ')';
    }
}
