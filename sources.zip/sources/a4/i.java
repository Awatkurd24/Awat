package a4;

import a2.h;
import a3.x;
import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.util.Size;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.widget.d;
import b0.u;
import b6.b;
import cf.d0;
import com.google.android.gms.internal.ads.f7;
import com.google.android.gms.internal.measurement.c4;
import com.google.android.gms.internal.measurement.f4;
import com.google.android.gms.internal.measurement.g;
import com.google.android.gms.internal.measurement.gb;
import com.google.android.gms.internal.measurement.m1;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import e0.f;
import e6.k;
import e6.l;
import g6.c;
import h.n0;
import j0.e;
import j0.p;
import j0.q;
import j0.r;
import j0.t;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import l.a;
import lg.g0;
import lg.o1;
import m.f0;
import m.o;
import m.w;
import na.w0;
import na.x1;
import ng.m;
import t.k2;
import t0.j;
import te.n;
import u.s;
import v7.je;
import v7.r0;
import w7.ua;
import yg.z;

public final class i implements a, k2, b {

    /* renamed from: a  reason: collision with root package name */
    public Object f549a;

    /* renamed from: b  reason: collision with root package name */
    public Object f550b;

    /* renamed from: c  reason: collision with root package name */
    public Object f551c;

    /* renamed from: d  reason: collision with root package name */
    public Object f552d;

    public i(int i10) {
        if (i10 == 10) {
            this.f549a = new ArrayList();
            this.f550b = null;
            this.f551c = null;
            this.f552d = new d(7, this);
        } else if (i10 != 12) {
            wb.a aVar = new wb.a(13);
            this.f549a = aVar;
            p pVar = new p((p) null, aVar);
            this.f551c = pVar;
            this.f550b = pVar.g();
            yb.b bVar = new yb.b(16);
            this.f552d = bVar;
            ((p) this.f551c).m("require", new gb(bVar));
            ((Map) ((yb.b) this.f552d).f30180b).put("internal.platform", m1.f15096a);
            ((p) this.f551c).m("runtime.counter", new g(Double.valueOf(0.0d)));
        }
    }

    public final void a(TotalCaptureResult totalCaptureResult) {
        if (((j) this.f551c) != null) {
            CaptureRequest request = totalCaptureResult.getRequest();
            Rect rect = request == null ? null : (Rect) request.get(CaptureRequest.SCALER_CROP_REGION);
            Object obj = this.f552d;
            if (((Rect) obj) != null && ((Rect) obj).equals(rect)) {
                ((j) this.f551c).a((Object) null);
                this.f551c = null;
                this.f552d = null;
            }
        }
    }

    public final boolean b(l.b bVar, o oVar) {
        return ((ActionMode.Callback) this.f549a).onPrepareActionMode(n(bVar), o(oVar));
    }

    public final boolean c(l.b bVar, MenuItem menuItem) {
        return ((ActionMode.Callback) this.f549a).onActionItemClicked(n(bVar), new w((Context) this.f550b, (l1.b) menuItem));
    }

    public final void d(n0 n0Var) {
        Rect rect = (Rect) this.f550b;
        if (rect != null) {
            n0Var.E(CaptureRequest.SCALER_CROP_REGION, rect);
        }
    }

    public final float e() {
        Float f10 = (Float) ((s) this.f549a).a(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        if (f10 != null && f10.floatValue() >= 1.0f) {
            return f10.floatValue();
        }
        return 1.0f;
    }

    public final boolean f(l.b bVar, o oVar) {
        return ((ActionMode.Callback) this.f549a).onCreateActionMode(n(bVar), o(oVar));
    }

    public final void g(l.b bVar) {
        ((ActionMode.Callback) this.f549a).onDestroyActionMode(n(bVar));
    }

    public final Object get() {
        return new k((Executor) ((vd.a) this.f549a).get(), (f6.d) ((vd.a) this.f550b).get(), (l) ((vd.a) this.f551c).get(), (c) ((vd.a) this.f552d).get());
    }

    public final float h() {
        return 1.0f;
    }

    public final void i() {
        this.f552d = null;
        this.f550b = null;
        Object obj = this.f551c;
        if (((j) obj) != null) {
            ((j) obj).b(new Exception("Camera is not active."));
            this.f551c = null;
        }
    }

    public final void j(int[] iArr, ValueAnimator valueAnimator) {
        h hVar = new h(iArr, valueAnimator);
        valueAnimator.addListener((Animator.AnimatorListener) this.f552d);
        ((ArrayList) this.f549a).add(hVar);
    }

    public final w0 k() {
        String str;
        if (((x1) this.f549a) == null) {
            str = " rolloutVariant";
        } else {
            str = "";
        }
        if (((String) this.f550b) == null) {
            str = str.concat(" parameterKey");
        }
        if (((String) this.f551c) == null) {
            str = l.H(str, " parameterValue");
        }
        if (((Long) this.f552d) == null) {
            str = l.H(str, " templateVersion");
        }
        if (str.isEmpty()) {
            return new w0((x1) this.f549a, (String) this.f550b, (String) this.f551c, ((Long) this.f552d).longValue());
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v20, resolved type: xe.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v21, resolved type: xe.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v13, resolved type: xe.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v31, resolved type: xe.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v7, resolved type: java.util.ArrayList} */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x013d, code lost:
        if (r4 != lg.t1.f22119e) goto L_0x0159;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0203, code lost:
        if ((!r0.isEmpty()) != false) goto L_0x0208;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x0286  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x01b6 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0212  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final lg.g0 l(lf.i r20, jf.a r21, lg.g0 r22) {
        /*
            r19 = this;
            r6 = r19
            r0 = r20
            r7 = r21
            r1 = r22
            r2 = 0
            if (r1 == 0) goto L_0x0014
            lg.t0 r3 = r22.J0()
            if (r3 != 0) goto L_0x0012
            goto L_0x0014
        L_0x0012:
            r8 = r3
            goto L_0x0022
        L_0x0014:
            hf.d r3 = new hf.d
            java.lang.Object r4 = r6.f549a
            q.f r4 = (q.f) r4
            r3.<init>(r4, r0, r2)
            lg.t0 r3 = v7.g9.m(r3)
            goto L_0x0012
        L_0x0022:
            r9 = r0
            cf.s r9 = (cf.s) r9
            cf.u r0 = r9.f4181b
            java.lang.String r3 = "Type not found: "
            if (r0 == 0) goto L_0x0426
            boolean r4 = r0 instanceof lf.g
            java.lang.Class<java.lang.Object> r5 = java.lang.Object.class
            java.lang.String r10 = "getUpperBounds(...)"
            lg.o1 r13 = r7.f20907a
            jf.b r14 = r7.f20908b
            boolean r15 = r7.f20910d
            java.lang.String r12 = "getParameters(...)"
            if (r4 == 0) goto L_0x019c
            lf.g r0 = (lf.g) r0
            r4 = r0
            cf.q r4 = (cf.q) r4
            uf.c r4 = r4.b()
            if (r15 == 0) goto L_0x00ab
            uf.c r11 = jf.d.f20922a
            boolean r11 = v7.r0.b(r4, r11)
            if (r11 == 0) goto L_0x00ab
            java.lang.Object r4 = r6.f549a
            q.f r4 = (q.f) r4
            java.lang.Object r4 = r4.f24801b
            hf.a r4 = (hf.a) r4
            te.o r4 = r4.f19708p
            r4.getClass()
            ne.s[] r11 = te.o.f26786e
            r11 = r11[r2]
            n7.k r2 = r4.f26789c
            r2.getClass()
            r16 = r8
            java.lang.String r8 = "property"
            v7.r0.j(r8, r11)
            java.lang.String r8 = r11.getName()
            java.lang.String r8 = v7.f9.b(r8)
            int r2 = r2.f22934b
            uf.f r8 = uf.f.e(r8)
            wd.d r11 = r4.f26788b
            java.lang.Object r11 = r11.getValue()
            eg.n r11 = (eg.n) r11
            df.d r7 = df.d.f17789b
            we.i r7 = r11.b(r8, r7)
            boolean r11 = r7 instanceof we.f
            if (r11 == 0) goto L_0x008e
            we.f r7 = (we.f) r7
            goto L_0x008f
        L_0x008e:
            r7 = 0
        L_0x008f:
            if (r7 != 0) goto L_0x00a8
            uf.b r7 = new uf.b
            uf.c r11 = te.q.f26827i
            r7.<init>(r11, r8)
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            java.util.List r2 = v7.i9.A(r2)
            a4.p r4 = r4.f26787a
            we.f r2 = r4.e(r7, r2)
            goto L_0x015d
        L_0x00a8:
            r2 = r7
            goto L_0x015d
        L_0x00ab:
            r16 = r8
            ve.e r2 = ve.e.f28321a
            java.lang.Object r7 = r6.f549a
            q.f r7 = (q.f) r7
            we.b0 r7 = r7.m()
            te.l r7 = r7.n()
            we.f r2 = ve.e.c(r2, r4, r7)
            if (r2 != 0) goto L_0x00c4
            r2 = 0
            goto L_0x015d
        L_0x00c4:
            java.lang.String r4 = ve.d.f28307a
            uf.e r4 = xf.e.g(r2)
            java.util.HashMap r7 = ve.d.f28317k
            boolean r4 = r7.containsKey(r4)
            if (r4 == 0) goto L_0x015d
            jf.b r4 = jf.b.f20915c
            if (r14 == r4) goto L_0x0159
            lg.o1 r4 = lg.o1.f22098a
            if (r13 == r4) goto L_0x0159
            java.util.ArrayList r4 = r9.b()
            java.lang.Object r4 = xd.o.m0(r4)
            lf.o r4 = (lf.o) r4
            boolean r8 = r4 instanceof lf.q
            if (r8 == 0) goto L_0x00eb
            lf.q r4 = (lf.q) r4
            goto L_0x00ec
        L_0x00eb:
            r4 = 0
        L_0x00ec:
            if (r4 == 0) goto L_0x015d
            cf.g0 r4 = (cf.g0) r4
            cf.d0 r8 = r4.b()
            if (r8 == 0) goto L_0x015d
            java.lang.reflect.WildcardType r4 = r4.f4165a
            java.lang.reflect.Type[] r4 = r4.getUpperBounds()
            v7.r0.i(r10, r4)
            java.lang.Object r4 = xd.k.K2(r4)
            boolean r4 = v7.r0.b(r4, r5)
            r8 = 1
            r4 = r4 ^ r8
            if (r4 != 0) goto L_0x015d
            uf.e r4 = xf.e.g(r2)
            java.lang.String r8 = ve.d.f28307a
            java.lang.Object r4 = r7.get(r4)
            uf.c r4 = (uf.c) r4
            if (r4 == 0) goto L_0x0140
            te.l r7 = bg.d.e(r2)
            we.f r4 = r7.i(r4)
            lg.a1 r4 = r4.h()
            java.util.List r4 = r4.r()
            v7.r0.i(r12, r4)
            java.lang.Object r4 = xd.o.m0(r4)
            we.a1 r4 = (we.a1) r4
            if (r4 == 0) goto L_0x015d
            lg.t1 r4 = r4.d0()
            if (r4 != 0) goto L_0x013b
            goto L_0x015d
        L_0x013b:
            lg.t1 r7 = lg.t1.OUT_VARIANCE
            if (r4 == r7) goto L_0x015d
            goto L_0x0159
        L_0x0140:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "Given class "
            r1.<init>(r3)
            r1.append(r2)
            java.lang.String r2 = " is not a read-only collection"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0159:
            we.f r2 = ve.e.b(r2)
        L_0x015d:
            if (r2 != 0) goto L_0x0179
            java.lang.Object r2 = r6.f549a
            q.f r2 = (q.f) r2
            java.lang.Object r2 = r2.f24801b
            hf.a r2 = (hf.a) r2
            hf.g r2 = r2.f19703k
            a4.e r2 = r2.f19730a
            if (r2 == 0) goto L_0x0172
            we.f r2 = r2.A(r0)
            goto L_0x0179
        L_0x0172:
            java.lang.String r0 = "resolver"
            v7.r0.D(r0)
            r0 = 0
            throw r0
        L_0x0179:
            if (r2 == 0) goto L_0x0183
            lg.a1 r0 = r2.h()
            if (r0 == 0) goto L_0x0183
        L_0x0181:
            r7 = r0
            goto L_0x01b4
        L_0x0183:
            uf.c r0 = new uf.c
            r9.getClass()
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r3)
            java.lang.reflect.Type r2 = r9.f4180a
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x019c:
            r16 = r8
            boolean r2 = r0 instanceof cf.e0
            if (r2 == 0) goto L_0x0412
            java.lang.Object r2 = r6.f550b
            hf.h r2 = (hf.h) r2
            cf.e0 r0 = (cf.e0) r0
            we.a1 r0 = r2.a(r0)
            if (r0 == 0) goto L_0x01b3
            lg.a1 r0 = r0.h()
            goto L_0x0181
        L_0x01b3:
            r7 = 0
        L_0x01b4:
            if (r7 != 0) goto L_0x01b8
            r0 = 0
            return r0
        L_0x01b8:
            jf.b r0 = jf.b.f20915c
            if (r14 != r0) goto L_0x01be
            r8 = 0
            goto L_0x01c8
        L_0x01be:
            if (r15 != 0) goto L_0x01c6
            lg.o1 r0 = lg.o1.f22098a
            if (r13 == r0) goto L_0x01c6
            r0 = 1
            goto L_0x01c7
        L_0x01c6:
            r0 = 0
        L_0x01c7:
            r8 = r0
        L_0x01c8:
            if (r1 == 0) goto L_0x01cf
            lg.a1 r0 = r22.K0()
            goto L_0x01d0
        L_0x01cf:
            r0 = 0
        L_0x01d0:
            boolean r0 = v7.r0.b(r0, r7)
            if (r0 == 0) goto L_0x01e4
            boolean r0 = r9.c()
            if (r0 != 0) goto L_0x01e4
            if (r8 == 0) goto L_0x01e4
            r0 = 1
            lg.g0 r0 = r1.O0(r0)
            return r0
        L_0x01e4:
            boolean r0 = r9.c()
            if (r0 != 0) goto L_0x0208
            java.util.ArrayList r0 = r9.b()
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L_0x0206
            java.util.List r0 = r7.r()
            v7.r0.i(r12, r0)
            java.util.Collection r0 = (java.util.Collection) r0
            boolean r0 = r0.isEmpty()
            r1 = 1
            r0 = r0 ^ r1
            if (r0 == 0) goto L_0x0206
            goto L_0x0208
        L_0x0206:
            r0 = 0
            goto L_0x0209
        L_0x0208:
            r0 = 1
        L_0x0209:
            java.util.List r1 = r7.r()
            v7.r0.i(r12, r1)
            if (r0 == 0) goto L_0x0286
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.ArrayList r10 = new java.util.ArrayList
            int r0 = xd.l.R(r1)
            r10.<init>(r0)
            java.util.Iterator r11 = r1.iterator()
        L_0x0221:
            boolean r0 = r11.hasNext()
            if (r0 == 0) goto L_0x0282
            java.lang.Object r0 = r11.next()
            r12 = r0
            we.a1 r12 = (we.a1) r12
            r13 = r21
            java.util.Set r0 = r13.f20911e
            r1 = 0
            boolean r0 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.R0(r12, r1, r0)
            if (r0 == 0) goto L_0x0240
            lg.l0 r0 = lg.q1.l(r12, r13)
            r22 = r11
            goto L_0x027c
        L_0x0240:
            lg.e0 r14 = new lg.e0
            java.lang.Object r0 = r6.f549a
            q.f r0 = (q.f) r0
            kg.u r15 = r0.o()
            jf.c r5 = new jf.c
            r0 = r5
            r1 = r19
            r2 = r12
            r3 = r21
            r4 = r7
            r22 = r11
            r11 = r5
            r5 = r9
            r0.<init>(r1, r2, r3, r4, r5)
            r14.<init>(r15, r11)
            java.lang.Object r0 = r6.f551c
            r11 = r0
            a2.h r11 = (a2.h) r11
            boolean r2 = r9.c()
            r1 = 0
            r3 = 0
            r4 = 0
            r5 = 59
            r0 = r21
            jf.a r0 = jf.a.f(r0, r1, r2, r3, r4, r5)
            java.lang.Object r1 = r6.f552d
            lg.g1 r1 = (lg.g1) r1
            r11.getClass()
            lg.l0 r0 = a2.h.e(r12, r0, r1, r14)
        L_0x027c:
            r10.add(r0)
            r11 = r22
            goto L_0x0221
        L_0x0282:
            r3 = r16
            goto L_0x040d
        L_0x0286:
            int r0 = r1.size()
            java.util.ArrayList r2 = r9.b()
            int r2 = r2.size()
            if (r0 == r2) goto L_0x02d4
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.ArrayList r0 = new java.util.ArrayList
            int r2 = xd.l.R(r1)
            r0.<init>(r2)
            java.util.Iterator r1 = r1.iterator()
        L_0x02a3:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x02cf
            java.lang.Object r2 = r1.next()
            we.a1 r2 = (we.a1) r2
            lg.l0 r3 = new lg.l0
            ng.l r4 = ng.l.f23483s
            uf.f r2 = r2.getName()
            java.lang.String r2 = r2.b()
            java.lang.String r5 = "asString(...)"
            v7.r0.i(r5, r2)
            java.lang.String[] r2 = new java.lang.String[]{r2}
            ng.j r2 = ng.m.c(r4, r2)
            r3.<init>((lg.b0) r2)
            r0.add(r3)
            goto L_0x02a3
        L_0x02cf:
            java.util.List r10 = xd.o.B0(r0)
            goto L_0x0282
        L_0x02d4:
            java.util.ArrayList r0 = r9.b()
            xd.j r0 = xd.o.G0(r0)
            java.util.ArrayList r2 = new java.util.ArrayList
            int r3 = xd.l.R(r0)
            r2.<init>(r3)
            java.util.Iterator r0 = r0.iterator()
        L_0x02e9:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x0407
            java.lang.Object r3 = r0.next()
            xd.t r3 = (xd.t) r3
            int r4 = r3.f29845a
            java.lang.Object r3 = r3.f29846b
            lf.o r3 = (lf.o) r3
            r1.size()
            java.lang.Object r4 = r1.get(r4)
            we.a1 r4 = (we.a1) r4
            lg.o1 r9 = lg.o1.f22099b
            r11 = 7
            r12 = 0
            r13 = 0
            jf.a r9 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.a2(r9, r12, r12, r13, r11)
            v7.r0.g(r4)
            boolean r12 = r3 instanceof lf.q
            if (r12 == 0) goto L_0x03ed
            lf.q r3 = (lf.q) r3
            r12 = r3
            cf.g0 r12 = (cf.g0) r12
            cf.d0 r13 = r12.b()
            java.lang.reflect.WildcardType r12 = r12.f4165a
            java.lang.reflect.Type[] r12 = r12.getUpperBounds()
            v7.r0.i(r10, r12)
            java.lang.Object r12 = xd.k.K2(r12)
            boolean r12 = v7.r0.b(r12, r5)
            r14 = 1
            r12 = r12 ^ r14
            if (r12 == 0) goto L_0x0335
            lg.t1 r12 = lg.t1.OUT_VARIANCE
            goto L_0x0337
        L_0x0335:
            lg.t1 r12 = lg.t1.IN_VARIANCE
        L_0x0337:
            if (r13 == 0) goto L_0x0348
            lg.t1 r15 = r4.d0()
            lg.t1 r14 = lg.t1.INVARIANT
            if (r15 != r14) goto L_0x0342
            goto L_0x0350
        L_0x0342:
            lg.t1 r14 = r4.d0()
            if (r12 == r14) goto L_0x0350
        L_0x0348:
            r22 = r0
            r17 = r1
            r11 = 0
            r14 = 0
            goto L_0x03e8
        L_0x0350:
            java.lang.Object r9 = r6.f549a
            q.f r9 = (q.f) r9
            java.lang.String r14 = "c"
            v7.r0.j(r14, r9)
            java.lang.String r14 = "wildcardType"
            v7.r0.j(r14, r3)
            r14 = r3
            cf.g0 r14 = (cf.g0) r14
            cf.d0 r14 = r14.b()
            if (r14 == 0) goto L_0x03dc
            hf.d r14 = new hf.d
            r15 = 0
            r14.<init>(r9, r3, r15)
            java.util.Iterator r3 = r14.iterator()
        L_0x0371:
            r9 = r3
            sg.b r9 = (sg.b) r9
            boolean r14 = r9.hasNext()
            if (r14 == 0) goto L_0x03a6
            java.lang.Object r9 = r9.next()
            r14 = r9
            xe.c r14 = (xe.c) r14
            uf.c[] r15 = ef.v.f18316b
            int r11 = r15.length
            r22 = r0
            r0 = 0
        L_0x0387:
            if (r0 >= r11) goto L_0x03a2
            r17 = r1
            r1 = r15[r0]
            r18 = r3
            uf.c r3 = r14.a()
            boolean r1 = v7.r0.b(r3, r1)
            if (r1 == 0) goto L_0x039b
            r0 = r9
            goto L_0x03ab
        L_0x039b:
            int r0 = r0 + 1
            r1 = r17
            r3 = r18
            goto L_0x0387
        L_0x03a2:
            r0 = r22
            r11 = 7
            goto L_0x0371
        L_0x03a6:
            r22 = r0
            r17 = r1
            r0 = 0
        L_0x03ab:
            xe.c r0 = (xe.c) r0
            lg.o1 r1 = lg.o1.f22099b
            r3 = 7
            r11 = 0
            r14 = 0
            jf.a r1 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.a2(r1, r11, r11, r14, r3)
            lg.b0 r1 = r6.w(r13, r1)
            if (r0 == 0) goto L_0x03d7
            xe.i r3 = r1.m()
            java.util.ArrayList r0 = xd.o.o0(r3, r0)
            boolean r3 = r0.isEmpty()
            if (r3 == 0) goto L_0x03cd
            xe.g r0 = xe.h.f29873a
            goto L_0x03d3
        L_0x03cd:
            xe.j r3 = new xe.j
            r3.<init>(r11, r0)
            r0 = r3
        L_0x03d3:
            lg.b0 r1 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.A1(r1, r0)
        L_0x03d7:
            lg.l0 r0 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.a0(r1, r12, r4)
            goto L_0x03fe
        L_0x03dc:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Nullability annotations on unbounded wildcards aren't supported"
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x03e8:
            lg.l0 r0 = lg.q1.l(r4, r9)
            goto L_0x03fe
        L_0x03ed:
            r22 = r0
            r17 = r1
            r11 = 0
            r14 = 0
            lg.l0 r0 = new lg.l0
            lg.t1 r1 = lg.t1.INVARIANT
            lg.b0 r3 = r6.w(r3, r9)
            r0.<init>(r3, r1)
        L_0x03fe:
            r2.add(r0)
            r0 = r22
            r1 = r17
            goto L_0x02e9
        L_0x0407:
            java.util.List r10 = xd.o.B0(r2)
            goto L_0x0282
        L_0x040d:
            lg.g0 r0 = lg.f.w(r3, r7, r10, r8)
            return r0
        L_0x0412:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown classifier kind: "
            r2.<init>(r3)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L_0x0426:
            uf.c r0 = new uf.c
            r9.getClass()
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r3)
            java.lang.reflect.Type r2 = r9.f4180a
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.i.l(lf.i, jf.a, lg.g0):lg.g0");
    }

    public final void m(r rVar, Map.Entry entry) {
        u uVar;
        r rVar2 = (r) entry.getValue();
        Size size = rVar.f20538f.f3324a;
        int i10 = ((e) entry.getKey()).f20468c;
        Rect rect = ((e) entry.getKey()).f20469d;
        int i11 = ((e) entry.getKey()).f20471f;
        boolean z4 = ((e) entry.getKey()).f20472g;
        if (rVar.f20535c) {
            uVar = (u) this.f550b;
        } else {
            uVar = null;
        }
        u uVar2 = uVar;
        rVar2.getClass();
        je.a();
        rVar2.a();
        ua.g("Consumer can only be linked once.", !rVar2.f20542j);
        rVar2.f20542j = true;
        q qVar = rVar2.f20544l;
        f.a(f.g(qVar.c(), new p(rVar2, qVar, i10, size, rect, i11, z4, uVar2), ua.n()), new xb.c(5, this), ua.n());
    }

    public final l.g n(l.b bVar) {
        int size = ((ArrayList) this.f551c).size();
        for (int i10 = 0; i10 < size; i10++) {
            l.g gVar = (l.g) ((ArrayList) this.f551c).get(i10);
            if (gVar != null && gVar.f21497b == bVar) {
                return gVar;
            }
        }
        l.g gVar2 = new l.g((Context) this.f550b, bVar);
        ((ArrayList) this.f551c).add(gVar2);
        return gVar2;
    }

    public final Menu o(o oVar) {
        Menu menu = (Menu) ((s0.k) this.f552d).getOrDefault(oVar, (Object) null);
        if (menu != null) {
            return menu;
        }
        f0 f0Var = new f0((Context) this.f550b, oVar);
        ((s0.k) this.f552d).put(oVar, f0Var);
        return f0Var;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: a4.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: java.lang.String} */
    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r5v3 */
    /* JADX WARNING: type inference failed for: r5v5 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final a4.g p(a4.j r7) {
        /*
            r6 = this;
            java.lang.String r0 = "id"
            v7.r0.j(r0, r7)
            java.lang.String r0 = "SELECT * FROM SystemIdInfo WHERE work_spec_id=? AND generation=?"
            r1 = 2
            a3.a0 r0 = a3.a0.p(r1, r0)
            java.lang.String r2 = r7.f553a
            r3 = 1
            if (r2 != 0) goto L_0x0015
            r0.t(r3)
            goto L_0x0018
        L_0x0015:
            r0.m(r3, r2)
        L_0x0018:
            int r7 = r7.f554b
            long r2 = (long) r7
            r0.D(r1, r2)
            java.lang.Object r7 = r6.f549a
            a3.x r7 = (a3.x) r7
            r7.b()
            java.lang.Object r7 = r6.f549a
            a3.x r7 = (a3.x) r7
            r1 = 0
            android.database.Cursor r7 = ne.c0.i(r7, r0, r1)
            java.lang.String r1 = "work_spec_id"
            int r1 = he.j.c(r7, r1)     // Catch:{ all -> 0x0061 }
            java.lang.String r2 = "generation"
            int r2 = he.j.c(r7, r2)     // Catch:{ all -> 0x0061 }
            java.lang.String r3 = "system_id"
            int r3 = he.j.c(r7, r3)     // Catch:{ all -> 0x0061 }
            boolean r4 = r7.moveToFirst()     // Catch:{ all -> 0x0061 }
            r5 = 0
            if (r4 == 0) goto L_0x0063
            boolean r4 = r7.isNull(r1)     // Catch:{ all -> 0x0061 }
            if (r4 == 0) goto L_0x004e
            goto L_0x0052
        L_0x004e:
            java.lang.String r5 = r7.getString(r1)     // Catch:{ all -> 0x0061 }
        L_0x0052:
            int r1 = r7.getInt(r2)     // Catch:{ all -> 0x0061 }
            int r2 = r7.getInt(r3)     // Catch:{ all -> 0x0061 }
            a4.g r3 = new a4.g     // Catch:{ all -> 0x0061 }
            r3.<init>(r5, r1, r2)     // Catch:{ all -> 0x0061 }
            r5 = r3
            goto L_0x0063
        L_0x0061:
            r1 = move-exception
            goto L_0x006a
        L_0x0063:
            r7.close()
            r0.q()
            return r5
        L_0x006a:
            r7.close()
            r0.q()
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.i.p(a4.j):a4.g");
    }

    public final void q(g gVar) {
        ((x) this.f549a).b();
        ((x) this.f549a).c();
        try {
            ((a3.e) this.f550b).M(gVar);
            ((x) this.f549a).n();
        } finally {
            ((x) this.f549a).j();
        }
    }

    public final void r(a2.r rVar) {
        ah.h hVar;
        Object a10 = ((ah.g) this.f551c).a(rVar);
        boolean z4 = a10 instanceof ah.h;
        Throwable th2 = null;
        if (z4) {
            if (z4) {
                hVar = (ah.h) a10;
            } else {
                hVar = null;
            }
            if (hVar != null) {
                th2 = hVar.f850a;
            }
            if (th2 == null) {
                th2 = new f7("Channel was closed normally", 2);
            }
            throw th2;
        } else if (!(!(a10 instanceof ah.i))) {
            throw new IllegalStateException("Check failed.".toString());
        } else if (((AtomicInteger) this.f552d).getAndIncrement() == 0) {
            b0.g1((z) this.f549a, (zd.j) null, new a2.o(this, (zd.e) null), 3);
        }
    }

    public final void s() {
        j0.j jVar = (j0.j) ((t) this.f549a);
        if (!jVar.f20488e.getAndSet(true)) {
            jVar.b(new androidx.activity.d(16, jVar), new t.g(2));
        }
        ua.n().execute(new androidx.activity.d(19, this));
    }

    public final d8.r t(Callable callable) {
        d8.r d10;
        synchronized (this.f551c) {
            d10 = ((d8.h) this.f550b).d((Executor) this.f549a, new wb.a(this, 18, callable));
            this.f550b = d10.d((Executor) this.f549a, new f((Object) this));
        }
        return d10;
    }

    public final d8.r u(Callable callable) {
        d8.r e10;
        synchronized (this.f551c) {
            e10 = ((d8.h) this.f550b).e((Executor) this.f549a, new wb.a(this, 18, callable));
            this.f550b = e10.d((Executor) this.f549a, new f((Object) this));
        }
        return e10;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0077  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final lg.s1 v(lf.f r7, jf.a r8, boolean r9) {
        /*
            r6 = this;
            java.lang.String r0 = "arrayType"
            v7.r0.j(r0, r7)
            r0 = r7
            cf.i r0 = (cf.i) r0
            cf.d0 r0 = r0.f4169b
            boolean r1 = r0 instanceof lf.n
            r2 = 0
            if (r1 == 0) goto L_0x0013
            r1 = r0
            lf.n r1 = (lf.n) r1
            goto L_0x0014
        L_0x0013:
            r1 = r2
        L_0x0014:
            if (r1 == 0) goto L_0x0030
            cf.b0 r1 = (cf.b0) r1
            java.lang.Class r3 = java.lang.Void.TYPE
            java.lang.Class r1 = r1.f4150a
            boolean r3 = v7.r0.b(r1, r3)
            if (r3 == 0) goto L_0x0023
            goto L_0x0030
        L_0x0023:
            java.lang.String r1 = r1.getName()
            cg.c r1 = cg.c.b(r1)
            te.n r1 = r1.d()
            goto L_0x0031
        L_0x0030:
            r1 = r2
        L_0x0031:
            hf.d r3 = new hf.d
            java.lang.Object r4 = r6.f549a
            q.f r4 = (q.f) r4
            r5 = 1
            r3.<init>(r4, r7, r5)
            r7 = 0
            boolean r8 = r8.f20910d
            if (r1 == 0) goto L_0x0077
            java.lang.Object r9 = r6.f549a
            q.f r9 = (q.f) r9
            we.b0 r9 = r9.m()
            te.l r9 = r9.n()
            lg.g0 r9 = r9.q(r1)
            xe.j r0 = new xe.j
            r1 = 2
            xe.i[] r1 = new xe.i[r1]
            xe.i r2 = r9.m()
            r1[r7] = r2
            r1[r5] = r3
            r0.<init>((xe.i[]) r1)
            lg.b0 r7 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.A1(r9, r0)
            java.lang.String r9 = "null cannot be cast to non-null type org.jetbrains.kotlin.types.SimpleType"
            v7.r0.h(r9, r7)
            lg.g0 r7 = (lg.g0) r7
            if (r8 == 0) goto L_0x006e
            goto L_0x0076
        L_0x006e:
            lg.g0 r8 = r7.O0(r5)
            lg.s1 r7 = lg.f.n(r7, r8)
        L_0x0076:
            return r7
        L_0x0077:
            lg.o1 r1 = lg.o1.f22099b
            r4 = 6
            jf.a r7 = com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0.a2(r1, r8, r7, r2, r4)
            lg.b0 r7 = r6.w(r0, r7)
            if (r8 == 0) goto L_0x009c
            if (r9 == 0) goto L_0x0089
            lg.t1 r8 = lg.t1.OUT_VARIANCE
            goto L_0x008b
        L_0x0089:
            lg.t1 r8 = lg.t1.INVARIANT
        L_0x008b:
            java.lang.Object r9 = r6.f549a
            q.f r9 = (q.f) r9
            we.b0 r9 = r9.m()
            te.l r9 = r9.n()
            lg.g0 r7 = r9.h(r8, r7, r3)
            return r7
        L_0x009c:
            java.lang.Object r8 = r6.f549a
            q.f r8 = (q.f) r8
            we.b0 r8 = r8.m()
            te.l r8 = r8.n()
            lg.t1 r9 = lg.t1.INVARIANT
            lg.g0 r8 = r8.h(r9, r7, r3)
            java.lang.Object r9 = r6.f549a
            q.f r9 = (q.f) r9
            we.b0 r9 = r9.m()
            te.l r9 = r9.n()
            lg.t1 r0 = lg.t1.OUT_VARIANCE
            lg.g0 r7 = r9.h(r0, r7, r3)
            lg.g0 r7 = r7.O0(r5)
            lg.s1 r7 = lg.f.n(r8, r7)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.i.v(lf.f, jf.a, boolean):lg.s1");
    }

    public final lg.b0 w(lf.o oVar, jf.a aVar) {
        lg.b0 b0Var;
        g0 g0Var;
        n nVar = null;
        if (oVar instanceof lf.n) {
            Class cls = Void.TYPE;
            Class cls2 = ((cf.b0) ((lf.n) oVar)).f4150a;
            if (!r0.b(cls2, cls)) {
                nVar = cg.c.b(cls2.getName()).d();
            }
            te.l n10 = ((q.f) this.f549a).m().n();
            if (nVar != null) {
                g0Var = n10.s(nVar);
            } else {
                g0Var = n10.w();
            }
            r0.g(g0Var);
            return g0Var;
        }
        boolean z4 = false;
        if (oVar instanceof lf.i) {
            lf.i iVar = (lf.i) oVar;
            if (!aVar.f20910d && aVar.f20907a != o1.f22098a) {
                z4 = true;
            }
            cf.s sVar = (cf.s) iVar;
            boolean c10 = sVar.c();
            Type type = sVar.f4180a;
            if (c10 || z4) {
                g0 l10 = l(sVar, aVar.g(jf.b.f20915c), (g0) null);
                if (l10 == null) {
                    return m.c(ng.l.f23467c, type.toString());
                }
                g0 l11 = l(sVar, aVar.g(jf.b.f20914b), l10);
                if (l11 == null) {
                    return m.c(ng.l.f23467c, type.toString());
                }
                if (c10) {
                    b0Var = new jf.h(l10, l11);
                } else {
                    b0Var = lg.f.n(l10, l11);
                }
                return b0Var;
            }
            g0 l12 = l(sVar, aVar, (g0) null);
            if (l12 != null) {
                return l12;
            }
            return m.c(ng.l.f23467c, type.toString());
        } else if (oVar instanceof lf.f) {
            return v((lf.f) oVar, aVar, false);
        } else {
            if (oVar instanceof lf.q) {
                d0 b5 = ((cf.g0) ((lf.q) oVar)).b();
                if (b5 != null) {
                    return w(b5, aVar);
                }
            } else if (oVar != null) {
                throw new UnsupportedOperationException("Unsupported type: " + oVar);
            }
            return ((q.f) this.f549a).m().n().m();
        }
    }

    public final com.google.android.gms.internal.measurement.n x(p pVar, c4... c4VarArr) {
        com.google.android.gms.internal.measurement.n nVar = com.google.android.gms.internal.measurement.n.A0;
        for (c4 o10 : c4VarArr) {
            nVar = f4.o(o10);
            f4.u((p) this.f551c);
            if ((nVar instanceof com.google.android.gms.internal.measurement.q) || (nVar instanceof com.google.android.gms.internal.measurement.o)) {
                nVar = ((wb.a) this.f549a).v(pVar, nVar);
            }
        }
        return nVar;
    }

    public i(u uVar, t tVar) {
        this.f550b = uVar;
        this.f549a = tVar;
    }

    public /* synthetic */ i(Object obj, Object obj2, Object obj3, Object obj4) {
        this.f549a = obj;
        this.f550b = obj2;
        this.f551c = obj3;
        this.f552d = obj4;
    }
}
