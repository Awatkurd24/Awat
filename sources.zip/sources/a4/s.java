package a4;

import f.c;
import ga.h;
import r3.f;
import r3.f0;
import r3.j;
import r3.u;
import v7.r0;

public final class s {

    /* renamed from: u  reason: collision with root package name */
    public static final String f576u;

    /* renamed from: v  reason: collision with root package name */
    public static final h f577v = new h(11);

    /* renamed from: a  reason: collision with root package name */
    public final String f578a;

    /* renamed from: b  reason: collision with root package name */
    public f0 f579b;

    /* renamed from: c  reason: collision with root package name */
    public final String f580c;

    /* renamed from: d  reason: collision with root package name */
    public String f581d;

    /* renamed from: e  reason: collision with root package name */
    public j f582e;

    /* renamed from: f  reason: collision with root package name */
    public j f583f;

    /* renamed from: g  reason: collision with root package name */
    public long f584g;

    /* renamed from: h  reason: collision with root package name */
    public long f585h;

    /* renamed from: i  reason: collision with root package name */
    public long f586i;

    /* renamed from: j  reason: collision with root package name */
    public f f587j;

    /* renamed from: k  reason: collision with root package name */
    public int f588k;

    /* renamed from: l  reason: collision with root package name */
    public int f589l;

    /* renamed from: m  reason: collision with root package name */
    public long f590m;

    /* renamed from: n  reason: collision with root package name */
    public long f591n;

    /* renamed from: o  reason: collision with root package name */
    public long f592o;

    /* renamed from: p  reason: collision with root package name */
    public long f593p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f594q;

    /* renamed from: r  reason: collision with root package name */
    public int f595r;

    /* renamed from: s  reason: collision with root package name */
    public final int f596s;

    /* renamed from: t  reason: collision with root package name */
    public final int f597t;

    static {
        String g10 = u.g("WorkSpec");
        r0.i("tagWithPrefix(\"WorkSpec\")", g10);
        f576u = g10;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public s(String str, String str2) {
        this(str, (f0) null, str2, (String) null, (j) null, (j) null, 0, 0, 0, (f) null, 0, 0, 0, 0, 0, 0, false, 0, 0, 1048570, 0);
        r0.j("id", str);
        r0.j("workerClassName_", str2);
    }

    public static s b(s sVar, String str, f0 f0Var, String str2, j jVar, int i10, long j3, int i11, int i12) {
        String str3;
        f0 f0Var2;
        String str4;
        String str5;
        j jVar2;
        j jVar3;
        long j10;
        long j11;
        long j12;
        f fVar;
        int i13;
        int i14;
        long j13;
        long j14;
        long j15;
        long j16;
        boolean z4;
        int i15;
        int i16;
        int i17;
        s sVar2 = sVar;
        int i18 = i12;
        if ((i18 & 1) != 0) {
            str3 = sVar2.f578a;
        } else {
            str3 = str;
        }
        if ((i18 & 2) != 0) {
            f0Var2 = sVar2.f579b;
        } else {
            f0Var2 = f0Var;
        }
        if ((i18 & 4) != 0) {
            str4 = sVar2.f580c;
        } else {
            str4 = str2;
        }
        if ((i18 & 8) != 0) {
            str5 = sVar2.f581d;
        } else {
            str5 = null;
        }
        if ((i18 & 16) != 0) {
            jVar2 = sVar2.f582e;
        } else {
            jVar2 = jVar;
        }
        if ((i18 & 32) != 0) {
            jVar3 = sVar2.f583f;
        } else {
            jVar3 = null;
        }
        if ((i18 & 64) != 0) {
            j10 = sVar2.f584g;
        } else {
            j10 = 0;
        }
        if ((i18 & 128) != 0) {
            j11 = sVar2.f585h;
        } else {
            j11 = 0;
        }
        if ((i18 & 256) != 0) {
            j12 = sVar2.f586i;
        } else {
            j12 = 0;
        }
        if ((i18 & 512) != 0) {
            fVar = sVar2.f587j;
        } else {
            fVar = null;
        }
        if ((i18 & 1024) != 0) {
            i13 = sVar2.f588k;
        } else {
            i13 = i10;
        }
        if ((i18 & 2048) != 0) {
            i14 = sVar2.f589l;
        } else {
            i14 = 0;
        }
        int i19 = i14;
        if ((i18 & 4096) != 0) {
            j13 = sVar2.f590m;
        } else {
            j13 = 0;
        }
        if ((i18 & 8192) != 0) {
            j14 = sVar2.f591n;
        } else {
            j14 = j3;
        }
        if ((i18 & 16384) != 0) {
            j15 = sVar2.f592o;
        } else {
            j15 = 0;
        }
        if ((32768 & i18) != 0) {
            j16 = sVar2.f593p;
        } else {
            j16 = 0;
        }
        if ((65536 & i18) != 0) {
            z4 = sVar2.f594q;
        } else {
            z4 = false;
        }
        if ((131072 & i18) != 0) {
            i15 = sVar2.f595r;
        } else {
            i15 = 0;
        }
        if ((262144 & i18) != 0) {
            i16 = sVar2.f596s;
        } else {
            i16 = 0;
        }
        if ((i18 & 524288) != 0) {
            i17 = sVar2.f597t;
        } else {
            i17 = i11;
        }
        sVar.getClass();
        r0.j("id", str3);
        r0.j("state", f0Var2);
        r0.j("workerClassName", str4);
        r0.j("input", jVar2);
        r0.j("output", jVar3);
        r0.j("constraints", fVar);
        int i20 = i19;
        c.x("backoffPolicy", i20);
        c.x("outOfQuotaPolicy", i15);
        return new s(str3, f0Var2, str4, str5, jVar2, jVar3, j10, j11, j12, fVar, i13, i20, j13, j14, j15, j16, z4, i15, i16, i17);
    }

    public final long a() {
        int i10;
        long j3;
        if (this.f579b != f0.f25340a || (i10 = this.f588k) <= 0) {
            long j10 = 0;
            if (d()) {
                int i11 = this.f596s;
                long j11 = this.f591n;
                if (i11 == 0) {
                    j11 += this.f584g;
                }
                long j12 = this.f586i;
                long j13 = this.f585h;
                if (j12 != j13) {
                    if (i11 == 0) {
                        j10 = ((long) -1) * j12;
                    }
                    j11 += j13;
                } else if (i11 != 0) {
                    j10 = j13;
                }
                return j10 + j11;
            }
            long j14 = this.f591n;
            if (j14 == 0) {
                j14 = System.currentTimeMillis();
            }
            return j14 + this.f584g;
        }
        if (this.f589l == 2) {
            j3 = this.f590m * ((long) i10);
        } else {
            j3 = (long) Math.scalb((float) this.f590m, i10 - 1);
        }
        long j15 = this.f591n;
        if (j3 > 18000000) {
            j3 = 18000000;
        }
        return j3 + j15;
    }

    public final boolean c() {
        return !r0.b(f.f25331i, this.f587j);
    }

    public final boolean d() {
        return this.f585h != 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return r0.b(this.f578a, sVar.f578a) && this.f579b == sVar.f579b && r0.b(this.f580c, sVar.f580c) && r0.b(this.f581d, sVar.f581d) && r0.b(this.f582e, sVar.f582e) && r0.b(this.f583f, sVar.f583f) && this.f584g == sVar.f584g && this.f585h == sVar.f585h && this.f586i == sVar.f586i && r0.b(this.f587j, sVar.f587j) && this.f588k == sVar.f588k && this.f589l == sVar.f589l && this.f590m == sVar.f590m && this.f591n == sVar.f591n && this.f592o == sVar.f592o && this.f593p == sVar.f593p && this.f594q == sVar.f594q && this.f595r == sVar.f595r && this.f596s == sVar.f596s && this.f597t == sVar.f597t;
    }

    public final int hashCode() {
        int i10;
        int hashCode = this.f579b.hashCode();
        int A = l.A(this.f580c, (hashCode + (this.f578a.hashCode() * 31)) * 31, 31);
        String str = this.f581d;
        if (str == null) {
            i10 = 0;
        } else {
            i10 = str.hashCode();
        }
        int hashCode2 = this.f582e.hashCode();
        int hashCode3 = this.f583f.hashCode();
        long j3 = this.f584g;
        long j10 = this.f585h;
        long j11 = this.f586i;
        int hashCode4 = this.f587j.hashCode();
        int h10 = t.u.h(this.f589l);
        long j12 = this.f590m;
        long j13 = this.f591n;
        long j14 = this.f592o;
        long j15 = this.f593p;
        int i11 = (((((((((h10 + ((((hashCode4 + ((((((((hashCode3 + ((hashCode2 + ((A + i10) * 31)) * 31)) * 31) + ((int) (j3 ^ (j3 >>> 32)))) * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31) + ((int) (j11 ^ (j11 >>> 32)))) * 31)) * 31) + this.f588k) * 31)) * 31) + ((int) (j12 ^ (j12 >>> 32)))) * 31) + ((int) (j13 ^ (j13 >>> 32)))) * 31) + ((int) (j14 ^ (j14 >>> 32)))) * 31) + ((int) (j15 ^ (j15 >>> 32)))) * 31;
        boolean z4 = this.f594q;
        if (z4) {
            z4 = true;
        }
        return ((((t.u.h(this.f595r) + ((i11 + (z4 ? 1 : 0)) * 31)) * 31) + this.f596s) * 31) + this.f597t;
    }

    public final String toString() {
        return "{WorkSpec: " + this.f578a + '}';
    }

    public s(String str, f0 f0Var, String str2, String str3, j jVar, j jVar2, long j3, long j10, long j11, f fVar, int i10, int i11, long j12, long j13, long j14, long j15, boolean z4, int i12, int i13, int i14) {
        j jVar3 = jVar2;
        f fVar2 = fVar;
        int i15 = i11;
        int i16 = i12;
        r0.j("id", str);
        r0.j("state", f0Var);
        r0.j("workerClassName", str2);
        r0.j("input", jVar);
        r0.j("output", jVar3);
        r0.j("constraints", fVar2);
        c.x("backoffPolicy", i15);
        c.x("outOfQuotaPolicy", i16);
        this.f578a = str;
        this.f579b = f0Var;
        this.f580c = str2;
        this.f581d = str3;
        this.f582e = jVar;
        this.f583f = jVar3;
        this.f584g = j3;
        this.f585h = j10;
        this.f586i = j11;
        this.f587j = fVar2;
        this.f588k = i10;
        this.f589l = i15;
        this.f590m = j12;
        this.f591n = j13;
        this.f592o = j14;
        this.f593p = j15;
        this.f594q = z4;
        this.f595r = i16;
        this.f596s = i13;
        this.f597t = i14;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ s(java.lang.String r31, r3.f0 r32, java.lang.String r33, java.lang.String r34, r3.j r35, r3.j r36, long r37, long r39, long r41, r3.f r43, int r44, int r45, long r46, long r48, long r50, long r52, boolean r54, int r55, int r56, int r57, int r58) {
        /*
            r30 = this;
            r0 = r57
            r1 = r0 & 2
            if (r1 == 0) goto L_0x000a
            r3.f0 r1 = r3.f0.f25340a
            r4 = r1
            goto L_0x000c
        L_0x000a:
            r4 = r32
        L_0x000c:
            r1 = r0 & 8
            if (r1 == 0) goto L_0x0013
            r1 = 0
            r6 = r1
            goto L_0x0015
        L_0x0013:
            r6 = r34
        L_0x0015:
            r1 = r0 & 16
            java.lang.String r2 = "EMPTY"
            if (r1 == 0) goto L_0x0022
            r3.j r1 = r3.j.f25369c
            v7.r0.i(r2, r1)
            r7 = r1
            goto L_0x0024
        L_0x0022:
            r7 = r35
        L_0x0024:
            r1 = r0 & 32
            if (r1 == 0) goto L_0x002f
            r3.j r1 = r3.j.f25369c
            v7.r0.i(r2, r1)
            r8 = r1
            goto L_0x0031
        L_0x002f:
            r8 = r36
        L_0x0031:
            r1 = r0 & 64
            if (r1 == 0) goto L_0x0038
            r9 = 0
            goto L_0x003a
        L_0x0038:
            r9 = r37
        L_0x003a:
            r1 = r0 & 128(0x80, float:1.794E-43)
            if (r1 == 0) goto L_0x0041
            r11 = 0
            goto L_0x0043
        L_0x0041:
            r11 = r39
        L_0x0043:
            r1 = r0 & 256(0x100, float:3.59E-43)
            if (r1 == 0) goto L_0x004a
            r13 = 0
            goto L_0x004c
        L_0x004a:
            r13 = r41
        L_0x004c:
            r1 = r0 & 512(0x200, float:7.175E-43)
            if (r1 == 0) goto L_0x0054
            r3.f r1 = r3.f.f25331i
            r15 = r1
            goto L_0x0056
        L_0x0054:
            r15 = r43
        L_0x0056:
            r1 = r0 & 1024(0x400, float:1.435E-42)
            r5 = 0
            if (r1 == 0) goto L_0x005e
            r16 = 0
            goto L_0x0060
        L_0x005e:
            r16 = r44
        L_0x0060:
            r1 = r0 & 2048(0x800, float:2.87E-42)
            r17 = 1
            if (r1 == 0) goto L_0x0068
            r1 = 1
            goto L_0x006a
        L_0x0068:
            r1 = r45
        L_0x006a:
            r2 = r0 & 4096(0x1000, float:5.74E-42)
            if (r2 == 0) goto L_0x0073
            r2 = 30000(0x7530, double:1.4822E-319)
            r18 = r2
            goto L_0x0075
        L_0x0073:
            r18 = r46
        L_0x0075:
            r2 = r0 & 8192(0x2000, float:1.14794E-41)
            if (r2 == 0) goto L_0x007c
            r20 = 0
            goto L_0x007e
        L_0x007c:
            r20 = r48
        L_0x007e:
            r2 = r0 & 16384(0x4000, float:2.2959E-41)
            if (r2 == 0) goto L_0x0085
            r22 = 0
            goto L_0x0087
        L_0x0085:
            r22 = r50
        L_0x0087:
            r2 = 32768(0x8000, float:4.5918E-41)
            r2 = r2 & r0
            if (r2 == 0) goto L_0x0092
            r2 = -1
            r24 = r2
            goto L_0x0094
        L_0x0092:
            r24 = r52
        L_0x0094:
            r2 = 65536(0x10000, float:9.18355E-41)
            r2 = r2 & r0
            if (r2 == 0) goto L_0x009c
            r26 = 0
            goto L_0x009e
        L_0x009c:
            r26 = r54
        L_0x009e:
            r2 = 131072(0x20000, float:1.83671E-40)
            r2 = r2 & r0
            if (r2 == 0) goto L_0x00a6
            r27 = 1
            goto L_0x00a8
        L_0x00a6:
            r27 = r55
        L_0x00a8:
            r2 = 262144(0x40000, float:3.67342E-40)
            r0 = r0 & r2
            if (r0 == 0) goto L_0x00b0
            r28 = 0
            goto L_0x00b2
        L_0x00b0:
            r28 = r56
        L_0x00b2:
            r29 = 0
            r2 = r30
            r3 = r31
            r5 = r33
            r17 = r1
            r2.<init>(r3, r4, r5, r6, r7, r8, r9, r11, r13, r15, r16, r17, r18, r20, r22, r24, r26, r27, r28, r29)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.s.<init>(java.lang.String, r3.f0, java.lang.String, java.lang.String, r3.j, r3.j, long, long, long, r3.f, int, int, long, long, long, long, boolean, int, int, int, int):void");
    }
}
