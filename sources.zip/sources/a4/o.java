package a4;

import a3.x;
import androidx.work.multiprocess.parcelable.ParcelableWorkInfos;
import c4.j;
import com.google.android.gms.internal.ads.a91;
import com.google.android.gms.internal.ads.ba1;
import com.google.android.gms.internal.ads.c81;
import com.google.android.gms.internal.ads.c91;
import com.google.android.gms.internal.ads.d81;
import com.google.android.gms.internal.ads.e91;
import com.google.android.gms.internal.ads.fd1;
import com.google.android.gms.internal.ads.g91;
import com.google.android.gms.internal.ads.h71;
import com.google.android.gms.internal.ads.l71;
import com.google.android.gms.internal.ads.la1;
import com.google.android.gms.internal.ads.n11;
import com.google.android.gms.internal.ads.n71;
import com.google.android.gms.internal.ads.o21;
import com.google.android.gms.internal.ads.p21;
import com.google.android.gms.internal.ads.q31;
import com.google.android.gms.internal.ads.q71;
import com.google.android.gms.internal.ads.v21;
import com.google.android.gms.internal.ads.v91;
import com.google.android.gms.internal.ads.wa1;
import com.google.android.gms.internal.ads.y91;
import com.v2ray.ang.dto.V2rayConfig;
import f4.h;
import f4.t;
import java.security.GeneralSecurityException;
import java.util.List;
import m.d;
import ne.c0;
import r3.z;

public final class o extends d {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ int f562d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o(int i10) {
        super(h71.class, new o21(v91.class, 1));
        this.f562d = i10;
        Class<n11> cls = n11.class;
        if (i10 == 1) {
            super(n71.class, new o21(cls, 2));
        } else if (i10 == 2) {
            super(c81.class, new o21(cls, 5));
        } else if (i10 == 3) {
            super(a91.class, new o21(cls, 6));
        } else if (i10 != 4) {
        } else {
            super(e91.class, new o21(cls, 7));
        }
    }

    public byte[] C(Object obj) {
        int i10 = this.f562d;
        switch (i10) {
            case 0:
                z zVar = (z) obj;
                return L();
            case 1:
                z zVar2 = (z) obj;
                return L();
            case 2:
                z zVar3 = (z) obj;
                return L();
            case 3:
                z zVar4 = (z) obj;
                return L();
            case 4:
                z zVar5 = (z) obj;
                return L();
            case 5:
                z zVar6 = (z) obj;
                return L();
            case 6:
                z zVar7 = (z) obj;
                return L();
            case 7:
                return c0.g(new ParcelableWorkInfos((List) obj));
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                Void voidR = (Void) obj;
                switch (i10) {
                }
                return t.f18462c;
            default:
                Void voidR2 = (Void) obj;
                switch (i10) {
                }
                return t.f18462c;
        }
    }

    public fd1 E() {
        switch (this.f562d) {
            case 0:
                return new v21(this);
            case 1:
                return new p21(q71.class, 1);
            case 2:
                return new p21(d81.class, 4);
            case 3:
                return new p21(c91.class, 5);
            default:
                return new p21(g91.class, 6);
        }
    }

    public int F() {
        switch (this.f562d) {
            case 0:
            case 1:
            case 2:
                return 2;
            default:
                return 5;
        }
    }

    public ba1 G(la1 la1) {
        switch (this.f562d) {
            case 0:
                return h71.y(la1, wa1.f13327b);
            case 1:
                return n71.x(la1, wa1.f13327b);
            case 2:
                return c81.x(la1, wa1.f13327b);
            case 3:
                return a91.x(la1, wa1.f13327b);
            default:
                return e91.x(la1, wa1.f13327b);
        }
    }

    public String H() {
        switch (this.f562d) {
            case 0:
                return "type.googleapis.com/google.crypto.tink.AesCtrKey";
            case 1:
                return "type.googleapis.com/google.crypto.tink.AesEaxKey";
            case 2:
                return "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key";
            case 3:
                return "type.googleapis.com/google.crypto.tink.KmsAeadKey";
            default:
                return "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey";
        }
    }

    public void I(ba1 ba1) {
        switch (this.f562d) {
            case 0:
                h71 h71 = (h71) ba1;
                y91.b(h71.v());
                y91.a(h71.A().q());
                l71 z4 = h71.z();
                if (z4.v() < 12 || z4.v() > 16) {
                    throw new GeneralSecurityException("invalid IV size");
                }
                return;
            case 1:
                n71 n71 = (n71) ba1;
                y91.b(n71.v());
                y91.a(n71.z().q());
                if (n71.y().v() != 12 && n71.y().v() != 16) {
                    throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                }
                return;
            case 2:
                c81 c81 = (c81) ba1;
                y91.b(c81.v());
                if (c81.y().q() != 32) {
                    throw new GeneralSecurityException("invalid ChaCha20Poly1305Key: incorrect key length");
                }
                return;
            case 3:
                y91.b(((a91) ba1).v());
                return;
            default:
                e91 e91 = (e91) ba1;
                y91.b(e91.v());
                if (!q31.f11461a.contains(e91.y().v().A())) {
                    throw new GeneralSecurityException(l.I("Unsupported DEK key type: ", e91.y().v().A(), ". Only Tink AEAD key types are supported."));
                }
                return;
        }
    }

    public int J() {
        return 1;
    }

    public byte[] L() {
        switch (this.f562d) {
            case 0:
                return t.f18462c;
            case 1:
                return t.f18462c;
            case 2:
                return t.f18462c;
            case 3:
                return t.f18462c;
            case 4:
                return t.f18462c;
            case 5:
                return t.f18462c;
            default:
                return t.f18462c;
        }
    }

    public String p() {
        switch (this.f562d) {
            case 0:
                return "DELETE from WorkProgress where work_spec_id=?";
            default:
                return "DELETE FROM WorkProgress";
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o(x xVar, int i10) {
        super(xVar);
        this.f562d = i10;
    }

    public /* synthetic */ o(b4.o oVar, h hVar, j jVar, int i10) {
        this.f562d = i10;
        this.f22218a = oVar;
        this.f22219b = hVar;
        this.f22220c = jVar;
    }
}
