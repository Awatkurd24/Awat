package a4;

import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import android.widget.TextView;
import com.flurry.android.Constants;
import com.google.android.gms.common.moduleinstall.internal.ApiFeatureRequest;
import com.google.android.gms.internal.measurement.c0;
import com.google.android.gms.internal.measurement.n;
import com.google.android.gms.internal.measurement.p4;
import com.google.gson.internal.l;
import com.v2ray.ang.AppConfig;
import com.v2ray.ang.dto.V2rayConfig;
import e0.c;
import e7.k;
import ic.h;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import lg.g0;
import me.a;
import pa.b;
import pf.g;
import rf.f;
import s3.s;
import t0.j;
import u6.d;
import v7.e9;
import v7.g9;
import v7.h9;
import v7.je;
import v7.r0;
import we.b0;
import we.g1;
import we.i;
import we.u0;
import xd.o;
import xd.r;
import xf.e;
import z.t0;
import z7.b4;
import z7.w6;
import ze.b1;
import ze.p;
import ze.x;
import zf.t;
import zf.v;
import zf.w;
import zf.y;

public final class m implements c, d, k, c0, b4, l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f557a;

    /* renamed from: b  reason: collision with root package name */
    public Object f558b;

    /* renamed from: c  reason: collision with root package name */
    public Object f559c;

    public /* synthetic */ m() {
        this.f557a = 19;
    }

    public final void D(Throwable th2) {
        switch (this.f557a) {
            case 3:
                ((t0) this.f558b).close();
                return;
            case 4:
                je.a();
                f.c.w(this.f558b);
                p4 p4Var = (p4) this.f559c;
                f.c.w(p4Var.f15159b);
                p4Var.f15159b = null;
                return;
            default:
                ((j) this.f558b).b(th2);
                return;
        }
    }

    public final Object Y() {
        throw new RuntimeException((String) this.f558b);
    }

    public final void a(String str, Object obj) {
        String valueOf = String.valueOf(obj);
        ((List) this.f558b).add(str + "=" + valueOf);
    }

    public final boolean b(j jVar) {
        boolean containsKey;
        synchronized (this.f558b) {
            containsKey = ((Map) this.f559c).containsKey(jVar);
        }
        return containsKey;
    }

    public final void c() {
        try {
            b bVar = (b) this.f559c;
            bVar.getClass();
            new File((File) bVar.f24100b, (String) this.f558b).createNewFile();
        } catch (IOException e10) {
            Log.e("FirebaseCrashlytics", "Error creating marker: " + ((String) this.f558b), e10);
        }
    }

    public final xe.d d(g gVar, f fVar) {
        r0.j("proto", gVar);
        r0.j("nameResolver", fVar);
        we.f h10 = g9.h((b0) this.f558b, h9.i(fVar, gVar.f24269c), (p) this.f559c);
        Map map = r.f29843a;
        if (gVar.f24270d.size() != 0 && !ng.m.f(h10)) {
            int i10 = e.f29913a;
            if (e.n(h10, we.g.f29334e)) {
                Collection E = h10.E();
                r0.i("getConstructors(...)", E);
                we.e eVar = (we.e) o.t0(E);
                if (eVar != null) {
                    List C0 = ((x) eVar).C0();
                    r0.i("getValueParameters(...)", C0);
                    Iterable iterable = C0;
                    int p5 = e9.p(xd.l.R(iterable));
                    if (p5 < 16) {
                        p5 = 16;
                    }
                    LinkedHashMap linkedHashMap = new LinkedHashMap(p5);
                    for (Object next : iterable) {
                        linkedHashMap.put(((p) ((g1) next)).getName(), next);
                    }
                    List<pf.e> list = gVar.f24270d;
                    r0.i("getArgumentList(...)", list);
                    ArrayList arrayList = new ArrayList();
                    for (pf.e eVar2 : list) {
                        r0.g(eVar2);
                        g1 g1Var = (g1) linkedHashMap.get(h9.l(fVar, eVar2.f24224c));
                        zf.g gVar2 = null;
                        if (g1Var != null) {
                            uf.f l10 = h9.l(fVar, eVar2.f24224c);
                            lg.b0 b5 = ((b1) g1Var).b();
                            r0.i("getType(...)", b5);
                            pf.d dVar = eVar2.f24225d;
                            r0.i("getValue(...)", dVar);
                            zf.g n10 = n(b5, dVar, fVar);
                            if (e(n10, b5, dVar)) {
                                gVar2 = n10;
                            }
                            if (gVar2 == null) {
                                String str = "Unexpected argument value: actual type " + dVar.f24196c + " != expected type " + b5;
                                r0.j("message", str);
                                gVar2 = new zf.j(str);
                            }
                            gVar2 = new wd.f(l10, gVar2);
                        }
                        if (gVar2 != null) {
                            arrayList.add(gVar2);
                        }
                    }
                    map = xd.x.z(arrayList);
                }
            }
        }
        return new xe.d(h10.l(), map, u0.f29379a);
    }

    public final boolean e(zf.g gVar, lg.b0 b0Var, pf.d dVar) {
        int i10;
        we.f fVar;
        pf.c cVar = dVar.f24196c;
        if (cVar == null) {
            i10 = -1;
        } else {
            i10 = hg.d.f19749a[cVar.ordinal()];
        }
        if (i10 == 10) {
            i p5 = b0Var.K0().p();
            if (p5 instanceof we.f) {
                fVar = (we.f) p5;
            } else {
                fVar = null;
            }
            if (fVar == null) {
                return true;
            }
            uf.f fVar2 = te.l.f26764e;
            if (te.l.b(fVar, te.p.P)) {
                return true;
            }
        } else if (i10 != 13) {
            return r0.b(gVar.a((b0) this.f558b), b0Var);
        } else {
            if (gVar instanceof zf.b) {
                zf.b bVar = (zf.b) gVar;
                if (((List) bVar.f31625a).size() == dVar.f24204k.size()) {
                    lg.b0 f10 = ((b0) this.f558b).n().f(b0Var);
                    Collection collection = (Collection) bVar.f31625a;
                    r0.j("<this>", collection);
                    a aVar = new a(0, collection.size() - 1, 1);
                    if ((aVar instanceof Collection) && ((Collection) aVar).isEmpty()) {
                        return true;
                    }
                    me.b f11 = aVar.iterator();
                    while (f11.f22699c) {
                        int b5 = f11.b();
                        pf.d dVar2 = (pf.d) dVar.f24204k.get(b5);
                        r0.i("getArrayElement(...)", dVar2);
                        if (!e((zf.g) ((List) bVar.f31625a).get(b5), f10, dVar2)) {
                        }
                    }
                    return true;
                }
            }
            throw new IllegalStateException(("Deserialized ArrayValue should have the same number of elements as the original array value: " + gVar).toString());
        }
        return false;
    }

    public final mc.b f() {
        if (((mc.b) this.f559c) == null) {
            this.f559c = ((ic.b) this.f558b).a();
        }
        return (mc.b) this.f559c;
    }

    public final mc.a g(int i10, mc.a aVar) {
        int[] iArr;
        mc.f fVar = (mc.f) ((ic.b) this.f558b);
        ic.i iVar = fVar.f20156a;
        int i11 = iVar.f20183a;
        if (aVar.f22656b < i11) {
            aVar = new mc.a(i11);
        } else {
            int length = aVar.f22655a.length;
            for (int i12 = 0; i12 < length; i12++) {
                aVar.f22655a[i12] = 0;
            }
        }
        if (fVar.f22680b.length < i11) {
            fVar.f22680b = new byte[i11];
        }
        int i13 = 0;
        while (true) {
            iArr = fVar.f22681c;
            if (i13 >= 32) {
                break;
            }
            iArr[i13] = 0;
            i13++;
        }
        byte[] b5 = iVar.b(i10, fVar.f22680b);
        for (int i14 = 0; i14 < i11; i14++) {
            int i15 = (b5[i14] & Constants.UNKNOWN) >> 3;
            iArr[i15] = iArr[i15] + 1;
        }
        int b10 = mc.f.b(iArr);
        if (i11 < 3) {
            for (int i16 = 0; i16 < i11; i16++) {
                if ((b5[i16] & Constants.UNKNOWN) < b10) {
                    aVar.j(i16);
                }
            }
        } else {
            byte b11 = b5[0] & Constants.UNKNOWN;
            int i17 = 1;
            byte b12 = b11;
            byte b13 = b5[1] & Constants.UNKNOWN;
            while (i17 < i11 - 1) {
                int i18 = i17 + 1;
                byte b14 = b5[i18] & Constants.UNKNOWN;
                if ((((b13 * 4) - b12) - b14) / 2 < b10) {
                    aVar.j(i17);
                }
                b12 = b13;
                i17 = i18;
                b13 = b14;
            }
        }
        return aVar;
    }

    public final p h(n nVar) {
        ((p) this.f558b).k((String) this.f559c, nVar);
        return (p) this.f558b;
    }

    public final void i(f7.g gVar, Object obj) {
        i7.f fVar = new i7.f((d8.i) obj, 0);
        i7.d dVar = (i7.d) ((i7.j) gVar).p();
        Parcel Z = dVar.Z();
        q7.b.d(Z, fVar);
        q7.b.c(Z, (ApiFeatureRequest) this.f559c);
        dVar.k0(Z, 1);
    }

    public final void j(int i10, Bundle bundle) {
        Object obj;
        String format = String.format(Locale.US, "Analytics listener received message. ID: %d, Extras: %s", new Object[]{Integer.valueOf(i10), bundle});
        if (Log.isLoggable("FirebaseCrashlytics", 2)) {
            Log.v("FirebaseCrashlytics", format, (Throwable) null);
        }
        String string = bundle.getString("name");
        if (string != null) {
            Bundle bundle2 = bundle.getBundle("params");
            if (bundle2 == null) {
                bundle2 = new Bundle();
            }
            if ("clx".equals(bundle2.getString("_o"))) {
                obj = this.f558b;
            } else {
                obj = this.f559c;
            }
            ja.b bVar = (ja.b) obj;
            if (bVar != null) {
                bVar.l(bundle2, string);
            }
        }
    }

    public final void k(String str, int i10, Throwable th2, byte[] bArr, Map map) {
        ((w6) this.f559c).w(true, i10, th2, bArr);
    }

    public final List l(String str) {
        List B0;
        r0.j("workSpecId", str);
        synchronized (this.f558b) {
            try {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                for (Map.Entry entry : ((Map) this.f559c).entrySet()) {
                    if (r0.b(((j) entry.getKey()).f553a, str)) {
                        linkedHashMap.put(entry.getKey(), entry.getValue());
                    }
                }
                for (j remove : linkedHashMap.keySet()) {
                    ((Map) this.f559c).remove(remove);
                }
                B0 = o.B0(linkedHashMap.values());
            } finally {
            }
        }
        return B0;
    }

    public final s m(j jVar) {
        s sVar;
        r0.j("id", jVar);
        synchronized (this.f558b) {
            sVar = (s) ((Map) this.f559c).remove(jVar);
        }
        return sVar;
    }

    public final zf.g n(lg.b0 b0Var, pf.d dVar, f fVar) {
        int i10;
        zf.g eVar;
        zf.g tVar;
        boolean z4;
        r0.j("nameResolver", fVar);
        boolean P = l.P(rf.e.N, dVar.f24206m, "get(...)");
        pf.c cVar = dVar.f24196c;
        if (cVar == null) {
            i10 = -1;
        } else {
            i10 = hg.d.f19749a[cVar.ordinal()];
        }
        switch (i10) {
            case 1:
                byte b5 = (byte) ((int) dVar.f24197d);
                if (P) {
                    return new y(b5);
                }
                return new zf.d(b5);
            case 2:
                eVar = new zf.e((char) ((int) dVar.f24197d));
                break;
            case 3:
                short s10 = (short) ((int) dVar.f24197d);
                if (P) {
                    return new y(s10);
                }
                return new v(s10);
            case 4:
                int i11 = (int) dVar.f24197d;
                if (!P) {
                    eVar = new zf.k(i11);
                    break;
                } else {
                    eVar = new y(i11);
                    break;
                }
            case 5:
                long j3 = dVar.f24197d;
                if (P) {
                    tVar = new y(j3);
                } else {
                    tVar = new t(j3);
                }
                return tVar;
            case 6:
                eVar = new zf.c(dVar.f24198e);
                break;
            case 7:
                eVar = new zf.c(dVar.f24199f);
                break;
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                if (dVar.f24197d != 0) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                eVar = new zf.c(z4);
                break;
            case 9:
                eVar = new w(fVar.a(dVar.f24200g));
                break;
            case 10:
                eVar = new zf.s(h9.i(fVar, dVar.f24201h), dVar.f24205l);
                break;
            case AppConfig.MSG_STATE_RUNNING /*11*/:
                eVar = new zf.i(h9.i(fVar, dVar.f24201h), h9.l(fVar, dVar.f24202i));
                break;
            case AppConfig.MSG_STATE_NOT_RUNNING /*12*/:
                g gVar = dVar.f24203j;
                r0.i("getAnnotation(...)", gVar);
                eVar = new zf.a(d(gVar, fVar));
                break;
            case 13:
                List list = dVar.f24204k;
                r0.i("getArrayElementList(...)", list);
                Iterable<pf.d> iterable = list;
                ArrayList arrayList = new ArrayList(xd.l.R(iterable));
                for (pf.d dVar2 : iterable) {
                    g0 e10 = ((b0) this.f558b).n().e();
                    r0.i("getAnyType(...)", e10);
                    r0.g(dVar2);
                    arrayList.add(n(e10, dVar2, fVar));
                }
                return new zf.x(arrayList, b0Var);
            default:
                throw new IllegalStateException(("Unsupported annotation argument type: " + dVar.f24196c + " (expected " + b0Var + ')').toString());
        }
        return eVar;
    }

    public final s o(j jVar) {
        s sVar;
        synchronized (this.f558b) {
            try {
                Map map = (Map) this.f559c;
                Object obj = map.get(jVar);
                if (obj == null) {
                    obj = new s(jVar);
                    map.put(jVar, obj);
                }
                sVar = (s) obj;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return sVar;
    }

    public final void onSuccess(Object obj) {
        switch (this.f557a) {
            case 3:
                Void voidR = (Void) obj;
                return;
            case 4:
                Void voidR2 = (Void) obj;
                return;
            default:
                try {
                    ((j) this.f558b).a(((p.a) this.f559c).apply(obj));
                    return;
                } catch (Throwable th2) {
                    ((j) this.f558b).b(th2);
                    return;
                }
        }
    }

    public final String toString() {
        switch (this.f557a) {
            case 6:
                return "Bounds{lower=" + ((j1.c) this.f558b) + " upper=" + ((j1.c) this.f559c) + "}";
            case 13:
                StringBuilder sb2 = new StringBuilder(100);
                sb2.append(this.f559c.getClass().getSimpleName());
                sb2.append('{');
                int size = ((List) this.f558b).size();
                for (int i10 = 0; i10 < size; i10++) {
                    sb2.append((String) ((List) this.f558b).get(i10));
                    if (i10 < size - 1) {
                        sb2.append(", ");
                    }
                }
                sb2.append('}');
                return sb2.toString();
            case 23:
                try {
                    return f().toString();
                } catch (h unused) {
                    return "";
                }
            default:
                return super.toString();
        }
    }

    public m(int i10) {
        this.f557a = i10;
        if (i10 == 21) {
            return;
        }
        if (i10 != 24) {
            switch (i10) {
                case V2rayConfig.DEFAULT_LEVEL /*8*/:
                    return;
                case 9:
                    this.f558b = "";
                    this.f559c = new ArrayList();
                    return;
                case 10:
                    this.f558b = new ConcurrentHashMap();
                    this.f559c = new AtomicInteger(0);
                    return;
                default:
                    this.f558b = new Object();
                    this.f559c = new LinkedHashMap();
                    return;
            }
        } else {
            this.f558b = new int[4];
            this.f559c = new StringBuilder();
        }
    }

    public m(a3.x xVar) {
        this.f557a = 0;
        this.f558b = xVar;
        this.f559c = new b(this, xVar, 3);
    }

    public m(TextView textView) {
        this.f557a = 1;
        textView.getClass();
        this.f558b = textView;
    }

    public /* synthetic */ m(Object obj) {
        this.f557a = 13;
        l7.a.j(obj);
        this.f559c = obj;
        this.f558b = new ArrayList();
    }

    public /* synthetic */ m(Object obj, int i10, Object obj2) {
        this.f557a = i10;
        this.f559c = obj;
        this.f558b = obj2;
    }

    public /* synthetic */ m(Object obj, Object obj2, int i10) {
        this.f557a = i10;
        this.f558b = obj;
        this.f559c = obj2;
    }

    public m(mc.f fVar) {
        this.f557a = 23;
        this.f558b = fVar;
    }

    public m(b0 b0Var, p pVar) {
        this.f557a = 26;
        r0.j("module", b0Var);
        r0.j("notFoundClasses", pVar);
        this.f558b = b0Var;
        this.f559c = pVar;
    }
}
