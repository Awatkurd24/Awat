package a4;

import a3.a0;
import a3.x;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraDevice;
import android.os.IInterface;
import android.os.Parcel;
import android.util.Log;
import androidx.appcompat.widget.c4;
import androidx.appcompat.widget.j;
import androidx.lifecycle.g0;
import b0.s0;
import com.google.android.gms.internal.measurement.c0;
import com.google.android.gms.internal.mlkit_vision_barcode_bundled.b0;
import d8.g;
import d8.r;
import e7.k;
import e7.m;
import eb.a;
import h.d;
import ic.n;
import j6.f;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import mc.b;
import n9.e;
import org.json.JSONException;
import org.json.JSONObject;
import p8.i;
import t.g1;
import t.h;
import t.n0;
import t.v1;
import t7.w;
import u.y;
import v.u;
import v.v;
import v7.f9;
import v7.je;
import v7.r0;
import v7.t9;
import w7.ua;

public class c implements d, e0.c, k, c0, i, o9.c, g {

    /* renamed from: a  reason: collision with root package name */
    public Object f536a;

    /* renamed from: b  reason: collision with root package name */
    public Object f537b;

    public c(int i10) {
        if (i10 != 21) {
            this.f536a = new g0();
            this.f537b = new HashMap();
        }
    }

    public static n B(n nVar, n nVar2, int i10) {
        float f10 = nVar2.f20209a;
        float f11 = nVar.f20209a;
        float f12 = (float) (i10 + 1);
        float f13 = nVar2.f20210b;
        float f14 = nVar.f20210b;
        return new n(f11 + ((f10 - f11) / f12), f14 + ((f13 - f14) / f12));
    }

    public static ArrayList G(List list) {
        ArrayList arrayList = new ArrayList(list.size());
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(((v.i) it.next()).f27442a.e());
        }
        return arrayList;
    }

    public static f[] I(String str) {
        String[] split = str.split("\\s*,\\s*");
        int length = split.length;
        f[] fVarArr = new f[length];
        for (int i10 = 0; i10 < split.length; i10++) {
            String trim = split[i10].trim();
            if (trim.matches("^(\\d+|FULL_WIDTH)\\s*[xX]\\s*(\\d+|AUTO_HEIGHT)$")) {
                String[] split2 = trim.split("[xX]");
                split2[0] = split2[0].trim();
                split2[1] = split2[1].trim();
                try {
                    fVarArr[i10] = new f("FULL_WIDTH".equals(split2[0]) ? -1 : Integer.parseInt(split2[0]), "AUTO_HEIGHT".equals(split2[1]) ? -2 : Integer.parseInt(split2[1]));
                } catch (NumberFormatException unused) {
                    throw new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(trim));
                }
            } else if ("BANNER".equals(trim)) {
                fVarArr[i10] = f.f20670h;
            } else if ("LARGE_BANNER".equals(trim)) {
                fVarArr[i10] = f.f20672j;
            } else if ("FULL_BANNER".equals(trim)) {
                fVarArr[i10] = f.f20671i;
            } else if ("LEADERBOARD".equals(trim)) {
                fVarArr[i10] = f.f20673k;
            } else if ("MEDIUM_RECTANGLE".equals(trim)) {
                fVarArr[i10] = f.f20674l;
            } else if ("SMART_BANNER".equals(trim)) {
                fVarArr[i10] = f.f20676n;
            } else if ("WIDE_SKYSCRAPER".equals(trim)) {
                fVarArr[i10] = f.f20675m;
            } else if ("FLUID".equals(trim)) {
                fVarArr[i10] = f.f20677o;
            } else if ("ICON".equals(trim)) {
                fVarArr[i10] = f.f20679q;
            } else {
                throw new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(trim));
            }
        }
        if (length != 0) {
            return fVarArr;
        }
        throw new IllegalArgumentException("Could not parse XML attribute \"adSize\": ".concat(str));
    }

    public static void g(CameraDevice cameraDevice, v vVar) {
        cameraDevice.getClass();
        vVar.getClass();
        u uVar = vVar.f27467a;
        uVar.d().getClass();
        List<v.i> e10 = uVar.e();
        if (e10 == null) {
            throw new IllegalArgumentException("Invalid output configurations");
        } else if (uVar.g() != null) {
            String id2 = cameraDevice.getId();
            for (v.i iVar : e10) {
                String d10 = iVar.f27442a.d();
                if (d10 != null && !d10.isEmpty()) {
                    t9.g("CameraDeviceCompat", "Camera " + id2 + ": Camera doesn't support physicalCameraId " + d10 + ". Ignoring.");
                }
            }
        } else {
            throw new IllegalArgumentException("Invalid executor");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x004e, code lost:
        if (r4.a().f21107e == false) goto L_0x0051;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0051, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean x(jh.i0 r3, jh.k0 r4) {
        /*
            int r0 = r4.f21136c
            r1 = 200(0xc8, float:2.8E-43)
            r2 = 0
            if (r0 == r1) goto L_0x0052
            r1 = 410(0x19a, float:5.75E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 414(0x19e, float:5.8E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 501(0x1f5, float:7.02E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 203(0xcb, float:2.84E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 204(0xcc, float:2.86E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 307(0x133, float:4.3E-43)
            if (r0 == r1) goto L_0x002f
            r1 = 308(0x134, float:4.32E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 404(0x194, float:5.66E-43)
            if (r0 == r1) goto L_0x0052
            r1 = 405(0x195, float:5.68E-43)
            if (r0 == r1) goto L_0x0052
            switch(r0) {
                case 300: goto L_0x0052;
                case 301: goto L_0x0052;
                case 302: goto L_0x002f;
                default: goto L_0x002e;
            }
        L_0x002e:
            goto L_0x0051
        L_0x002f:
            java.lang.String r0 = "Expires"
            java.lang.String r0 = r4.d(r0)
            if (r0 != 0) goto L_0x0052
            jh.i r0 = r4.a()
            r1 = -1
            int r0 = r0.f21105c
            if (r0 != r1) goto L_0x0052
            jh.i r0 = r4.a()
            boolean r0 = r0.f21108f
            if (r0 != 0) goto L_0x0052
            jh.i r0 = r4.a()
            boolean r0 = r0.f21107e
            if (r0 == 0) goto L_0x0051
            goto L_0x0052
        L_0x0051:
            return r2
        L_0x0052:
            jh.i r4 = r4.a()
            boolean r4 = r4.f21104b
            if (r4 != 0) goto L_0x006c
            jh.i r4 = r3.f21121f
            if (r4 == 0) goto L_0x005f
            goto L_0x0067
        L_0x005f:
            jh.y r4 = r3.f21118c
            jh.i r4 = jh.i.a(r4)
            r3.f21121f = r4
        L_0x0067:
            boolean r3 = r4.f21104b
            if (r3 != 0) goto L_0x006c
            r2 = 1
        L_0x006c:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c.x(jh.i0, jh.k0):boolean");
    }

    public static n z(n nVar, float f10, float f11) {
        float f12 = nVar.f20209a;
        float f13 = f12 < f10 ? f12 - 1.0f : f12 + 1.0f;
        float f14 = nVar.f20210b;
        return new n(f13, f14 < f11 ? f14 - 1.0f : f14 + 1.0f);
    }

    public final a A() {
        JSONObject jSONObject;
        FileInputStream fileInputStream;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[16384];
        try {
            fileInputStream = new FileInputStream(p());
            while (true) {
                int read = fileInputStream.read(bArr, 0, 16384);
                if (read < 0) {
                    break;
                }
                byteArrayOutputStream.write(bArr, 0, read);
            }
            jSONObject = new JSONObject(byteArrayOutputStream.toString());
            fileInputStream.close();
        } catch (IOException | JSONException unused) {
            jSONObject = new JSONObject();
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
        String optString = jSONObject.optString("Fid", (String) null);
        int optInt = jSONObject.optInt("Status", 0);
        String optString2 = jSONObject.optString("AuthToken", (String) null);
        String optString3 = jSONObject.optString("RefreshToken", (String) null);
        long optLong = jSONObject.optLong("TokenCreationEpochInSecs", 0);
        long optLong2 = jSONObject.optLong("ExpiresInSecs", 0);
        String optString4 = jSONObject.optString("FisError", (String) null);
        int i10 = a.f18128h;
        c4 c4Var = new c4(16);
        c4Var.f1320f = 0L;
        c4Var.l(eb.c.f18139a);
        c4Var.f1319e = 0L;
        c4Var.f1315a = optString;
        c4Var.l(eb.c.values()[optInt]);
        c4Var.f1317c = optString2;
        c4Var.f1318d = optString3;
        c4Var.f1320f = Long.valueOf(optLong);
        c4Var.f1319e = Long.valueOf(optLong2);
        c4Var.f1321g = optString4;
        return c4Var.g();
        throw th;
    }

    public final float C(int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        boolean z4;
        c cVar;
        boolean z10;
        int i19 = 1;
        boolean z11 = Math.abs(i13 - i11) > Math.abs(i12 - i10);
        if (z11) {
            i16 = i10;
            i17 = i11;
            i14 = i12;
            i15 = i13;
        } else {
            i17 = i10;
            i16 = i11;
            i15 = i12;
            i14 = i13;
        }
        int abs = Math.abs(i15 - i17);
        int abs2 = Math.abs(i14 - i16);
        int i20 = (-abs) / 2;
        int i21 = -1;
        int i22 = i17 < i15 ? 1 : -1;
        if (i16 < i14) {
            i21 = 1;
        }
        int i23 = i15 + i22;
        int i24 = i17;
        int i25 = i16;
        int i26 = 0;
        while (true) {
            if (i24 == i23) {
                i18 = i23;
                break;
            }
            int i27 = z11 ? i25 : i24;
            int i28 = z11 ? i24 : i25;
            if (i26 == i19) {
                cVar = this;
                z4 = z11;
                i18 = i23;
                z10 = true;
            } else {
                cVar = this;
                z4 = z11;
                i18 = i23;
                z10 = false;
            }
            if (z10 == ((b) cVar.f536a).b(i27, i28)) {
                if (i26 == 2) {
                    return f9.g(i24, i25, i17, i16);
                }
                i26++;
            }
            i20 += abs2;
            if (i20 > 0) {
                if (i25 == i14) {
                    break;
                }
                i25 += i21;
                i20 -= abs;
            }
            i24 += i22;
            i23 = i18;
            z11 = z4;
            i19 = 1;
        }
        if (i26 == 2) {
            return f9.g(i18, i14, i17, i16);
        }
        return Float.NaN;
    }

    public final void D(Throwable th2) {
        je.a();
        c0.g gVar = (c0.g) this.f536a;
        Object obj = this.f537b;
        if (gVar == ((c0.g) ((q.f) obj).f24802c)) {
            ((q.f) obj).f24802c = null;
        }
    }

    public final float E(int i10, int i11, int i12, int i13) {
        float f10;
        float f11;
        float C = C(i10, i11, i12, i13);
        int i14 = i10 - (i12 - i10);
        int i15 = 0;
        if (i14 < 0) {
            f10 = ((float) i10) / ((float) (i10 - i14));
            i14 = 0;
        } else {
            Object obj = this.f536a;
            if (i14 >= ((b) obj).f22657a) {
                int i16 = ((b) obj).f22657a - 1;
                f10 = ((float) ((((b) obj).f22657a - 1) - i10)) / ((float) (i14 - i10));
                i14 = i16;
            } else {
                f10 = 1.0f;
            }
        }
        float f12 = (float) i11;
        int i17 = (int) (f12 - (((float) (i13 - i11)) * f10));
        if (i17 < 0) {
            f11 = f12 / ((float) (i11 - i17));
        } else {
            Object obj2 = this.f536a;
            if (i17 >= ((b) obj2).f22658b) {
                f11 = ((float) ((((b) obj2).f22658b - 1) - i11)) / ((float) (i17 - i11));
                i15 = ((b) obj2).f22658b - 1;
            } else {
                i15 = i17;
                f11 = 1.0f;
            }
        }
        return (C(i10, i11, (int) ((((float) (i14 - i10)) * f11) + ((float) i10)), i15) + C) - 1.0f;
    }

    public final int F(n nVar, n nVar2) {
        boolean z4;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        n nVar3 = nVar;
        n nVar4 = nVar2;
        int i15 = (int) nVar3.f20209a;
        int i16 = (int) nVar3.f20210b;
        int i17 = (int) nVar4.f20209a;
        int i18 = 1;
        int min = Math.min(((b) this.f536a).f22658b - 1, (int) nVar4.f20210b);
        int i19 = 0;
        if (Math.abs(min - i16) > Math.abs(i17 - i15)) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z4) {
            int i20 = i15;
            i15 = i16;
            i16 = i20;
            int i21 = i17;
            i17 = min;
            min = i21;
        }
        int abs = Math.abs(i17 - i15);
        int abs2 = Math.abs(min - i16);
        int i22 = (-abs) / 2;
        if (i16 < min) {
            i10 = 1;
        } else {
            i10 = -1;
        }
        if (i15 >= i17) {
            i18 = -1;
        }
        b bVar = (b) this.f536a;
        if (z4) {
            i11 = i16;
        } else {
            i11 = i15;
        }
        if (z4) {
            i12 = i15;
        } else {
            i12 = i16;
        }
        boolean b5 = bVar.b(i11, i12);
        while (i15 != i17) {
            b bVar2 = (b) this.f536a;
            if (z4) {
                i13 = i16;
            } else {
                i13 = i15;
            }
            if (z4) {
                i14 = i15;
            } else {
                i14 = i16;
            }
            boolean b10 = bVar2.b(i13, i14);
            if (b10 != b5) {
                i19++;
                b5 = b10;
            }
            i22 += abs2;
            if (i22 > 0) {
                if (i16 == min) {
                    break;
                }
                i16 += i10;
                i22 -= abs;
            }
            i15 += i18;
        }
        return i19;
    }

    public final void H() {
        ((m) ((j) this.f537b).f1371c).getClass();
        throw null;
    }

    public final Object a() {
        Context context = ((e) ((o9.c) this.f536a)).f22986a.f30695a;
        if (context != null) {
            return new n9.j(context, (n9.k) ((o9.c) this.f537b).a());
        }
        throw new NullPointerException("Cannot return null from a non-@Nullable @Provides method");
    }

    public final void b(i.j jVar, int i10) {
        ActionBar actionBar = ((Activity) this.f536a).getActionBar();
        if (actionBar != null) {
            h.e.b(actionBar, jVar);
            h.e.a(actionBar, i10);
        }
    }

    public final boolean c() {
        ActionBar actionBar = ((Activity) this.f536a).getActionBar();
        return (actionBar == null || (actionBar.getDisplayOptions() & 4) == 0) ? false : true;
    }

    public final void d(Executor executor, g1 g1Var) {
        synchronized (((Map) this.f537b)) {
            s0 s0Var = (s0) ((Map) this.f537b).get(g1Var);
            if (s0Var != null) {
                s0Var.f3448a.set(false);
            }
            s0 s0Var2 = new s0(executor, g1Var);
            ((Map) this.f537b).put(g1Var, s0Var2);
            ua.n().execute(new h(this, s0Var, s0Var2, 3));
        }
    }

    public final float e(cd.c cVar, cd.c cVar2) {
        int i10 = (int) cVar.f20210b;
        int i11 = (int) cVar2.f20210b;
        float E = E((int) cVar.f20209a, i10, (int) cVar2.f20209a, i11);
        float E2 = E((int) cVar2.f20209a, i11, (int) cVar.f20209a, i10);
        if (Float.isNaN(E)) {
            return E2 / 7.0f;
        }
        if (Float.isNaN(E2)) {
            return E / 7.0f;
        }
        return (E + E2) / 14.0f;
    }

    public final void f(int i10) {
        ActionBar actionBar = ((Activity) this.f536a).getActionBar();
        if (actionBar != null) {
            h.e.a(actionBar, i10);
        }
    }

    public final p h(com.google.android.gms.internal.measurement.n nVar) {
        p g10 = ((p) this.f536a).g();
        String str = (String) this.f537b;
        g10.k(str, nVar);
        ((Map) g10.f566d).put(str, Boolean.TRUE);
        return g10;
    }

    public final void i(f7.g gVar, Object obj) {
        f.c.w(this.f537b);
        i7.h hVar = new i7.h((d8.i) obj);
        i7.d dVar = (i7.d) ((i7.j) gVar).p();
        Parcel Z = dVar.Z();
        q7.b.d(Z, hVar);
        q7.b.d(Z, (IInterface) null);
        dVar.k0(Z, 6);
    }

    public final Context j() {
        ActionBar actionBar = ((Activity) this.f536a).getActionBar();
        return actionBar != null ? actionBar.getThemedContext() : (Activity) this.f536a;
    }

    public void k(v vVar) {
        g((CameraDevice) this.f536a, vVar);
        u uVar = vVar.f27467a;
        if (uVar.f() != null) {
            throw new IllegalArgumentException("Reprocessing sessions not supported until API 23");
        } else if (uVar.c() != 1) {
            u.n nVar = new u.n(uVar.g(), uVar.d());
            try {
                ((CameraDevice) this.f536a).createCaptureSession(G(uVar.e()), nVar, ((y) this.f537b).f26934a);
            } catch (CameraAccessException e10) {
                throw new u.g(e10);
            }
        } else {
            throw new IllegalArgumentException("High speed capture sessions not supported until API 23");
        }
    }

    public final cd.a l(float f10, float f11, int i10, int i11) {
        int i12;
        b bVar;
        cd.a b5;
        cd.a b10;
        int i13 = (int) (f11 * f10);
        int max = Math.max(0, i10 - i13);
        int min = Math.min(((b) this.f536a).f22657a - 1, i10 + i13) - max;
        float f12 = 3.0f * f10;
        if (((float) min) >= f12) {
            int max2 = Math.max(0, i11 - i13);
            int min2 = Math.min(((b) this.f536a).f22658b - 1, i11 + i13) - max2;
            if (((float) min2) >= f12) {
                f.c.w(this.f537b);
                cd.b bVar2 = new cd.b((b) this.f536a, max, max2, min, min2, f10);
                int i14 = bVar2.f4130e;
                int i15 = bVar2.f4128c;
                int i16 = i14 + i15;
                int i17 = bVar2.f4131f;
                int i18 = (i17 / 2) + bVar2.f4129d;
                int[] iArr = new int[3];
                for (int i19 = 0; i19 < i17; i19++) {
                    if ((i19 & 1) == 0) {
                        i12 = (i19 + 1) / 2;
                    } else {
                        i12 = -((i19 + 1) / 2);
                    }
                    int i20 = i12 + i18;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    iArr[2] = 0;
                    int i21 = i15;
                    while (true) {
                        bVar = bVar2.f4126a;
                        if (i21 >= i16 || bVar.b(i21, i20)) {
                            int i22 = 0;
                        } else {
                            i21++;
                        }
                    }
                    int i222 = 0;
                    while (i21 < i16) {
                        if (!bVar.b(i21, i20)) {
                            if (i222 == 1) {
                                i222++;
                            }
                            iArr[i222] = iArr[i222] + 1;
                        } else if (i222 == 1) {
                            iArr[1] = iArr[1] + 1;
                        } else if (i222 != 2) {
                            i222++;
                            iArr[i222] = iArr[i222] + 1;
                        } else if (bVar2.a(iArr) && (b10 = bVar2.b(i20, i21, iArr)) != null) {
                            return b10;
                        } else {
                            iArr[0] = iArr[2];
                            iArr[1] = 1;
                            iArr[2] = 0;
                            i222 = 1;
                        }
                        i21++;
                    }
                    if (bVar2.a(iArr) && (b5 = bVar2.b(i20, i16, iArr)) != null) {
                        return b5;
                    }
                }
                ArrayList arrayList = bVar2.f4127b;
                if (!arrayList.isEmpty()) {
                    return (cd.a) arrayList.get(0);
                }
                throw ic.h.a();
            }
            throw ic.h.a();
        }
        throw ic.h.a();
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0046  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.google.android.datatransport.cct.CctBackendFactory m(java.lang.String r15) {
        /*
            r14 = this;
            java.lang.String r0 = "Could not instantiate %s."
            java.lang.String r1 = "Could not instantiate %s"
            java.lang.Object r2 = r14.f537b
            java.util.Map r2 = (java.util.Map) r2
            r3 = 0
            java.lang.String r4 = "BackendRegistry"
            r5 = 0
            if (r2 != 0) goto L_0x0098
            java.lang.Object r2 = r14.f536a
            android.content.Context r2 = (android.content.Context) r2
            android.content.pm.PackageManager r6 = r2.getPackageManager()     // Catch:{ NameNotFoundException -> 0x0034 }
            if (r6 != 0) goto L_0x001f
            java.lang.String r2 = "Context has no PackageManager."
        L_0x001a:
            android.util.Log.w(r4, r2)     // Catch:{ NameNotFoundException -> 0x0034 }
        L_0x001d:
            r2 = r3
            goto L_0x003a
        L_0x001f:
            android.content.ComponentName r7 = new android.content.ComponentName     // Catch:{ NameNotFoundException -> 0x0034 }
            java.lang.Class<com.google.android.datatransport.runtime.backends.TransportBackendDiscovery> r8 = com.google.android.datatransport.runtime.backends.TransportBackendDiscovery.class
            r7.<init>(r2, r8)     // Catch:{ NameNotFoundException -> 0x0034 }
            r2 = 128(0x80, float:1.794E-43)
            android.content.pm.ServiceInfo r2 = r6.getServiceInfo(r7, r2)     // Catch:{ NameNotFoundException -> 0x0034 }
            if (r2 != 0) goto L_0x0031
            java.lang.String r2 = "TransportBackendDiscovery has no service info."
            goto L_0x001a
        L_0x0031:
            android.os.Bundle r2 = r2.metaData     // Catch:{ NameNotFoundException -> 0x0034 }
            goto L_0x003a
        L_0x0034:
            java.lang.String r2 = "Application info not found."
            android.util.Log.w(r4, r2)
            goto L_0x001d
        L_0x003a:
            if (r2 != 0) goto L_0x0046
            java.lang.String r2 = "Could not retrieve metadata, returning empty list of transport backends."
            android.util.Log.w(r4, r2)
            java.util.Map r2 = java.util.Collections.emptyMap()
            goto L_0x0096
        L_0x0046:
            java.util.HashMap r6 = new java.util.HashMap
            r6.<init>()
            java.util.Set r7 = r2.keySet()
            java.util.Iterator r7 = r7.iterator()
        L_0x0053:
            boolean r8 = r7.hasNext()
            if (r8 == 0) goto L_0x0095
            java.lang.Object r8 = r7.next()
            java.lang.String r8 = (java.lang.String) r8
            java.lang.Object r9 = r2.get(r8)
            boolean r10 = r9 instanceof java.lang.String
            if (r10 == 0) goto L_0x0053
            java.lang.String r10 = "backend:"
            boolean r10 = r8.startsWith(r10)
            if (r10 == 0) goto L_0x0053
            java.lang.String r9 = (java.lang.String) r9
            java.lang.String r10 = ","
            r11 = -1
            java.lang.String[] r9 = r9.split(r10, r11)
            int r10 = r9.length
            r11 = 0
        L_0x007a:
            if (r11 >= r10) goto L_0x0053
            r12 = r9[r11]
            java.lang.String r12 = r12.trim()
            boolean r13 = r12.isEmpty()
            if (r13 == 0) goto L_0x0089
            goto L_0x0092
        L_0x0089:
            r13 = 8
            java.lang.String r13 = r8.substring(r13)
            r6.put(r12, r13)
        L_0x0092:
            int r11 = r11 + 1
            goto L_0x007a
        L_0x0095:
            r2 = r6
        L_0x0096:
            r14.f537b = r2
        L_0x0098:
            java.lang.Object r2 = r14.f537b
            java.util.Map r2 = (java.util.Map) r2
            java.lang.Object r15 = r2.get(r15)
            java.lang.String r15 = (java.lang.String) r15
            if (r15 != 0) goto L_0x00a5
            return r3
        L_0x00a5:
            r2 = 1
            java.lang.Class r6 = java.lang.Class.forName(r15)     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            java.lang.Class<com.google.android.datatransport.cct.CctBackendFactory> r7 = com.google.android.datatransport.cct.CctBackendFactory.class
            java.lang.Class r6 = r6.asSubclass(r7)     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            java.lang.Class[] r7 = new java.lang.Class[r5]     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            java.lang.reflect.Constructor r6 = r6.getDeclaredConstructor(r7)     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            java.lang.Object[] r7 = new java.lang.Object[r5]     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            java.lang.Object r6 = r6.newInstance(r7)     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            com.google.android.datatransport.cct.CctBackendFactory r6 = (com.google.android.datatransport.cct.CctBackendFactory) r6     // Catch:{ ClassNotFoundException -> 0x00c7, IllegalAccessException -> 0x00c5, InstantiationException -> 0x00c3, NoSuchMethodException -> 0x00c1, InvocationTargetException -> 0x00bf }
            return r6
        L_0x00bf:
            r0 = move-exception
            goto L_0x00c9
        L_0x00c1:
            r0 = move-exception
            goto L_0x00d5
        L_0x00c3:
            r1 = move-exception
            goto L_0x00de
        L_0x00c5:
            r1 = move-exception
            goto L_0x00ea
        L_0x00c7:
            r0 = move-exception
            goto L_0x00f3
        L_0x00c9:
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r2[r5] = r15
            java.lang.String r15 = java.lang.String.format(r1, r2)
        L_0x00d1:
            android.util.Log.w(r4, r15, r0)
            goto L_0x00fe
        L_0x00d5:
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r2[r5] = r15
            java.lang.String r15 = java.lang.String.format(r1, r2)
            goto L_0x00d1
        L_0x00de:
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r2[r5] = r15
            java.lang.String r15 = java.lang.String.format(r0, r2)
        L_0x00e6:
            android.util.Log.w(r4, r15, r1)
            goto L_0x00fe
        L_0x00ea:
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r2[r5] = r15
            java.lang.String r15 = java.lang.String.format(r0, r2)
            goto L_0x00e6
        L_0x00f3:
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r1[r5] = r15
            java.lang.String r15 = "Class %s is not found."
            java.lang.String r15 = java.lang.String.format(r15, r1)
            goto L_0x00d1
        L_0x00fe:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c.m(java.lang.String):com.google.android.datatransport.cct.CctBackendFactory");
    }

    public final r n(Object obj) {
        if (((ra.a) obj) == null) {
            Log.w("FirebaseCrashlytics", "Received null app settings at app startup. Cannot send cached reports", (Throwable) null);
        } else {
            la.n.b((la.n) ((e) ((d0.b) this.f537b).f17614c).f542c);
            ((la.n) ((e) ((d0.b) this.f537b).f17614c).f542c).f21802m.z((Executor) this.f536a, (String) null);
            ((la.n) ((e) ((d0.b) this.f537b).f17614c).f542c).f21806q.d((Object) null);
        }
        return b0.m0((Object) null);
    }

    public final boolean o(String str, boolean z4) {
        String u10 = u(str);
        if (u10 == null || u10.length() == 0) {
            return z4;
        }
        try {
            return Boolean.parseBoolean(u10);
        } catch (Exception unused) {
            return z4;
        }
    }

    public final /* bridge */ /* synthetic */ void onSuccess(Object obj) {
        Void voidR = (Void) obj;
    }

    public final File p() {
        if (((File) this.f536a) == null) {
            synchronized (this) {
                try {
                    if (((File) this.f536a) == null) {
                        aa.g gVar = (aa.g) this.f537b;
                        gVar.a();
                        File filesDir = gVar.f756a.getFilesDir();
                        this.f536a = new File(filesDir, "PersistedInstallation." + ((aa.g) this.f537b).d() + ".json");
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        return (File) this.f536a;
    }

    public final ArrayList q(String str) {
        a0 p5 = a0.p(1, "SELECT work_spec_id FROM dependency WHERE prerequisite_id=?");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        ((x) this.f536a).b();
        Cursor i10 = ne.c0.i((x) this.f536a, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                arrayList.add(i10.isNull(0) ? null : i10.getString(0));
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final int r(String str, int i10) {
        String u10 = u(str);
        if (u10 == null || u10.length() == 0) {
            return i10;
        }
        try {
            return Integer.parseInt(u10);
        } catch (Exception unused) {
            return i10;
        }
    }

    public final String s(String str, String str2) {
        String u10 = u(str);
        return (u10 == null || u10.length() == 0) ? str2 : u10;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v46, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r29v1, resolved type: java.util.List} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v150, resolved type: java.util.ArrayList} */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x03c6, code lost:
        r0 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:371:0x09d3, code lost:
        if (r1 < r7) goto L_0x0a00;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x01e7, code lost:
        if (r4.contains(r15) != false) goto L_0x02d9;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x02db  */
    /* JADX WARNING: Removed duplicated region for block: B:273:0x0738  */
    /* JADX WARNING: Removed duplicated region for block: B:288:0x0785  */
    /* JADX WARNING: Removed duplicated region for block: B:400:0x0a45  */
    /* JADX WARNING: Removed duplicated region for block: B:486:0x0c6a  */
    /* JADX WARNING: Removed duplicated region for block: B:504:0x0cb5  */
    /* JADX WARNING: Removed duplicated region for block: B:596:0x02f8 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:656:0x0a8c A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.util.Pair t(int r42, java.lang.String r43, java.util.ArrayList r44, java.util.HashMap r45) {
        /*
            r41 = this;
            r9 = r42
            r0 = r43
            r10 = r44
            boolean r1 = r45.isEmpty()
            r11 = 1
            r1 = r1 ^ r11
            java.lang.String r2 = "No new use cases to be bound."
            w7.ua.b(r2, r1)
            r12 = r41
            java.lang.Object r1 = r12.f536a
            java.util.Map r1 = (java.util.Map) r1
            java.lang.Object r1 = r1.get(r0)
            r13 = r1
            t.v1 r13 = (t.v1) r13
            if (r13 == 0) goto L_0x0e63
            t.d1 r0 = r13.f26419s
            android.util.Size r1 = r0.a()
            r0.f26221b = r1
            b0.h r0 = r13.f26417q
            if (r0 != 0) goto L_0x0030
            r13.b()
            goto L_0x004c
        L_0x0030:
            t.d1 r0 = r13.f26419s
            android.util.Size r4 = r0.e()
            b0.h r0 = r13.f26417q
            android.util.Size r2 = r0.f3346a
            java.util.Map r3 = r0.f3347b
            java.util.Map r5 = r0.f3349d
            android.util.Size r6 = r0.f3350e
            java.util.Map r7 = r0.f3351f
            java.util.Map r8 = r0.f3352g
            b0.h r0 = new b0.h
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6, r7, r8)
            r13.f26417q = r0
        L_0x004c:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.Iterator r1 = r44.iterator()
        L_0x0055:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0067
            java.lang.Object r2 = r1.next()
            b0.a r2 = (b0.a) r2
            b0.g r2 = r2.f3276a
            r0.add(r2)
            goto L_0x0055
        L_0x0067:
            java.util.ArrayList r14 = new java.util.ArrayList
            java.util.Set r1 = r45.keySet()
            r14.<init>(r1)
            java.util.ArrayList r15 = new java.util.ArrayList
            r15.<init>()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Iterator r2 = r14.iterator()
        L_0x007e:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x00a0
            java.lang.Object r3 = r2.next()
            b0.p1 r3 = (b0.p1) r3
            int r3 = r3.G()
            java.lang.Integer r4 = java.lang.Integer.valueOf(r3)
            boolean r4 = r1.contains(r4)
            if (r4 != 0) goto L_0x007e
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1.add(r3)
            goto L_0x007e
        L_0x00a0:
            java.util.Collections.sort(r1)
            java.util.Collections.reverse(r1)
            java.util.Iterator r1 = r1.iterator()
        L_0x00aa:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x00dc
            java.lang.Object r2 = r1.next()
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            java.util.Iterator r3 = r14.iterator()
        L_0x00be:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x00aa
            java.lang.Object r4 = r3.next()
            b0.p1 r4 = (b0.p1) r4
            int r5 = r4.G()
            if (r2 != r5) goto L_0x00be
            int r4 = r14.indexOf(r4)
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r15.add(r4)
            goto L_0x00be
        L_0x00dc:
            t.f1 r1 = r13.f26422v
            r1.getClass()
            java.util.LinkedHashSet r2 = new java.util.LinkedHashSet
            r2.<init>()
            java.util.Iterator r3 = r44.iterator()
        L_0x00ea:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x00fc
            java.lang.Object r4 = r3.next()
            b0.a r4 = (b0.a) r4
            z.v r4 = r4.f3279d
            r2.add(r4)
            goto L_0x00ea
        L_0x00fc:
            java.lang.Object r3 = r1.f26239d
            h.z r3 = (h.z) r3
            java.lang.Object r3 = r3.f19485b
            v.b r3 = (v.b) r3
            java.util.Set r3 = r3.c()
            java.util.HashSet r4 = new java.util.HashSet
            r4.<init>(r3)
            java.util.Iterator r5 = r2.iterator()
        L_0x0111:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0125
            java.lang.Object r6 = r5.next()
            z.v r6 = (z.v) r6
            java.lang.Object r7 = r1.f26239d
            h.z r7 = (h.z) r7
            t.f1.p(r4, r6, r7)
            goto L_0x0111
        L_0x0125:
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            java.util.Iterator r8 = r15.iterator()
        L_0x0138:
            boolean r16 = r8.hasNext()
            if (r16 == 0) goto L_0x0183
            java.lang.Object r16 = r8.next()
            java.lang.Integer r16 = (java.lang.Integer) r16
            int r11 = r16.intValue()
            java.lang.Object r11 = r14.get(r11)
            b0.p1 r11 = (b0.p1) r11
            r16 = r8
            z.v r8 = r11.q()
            z.v r12 = z.v.f30551c
            boolean r12 = java.util.Objects.equals(r8, r12)
            if (r12 == 0) goto L_0x0162
            r7.add(r11)
            r18 = r15
            goto L_0x017b
        L_0x0162:
            int r12 = r8.f30558a
            r18 = r15
            r15 = 2
            if (r12 == r15) goto L_0x0178
            int r8 = r8.f30559b
            if (r12 == 0) goto L_0x016f
            if (r8 == 0) goto L_0x0178
        L_0x016f:
            if (r12 != 0) goto L_0x0174
            if (r8 == 0) goto L_0x0174
            goto L_0x0178
        L_0x0174:
            r5.add(r11)
            goto L_0x017b
        L_0x0178:
            r6.add(r11)
        L_0x017b:
            r12 = r41
            r8 = r16
            r15 = r18
            r11 = 1
            goto L_0x0138
        L_0x0183:
            r18 = r15
            java.util.HashMap r11 = new java.util.HashMap
            r11.<init>()
            java.util.LinkedHashSet r8 = new java.util.LinkedHashSet
            r8.<init>()
            java.util.ArrayList r12 = new java.util.ArrayList
            r12.<init>()
            r12.addAll(r5)
            r12.addAll(r6)
            r12.addAll(r7)
            java.util.Iterator r5 = r12.iterator()
        L_0x01a1:
            boolean r6 = r5.hasNext()
            z.v r15 = z.v.f30552d
            r19 = 0
            if (r6 == 0) goto L_0x0321
            java.lang.Object r6 = r5.next()
            b0.p1 r6 = (b0.p1) r6
            z.v r7 = r6.q()
            java.lang.String r22 = r6.t()
            boolean r23 = r7.b()
            if (r23 == 0) goto L_0x01d4
            boolean r15 = r4.contains(r7)
            r25 = r0
            r24 = r5
            if (r15 == 0) goto L_0x01ce
            r15 = r7
            r26 = r14
            goto L_0x02d9
        L_0x01ce:
            r26 = r14
        L_0x01d0:
            r15 = r19
            goto L_0x02d9
        L_0x01d4:
            int r12 = r7.f30558a
            r24 = r5
            int r5 = r7.f30559b
            r10 = 1
            if (r12 != r10) goto L_0x01eb
            if (r5 != 0) goto L_0x01eb
            boolean r5 = r4.contains(r15)
            r25 = r0
            r26 = r14
            if (r5 == 0) goto L_0x01d0
            goto L_0x02d9
        L_0x01eb:
            z.v r10 = t.f1.n(r7, r2, r4)
            r25 = r0
            java.lang.String r0 = "DynamicRangeResolver"
            r26 = r14
            if (r10 == 0) goto L_0x0211
            r14 = 3
            java.lang.Object[] r5 = new java.lang.Object[r14]
            r20 = 0
            r5[r20] = r22
            r17 = 1
            r5[r17] = r7
            r12 = 2
            r5[r12] = r10
            java.lang.String r15 = "Resolved dynamic range for use case %s from existing attached surface.\n%s\n->\n%s"
            java.lang.String r5 = java.lang.String.format(r15, r5)
        L_0x020b:
            v7.t9.a(r0, r5)
            r15 = r10
            goto L_0x02d9
        L_0x0211:
            r10 = 2
            r14 = 3
            r17 = 1
            r20 = 0
            z.v r23 = t.f1.n(r7, r8, r4)
            if (r23 == 0) goto L_0x0232
            java.lang.Object[] r5 = new java.lang.Object[r14]
            r5[r20] = r22
            r5[r17] = r7
            r5[r10] = r23
            java.lang.String r12 = "Resolved dynamic range for use case %s from concurrently bound use case.\n%s\n->\n%s"
            java.lang.String r5 = java.lang.String.format(r12, r5)
            v7.t9.a(r0, r5)
            r15 = r23
            goto L_0x02d9
        L_0x0232:
            boolean r23 = t.f1.i(r7, r15, r4)
            if (r23 == 0) goto L_0x024b
            java.lang.Object[] r5 = new java.lang.Object[r14]
            r5[r20] = r22
            r5[r17] = r7
            r5[r10] = r15
            java.lang.String r12 = "Resolved dynamic range for use case %s to no compatible HDR dynamic ranges.\n%s\n->\n%s"
            java.lang.String r5 = java.lang.String.format(r12, r5)
            v7.t9.a(r0, r5)
            goto L_0x02d9
        L_0x024b:
            if (r12 != r10) goto L_0x029f
            r10 = 10
            if (r5 == r10) goto L_0x0253
            if (r5 != 0) goto L_0x029f
        L_0x0253:
            java.util.LinkedHashSet r5 = new java.util.LinkedHashSet
            r5.<init>()
            int r10 = android.os.Build.VERSION.SDK_INT
            r12 = 33
            if (r10 < r12) goto L_0x026c
            java.lang.Object r10 = r1.f26238c
            u.s r10 = (u.s) r10
            z.v r10 = t.e1.a(r10)
            if (r10 == 0) goto L_0x026e
            r5.add(r10)
            goto L_0x026e
        L_0x026c:
            r10 = r19
        L_0x026e:
            z.v r12 = z.v.f30553e
            r5.add(r12)
            z.v r5 = t.f1.n(r7, r5, r4)
            if (r5 == 0) goto L_0x029f
            r12 = 4
            java.lang.Object[] r14 = new java.lang.Object[r12]
            r12 = 0
            r14[r12] = r22
            boolean r10 = r5.equals(r10)
            if (r10 == 0) goto L_0x0289
            java.lang.String r10 = "recommended"
        L_0x0287:
            r12 = 1
            goto L_0x028c
        L_0x0289:
            java.lang.String r10 = "required"
            goto L_0x0287
        L_0x028c:
            r14[r12] = r10
            r10 = 2
            r14[r10] = r7
            r10 = 3
            r14[r10] = r5
            java.lang.String r10 = "Resolved dynamic range for use case %s from %s 10-bit supported dynamic range.\n%s\n->\n%s"
            java.lang.String r10 = java.lang.String.format(r10, r14)
            v7.t9.a(r0, r10)
            r15 = r5
            goto L_0x02d9
        L_0x029f:
            java.util.Iterator r5 = r4.iterator()
        L_0x02a3:
            boolean r10 = r5.hasNext()
            if (r10 == 0) goto L_0x01d0
            java.lang.Object r10 = r5.next()
            z.v r10 = (z.v) r10
            boolean r12 = r10.b()
            java.lang.String r14 = "Candidate dynamic range must be fully specified."
            w7.ua.g(r14, r12)
            boolean r12 = r10.equals(r15)
            if (r12 == 0) goto L_0x02bf
            goto L_0x02a3
        L_0x02bf:
            boolean r12 = t.f1.h(r7, r10)
            if (r12 == 0) goto L_0x02a3
            r12 = 3
            java.lang.Object[] r5 = new java.lang.Object[r12]
            r12 = 0
            r5[r12] = r22
            r12 = 1
            r5[r12] = r7
            r12 = 2
            r5[r12] = r10
            java.lang.String r12 = "Resolved dynamic range for use case %s from validated dynamic range constraints or supported HDR dynamic ranges.\n%s\n->\n%s"
            java.lang.String r5 = java.lang.String.format(r12, r5)
            goto L_0x020b
        L_0x02d9:
            if (r15 == 0) goto L_0x02f8
            java.lang.Object r0 = r1.f26239d
            h.z r0 = (h.z) r0
            t.f1.p(r4, r15, r0)
            r11.put(r6, r15)
            boolean r0 = r2.contains(r15)
            if (r0 != 0) goto L_0x02ee
            r8.add(r15)
        L_0x02ee:
            r10 = r44
            r5 = r24
            r0 = r25
            r14 = r26
            goto L_0x01a1
        L_0x02f8:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = 4
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.String r2 = r6.t()
            r5 = 0
            r1[r5] = r2
            r2 = 1
            r1[r2] = r7
            java.lang.String r2 = "\n  "
            java.lang.String r3 = android.text.TextUtils.join(r2, r3)
            r5 = 2
            r1[r5] = r3
            java.lang.String r2 = android.text.TextUtils.join(r2, r4)
            r3 = 3
            r1[r3] = r2
            java.lang.String r2 = "Unable to resolve supported dynamic range. The dynamic range may not be supported on the device or may not be allowed concurrently with other attached use cases.\nUse case:\n  %s\nRequested dynamic range:\n  %s\nSupported dynamic ranges:\n  %s\nConstrained set of concurrent dynamic ranges:\n  %s"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.<init>(r1)
            throw r0
        L_0x0321:
            r25 = r0
            r26 = r14
            r1 = 4
            r3 = 3
            r12 = 33
            java.util.Collection r0 = r11.values()
            java.util.Iterator r0 = r0.iterator()
        L_0x0331:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0346
            java.lang.Object r2 = r0.next()
            z.v r2 = (z.v) r2
            int r2 = r2.f30559b
            r10 = 10
            if (r2 != r10) goto L_0x0331
            r0 = 10
            goto L_0x034a
        L_0x0346:
            r10 = 10
            r0 = 8
        L_0x034a:
            t.d r14 = new t.d
            r14.<init>(r9, r0)
            if (r9 == 0) goto L_0x0376
            if (r0 != r10) goto L_0x0376
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = 2
            java.lang.Object[] r2 = new java.lang.Object[r1]
            java.lang.String r3 = r13.f26407g
            r4 = 0
            r2[r4] = r3
            r3 = 1
            if (r9 == r3) goto L_0x0368
            if (r9 == r1) goto L_0x0365
            java.lang.String r1 = "DEFAULT"
            goto L_0x036a
        L_0x0365:
            java.lang.String r1 = "ULTRA_HIGH_RESOLUTION_CAMERA"
            goto L_0x036a
        L_0x0368:
            java.lang.String r1 = "CONCURRENT_CAMERA"
        L_0x036a:
            r2[r3] = r1
            java.lang.String r1 = "No supported surface combination is found for camera device - Id : %s. Ten bit dynamic range is not currently supported in %s camera mode."
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.<init>(r1)
            throw r0
        L_0x0376:
            java.util.Iterator r0 = r26.iterator()
        L_0x037a:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x03a1
            java.lang.Object r2 = r0.next()
            b0.p1 r2 = (b0.p1) r2
            int r2 = r2.C()
            android.util.Size r4 = new android.util.Size
            r5 = 640(0x280, float:8.97E-43)
            r6 = 480(0x1e0, float:6.73E-43)
            r4.<init>(r5, r6)
            b0.h r5 = r13.i(r2)
            b0.g r2 = b0.g.a(r9, r2, r4, r5)
            r4 = r25
            r4.add(r2)
            goto L_0x037a
        L_0x03a1:
            r4 = r25
            b0.c r0 = t.s1.f26390a
            java.util.Iterator r0 = r44.iterator()
        L_0x03a9:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x03c8
            java.lang.Object r2 = r0.next()
            b0.a r2 = (b0.a) r2
            java.util.List r5 = r2.f3280e
            r6 = 0
            java.lang.Object r5 = r5.get(r6)
            b0.r1 r5 = (b0.r1) r5
            b0.d0 r2 = r2.f3281f
            boolean r2 = t.s1.c(r2, r5)
            if (r2 == 0) goto L_0x03a9
        L_0x03c6:
            r0 = 1
            goto L_0x03e4
        L_0x03c8:
            java.util.Iterator r0 = r26.iterator()
        L_0x03cc:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x03e3
            java.lang.Object r2 = r0.next()
            b0.p1 r2 = (b0.p1) r2
            b0.r1 r5 = r2.g()
            boolean r2 = t.s1.c(r2, r5)
            if (r2 == 0) goto L_0x03cc
            goto L_0x03c6
        L_0x03e3:
            r0 = 0
        L_0x03e4:
            boolean r2 = r13.f26415o
            if (r2 == 0) goto L_0x03ef
            if (r0 != 0) goto L_0x03ef
            java.util.List r0 = r13.d(r14, r4)
            goto L_0x03f1
        L_0x03ef:
            r0 = r19
        L_0x03f1:
            boolean r10 = r13.a(r14, r4)
            java.lang.String r8 = ".  May be attempting to bind too many use cases. Existing surfaces: "
            java.lang.String r7 = " New configs: "
            java.lang.String r6 = "No supported surface combination is found for camera device - Id : "
            if (r0 != 0) goto L_0x03ff
            if (r10 == 0) goto L_0x0404
        L_0x03ff:
            r5 = r44
            r4 = r26
            goto L_0x0428
        L_0x0404:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r6)
            java.lang.String r2 = r13.f26407g
            r1.append(r2)
            r1.append(r8)
            r5 = r44
            r1.append(r5)
            r1.append(r7)
            r4 = r26
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0428:
            java.util.Iterator r2 = r44.iterator()
            r1 = r19
            r12 = 2147483647(0x7fffffff, float:NaN)
        L_0x0431:
            boolean r22 = r2.hasNext()
            if (r22 == 0) goto L_0x0459
            java.lang.Object r22 = r2.next()
            r3 = r22
            b0.a r3 = (b0.a) r3
            r22 = r2
            android.util.Range r2 = r3.f3282g
            if (r1 != 0) goto L_0x0447
            r1 = r2
            goto L_0x044d
        L_0x0447:
            if (r2 == 0) goto L_0x044d
            android.util.Range r1 = r1.intersect(r2)     // Catch:{ IllegalArgumentException -> 0x044d }
        L_0x044d:
            int r2 = r3.f3277b
            android.util.Size r3 = r3.f3278c
            int r12 = r13.h(r12, r2, r3)
            r2 = r22
            r3 = 3
            goto L_0x0431
        L_0x0459:
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Iterator r3 = r18.iterator()
        L_0x0462:
            boolean r22 = r3.hasNext()
            if (r22 == 0) goto L_0x0576
            java.lang.Object r22 = r3.next()
            java.lang.Integer r22 = (java.lang.Integer) r22
            r24 = r1
            int r1 = r22.intValue()
            java.lang.Object r1 = r4.get(r1)
            b0.p1 r1 = (b0.p1) r1
            r22 = r3
            r3 = r45
            java.lang.Object r25 = r3.get(r1)
            java.util.List r25 = (java.util.List) r25
            int r1 = r1.C()
            f9.f r3 = r13.f26420t
            r3.getClass()
            h.z r3 = w.k.f28507a
            java.lang.Class<w.y> r5 = w.y.class
            b0.z0 r3 = r3.f(r5)
            w.y r3 = (w.y) r3
            if (r3 == 0) goto L_0x049b
        L_0x0499:
            r3 = 2
            goto L_0x04ad
        L_0x049b:
            u.s r3 = r13.f26409i
            h.z r3 = l7.a.t(r3)
            java.lang.Class<w.c> r5 = w.c.class
            b0.z0 r3 = r3.f(r5)
            w.c r3 = (w.c) r3
            if (r3 == 0) goto L_0x04ac
            goto L_0x0499
        L_0x04ac:
            r3 = 3
        L_0x04ad:
            if (r3 == 0) goto L_0x04e1
            r5 = 1
            if (r3 == r5) goto L_0x04dc
            r5 = 2
            if (r3 == r5) goto L_0x04ba
            r27 = r6
            r5 = r19
            goto L_0x04e5
        L_0x04ba:
            r3 = 256(0x100, float:3.59E-43)
            b0.h r5 = r13.i(r3)
            r27 = r6
            java.lang.Integer r6 = java.lang.Integer.valueOf(r3)
            java.util.Map r3 = r5.f3351f
            java.lang.Object r3 = r3.get(r6)
            android.util.Size r3 = (android.util.Size) r3
            android.util.Rational r5 = new android.util.Rational
            int r6 = r3.getWidth()
            int r3 = r3.getHeight()
            r5.<init>(r6, r3)
            goto L_0x04e5
        L_0x04dc:
            r27 = r6
            android.util.Rational r5 = c0.b.f3715c
            goto L_0x04e5
        L_0x04e1:
            r27 = r6
            android.util.Rational r5 = c0.b.f3713a
        L_0x04e5:
            if (r5 != 0) goto L_0x04ea
            r29 = r7
            goto L_0x0520
        L_0x04ea:
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.Iterator r25 = r25.iterator()
        L_0x04f8:
            boolean r28 = r25.hasNext()
            if (r28 == 0) goto L_0x0518
            java.lang.Object r28 = r25.next()
            r29 = r7
            r7 = r28
            android.util.Size r7 = (android.util.Size) r7
            boolean r28 = c0.b.a(r7, r5)
            if (r28 == 0) goto L_0x0512
            r3.add(r7)
            goto L_0x0515
        L_0x0512:
            r6.add(r7)
        L_0x0515:
            r7 = r29
            goto L_0x04f8
        L_0x0518:
            r29 = r7
            r7 = 0
            r6.addAll(r7, r3)
            r25 = r6
        L_0x0520:
            r3 = 35
            if (r1 != r3) goto L_0x0526
            r1 = 2
            goto L_0x0533
        L_0x0526:
            r3 = 256(0x100, float:3.59E-43)
            if (r1 != r3) goto L_0x052c
            r1 = 3
            goto L_0x0533
        L_0x052c:
            r3 = 32
            if (r1 != r3) goto L_0x0532
            r1 = 4
            goto L_0x0533
        L_0x0532:
            r1 = 1
        L_0x0533:
            ha.c r3 = r13.f26421u
            java.lang.Object r3 = r3.f19652b
            w.m r3 = (w.m) r3
            if (r3 != 0) goto L_0x053e
        L_0x053b:
            r3 = r25
            goto L_0x0567
        L_0x053e:
            android.util.Size r1 = w.m.a(r1)
            if (r1 != 0) goto L_0x0545
            goto L_0x053b
        L_0x0545:
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r3.add(r1)
            java.util.Iterator r5 = r25.iterator()
        L_0x0551:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0567
            java.lang.Object r6 = r5.next()
            android.util.Size r6 = (android.util.Size) r6
            boolean r7 = r6.equals(r1)
            if (r7 != 0) goto L_0x0551
            r3.add(r6)
            goto L_0x0551
        L_0x0567:
            r2.add(r3)
            r5 = r44
            r3 = r22
            r1 = r24
            r6 = r27
            r7 = r29
            goto L_0x0462
        L_0x0576:
            r24 = r1
            r27 = r6
            r29 = r7
            java.util.Iterator r1 = r2.iterator()
            r3 = 1
        L_0x0581:
            boolean r5 = r1.hasNext()
            if (r5 == 0) goto L_0x0594
            java.lang.Object r5 = r1.next()
            java.util.List r5 = (java.util.List) r5
            int r5 = r5.size()
            int r3 = r3 * r5
            goto L_0x0581
        L_0x0594:
            if (r3 == 0) goto L_0x0e5b
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            r1 = 0
        L_0x059c:
            if (r1 >= r3) goto L_0x05a9
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            r7.add(r5)
            int r1 = r1 + 1
            goto L_0x059c
        L_0x05a9:
            r6 = 0
            java.lang.Object r1 = r2.get(r6)
            java.util.List r1 = (java.util.List) r1
            int r1 = r1.size()
            int r1 = r3 / r1
            r16 = r3
            r5 = 0
        L_0x05b9:
            int r6 = r2.size()
            if (r5 >= r6) goto L_0x060c
            java.lang.Object r6 = r2.get(r5)
            java.util.List r6 = (java.util.List) r6
            r22 = r8
            r8 = 0
        L_0x05c8:
            if (r8 >= r3) goto L_0x05e8
            java.lang.Object r23 = r7.get(r8)
            r45 = r3
            r3 = r23
            java.util.List r3 = (java.util.List) r3
            int r23 = r8 % r16
            int r9 = r23 / r1
            java.lang.Object r9 = r6.get(r9)
            android.util.Size r9 = (android.util.Size) r9
            r3.add(r9)
            int r8 = r8 + 1
            r9 = r42
            r3 = r45
            goto L_0x05c8
        L_0x05e8:
            r45 = r3
            int r3 = r2.size()
            r6 = 1
            int r3 = r3 - r6
            if (r5 >= r3) goto L_0x0603
            int r3 = r5 + 1
            java.lang.Object r3 = r2.get(r3)
            java.util.List r3 = (java.util.List) r3
            int r3 = r3.size()
            int r3 = r1 / r3
            r16 = r1
            r1 = r3
        L_0x0603:
            int r5 = r5 + 1
            r9 = r42
            r3 = r45
            r8 = r22
            goto L_0x05b9
        L_0x060c:
            r22 = r8
            java.util.Iterator r1 = r18.iterator()
            r9 = r24
        L_0x0614:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x063b
            java.lang.Object r2 = r1.next()
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            java.lang.Object r2 = r4.get(r2)
            b0.p1 r2 = (b0.p1) r2
            android.util.Range r2 = r2.B()
            if (r9 != 0) goto L_0x0632
        L_0x0630:
            r9 = r2
            goto L_0x0614
        L_0x0632:
            if (r2 == 0) goto L_0x0614
            android.util.Range r2 = r9.intersect(r2)     // Catch:{ IllegalArgumentException -> 0x0639 }
            goto L_0x0630
        L_0x0639:
            goto L_0x0614
        L_0x063b:
            java.util.HashMap r8 = new java.util.HashMap
            r8.<init>()
            java.util.HashMap r6 = new java.util.HashMap
            r6.<init>()
            java.util.HashMap r5 = new java.util.HashMap
            r5.<init>()
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            java.lang.String r2 = "SurfaceConfig does not map to any use case"
            if (r0 == 0) goto L_0x07fa
            java.util.Iterator r16 = r7.iterator()
        L_0x0657:
            boolean r1 = r16.hasNext()
            if (r1 == 0) goto L_0x07aa
            java.lang.Object r0 = r16.next()
            r23 = r0
            java.util.List r23 = (java.util.List) r23
            r0 = r13
            r1 = r42
            r24 = r11
            r11 = r2
            r2 = r44
            r45 = r3
            r3 = r23
            r26 = r4
            r25 = r5
            r23 = r15
            r15 = r44
            r5 = r18
            r30 = r6
            r20 = 0
            r40 = r27
            r27 = r9
            r9 = r40
            r6 = r12
            r20 = r7
            r28 = r12
            r32 = r29
            r12 = 0
            r7 = r25
            r34 = r8
            r33 = r22
            r8 = r45
            android.util.Pair r0 = r0.g(r1, r2, r3, r4, r5, r6, r7, r8)
            java.lang.Object r0 = r0.first
            java.util.List r0 = (java.util.List) r0
            java.util.List r0 = r13.d(r14, r0)
            if (r0 == 0) goto L_0x0732
            r7 = 0
        L_0x06a4:
            int r1 = r0.size()
            if (r7 >= r1) goto L_0x0732
            java.lang.Object r1 = r0.get(r7)
            b0.g r1 = (b0.g) r1
            long r1 = r1.f3331c
            java.lang.Integer r3 = java.lang.Integer.valueOf(r7)
            r8 = r25
            boolean r3 = r8.containsKey(r3)
            b0.r1 r4 = b0.r1.f3445e
            if (r3 == 0) goto L_0x06e4
            java.lang.Integer r3 = java.lang.Integer.valueOf(r7)
            java.lang.Object r3 = r8.get(r3)
            b0.a r3 = (b0.a) r3
            java.util.List r5 = r3.f3280e
            int r5 = r5.size()
            java.util.List r3 = r3.f3280e
            r6 = 1
            if (r5 != r6) goto L_0x06db
            java.lang.Object r4 = r3.get(r12)
            b0.r1 r4 = (b0.r1) r4
        L_0x06db:
            boolean r1 = t.s1.b(r4, r1, r3)
            r5 = r45
            if (r1 != 0) goto L_0x0723
            goto L_0x0720
        L_0x06e4:
            r6 = 1
            java.lang.Integer r3 = java.lang.Integer.valueOf(r7)
            r5 = r45
            boolean r3 = r5.containsKey(r3)
            if (r3 == 0) goto L_0x072c
            java.lang.Integer r3 = java.lang.Integer.valueOf(r7)
            java.lang.Object r3 = r5.get(r3)
            b0.p1 r3 = (b0.p1) r3
            b0.r1 r6 = r3.g()
            b0.r1 r12 = r3.g()
            if (r12 != r4) goto L_0x0716
            l0.b r3 = (l0.b) r3
            b0.c r4 = l0.b.f21549b
            b0.d0 r3 = r3.z()
            b0.x0 r3 = (b0.x0) r3
            java.lang.Object r3 = r3.r(r4)
            java.util.List r3 = (java.util.List) r3
            goto L_0x071a
        L_0x0716:
            java.util.List r3 = java.util.Collections.emptyList()
        L_0x071a:
            boolean r1 = t.s1.b(r6, r1, r3)
            if (r1 != 0) goto L_0x0723
        L_0x0720:
            r0 = r19
            goto L_0x0736
        L_0x0723:
            int r7 = r7 + 1
            r45 = r5
            r25 = r8
            r12 = 0
            goto L_0x06a4
        L_0x072c:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r0.<init>(r11)
            throw r0
        L_0x0732:
            r5 = r45
            r8 = r25
        L_0x0736:
            if (r0 == 0) goto L_0x0785
            u.s r1 = r13.f26409i
            int r2 = android.os.Build.VERSION.SDK_INT
            r12 = 33
            if (r2 >= r12) goto L_0x0741
            goto L_0x0782
        L_0x0741:
            android.hardware.camera2.CameraCharacteristics$Key r2 = android.hardware.camera2.CameraCharacteristics.SCALER_AVAILABLE_STREAM_USE_CASES
            java.lang.Object r1 = r1.a(r2)
            long[] r1 = (long[]) r1
            if (r1 == 0) goto L_0x0782
            int r2 = r1.length
            if (r2 != 0) goto L_0x0751
            goto L_0x0782
        L_0x0751:
            java.util.HashSet r2 = new java.util.HashSet
            r2.<init>()
            int r3 = r1.length
            r7 = 0
        L_0x0758:
            if (r7 >= r3) goto L_0x0766
            r35 = r1[r7]
            java.lang.Long r4 = java.lang.Long.valueOf(r35)
            r2.add(r4)
            int r7 = r7 + 1
            goto L_0x0758
        L_0x0766:
            java.util.Iterator r1 = r0.iterator()
        L_0x076a:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x07c9
            java.lang.Object r3 = r1.next()
            b0.g r3 = (b0.g) r3
            long r3 = r3.f3331c
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            boolean r3 = r2.contains(r3)
            if (r3 != 0) goto L_0x076a
        L_0x0782:
            r0 = r19
            goto L_0x0787
        L_0x0785:
            r12 = 33
        L_0x0787:
            r8.clear()
            r5.clear()
            r3 = r5
            r5 = r8
            r2 = r11
            r7 = r20
            r15 = r23
            r11 = r24
            r4 = r26
            r12 = r28
            r6 = r30
            r29 = r32
            r22 = r33
            r8 = r34
            r40 = r27
            r27 = r9
            r9 = r40
            goto L_0x0657
        L_0x07aa:
            r26 = r4
            r30 = r6
            r20 = r7
            r34 = r8
            r24 = r11
            r28 = r12
            r23 = r15
            r33 = r22
            r32 = r29
            r12 = 33
            r15 = r44
            r11 = r2
            r8 = r5
            r5 = r3
            r40 = r27
            r27 = r9
            r9 = r40
        L_0x07c9:
            if (r0 != 0) goto L_0x07cd
            if (r10 == 0) goto L_0x07d2
        L_0x07cd:
            r7 = r26
            r10 = r32
            goto L_0x07f8
        L_0x07d2:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r9)
            java.lang.String r2 = r13.f26407g
            r1.append(r2)
            r2 = r33
            r1.append(r2)
            r1.append(r15)
            r10 = r32
            r1.append(r10)
            r7 = r26
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x07f8:
            r6 = r0
            goto L_0x0817
        L_0x07fa:
            r30 = r6
            r20 = r7
            r34 = r8
            r24 = r11
            r28 = r12
            r23 = r15
            r10 = r29
            r12 = 33
            r15 = r44
            r11 = r2
            r7 = r4
            r8 = r5
            r5 = r3
            r40 = r27
            r27 = r9
            r9 = r40
            goto L_0x07f8
        L_0x0817:
            java.util.Iterator r16 = r20.iterator()
            r25 = r19
            r26 = r25
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 2147483647(0x7fffffff, float:NaN)
            r20 = 0
            r22 = 0
        L_0x0829:
            boolean r0 = r16.hasNext()
            if (r0 == 0) goto L_0x08ea
            java.lang.Object r0 = r16.next()
            r29 = r0
            java.util.List r29 = (java.util.List) r29
            r31 = 0
            r32 = 0
            r0 = r13
            r1 = r42
            r2 = r44
            r12 = r3
            r3 = r29
            r37 = r4
            r4 = r7
            r38 = r5
            r5 = r18
            r39 = r6
            r17 = 1
            r6 = r28
            r45 = r7
            r7 = r31
            r31 = r10
            r10 = r8
            r8 = r32
            android.util.Pair r0 = r0.g(r1, r2, r3, r4, r5, r6, r7, r8)
            java.lang.Object r1 = r0.first
            java.util.List r1 = (java.util.List) r1
            java.lang.Object r0 = r0.second
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r4 = r0.intValue()
            r0 = r28
            if (r27 == 0) goto L_0x087d
            if (r0 <= r4) goto L_0x087d
            java.lang.Comparable r2 = r27.getLower()
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            if (r4 >= r2) goto L_0x087d
            r7 = 0
            goto L_0x087e
        L_0x087d:
            r7 = 1
        L_0x087e:
            if (r20 != 0) goto L_0x08ab
            boolean r2 = r13.a(r14, r1)
            if (r2 == 0) goto L_0x08ab
            r3 = r37
            r2 = 2147483647(0x7fffffff, float:NaN)
            if (r3 != r2) goto L_0x088e
            goto L_0x0890
        L_0x088e:
            if (r3 >= r4) goto L_0x0893
        L_0x0890:
            r3 = r4
            r25 = r29
        L_0x0893:
            if (r7 == 0) goto L_0x08a8
            if (r22 == 0) goto L_0x08a0
            r3 = r12
            r1 = r26
            r0 = r29
            r2 = r39
            goto L_0x08fb
        L_0x08a0:
            r3 = r4
            r25 = r29
            r2 = r39
            r20 = 1
            goto L_0x08ae
        L_0x08a8:
            r2 = r39
            goto L_0x08ae
        L_0x08ab:
            r3 = r37
            goto L_0x08a8
        L_0x08ae:
            if (r2 == 0) goto L_0x08d7
            if (r22 != 0) goto L_0x08d7
            java.util.List r1 = r13.d(r14, r1)
            if (r1 == 0) goto L_0x08d7
            r1 = 2147483647(0x7fffffff, float:NaN)
            if (r12 != r1) goto L_0x08be
            goto L_0x08c0
        L_0x08be:
            if (r12 >= r4) goto L_0x08c3
        L_0x08c0:
            r12 = r4
            r26 = r29
        L_0x08c3:
            if (r7 == 0) goto L_0x08da
            if (r20 == 0) goto L_0x08d1
            r0 = r25
            r1 = r29
            r40 = r4
            r4 = r3
            r3 = r40
            goto L_0x08fb
        L_0x08d1:
            r12 = r4
            r26 = r29
            r22 = 1
            goto L_0x08da
        L_0x08d7:
            r1 = 2147483647(0x7fffffff, float:NaN)
        L_0x08da:
            r7 = r45
            r28 = r0
            r6 = r2
            r4 = r3
            r8 = r10
            r3 = r12
            r10 = r31
            r5 = r38
            r12 = 33
            goto L_0x0829
        L_0x08ea:
            r12 = r3
            r3 = r4
            r38 = r5
            r2 = r6
            r45 = r7
            r31 = r10
            r17 = 1
            r10 = r8
            r3 = r12
            r0 = r25
            r1 = r26
        L_0x08fb:
            if (r0 == 0) goto L_0x0e2b
            if (r27 == 0) goto L_0x0ab1
            u.s r5 = r13.f26409i
            android.hardware.camera2.CameraCharacteristics$Key r6 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
            java.lang.Object r5 = r5.a(r6)
            android.util.Range[] r5 = (android.util.Range[]) r5
            if (r5 != 0) goto L_0x0919
            android.util.Range r5 = b0.f.f3323e
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r19 = r5
            goto L_0x0ab9
        L_0x0919:
            android.util.Range r6 = new android.util.Range
            java.lang.Comparable r7 = r27.getLower()
            java.lang.Integer r7 = (java.lang.Integer) r7
            int r7 = r7.intValue()
            int r7 = java.lang.Math.min(r7, r4)
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            java.lang.Comparable r8 = r27.getUpper()
            java.lang.Integer r8 = (java.lang.Integer) r8
            int r8 = r8.intValue()
            int r8 = java.lang.Math.min(r8, r4)
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)
            r6.<init>(r7, r8)
            android.util.Range r7 = b0.f.f3323e
            int r8 = r5.length
            r9 = r7
            r7 = 0
            r12 = 0
        L_0x0948:
            if (r7 >= r8) goto L_0x0aa0
            r14 = r5[r7]
            java.lang.Comparable r16 = r14.getLower()
            java.lang.Integer r16 = (java.lang.Integer) r16
            r42 = r5
            int r5 = r16.intValue()
            if (r4 < r5) goto L_0x0a7c
            android.util.Range r5 = b0.f.f3323e
            boolean r5 = r9.equals(r5)
            if (r5 == 0) goto L_0x0963
            r9 = r14
        L_0x0963:
            boolean r5 = r14.equals(r6)
            if (r5 == 0) goto L_0x0978
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r25 = r10
            r16 = r11
            r9 = r14
            goto L_0x0aac
        L_0x0978:
            android.util.Range r5 = r14.intersect(r6)     // Catch:{ IllegalArgumentException -> 0x0a32 }
            int r5 = t.v1.f(r5)     // Catch:{ IllegalArgumentException -> 0x0a32 }
            if (r12 != 0) goto L_0x0995
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r12 = r5
            r26 = r7
            r19 = r8
            r25 = r10
            r16 = r11
            goto L_0x0a30
        L_0x0995:
            if (r5 < r12) goto L_0x0a1f
            android.util.Range r5 = r9.intersect(r6)     // Catch:{ IllegalArgumentException -> 0x0a32 }
            int r5 = t.v1.f(r5)     // Catch:{ IllegalArgumentException -> 0x0a32 }
            r25 = r10
            r16 = r11
            double r10 = (double) r5
            android.util.Range r5 = r14.intersect(r6)     // Catch:{ IllegalArgumentException -> 0x0a16 }
            int r5 = t.v1.f(r5)     // Catch:{ IllegalArgumentException -> 0x0a16 }
            r20 = r3
            r21 = r4
            double r3 = (double) r5
            int r5 = t.v1.f(r14)     // Catch:{ IllegalArgumentException -> 0x0a11 }
            r22 = r1
            r39 = r2
            double r1 = (double) r5
            double r1 = r3 / r1
            int r5 = t.v1.f(r9)     // Catch:{ IllegalArgumentException -> 0x0a0c }
            r26 = r7
            r19 = r8
            double r7 = (double) r5
            double r7 = r10 / r7
            r27 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            int r5 = (r3 > r10 ? 1 : (r3 == r10 ? 0 : -1))
            if (r5 <= 0) goto L_0x09d7
            int r3 = (r1 > r27 ? 1 : (r1 == r27 ? 0 : -1))
            if (r3 >= 0) goto L_0x09d5
            int r3 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r3 < 0) goto L_0x0a00
        L_0x09d5:
            r9 = r14
            goto L_0x0a00
        L_0x09d7:
            if (r5 != 0) goto L_0x09f7
            int r3 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r3 <= 0) goto L_0x09de
            goto L_0x09d5
        L_0x09de:
            if (r3 != 0) goto L_0x0a00
            java.lang.Comparable r1 = r14.getLower()     // Catch:{ IllegalArgumentException -> 0x0a0a }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ IllegalArgumentException -> 0x0a0a }
            int r1 = r1.intValue()     // Catch:{ IllegalArgumentException -> 0x0a0a }
            java.lang.Comparable r2 = r9.getLower()     // Catch:{ IllegalArgumentException -> 0x0a0a }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ IllegalArgumentException -> 0x0a0a }
            int r2 = r2.intValue()     // Catch:{ IllegalArgumentException -> 0x0a0a }
            if (r1 <= r2) goto L_0x0a00
            goto L_0x09d5
        L_0x09f7:
            int r3 = (r7 > r27 ? 1 : (r7 == r27 ? 0 : -1))
            if (r3 >= 0) goto L_0x0a00
            int r3 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r3 <= 0) goto L_0x0a00
            goto L_0x09d5
        L_0x0a00:
            android.util.Range r1 = r6.intersect(r9)     // Catch:{ IllegalArgumentException -> 0x0a0a }
            int r12 = t.v1.f(r1)     // Catch:{ IllegalArgumentException -> 0x0a0a }
        L_0x0a08:
            r14 = r9
            goto L_0x0a30
        L_0x0a0a:
            goto L_0x0a43
        L_0x0a0c:
            r26 = r7
            r19 = r8
            goto L_0x0a0a
        L_0x0a11:
            r22 = r1
            r39 = r2
            goto L_0x0a0c
        L_0x0a16:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            goto L_0x0a0c
        L_0x0a1f:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r26 = r7
            r19 = r8
            r25 = r10
            r16 = r11
            goto L_0x0a08
        L_0x0a30:
            r9 = r14
            goto L_0x0a8c
        L_0x0a32:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r26 = r7
            r19 = r8
            r25 = r10
            r16 = r11
            goto L_0x0a0a
        L_0x0a43:
            if (r12 != 0) goto L_0x0a8c
            int r1 = t.v1.e(r14, r6)
            int r2 = t.v1.e(r9, r6)
            if (r1 >= r2) goto L_0x0a50
            goto L_0x0a7b
        L_0x0a50:
            int r1 = t.v1.e(r14, r6)
            int r2 = t.v1.e(r9, r6)
            if (r1 != r2) goto L_0x0a8c
            java.lang.Comparable r1 = r14.getLower()
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            java.lang.Comparable r2 = r9.getUpper()
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            if (r1 <= r2) goto L_0x0a71
            goto L_0x0a7b
        L_0x0a71:
            int r1 = t.v1.f(r14)
            int r2 = t.v1.f(r9)
            if (r1 >= r2) goto L_0x0a8c
        L_0x0a7b:
            goto L_0x0a30
        L_0x0a7c:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r26 = r7
            r19 = r8
            r25 = r10
            r16 = r11
        L_0x0a8c:
            int r7 = r26 + 1
            r5 = r42
            r11 = r16
            r8 = r19
            r3 = r20
            r4 = r21
            r1 = r22
            r10 = r25
            r2 = r39
            goto L_0x0948
        L_0x0aa0:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
            r25 = r10
            r16 = r11
        L_0x0aac:
            r19 = r9
        L_0x0aae:
            r1 = r19
            goto L_0x0abe
        L_0x0ab1:
            r22 = r1
            r39 = r2
            r20 = r3
            r21 = r4
        L_0x0ab9:
            r25 = r10
            r16 = r11
            goto L_0x0aae
        L_0x0abe:
            java.util.Iterator r2 = r45.iterator()
        L_0x0ac2:
            boolean r3 = r2.hasNext()
            java.lang.String r4 = "Null resolution"
            java.lang.String r5 = "Null expectedFrameRateRange"
            if (r3 == 0) goto L_0x0b7d
            java.lang.Object r3 = r2.next()
            b0.p1 r3 = (b0.p1) r3
            r6 = r45
            int r7 = r6.indexOf(r3)
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            r8 = r18
            int r7 = r8.indexOf(r7)
            java.lang.Object r7 = r0.get(r7)
            android.util.Size r7 = (android.util.Size) r7
            android.util.Range r9 = b0.f.f3323e
            ib.t r9 = new ib.t
            r10 = 2
            r9.<init>(r10)
            if (r7 == 0) goto L_0x0b77
            r9.f20102a = r7
            android.util.Range r4 = b0.f.f3323e
            if (r4 == 0) goto L_0x0b71
            r9.f20104c = r4
            r7 = r23
            r9.f20103b = r7
            r4 = r24
            java.lang.Object r5 = r4.get(r3)
            z.v r5 = (z.v) r5
            r5.getClass()
            r9.f20103b = r5
            b0.v0 r5 = b0.v0.b()
            b0.c r10 = s.a.f25699d
            boolean r11 = r3.H(r10)
            if (r11 == 0) goto L_0x0b20
            java.lang.Object r11 = r3.r(r10)
            java.lang.Long r11 = (java.lang.Long) r11
            r5.k(r10, r11)
        L_0x0b20:
            b0.c r10 = b0.p1.f3437r0
            boolean r11 = r3.H(r10)
            if (r11 == 0) goto L_0x0b31
            java.lang.Object r11 = r3.r(r10)
            java.lang.Boolean r11 = (java.lang.Boolean) r11
            r5.k(r10, r11)
        L_0x0b31:
            b0.c r10 = b0.l0.f3398b
            boolean r11 = r3.H(r10)
            if (r11 == 0) goto L_0x0b42
            java.lang.Object r11 = r3.r(r10)
            java.lang.Integer r11 = (java.lang.Integer) r11
            r5.k(r10, r11)
        L_0x0b42:
            b0.c r10 = b0.m0.U
            boolean r11 = r3.H(r10)
            if (r11 == 0) goto L_0x0b53
            java.lang.Object r11 = r3.r(r10)
            java.lang.Integer r11 = (java.lang.Integer) r11
            r5.k(r10, r11)
        L_0x0b53:
            s.a r10 = new s.a
            r10.<init>(r5)
            r9.f20105d = r10
            if (r1 == 0) goto L_0x0b5e
            r9.f20104c = r1
        L_0x0b5e:
            b0.f r5 = r9.a()
            r9 = r30
            r9.put(r3, r5)
            r24 = r4
            r45 = r6
            r23 = r7
            r18 = r8
            goto L_0x0ac2
        L_0x0b71:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r5)
            throw r0
        L_0x0b77:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r4)
            throw r0
        L_0x0b7d:
            r7 = r23
            r9 = r30
            if (r39 == 0) goto L_0x0bac
            r12 = r20
            r3 = r21
            if (r3 != r12) goto L_0x0bac
            int r1 = r0.size()
            int r2 = r22.size()
            if (r1 != r2) goto L_0x0bac
            r1 = 0
        L_0x0b94:
            int r2 = r0.size()
            if (r1 >= r2) goto L_0x0bb5
            java.lang.Object r2 = r0.get(r1)
            android.util.Size r2 = (android.util.Size) r2
            r3 = r22
            java.lang.Object r6 = r3.get(r1)
            boolean r2 = r2.equals(r6)
            if (r2 != 0) goto L_0x0bb0
        L_0x0bac:
            r8 = r34
            goto L_0x0e25
        L_0x0bb0:
            int r1 = r1 + 1
            r22 = r3
            goto L_0x0b94
        L_0x0bb5:
            u.s r0 = r13.f26409i
            int r1 = android.os.Build.VERSION.SDK_INT
            java.lang.String r2 = "Null dynamicRange"
            r3 = 33
            if (r1 >= r3) goto L_0x0bc3
        L_0x0bbf:
            r8 = r34
            goto L_0x0d70
        L_0x0bc3:
            java.util.ArrayList r1 = new java.util.ArrayList
            java.util.Set r3 = r9.keySet()
            r1.<init>(r3)
            java.util.Iterator r3 = r44.iterator()
        L_0x0bd0:
            boolean r6 = r3.hasNext()
            if (r6 == 0) goto L_0x0be2
            java.lang.Object r6 = r3.next()
            b0.a r6 = (b0.a) r6
            b0.d0 r6 = r6.f3281f
            r6.getClass()
            goto L_0x0bd0
        L_0x0be2:
            java.util.Iterator r3 = r1.iterator()
        L_0x0be6:
            boolean r6 = r3.hasNext()
            if (r6 == 0) goto L_0x0c01
            java.lang.Object r6 = r3.next()
            b0.p1 r6 = (b0.p1) r6
            java.lang.Object r6 = r9.get(r6)
            b0.f r6 = (b0.f) r6
            r6.getClass()
            b0.d0 r6 = r6.f3327d
            r6.getClass()
            goto L_0x0be6
        L_0x0c01:
            android.hardware.camera2.CameraCharacteristics$Key r3 = android.hardware.camera2.CameraCharacteristics.SCALER_AVAILABLE_STREAM_USE_CASES
            java.lang.Object r0 = r0.a(r3)
            long[] r0 = (long[]) r0
            if (r0 == 0) goto L_0x0bbf
            int r3 = r0.length
            if (r3 != 0) goto L_0x0c11
            goto L_0x0bbf
        L_0x0c11:
            java.util.HashSet r3 = new java.util.HashSet
            r3.<init>()
            int r6 = r0.length
            r8 = 0
        L_0x0c18:
            if (r8 >= r6) goto L_0x0c26
            r10 = r0[r8]
            java.lang.Long r10 = java.lang.Long.valueOf(r10)
            r3.add(r10)
            int r8 = r8 + 1
            goto L_0x0c18
        L_0x0c26:
            java.util.HashSet r0 = new java.util.HashSet
            r0.<init>()
            java.util.Iterator r6 = r44.iterator()
            boolean r8 = r6.hasNext()
            r10 = 0
            if (r8 == 0) goto L_0x0c5e
            java.lang.Object r6 = r6.next()
            b0.a r6 = (b0.a) r6
            b0.d0 r8 = r6.f3281f
            b0.c r12 = s.a.f25699d
            boolean r8 = r8.H(r12)
            if (r8 != 0) goto L_0x0c4a
        L_0x0c47:
            r6 = 0
            r8 = 1
            goto L_0x0c60
        L_0x0c4a:
            b0.d0 r6 = r6.f3281f
            java.lang.Object r6 = r6.r(r12)
            java.lang.Long r6 = (java.lang.Long) r6
            long r12 = r6.longValue()
            int r6 = (r12 > r10 ? 1 : (r12 == r10 ? 0 : -1))
            if (r6 != 0) goto L_0x0c5b
            goto L_0x0c47
        L_0x0c5b:
            r6 = 1
        L_0x0c5c:
            r8 = 0
            goto L_0x0c60
        L_0x0c5e:
            r6 = 0
            goto L_0x0c5c
        L_0x0c60:
            java.util.Iterator r12 = r1.iterator()
        L_0x0c64:
            boolean r13 = r12.hasNext()
            if (r13 == 0) goto L_0x0cb3
            java.lang.Object r13 = r12.next()
            b0.p1 r13 = (b0.p1) r13
            b0.c r14 = s.a.f25699d
            boolean r18 = r13.H(r14)
            java.lang.String r10 = "Either all use cases must have non-default stream use case assigned or none should have it"
            if (r18 != 0) goto L_0x0c86
            if (r6 != 0) goto L_0x0c80
            r8 = 1
            r18 = 0
            goto L_0x0caa
        L_0x0c80:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r0.<init>(r10)
            throw r0
        L_0x0c86:
            java.lang.Object r11 = r13.r(r14)
            java.lang.Long r11 = (java.lang.Long) r11
            long r13 = r11.longValue()
            r18 = 0
            int r11 = (r13 > r18 ? 1 : (r13 == r18 ? 0 : -1))
            if (r11 != 0) goto L_0x0ca0
            if (r6 != 0) goto L_0x0c9a
            r8 = 1
            goto L_0x0caa
        L_0x0c9a:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r0.<init>(r10)
            throw r0
        L_0x0ca0:
            if (r8 != 0) goto L_0x0cad
            java.lang.Long r6 = java.lang.Long.valueOf(r13)
            r0.add(r6)
            r6 = 1
        L_0x0caa:
            r10 = r18
            goto L_0x0c64
        L_0x0cad:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r0.<init>(r10)
            throw r0
        L_0x0cb3:
            if (r8 != 0) goto L_0x0bbf
            java.util.Iterator r0 = r0.iterator()
        L_0x0cb9:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x0ccd
            java.lang.Object r6 = r0.next()
            java.lang.Long r6 = (java.lang.Long) r6
            boolean r6 = r3.contains(r6)
            if (r6 != 0) goto L_0x0cb9
            goto L_0x0bbf
        L_0x0ccd:
            java.util.Iterator r0 = r44.iterator()
        L_0x0cd1:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x0d36
            java.lang.Object r3 = r0.next()
            b0.a r3 = (b0.a) r3
            b0.d0 r6 = r3.f3281f
            b0.c r8 = s.a.f25699d
            java.lang.Object r8 = r6.r(r8)
            java.lang.Long r8 = (java.lang.Long) r8
            long r10 = r8.longValue()
            s.a r6 = t.s1.a(r6, r10)
            if (r6 == 0) goto L_0x0d31
            android.util.Range r8 = b0.f.f3323e
            ib.t r8 = new ib.t
            r10 = 2
            r8.<init>(r10)
            android.util.Size r10 = r3.f3278c
            if (r10 == 0) goto L_0x0d2b
            r8.f20102a = r10
            android.util.Range r10 = b0.f.f3323e
            if (r10 == 0) goto L_0x0d25
            r8.f20104c = r10
            r8.f20103b = r7
            z.v r10 = r3.f3279d
            if (r10 == 0) goto L_0x0d1f
            r8.f20103b = r10
            r8.f20105d = r6
            android.util.Range r6 = r3.f3282g
            if (r6 == 0) goto L_0x0d15
            r8.f20104c = r6
        L_0x0d15:
            b0.f r6 = r8.a()
            r8 = r34
            r8.put(r3, r6)
            goto L_0x0d33
        L_0x0d1f:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r2)
            throw r0
        L_0x0d25:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r5)
            throw r0
        L_0x0d2b:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r4)
            throw r0
        L_0x0d31:
            r8 = r34
        L_0x0d33:
            r34 = r8
            goto L_0x0cd1
        L_0x0d36:
            r8 = r34
            java.util.Iterator r0 = r1.iterator()
        L_0x0d3c:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0e25
            java.lang.Object r1 = r0.next()
            b0.p1 r1 = (b0.p1) r1
            java.lang.Object r2 = r9.get(r1)
            b0.f r2 = (b0.f) r2
            b0.d0 r3 = r2.f3327d
            b0.c r4 = s.a.f25699d
            java.lang.Object r4 = r3.r(r4)
            java.lang.Long r4 = (java.lang.Long) r4
            long r4 = r4.longValue()
            s.a r3 = t.s1.a(r3, r4)
            if (r3 == 0) goto L_0x0d3c
            ib.t r2 = r2.a()
            r2.f20105d = r3
            b0.f r2 = r2.a()
            r9.put(r1, r2)
            goto L_0x0d3c
        L_0x0d70:
            r0 = 0
        L_0x0d71:
            int r1 = r39.size()
            if (r0 >= r1) goto L_0x0e25
            r1 = r39
            java.lang.Object r3 = r1.get(r0)
            b0.g r3 = (b0.g) r3
            long r10 = r3.f3331c
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)
            r6 = r25
            boolean r3 = r6.containsKey(r3)
            if (r3 == 0) goto L_0x0de1
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)
            java.lang.Object r3 = r6.get(r3)
            b0.a r3 = (b0.a) r3
            b0.d0 r12 = r3.f3281f
            s.a r10 = t.s1.a(r12, r10)
            if (r10 == 0) goto L_0x0ddd
            android.util.Range r11 = b0.f.f3323e
            ib.t r11 = new ib.t
            r12 = 2
            r11.<init>(r12)
            android.util.Size r13 = r3.f3278c
            if (r13 == 0) goto L_0x0dd7
            r11.f20102a = r13
            android.util.Range r13 = b0.f.f3323e
            if (r13 == 0) goto L_0x0dd1
            r11.f20104c = r13
            r11.f20103b = r7
            z.v r13 = r3.f3279d
            if (r13 == 0) goto L_0x0dcb
            r11.f20103b = r13
            r11.f20105d = r10
            android.util.Range r10 = r3.f3282g
            if (r10 == 0) goto L_0x0dc3
            r11.f20104c = r10
        L_0x0dc3:
            b0.f r10 = r11.a()
            r8.put(r3, r10)
            goto L_0x0dde
        L_0x0dcb:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r2)
            throw r0
        L_0x0dd1:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r5)
            throw r0
        L_0x0dd7:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            r0.<init>(r4)
            throw r0
        L_0x0ddd:
            r12 = 2
        L_0x0dde:
            r13 = r38
            goto L_0x0e13
        L_0x0de1:
            r12 = 2
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)
            r13 = r38
            boolean r3 = r13.containsKey(r3)
            if (r3 == 0) goto L_0x0e1d
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)
            java.lang.Object r3 = r13.get(r3)
            b0.p1 r3 = (b0.p1) r3
            java.lang.Object r14 = r9.get(r3)
            b0.f r14 = (b0.f) r14
            b0.d0 r15 = r14.f3327d
            s.a r10 = t.s1.a(r15, r10)
            if (r10 == 0) goto L_0x0e13
            ib.t r11 = r14.a()
            r11.f20105d = r10
            b0.f r10 = r11.a()
            r9.put(r3, r10)
        L_0x0e13:
            int r0 = r0 + 1
            r39 = r1
            r25 = r6
            r38 = r13
            goto L_0x0d71
        L_0x0e1d:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r1 = r16
            r0.<init>(r1)
            throw r0
        L_0x0e25:
            android.util.Pair r0 = new android.util.Pair
            r0.<init>(r9, r8)
            return r0
        L_0x0e2b:
            r6 = r45
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r9)
            java.lang.String r2 = r13.f26407g
            r1.append(r2)
            java.lang.String r2 = " and Hardware level: "
            r1.append(r2)
            int r2 = r13.f26411k
            r1.append(r2)
            java.lang.String r2 = ". May be the specified resolution is too large and not supported. Existing surfaces: "
            r1.append(r2)
            r1.append(r15)
            r2 = r31
            r1.append(r2)
            r1.append(r6)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0e5b:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Failed to find supported resolutions."
            r0.<init>(r1)
            throw r0
        L_0x0e63:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "No such camera id in supported combination list: "
            java.lang.String r0 = t.u.d(r2, r0)
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c.t(int, java.lang.String, java.util.ArrayList, java.util.HashMap):android.util.Pair");
    }

    public final String u(String str) {
        try {
            String str2 = (String) ((Map) this.f536a).get(str);
            if (str2 != null) {
                if (str2.length() != 0) {
                    return w.b(str2, (String) this.f537b);
                }
            }
        } catch (Exception unused) {
        }
        return null;
    }

    public final boolean v(String str) {
        boolean z4 = true;
        a0 p5 = a0.p(1, "SELECT COUNT(*)=0 FROM dependency WHERE work_spec_id=? AND prerequisite_id IN (SELECT id FROM workspec WHERE state!=2)");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        ((x) this.f536a).b();
        boolean z10 = false;
        Cursor i10 = ne.c0.i((x) this.f536a, p5, false);
        try {
            if (i10.moveToFirst()) {
                if (i10.getInt(0) == 0) {
                    z4 = false;
                }
                z10 = z4;
            }
            return z10;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final void w(a aVar) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("Fid", aVar.f18129a);
            jSONObject.put("Status", aVar.f18130b.ordinal());
            jSONObject.put("AuthToken", aVar.f18131c);
            jSONObject.put("RefreshToken", aVar.f18132d);
            jSONObject.put("TokenCreationEpochInSecs", aVar.f18134f);
            jSONObject.put("ExpiresInSecs", aVar.f18133e);
            jSONObject.put("FisError", aVar.f18135g);
            aa.g gVar = (aa.g) this.f537b;
            gVar.a();
            File createTempFile = File.createTempFile("PersistedInstallation", "tmp", gVar.f756a.getFilesDir());
            FileOutputStream fileOutputStream = new FileOutputStream(createTempFile);
            fileOutputStream.write(jSONObject.toString().getBytes("UTF-8"));
            fileOutputStream.close();
            if (!createTempFile.renameTo(p())) {
                throw new IOException("unable to rename the tmpfile to PersistedInstallation");
            }
        } catch (IOException | JSONException unused) {
        }
    }

    public final boolean y(n nVar) {
        float f10 = nVar.f20209a;
        if (f10 >= 0.0f) {
            b bVar = (b) this.f536a;
            if (f10 <= ((float) (bVar.f22657a - 1))) {
                float f11 = nVar.f20210b;
                if (f11 <= 0.0f || f11 > ((float) (bVar.f22658b - 1))) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    public c(x xVar, int i10) {
        if (i10 != 7) {
            this.f536a = xVar;
            this.f537b = new b(this, xVar, 0);
            return;
        }
        r0.j("database", xVar);
        this.f536a = xVar;
        Set newSetFromMap = Collections.newSetFromMap(new IdentityHashMap());
        r0.i("newSetFromMap(IdentityHashMap())", newSetFromMap);
        this.f537b = newSetFromMap;
    }

    public c(Context context, u.b0 b0Var, LinkedHashSet linkedHashSet) {
        Object obj = new Object();
        this.f536a = new HashMap();
        this.f537b = obj;
        b0Var = !(b0Var instanceof u.b0) ? u.b0.a(context, c0.g.c()) : b0Var;
        context.getClass();
        Iterator it = linkedHashSet.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            ((Map) this.f536a).put(str, new v1(context, str, b0Var, (n0) this.f537b));
        }
    }

    public c(CameraDevice cameraDevice, y yVar) {
        cameraDevice.getClass();
        this.f536a = cameraDevice;
        this.f537b = yVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0013, code lost:
        if (r0.equals("android.os.IMessenger") != false) goto L_0x0017;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public c(android.os.IBinder r5) {
        /*
            r4 = this;
            r4.<init>()
            java.lang.String r0 = r5.getInterfaceDescriptor()
            java.lang.String r1 = "android.os.IMessenger"
            r2 = 1
            if (r0 == r1) goto L_0x0017
            r3 = 0
            if (r0 == 0) goto L_0x0016
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x0018
            goto L_0x0017
        L_0x0016:
            r2 = 0
        L_0x0017:
            r3 = r2
        L_0x0018:
            r1 = 0
            if (r3 == 0) goto L_0x0025
            android.os.Messenger r0 = new android.os.Messenger
            r0.<init>(r5)
            r4.f536a = r0
            r4.f537b = r1
            return
        L_0x0025:
            java.lang.String r2 = "com.google.android.gms.iid.IMessengerCompat"
            if (r0 == r2) goto L_0x0047
            if (r0 == 0) goto L_0x0032
            boolean r2 = r0.equals(r2)
            if (r2 == 0) goto L_0x0032
            goto L_0x0047
        L_0x0032:
            java.lang.String r5 = java.lang.String.valueOf(r0)
            java.lang.String r0 = "Invalid interface descriptor: "
            java.lang.String r5 = r0.concat(r5)
            java.lang.String r0 = "MessengerIpcClient"
            android.util.Log.w(r0, r5)
            android.os.RemoteException r5 = new android.os.RemoteException
            r5.<init>()
            throw r5
        L_0x0047:
            com.google.android.gms.cloudmessaging.zze r0 = new com.google.android.gms.cloudmessaging.zze
            r0.<init>(r5)
            r4.f537b = r0
            r4.f536a = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c.<init>(android.os.IBinder):void");
    }

    public /* synthetic */ c(Object obj) {
        this.f536a = obj;
    }

    public /* synthetic */ c(Object obj, int i10) {
        this.f537b = obj;
    }

    public /* synthetic */ c(Object obj, Object obj2) {
        this.f537b = obj;
        this.f536a = obj2;
    }

    public /* synthetic */ c(Object obj, Object obj2, int i10) {
        this.f536a = obj;
        this.f537b = obj2;
    }
}
