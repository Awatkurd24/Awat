package a4;

import android.hardware.camera2.CaptureResult;
import android.os.Bundle;
import androidx.datastore.preferences.protobuf.p;
import androidx.fragment.app.a0;
import androidx.recyclerview.widget.RecyclerView;
import b0.a1;
import b0.c;
import b0.c0;
import b0.d0;
import b0.m0;
import b0.o0;
import b0.p1;
import b0.r1;
import b0.v0;
import b0.x0;
import com.google.android.gms.internal.measurement.d1;
import com.google.android.gms.internal.measurement.k1;
import com.google.android.gms.internal.measurement.q0;
import com.v2ray.ang.dto.V2rayConfig;
import he.x;
import ib.g;
import java.util.Objects;
import java.util.Set;
import k0.a;
import rf.b;
import v7.r0;
import z.v;

public abstract /* synthetic */ class l {
    public static int A(String str, int i10, int i11) {
        return (str.hashCode() + i10) * i11;
    }

    public static Bundle B(d1 d1Var, q0 q0Var, int i10, long j3) {
        d1Var.f(new k1(d1Var, q0Var, i10));
        return q0Var.Z(j3);
    }

    public static String C(RecyclerView recyclerView, StringBuilder sb2) {
        sb2.append(recyclerView.C());
        return sb2.toString();
    }

    public static String D(x xVar, Class cls, StringBuilder sb2) {
        sb2.append(xVar.b(cls));
        return sb2.toString();
    }

    public static String E(String str, int i10, String str2, int i11) {
        return str + i10 + str2 + i11;
    }

    public static String F(String str, long j3) {
        return str + j3;
    }

    public static String G(String str, a0 a0Var, String str2) {
        return str + a0Var + str2;
    }

    public static String H(String str, String str2) {
        return str + str2;
    }

    public static String I(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static String J(StringBuilder sb2, String str, String str2) {
        sb2.append(str);
        sb2.append(str2);
        return sb2.toString();
    }

    public static StringBuilder K(String str, int i10, String str2) {
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(i10);
        sb2.append(str2);
        return sb2;
    }

    public static StringBuilder L(String str, int i10, String str2, int i11, String str3) {
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(i10);
        sb2.append(str2);
        sb2.append(i11);
        sb2.append(str3);
        return sb2;
    }

    public static StringBuilder M(String str, String str2, String str3, String str4, String str5) {
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(str2);
        sb2.append(str3);
        sb2.append(str4);
        sb2.append(str5);
        return sb2;
    }

    public static /* synthetic */ void N(Object obj) {
        throw new ClassCastException();
    }

    public static void O(StringBuilder sb2, String str, String str2, String str3, String str4) {
        sb2.append(str);
        sb2.append(str2);
        sb2.append(str3);
        sb2.append(str4);
    }

    public static boolean P(b bVar, int i10, String str) {
        Boolean c10 = bVar.c(i10);
        r0.i(str, c10);
        return c10.booleanValue();
    }

    public static int Q(int i10, int i11, int i12, int i13) {
        return ((i10 * i11) / i12) + i13;
    }

    public static String R(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static x0 S(d0 d0Var, d0 d0Var2) {
        v0 v0Var;
        if (d0Var == null && d0Var2 == null) {
            return x0.f3474c;
        }
        if (d0Var2 != null) {
            v0Var = v0.f(d0Var2);
        } else {
            v0Var = v0.b();
        }
        if (d0Var != null) {
            for (c T : d0Var.J()) {
                T(v0Var, d0Var2, d0Var, T);
            }
        }
        return x0.a(v0Var);
    }

    public static void T(v0 v0Var, d0 d0Var, d0 d0Var2, c cVar) {
        if (Objects.equals(cVar, o0.f3427h0)) {
            k0.b bVar = (k0.b) d0Var2.m(cVar, (Object) null);
            k0.b bVar2 = (k0.b) d0Var.m(cVar, (Object) null);
            c0 T = d0Var2.T(cVar);
            if (bVar != null) {
                if (bVar2 != null) {
                    a aVar = bVar.f21232a;
                    if (aVar == null) {
                        aVar = bVar2.f21232a;
                    }
                    k0.c cVar2 = bVar.f21233b;
                    if (cVar2 == null) {
                        cVar2 = bVar2.f21233b;
                    }
                    int i10 = bVar.f21234c;
                    if (i10 == 0) {
                        i10 = bVar2.f21234c;
                    }
                    bVar2 = new k0.b(aVar, cVar2, i10);
                }
                v0Var.i(cVar, T, bVar);
                return;
            }
            bVar = bVar2;
            v0Var.i(cVar, T, bVar);
            return;
        }
        v0Var.i(cVar, d0Var2.T(cVar), d0Var2.r(cVar));
    }

    public static /* synthetic */ String U(int i10) {
        if (i10 == 1) {
            return "OK";
        }
        if (i10 == 2) {
            return "TRANSIENT_ERROR";
        }
        if (i10 != 3) {
            return i10 != 4 ? "null" : "INVALID_PAYLOAD";
        }
        return "FATAL_ERROR";
    }

    public static /* synthetic */ String V(int i10) {
        if (i10 == 1) {
            return "NONE";
        }
        if (i10 != 2) {
            return i10 != 3 ? "null" : "REMOVING";
        }
        return "ADDING";
    }

    public static /* synthetic */ String W(int i10) {
        if (i10 == 1) {
            return "REMOVED";
        }
        if (i10 == 2) {
            return "VISIBLE";
        }
        if (i10 != 3) {
            return i10 != 4 ? "null" : "INVISIBLE";
        }
        return "GONE";
    }

    public static /* synthetic */ String X(int i10) {
        switch (i10) {
            case 1:
                return "VGA";
            case 2:
                return "s720p";
            case 3:
                return "PREVIEW";
            case 4:
                return "s1440p";
            case 5:
                return "RECORD";
            case 6:
                return "MAXIMUM";
            case 7:
                return "ULTRA_MAXIMUM";
            case V2rayConfig.DEFAULT_LEVEL /*8*/:
                return "NOT_SUPPORT";
            default:
                return "null";
        }
    }

    public static /* synthetic */ String Y(int i10) {
        if (i10 == 1) {
            return "PRIV";
        }
        if (i10 == 2) {
            return "YUV";
        }
        if (i10 != 3) {
            return i10 != 4 ? "null" : "RAW";
        }
        return "JPEG";
    }

    public static boolean a(a1 a1Var, c cVar) {
        return a1Var.z().H(cVar);
    }

    public static void b(a1 a1Var, g gVar) {
        a1Var.z().c(gVar);
    }

    public static CaptureResult c() {
        return c();
    }

    public static r1 d(p1 p1Var) {
        return (r1) p1Var.r(p1.f3439t0);
    }

    public static v e(p1 p1Var) {
        v vVar = (v) p1Var.m(m0.V, v.f30551c);
        vVar.getClass();
        return vVar;
    }

    public static c0 f(a1 a1Var, c cVar) {
        return a1Var.z().T(cVar);
    }

    public static Set g(a1 a1Var, c cVar) {
        return a1Var.z().p(cVar);
    }

    public static int h(p1 p1Var) {
        return ((Integer) p1Var.r(p1.f3434n0)).intValue();
    }

    public static int i(p1 p1Var) {
        return ((Integer) p1Var.m(p1.f3434n0, 0)).intValue();
    }

    public static boolean j(p1 p1Var) {
        return ((Boolean) p1Var.m(p1.f3438s0, Boolean.FALSE)).booleanValue();
    }

    public static boolean k(p1 p1Var) {
        return ((Boolean) p1Var.m(p1.f3437r0, Boolean.FALSE)).booleanValue();
    }

    public static Set l(a1 a1Var) {
        return a1Var.z().J();
    }

    public static Object m(a1 a1Var, c cVar) {
        return a1Var.z().r(cVar);
    }

    public static Object n(a1 a1Var, c cVar, Object obj) {
        return a1Var.z().m(cVar, obj);
    }

    public static Object o(a1 a1Var, c cVar, c0 c0Var) {
        return a1Var.z().A(cVar, c0Var);
    }

    /* JADX WARNING: type inference failed for: r4v2, types: [android.view.ViewParent] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void p(int r4, android.view.View r5) {
        /*
            r0 = 0
            if (r4 == 0) goto L_0x009d
            r1 = 1
            int r4 = r4 - r1
            r2 = 2
            java.lang.String r3 = "FragmentManager"
            if (r4 == 0) goto L_0x006d
            java.lang.String r0 = "SpecialEffectsController: Setting view "
            if (r4 == r1) goto L_0x0051
            if (r4 == r2) goto L_0x0034
            r1 = 3
            if (r4 == r1) goto L_0x0015
            goto L_0x009c
        L_0x0015:
            boolean r4 = android.util.Log.isLoggable(r3, r2)
            if (r4 == 0) goto L_0x002f
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>(r0)
            r4.append(r5)
            java.lang.String r0 = " to INVISIBLE"
            r4.append(r0)
            java.lang.String r4 = r4.toString()
            android.util.Log.v(r3, r4)
        L_0x002f:
            r4 = 4
        L_0x0030:
            r5.setVisibility(r4)
            goto L_0x009c
        L_0x0034:
            boolean r4 = android.util.Log.isLoggable(r3, r2)
            if (r4 == 0) goto L_0x004e
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>(r0)
            r4.append(r5)
            java.lang.String r0 = " to GONE"
            r4.append(r0)
            java.lang.String r4 = r4.toString()
            android.util.Log.v(r3, r4)
        L_0x004e:
            r4 = 8
            goto L_0x0030
        L_0x0051:
            boolean r4 = android.util.Log.isLoggable(r3, r2)
            if (r4 == 0) goto L_0x006b
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>(r0)
            r4.append(r5)
            java.lang.String r0 = " to VISIBLE"
            r4.append(r0)
            java.lang.String r4 = r4.toString()
            android.util.Log.v(r3, r4)
        L_0x006b:
            r4 = 0
            goto L_0x0030
        L_0x006d:
            android.view.ViewParent r4 = r5.getParent()
            boolean r1 = r4 instanceof android.view.ViewGroup
            if (r1 == 0) goto L_0x0078
            r0 = r4
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
        L_0x0078:
            if (r0 == 0) goto L_0x009c
            boolean r4 = android.util.Log.isLoggable(r3, r2)
            if (r4 == 0) goto L_0x0099
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r1 = "SpecialEffectsController: Removing view "
            r4.<init>(r1)
            r4.append(r5)
            java.lang.String r1 = " from container "
            r4.append(r1)
            r4.append(r0)
            java.lang.String r4 = r4.toString()
            android.util.Log.v(r3, r4)
        L_0x0099:
            r0.removeView(r5)
        L_0x009c:
            return
        L_0x009d:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.l.p(int, android.view.View):void");
    }

    public static /* synthetic */ boolean q(int i10, int i11, int i12) {
        switch (i10) {
            case 1:
                return r(i10, i11, i12);
            case 2:
                return s(i10, i11, i12);
            case 3:
                return t(i10, i11, i12);
            case 4:
                return u(i10, i11, i12);
            case 5:
                return v(i10, i11, i12);
            case 6:
                return w(i10, i11, i12);
            case 7:
                return x(i10, i11, i12);
            default:
                return y(i10, i11, i12);
        }
    }

    public static final boolean r(int i10, int i11, int i12) {
        return ((i11 + i12) & 1) == 0;
    }

    public static final boolean s(int i10, int i11, int i12) {
        return (i11 & 1) == 0;
    }

    public static final boolean t(int i10, int i11, int i12) {
        return i12 % 3 == 0;
    }

    public static final boolean u(int i10, int i11, int i12) {
        return (i11 + i12) % 3 == 0;
    }

    public static final boolean v(int i10, int i11, int i12) {
        return (((i12 / 3) + (i11 / 2)) & 1) == 0;
    }

    public static final boolean w(int i10, int i11, int i12) {
        return (i11 * i12) % 6 == 0;
    }

    public static final boolean x(int i10, int i11, int i12) {
        return (i11 * i12) % 6 < 3;
    }

    public static final boolean y(int i10, int i11, int i12) {
        return ((((i11 * i12) % 3) + (i11 + i12)) & 1) == 0;
    }

    public static int z(int i10, int i11, int i12, int i13) {
        return p.D(i10) + i11 + i12 + i13;
    }
}
