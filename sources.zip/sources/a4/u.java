package a4;

import a3.a0;
import a3.x;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import androidx.recyclerview.widget.b0;
import com.google.android.gms.internal.ads.ba0;
import com.google.android.gms.internal.ads.cg1;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.dk0;
import com.google.android.gms.internal.ads.dr0;
import com.google.android.gms.internal.ads.eg1;
import com.google.android.gms.internal.ads.em0;
import com.google.android.gms.internal.ads.gk0;
import com.google.android.gms.internal.ads.gm0;
import com.google.android.gms.internal.ads.gr0;
import com.google.android.gms.internal.ads.he;
import com.google.android.gms.internal.ads.hk;
import com.google.android.gms.internal.ads.kr;
import com.google.android.gms.internal.ads.kw;
import com.google.android.gms.internal.ads.lr;
import com.google.android.gms.internal.ads.mv;
import com.google.android.gms.internal.ads.nl0;
import com.google.android.gms.internal.ads.nm0;
import com.google.android.gms.internal.ads.o40;
import com.google.android.gms.internal.ads.pl0;
import com.google.android.gms.internal.ads.pq;
import com.google.android.gms.internal.ads.qa0;
import com.google.android.gms.internal.ads.qc0;
import com.google.android.gms.internal.ads.qm0;
import com.google.android.gms.internal.ads.s;
import com.google.android.gms.internal.ads.sk0;
import com.google.android.gms.internal.ads.te;
import com.google.android.gms.internal.ads.uf1;
import com.google.android.gms.internal.ads.uq;
import com.google.android.gms.internal.ads.vr0;
import com.google.android.gms.internal.ads.wf1;
import com.google.android.gms.internal.ads.wm0;
import com.google.android.gms.internal.ads.wu;
import com.google.android.gms.internal.ads.xj0;
import com.google.android.gms.internal.ads.yl0;
import com.google.android.gms.internal.ads.yx0;
import com.google.android.gms.internal.ads.zf1;
import com.google.android.gms.internal.ads.zu;
import com.google.android.gms.internal.ads.zzbve;
import com.google.android.gms.internal.ads.zzbwa;
import f3.i;
import he.j;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import m.d;
import ne.c0;
import p6.q;
import r3.f;
import r3.f0;
import v7.r0;

public final class u {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f599a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f600b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f601c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f602d;

    /* renamed from: e  reason: collision with root package name */
    public final Object f603e;

    /* renamed from: f  reason: collision with root package name */
    public final Object f604f;

    /* renamed from: g  reason: collision with root package name */
    public final Object f605g;

    /* renamed from: h  reason: collision with root package name */
    public final Object f606h;

    /* renamed from: i  reason: collision with root package name */
    public final Object f607i;

    /* renamed from: j  reason: collision with root package name */
    public final Object f608j;

    /* renamed from: k  reason: collision with root package name */
    public final Object f609k;

    /* renamed from: l  reason: collision with root package name */
    public final Object f610l;

    /* renamed from: m  reason: collision with root package name */
    public final Object f611m;

    /* renamed from: n  reason: collision with root package name */
    public final Object f612n;

    /* renamed from: o  reason: collision with root package name */
    public final Object f613o;

    public u(x xVar) {
        this.f599a = 0;
        this.f600b = xVar;
        this.f601c = new b(this, xVar, 5);
        this.f602d = new t(xVar);
        this.f603e = new t(xVar, 5);
        this.f604f = new t(xVar, 6);
        this.f605g = new t(xVar, 7);
        this.f606h = new t(xVar, 8);
        this.f607i = new t(xVar, 9);
        this.f608j = new t(xVar, 10);
        this.f609k = new t(xVar, 11);
        this.f610l = new t(xVar, 0);
        this.f611m = new t(xVar, 1);
        this.f612n = new t(xVar, 2);
        this.f613o = new t(xVar, 3);
    }

    public final void a(String str) {
        Object obj = this.f600b;
        ((x) obj).b();
        Object obj2 = this.f603e;
        i c10 = ((d) obj2).c();
        if (str == null) {
            c10.t(1);
        } else {
            c10.m(1, str);
        }
        ((x) obj).c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            ((x) obj).j();
            ((d) obj2).x(c10);
        }
    }

    public final ArrayList b() {
        a0 a0Var;
        boolean z4;
        int i10;
        boolean z10;
        int i11;
        boolean z11;
        int i12;
        boolean z12;
        int i13;
        boolean z13;
        int i14;
        a0 p5 = a0.p(1, "SELECT * FROM workspec WHERE state=0 ORDER BY last_enqueue_time LIMIT ?");
        p5.D(1, (long) b0.DEFAULT_DRAG_ANIMATION_DURATION);
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i15 = c0.i(xVar, p5, false);
        try {
            int c10 = j.c(i15, "id");
            int c11 = j.c(i15, "state");
            int c12 = j.c(i15, "worker_class_name");
            int c13 = j.c(i15, "input_merger_class_name");
            int c14 = j.c(i15, "input");
            int c15 = j.c(i15, "output");
            int c16 = j.c(i15, "initial_delay");
            int c17 = j.c(i15, "interval_duration");
            int c18 = j.c(i15, "flex_duration");
            int c19 = j.c(i15, "run_attempt_count");
            int c20 = j.c(i15, "backoff_policy");
            int c21 = j.c(i15, "backoff_delay_duration");
            int c22 = j.c(i15, "last_enqueue_time");
            int c23 = j.c(i15, "minimum_retention_duration");
            a0Var = p5;
            try {
                int c24 = j.c(i15, "schedule_requested_at");
                int c25 = j.c(i15, "run_in_foreground");
                int c26 = j.c(i15, "out_of_quota_policy");
                int c27 = j.c(i15, "period_count");
                int c28 = j.c(i15, "generation");
                int c29 = j.c(i15, "required_network_type");
                int c30 = j.c(i15, "requires_charging");
                int c31 = j.c(i15, "requires_device_idle");
                int c32 = j.c(i15, "requires_battery_not_low");
                int c33 = j.c(i15, "requires_storage_not_low");
                int c34 = j.c(i15, "trigger_content_update_delay");
                int c35 = j.c(i15, "trigger_max_content_delay");
                int c36 = j.c(i15, "content_uri_triggers");
                int i16 = c23;
                ArrayList arrayList = new ArrayList(i15.getCount());
                while (i15.moveToNext()) {
                    byte[] bArr = null;
                    String string = i15.isNull(c10) ? null : i15.getString(c10);
                    f0 f10 = gc.d.f(i15.getInt(c11));
                    String string2 = i15.isNull(c12) ? null : i15.getString(c12);
                    String string3 = i15.isNull(c13) ? null : i15.getString(c13);
                    r3.j a10 = r3.j.a(i15.isNull(c14) ? null : i15.getBlob(c14));
                    r3.j a11 = r3.j.a(i15.isNull(c15) ? null : i15.getBlob(c15));
                    long j3 = i15.getLong(c16);
                    long j10 = i15.getLong(c17);
                    long j11 = i15.getLong(c18);
                    int i17 = i15.getInt(c19);
                    int c37 = gc.d.c(i15.getInt(c20));
                    long j12 = i15.getLong(c21);
                    long j13 = i15.getLong(c22);
                    int i18 = i16;
                    long j14 = i15.getLong(i18);
                    int i19 = c10;
                    int i20 = c24;
                    long j15 = i15.getLong(i20);
                    c24 = i20;
                    int i21 = c25;
                    if (i15.getInt(i21) != 0) {
                        c25 = i21;
                        i10 = c26;
                        z4 = true;
                    } else {
                        c25 = i21;
                        i10 = c26;
                        z4 = false;
                    }
                    int e10 = gc.d.e(i15.getInt(i10));
                    c26 = i10;
                    int i22 = c27;
                    int i23 = i15.getInt(i22);
                    c27 = i22;
                    int i24 = c28;
                    int i25 = i15.getInt(i24);
                    c28 = i24;
                    int i26 = c29;
                    int d10 = gc.d.d(i15.getInt(i26));
                    c29 = i26;
                    int i27 = c30;
                    if (i15.getInt(i27) != 0) {
                        c30 = i27;
                        i11 = c31;
                        z10 = true;
                    } else {
                        c30 = i27;
                        i11 = c31;
                        z10 = false;
                    }
                    if (i15.getInt(i11) != 0) {
                        c31 = i11;
                        i12 = c32;
                        z11 = true;
                    } else {
                        c31 = i11;
                        i12 = c32;
                        z11 = false;
                    }
                    if (i15.getInt(i12) != 0) {
                        c32 = i12;
                        i13 = c33;
                        z12 = true;
                    } else {
                        c32 = i12;
                        i13 = c33;
                        z12 = false;
                    }
                    if (i15.getInt(i13) != 0) {
                        c33 = i13;
                        i14 = c34;
                        z13 = true;
                    } else {
                        c33 = i13;
                        i14 = c34;
                        z13 = false;
                    }
                    long j16 = i15.getLong(i14);
                    c34 = i14;
                    int i28 = c35;
                    long j17 = i15.getLong(i28);
                    c35 = i28;
                    int i29 = c36;
                    if (!i15.isNull(i29)) {
                        bArr = i15.getBlob(i29);
                    }
                    c36 = i29;
                    arrayList.add(new s(string, f10, string2, string3, a10, a11, j3, j10, j11, new f(d10, z10, z11, z12, z13, j16, j17, gc.d.b(bArr)), i17, c37, j12, j13, j14, j15, z4, e10, i23, i25));
                    c10 = i19;
                    i16 = i18;
                }
                i15.close();
                a0Var.q();
                return arrayList;
            } catch (Throwable th2) {
                th = th2;
                i15.close();
                a0Var.q();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            a0Var = p5;
            i15.close();
            a0Var.q();
            throw th;
        }
    }

    public final ArrayList c() {
        a0 p5 = a0.p(0, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5)");
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                arrayList.add(i10.isNull(0) ? null : i10.getString(0));
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final ArrayList d(int i10) {
        a0 a0Var;
        boolean z4;
        int i11;
        boolean z10;
        int i12;
        boolean z11;
        int i13;
        boolean z12;
        int i14;
        boolean z13;
        int i15;
        a0 p5 = a0.p(1, "SELECT * FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY last_enqueue_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))");
        p5.D(1, (long) i10);
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i16 = c0.i(xVar, p5, false);
        try {
            int c10 = j.c(i16, "id");
            int c11 = j.c(i16, "state");
            int c12 = j.c(i16, "worker_class_name");
            int c13 = j.c(i16, "input_merger_class_name");
            int c14 = j.c(i16, "input");
            int c15 = j.c(i16, "output");
            int c16 = j.c(i16, "initial_delay");
            int c17 = j.c(i16, "interval_duration");
            int c18 = j.c(i16, "flex_duration");
            int c19 = j.c(i16, "run_attempt_count");
            int c20 = j.c(i16, "backoff_policy");
            int c21 = j.c(i16, "backoff_delay_duration");
            int c22 = j.c(i16, "last_enqueue_time");
            int c23 = j.c(i16, "minimum_retention_duration");
            a0Var = p5;
            try {
                int c24 = j.c(i16, "schedule_requested_at");
                int c25 = j.c(i16, "run_in_foreground");
                int c26 = j.c(i16, "out_of_quota_policy");
                int c27 = j.c(i16, "period_count");
                int c28 = j.c(i16, "generation");
                int c29 = j.c(i16, "required_network_type");
                int c30 = j.c(i16, "requires_charging");
                int c31 = j.c(i16, "requires_device_idle");
                int c32 = j.c(i16, "requires_battery_not_low");
                int c33 = j.c(i16, "requires_storage_not_low");
                int c34 = j.c(i16, "trigger_content_update_delay");
                int c35 = j.c(i16, "trigger_max_content_delay");
                int c36 = j.c(i16, "content_uri_triggers");
                int i17 = c23;
                ArrayList arrayList = new ArrayList(i16.getCount());
                while (i16.moveToNext()) {
                    byte[] bArr = null;
                    String string = i16.isNull(c10) ? null : i16.getString(c10);
                    f0 f10 = gc.d.f(i16.getInt(c11));
                    String string2 = i16.isNull(c12) ? null : i16.getString(c12);
                    String string3 = i16.isNull(c13) ? null : i16.getString(c13);
                    r3.j a10 = r3.j.a(i16.isNull(c14) ? null : i16.getBlob(c14));
                    r3.j a11 = r3.j.a(i16.isNull(c15) ? null : i16.getBlob(c15));
                    long j3 = i16.getLong(c16);
                    long j10 = i16.getLong(c17);
                    long j11 = i16.getLong(c18);
                    int i18 = i16.getInt(c19);
                    int c37 = gc.d.c(i16.getInt(c20));
                    long j12 = i16.getLong(c21);
                    long j13 = i16.getLong(c22);
                    int i19 = i17;
                    long j14 = i16.getLong(i19);
                    int i20 = c10;
                    int i21 = c24;
                    long j15 = i16.getLong(i21);
                    c24 = i21;
                    int i22 = c25;
                    if (i16.getInt(i22) != 0) {
                        c25 = i22;
                        i11 = c26;
                        z4 = true;
                    } else {
                        c25 = i22;
                        i11 = c26;
                        z4 = false;
                    }
                    int e10 = gc.d.e(i16.getInt(i11));
                    c26 = i11;
                    int i23 = c27;
                    int i24 = i16.getInt(i23);
                    c27 = i23;
                    int i25 = c28;
                    int i26 = i16.getInt(i25);
                    c28 = i25;
                    int i27 = c29;
                    int d10 = gc.d.d(i16.getInt(i27));
                    c29 = i27;
                    int i28 = c30;
                    if (i16.getInt(i28) != 0) {
                        c30 = i28;
                        i12 = c31;
                        z10 = true;
                    } else {
                        c30 = i28;
                        i12 = c31;
                        z10 = false;
                    }
                    if (i16.getInt(i12) != 0) {
                        c31 = i12;
                        i13 = c32;
                        z11 = true;
                    } else {
                        c31 = i12;
                        i13 = c32;
                        z11 = false;
                    }
                    if (i16.getInt(i13) != 0) {
                        c32 = i13;
                        i14 = c33;
                        z12 = true;
                    } else {
                        c32 = i13;
                        i14 = c33;
                        z12 = false;
                    }
                    if (i16.getInt(i14) != 0) {
                        c33 = i14;
                        i15 = c34;
                        z13 = true;
                    } else {
                        c33 = i14;
                        i15 = c34;
                        z13 = false;
                    }
                    long j16 = i16.getLong(i15);
                    c34 = i15;
                    int i29 = c35;
                    long j17 = i16.getLong(i29);
                    c35 = i29;
                    int i30 = c36;
                    if (!i16.isNull(i30)) {
                        bArr = i16.getBlob(i30);
                    }
                    c36 = i30;
                    arrayList.add(new s(string, f10, string2, string3, a10, a11, j3, j10, j11, new f(d10, z10, z11, z12, z13, j16, j17, gc.d.b(bArr)), i18, c37, j12, j13, j14, j15, z4, e10, i24, i26));
                    c10 = i20;
                    i17 = i19;
                }
                i16.close();
                a0Var.q();
                return arrayList;
            } catch (Throwable th2) {
                th = th2;
                i16.close();
                a0Var.q();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            a0Var = p5;
            i16.close();
            a0Var.q();
            throw th;
        }
    }

    public final ArrayList e() {
        a0 a0Var;
        boolean z4;
        int i10;
        boolean z10;
        int i11;
        boolean z11;
        int i12;
        boolean z12;
        int i13;
        boolean z13;
        int i14;
        a0 p5 = a0.p(0, "SELECT * FROM workspec WHERE state=1");
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i15 = c0.i(xVar, p5, false);
        try {
            int c10 = j.c(i15, "id");
            int c11 = j.c(i15, "state");
            int c12 = j.c(i15, "worker_class_name");
            int c13 = j.c(i15, "input_merger_class_name");
            int c14 = j.c(i15, "input");
            int c15 = j.c(i15, "output");
            int c16 = j.c(i15, "initial_delay");
            int c17 = j.c(i15, "interval_duration");
            int c18 = j.c(i15, "flex_duration");
            int c19 = j.c(i15, "run_attempt_count");
            int c20 = j.c(i15, "backoff_policy");
            int c21 = j.c(i15, "backoff_delay_duration");
            int c22 = j.c(i15, "last_enqueue_time");
            int c23 = j.c(i15, "minimum_retention_duration");
            a0Var = p5;
            try {
                int c24 = j.c(i15, "schedule_requested_at");
                int c25 = j.c(i15, "run_in_foreground");
                int c26 = j.c(i15, "out_of_quota_policy");
                int c27 = j.c(i15, "period_count");
                int c28 = j.c(i15, "generation");
                int c29 = j.c(i15, "required_network_type");
                int c30 = j.c(i15, "requires_charging");
                int c31 = j.c(i15, "requires_device_idle");
                int c32 = j.c(i15, "requires_battery_not_low");
                int c33 = j.c(i15, "requires_storage_not_low");
                int c34 = j.c(i15, "trigger_content_update_delay");
                int c35 = j.c(i15, "trigger_max_content_delay");
                int c36 = j.c(i15, "content_uri_triggers");
                int i16 = c23;
                ArrayList arrayList = new ArrayList(i15.getCount());
                while (i15.moveToNext()) {
                    byte[] bArr = null;
                    String string = i15.isNull(c10) ? null : i15.getString(c10);
                    f0 f10 = gc.d.f(i15.getInt(c11));
                    String string2 = i15.isNull(c12) ? null : i15.getString(c12);
                    String string3 = i15.isNull(c13) ? null : i15.getString(c13);
                    r3.j a10 = r3.j.a(i15.isNull(c14) ? null : i15.getBlob(c14));
                    r3.j a11 = r3.j.a(i15.isNull(c15) ? null : i15.getBlob(c15));
                    long j3 = i15.getLong(c16);
                    long j10 = i15.getLong(c17);
                    long j11 = i15.getLong(c18);
                    int i17 = i15.getInt(c19);
                    int c37 = gc.d.c(i15.getInt(c20));
                    long j12 = i15.getLong(c21);
                    long j13 = i15.getLong(c22);
                    int i18 = i16;
                    long j14 = i15.getLong(i18);
                    int i19 = c10;
                    int i20 = c24;
                    long j15 = i15.getLong(i20);
                    c24 = i20;
                    int i21 = c25;
                    if (i15.getInt(i21) != 0) {
                        c25 = i21;
                        i10 = c26;
                        z4 = true;
                    } else {
                        c25 = i21;
                        i10 = c26;
                        z4 = false;
                    }
                    int e10 = gc.d.e(i15.getInt(i10));
                    c26 = i10;
                    int i22 = c27;
                    int i23 = i15.getInt(i22);
                    c27 = i22;
                    int i24 = c28;
                    int i25 = i15.getInt(i24);
                    c28 = i24;
                    int i26 = c29;
                    int d10 = gc.d.d(i15.getInt(i26));
                    c29 = i26;
                    int i27 = c30;
                    if (i15.getInt(i27) != 0) {
                        c30 = i27;
                        i11 = c31;
                        z10 = true;
                    } else {
                        c30 = i27;
                        i11 = c31;
                        z10 = false;
                    }
                    if (i15.getInt(i11) != 0) {
                        c31 = i11;
                        i12 = c32;
                        z11 = true;
                    } else {
                        c31 = i11;
                        i12 = c32;
                        z11 = false;
                    }
                    if (i15.getInt(i12) != 0) {
                        c32 = i12;
                        i13 = c33;
                        z12 = true;
                    } else {
                        c32 = i12;
                        i13 = c33;
                        z12 = false;
                    }
                    if (i15.getInt(i13) != 0) {
                        c33 = i13;
                        i14 = c34;
                        z13 = true;
                    } else {
                        c33 = i13;
                        i14 = c34;
                        z13 = false;
                    }
                    long j16 = i15.getLong(i14);
                    c34 = i14;
                    int i28 = c35;
                    long j17 = i15.getLong(i28);
                    c35 = i28;
                    int i29 = c36;
                    if (!i15.isNull(i29)) {
                        bArr = i15.getBlob(i29);
                    }
                    c36 = i29;
                    arrayList.add(new s(string, f10, string2, string3, a10, a11, j3, j10, j11, new f(d10, z10, z11, z12, z13, j16, j17, gc.d.b(bArr)), i17, c37, j12, j13, j14, j15, z4, e10, i23, i25));
                    c10 = i19;
                    i16 = i18;
                }
                i15.close();
                a0Var.q();
                return arrayList;
            } catch (Throwable th2) {
                th = th2;
                i15.close();
                a0Var.q();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            a0Var = p5;
            i15.close();
            a0Var.q();
            throw th;
        }
    }

    public final ArrayList f() {
        a0 a0Var;
        boolean z4;
        int i10;
        boolean z10;
        int i11;
        boolean z11;
        int i12;
        boolean z12;
        int i13;
        boolean z13;
        int i14;
        a0 p5 = a0.p(0, "SELECT * FROM workspec WHERE state=0 AND schedule_requested_at<>-1");
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i15 = c0.i(xVar, p5, false);
        try {
            int c10 = j.c(i15, "id");
            int c11 = j.c(i15, "state");
            int c12 = j.c(i15, "worker_class_name");
            int c13 = j.c(i15, "input_merger_class_name");
            int c14 = j.c(i15, "input");
            int c15 = j.c(i15, "output");
            int c16 = j.c(i15, "initial_delay");
            int c17 = j.c(i15, "interval_duration");
            int c18 = j.c(i15, "flex_duration");
            int c19 = j.c(i15, "run_attempt_count");
            int c20 = j.c(i15, "backoff_policy");
            int c21 = j.c(i15, "backoff_delay_duration");
            int c22 = j.c(i15, "last_enqueue_time");
            int c23 = j.c(i15, "minimum_retention_duration");
            a0Var = p5;
            try {
                int c24 = j.c(i15, "schedule_requested_at");
                int c25 = j.c(i15, "run_in_foreground");
                int c26 = j.c(i15, "out_of_quota_policy");
                int c27 = j.c(i15, "period_count");
                int c28 = j.c(i15, "generation");
                int c29 = j.c(i15, "required_network_type");
                int c30 = j.c(i15, "requires_charging");
                int c31 = j.c(i15, "requires_device_idle");
                int c32 = j.c(i15, "requires_battery_not_low");
                int c33 = j.c(i15, "requires_storage_not_low");
                int c34 = j.c(i15, "trigger_content_update_delay");
                int c35 = j.c(i15, "trigger_max_content_delay");
                int c36 = j.c(i15, "content_uri_triggers");
                int i16 = c23;
                ArrayList arrayList = new ArrayList(i15.getCount());
                while (i15.moveToNext()) {
                    byte[] bArr = null;
                    String string = i15.isNull(c10) ? null : i15.getString(c10);
                    f0 f10 = gc.d.f(i15.getInt(c11));
                    String string2 = i15.isNull(c12) ? null : i15.getString(c12);
                    String string3 = i15.isNull(c13) ? null : i15.getString(c13);
                    r3.j a10 = r3.j.a(i15.isNull(c14) ? null : i15.getBlob(c14));
                    r3.j a11 = r3.j.a(i15.isNull(c15) ? null : i15.getBlob(c15));
                    long j3 = i15.getLong(c16);
                    long j10 = i15.getLong(c17);
                    long j11 = i15.getLong(c18);
                    int i17 = i15.getInt(c19);
                    int c37 = gc.d.c(i15.getInt(c20));
                    long j12 = i15.getLong(c21);
                    long j13 = i15.getLong(c22);
                    int i18 = i16;
                    long j14 = i15.getLong(i18);
                    int i19 = c10;
                    int i20 = c24;
                    long j15 = i15.getLong(i20);
                    c24 = i20;
                    int i21 = c25;
                    if (i15.getInt(i21) != 0) {
                        c25 = i21;
                        i10 = c26;
                        z4 = true;
                    } else {
                        c25 = i21;
                        i10 = c26;
                        z4 = false;
                    }
                    int e10 = gc.d.e(i15.getInt(i10));
                    c26 = i10;
                    int i22 = c27;
                    int i23 = i15.getInt(i22);
                    c27 = i22;
                    int i24 = c28;
                    int i25 = i15.getInt(i24);
                    c28 = i24;
                    int i26 = c29;
                    int d10 = gc.d.d(i15.getInt(i26));
                    c29 = i26;
                    int i27 = c30;
                    if (i15.getInt(i27) != 0) {
                        c30 = i27;
                        i11 = c31;
                        z10 = true;
                    } else {
                        c30 = i27;
                        i11 = c31;
                        z10 = false;
                    }
                    if (i15.getInt(i11) != 0) {
                        c31 = i11;
                        i12 = c32;
                        z11 = true;
                    } else {
                        c31 = i11;
                        i12 = c32;
                        z11 = false;
                    }
                    if (i15.getInt(i12) != 0) {
                        c32 = i12;
                        i13 = c33;
                        z12 = true;
                    } else {
                        c32 = i12;
                        i13 = c33;
                        z12 = false;
                    }
                    if (i15.getInt(i13) != 0) {
                        c33 = i13;
                        i14 = c34;
                        z13 = true;
                    } else {
                        c33 = i13;
                        i14 = c34;
                        z13 = false;
                    }
                    long j16 = i15.getLong(i14);
                    c34 = i14;
                    int i28 = c35;
                    long j17 = i15.getLong(i28);
                    c35 = i28;
                    int i29 = c36;
                    if (!i15.isNull(i29)) {
                        bArr = i15.getBlob(i29);
                    }
                    c36 = i29;
                    arrayList.add(new s(string, f10, string2, string3, a10, a11, j3, j10, j11, new f(d10, z10, z11, z12, z13, j16, j17, gc.d.b(bArr)), i17, c37, j12, j13, j14, j15, z4, e10, i23, i25));
                    c10 = i19;
                    i16 = i18;
                }
                i15.close();
                a0Var.q();
                return arrayList;
            } catch (Throwable th2) {
                th = th2;
                i15.close();
                a0Var.q();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            a0Var = p5;
            i15.close();
            a0Var.q();
            throw th;
        }
    }

    public final f0 g(String str) {
        a0 p5 = a0.p(1, "SELECT state FROM workspec WHERE id=?");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            f0 f0Var = null;
            if (i10.moveToFirst()) {
                Integer valueOf = i10.isNull(0) ? null : Integer.valueOf(i10.getInt(0));
                if (valueOf != null) {
                    f0Var = gc.d.f(valueOf.intValue());
                }
            }
            return f0Var;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final ArrayList h(String str) {
        a0 p5 = a0.p(1, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                arrayList.add(i10.isNull(0) ? null : i10.getString(0));
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final ArrayList i(String str) {
        a0 p5 = a0.p(1, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM worktag WHERE tag=?)");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                arrayList.add(i10.isNull(0) ? null : i10.getString(0));
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v1, resolved type: a4.s} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v2, resolved type: byte[]} */
    /* JADX WARNING: type inference failed for: r30v0 */
    /* JADX WARNING: type inference failed for: r31v1, types: [a4.s] */
    /* JADX WARNING: type inference failed for: r30v5 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final a4.s j(java.lang.String r71) {
        /*
            r70 = this;
            r0 = r71
            java.lang.String r1 = "SELECT * FROM workspec WHERE id=?"
            r2 = 1
            a3.a0 r1 = a3.a0.p(r2, r1)
            if (r0 != 0) goto L_0x0011
            r1.t(r2)
        L_0x000e:
            r3 = r70
            goto L_0x0015
        L_0x0011:
            r1.m(r2, r0)
            goto L_0x000e
        L_0x0015:
            java.lang.Object r0 = r3.f600b
            a3.x r0 = (a3.x) r0
            r0.b()
            r4 = 0
            android.database.Cursor r5 = ne.c0.i(r0, r1, r4)
            java.lang.String r0 = "id"
            int r0 = he.j.c(r5, r0)     // Catch:{ all -> 0x0204 }
            java.lang.String r6 = "state"
            int r6 = he.j.c(r5, r6)     // Catch:{ all -> 0x0204 }
            java.lang.String r7 = "worker_class_name"
            int r7 = he.j.c(r5, r7)     // Catch:{ all -> 0x0204 }
            java.lang.String r8 = "input_merger_class_name"
            int r8 = he.j.c(r5, r8)     // Catch:{ all -> 0x0204 }
            java.lang.String r9 = "input"
            int r9 = he.j.c(r5, r9)     // Catch:{ all -> 0x0204 }
            java.lang.String r10 = "output"
            int r10 = he.j.c(r5, r10)     // Catch:{ all -> 0x0204 }
            java.lang.String r11 = "initial_delay"
            int r11 = he.j.c(r5, r11)     // Catch:{ all -> 0x0204 }
            java.lang.String r12 = "interval_duration"
            int r12 = he.j.c(r5, r12)     // Catch:{ all -> 0x0204 }
            java.lang.String r13 = "flex_duration"
            int r13 = he.j.c(r5, r13)     // Catch:{ all -> 0x0204 }
            java.lang.String r14 = "run_attempt_count"
            int r14 = he.j.c(r5, r14)     // Catch:{ all -> 0x0204 }
            java.lang.String r15 = "backoff_policy"
            int r15 = he.j.c(r5, r15)     // Catch:{ all -> 0x0204 }
            java.lang.String r2 = "backoff_delay_duration"
            int r2 = he.j.c(r5, r2)     // Catch:{ all -> 0x0204 }
            java.lang.String r4 = "last_enqueue_time"
            int r4 = he.j.c(r5, r4)     // Catch:{ all -> 0x0204 }
            java.lang.String r3 = "minimum_retention_duration"
            int r3 = he.j.c(r5, r3)     // Catch:{ all -> 0x0204 }
            r16 = r1
            java.lang.String r1 = "schedule_requested_at"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r17 = r1
            java.lang.String r1 = "run_in_foreground"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r18 = r1
            java.lang.String r1 = "out_of_quota_policy"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r19 = r1
            java.lang.String r1 = "period_count"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r20 = r1
            java.lang.String r1 = "generation"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r21 = r1
            java.lang.String r1 = "required_network_type"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r22 = r1
            java.lang.String r1 = "requires_charging"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r23 = r1
            java.lang.String r1 = "requires_device_idle"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r24 = r1
            java.lang.String r1 = "requires_battery_not_low"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r25 = r1
            java.lang.String r1 = "requires_storage_not_low"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r26 = r1
            java.lang.String r1 = "trigger_content_update_delay"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r27 = r1
            java.lang.String r1 = "trigger_max_content_delay"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            r28 = r1
            java.lang.String r1 = "content_uri_triggers"
            int r1 = he.j.c(r5, r1)     // Catch:{ all -> 0x01fb }
            boolean r29 = r5.moveToFirst()     // Catch:{ all -> 0x01fb }
            r30 = 0
            if (r29 == 0) goto L_0x01fd
            boolean r29 = r5.isNull(r0)     // Catch:{ all -> 0x01fb }
            if (r29 == 0) goto L_0x00ee
            r32 = r30
            goto L_0x00f4
        L_0x00ee:
            java.lang.String r0 = r5.getString(r0)     // Catch:{ all -> 0x01fb }
            r32 = r0
        L_0x00f4:
            int r0 = r5.getInt(r6)     // Catch:{ all -> 0x01fb }
            r3.f0 r33 = gc.d.f(r0)     // Catch:{ all -> 0x01fb }
            boolean r0 = r5.isNull(r7)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x0105
            r34 = r30
            goto L_0x010b
        L_0x0105:
            java.lang.String r0 = r5.getString(r7)     // Catch:{ all -> 0x01fb }
            r34 = r0
        L_0x010b:
            boolean r0 = r5.isNull(r8)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x0114
            r35 = r30
            goto L_0x011a
        L_0x0114:
            java.lang.String r0 = r5.getString(r8)     // Catch:{ all -> 0x01fb }
            r35 = r0
        L_0x011a:
            boolean r0 = r5.isNull(r9)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x0123
            r0 = r30
            goto L_0x0127
        L_0x0123:
            byte[] r0 = r5.getBlob(r9)     // Catch:{ all -> 0x01fb }
        L_0x0127:
            r3.j r36 = r3.j.a(r0)     // Catch:{ all -> 0x01fb }
            boolean r0 = r5.isNull(r10)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x0134
            r0 = r30
            goto L_0x0138
        L_0x0134:
            byte[] r0 = r5.getBlob(r10)     // Catch:{ all -> 0x01fb }
        L_0x0138:
            r3.j r37 = r3.j.a(r0)     // Catch:{ all -> 0x01fb }
            long r38 = r5.getLong(r11)     // Catch:{ all -> 0x01fb }
            long r40 = r5.getLong(r12)     // Catch:{ all -> 0x01fb }
            long r42 = r5.getLong(r13)     // Catch:{ all -> 0x01fb }
            int r45 = r5.getInt(r14)     // Catch:{ all -> 0x01fb }
            int r0 = r5.getInt(r15)     // Catch:{ all -> 0x01fb }
            int r46 = gc.d.c(r0)     // Catch:{ all -> 0x01fb }
            long r47 = r5.getLong(r2)     // Catch:{ all -> 0x01fb }
            long r49 = r5.getLong(r4)     // Catch:{ all -> 0x01fb }
            long r51 = r5.getLong(r3)     // Catch:{ all -> 0x01fb }
            r0 = r17
            long r53 = r5.getLong(r0)     // Catch:{ all -> 0x01fb }
            r0 = r18
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x0173
            r0 = r19
            r55 = 1
            goto L_0x0177
        L_0x0173:
            r0 = r19
            r55 = 0
        L_0x0177:
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            int r56 = gc.d.e(r0)     // Catch:{ all -> 0x01fb }
            r0 = r20
            int r57 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            r0 = r21
            int r58 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            r0 = r22
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            int r60 = gc.d.d(r0)     // Catch:{ all -> 0x01fb }
            r0 = r23
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x01a2
            r0 = r24
            r61 = 1
            goto L_0x01a6
        L_0x01a2:
            r0 = r24
            r61 = 0
        L_0x01a6:
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x01b1
            r0 = r25
            r62 = 1
            goto L_0x01b5
        L_0x01b1:
            r0 = r25
            r62 = 0
        L_0x01b5:
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x01c0
            r0 = r26
            r63 = 1
            goto L_0x01c4
        L_0x01c0:
            r0 = r26
            r63 = 0
        L_0x01c4:
            int r0 = r5.getInt(r0)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x01cf
            r0 = r27
            r64 = 1
            goto L_0x01d3
        L_0x01cf:
            r0 = r27
            r64 = 0
        L_0x01d3:
            long r65 = r5.getLong(r0)     // Catch:{ all -> 0x01fb }
            r0 = r28
            long r67 = r5.getLong(r0)     // Catch:{ all -> 0x01fb }
            boolean r0 = r5.isNull(r1)     // Catch:{ all -> 0x01fb }
            if (r0 == 0) goto L_0x01e4
            goto L_0x01e8
        L_0x01e4:
            byte[] r30 = r5.getBlob(r1)     // Catch:{ all -> 0x01fb }
        L_0x01e8:
            java.util.LinkedHashSet r69 = gc.d.b(r30)     // Catch:{ all -> 0x01fb }
            r3.f r44 = new r3.f     // Catch:{ all -> 0x01fb }
            r59 = r44
            r59.<init>(r60, r61, r62, r63, r64, r65, r67, r69)     // Catch:{ all -> 0x01fb }
            a4.s r30 = new a4.s     // Catch:{ all -> 0x01fb }
            r31 = r30
            r31.<init>(r32, r33, r34, r35, r36, r37, r38, r40, r42, r44, r45, r46, r47, r49, r51, r53, r55, r56, r57, r58)     // Catch:{ all -> 0x01fb }
            goto L_0x01fd
        L_0x01fb:
            r0 = move-exception
            goto L_0x0207
        L_0x01fd:
            r5.close()
            r16.q()
            return r30
        L_0x0204:
            r0 = move-exception
            r16 = r1
        L_0x0207:
            r5.close()
            r16.q()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.u.j(java.lang.String):a4.s");
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [java.lang.Object, a4.q] */
    public final ArrayList k(String str) {
        String str2;
        a0 p5 = a0.p(1, "SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)");
        if (str == null) {
            p5.t(1);
        } else {
            p5.m(1, str);
        }
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            ArrayList arrayList = new ArrayList(i10.getCount());
            while (i10.moveToNext()) {
                if (i10.isNull(0)) {
                    str2 = null;
                } else {
                    str2 = i10.getString(0);
                }
                f0 f10 = gc.d.f(i10.getInt(1));
                r0.j("id", str2);
                ? obj = new Object();
                obj.f567a = str2;
                obj.f568b = f10;
                arrayList.add(obj);
            }
            return arrayList;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final boolean l() {
        boolean z4 = false;
        a0 p5 = a0.p(0, "SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1");
        x xVar = (x) this.f600b;
        xVar.b();
        Cursor i10 = c0.i(xVar, p5, false);
        try {
            if (i10.moveToFirst() && i10.getInt(0) != 0) {
                z4 = true;
            }
            return z4;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final void m(String str) {
        Object obj = this.f600b;
        ((x) obj).b();
        Object obj2 = this.f605g;
        i c10 = ((d) obj2).c();
        if (str == null) {
            c10.t(1);
        } else {
            c10.m(1, str);
        }
        ((x) obj).c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            ((x) obj).j();
            ((d) obj2).x(c10);
        }
    }

    public final void n(String str) {
        Object obj = this.f600b;
        x xVar = (x) obj;
        xVar.b();
        d dVar = (d) this.f608j;
        i c10 = dVar.c();
        if (str == null) {
            c10.t(1);
        } else {
            c10.m(1, str);
        }
        xVar.c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            xVar.j();
            dVar.x(c10);
        }
    }

    public final void o(long j3, String str) {
        Object obj = this.f600b;
        x xVar = (x) obj;
        xVar.b();
        d dVar = (d) this.f610l;
        i c10 = dVar.c();
        c10.D(1, j3);
        if (str == null) {
            c10.t(2);
        } else {
            c10.m(2, str);
        }
        xVar.c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            xVar.j();
            dVar.x(c10);
        }
    }

    public final void p(String str) {
        Object obj = this.f600b;
        x xVar = (x) obj;
        xVar.b();
        d dVar = (d) this.f609k;
        i c10 = dVar.c();
        if (str == null) {
            c10.t(1);
        } else {
            c10.m(1, str);
        }
        xVar.c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            xVar.j();
            dVar.x(c10);
        }
    }

    public final void q(long j3, String str) {
        Object obj = this.f600b;
        ((x) obj).b();
        Object obj2 = this.f607i;
        i c10 = ((d) obj2).c();
        c10.D(1, j3);
        if (str == null) {
            c10.t(2);
        } else {
            c10.m(2, str);
        }
        ((x) obj).c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            ((x) obj).j();
            ((d) obj2).x(c10);
        }
    }

    public final void r(String str, r3.j jVar) {
        Object obj = this.f600b;
        ((x) obj).b();
        Object obj2 = this.f606h;
        i c10 = ((d) obj2).c();
        byte[] c11 = r3.j.c(jVar);
        if (c11 == null) {
            c10.t(1);
        } else {
            c10.G(1, c11);
        }
        if (str == null) {
            c10.t(2);
        } else {
            c10.m(2, str);
        }
        ((x) obj).c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            ((x) obj).j();
            ((d) obj2).x(c10);
        }
    }

    public final void s(f0 f0Var, String str) {
        Object obj = this.f600b;
        x xVar = (x) obj;
        xVar.b();
        d dVar = (d) this.f604f;
        i c10 = dVar.c();
        c10.D(1, (long) gc.d.j(f0Var));
        if (str == null) {
            c10.t(2);
        } else {
            c10.m(2, str);
        }
        xVar.c();
        try {
            c10.r();
            ((x) obj).n();
        } finally {
            xVar.j();
            dVar.x(c10);
        }
    }

    /* JADX WARNING: type inference failed for: r9v2, types: [com.google.android.gms.internal.ads.em0, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r10v8, types: [com.google.android.gms.internal.ads.pq, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r10v12, types: [com.google.android.gms.internal.ads.pq, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r10v14, types: [com.google.android.gms.internal.ads.pq, java.lang.Object] */
    public final gm0 t() {
        boolean z4;
        int i10;
        boolean z10;
        List list;
        String str;
        PackageInfo packageInfo;
        int i11 = this.f599a;
        Object obj = this.f600b;
        Object obj2 = this.f601c;
        switch (i11) {
            case 1:
                mv mvVar = (mv) obj2;
                Context context = (Context) mvVar.f10362b.f13502c;
                cq0.X0(context);
                hk hkVar = new hk(11);
                kr krVar = lr.f10046a;
                cq0.X0(krVar);
                String h10 = ((wm0) obj).h();
                cq0.X0(h10);
                HashSet hashSet = new HashSet();
                hashSet.add(new pl0(new nl0((Object) hkVar, (ExecutorService) krVar, (Object) h10, 5), 0, (ScheduledExecutorService) mvVar.f10370f.c()));
                return new gm0(context, krVar, hashSet, (vr0) ((eg1) this.f613o).c(), (qa0) mvVar.E.c());
            default:
                mv mvVar2 = (mv) obj2;
                Context context2 = (Context) mvVar2.f10362b.f13502c;
                cq0.X0(context2);
                kr krVar2 = lr.f10046a;
                cq0.X0(krVar2);
                qm0 qm0 = (qm0) obj;
                cq0.X0(qm0.v());
                ? obj3 = new Object();
                eg1 eg1 = mvVar2.f10370f;
                pl0 pl0 = new pl0(obj3, 0, (ScheduledExecutorService) eg1.c());
                wu wuVar = mvVar2.f10362b;
                Context context3 = (Context) wuVar.f13502c;
                cq0.X0(context3);
                pl0 pl02 = new pl0(new nl0((Object) new hk(5), (ExecutorService) (ScheduledExecutorService) eg1.c(), (Object) context3, 7), ((Long) q.f24015d.f24018c.a(he.B3)).longValue(), (ScheduledExecutorService) eg1.c());
                ? obj4 = new Object();
                Context context4 = (Context) wuVar.f13502c;
                cq0.X0(context4);
                ScheduledExecutorService scheduledExecutorService = (ScheduledExecutorService) eg1.c();
                int a10 = qm0.a();
                int i12 = qm0.f11597a;
                switch (i12) {
                    case 0:
                        z4 = ((zzbve) qm0.f11599c).f14717i;
                        break;
                    default:
                        z4 = ((zzbwa) qm0.f11599c).f14740l;
                        break;
                }
                switch (i12) {
                    case 0:
                        i10 = i12;
                        z10 = ((zzbve) qm0.f11599c).f14716h;
                        break;
                    default:
                        i10 = i12;
                        z10 = ((zzbwa) qm0.f11599c).f14729a.getBoolean("is_gbid");
                        break;
                }
                nm0 nm0 = r9;
                pl0 pl03 = pl02;
                ScheduledExecutorService scheduledExecutorService2 = scheduledExecutorService;
                wu wuVar2 = wuVar;
                pl0 pl04 = pl0;
                eg1 eg12 = eg1;
                nm0 nm02 = new nm0(obj4, context4, scheduledExecutorService2, krVar2, a10, z4, z10);
                pl0 pl05 = new pl0(nm0, 0, (ScheduledExecutorService) eg12.c());
                pl0 pl06 = new pl0(new sk0(krVar2, 4), 0, (ScheduledExecutorService) eg12.c());
                Context context5 = (Context) wuVar2.f13502c;
                cq0.X0(context5);
                String v10 = qm0.v();
                cq0.X0(v10);
                nl0 nl0 = new nl0(context5, v10, krVar2);
                em0[] em0Arr = new em0[6];
                s sVar = new s(13);
                Context context6 = (Context) wuVar2.f13502c;
                cq0.X0(context6);
                em0Arr[0] = new nl0((Object) sVar, (ExecutorService) krVar2, (Object) context6, 4);
                s sVar2 = new s(22);
                switch (i10) {
                    case 0:
                        list = ((zzbve) qm0.f11599c).f14715g;
                        break;
                    default:
                        list = ((zzbwa) qm0.f11599c).f14733e;
                        break;
                }
                cq0.X0(list);
                em0Arr[1] = new nl0((Object) sVar2, (ExecutorService) krVar2, (Object) list, 6);
                ? obj5 = new Object();
                switch (i10) {
                    case 0:
                        str = ((zzbve) qm0.f11599c).f14712d;
                        break;
                    default:
                        str = cq0.h1(((zzbwa) qm0.f11599c).f14729a.getString("ms"));
                        break;
                }
                cq0.X0(str);
                switch (i10) {
                    case 0:
                        packageInfo = ((zzbve) qm0.f11599c).f14711c;
                        break;
                    default:
                        packageInfo = ((zzbwa) qm0.f11599c).f14734f;
                        break;
                }
                qm0.a();
                em0Arr[2] = new dk0((pq) obj5, krVar2, str, packageInfo);
                ? obj6 = new Object();
                qm0.a();
                Context context7 = (Context) wuVar2.f13502c;
                cq0.X0(context7);
                eg1 eg13 = mvVar2.L;
                String v11 = qm0.v();
                cq0.X0(v11);
                em0[] em0Arr2 = em0Arr;
                pl0 pl07 = pl06;
                em0Arr2[3] = new yl0((pq) obj6, context7, (uq) eg13.c(), (ScheduledExecutorService) eg12.c(), krVar2, v11);
                em0Arr2[4] = (em0) mvVar2.f10385m0.c();
                String v12 = qm0.v();
                cq0.X0(v12);
                em0Arr2[5] = new xj0(v12, new s(12), (uq) eg13.c(), (ScheduledExecutorService) eg12.c(), krVar2);
                return new gm0(context2, krVar2, yx0.F(pl04, pl03, pl05, pl07, nl0, em0Arr2), (vr0) ((eg1) this.f603e).c(), (qa0) mvVar2.E.c());
        }
    }

    public u(mv mvVar, qm0 qm0) {
        this.f599a = 2;
        this.f602d = this;
        this.f601c = mvVar;
        this.f600b = qm0;
        this.f603e = wf1.b(new gk0(mvVar.f10390r, 16));
        kw kwVar = new kw(2, qm0);
        this.f604f = kwVar;
        eg1 b5 = wf1.b(o40.f10804m);
        this.f605g = b5;
        eg1 b10 = wf1.b(o40.f10803l);
        this.f606h = b10;
        eg1 b11 = wf1.b(o40.f10805n);
        this.f607i = b11;
        eg1 b12 = wf1.b(o40.f10806o);
        this.f608j = b12;
        int i10 = zf1.f14367b;
        LinkedHashMap C0 = cq0.C0(4);
        C0.put(dr0.GMS_SIGNALS, b5);
        C0.put(dr0.BUILD_URL, b10);
        C0.put(dr0.HTTP, b11);
        C0.put(dr0.PRE_PROCESS, b12);
        uf1 uf1 = new uf1(C0);
        this.f609k = uf1;
        zu zuVar = mvVar.f10366d;
        ba0 ba0 = cq0.f6815f;
        eg1 b13 = wf1.b(new te(kwVar, zuVar, ba0, uf1, 14));
        this.f610l = b13;
        int i11 = cg1.f6727c;
        List emptyList = Collections.emptyList();
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(b13);
        cg1 cg1 = new cg1(emptyList, arrayList);
        this.f611m = cg1;
        gr0 gr0 = new gr0(cg1);
        this.f612n = gr0;
        this.f613o = wf1.b(new qc0(ba0, mvVar.f10370f, gr0, 16));
    }

    public u(mv mvVar, wm0 wm0) {
        this.f599a = 1;
        this.f602d = this;
        this.f601c = mvVar;
        this.f600b = wm0;
        kw kwVar = new kw(3, wm0);
        this.f603e = kwVar;
        eg1 b5 = wf1.b(o40.f10804m);
        this.f604f = b5;
        eg1 b10 = wf1.b(o40.f10803l);
        this.f605g = b10;
        eg1 b11 = wf1.b(o40.f10805n);
        this.f606h = b11;
        eg1 b12 = wf1.b(o40.f10806o);
        this.f607i = b12;
        int i10 = zf1.f14367b;
        LinkedHashMap C0 = cq0.C0(4);
        C0.put(dr0.GMS_SIGNALS, b5);
        C0.put(dr0.BUILD_URL, b10);
        C0.put(dr0.HTTP, b11);
        C0.put(dr0.PRE_PROCESS, b12);
        uf1 uf1 = new uf1(C0);
        this.f608j = uf1;
        zu zuVar = mvVar.f10366d;
        ba0 ba0 = cq0.f6815f;
        eg1 b13 = wf1.b(new te(kwVar, zuVar, ba0, uf1, 14));
        this.f609k = b13;
        int i11 = cg1.f6727c;
        List emptyList = Collections.emptyList();
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(b13);
        cg1 cg1 = new cg1(emptyList, arrayList);
        this.f610l = cg1;
        gr0 gr0 = new gr0(cg1);
        this.f611m = gr0;
        this.f612n = wf1.b(new qc0(ba0, mvVar.f10370f, gr0, 16));
        this.f613o = wf1.b(new gk0(mvVar.f10390r, 16));
    }
}
