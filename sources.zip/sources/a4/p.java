package a4;

import a3.x;
import android.util.SparseArray;
import android.view.Surface;
import e0.c;
import f3.i;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import kg.n;
import kg.q;
import kg.r;
import kg.u;
import m.d;
import na.o0;
import na.z0;
import s0.k;
import t0.j;
import u0.e;
import u0.h;
import uf.b;
import v7.r0;
import w7.ua;
import wb.a;
import we.b0;
import we.d0;
import we.f;
import we.f0;

public final class p implements c {

    /* renamed from: a  reason: collision with root package name */
    public Object f563a;

    /* renamed from: b  reason: collision with root package name */
    public Object f564b;

    /* renamed from: c  reason: collision with root package name */
    public Object f565c;

    /* renamed from: d  reason: collision with root package name */
    public Object f566d;

    public p(int i10) {
        if (i10 == 3) {
            this.f563a = new e(256, 0);
            this.f564b = new e(256, 0);
            this.f565c = new e(256, 0);
            this.f566d = new h[32];
        } else if (i10 == 5) {
            this.f563a = new k();
            this.f564b = new SparseArray();
            this.f565c = new s0.e();
            this.f566d = new k();
        } else if (i10 == 7) {
            this.f563a = null;
            this.f564b = new ArrayList();
            this.f565c = null;
            this.f566d = "";
        } else if (i10 == 8) {
            this.f566d = Collections.emptyList();
        }
    }

    public final void D(Throwable th2) {
        if (th2 instanceof CancellationException) {
            ua.g((String) null, ((j) this.f564b).b(new RuntimeException(l.J(new StringBuilder(), (String) this.f565c, " cancelled."), th2)));
        } else {
            ((j) this.f564b).a((Object) null);
        }
    }

    public final o0 a() {
        String str;
        if (((Long) this.f563a) == null) {
            str = " baseAddress";
        } else {
            str = "";
        }
        if (((Long) this.f564b) == null) {
            str = str.concat(" size");
        }
        if (((String) this.f565c) == null) {
            str = l.H(str, " name");
        }
        if (str.isEmpty()) {
            return new o0(((Long) this.f563a).longValue(), ((Long) this.f564b).longValue(), (String) this.f565c, (String) this.f566d);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final z0 b() {
        String str;
        if (((Integer) this.f563a) == null) {
            str = " platform";
        } else {
            str = "";
        }
        if (((String) this.f564b) == null) {
            str = str.concat(" version");
        }
        if (((String) this.f565c) == null) {
            str = l.H(str, " buildVersion");
        }
        if (((Boolean) this.f566d) == null) {
            str = l.H(str, " jailbroken");
        }
        if (str.isEmpty()) {
            return new z0(((Integer) this.f563a).intValue(), (String) this.f564b, (String) this.f565c, ((Boolean) this.f566d).booleanValue());
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public final void c(String str) {
        ((x) this.f563a).b();
        i c10 = ((d) this.f565c).c();
        if (str == null) {
            c10.t(1);
        } else {
            c10.m(1, str);
        }
        ((x) this.f563a).c();
        try {
            c10.r();
            ((x) this.f563a).n();
        } finally {
            ((x) this.f563a).j();
            ((d) this.f565c).x(c10);
        }
    }

    public final void d() {
        ((x) this.f563a).b();
        i c10 = ((d) this.f566d).c();
        ((x) this.f563a).c();
        try {
            c10.r();
            ((x) this.f563a).n();
        } finally {
            ((x) this.f563a).j();
            ((d) this.f566d).x(c10);
        }
    }

    public final f e(b bVar, List list) {
        r0.j("classId", bVar);
        return (f) ((n) ((r) this.f566d)).h(new d0(bVar, list));
    }

    public final void f(n nVar) {
        ((x) this.f563a).b();
        ((x) this.f563a).c();
        try {
            ((a3.e) this.f564b).M(nVar);
            ((x) this.f563a).n();
        } finally {
            ((x) this.f563a).j();
        }
    }

    public final p g() {
        return new p(this, (a) this.f564b);
    }

    public final com.google.android.gms.internal.measurement.n h(com.google.android.gms.internal.measurement.e eVar) {
        com.google.android.gms.internal.measurement.n nVar = com.google.android.gms.internal.measurement.n.A0;
        Iterator J = eVar.J();
        while (J.hasNext()) {
            nVar = ((a) this.f564b).v(this, eVar.C(((Integer) J.next()).intValue()));
            if (nVar instanceof com.google.android.gms.internal.measurement.h) {
                break;
            }
        }
        return nVar;
    }

    public final com.google.android.gms.internal.measurement.n i(com.google.android.gms.internal.measurement.n nVar) {
        return ((a) this.f564b).v(this, nVar);
    }

    public final com.google.android.gms.internal.measurement.n j(String str) {
        p pVar = this;
        while (!((Map) pVar.f565c).containsKey(str)) {
            Object obj = pVar.f563a;
            if (((p) obj) != null) {
                pVar = (p) obj;
            } else {
                throw new IllegalArgumentException(String.format("%s is not defined", new Object[]{str}));
            }
        }
        return (com.google.android.gms.internal.measurement.n) ((Map) pVar.f565c).get(str);
    }

    public final void k(String str, com.google.android.gms.internal.measurement.n nVar) {
        if (((Map) this.f566d).containsKey(str)) {
            return;
        }
        if (nVar == null) {
            ((Map) this.f565c).remove(str);
        } else {
            ((Map) this.f565c).put(str, nVar);
        }
    }

    public final boolean l(String str) {
        p pVar = this;
        while (!((Map) pVar.f565c).containsKey(str)) {
            Object obj = pVar.f563a;
            if (((p) obj) == null) {
                return false;
            }
            pVar = (p) obj;
        }
        return true;
    }

    public final void m(String str, com.google.android.gms.internal.measurement.n nVar) {
        p pVar = this;
        while (!((Map) pVar.f565c).containsKey(str)) {
            Object obj = pVar.f563a;
            if (((p) obj) == null || !((p) obj).l(str)) {
                break;
            }
            pVar = (p) pVar.f563a;
        }
        if (((Map) pVar.f566d).containsKey(str)) {
            return;
        }
        if (nVar == null) {
            ((Map) pVar.f565c).remove(str);
        } else {
            ((Map) pVar.f565c).put(str, nVar);
        }
    }

    public final void onSuccess(Object obj) {
        Surface surface = (Surface) obj;
        e0.f.f(true, (y9.a) this.f563a, (j) this.f564b, ua.k());
    }

    public p(p pVar, a aVar) {
        this.f565c = new HashMap();
        this.f566d = new HashMap();
        this.f563a = pVar;
        this.f564b = aVar;
    }

    public p(u uVar, b0 b0Var) {
        r0.j("storageManager", uVar);
        r0.j("module", b0Var);
        this.f563a = uVar;
        this.f564b = b0Var;
        this.f565c = ((q) uVar).b(new f0(this, 1));
        this.f566d = ((q) ((u) this.f563a)).b(new f0(this, 0));
    }
}
