package a4;

import r3.f0;
import v7.r0;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public String f567a;

    /* renamed from: b  reason: collision with root package name */
    public f0 f568b;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return r0.b(this.f567a, qVar.f567a) && this.f568b == qVar.f568b;
    }

    public final int hashCode() {
        return this.f568b.hashCode() + (this.f567a.hashCode() * 31);
    }

    public final String toString() {
        return "IdAndState(id=" + this.f567a + ", state=" + this.f568b + ')';
    }
}
