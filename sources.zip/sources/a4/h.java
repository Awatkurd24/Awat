package a4;

import a3.x;
import m.d;
import s0.a;
import s0.b;

public final class h extends d {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ int f547d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ Object f548e;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(int i10, Object obj) {
        super(1, 0);
        this.f547d = i10;
        this.f548e = obj;
    }

    public void f() {
        int i10 = this.f547d;
        Object obj = this.f548e;
        switch (i10) {
            case 0:
                ((a) obj).clear();
                return;
            default:
                ((b) obj).clear();
                return;
        }
    }

    public Object g(int i10, int i11) {
        int i12 = this.f547d;
        Object obj = this.f548e;
        switch (i12) {
            case 0:
                return ((a) obj).f25751b[(i10 << 1) + i11];
            default:
                return ((b) obj).f25715b[i10];
        }
    }

    public a h() {
        switch (this.f547d) {
            case 0:
                return (a) this.f548e;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public int i() {
        int i10 = this.f547d;
        Object obj = this.f548e;
        switch (i10) {
            case 0:
                return ((a) obj).f25752c;
            default:
                return ((b) obj).f25716c;
        }
    }

    public int j(Object obj) {
        int i10 = this.f547d;
        Object obj2 = this.f548e;
        switch (i10) {
            case 0:
                return ((a) obj2).f(obj);
            default:
                return ((b) obj2).indexOf(obj);
        }
    }

    public int k(Object obj) {
        int i10 = this.f547d;
        Object obj2 = this.f548e;
        switch (i10) {
            case 0:
                return ((a) obj2).h(obj);
            default:
                return ((b) obj2).indexOf(obj);
        }
    }

    public void l(Object obj, Object obj2) {
        int i10 = this.f547d;
        Object obj3 = this.f548e;
        switch (i10) {
            case 0:
                ((a) obj3).put(obj, obj2);
                return;
            default:
                ((b) obj3).add(obj);
                return;
        }
    }

    public void m(int i10) {
        int i11 = this.f547d;
        Object obj = this.f548e;
        switch (i11) {
            case 0:
                ((a) obj).j(i10);
                return;
            default:
                ((b) obj).q(i10);
                return;
        }
    }

    public Object n(int i10, Object obj) {
        switch (this.f547d) {
            case 0:
                int i11 = (i10 << 1) + 1;
                Object[] objArr = ((a) this.f548e).f25751b;
                Object obj2 = objArr[i11];
                objArr[i11] = obj;
                return obj2;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public String p() {
        switch (this.f547d) {
            case 0:
                return "DELETE FROM SystemIdInfo where work_spec_id=? AND generation=?";
            case 1:
                return "DELETE FROM SystemIdInfo where work_spec_id=?";
            default:
                return "DELETE FROM worktag WHERE work_spec_id=?";
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(Object obj, x xVar, int i10) {
        super(xVar);
        this.f547d = i10;
        this.f548e = obj;
    }
}
