package a4;

import v7.r0;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final String f532a;

    /* renamed from: b  reason: collision with root package name */
    public final String f533b;

    public a(String str, String str2) {
        r0.j("prerequisiteId", str2);
        this.f532a = str;
        this.f533b = str2;
    }
}
