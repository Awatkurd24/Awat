package a4;

import v7.r0;

public final class v {

    /* renamed from: a  reason: collision with root package name */
    public final String f614a;

    /* renamed from: b  reason: collision with root package name */
    public final String f615b;

    public v(String str, String str2) {
        r0.j("tag", str);
        this.f614a = str;
        this.f615b = str2;
    }
}
