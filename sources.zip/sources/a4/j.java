package a4;

import v7.r0;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public final String f553a;

    /* renamed from: b  reason: collision with root package name */
    public final int f554b;

    public j(String str, int i10) {
        r0.j("workSpecId", str);
        this.f553a = str;
        this.f554b = i10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return r0.b(this.f553a, jVar.f553a) && this.f554b == jVar.f554b;
    }

    public final int hashCode() {
        return (this.f553a.hashCode() * 31) + this.f554b;
    }

    public final String toString() {
        return "WorkGenerationalId(workSpecId=" + this.f553a + ", generation=" + this.f554b + ')';
    }
}
