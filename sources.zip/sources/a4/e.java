package a4;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IInterface;
import android.os.Parcel;
import android.text.TextUtils;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import androidx.lifecycle.g0;
import androidx.lifecycle.i0;
import androidx.work.impl.WorkDatabase;
import b0.p0;
import b0.q0;
import b0.x;
import b6.b;
import cf.q;
import com.google.android.gms.common.moduleinstall.internal.ApiFeatureRequest;
import com.google.android.gms.internal.ads.fr;
import com.google.android.gms.internal.ads.u5;
import com.google.android.gms.internal.ads.w5;
import com.google.android.gms.internal.measurement.c0;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.gson.internal.l;
import com.google.gson.internal.u;
import d8.a;
import d8.h;
import d8.i;
import df.d;
import e7.k;
import eg.n;
import h.z;
import i7.j;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Executor;
import lf.r;
import n1.f;
import p000if.v;
import rx.Observable;
import rx.functions.Func1;
import rx.subjects.PublishSubject;
import t.f1;
import t.t;
import u.a0;
import u.f0;
import u8.g;
import uf.c;
import v7.r0;
import v7.t9;
import w7.ua;
import w7.wa;
import xd.o;
import z.d1;
import z.t0;

public class e implements q0, f, b, u5, u6.b, a, k, c0, g, d8.g, l, Func1 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f540a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f541b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f542c;

    public e(int i10) {
        this.f540a = i10;
        if (i10 == 18) {
            return;
        }
        if (i10 != 20) {
            this.f541b = new e5.a((Integer) null);
            this.f542c = new HashMap();
            return;
        }
        this.f541b = new ArrayList();
        this.f542c = new ArrayList();
    }

    public final we.f A(lf.g gVar) {
        q qVar;
        n nVar;
        xe.a aVar;
        q qVar2 = (q) gVar;
        c b5 = qVar2.b();
        r[] rVarArr = r.f22026a;
        Class<?> declaringClass = qVar2.f4178a.getDeclaringClass();
        if (declaringClass != null) {
            qVar = new q(declaringClass);
        } else {
            qVar = null;
        }
        if (qVar != null) {
            we.f A = A(qVar);
            if (A != null) {
                nVar = A.l0();
            } else {
                nVar = null;
            }
            if (nVar != null) {
                aVar = nVar.b(qVar2.d(), d.f17795h);
            } else {
                aVar = null;
            }
            if (aVar instanceof we.f) {
                return (we.f) aVar;
            }
            return null;
        }
        c e10 = b5.e();
        r0.i("parent(...)", e10);
        p000if.q qVar3 = (p000if.q) o.f0(((hf.e) this.f541b).c(e10));
        if (qVar3 == null) {
            return null;
        }
        v vVar = qVar3.f20309j.f20242d;
        vVar.getClass();
        return vVar.v(qVar2.d(), gVar);
    }

    public void B(t tVar) {
        a0 a0Var;
        if (tVar != null) {
            f0 f0Var = (f0) this.f542c;
            synchronized (f0Var.f26889a) {
                a0Var = (a0) f0Var.f26889a.remove(tVar);
            }
        } else {
            a0Var = null;
        }
        if (a0Var != null) {
            a0Var.a();
        }
        ((CameraManager) this.f541b).unregisterAvailabilityCallback(a0Var);
    }

    public final void C(b0.t tVar, z.f fVar) {
        z.e eVar;
        switch (tVar.ordinal()) {
            case 0:
                x xVar = (x) this.f541b;
                synchronized (xVar.f3468b) {
                    Iterator it = xVar.f3471e.entrySet().iterator();
                    while (true) {
                        if (it.hasNext()) {
                            if (((b0.v) ((Map.Entry) it.next()).getValue()).f3463a == b0.t.CLOSING) {
                                eVar = new z.e(2, (z.f) null);
                                break;
                            }
                        } else {
                            eVar = new z.e(1, (z.f) null);
                            break;
                        }
                    }
                }
            case 1:
                eVar = new z.e(2, fVar);
                break;
            case 2:
            case 3:
                eVar = new z.e(3, fVar);
                break;
            case 4:
            case 6:
                eVar = new z.e(4, fVar);
                break;
            case 5:
            case 7:
                eVar = new z.e(5, fVar);
                break;
            default:
                throw new IllegalStateException("Unknown internal camera state: " + tVar);
        }
        t9.a("CameraStateMachine", "New public camera state " + eVar + " from " + tVar + " and " + fVar);
        if (!Objects.equals((z.e) ((i0) this.f542c).d(), eVar)) {
            t9.a("CameraStateMachine", "Publishing new public camera state " + eVar);
            ((i0) this.f542c).k(eVar);
        }
    }

    public final Object Y() {
        try {
            return u.f17203a.a((Class) this.f541b);
        } catch (Exception e10) {
            throw new RuntimeException("Unable to create instance of " + ((Class) this.f541b) + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", e10);
        }
    }

    public final Surface a() {
        return ((q0) this.f541b).a();
    }

    public final t0 b() {
        if (((q0) this.f541b).b() == null) {
            return null;
        }
        f.c.w(this.f542c);
        ua.g("Pending request should not be null", false);
        f.c.w(this.f542c);
        throw null;
    }

    public final int c() {
        return ((q0) this.f541b).c();
    }

    public final Object call(Object obj) {
        md.d dVar;
        md.a aVar;
        md.c cVar = (md.c) this.f542c;
        String[] strArr = (String[]) this.f541b;
        cVar.getClass();
        ArrayList arrayList = new ArrayList(strArr.length);
        ArrayList arrayList2 = new ArrayList();
        int length = strArr.length;
        int i10 = 0;
        while (true) {
            dVar = cVar.f22692a;
            if (i10 >= length) {
                break;
            }
            String str = strArr[i10];
            dVar.getClass();
            int i11 = Build.VERSION.SDK_INT;
            if (i11 < 23 || dVar.getActivity().checkSelfPermission(str) == 0) {
                aVar = new md.a(str, true, false);
            } else if (i11 < 23 || !dVar.getActivity().getPackageManager().isPermissionRevokedByPolicy(str, dVar.getActivity().getPackageName())) {
                HashMap hashMap = dVar.f22693a;
                PublishSubject publishSubject = (PublishSubject) hashMap.get(str);
                if (publishSubject == null) {
                    arrayList2.add(str);
                    publishSubject = PublishSubject.create();
                    PublishSubject publishSubject2 = (PublishSubject) hashMap.put(str, publishSubject);
                }
                arrayList.add(publishSubject);
                i10++;
            } else {
                aVar = new md.a(str, false, false);
            }
            arrayList.add(Observable.just(aVar));
            i10++;
        }
        if (!arrayList2.isEmpty()) {
            String[] strArr2 = (String[]) arrayList2.toArray(new String[arrayList2.size()]);
            TextUtils.join(", ", strArr2);
            dVar.getClass();
            dVar.requestPermissions(strArr2, 42);
        }
        return Observable.concat(Observable.from(arrayList));
    }

    public final void close() {
        ((q0) this.f541b).close();
    }

    public final void d() {
        ((k3.r) this.f541b).d();
    }

    public final void e(w5 w5Var) {
        String obj = w5Var.toString();
        fr.g("Failed to load URL: " + ((String) this.f541b) + "\n" + obj);
        ((r6.t) this.f542c).b((Object) null);
    }

    public final void f() {
        ((q0) this.f541b).f();
    }

    public final void g(p0 p0Var, Executor executor) {
        ((q0) this.f541b).g(new d1(this, p0Var, 1), executor);
    }

    public final Object get() {
        return new a6.f((Context) ((vd.a) this.f541b).get(), (a6.d) ((vd.a) this.f542c).get());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0020, code lost:
        r0 = (android.view.View) ((com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r4.f542c).getParent();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int getHeight() {
        /*
            r4 = this;
            int r0 = r4.f540a
            switch(r0) {
                case 4: goto L_0x006b;
                default: goto L_0x0005;
            }
        L_0x0005:
            java.lang.Object r0 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r0 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r0
            int r1 = r0.H
            r2 = -1
            r3 = -2
            if (r1 != r2) goto L_0x0065
            android.view.ViewParent r0 = r0.getParent()
            boolean r0 = r0 instanceof android.view.View
            if (r0 != 0) goto L_0x0020
        L_0x0017:
            java.lang.Object r0 = r4.f541b
            u8.g r0 = (u8.g) r0
            int r1 = r0.getHeight()
            goto L_0x006a
        L_0x0020:
            java.lang.Object r0 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r0 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r0
            android.view.ViewParent r0 = r0.getParent()
            android.view.View r0 = (android.view.View) r0
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            if (r1 == 0) goto L_0x0035
            int r1 = r1.height
            if (r1 != r3) goto L_0x0035
            goto L_0x0017
        L_0x0035:
            int r1 = r0.getPaddingTop()
            int r2 = r0.getPaddingBottom()
            int r2 = r2 + r1
            java.lang.Object r1 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r1 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r1
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            boolean r1 = r1 instanceof android.view.ViewGroup.MarginLayoutParams
            if (r1 == 0) goto L_0x005c
            java.lang.Object r1 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r1 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r1
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r1 = (android.view.ViewGroup.MarginLayoutParams) r1
            if (r1 == 0) goto L_0x005c
            int r3 = r1.topMargin
            int r1 = r1.bottomMargin
            int r3 = r3 + r1
            goto L_0x005d
        L_0x005c:
            r3 = 0
        L_0x005d:
            int r0 = r0.getHeight()
            int r0 = r0 - r3
            int r1 = r0 - r2
            goto L_0x006a
        L_0x0065:
            if (r1 == 0) goto L_0x0017
            if (r1 != r3) goto L_0x006a
            goto L_0x0017
        L_0x006a:
            return r1
        L_0x006b:
            java.lang.Object r0 = r4.f541b
            b0.q0 r0 = (b0.q0) r0
            int r0 = r0.getHeight()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.e.getHeight():int");
    }

    public final ViewGroup.LayoutParams getLayoutParams() {
        int i10;
        Object obj = this.f542c;
        if (((ExtendedFloatingActionButton) obj).H == 0) {
            i10 = -2;
        } else {
            i10 = ((ExtendedFloatingActionButton) obj).H;
        }
        return new ViewGroup.LayoutParams(-1, i10);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x001a, code lost:
        r0 = (android.view.View) ((com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r4.f542c).getParent();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int getWidth() {
        /*
            r4 = this;
            int r0 = r4.f540a
            switch(r0) {
                case 4: goto L_0x005f;
                default: goto L_0x0005;
            }
        L_0x0005:
            java.lang.Object r0 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r0 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r0
            android.view.ViewParent r0 = r0.getParent()
            boolean r0 = r0 instanceof android.view.View
            if (r0 != 0) goto L_0x001a
        L_0x0011:
            java.lang.Object r0 = r4.f541b
            u8.g r0 = (u8.g) r0
            int r0 = r0.getWidth()
            goto L_0x005e
        L_0x001a:
            java.lang.Object r0 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r0 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r0
            android.view.ViewParent r0 = r0.getParent()
            android.view.View r0 = (android.view.View) r0
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            if (r1 == 0) goto L_0x0030
            int r1 = r1.width
            r2 = -2
            if (r1 != r2) goto L_0x0030
            goto L_0x0011
        L_0x0030:
            int r1 = r0.getPaddingLeft()
            int r2 = r0.getPaddingRight()
            int r2 = r2 + r1
            java.lang.Object r1 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r1 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r1
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            boolean r1 = r1 instanceof android.view.ViewGroup.MarginLayoutParams
            if (r1 == 0) goto L_0x0057
            java.lang.Object r1 = r4.f542c
            com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton r1 = (com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton) r1
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r1 = (android.view.ViewGroup.MarginLayoutParams) r1
            if (r1 == 0) goto L_0x0057
            int r3 = r1.leftMargin
            int r1 = r1.rightMargin
            int r3 = r3 + r1
            goto L_0x0058
        L_0x0057:
            r3 = 0
        L_0x0058:
            int r0 = r0.getWidth()
            int r0 = r0 - r3
            int r0 = r0 - r2
        L_0x005e:
            return r0
        L_0x005f:
            java.lang.Object r0 = r4.f541b
            b0.q0 r0 = (b0.q0) r0
            int r0 = r0.getWidth()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.e.getWidth():int");
    }

    public final p h(com.google.android.gms.internal.measurement.n nVar) {
        p g10 = ((p) this.f541b).g();
        g10.k((String) this.f542c, nVar);
        return g10;
    }

    public final void i(f7.g gVar, Object obj) {
        i7.f fVar = new i7.f((i) obj, 1);
        i7.d dVar = (i7.d) ((j) gVar).p();
        Parcel Z = dVar.Z();
        q7.b.d(Z, fVar);
        q7.b.c(Z, (ApiFeatureRequest) this.f542c);
        q7.b.d(Z, (IInterface) null);
        dVar.k0(Z, 2);
    }

    public final int j() {
        return ((q0) this.f541b).j();
    }

    public final void k(int[] iArr, String str) {
        ((List) this.f541b).add(iArr);
        ((List) this.f542c).add(str);
    }

    public final Object l(h hVar) {
        Bundle bundle;
        c7.b bVar = (c7.b) this.f541b;
        Bundle bundle2 = (Bundle) this.f542c;
        bVar.getClass();
        if (hVar.i() && (bundle = (Bundle) hVar.g()) != null && bundle.containsKey("google.messenger")) {
            return bVar.a(bundle2).j(c7.n.f4075a, c7.c.f4043b);
        }
        return hVar;
    }

    public final t0 m() {
        if (((q0) this.f541b).m() == null) {
            return null;
        }
        f.c.w(this.f542c);
        ua.g("Pending request should not be null", false);
        f.c.w(this.f542c);
        throw null;
    }

    public final d8.r n(Object obj) {
        return ((la.n) this.f542c).f21794e.u(new d0.b((Object) this, 8, (Object) (Boolean) obj));
    }

    public final int o() {
        return ((ExtendedFloatingActionButton) this.f542c).A;
    }

    public CameraCharacteristics p(String str) {
        try {
            return ((CameraManager) this.f541b).getCameraCharacteristics(str);
        } catch (CameraAccessException e10) {
            throw u.g.a(e10);
        }
    }

    public Set q() {
        return Collections.emptySet();
    }

    public final KeyListener r(KeyListener keyListener) {
        if (!(keyListener instanceof NumberKeyListener)) {
            return ((wa) ((j2.b) this.f542c).f20593d).e(keyListener);
        }
        return keyListener;
    }

    public final Long s(String str) {
        a3.a0 p5 = a3.a0.p(1, "SELECT long_value FROM Preference where `key`=?");
        p5.m(1, str);
        ((a3.x) this.f541b).b();
        Cursor i10 = ne.c0.i((a3.x) this.f541b, p5, false);
        try {
            Long l10 = null;
            if (i10.moveToFirst()) {
                if (!i10.isNull(0)) {
                    l10 = Long.valueOf(i10.getLong(0));
                }
            }
            return l10;
        } finally {
            i10.close();
            p5.q();
        }
    }

    public final void t(d dVar) {
        ((a3.x) this.f541b).b();
        ((a3.x) this.f541b).c();
        try {
            ((a3.e) this.f542c).M(dVar);
            ((a3.x) this.f541b).n();
        } finally {
            ((a3.x) this.f541b).j();
        }
    }

    public final String toString() {
        switch (this.f540a) {
            case 7:
                StringBuilder sb2 = new StringBuilder("LinkedMultimap( ");
                e5.a aVar = ((e5.a) this.f541b).f17942b;
                while (!r0.b(aVar, (e5.a) this.f541b)) {
                    sb2.append('{');
                    sb2.append(aVar.f17941a);
                    sb2.append(':');
                    aVar.getClass();
                    sb2.append(0);
                    sb2.append('}');
                    aVar = aVar.f17942b;
                    if (!r0.b(aVar, (e5.a) this.f541b)) {
                        sb2.append(", ");
                    }
                }
                sb2.append(" )");
                String sb3 = sb2.toString();
                r0.i("StringBuilder().apply(builderAction).toString()", sb3);
                return sb3;
            default:
                return super.toString();
        }
    }

    /* JADX INFO: finally extract failed */
    public final void u(AttributeSet attributeSet, int i10) {
        TypedArray obtainStyledAttributes = ((EditText) this.f541b).getContext().obtainStyledAttributes(attributeSet, g.a.f18928j, i10, 0);
        try {
            boolean z4 = true;
            if (obtainStyledAttributes.hasValue(14)) {
                z4 = obtainStyledAttributes.getBoolean(14, true);
            }
            obtainStyledAttributes.recycle();
            ((wa) ((j2.b) this.f542c).f20593d).o(z4);
        } catch (Throwable th2) {
            obtainStyledAttributes.recycle();
            throw th2;
        }
    }

    public final InputConnection v(InputConnection inputConnection, EditorInfo editorInfo) {
        j2.b bVar = (j2.b) this.f542c;
        if (inputConnection != null) {
            return ((wa) bVar.f20593d).n(inputConnection, editorInfo);
        }
        bVar.getClass();
        return null;
    }

    public final void w(o1.e eVar) {
        int i10 = eVar.f23548b;
        if (i10 == 0) {
            ((Handler) this.f542c).post(new o1.a(this, (z) this.f541b, eVar.f23547a, 0));
            return;
        }
        ((Handler) this.f542c).post(new c.d(this, (z) this.f541b, i10, 6, 0));
    }

    public final int x() {
        return ((ExtendedFloatingActionButton) this.f542c).f16576z;
    }

    public void y(String str, d0.h hVar, CameraDevice.StateCallback stateCallback) {
        hVar.getClass();
        stateCallback.getClass();
        try {
            ((CameraManager) this.f541b).openCamera(str, new u.u(hVar, stateCallback), ((f0) this.f542c).f26890b);
        } catch (CameraAccessException e10) {
            throw new u.g(e10);
        }
    }

    public void z(d0.h hVar, t tVar) {
        a0 a0Var;
        f0 f0Var = (f0) this.f542c;
        synchronized (f0Var.f26889a) {
            try {
                a0Var = (a0) f0Var.f26889a.get(tVar);
                if (a0Var == null) {
                    a0Var = new a0(hVar, tVar);
                    f0Var.f26889a.put(tVar, a0Var);
                }
            } catch (Throwable th2) {
                while (true) {
                    throw th2;
                }
            }
        }
        ((CameraManager) this.f541b).registerAvailabilityCallback(a0Var, f0Var.f26890b);
    }

    public e(Context context, f0 f0Var) {
        this.f540a = 3;
        this.f541b = (CameraManager) context.getSystemService("camera");
        this.f542c = f0Var;
    }

    public e(EditText editText) {
        this.f540a = 1;
        this.f541b = editText;
        this.f542c = new j2.b(editText);
    }

    public e(WorkDatabase workDatabase) {
        this.f540a = 0;
        this.f541b = workDatabase;
        this.f542c = new b(this, workDatabase, 1);
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [java.lang.Object, androidx.lifecycle.g0, androidx.lifecycle.i0] */
    public e(x xVar) {
        this.f540a = 2;
        this.f541b = xVar;
        ? g0Var = new g0();
        this.f542c = g0Var;
        g0Var.k(new z.e(5, (z.f) null));
    }

    public e(hf.e eVar) {
        x7.b bVar = ff.j.O0;
        this.f540a = 22;
        this.f541b = eVar;
        this.f542c = bVar;
    }

    public /* synthetic */ e(Object obj, int i10, Object obj2) {
        this.f540a = i10;
        this.f541b = obj;
        this.f542c = obj2;
    }

    public /* synthetic */ e(Object obj, Object obj2, int i10) {
        this.f540a = i10;
        this.f542c = obj;
        this.f541b = obj2;
    }

    public e(String str, r6.t tVar) {
        this.f540a = 9;
        this.f541b = str;
        this.f542c = tVar;
    }

    public e(f1 f1Var) {
        this.f540a = 4;
        this.f541b = f1Var;
    }
}
