package a4;

import a3.e;
import a3.x;
import f3.i;
import gc.d;
import r3.f;
import r3.j;
import v7.r0;

public final class b extends e {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ int f534d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ Object f535e;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(Object obj, x xVar, int i10) {
        super(xVar);
        this.f534d = i10;
        this.f535e = obj;
        r0.j("database", xVar);
    }

    public final void L(i iVar, Object obj) {
        switch (this.f534d) {
            case 0:
                a aVar = (a) obj;
                String str = aVar.f532a;
                if (str == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str);
                }
                String str2 = aVar.f533b;
                if (str2 == null) {
                    iVar.t(2);
                    return;
                } else {
                    iVar.m(2, str2);
                    return;
                }
            case 1:
                d dVar = (d) obj;
                String str3 = dVar.f538a;
                if (str3 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str3);
                }
                Long l10 = dVar.f539b;
                if (l10 == null) {
                    iVar.t(2);
                    return;
                } else {
                    iVar.D(2, l10.longValue());
                    return;
                }
            case 2:
                g gVar = (g) obj;
                String str4 = gVar.f544a;
                if (str4 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str4);
                }
                iVar.D(2, (long) gVar.f545b);
                iVar.D(3, (long) gVar.f546c);
                return;
            case 3:
                k kVar = (k) obj;
                String str5 = kVar.f555a;
                if (str5 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str5);
                }
                String str6 = kVar.f556b;
                if (str6 == null) {
                    iVar.t(2);
                    return;
                } else {
                    iVar.m(2, str6);
                    return;
                }
            case 4:
                n nVar = (n) obj;
                String str7 = nVar.f560a;
                if (str7 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str7);
                }
                byte[] c10 = j.c(nVar.f561b);
                if (c10 == null) {
                    iVar.t(2);
                    return;
                } else {
                    iVar.G(2, c10);
                    return;
                }
            case 5:
                s sVar = (s) obj;
                String str8 = sVar.f578a;
                if (str8 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str8);
                }
                iVar.D(2, (long) d.j(sVar.f579b));
                String str9 = sVar.f580c;
                if (str9 == null) {
                    iVar.t(3);
                } else {
                    iVar.m(3, str9);
                }
                String str10 = sVar.f581d;
                if (str10 == null) {
                    iVar.t(4);
                } else {
                    iVar.m(4, str10);
                }
                byte[] c11 = j.c(sVar.f582e);
                if (c11 == null) {
                    iVar.t(5);
                } else {
                    iVar.G(5, c11);
                }
                byte[] c12 = j.c(sVar.f583f);
                if (c12 == null) {
                    iVar.t(6);
                } else {
                    iVar.G(6, c12);
                }
                iVar.D(7, sVar.f584g);
                iVar.D(8, sVar.f585h);
                iVar.D(9, sVar.f586i);
                iVar.D(10, (long) sVar.f588k);
                iVar.D(11, (long) d.a(sVar.f589l));
                iVar.D(12, sVar.f590m);
                iVar.D(13, sVar.f591n);
                iVar.D(14, sVar.f592o);
                iVar.D(15, sVar.f593p);
                iVar.D(16, sVar.f594q ? 1 : 0);
                iVar.D(17, (long) d.h(sVar.f595r));
                iVar.D(18, (long) sVar.f596s);
                iVar.D(19, (long) sVar.f597t);
                f fVar = sVar.f587j;
                if (fVar != null) {
                    iVar.D(20, (long) d.g(fVar.f25332a));
                    iVar.D(21, fVar.f25333b ? 1 : 0);
                    iVar.D(22, fVar.f25334c ? 1 : 0);
                    iVar.D(23, fVar.f25335d ? 1 : 0);
                    iVar.D(24, fVar.f25336e ? 1 : 0);
                    iVar.D(25, fVar.f25337f);
                    iVar.D(26, fVar.f25338g);
                    iVar.G(27, d.i(fVar.f25339h));
                    return;
                }
                iVar.t(20);
                iVar.t(21);
                iVar.t(22);
                iVar.t(23);
                iVar.t(24);
                iVar.t(25);
                iVar.t(26);
                iVar.t(27);
                return;
            default:
                v vVar = (v) obj;
                String str11 = vVar.f614a;
                if (str11 == null) {
                    iVar.t(1);
                } else {
                    iVar.m(1, str11);
                }
                String str12 = vVar.f615b;
                if (str12 == null) {
                    iVar.t(2);
                    return;
                } else {
                    iVar.m(2, str12);
                    return;
                }
        }
    }

    public final String p() {
        switch (this.f534d) {
            case 0:
                return "INSERT OR IGNORE INTO `Dependency` (`work_spec_id`,`prerequisite_id`) VALUES (?,?)";
            case 1:
                return "INSERT OR REPLACE INTO `Preference` (`key`,`long_value`) VALUES (?,?)";
            case 2:
                return "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`generation`,`system_id`) VALUES (?,?,?)";
            case 3:
                return "INSERT OR IGNORE INTO `WorkName` (`name`,`work_spec_id`) VALUES (?,?)";
            case 4:
                return "INSERT OR REPLACE INTO `WorkProgress` (`work_spec_id`,`progress`) VALUES (?,?)";
            case 5:
                return "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`last_enqueue_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`period_count`,`generation`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            default:
                return "INSERT OR IGNORE INTO `WorkTag` (`tag`,`work_spec_id`) VALUES (?,?)";
        }
    }
}
