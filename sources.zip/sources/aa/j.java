package aa;

import a4.m;
import android.content.Context;
import android.text.TextUtils;
import d0.g;
import f7.l;
import java.util.Arrays;
import k7.d;
import l7.a;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public final String f771a;

    /* renamed from: b  reason: collision with root package name */
    public final String f772b;

    /* renamed from: c  reason: collision with root package name */
    public final String f773c;

    /* renamed from: d  reason: collision with root package name */
    public final String f774d;

    /* renamed from: e  reason: collision with root package name */
    public final String f775e;

    /* renamed from: f  reason: collision with root package name */
    public final String f776f;

    /* renamed from: g  reason: collision with root package name */
    public final String f777g;

    public j(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        boolean z4;
        int i10 = d.f21421a;
        if (str == null || str.trim().isEmpty()) {
            z4 = true;
        } else {
            z4 = false;
        }
        a.l("ApplicationId must be set.", true ^ z4);
        this.f772b = str;
        this.f771a = str2;
        this.f773c = str3;
        this.f774d = str4;
        this.f775e = str5;
        this.f776f = str6;
        this.f777g = str7;
    }

    public static j a(Context context) {
        l lVar = new l(context);
        String a10 = lVar.a("google_app_id");
        if (TextUtils.isEmpty(a10)) {
            return null;
        }
        return new j(a10, lVar.a("google_api_key"), lVar.a("firebase_database_url"), lVar.a("ga_trackingId"), lVar.a("gcm_defaultSenderId"), lVar.a("google_storage_bucket"), lVar.a("project_id"));
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return g.f(this.f772b, jVar.f772b) && g.f(this.f771a, jVar.f771a) && g.f(this.f773c, jVar.f773c) && g.f(this.f774d, jVar.f774d) && g.f(this.f775e, jVar.f775e) && g.f(this.f776f, jVar.f776f) && g.f(this.f777g, jVar.f777g);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f772b, this.f771a, this.f773c, this.f774d, this.f775e, this.f776f, this.f777g});
    }

    public final String toString() {
        m mVar = new m((Object) this);
        mVar.a("applicationId", this.f772b);
        mVar.a("apiKey", this.f771a);
        mVar.a("databaseUrl", this.f773c);
        mVar.a("gcmSenderId", this.f775e);
        mVar.a("storageBucket", this.f776f);
        mVar.a("projectId", this.f777g);
        return mVar.toString();
    }
}
