package aa;

import android.media.MediaCodec;
import java.util.function.Consumer;

public abstract /* synthetic */ class i {
    public static /* synthetic */ MediaCodec.CryptoInfo.Pattern g() {
        return new MediaCodec.CryptoInfo.Pattern(0, 0);
    }

    public static /* synthetic */ MediaCodec.CryptoInfo.Pattern h(int i10, int i11) {
        return new MediaCodec.CryptoInfo.Pattern(i10, i11);
    }

    public static /* bridge */ /* synthetic */ Class l() {
        return Consumer.class;
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: MethodInlineVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.visitors.MethodInlineVisitor.inlineMth(MethodInlineVisitor.java:57)
        	at jadx.core.dex.visitors.MethodInlineVisitor.visit(MethodInlineVisitor.java:47)
        */
    public static /* synthetic */ void n() {
        /*
            android.media.MediaCodec$CryptoInfo$Pattern r0 = new android.media.MediaCodec$CryptoInfo$Pattern
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: aa.i.n():void");
    }
}
