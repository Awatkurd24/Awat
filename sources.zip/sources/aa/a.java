package aa;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final long f744a;

    /* renamed from: b  reason: collision with root package name */
    public final long f745b;

    /* renamed from: c  reason: collision with root package name */
    public final long f746c;

    public a(long j3, long j10, long j11) {
        this.f744a = j3;
        this.f745b = j10;
        this.f746c = j11;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (this.f744a == aVar.f744a && this.f745b == aVar.f745b && this.f746c == aVar.f746c) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        long j3 = this.f744a;
        long j10 = this.f745b;
        long j11 = this.f746c;
        return ((int) ((j11 >>> 32) ^ j11)) ^ ((((((int) (j3 ^ (j3 >>> 32))) ^ 1000003) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003);
    }

    public final String toString() {
        return "StartupTime{epochMillis=" + this.f744a + ", elapsedRealtime=" + this.f745b + ", uptimeMillis=" + this.f746c + "}";
    }
}
