package aa;

public final /* synthetic */ class d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f750a;

    public /* synthetic */ d(g gVar) {
        this.f750a = gVar;
    }
}
