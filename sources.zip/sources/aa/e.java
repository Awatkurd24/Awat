package aa;

import ab.c;
import android.util.Log;
import e7.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;

public final class e implements b {

    /* renamed from: a  reason: collision with root package name */
    public static final AtomicReference f751a = new AtomicReference();

    public final void a(boolean z4) {
        synchronized (g.f754k) {
            try {
                Iterator it = new ArrayList(g.f755l.values()).iterator();
                while (it.hasNext()) {
                    g gVar = (g) it.next();
                    if (gVar.f760e.get()) {
                        Log.d("FirebaseApp", "Notifying background state change listeners.");
                        Iterator it2 = gVar.f764i.iterator();
                        while (it2.hasNext()) {
                            g gVar2 = ((d) it2.next()).f750a;
                            if (!z4) {
                                ((c) gVar2.f763h.get()).c();
                            } else {
                                gVar2.getClass();
                            }
                        }
                    }
                }
            } finally {
            }
        }
    }
}
