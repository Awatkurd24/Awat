package aa;

import androidx.appcompat.widget.c4;
import ea.a;
import ea.b;
import ea.c;
import ea.d;
import fa.f;
import fa.s;
import java.util.concurrent.Executor;
import v7.r0;
import yg.s0;

public final class h implements f {

    /* renamed from: b  reason: collision with root package name */
    public static final h f766b = new h(0);

    /* renamed from: c  reason: collision with root package name */
    public static final h f767c = new h(1);

    /* renamed from: d  reason: collision with root package name */
    public static final h f768d = new h(2);

    /* renamed from: e  reason: collision with root package name */
    public static final h f769e = new h(3);

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f770a;

    public /* synthetic */ h(int i10) {
        this.f770a = i10;
    }

    public final s0 a(c4 c4Var) {
        Class<Executor> cls = Executor.class;
        switch (this.f770a) {
            case 0:
                Object b5 = c4Var.b(new s(a.class, cls));
                r0.i("c.get(Qualified.qualifie…a, Executor::class.java))", b5);
                return new s0((Executor) b5);
            case 1:
                Object b10 = c4Var.b(new s(c.class, cls));
                r0.i("c.get(Qualified.qualifie…a, Executor::class.java))", b10);
                return new s0((Executor) b10);
            case 2:
                Object b11 = c4Var.b(new s(b.class, cls));
                r0.i("c.get(Qualified.qualifie…a, Executor::class.java))", b11);
                return new s0((Executor) b11);
            default:
                Object b12 = c4Var.b(new s(d.class, cls));
                r0.i("c.get(Qualified.qualifie…a, Executor::class.java))", b12);
                return new s0((Executor) b12);
        }
    }

    public final /* bridge */ /* synthetic */ Object c(c4 c4Var) {
        switch (this.f770a) {
            case 0:
                return a(c4Var);
            case 1:
                return a(c4Var);
            case 2:
                return a(c4Var);
            default:
                return a(c4Var);
        }
    }
}
