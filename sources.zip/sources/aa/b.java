package aa;

public abstract class b {
}
