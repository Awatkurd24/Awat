package aa;

import a4.m;
import android.app.Application;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Trace;
import android.util.Base64;
import android.util.Log;
import cb.c;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.components.ComponentDiscoveryService;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.provider.FirebaseInitProvider;
import fa.b;
import fa.d;
import fa.e;
import fa.i;
import fa.o;
import h.z;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import n1.t;
import s0.a;
import s0.k;
import w7.u1;

public final class g {

    /* renamed from: k  reason: collision with root package name */
    public static final Object f754k = new Object();

    /* renamed from: l  reason: collision with root package name */
    public static final a f755l = new k();

    /* renamed from: a  reason: collision with root package name */
    public final Context f756a;

    /* renamed from: b  reason: collision with root package name */
    public final String f757b;

    /* renamed from: c  reason: collision with root package name */
    public final j f758c;

    /* renamed from: d  reason: collision with root package name */
    public final i f759d;

    /* renamed from: e  reason: collision with root package name */
    public final AtomicBoolean f760e;

    /* renamed from: f  reason: collision with root package name */
    public final AtomicBoolean f761f = new AtomicBoolean();

    /* renamed from: g  reason: collision with root package name */
    public final o f762g;

    /* renamed from: h  reason: collision with root package name */
    public final c f763h;

    /* renamed from: i  reason: collision with root package name */
    public final CopyOnWriteArrayList f764i;

    /* renamed from: j  reason: collision with root package name */
    public final CopyOnWriteArrayList f765j;

    public g(Context context, j jVar, String str) {
        AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        this.f760e = atomicBoolean;
        CopyOnWriteArrayList copyOnWriteArrayList = new CopyOnWriteArrayList();
        this.f764i = copyOnWriteArrayList;
        this.f765j = new CopyOnWriteArrayList();
        this.f756a = context;
        l7.a.g(str);
        this.f757b = str;
        this.f758c = jVar;
        a aVar = FirebaseInitProvider.f17013a;
        Trace.beginSection("Firebase");
        Trace.beginSection("ComponentDiscovery");
        ArrayList a10 = new e(context, new z(ComponentDiscoveryService.class)).a();
        Trace.endSection();
        Trace.beginSection("Runtime");
        ga.k kVar = ga.k.f19173a;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        arrayList.addAll(a10);
        arrayList.add(new d(1, new FirebaseCommonRegistrar()));
        arrayList.add(new d(1, new ExecutorsRegistrar()));
        arrayList2.add(b.c(context, Context.class, new Class[0]));
        arrayList2.add(b.c(this, g.class, new Class[0]));
        arrayList2.add(b.c(jVar, j.class, new Class[0]));
        u1 u1Var = new u1(5);
        if ((Build.VERSION.SDK_INT < 24 || t.a(context)) && FirebaseInitProvider.f17014b.get()) {
            arrayList2.add(b.c(aVar, a.class, new Class[0]));
        }
        i iVar = new i(kVar, arrayList, arrayList2, u1Var);
        this.f759d = iVar;
        Trace.endSection();
        this.f762g = new o(new c(this, 0, context));
        this.f763h = iVar.f(ab.c.class);
        d dVar = new d(this);
        a();
        if (atomicBoolean.get()) {
            e7.c.f18005e.f18006a.get();
        }
        copyOnWriteArrayList.add(dVar);
        Trace.endSection();
    }

    public static g c() {
        g gVar;
        synchronized (f754k) {
            try {
                gVar = (g) f755l.getOrDefault("[DEFAULT]", (Object) null);
                if (gVar != null) {
                    ((ab.c) gVar.f763h.get()).c();
                } else {
                    throw new IllegalStateException("Default FirebaseApp is not initialized in this process " + k7.c.c() + ". Make sure to call FirebaseApp.initializeApp(Context) first.");
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return gVar;
    }

    public static g f(Context context) {
        synchronized (f754k) {
            try {
                if (f755l.containsKey("[DEFAULT]")) {
                    g c10 = c();
                    return c10;
                }
                j a10 = j.a(context);
                if (a10 == null) {
                    Log.w("FirebaseApp", "Default FirebaseApp failed to initialize because no default options were found. This usually means that com.google.gms:google-services was not applied to your gradle project.");
                    return null;
                }
                g g10 = g(context, a10);
                return g10;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r2v2, types: [e7.b, java.lang.Object] */
    public static g g(Context context, j jVar) {
        g gVar;
        AtomicReference atomicReference = e.f751a;
        if (context.getApplicationContext() instanceof Application) {
            Application application = (Application) context.getApplicationContext();
            AtomicReference atomicReference2 = e.f751a;
            if (atomicReference2.get() == null) {
                ? obj = new Object();
                while (true) {
                    if (!atomicReference2.compareAndSet((Object) null, obj)) {
                        if (atomicReference2.get() != null) {
                            break;
                        }
                    } else {
                        e7.c.b(application);
                        e7.c.f18005e.a(obj);
                        break;
                    }
                }
            }
        }
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        synchronized (f754k) {
            a aVar = f755l;
            l7.a.l("FirebaseApp name " + "[DEFAULT]" + " already exists!", !aVar.containsKey("[DEFAULT]"));
            l7.a.k(context, "Application context cannot be null.");
            gVar = new g(context, jVar, "[DEFAULT]");
            aVar.put("[DEFAULT]", gVar);
        }
        gVar.e();
        return gVar;
    }

    public final void a() {
        l7.a.l("FirebaseApp was deleted", !this.f761f.get());
    }

    public final Object b(Class cls) {
        a();
        return this.f759d.a(cls);
    }

    public final String d() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        a();
        byte[] bytes = this.f757b.getBytes(Charset.defaultCharset());
        String str2 = null;
        if (bytes == null) {
            str = null;
        } else {
            str = Base64.encodeToString(bytes, 11);
        }
        sb2.append(str);
        sb2.append("+");
        a();
        byte[] bytes2 = this.f758c.f772b.getBytes(Charset.defaultCharset());
        if (bytes2 != null) {
            str2 = Base64.encodeToString(bytes2, 11);
        }
        sb2.append(str2);
        return sb2.toString();
    }

    public final void e() {
        boolean z4;
        int i10 = Build.VERSION.SDK_INT;
        Context context = this.f756a;
        if (i10 >= 24) {
            z4 = t.a(context);
        } else {
            z4 = true;
        }
        boolean z10 = !z4;
        String str = this.f757b;
        if (z10) {
            StringBuilder sb2 = new StringBuilder("Device in Direct Boot Mode: postponing initialization of Firebase APIs for app ");
            a();
            sb2.append(str);
            Log.i("FirebaseApp", sb2.toString());
            AtomicReference atomicReference = f.f752b;
            if (atomicReference.get() == null) {
                f fVar = new f(context);
                while (!atomicReference.compareAndSet((Object) null, fVar)) {
                    if (atomicReference.get() != null) {
                        return;
                    }
                }
                context.registerReceiver(fVar, new IntentFilter("android.intent.action.USER_UNLOCKED"));
                return;
            }
            return;
        }
        StringBuilder sb3 = new StringBuilder("Device unlocked: initializing all Firebase APIs for app ");
        a();
        sb3.append(str);
        Log.i("FirebaseApp", sb3.toString());
        a();
        this.f759d.h("[DEFAULT]".equals(str));
        ((ab.c) this.f763h.get()).c();
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        gVar.a();
        return this.f757b.equals(gVar.f757b);
    }

    public final boolean h() {
        boolean z4;
        a();
        gb.a aVar = (gb.a) this.f762g.get();
        synchronized (aVar) {
            z4 = aVar.f19176a;
        }
        return z4;
    }

    public final int hashCode() {
        return this.f757b.hashCode();
    }

    public final String toString() {
        m mVar = new m((Object) this);
        mVar.a("name", this.f757b);
        mVar.a("options", this.f758c);
        return mVar.toString();
    }
}
