package aa;

import ab.h;
import android.content.Context;
import fa.f;
import fa.i;
import fa.l;
import fa.s;
import gb.a;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import za.b;

public final /* synthetic */ class c implements cb.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f747a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f748b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f749c;

    public /* synthetic */ c(Context context, String str) {
        this.f747a = 2;
        this.f749c = context;
        this.f748b = str;
    }

    /* JADX WARNING: type inference failed for: r5v1, types: [androidx.appcompat.widget.c4, java.lang.Object] */
    public final Object get() {
        boolean z4;
        int i10 = this.f747a;
        Class<b> cls = b.class;
        Object obj = this.f748b;
        Object obj2 = this.f749c;
        switch (i10) {
            case 0:
                g gVar = (g) obj;
                String d10 = gVar.d();
                b bVar = (b) gVar.f759d.a(cls);
                return new a((Context) obj2, d10);
            case 1:
                i iVar = (i) obj;
                fa.b bVar2 = (fa.b) obj2;
                iVar.getClass();
                f fVar = bVar2.f18731f;
                ? obj3 = new Object();
                HashSet hashSet = new HashSet();
                HashSet hashSet2 = new HashSet();
                HashSet hashSet3 = new HashSet();
                HashSet hashSet4 = new HashSet();
                HashSet hashSet5 = new HashSet();
                for (l lVar : bVar2.f18728c) {
                    int i11 = lVar.f18753c;
                    if (i11 == 0) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    int i12 = lVar.f18752b;
                    s sVar = lVar.f18751a;
                    if (z4) {
                        if (i12 == 2) {
                            hashSet4.add(sVar);
                        } else {
                            hashSet.add(sVar);
                        }
                    } else if (i11 == 2) {
                        hashSet3.add(sVar);
                    } else if (i12 == 2) {
                        hashSet5.add(sVar);
                    } else {
                        hashSet2.add(sVar);
                    }
                }
                Set set = bVar2.f18732g;
                if (!set.isEmpty()) {
                    hashSet.add(s.a(cls));
                }
                obj3.f1315a = Collections.unmodifiableSet(hashSet);
                obj3.f1316b = Collections.unmodifiableSet(hashSet2);
                obj3.f1317c = Collections.unmodifiableSet(hashSet3);
                obj3.f1318d = Collections.unmodifiableSet(hashSet4);
                obj3.f1319e = Collections.unmodifiableSet(hashSet5);
                obj3.f1320f = set;
                obj3.f1321g = iVar;
                return fVar.c(obj3);
            default:
                return new h((Context) obj2, (String) obj);
        }
    }

    public /* synthetic */ c(Object obj, int i10, Object obj2) {
        this.f747a = i10;
        this.f748b = obj;
        this.f749c = obj2;
    }
}
