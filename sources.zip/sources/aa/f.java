package aa;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import s0.j;

public final class f extends BroadcastReceiver {

    /* renamed from: b  reason: collision with root package name */
    public static final AtomicReference f752b = new AtomicReference();

    /* renamed from: a  reason: collision with root package name */
    public final Context f753a;

    public f(Context context) {
        this.f753a = context;
    }

    public final void onReceive(Context context, Intent intent) {
        synchronized (g.f754k) {
            try {
                Iterator it = ((j) g.f755l.values()).iterator();
                while (it.hasNext()) {
                    ((g) it.next()).e();
                }
            } catch (Throwable th2) {
                while (true) {
                    throw th2;
                }
            }
        }
        this.f753a.unregisterReceiver(this);
    }
}
